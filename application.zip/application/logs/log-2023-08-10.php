<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-10 16:49:37 --> Config Class Initialized
INFO - 2023-08-10 16:49:37 --> Hooks Class Initialized
DEBUG - 2023-08-10 16:49:37 --> UTF-8 Support Enabled
INFO - 2023-08-10 16:49:37 --> Utf8 Class Initialized
INFO - 2023-08-10 16:49:37 --> URI Class Initialized
DEBUG - 2023-08-10 16:49:37 --> No URI present. Default controller set.
INFO - 2023-08-10 16:49:37 --> Router Class Initialized
INFO - 2023-08-10 16:49:37 --> Output Class Initialized
INFO - 2023-08-10 16:49:37 --> Security Class Initialized
DEBUG - 2023-08-10 16:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 16:49:37 --> Input Class Initialized
INFO - 2023-08-10 16:49:37 --> Language Class Initialized
INFO - 2023-08-10 16:49:37 --> Loader Class Initialized
INFO - 2023-08-10 16:49:37 --> Helper loaded: url_helper
INFO - 2023-08-10 16:49:37 --> Helper loaded: file_helper
INFO - 2023-08-10 16:49:37 --> Database Driver Class Initialized
INFO - 2023-08-10 16:49:37 --> Email Class Initialized
DEBUG - 2023-08-10 16:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 16:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 16:49:37 --> Controller Class Initialized
INFO - 2023-08-10 16:49:37 --> File loaded: C:\xampp\htdocs\DW\application\views\welcome_message.php
INFO - 2023-08-10 16:49:37 --> Final output sent to browser
DEBUG - 2023-08-10 16:49:37 --> Total execution time: 0.0633
INFO - 2023-08-10 16:49:42 --> Config Class Initialized
INFO - 2023-08-10 16:49:42 --> Hooks Class Initialized
DEBUG - 2023-08-10 16:49:42 --> UTF-8 Support Enabled
INFO - 2023-08-10 16:49:42 --> Utf8 Class Initialized
INFO - 2023-08-10 16:49:42 --> URI Class Initialized
INFO - 2023-08-10 16:49:42 --> Router Class Initialized
INFO - 2023-08-10 16:49:42 --> Output Class Initialized
INFO - 2023-08-10 16:49:42 --> Security Class Initialized
DEBUG - 2023-08-10 16:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 16:49:42 --> Input Class Initialized
INFO - 2023-08-10 16:49:42 --> Language Class Initialized
INFO - 2023-08-10 16:49:42 --> Loader Class Initialized
INFO - 2023-08-10 16:49:42 --> Helper loaded: url_helper
INFO - 2023-08-10 16:49:42 --> Helper loaded: file_helper
INFO - 2023-08-10 16:49:42 --> Database Driver Class Initialized
INFO - 2023-08-10 16:49:42 --> Email Class Initialized
DEBUG - 2023-08-10 16:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 16:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 16:49:42 --> Controller Class Initialized
INFO - 2023-08-10 16:49:42 --> Model "Gallery_model" initialized
INFO - 2023-08-10 16:49:42 --> Helper loaded: form_helper
INFO - 2023-08-10 16:49:42 --> Form Validation Class Initialized
INFO - 2023-08-10 16:49:42 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-10 16:49:42 --> Final output sent to browser
DEBUG - 2023-08-10 16:49:42 --> Total execution time: 0.0622
INFO - 2023-08-10 16:49:44 --> Config Class Initialized
INFO - 2023-08-10 16:49:44 --> Hooks Class Initialized
DEBUG - 2023-08-10 16:49:44 --> UTF-8 Support Enabled
INFO - 2023-08-10 16:49:44 --> Utf8 Class Initialized
INFO - 2023-08-10 16:49:44 --> URI Class Initialized
INFO - 2023-08-10 16:49:44 --> Router Class Initialized
INFO - 2023-08-10 16:49:44 --> Output Class Initialized
INFO - 2023-08-10 16:49:44 --> Security Class Initialized
DEBUG - 2023-08-10 16:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 16:49:44 --> Input Class Initialized
INFO - 2023-08-10 16:49:44 --> Language Class Initialized
INFO - 2023-08-10 16:49:44 --> Loader Class Initialized
INFO - 2023-08-10 16:49:44 --> Helper loaded: url_helper
INFO - 2023-08-10 16:49:44 --> Helper loaded: file_helper
INFO - 2023-08-10 16:49:44 --> Database Driver Class Initialized
INFO - 2023-08-10 16:49:44 --> Email Class Initialized
DEBUG - 2023-08-10 16:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 16:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 16:49:44 --> Controller Class Initialized
INFO - 2023-08-10 16:49:44 --> Model "Banner_model" initialized
INFO - 2023-08-10 16:49:44 --> Helper loaded: form_helper
INFO - 2023-08-10 16:49:44 --> Form Validation Class Initialized
INFO - 2023-08-10 16:49:44 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-10 16:49:44 --> Final output sent to browser
DEBUG - 2023-08-10 16:49:44 --> Total execution time: 0.0615
INFO - 2023-08-10 16:49:52 --> Config Class Initialized
INFO - 2023-08-10 16:49:52 --> Hooks Class Initialized
DEBUG - 2023-08-10 16:49:52 --> UTF-8 Support Enabled
INFO - 2023-08-10 16:49:52 --> Utf8 Class Initialized
INFO - 2023-08-10 16:49:52 --> URI Class Initialized
INFO - 2023-08-10 16:49:52 --> Router Class Initialized
INFO - 2023-08-10 16:49:52 --> Output Class Initialized
INFO - 2023-08-10 16:49:52 --> Security Class Initialized
DEBUG - 2023-08-10 16:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 16:49:52 --> Input Class Initialized
INFO - 2023-08-10 16:49:52 --> Language Class Initialized
INFO - 2023-08-10 16:49:52 --> Loader Class Initialized
INFO - 2023-08-10 16:49:52 --> Helper loaded: url_helper
INFO - 2023-08-10 16:49:52 --> Helper loaded: file_helper
INFO - 2023-08-10 16:49:52 --> Database Driver Class Initialized
INFO - 2023-08-10 16:49:52 --> Email Class Initialized
DEBUG - 2023-08-10 16:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 16:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 16:49:52 --> Controller Class Initialized
INFO - 2023-08-10 16:49:52 --> Model "Faq_model" initialized
INFO - 2023-08-10 16:49:52 --> Helper loaded: form_helper
INFO - 2023-08-10 16:49:52 --> Form Validation Class Initialized
INFO - 2023-08-10 16:49:52 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 16:49:52 --> Final output sent to browser
DEBUG - 2023-08-10 16:49:52 --> Total execution time: 0.0644
INFO - 2023-08-10 16:50:14 --> Config Class Initialized
INFO - 2023-08-10 16:50:14 --> Hooks Class Initialized
DEBUG - 2023-08-10 16:50:14 --> UTF-8 Support Enabled
INFO - 2023-08-10 16:50:14 --> Utf8 Class Initialized
INFO - 2023-08-10 16:50:14 --> URI Class Initialized
INFO - 2023-08-10 16:50:14 --> Router Class Initialized
INFO - 2023-08-10 16:50:14 --> Output Class Initialized
INFO - 2023-08-10 16:50:14 --> Security Class Initialized
DEBUG - 2023-08-10 16:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 16:50:14 --> Input Class Initialized
INFO - 2023-08-10 16:50:14 --> Language Class Initialized
ERROR - 2023-08-10 16:50:14 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-10 17:09:29 --> Config Class Initialized
INFO - 2023-08-10 17:09:29 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:09:29 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:09:29 --> Utf8 Class Initialized
INFO - 2023-08-10 17:09:29 --> URI Class Initialized
INFO - 2023-08-10 17:09:29 --> Router Class Initialized
INFO - 2023-08-10 17:09:29 --> Output Class Initialized
INFO - 2023-08-10 17:09:29 --> Security Class Initialized
DEBUG - 2023-08-10 17:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:09:29 --> Input Class Initialized
INFO - 2023-08-10 17:09:29 --> Language Class Initialized
INFO - 2023-08-10 17:09:29 --> Loader Class Initialized
INFO - 2023-08-10 17:09:29 --> Helper loaded: url_helper
INFO - 2023-08-10 17:09:29 --> Helper loaded: file_helper
INFO - 2023-08-10 17:09:29 --> Database Driver Class Initialized
INFO - 2023-08-10 17:09:29 --> Email Class Initialized
DEBUG - 2023-08-10 17:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:09:29 --> Controller Class Initialized
INFO - 2023-08-10 17:09:29 --> Model "Services_model" initialized
INFO - 2023-08-10 17:09:29 --> Helper loaded: form_helper
INFO - 2023-08-10 17:09:29 --> Form Validation Class Initialized
INFO - 2023-08-10 17:09:29 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-10 17:09:29 --> Final output sent to browser
DEBUG - 2023-08-10 17:09:29 --> Total execution time: 0.1827
INFO - 2023-08-10 17:09:29 --> Config Class Initialized
INFO - 2023-08-10 17:09:29 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:09:29 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:09:29 --> Utf8 Class Initialized
INFO - 2023-08-10 17:09:29 --> URI Class Initialized
INFO - 2023-08-10 17:09:29 --> Router Class Initialized
INFO - 2023-08-10 17:09:29 --> Output Class Initialized
INFO - 2023-08-10 17:09:29 --> Security Class Initialized
DEBUG - 2023-08-10 17:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:09:29 --> Input Class Initialized
INFO - 2023-08-10 17:09:29 --> Language Class Initialized
ERROR - 2023-08-10 17:09:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-10 17:09:49 --> Config Class Initialized
INFO - 2023-08-10 17:09:49 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:09:49 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:09:49 --> Utf8 Class Initialized
INFO - 2023-08-10 17:09:49 --> URI Class Initialized
INFO - 2023-08-10 17:09:49 --> Router Class Initialized
INFO - 2023-08-10 17:09:49 --> Output Class Initialized
INFO - 2023-08-10 17:09:49 --> Security Class Initialized
DEBUG - 2023-08-10 17:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:09:49 --> Input Class Initialized
INFO - 2023-08-10 17:09:49 --> Language Class Initialized
INFO - 2023-08-10 17:09:49 --> Loader Class Initialized
INFO - 2023-08-10 17:09:49 --> Helper loaded: url_helper
INFO - 2023-08-10 17:09:49 --> Helper loaded: file_helper
INFO - 2023-08-10 17:09:49 --> Database Driver Class Initialized
INFO - 2023-08-10 17:09:49 --> Email Class Initialized
DEBUG - 2023-08-10 17:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:09:49 --> Controller Class Initialized
INFO - 2023-08-10 17:09:49 --> Model "Services_model" initialized
INFO - 2023-08-10 17:09:49 --> Helper loaded: form_helper
INFO - 2023-08-10 17:09:49 --> Form Validation Class Initialized
INFO - 2023-08-10 17:09:49 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-10 17:09:49 --> Final output sent to browser
DEBUG - 2023-08-10 17:09:49 --> Total execution time: 0.1599
INFO - 2023-08-10 17:09:49 --> Config Class Initialized
INFO - 2023-08-10 17:09:49 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:09:49 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:09:49 --> Utf8 Class Initialized
INFO - 2023-08-10 17:09:49 --> URI Class Initialized
INFO - 2023-08-10 17:09:49 --> Router Class Initialized
INFO - 2023-08-10 17:09:49 --> Output Class Initialized
INFO - 2023-08-10 17:09:49 --> Security Class Initialized
DEBUG - 2023-08-10 17:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:09:49 --> Input Class Initialized
INFO - 2023-08-10 17:09:49 --> Language Class Initialized
ERROR - 2023-08-10 17:09:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-10 17:09:51 --> Config Class Initialized
INFO - 2023-08-10 17:09:51 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:09:51 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:09:51 --> Utf8 Class Initialized
INFO - 2023-08-10 17:09:51 --> URI Class Initialized
INFO - 2023-08-10 17:09:51 --> Router Class Initialized
INFO - 2023-08-10 17:09:51 --> Output Class Initialized
INFO - 2023-08-10 17:09:51 --> Security Class Initialized
DEBUG - 2023-08-10 17:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:09:51 --> Input Class Initialized
INFO - 2023-08-10 17:09:51 --> Language Class Initialized
INFO - 2023-08-10 17:09:52 --> Config Class Initialized
INFO - 2023-08-10 17:09:52 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:09:52 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:09:52 --> Utf8 Class Initialized
INFO - 2023-08-10 17:09:52 --> URI Class Initialized
INFO - 2023-08-10 17:09:52 --> Router Class Initialized
INFO - 2023-08-10 17:09:52 --> Output Class Initialized
INFO - 2023-08-10 17:09:52 --> Security Class Initialized
DEBUG - 2023-08-10 17:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:09:52 --> Input Class Initialized
INFO - 2023-08-10 17:09:52 --> Language Class Initialized
ERROR - 2023-08-10 17:09:52 --> 404 Page Not Found: admin/Faq/images
INFO - 2023-08-10 17:12:22 --> Config Class Initialized
INFO - 2023-08-10 17:12:22 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:12:22 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:12:22 --> Utf8 Class Initialized
INFO - 2023-08-10 17:12:22 --> URI Class Initialized
INFO - 2023-08-10 17:12:22 --> Router Class Initialized
INFO - 2023-08-10 17:12:22 --> Output Class Initialized
INFO - 2023-08-10 17:12:22 --> Security Class Initialized
DEBUG - 2023-08-10 17:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:12:22 --> Input Class Initialized
INFO - 2023-08-10 17:12:22 --> Language Class Initialized
INFO - 2023-08-10 17:12:22 --> Loader Class Initialized
INFO - 2023-08-10 17:12:22 --> Helper loaded: url_helper
INFO - 2023-08-10 17:12:22 --> Helper loaded: file_helper
INFO - 2023-08-10 17:12:22 --> Database Driver Class Initialized
INFO - 2023-08-10 17:12:22 --> Email Class Initialized
DEBUG - 2023-08-10 17:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:12:22 --> Controller Class Initialized
INFO - 2023-08-10 17:12:22 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:12:22 --> Helper loaded: form_helper
INFO - 2023-08-10 17:12:22 --> Form Validation Class Initialized
ERROR - 2023-08-10 17:12:22 --> Severity: Warning --> Undefined variable $service_id C:\xampp\htdocs\DW\application\views\admin\faq_create.php 59
INFO - 2023-08-10 17:12:22 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:12:22 --> Final output sent to browser
DEBUG - 2023-08-10 17:12:22 --> Total execution time: 0.3328
INFO - 2023-08-10 17:12:26 --> Config Class Initialized
INFO - 2023-08-10 17:12:26 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:12:26 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:12:26 --> Utf8 Class Initialized
INFO - 2023-08-10 17:12:26 --> URI Class Initialized
INFO - 2023-08-10 17:12:26 --> Router Class Initialized
INFO - 2023-08-10 17:12:26 --> Output Class Initialized
INFO - 2023-08-10 17:12:26 --> Security Class Initialized
DEBUG - 2023-08-10 17:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:12:26 --> Input Class Initialized
INFO - 2023-08-10 17:12:26 --> Language Class Initialized
INFO - 2023-08-10 17:12:26 --> Loader Class Initialized
INFO - 2023-08-10 17:12:26 --> Helper loaded: url_helper
INFO - 2023-08-10 17:12:26 --> Helper loaded: file_helper
INFO - 2023-08-10 17:12:26 --> Database Driver Class Initialized
INFO - 2023-08-10 17:12:26 --> Email Class Initialized
DEBUG - 2023-08-10 17:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:12:26 --> Controller Class Initialized
INFO - 2023-08-10 17:12:26 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:12:26 --> Helper loaded: form_helper
INFO - 2023-08-10 17:12:26 --> Form Validation Class Initialized
ERROR - 2023-08-10 17:12:26 --> Severity: Warning --> Undefined variable $service_id C:\xampp\htdocs\DW\application\views\admin\faq_create.php 59
INFO - 2023-08-10 17:12:26 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:12:26 --> Final output sent to browser
DEBUG - 2023-08-10 17:12:26 --> Total execution time: 0.0406
INFO - 2023-08-10 17:13:12 --> Config Class Initialized
INFO - 2023-08-10 17:13:12 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:13:12 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:13:12 --> Utf8 Class Initialized
INFO - 2023-08-10 17:13:12 --> URI Class Initialized
INFO - 2023-08-10 17:13:12 --> Router Class Initialized
INFO - 2023-08-10 17:13:12 --> Output Class Initialized
INFO - 2023-08-10 17:13:12 --> Security Class Initialized
DEBUG - 2023-08-10 17:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:13:12 --> Input Class Initialized
INFO - 2023-08-10 17:13:12 --> Language Class Initialized
INFO - 2023-08-10 17:13:12 --> Loader Class Initialized
INFO - 2023-08-10 17:13:12 --> Helper loaded: url_helper
INFO - 2023-08-10 17:13:12 --> Helper loaded: file_helper
INFO - 2023-08-10 17:13:12 --> Database Driver Class Initialized
INFO - 2023-08-10 17:13:12 --> Email Class Initialized
DEBUG - 2023-08-10 17:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:13:12 --> Controller Class Initialized
INFO - 2023-08-10 17:13:12 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:13:12 --> Helper loaded: form_helper
INFO - 2023-08-10 17:13:12 --> Form Validation Class Initialized
ERROR - 2023-08-10 17:13:12 --> Severity: Warning --> Undefined variable $service_id C:\xampp\htdocs\DW\application\views\admin\faq_create.php 59
INFO - 2023-08-10 17:13:12 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:13:12 --> Final output sent to browser
DEBUG - 2023-08-10 17:13:12 --> Total execution time: 1.1941
INFO - 2023-08-10 17:14:22 --> Config Class Initialized
INFO - 2023-08-10 17:14:22 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:14:22 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:14:22 --> Utf8 Class Initialized
INFO - 2023-08-10 17:14:22 --> URI Class Initialized
INFO - 2023-08-10 17:14:22 --> Router Class Initialized
INFO - 2023-08-10 17:14:22 --> Output Class Initialized
INFO - 2023-08-10 17:14:22 --> Security Class Initialized
DEBUG - 2023-08-10 17:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:14:22 --> Input Class Initialized
INFO - 2023-08-10 17:14:22 --> Language Class Initialized
INFO - 2023-08-10 17:14:22 --> Loader Class Initialized
INFO - 2023-08-10 17:14:22 --> Helper loaded: url_helper
INFO - 2023-08-10 17:14:22 --> Helper loaded: file_helper
INFO - 2023-08-10 17:14:22 --> Database Driver Class Initialized
INFO - 2023-08-10 17:14:22 --> Email Class Initialized
DEBUG - 2023-08-10 17:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:14:22 --> Controller Class Initialized
INFO - 2023-08-10 17:14:22 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:14:22 --> Helper loaded: form_helper
INFO - 2023-08-10 17:14:23 --> Form Validation Class Initialized
ERROR - 2023-08-10 17:14:23 --> Severity: Warning --> Undefined variable $service_id C:\xampp\htdocs\DW\application\views\admin\faq_create.php 59
INFO - 2023-08-10 17:14:23 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:14:23 --> Final output sent to browser
DEBUG - 2023-08-10 17:14:23 --> Total execution time: 0.1062
INFO - 2023-08-10 17:14:26 --> Config Class Initialized
INFO - 2023-08-10 17:14:26 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:14:26 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:14:26 --> Utf8 Class Initialized
INFO - 2023-08-10 17:14:26 --> URI Class Initialized
INFO - 2023-08-10 17:14:26 --> Router Class Initialized
INFO - 2023-08-10 17:14:26 --> Output Class Initialized
INFO - 2023-08-10 17:14:26 --> Security Class Initialized
DEBUG - 2023-08-10 17:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:14:26 --> Input Class Initialized
INFO - 2023-08-10 17:14:26 --> Language Class Initialized
INFO - 2023-08-10 17:14:26 --> Loader Class Initialized
INFO - 2023-08-10 17:14:26 --> Helper loaded: url_helper
INFO - 2023-08-10 17:14:26 --> Helper loaded: file_helper
INFO - 2023-08-10 17:14:26 --> Database Driver Class Initialized
INFO - 2023-08-10 17:14:26 --> Email Class Initialized
DEBUG - 2023-08-10 17:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:14:26 --> Controller Class Initialized
INFO - 2023-08-10 17:14:26 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:14:26 --> Helper loaded: form_helper
INFO - 2023-08-10 17:14:26 --> Form Validation Class Initialized
ERROR - 2023-08-10 17:14:26 --> Severity: Warning --> Undefined variable $service_id C:\xampp\htdocs\DW\application\views\admin\faq_create.php 59
INFO - 2023-08-10 17:14:26 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:14:26 --> Final output sent to browser
DEBUG - 2023-08-10 17:14:26 --> Total execution time: 0.0579
INFO - 2023-08-10 17:14:37 --> Config Class Initialized
INFO - 2023-08-10 17:14:37 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:14:37 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:14:37 --> Utf8 Class Initialized
INFO - 2023-08-10 17:14:37 --> URI Class Initialized
INFO - 2023-08-10 17:14:37 --> Router Class Initialized
INFO - 2023-08-10 17:14:37 --> Output Class Initialized
INFO - 2023-08-10 17:14:37 --> Security Class Initialized
DEBUG - 2023-08-10 17:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:14:37 --> Input Class Initialized
INFO - 2023-08-10 17:14:37 --> Language Class Initialized
INFO - 2023-08-10 17:14:37 --> Loader Class Initialized
INFO - 2023-08-10 17:14:37 --> Helper loaded: url_helper
INFO - 2023-08-10 17:14:37 --> Helper loaded: file_helper
INFO - 2023-08-10 17:14:37 --> Database Driver Class Initialized
INFO - 2023-08-10 17:14:37 --> Email Class Initialized
DEBUG - 2023-08-10 17:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:14:37 --> Controller Class Initialized
INFO - 2023-08-10 17:14:37 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:14:37 --> Helper loaded: form_helper
INFO - 2023-08-10 17:14:37 --> Form Validation Class Initialized
INFO - 2023-08-10 17:14:37 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:14:37 --> Final output sent to browser
DEBUG - 2023-08-10 17:14:37 --> Total execution time: 0.3167
INFO - 2023-08-10 17:14:42 --> Config Class Initialized
INFO - 2023-08-10 17:14:42 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:14:42 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:14:42 --> Utf8 Class Initialized
INFO - 2023-08-10 17:14:42 --> URI Class Initialized
INFO - 2023-08-10 17:14:42 --> Router Class Initialized
INFO - 2023-08-10 17:14:42 --> Output Class Initialized
INFO - 2023-08-10 17:14:42 --> Security Class Initialized
DEBUG - 2023-08-10 17:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:14:42 --> Input Class Initialized
INFO - 2023-08-10 17:14:42 --> Language Class Initialized
INFO - 2023-08-10 17:14:42 --> Loader Class Initialized
INFO - 2023-08-10 17:14:42 --> Helper loaded: url_helper
INFO - 2023-08-10 17:14:42 --> Helper loaded: file_helper
INFO - 2023-08-10 17:14:42 --> Database Driver Class Initialized
INFO - 2023-08-10 17:14:42 --> Email Class Initialized
DEBUG - 2023-08-10 17:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:14:42 --> Controller Class Initialized
INFO - 2023-08-10 17:14:42 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:14:42 --> Helper loaded: form_helper
INFO - 2023-08-10 17:14:42 --> Form Validation Class Initialized
INFO - 2023-08-10 17:14:42 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:14:42 --> Final output sent to browser
DEBUG - 2023-08-10 17:14:42 --> Total execution time: 0.0578
INFO - 2023-08-10 17:15:37 --> Config Class Initialized
INFO - 2023-08-10 17:15:37 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:15:37 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:15:37 --> Utf8 Class Initialized
INFO - 2023-08-10 17:15:37 --> URI Class Initialized
INFO - 2023-08-10 17:15:37 --> Router Class Initialized
INFO - 2023-08-10 17:15:37 --> Output Class Initialized
INFO - 2023-08-10 17:15:37 --> Security Class Initialized
DEBUG - 2023-08-10 17:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:15:37 --> Input Class Initialized
INFO - 2023-08-10 17:15:37 --> Language Class Initialized
INFO - 2023-08-10 17:15:38 --> Loader Class Initialized
INFO - 2023-08-10 17:15:38 --> Helper loaded: url_helper
INFO - 2023-08-10 17:15:38 --> Helper loaded: file_helper
INFO - 2023-08-10 17:15:38 --> Database Driver Class Initialized
INFO - 2023-08-10 17:15:38 --> Email Class Initialized
DEBUG - 2023-08-10 17:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:15:38 --> Controller Class Initialized
INFO - 2023-08-10 17:15:38 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:15:38 --> Helper loaded: form_helper
INFO - 2023-08-10 17:15:38 --> Form Validation Class Initialized
INFO - 2023-08-10 17:15:38 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:15:38 --> Final output sent to browser
DEBUG - 2023-08-10 17:15:38 --> Total execution time: 1.0836
INFO - 2023-08-10 17:16:00 --> Config Class Initialized
INFO - 2023-08-10 17:16:00 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:16:00 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:16:00 --> Utf8 Class Initialized
INFO - 2023-08-10 17:16:00 --> URI Class Initialized
INFO - 2023-08-10 17:16:00 --> Router Class Initialized
INFO - 2023-08-10 17:16:00 --> Output Class Initialized
INFO - 2023-08-10 17:16:00 --> Security Class Initialized
DEBUG - 2023-08-10 17:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:16:00 --> Input Class Initialized
INFO - 2023-08-10 17:16:00 --> Language Class Initialized
INFO - 2023-08-10 17:16:00 --> Loader Class Initialized
INFO - 2023-08-10 17:16:00 --> Helper loaded: url_helper
INFO - 2023-08-10 17:16:00 --> Helper loaded: file_helper
INFO - 2023-08-10 17:16:00 --> Database Driver Class Initialized
INFO - 2023-08-10 17:16:00 --> Email Class Initialized
DEBUG - 2023-08-10 17:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:16:00 --> Controller Class Initialized
INFO - 2023-08-10 17:16:00 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:16:00 --> Helper loaded: form_helper
INFO - 2023-08-10 17:16:00 --> Form Validation Class Initialized
INFO - 2023-08-10 17:16:00 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:16:00 --> Final output sent to browser
DEBUG - 2023-08-10 17:16:00 --> Total execution time: 0.1207
INFO - 2023-08-10 17:16:15 --> Config Class Initialized
INFO - 2023-08-10 17:16:15 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:16:15 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:16:15 --> Utf8 Class Initialized
INFO - 2023-08-10 17:16:15 --> URI Class Initialized
INFO - 2023-08-10 17:16:15 --> Router Class Initialized
INFO - 2023-08-10 17:16:15 --> Output Class Initialized
INFO - 2023-08-10 17:16:15 --> Security Class Initialized
DEBUG - 2023-08-10 17:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:16:15 --> Input Class Initialized
INFO - 2023-08-10 17:16:15 --> Language Class Initialized
INFO - 2023-08-10 17:16:15 --> Loader Class Initialized
INFO - 2023-08-10 17:16:15 --> Helper loaded: url_helper
INFO - 2023-08-10 17:16:15 --> Helper loaded: file_helper
INFO - 2023-08-10 17:16:15 --> Database Driver Class Initialized
INFO - 2023-08-10 17:16:15 --> Email Class Initialized
DEBUG - 2023-08-10 17:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:16:15 --> Controller Class Initialized
INFO - 2023-08-10 17:16:15 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:16:15 --> Helper loaded: form_helper
INFO - 2023-08-10 17:16:15 --> Form Validation Class Initialized
INFO - 2023-08-10 17:16:16 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:16:16 --> Final output sent to browser
DEBUG - 2023-08-10 17:16:16 --> Total execution time: 0.1107
INFO - 2023-08-10 17:18:40 --> Config Class Initialized
INFO - 2023-08-10 17:18:40 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:18:40 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:18:40 --> Utf8 Class Initialized
INFO - 2023-08-10 17:18:40 --> URI Class Initialized
INFO - 2023-08-10 17:18:40 --> Router Class Initialized
INFO - 2023-08-10 17:18:40 --> Output Class Initialized
INFO - 2023-08-10 17:18:40 --> Security Class Initialized
DEBUG - 2023-08-10 17:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:18:40 --> Input Class Initialized
INFO - 2023-08-10 17:18:40 --> Language Class Initialized
INFO - 2023-08-10 17:18:40 --> Loader Class Initialized
INFO - 2023-08-10 17:18:40 --> Helper loaded: url_helper
INFO - 2023-08-10 17:18:40 --> Helper loaded: file_helper
INFO - 2023-08-10 17:18:40 --> Database Driver Class Initialized
INFO - 2023-08-10 17:18:40 --> Email Class Initialized
DEBUG - 2023-08-10 17:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:18:40 --> Controller Class Initialized
INFO - 2023-08-10 17:18:40 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:18:40 --> Helper loaded: form_helper
INFO - 2023-08-10 17:18:40 --> Form Validation Class Initialized
INFO - 2023-08-10 17:18:40 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:18:40 --> Final output sent to browser
DEBUG - 2023-08-10 17:18:40 --> Total execution time: 0.1323
INFO - 2023-08-10 17:18:42 --> Config Class Initialized
INFO - 2023-08-10 17:18:42 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:18:42 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:18:42 --> Utf8 Class Initialized
INFO - 2023-08-10 17:18:42 --> URI Class Initialized
INFO - 2023-08-10 17:18:42 --> Router Class Initialized
INFO - 2023-08-10 17:18:42 --> Output Class Initialized
INFO - 2023-08-10 17:18:42 --> Security Class Initialized
DEBUG - 2023-08-10 17:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:18:42 --> Input Class Initialized
INFO - 2023-08-10 17:18:42 --> Language Class Initialized
INFO - 2023-08-10 17:18:42 --> Loader Class Initialized
INFO - 2023-08-10 17:18:42 --> Helper loaded: url_helper
INFO - 2023-08-10 17:18:42 --> Helper loaded: file_helper
INFO - 2023-08-10 17:18:42 --> Database Driver Class Initialized
INFO - 2023-08-10 17:18:42 --> Email Class Initialized
DEBUG - 2023-08-10 17:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:18:42 --> Controller Class Initialized
INFO - 2023-08-10 17:18:42 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:18:42 --> Helper loaded: form_helper
INFO - 2023-08-10 17:18:42 --> Form Validation Class Initialized
INFO - 2023-08-10 17:18:42 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:18:42 --> Final output sent to browser
DEBUG - 2023-08-10 17:18:42 --> Total execution time: 0.0593
INFO - 2023-08-10 17:18:48 --> Config Class Initialized
INFO - 2023-08-10 17:18:48 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:18:48 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:18:48 --> Utf8 Class Initialized
INFO - 2023-08-10 17:18:48 --> URI Class Initialized
INFO - 2023-08-10 17:18:48 --> Router Class Initialized
INFO - 2023-08-10 17:18:48 --> Output Class Initialized
INFO - 2023-08-10 17:18:48 --> Security Class Initialized
DEBUG - 2023-08-10 17:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:18:48 --> Input Class Initialized
INFO - 2023-08-10 17:18:48 --> Language Class Initialized
INFO - 2023-08-10 17:18:48 --> Loader Class Initialized
INFO - 2023-08-10 17:18:48 --> Helper loaded: url_helper
INFO - 2023-08-10 17:18:48 --> Helper loaded: file_helper
INFO - 2023-08-10 17:18:48 --> Database Driver Class Initialized
INFO - 2023-08-10 17:18:48 --> Email Class Initialized
DEBUG - 2023-08-10 17:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:18:48 --> Controller Class Initialized
INFO - 2023-08-10 17:18:48 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:18:48 --> Helper loaded: form_helper
INFO - 2023-08-10 17:18:48 --> Form Validation Class Initialized
INFO - 2023-08-10 17:18:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 17:18:48 --> Config Class Initialized
INFO - 2023-08-10 17:18:48 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:18:48 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:18:48 --> Utf8 Class Initialized
INFO - 2023-08-10 17:18:48 --> URI Class Initialized
INFO - 2023-08-10 17:18:48 --> Router Class Initialized
INFO - 2023-08-10 17:18:48 --> Output Class Initialized
INFO - 2023-08-10 17:18:48 --> Security Class Initialized
DEBUG - 2023-08-10 17:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:18:48 --> Input Class Initialized
INFO - 2023-08-10 17:18:48 --> Language Class Initialized
INFO - 2023-08-10 17:18:48 --> Loader Class Initialized
INFO - 2023-08-10 17:18:48 --> Helper loaded: url_helper
INFO - 2023-08-10 17:18:48 --> Helper loaded: file_helper
INFO - 2023-08-10 17:18:48 --> Database Driver Class Initialized
INFO - 2023-08-10 17:18:48 --> Email Class Initialized
DEBUG - 2023-08-10 17:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:18:48 --> Controller Class Initialized
INFO - 2023-08-10 17:18:48 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:18:48 --> Helper loaded: form_helper
INFO - 2023-08-10 17:18:48 --> Form Validation Class Initialized
INFO - 2023-08-10 17:18:48 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:18:48 --> Final output sent to browser
DEBUG - 2023-08-10 17:18:48 --> Total execution time: 0.0772
INFO - 2023-08-10 17:18:54 --> Config Class Initialized
INFO - 2023-08-10 17:18:54 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:18:54 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:18:54 --> Utf8 Class Initialized
INFO - 2023-08-10 17:18:54 --> URI Class Initialized
INFO - 2023-08-10 17:18:54 --> Router Class Initialized
INFO - 2023-08-10 17:18:54 --> Output Class Initialized
INFO - 2023-08-10 17:18:54 --> Security Class Initialized
DEBUG - 2023-08-10 17:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:18:54 --> Input Class Initialized
INFO - 2023-08-10 17:18:54 --> Language Class Initialized
INFO - 2023-08-10 17:18:54 --> Loader Class Initialized
INFO - 2023-08-10 17:18:54 --> Helper loaded: url_helper
INFO - 2023-08-10 17:18:54 --> Helper loaded: file_helper
INFO - 2023-08-10 17:18:54 --> Database Driver Class Initialized
INFO - 2023-08-10 17:18:54 --> Email Class Initialized
DEBUG - 2023-08-10 17:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:18:55 --> Controller Class Initialized
INFO - 2023-08-10 17:18:55 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:18:55 --> Helper loaded: form_helper
INFO - 2023-08-10 17:18:55 --> Form Validation Class Initialized
INFO - 2023-08-10 17:18:55 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:18:55 --> Final output sent to browser
DEBUG - 2023-08-10 17:18:55 --> Total execution time: 0.0488
INFO - 2023-08-10 17:19:03 --> Config Class Initialized
INFO - 2023-08-10 17:19:03 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:19:03 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:19:03 --> Utf8 Class Initialized
INFO - 2023-08-10 17:19:03 --> URI Class Initialized
INFO - 2023-08-10 17:19:03 --> Router Class Initialized
INFO - 2023-08-10 17:19:03 --> Output Class Initialized
INFO - 2023-08-10 17:19:03 --> Security Class Initialized
DEBUG - 2023-08-10 17:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:19:03 --> Input Class Initialized
INFO - 2023-08-10 17:19:03 --> Language Class Initialized
INFO - 2023-08-10 17:19:03 --> Loader Class Initialized
INFO - 2023-08-10 17:19:03 --> Helper loaded: url_helper
INFO - 2023-08-10 17:19:03 --> Helper loaded: file_helper
INFO - 2023-08-10 17:19:03 --> Database Driver Class Initialized
INFO - 2023-08-10 17:19:03 --> Email Class Initialized
DEBUG - 2023-08-10 17:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:19:03 --> Controller Class Initialized
INFO - 2023-08-10 17:19:03 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:19:03 --> Helper loaded: form_helper
INFO - 2023-08-10 17:19:03 --> Form Validation Class Initialized
INFO - 2023-08-10 17:19:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 17:19:03 --> Config Class Initialized
INFO - 2023-08-10 17:19:03 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:19:03 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:19:03 --> Utf8 Class Initialized
INFO - 2023-08-10 17:19:03 --> URI Class Initialized
INFO - 2023-08-10 17:19:03 --> Router Class Initialized
INFO - 2023-08-10 17:19:03 --> Output Class Initialized
INFO - 2023-08-10 17:19:03 --> Security Class Initialized
DEBUG - 2023-08-10 17:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:19:03 --> Input Class Initialized
INFO - 2023-08-10 17:19:03 --> Language Class Initialized
INFO - 2023-08-10 17:19:03 --> Loader Class Initialized
INFO - 2023-08-10 17:19:03 --> Helper loaded: url_helper
INFO - 2023-08-10 17:19:03 --> Helper loaded: file_helper
INFO - 2023-08-10 17:19:03 --> Database Driver Class Initialized
INFO - 2023-08-10 17:19:03 --> Email Class Initialized
DEBUG - 2023-08-10 17:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:19:03 --> Controller Class Initialized
INFO - 2023-08-10 17:19:03 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:19:03 --> Helper loaded: form_helper
INFO - 2023-08-10 17:19:03 --> Form Validation Class Initialized
INFO - 2023-08-10 17:19:03 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:19:03 --> Final output sent to browser
DEBUG - 2023-08-10 17:19:03 --> Total execution time: 0.0629
INFO - 2023-08-10 17:20:17 --> Config Class Initialized
INFO - 2023-08-10 17:20:17 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:20:17 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:20:17 --> Utf8 Class Initialized
INFO - 2023-08-10 17:20:17 --> URI Class Initialized
INFO - 2023-08-10 17:20:17 --> Router Class Initialized
INFO - 2023-08-10 17:20:17 --> Output Class Initialized
INFO - 2023-08-10 17:20:17 --> Security Class Initialized
DEBUG - 2023-08-10 17:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:20:17 --> Input Class Initialized
INFO - 2023-08-10 17:20:17 --> Language Class Initialized
INFO - 2023-08-10 17:20:17 --> Loader Class Initialized
INFO - 2023-08-10 17:20:17 --> Helper loaded: url_helper
INFO - 2023-08-10 17:20:17 --> Helper loaded: file_helper
INFO - 2023-08-10 17:20:17 --> Database Driver Class Initialized
INFO - 2023-08-10 17:20:17 --> Email Class Initialized
DEBUG - 2023-08-10 17:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:20:17 --> Controller Class Initialized
INFO - 2023-08-10 17:20:17 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:20:17 --> Helper loaded: form_helper
INFO - 2023-08-10 17:20:17 --> Form Validation Class Initialized
INFO - 2023-08-10 17:20:17 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:20:17 --> Final output sent to browser
DEBUG - 2023-08-10 17:20:17 --> Total execution time: 0.0506
INFO - 2023-08-10 17:20:20 --> Config Class Initialized
INFO - 2023-08-10 17:20:20 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:20:20 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:20:20 --> Utf8 Class Initialized
INFO - 2023-08-10 17:20:20 --> URI Class Initialized
INFO - 2023-08-10 17:20:20 --> Router Class Initialized
INFO - 2023-08-10 17:20:20 --> Output Class Initialized
INFO - 2023-08-10 17:20:20 --> Security Class Initialized
DEBUG - 2023-08-10 17:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:20:20 --> Input Class Initialized
INFO - 2023-08-10 17:20:20 --> Language Class Initialized
INFO - 2023-08-10 17:20:20 --> Loader Class Initialized
INFO - 2023-08-10 17:20:20 --> Helper loaded: url_helper
INFO - 2023-08-10 17:20:20 --> Helper loaded: file_helper
INFO - 2023-08-10 17:20:20 --> Database Driver Class Initialized
INFO - 2023-08-10 17:20:20 --> Email Class Initialized
DEBUG - 2023-08-10 17:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:20:20 --> Controller Class Initialized
INFO - 2023-08-10 17:20:20 --> Model "Services_model" initialized
INFO - 2023-08-10 17:20:20 --> Helper loaded: form_helper
INFO - 2023-08-10 17:20:20 --> Form Validation Class Initialized
INFO - 2023-08-10 17:20:20 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-10 17:20:20 --> Final output sent to browser
DEBUG - 2023-08-10 17:20:20 --> Total execution time: 0.1521
INFO - 2023-08-10 17:20:20 --> Config Class Initialized
INFO - 2023-08-10 17:20:20 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:20:20 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:20:20 --> Utf8 Class Initialized
INFO - 2023-08-10 17:20:20 --> URI Class Initialized
INFO - 2023-08-10 17:20:20 --> Router Class Initialized
INFO - 2023-08-10 17:20:20 --> Output Class Initialized
INFO - 2023-08-10 17:20:20 --> Security Class Initialized
DEBUG - 2023-08-10 17:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:20:20 --> Input Class Initialized
INFO - 2023-08-10 17:20:20 --> Language Class Initialized
ERROR - 2023-08-10 17:20:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-10 17:20:22 --> Config Class Initialized
INFO - 2023-08-10 17:20:22 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:20:22 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:20:22 --> Utf8 Class Initialized
INFO - 2023-08-10 17:20:22 --> URI Class Initialized
INFO - 2023-08-10 17:20:22 --> Router Class Initialized
INFO - 2023-08-10 17:20:22 --> Output Class Initialized
INFO - 2023-08-10 17:20:22 --> Security Class Initialized
DEBUG - 2023-08-10 17:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:20:22 --> Input Class Initialized
INFO - 2023-08-10 17:20:22 --> Language Class Initialized
INFO - 2023-08-10 17:20:22 --> Loader Class Initialized
INFO - 2023-08-10 17:20:22 --> Helper loaded: url_helper
INFO - 2023-08-10 17:20:22 --> Helper loaded: file_helper
INFO - 2023-08-10 17:20:22 --> Database Driver Class Initialized
INFO - 2023-08-10 17:20:22 --> Email Class Initialized
DEBUG - 2023-08-10 17:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:20:22 --> Controller Class Initialized
INFO - 2023-08-10 17:20:22 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:20:22 --> Helper loaded: form_helper
INFO - 2023-08-10 17:20:22 --> Form Validation Class Initialized
INFO - 2023-08-10 17:20:23 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:20:23 --> Final output sent to browser
DEBUG - 2023-08-10 17:20:23 --> Total execution time: 0.1471
INFO - 2023-08-10 17:22:54 --> Config Class Initialized
INFO - 2023-08-10 17:22:54 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:22:54 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:22:54 --> Utf8 Class Initialized
INFO - 2023-08-10 17:22:54 --> URI Class Initialized
INFO - 2023-08-10 17:22:54 --> Router Class Initialized
INFO - 2023-08-10 17:22:54 --> Output Class Initialized
INFO - 2023-08-10 17:22:54 --> Security Class Initialized
DEBUG - 2023-08-10 17:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:22:54 --> Input Class Initialized
INFO - 2023-08-10 17:22:54 --> Language Class Initialized
INFO - 2023-08-10 17:22:54 --> Loader Class Initialized
INFO - 2023-08-10 17:22:54 --> Helper loaded: url_helper
INFO - 2023-08-10 17:22:54 --> Helper loaded: file_helper
INFO - 2023-08-10 17:22:55 --> Database Driver Class Initialized
INFO - 2023-08-10 17:22:55 --> Email Class Initialized
DEBUG - 2023-08-10 17:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:22:55 --> Controller Class Initialized
INFO - 2023-08-10 17:22:55 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:22:55 --> Helper loaded: form_helper
INFO - 2023-08-10 17:22:55 --> Form Validation Class Initialized
INFO - 2023-08-10 17:22:55 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:22:55 --> Final output sent to browser
DEBUG - 2023-08-10 17:22:55 --> Total execution time: 0.4470
INFO - 2023-08-10 17:23:02 --> Config Class Initialized
INFO - 2023-08-10 17:23:02 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:23:02 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:23:02 --> Utf8 Class Initialized
INFO - 2023-08-10 17:23:02 --> URI Class Initialized
INFO - 2023-08-10 17:23:02 --> Router Class Initialized
INFO - 2023-08-10 17:23:02 --> Output Class Initialized
INFO - 2023-08-10 17:23:02 --> Security Class Initialized
DEBUG - 2023-08-10 17:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:23:02 --> Input Class Initialized
INFO - 2023-08-10 17:23:02 --> Language Class Initialized
INFO - 2023-08-10 17:23:02 --> Loader Class Initialized
INFO - 2023-08-10 17:23:02 --> Helper loaded: url_helper
INFO - 2023-08-10 17:23:02 --> Helper loaded: file_helper
INFO - 2023-08-10 17:23:02 --> Database Driver Class Initialized
INFO - 2023-08-10 17:23:02 --> Email Class Initialized
DEBUG - 2023-08-10 17:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:23:02 --> Controller Class Initialized
INFO - 2023-08-10 17:23:02 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:23:02 --> Helper loaded: form_helper
INFO - 2023-08-10 17:23:02 --> Form Validation Class Initialized
INFO - 2023-08-10 17:23:02 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:23:02 --> Final output sent to browser
DEBUG - 2023-08-10 17:23:02 --> Total execution time: 0.0789
INFO - 2023-08-10 17:23:12 --> Config Class Initialized
INFO - 2023-08-10 17:23:12 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:23:12 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:23:12 --> Utf8 Class Initialized
INFO - 2023-08-10 17:23:12 --> URI Class Initialized
INFO - 2023-08-10 17:23:12 --> Router Class Initialized
INFO - 2023-08-10 17:23:12 --> Output Class Initialized
INFO - 2023-08-10 17:23:12 --> Security Class Initialized
DEBUG - 2023-08-10 17:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:23:12 --> Input Class Initialized
INFO - 2023-08-10 17:23:12 --> Language Class Initialized
INFO - 2023-08-10 17:23:12 --> Loader Class Initialized
INFO - 2023-08-10 17:23:12 --> Helper loaded: url_helper
INFO - 2023-08-10 17:23:12 --> Helper loaded: file_helper
INFO - 2023-08-10 17:23:12 --> Database Driver Class Initialized
INFO - 2023-08-10 17:23:12 --> Email Class Initialized
DEBUG - 2023-08-10 17:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:23:12 --> Controller Class Initialized
INFO - 2023-08-10 17:23:12 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:23:12 --> Helper loaded: form_helper
INFO - 2023-08-10 17:23:12 --> Form Validation Class Initialized
INFO - 2023-08-10 17:23:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 17:23:12 --> Config Class Initialized
INFO - 2023-08-10 17:23:12 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:23:12 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:23:12 --> Utf8 Class Initialized
INFO - 2023-08-10 17:23:12 --> URI Class Initialized
INFO - 2023-08-10 17:23:12 --> Router Class Initialized
INFO - 2023-08-10 17:23:12 --> Output Class Initialized
INFO - 2023-08-10 17:23:12 --> Security Class Initialized
DEBUG - 2023-08-10 17:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:23:12 --> Input Class Initialized
INFO - 2023-08-10 17:23:12 --> Language Class Initialized
INFO - 2023-08-10 17:23:12 --> Loader Class Initialized
INFO - 2023-08-10 17:23:12 --> Helper loaded: url_helper
INFO - 2023-08-10 17:23:12 --> Helper loaded: file_helper
INFO - 2023-08-10 17:23:12 --> Database Driver Class Initialized
INFO - 2023-08-10 17:23:12 --> Email Class Initialized
DEBUG - 2023-08-10 17:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:23:12 --> Controller Class Initialized
INFO - 2023-08-10 17:23:12 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:23:12 --> Helper loaded: form_helper
INFO - 2023-08-10 17:23:12 --> Form Validation Class Initialized
INFO - 2023-08-10 17:23:12 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:23:12 --> Final output sent to browser
DEBUG - 2023-08-10 17:23:12 --> Total execution time: 0.0568
INFO - 2023-08-10 17:29:38 --> Config Class Initialized
INFO - 2023-08-10 17:29:38 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:29:38 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:29:38 --> Utf8 Class Initialized
INFO - 2023-08-10 17:29:38 --> URI Class Initialized
INFO - 2023-08-10 17:29:38 --> Router Class Initialized
INFO - 2023-08-10 17:29:38 --> Output Class Initialized
INFO - 2023-08-10 17:29:38 --> Security Class Initialized
DEBUG - 2023-08-10 17:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:29:38 --> Input Class Initialized
INFO - 2023-08-10 17:29:38 --> Language Class Initialized
INFO - 2023-08-10 17:29:38 --> Loader Class Initialized
INFO - 2023-08-10 17:29:38 --> Helper loaded: url_helper
INFO - 2023-08-10 17:29:38 --> Helper loaded: file_helper
INFO - 2023-08-10 17:29:38 --> Database Driver Class Initialized
INFO - 2023-08-10 17:29:38 --> Email Class Initialized
DEBUG - 2023-08-10 17:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:29:38 --> Controller Class Initialized
INFO - 2023-08-10 17:29:38 --> Model "Services_model" initialized
INFO - 2023-08-10 17:29:38 --> Helper loaded: form_helper
INFO - 2023-08-10 17:29:38 --> Form Validation Class Initialized
INFO - 2023-08-10 17:29:38 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-10 17:29:38 --> Final output sent to browser
DEBUG - 2023-08-10 17:29:38 --> Total execution time: 0.0452
INFO - 2023-08-10 17:29:38 --> Config Class Initialized
INFO - 2023-08-10 17:29:38 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:29:38 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:29:38 --> Utf8 Class Initialized
INFO - 2023-08-10 17:29:38 --> URI Class Initialized
INFO - 2023-08-10 17:29:38 --> Router Class Initialized
INFO - 2023-08-10 17:29:38 --> Output Class Initialized
INFO - 2023-08-10 17:29:38 --> Security Class Initialized
DEBUG - 2023-08-10 17:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:29:38 --> Input Class Initialized
INFO - 2023-08-10 17:29:38 --> Language Class Initialized
ERROR - 2023-08-10 17:29:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-10 17:29:41 --> Config Class Initialized
INFO - 2023-08-10 17:29:41 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:29:41 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:29:41 --> Utf8 Class Initialized
INFO - 2023-08-10 17:29:41 --> URI Class Initialized
INFO - 2023-08-10 17:29:41 --> Router Class Initialized
INFO - 2023-08-10 17:29:41 --> Output Class Initialized
INFO - 2023-08-10 17:29:41 --> Security Class Initialized
DEBUG - 2023-08-10 17:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:29:41 --> Input Class Initialized
INFO - 2023-08-10 17:29:41 --> Language Class Initialized
INFO - 2023-08-10 17:29:41 --> Loader Class Initialized
INFO - 2023-08-10 17:29:41 --> Helper loaded: url_helper
INFO - 2023-08-10 17:29:41 --> Helper loaded: file_helper
INFO - 2023-08-10 17:29:41 --> Database Driver Class Initialized
INFO - 2023-08-10 17:29:41 --> Email Class Initialized
DEBUG - 2023-08-10 17:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:29:41 --> Controller Class Initialized
INFO - 2023-08-10 17:29:41 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:29:41 --> Helper loaded: form_helper
INFO - 2023-08-10 17:29:41 --> Form Validation Class Initialized
INFO - 2023-08-10 17:29:41 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:29:41 --> Final output sent to browser
DEBUG - 2023-08-10 17:29:41 --> Total execution time: 0.1035
INFO - 2023-08-10 17:29:45 --> Config Class Initialized
INFO - 2023-08-10 17:29:45 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:29:45 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:29:45 --> Utf8 Class Initialized
INFO - 2023-08-10 17:29:45 --> URI Class Initialized
INFO - 2023-08-10 17:29:45 --> Router Class Initialized
INFO - 2023-08-10 17:29:45 --> Output Class Initialized
INFO - 2023-08-10 17:29:45 --> Security Class Initialized
DEBUG - 2023-08-10 17:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:29:45 --> Input Class Initialized
INFO - 2023-08-10 17:29:45 --> Language Class Initialized
INFO - 2023-08-10 17:29:45 --> Loader Class Initialized
INFO - 2023-08-10 17:29:45 --> Helper loaded: url_helper
INFO - 2023-08-10 17:29:45 --> Helper loaded: file_helper
INFO - 2023-08-10 17:29:45 --> Database Driver Class Initialized
INFO - 2023-08-10 17:29:45 --> Email Class Initialized
DEBUG - 2023-08-10 17:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:29:45 --> Controller Class Initialized
INFO - 2023-08-10 17:29:45 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:29:45 --> Helper loaded: form_helper
INFO - 2023-08-10 17:29:45 --> Form Validation Class Initialized
INFO - 2023-08-10 17:29:45 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:29:45 --> Final output sent to browser
DEBUG - 2023-08-10 17:29:45 --> Total execution time: 0.0496
INFO - 2023-08-10 17:29:53 --> Config Class Initialized
INFO - 2023-08-10 17:29:53 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:29:53 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:29:53 --> Utf8 Class Initialized
INFO - 2023-08-10 17:29:53 --> URI Class Initialized
INFO - 2023-08-10 17:29:53 --> Router Class Initialized
INFO - 2023-08-10 17:29:53 --> Output Class Initialized
INFO - 2023-08-10 17:29:53 --> Security Class Initialized
DEBUG - 2023-08-10 17:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:29:53 --> Input Class Initialized
INFO - 2023-08-10 17:29:53 --> Language Class Initialized
INFO - 2023-08-10 17:29:53 --> Loader Class Initialized
INFO - 2023-08-10 17:29:53 --> Helper loaded: url_helper
INFO - 2023-08-10 17:29:53 --> Helper loaded: file_helper
INFO - 2023-08-10 17:29:53 --> Database Driver Class Initialized
INFO - 2023-08-10 17:29:53 --> Email Class Initialized
DEBUG - 2023-08-10 17:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:29:53 --> Controller Class Initialized
INFO - 2023-08-10 17:29:53 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:29:53 --> Helper loaded: form_helper
INFO - 2023-08-10 17:29:53 --> Form Validation Class Initialized
INFO - 2023-08-10 17:29:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 17:29:53 --> Config Class Initialized
INFO - 2023-08-10 17:29:53 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:29:53 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:29:53 --> Utf8 Class Initialized
INFO - 2023-08-10 17:29:53 --> URI Class Initialized
INFO - 2023-08-10 17:29:53 --> Router Class Initialized
INFO - 2023-08-10 17:29:53 --> Output Class Initialized
INFO - 2023-08-10 17:29:53 --> Security Class Initialized
DEBUG - 2023-08-10 17:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:29:53 --> Input Class Initialized
INFO - 2023-08-10 17:29:53 --> Language Class Initialized
INFO - 2023-08-10 17:29:53 --> Loader Class Initialized
INFO - 2023-08-10 17:29:53 --> Helper loaded: url_helper
INFO - 2023-08-10 17:29:53 --> Helper loaded: file_helper
INFO - 2023-08-10 17:29:53 --> Database Driver Class Initialized
INFO - 2023-08-10 17:29:53 --> Email Class Initialized
DEBUG - 2023-08-10 17:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:29:53 --> Controller Class Initialized
INFO - 2023-08-10 17:29:53 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:29:53 --> Helper loaded: form_helper
INFO - 2023-08-10 17:29:53 --> Form Validation Class Initialized
INFO - 2023-08-10 17:29:53 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:29:53 --> Final output sent to browser
DEBUG - 2023-08-10 17:29:53 --> Total execution time: 0.0497
INFO - 2023-08-10 17:30:03 --> Config Class Initialized
INFO - 2023-08-10 17:30:03 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:30:03 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:30:03 --> Utf8 Class Initialized
INFO - 2023-08-10 17:30:03 --> URI Class Initialized
INFO - 2023-08-10 17:30:03 --> Router Class Initialized
INFO - 2023-08-10 17:30:03 --> Output Class Initialized
INFO - 2023-08-10 17:30:03 --> Security Class Initialized
DEBUG - 2023-08-10 17:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:30:03 --> Input Class Initialized
INFO - 2023-08-10 17:30:03 --> Language Class Initialized
INFO - 2023-08-10 17:30:03 --> Loader Class Initialized
INFO - 2023-08-10 17:30:03 --> Helper loaded: url_helper
INFO - 2023-08-10 17:30:03 --> Helper loaded: file_helper
INFO - 2023-08-10 17:30:03 --> Database Driver Class Initialized
INFO - 2023-08-10 17:30:03 --> Email Class Initialized
DEBUG - 2023-08-10 17:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:30:03 --> Controller Class Initialized
INFO - 2023-08-10 17:30:03 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:30:03 --> Helper loaded: form_helper
INFO - 2023-08-10 17:30:03 --> Form Validation Class Initialized
INFO - 2023-08-10 17:30:03 --> Config Class Initialized
INFO - 2023-08-10 17:30:03 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:30:03 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:30:03 --> Utf8 Class Initialized
INFO - 2023-08-10 17:30:03 --> URI Class Initialized
INFO - 2023-08-10 17:30:03 --> Router Class Initialized
INFO - 2023-08-10 17:30:03 --> Output Class Initialized
INFO - 2023-08-10 17:30:03 --> Security Class Initialized
DEBUG - 2023-08-10 17:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:30:03 --> Input Class Initialized
INFO - 2023-08-10 17:30:03 --> Language Class Initialized
INFO - 2023-08-10 17:30:03 --> Loader Class Initialized
INFO - 2023-08-10 17:30:03 --> Helper loaded: url_helper
INFO - 2023-08-10 17:30:03 --> Helper loaded: file_helper
INFO - 2023-08-10 17:30:03 --> Database Driver Class Initialized
INFO - 2023-08-10 17:30:03 --> Email Class Initialized
DEBUG - 2023-08-10 17:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:30:03 --> Controller Class Initialized
INFO - 2023-08-10 17:30:03 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:30:03 --> Helper loaded: form_helper
INFO - 2023-08-10 17:30:03 --> Form Validation Class Initialized
INFO - 2023-08-10 17:30:03 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:30:03 --> Final output sent to browser
DEBUG - 2023-08-10 17:30:03 --> Total execution time: 0.0467
INFO - 2023-08-10 17:30:12 --> Config Class Initialized
INFO - 2023-08-10 17:30:12 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:30:12 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:30:12 --> Utf8 Class Initialized
INFO - 2023-08-10 17:30:12 --> URI Class Initialized
INFO - 2023-08-10 17:30:12 --> Router Class Initialized
INFO - 2023-08-10 17:30:12 --> Output Class Initialized
INFO - 2023-08-10 17:30:12 --> Security Class Initialized
DEBUG - 2023-08-10 17:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:30:12 --> Input Class Initialized
INFO - 2023-08-10 17:30:12 --> Language Class Initialized
INFO - 2023-08-10 17:30:12 --> Loader Class Initialized
INFO - 2023-08-10 17:30:12 --> Helper loaded: url_helper
INFO - 2023-08-10 17:30:12 --> Helper loaded: file_helper
INFO - 2023-08-10 17:30:12 --> Database Driver Class Initialized
INFO - 2023-08-10 17:30:12 --> Email Class Initialized
DEBUG - 2023-08-10 17:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:30:12 --> Controller Class Initialized
INFO - 2023-08-10 17:30:12 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:30:12 --> Helper loaded: form_helper
INFO - 2023-08-10 17:30:12 --> Form Validation Class Initialized
INFO - 2023-08-10 17:30:12 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:30:12 --> Final output sent to browser
DEBUG - 2023-08-10 17:30:12 --> Total execution time: 0.1056
INFO - 2023-08-10 17:30:17 --> Config Class Initialized
INFO - 2023-08-10 17:30:17 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:30:17 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:30:17 --> Utf8 Class Initialized
INFO - 2023-08-10 17:30:17 --> URI Class Initialized
INFO - 2023-08-10 17:30:17 --> Router Class Initialized
INFO - 2023-08-10 17:30:17 --> Output Class Initialized
INFO - 2023-08-10 17:30:17 --> Security Class Initialized
DEBUG - 2023-08-10 17:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:30:17 --> Input Class Initialized
INFO - 2023-08-10 17:30:17 --> Language Class Initialized
INFO - 2023-08-10 17:30:17 --> Loader Class Initialized
INFO - 2023-08-10 17:30:17 --> Helper loaded: url_helper
INFO - 2023-08-10 17:30:17 --> Helper loaded: file_helper
INFO - 2023-08-10 17:30:17 --> Database Driver Class Initialized
INFO - 2023-08-10 17:30:17 --> Email Class Initialized
DEBUG - 2023-08-10 17:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:30:17 --> Controller Class Initialized
INFO - 2023-08-10 17:30:17 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:30:17 --> Helper loaded: form_helper
INFO - 2023-08-10 17:30:17 --> Form Validation Class Initialized
INFO - 2023-08-10 17:30:17 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:30:17 --> Final output sent to browser
DEBUG - 2023-08-10 17:30:17 --> Total execution time: 0.0606
INFO - 2023-08-10 17:30:23 --> Config Class Initialized
INFO - 2023-08-10 17:30:23 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:30:23 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:30:23 --> Utf8 Class Initialized
INFO - 2023-08-10 17:30:23 --> URI Class Initialized
INFO - 2023-08-10 17:30:23 --> Router Class Initialized
INFO - 2023-08-10 17:30:23 --> Output Class Initialized
INFO - 2023-08-10 17:30:23 --> Security Class Initialized
DEBUG - 2023-08-10 17:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:30:23 --> Input Class Initialized
INFO - 2023-08-10 17:30:23 --> Language Class Initialized
INFO - 2023-08-10 17:30:23 --> Loader Class Initialized
INFO - 2023-08-10 17:30:23 --> Helper loaded: url_helper
INFO - 2023-08-10 17:30:23 --> Helper loaded: file_helper
INFO - 2023-08-10 17:30:23 --> Database Driver Class Initialized
INFO - 2023-08-10 17:30:23 --> Email Class Initialized
DEBUG - 2023-08-10 17:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:30:23 --> Controller Class Initialized
INFO - 2023-08-10 17:30:23 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:30:23 --> Helper loaded: form_helper
INFO - 2023-08-10 17:30:23 --> Form Validation Class Initialized
INFO - 2023-08-10 17:30:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 17:30:23 --> Config Class Initialized
INFO - 2023-08-10 17:30:23 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:30:23 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:30:23 --> Utf8 Class Initialized
INFO - 2023-08-10 17:30:23 --> URI Class Initialized
INFO - 2023-08-10 17:30:23 --> Router Class Initialized
INFO - 2023-08-10 17:30:23 --> Output Class Initialized
INFO - 2023-08-10 17:30:23 --> Security Class Initialized
DEBUG - 2023-08-10 17:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:30:23 --> Input Class Initialized
INFO - 2023-08-10 17:30:23 --> Language Class Initialized
INFO - 2023-08-10 17:30:23 --> Loader Class Initialized
INFO - 2023-08-10 17:30:23 --> Helper loaded: url_helper
INFO - 2023-08-10 17:30:23 --> Helper loaded: file_helper
INFO - 2023-08-10 17:30:23 --> Database Driver Class Initialized
INFO - 2023-08-10 17:30:23 --> Email Class Initialized
DEBUG - 2023-08-10 17:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:30:23 --> Controller Class Initialized
INFO - 2023-08-10 17:30:23 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:30:23 --> Helper loaded: form_helper
INFO - 2023-08-10 17:30:23 --> Form Validation Class Initialized
INFO - 2023-08-10 17:30:23 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:30:23 --> Final output sent to browser
DEBUG - 2023-08-10 17:30:23 --> Total execution time: 0.0550
INFO - 2023-08-10 17:30:36 --> Config Class Initialized
INFO - 2023-08-10 17:30:36 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:30:36 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:30:36 --> Utf8 Class Initialized
INFO - 2023-08-10 17:30:36 --> URI Class Initialized
INFO - 2023-08-10 17:30:36 --> Router Class Initialized
INFO - 2023-08-10 17:30:36 --> Output Class Initialized
INFO - 2023-08-10 17:30:36 --> Security Class Initialized
DEBUG - 2023-08-10 17:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:30:36 --> Input Class Initialized
INFO - 2023-08-10 17:30:36 --> Language Class Initialized
INFO - 2023-08-10 17:30:36 --> Loader Class Initialized
INFO - 2023-08-10 17:30:36 --> Helper loaded: url_helper
INFO - 2023-08-10 17:30:36 --> Helper loaded: file_helper
INFO - 2023-08-10 17:30:36 --> Database Driver Class Initialized
INFO - 2023-08-10 17:30:36 --> Email Class Initialized
DEBUG - 2023-08-10 17:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:30:36 --> Controller Class Initialized
INFO - 2023-08-10 17:30:36 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:30:36 --> Helper loaded: form_helper
INFO - 2023-08-10 17:30:36 --> Form Validation Class Initialized
INFO - 2023-08-10 17:30:36 --> Config Class Initialized
INFO - 2023-08-10 17:30:36 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:30:36 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:30:36 --> Utf8 Class Initialized
INFO - 2023-08-10 17:30:36 --> URI Class Initialized
INFO - 2023-08-10 17:30:36 --> Router Class Initialized
INFO - 2023-08-10 17:30:36 --> Output Class Initialized
INFO - 2023-08-10 17:30:36 --> Security Class Initialized
DEBUG - 2023-08-10 17:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:30:36 --> Input Class Initialized
INFO - 2023-08-10 17:30:36 --> Language Class Initialized
INFO - 2023-08-10 17:30:36 --> Loader Class Initialized
INFO - 2023-08-10 17:30:36 --> Helper loaded: url_helper
INFO - 2023-08-10 17:30:36 --> Helper loaded: file_helper
INFO - 2023-08-10 17:30:36 --> Database Driver Class Initialized
INFO - 2023-08-10 17:30:36 --> Email Class Initialized
DEBUG - 2023-08-10 17:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:30:36 --> Controller Class Initialized
INFO - 2023-08-10 17:30:36 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:30:36 --> Helper loaded: form_helper
INFO - 2023-08-10 17:30:36 --> Form Validation Class Initialized
INFO - 2023-08-10 17:30:36 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:30:36 --> Final output sent to browser
DEBUG - 2023-08-10 17:30:36 --> Total execution time: 0.0487
INFO - 2023-08-10 17:31:01 --> Config Class Initialized
INFO - 2023-08-10 17:31:01 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:31:01 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:31:01 --> Utf8 Class Initialized
INFO - 2023-08-10 17:31:01 --> URI Class Initialized
INFO - 2023-08-10 17:31:01 --> Router Class Initialized
INFO - 2023-08-10 17:31:01 --> Output Class Initialized
INFO - 2023-08-10 17:31:01 --> Security Class Initialized
DEBUG - 2023-08-10 17:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:31:01 --> Input Class Initialized
INFO - 2023-08-10 17:31:01 --> Language Class Initialized
INFO - 2023-08-10 17:31:01 --> Loader Class Initialized
INFO - 2023-08-10 17:31:01 --> Helper loaded: url_helper
INFO - 2023-08-10 17:31:01 --> Helper loaded: file_helper
INFO - 2023-08-10 17:31:01 --> Database Driver Class Initialized
INFO - 2023-08-10 17:31:01 --> Email Class Initialized
DEBUG - 2023-08-10 17:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:31:01 --> Controller Class Initialized
INFO - 2023-08-10 17:31:01 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:31:01 --> Helper loaded: form_helper
INFO - 2023-08-10 17:31:01 --> Form Validation Class Initialized
INFO - 2023-08-10 17:31:01 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 17:31:01 --> Final output sent to browser
DEBUG - 2023-08-10 17:31:01 --> Total execution time: 0.2041
INFO - 2023-08-10 17:31:07 --> Config Class Initialized
INFO - 2023-08-10 17:31:07 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:31:07 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:31:07 --> Utf8 Class Initialized
INFO - 2023-08-10 17:31:07 --> URI Class Initialized
INFO - 2023-08-10 17:31:07 --> Router Class Initialized
INFO - 2023-08-10 17:31:07 --> Output Class Initialized
INFO - 2023-08-10 17:31:07 --> Security Class Initialized
DEBUG - 2023-08-10 17:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:31:07 --> Input Class Initialized
INFO - 2023-08-10 17:31:07 --> Language Class Initialized
INFO - 2023-08-10 17:31:07 --> Loader Class Initialized
INFO - 2023-08-10 17:31:07 --> Helper loaded: url_helper
INFO - 2023-08-10 17:31:07 --> Helper loaded: file_helper
INFO - 2023-08-10 17:31:07 --> Database Driver Class Initialized
INFO - 2023-08-10 17:31:07 --> Email Class Initialized
DEBUG - 2023-08-10 17:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:31:07 --> Controller Class Initialized
INFO - 2023-08-10 17:31:07 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:31:07 --> Helper loaded: form_helper
INFO - 2023-08-10 17:31:07 --> Form Validation Class Initialized
INFO - 2023-08-10 17:31:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 17:31:07 --> Config Class Initialized
INFO - 2023-08-10 17:31:07 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:31:07 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:31:07 --> Utf8 Class Initialized
INFO - 2023-08-10 17:31:07 --> URI Class Initialized
INFO - 2023-08-10 17:31:07 --> Router Class Initialized
INFO - 2023-08-10 17:31:07 --> Output Class Initialized
INFO - 2023-08-10 17:31:07 --> Security Class Initialized
DEBUG - 2023-08-10 17:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:31:07 --> Input Class Initialized
INFO - 2023-08-10 17:31:07 --> Language Class Initialized
INFO - 2023-08-10 17:31:07 --> Loader Class Initialized
INFO - 2023-08-10 17:31:07 --> Helper loaded: url_helper
INFO - 2023-08-10 17:31:07 --> Helper loaded: file_helper
INFO - 2023-08-10 17:31:07 --> Database Driver Class Initialized
INFO - 2023-08-10 17:31:07 --> Email Class Initialized
DEBUG - 2023-08-10 17:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:31:07 --> Controller Class Initialized
INFO - 2023-08-10 17:31:07 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:31:07 --> Helper loaded: form_helper
INFO - 2023-08-10 17:31:07 --> Form Validation Class Initialized
INFO - 2023-08-10 17:31:07 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:31:07 --> Final output sent to browser
DEBUG - 2023-08-10 17:31:07 --> Total execution time: 0.0600
INFO - 2023-08-10 17:31:15 --> Config Class Initialized
INFO - 2023-08-10 17:31:15 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:31:15 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:31:15 --> Utf8 Class Initialized
INFO - 2023-08-10 17:31:15 --> URI Class Initialized
INFO - 2023-08-10 17:31:15 --> Router Class Initialized
INFO - 2023-08-10 17:31:15 --> Output Class Initialized
INFO - 2023-08-10 17:31:15 --> Security Class Initialized
DEBUG - 2023-08-10 17:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:31:15 --> Input Class Initialized
INFO - 2023-08-10 17:31:15 --> Language Class Initialized
INFO - 2023-08-10 17:31:15 --> Loader Class Initialized
INFO - 2023-08-10 17:31:15 --> Helper loaded: url_helper
INFO - 2023-08-10 17:31:15 --> Helper loaded: file_helper
INFO - 2023-08-10 17:31:15 --> Database Driver Class Initialized
INFO - 2023-08-10 17:31:15 --> Email Class Initialized
DEBUG - 2023-08-10 17:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:31:15 --> Controller Class Initialized
INFO - 2023-08-10 17:31:15 --> Model "Services_model" initialized
INFO - 2023-08-10 17:31:15 --> Helper loaded: form_helper
INFO - 2023-08-10 17:31:15 --> Form Validation Class Initialized
INFO - 2023-08-10 17:31:15 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-10 17:31:15 --> Final output sent to browser
DEBUG - 2023-08-10 17:31:15 --> Total execution time: 0.0851
INFO - 2023-08-10 17:31:15 --> Config Class Initialized
INFO - 2023-08-10 17:31:15 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:31:15 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:31:15 --> Utf8 Class Initialized
INFO - 2023-08-10 17:31:15 --> URI Class Initialized
INFO - 2023-08-10 17:31:15 --> Router Class Initialized
INFO - 2023-08-10 17:31:15 --> Output Class Initialized
INFO - 2023-08-10 17:31:15 --> Security Class Initialized
DEBUG - 2023-08-10 17:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:31:15 --> Input Class Initialized
INFO - 2023-08-10 17:31:15 --> Language Class Initialized
ERROR - 2023-08-10 17:31:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-10 17:31:18 --> Config Class Initialized
INFO - 2023-08-10 17:31:18 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:31:18 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:31:18 --> Utf8 Class Initialized
INFO - 2023-08-10 17:31:18 --> URI Class Initialized
INFO - 2023-08-10 17:31:18 --> Router Class Initialized
INFO - 2023-08-10 17:31:18 --> Output Class Initialized
INFO - 2023-08-10 17:31:18 --> Security Class Initialized
DEBUG - 2023-08-10 17:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:31:18 --> Input Class Initialized
INFO - 2023-08-10 17:31:18 --> Language Class Initialized
INFO - 2023-08-10 17:31:18 --> Loader Class Initialized
INFO - 2023-08-10 17:31:18 --> Helper loaded: url_helper
INFO - 2023-08-10 17:31:18 --> Helper loaded: file_helper
INFO - 2023-08-10 17:31:18 --> Database Driver Class Initialized
INFO - 2023-08-10 17:31:18 --> Email Class Initialized
DEBUG - 2023-08-10 17:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:31:18 --> Controller Class Initialized
INFO - 2023-08-10 17:31:18 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:31:18 --> Helper loaded: form_helper
INFO - 2023-08-10 17:31:18 --> Form Validation Class Initialized
INFO - 2023-08-10 17:31:18 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:31:18 --> Final output sent to browser
DEBUG - 2023-08-10 17:31:18 --> Total execution time: 0.0454
INFO - 2023-08-10 17:31:50 --> Config Class Initialized
INFO - 2023-08-10 17:31:50 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:31:50 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:31:50 --> Utf8 Class Initialized
INFO - 2023-08-10 17:31:50 --> URI Class Initialized
INFO - 2023-08-10 17:31:50 --> Router Class Initialized
INFO - 2023-08-10 17:31:50 --> Output Class Initialized
INFO - 2023-08-10 17:31:50 --> Security Class Initialized
DEBUG - 2023-08-10 17:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:31:50 --> Input Class Initialized
INFO - 2023-08-10 17:31:50 --> Language Class Initialized
INFO - 2023-08-10 17:31:50 --> Loader Class Initialized
INFO - 2023-08-10 17:31:50 --> Helper loaded: url_helper
INFO - 2023-08-10 17:31:50 --> Helper loaded: file_helper
INFO - 2023-08-10 17:31:50 --> Database Driver Class Initialized
INFO - 2023-08-10 17:31:50 --> Email Class Initialized
DEBUG - 2023-08-10 17:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:31:50 --> Controller Class Initialized
INFO - 2023-08-10 17:31:50 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:31:50 --> Helper loaded: form_helper
INFO - 2023-08-10 17:31:50 --> Form Validation Class Initialized
INFO - 2023-08-10 17:31:50 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 17:31:50 --> Final output sent to browser
DEBUG - 2023-08-10 17:31:50 --> Total execution time: 0.1021
INFO - 2023-08-10 17:31:51 --> Config Class Initialized
INFO - 2023-08-10 17:31:51 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:31:51 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:31:51 --> Utf8 Class Initialized
INFO - 2023-08-10 17:31:51 --> URI Class Initialized
INFO - 2023-08-10 17:31:51 --> Router Class Initialized
INFO - 2023-08-10 17:31:51 --> Output Class Initialized
INFO - 2023-08-10 17:31:51 --> Security Class Initialized
DEBUG - 2023-08-10 17:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:31:51 --> Input Class Initialized
INFO - 2023-08-10 17:31:51 --> Language Class Initialized
INFO - 2023-08-10 17:31:51 --> Loader Class Initialized
INFO - 2023-08-10 17:31:51 --> Helper loaded: url_helper
INFO - 2023-08-10 17:31:51 --> Helper loaded: file_helper
INFO - 2023-08-10 17:31:51 --> Database Driver Class Initialized
INFO - 2023-08-10 17:31:51 --> Email Class Initialized
DEBUG - 2023-08-10 17:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:31:51 --> Controller Class Initialized
INFO - 2023-08-10 17:31:51 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:31:51 --> Helper loaded: form_helper
INFO - 2023-08-10 17:31:51 --> Form Validation Class Initialized
ERROR - 2023-08-10 17:31:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-10 17:31:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-10 17:31:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-10 17:31:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-10 17:31:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-10 17:31:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-10 17:31:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-10 17:31:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-10 17:31:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-10 17:31:51 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 17:31:51 --> Final output sent to browser
DEBUG - 2023-08-10 17:31:51 --> Total execution time: 0.0480
INFO - 2023-08-10 17:35:56 --> Config Class Initialized
INFO - 2023-08-10 17:35:56 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:35:56 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:35:56 --> Utf8 Class Initialized
INFO - 2023-08-10 17:35:56 --> URI Class Initialized
INFO - 2023-08-10 17:35:56 --> Router Class Initialized
INFO - 2023-08-10 17:35:56 --> Output Class Initialized
INFO - 2023-08-10 17:35:56 --> Security Class Initialized
DEBUG - 2023-08-10 17:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:35:56 --> Input Class Initialized
INFO - 2023-08-10 17:35:56 --> Language Class Initialized
INFO - 2023-08-10 17:35:56 --> Loader Class Initialized
INFO - 2023-08-10 17:35:56 --> Helper loaded: url_helper
INFO - 2023-08-10 17:35:56 --> Helper loaded: file_helper
INFO - 2023-08-10 17:35:56 --> Database Driver Class Initialized
INFO - 2023-08-10 17:35:56 --> Email Class Initialized
DEBUG - 2023-08-10 17:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:35:56 --> Controller Class Initialized
INFO - 2023-08-10 17:35:56 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:35:56 --> Helper loaded: form_helper
INFO - 2023-08-10 17:35:56 --> Form Validation Class Initialized
INFO - 2023-08-10 17:35:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:35:56 --> Final output sent to browser
DEBUG - 2023-08-10 17:35:56 --> Total execution time: 0.0756
INFO - 2023-08-10 17:35:59 --> Config Class Initialized
INFO - 2023-08-10 17:35:59 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:35:59 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:35:59 --> Utf8 Class Initialized
INFO - 2023-08-10 17:35:59 --> URI Class Initialized
INFO - 2023-08-10 17:35:59 --> Router Class Initialized
INFO - 2023-08-10 17:35:59 --> Output Class Initialized
INFO - 2023-08-10 17:35:59 --> Security Class Initialized
DEBUG - 2023-08-10 17:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:35:59 --> Input Class Initialized
INFO - 2023-08-10 17:35:59 --> Language Class Initialized
INFO - 2023-08-10 17:35:59 --> Loader Class Initialized
INFO - 2023-08-10 17:35:59 --> Helper loaded: url_helper
INFO - 2023-08-10 17:35:59 --> Helper loaded: file_helper
INFO - 2023-08-10 17:35:59 --> Database Driver Class Initialized
INFO - 2023-08-10 17:35:59 --> Email Class Initialized
DEBUG - 2023-08-10 17:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:35:59 --> Controller Class Initialized
INFO - 2023-08-10 17:35:59 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:35:59 --> Helper loaded: form_helper
INFO - 2023-08-10 17:35:59 --> Form Validation Class Initialized
INFO - 2023-08-10 17:35:59 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:35:59 --> Final output sent to browser
DEBUG - 2023-08-10 17:35:59 --> Total execution time: 0.0510
INFO - 2023-08-10 17:53:13 --> Config Class Initialized
INFO - 2023-08-10 17:53:13 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:53:13 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:53:13 --> Utf8 Class Initialized
INFO - 2023-08-10 17:53:13 --> URI Class Initialized
INFO - 2023-08-10 17:53:13 --> Router Class Initialized
INFO - 2023-08-10 17:53:13 --> Output Class Initialized
INFO - 2023-08-10 17:53:13 --> Security Class Initialized
DEBUG - 2023-08-10 17:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:53:13 --> Input Class Initialized
INFO - 2023-08-10 17:53:13 --> Language Class Initialized
INFO - 2023-08-10 17:53:13 --> Loader Class Initialized
INFO - 2023-08-10 17:53:13 --> Helper loaded: url_helper
INFO - 2023-08-10 17:53:13 --> Helper loaded: file_helper
INFO - 2023-08-10 17:53:13 --> Database Driver Class Initialized
INFO - 2023-08-10 17:53:13 --> Email Class Initialized
DEBUG - 2023-08-10 17:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:53:13 --> Controller Class Initialized
INFO - 2023-08-10 17:53:13 --> Model "Services_model" initialized
INFO - 2023-08-10 17:53:13 --> Helper loaded: form_helper
INFO - 2023-08-10 17:53:13 --> Form Validation Class Initialized
INFO - 2023-08-10 17:53:13 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-10 17:53:13 --> Final output sent to browser
DEBUG - 2023-08-10 17:53:13 --> Total execution time: 0.0448
INFO - 2023-08-10 17:53:13 --> Config Class Initialized
INFO - 2023-08-10 17:53:13 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:53:13 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:53:13 --> Utf8 Class Initialized
INFO - 2023-08-10 17:53:13 --> URI Class Initialized
INFO - 2023-08-10 17:53:13 --> Router Class Initialized
INFO - 2023-08-10 17:53:13 --> Output Class Initialized
INFO - 2023-08-10 17:53:13 --> Security Class Initialized
DEBUG - 2023-08-10 17:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:53:13 --> Input Class Initialized
INFO - 2023-08-10 17:53:13 --> Language Class Initialized
ERROR - 2023-08-10 17:53:13 --> 404 Page Not Found: Assets/images
INFO - 2023-08-10 17:53:15 --> Config Class Initialized
INFO - 2023-08-10 17:53:15 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:53:15 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:53:15 --> Utf8 Class Initialized
INFO - 2023-08-10 17:53:15 --> URI Class Initialized
INFO - 2023-08-10 17:53:15 --> Router Class Initialized
INFO - 2023-08-10 17:53:15 --> Output Class Initialized
INFO - 2023-08-10 17:53:15 --> Security Class Initialized
DEBUG - 2023-08-10 17:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:53:15 --> Input Class Initialized
INFO - 2023-08-10 17:53:15 --> Language Class Initialized
INFO - 2023-08-10 17:53:15 --> Loader Class Initialized
INFO - 2023-08-10 17:53:15 --> Helper loaded: url_helper
INFO - 2023-08-10 17:53:15 --> Helper loaded: file_helper
INFO - 2023-08-10 17:53:15 --> Database Driver Class Initialized
INFO - 2023-08-10 17:53:15 --> Email Class Initialized
DEBUG - 2023-08-10 17:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:53:15 --> Controller Class Initialized
INFO - 2023-08-10 17:53:15 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:53:15 --> Helper loaded: form_helper
INFO - 2023-08-10 17:53:15 --> Form Validation Class Initialized
INFO - 2023-08-10 17:53:15 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:53:15 --> Final output sent to browser
DEBUG - 2023-08-10 17:53:15 --> Total execution time: 0.0509
INFO - 2023-08-10 17:56:02 --> Config Class Initialized
INFO - 2023-08-10 17:56:02 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:56:02 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:56:02 --> Utf8 Class Initialized
INFO - 2023-08-10 17:56:02 --> URI Class Initialized
INFO - 2023-08-10 17:56:02 --> Router Class Initialized
INFO - 2023-08-10 17:56:02 --> Output Class Initialized
INFO - 2023-08-10 17:56:02 --> Security Class Initialized
DEBUG - 2023-08-10 17:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:56:02 --> Input Class Initialized
INFO - 2023-08-10 17:56:02 --> Language Class Initialized
INFO - 2023-08-10 17:56:02 --> Loader Class Initialized
INFO - 2023-08-10 17:56:02 --> Helper loaded: url_helper
INFO - 2023-08-10 17:56:02 --> Helper loaded: file_helper
INFO - 2023-08-10 17:56:02 --> Database Driver Class Initialized
INFO - 2023-08-10 17:56:02 --> Email Class Initialized
DEBUG - 2023-08-10 17:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:56:02 --> Controller Class Initialized
INFO - 2023-08-10 17:56:02 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:56:02 --> Helper loaded: form_helper
INFO - 2023-08-10 17:56:02 --> Form Validation Class Initialized
INFO - 2023-08-10 17:56:02 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:56:03 --> Final output sent to browser
DEBUG - 2023-08-10 17:56:03 --> Total execution time: 0.1481
INFO - 2023-08-10 17:56:56 --> Config Class Initialized
INFO - 2023-08-10 17:56:56 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:56:56 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:56:56 --> Utf8 Class Initialized
INFO - 2023-08-10 17:56:56 --> URI Class Initialized
INFO - 2023-08-10 17:56:56 --> Router Class Initialized
INFO - 2023-08-10 17:56:56 --> Output Class Initialized
INFO - 2023-08-10 17:56:56 --> Security Class Initialized
DEBUG - 2023-08-10 17:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:56:56 --> Input Class Initialized
INFO - 2023-08-10 17:56:56 --> Language Class Initialized
INFO - 2023-08-10 17:56:56 --> Loader Class Initialized
INFO - 2023-08-10 17:56:56 --> Helper loaded: url_helper
INFO - 2023-08-10 17:56:56 --> Helper loaded: file_helper
INFO - 2023-08-10 17:56:56 --> Database Driver Class Initialized
INFO - 2023-08-10 17:56:56 --> Email Class Initialized
DEBUG - 2023-08-10 17:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:56:56 --> Controller Class Initialized
INFO - 2023-08-10 17:56:56 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:56:56 --> Helper loaded: form_helper
INFO - 2023-08-10 17:56:56 --> Form Validation Class Initialized
INFO - 2023-08-10 17:56:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:56:56 --> Final output sent to browser
DEBUG - 2023-08-10 17:56:56 --> Total execution time: 0.1302
INFO - 2023-08-10 17:59:42 --> Config Class Initialized
INFO - 2023-08-10 17:59:42 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:59:42 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:59:42 --> Utf8 Class Initialized
INFO - 2023-08-10 17:59:42 --> URI Class Initialized
INFO - 2023-08-10 17:59:42 --> Router Class Initialized
INFO - 2023-08-10 17:59:42 --> Output Class Initialized
INFO - 2023-08-10 17:59:42 --> Security Class Initialized
DEBUG - 2023-08-10 17:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:59:42 --> Input Class Initialized
INFO - 2023-08-10 17:59:42 --> Language Class Initialized
INFO - 2023-08-10 17:59:42 --> Loader Class Initialized
INFO - 2023-08-10 17:59:42 --> Helper loaded: url_helper
INFO - 2023-08-10 17:59:42 --> Helper loaded: file_helper
INFO - 2023-08-10 17:59:42 --> Database Driver Class Initialized
INFO - 2023-08-10 17:59:42 --> Email Class Initialized
DEBUG - 2023-08-10 17:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:59:42 --> Controller Class Initialized
INFO - 2023-08-10 17:59:42 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:59:42 --> Helper loaded: form_helper
INFO - 2023-08-10 17:59:42 --> Form Validation Class Initialized
INFO - 2023-08-10 17:59:42 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 17:59:42 --> Final output sent to browser
DEBUG - 2023-08-10 17:59:42 --> Total execution time: 0.3573
INFO - 2023-08-10 17:59:43 --> Config Class Initialized
INFO - 2023-08-10 17:59:43 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:59:43 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:59:43 --> Utf8 Class Initialized
INFO - 2023-08-10 17:59:43 --> URI Class Initialized
INFO - 2023-08-10 17:59:43 --> Router Class Initialized
INFO - 2023-08-10 17:59:43 --> Output Class Initialized
INFO - 2023-08-10 17:59:43 --> Security Class Initialized
DEBUG - 2023-08-10 17:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:59:43 --> Input Class Initialized
INFO - 2023-08-10 17:59:43 --> Language Class Initialized
INFO - 2023-08-10 17:59:43 --> Loader Class Initialized
INFO - 2023-08-10 17:59:43 --> Helper loaded: url_helper
INFO - 2023-08-10 17:59:43 --> Helper loaded: file_helper
INFO - 2023-08-10 17:59:43 --> Database Driver Class Initialized
INFO - 2023-08-10 17:59:43 --> Email Class Initialized
DEBUG - 2023-08-10 17:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:59:43 --> Controller Class Initialized
INFO - 2023-08-10 17:59:43 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:59:43 --> Helper loaded: form_helper
INFO - 2023-08-10 17:59:43 --> Form Validation Class Initialized
ERROR - 2023-08-10 17:59:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-10 17:59:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-10 17:59:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-10 17:59:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-10 17:59:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-10 17:59:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-10 17:59:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-10 17:59:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-10 17:59:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-10 17:59:43 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 17:59:43 --> Final output sent to browser
DEBUG - 2023-08-10 17:59:43 --> Total execution time: 0.0517
INFO - 2023-08-10 17:59:45 --> Config Class Initialized
INFO - 2023-08-10 17:59:45 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:59:45 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:59:45 --> Utf8 Class Initialized
INFO - 2023-08-10 17:59:45 --> URI Class Initialized
INFO - 2023-08-10 17:59:45 --> Router Class Initialized
INFO - 2023-08-10 17:59:45 --> Output Class Initialized
INFO - 2023-08-10 17:59:45 --> Security Class Initialized
DEBUG - 2023-08-10 17:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:59:45 --> Input Class Initialized
INFO - 2023-08-10 17:59:45 --> Language Class Initialized
INFO - 2023-08-10 17:59:45 --> Loader Class Initialized
INFO - 2023-08-10 17:59:45 --> Helper loaded: url_helper
INFO - 2023-08-10 17:59:45 --> Helper loaded: file_helper
INFO - 2023-08-10 17:59:45 --> Database Driver Class Initialized
INFO - 2023-08-10 17:59:45 --> Email Class Initialized
DEBUG - 2023-08-10 17:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:59:45 --> Controller Class Initialized
INFO - 2023-08-10 17:59:45 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:59:45 --> Helper loaded: form_helper
INFO - 2023-08-10 17:59:45 --> Form Validation Class Initialized
INFO - 2023-08-10 17:59:45 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:59:45 --> Final output sent to browser
DEBUG - 2023-08-10 17:59:45 --> Total execution time: 0.0496
INFO - 2023-08-10 17:59:48 --> Config Class Initialized
INFO - 2023-08-10 17:59:48 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:59:48 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:59:48 --> Utf8 Class Initialized
INFO - 2023-08-10 17:59:48 --> URI Class Initialized
INFO - 2023-08-10 17:59:48 --> Router Class Initialized
INFO - 2023-08-10 17:59:48 --> Output Class Initialized
INFO - 2023-08-10 17:59:48 --> Security Class Initialized
DEBUG - 2023-08-10 17:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:59:48 --> Input Class Initialized
INFO - 2023-08-10 17:59:48 --> Language Class Initialized
INFO - 2023-08-10 17:59:48 --> Loader Class Initialized
INFO - 2023-08-10 17:59:48 --> Helper loaded: url_helper
INFO - 2023-08-10 17:59:48 --> Helper loaded: file_helper
INFO - 2023-08-10 17:59:48 --> Database Driver Class Initialized
INFO - 2023-08-10 17:59:48 --> Email Class Initialized
DEBUG - 2023-08-10 17:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:59:48 --> Controller Class Initialized
INFO - 2023-08-10 17:59:48 --> Model "Services_model" initialized
INFO - 2023-08-10 17:59:48 --> Helper loaded: form_helper
INFO - 2023-08-10 17:59:48 --> Form Validation Class Initialized
INFO - 2023-08-10 17:59:48 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-10 17:59:48 --> Final output sent to browser
DEBUG - 2023-08-10 17:59:48 --> Total execution time: 0.0572
INFO - 2023-08-10 17:59:48 --> Config Class Initialized
INFO - 2023-08-10 17:59:48 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:59:48 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:59:48 --> Utf8 Class Initialized
INFO - 2023-08-10 17:59:48 --> URI Class Initialized
INFO - 2023-08-10 17:59:48 --> Router Class Initialized
INFO - 2023-08-10 17:59:48 --> Output Class Initialized
INFO - 2023-08-10 17:59:48 --> Security Class Initialized
DEBUG - 2023-08-10 17:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:59:48 --> Input Class Initialized
INFO - 2023-08-10 17:59:48 --> Language Class Initialized
ERROR - 2023-08-10 17:59:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-10 17:59:50 --> Config Class Initialized
INFO - 2023-08-10 17:59:50 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:59:50 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:59:50 --> Utf8 Class Initialized
INFO - 2023-08-10 17:59:50 --> URI Class Initialized
INFO - 2023-08-10 17:59:50 --> Router Class Initialized
INFO - 2023-08-10 17:59:50 --> Output Class Initialized
INFO - 2023-08-10 17:59:50 --> Security Class Initialized
DEBUG - 2023-08-10 17:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:59:50 --> Input Class Initialized
INFO - 2023-08-10 17:59:50 --> Language Class Initialized
INFO - 2023-08-10 17:59:50 --> Loader Class Initialized
INFO - 2023-08-10 17:59:50 --> Helper loaded: url_helper
INFO - 2023-08-10 17:59:50 --> Helper loaded: file_helper
INFO - 2023-08-10 17:59:50 --> Database Driver Class Initialized
INFO - 2023-08-10 17:59:50 --> Email Class Initialized
DEBUG - 2023-08-10 17:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:59:50 --> Controller Class Initialized
INFO - 2023-08-10 17:59:50 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:59:50 --> Helper loaded: form_helper
INFO - 2023-08-10 17:59:50 --> Form Validation Class Initialized
INFO - 2023-08-10 17:59:50 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 17:59:50 --> Final output sent to browser
DEBUG - 2023-08-10 17:59:50 --> Total execution time: 0.0518
INFO - 2023-08-10 17:59:53 --> Config Class Initialized
INFO - 2023-08-10 17:59:53 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:59:53 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:59:53 --> Utf8 Class Initialized
INFO - 2023-08-10 17:59:53 --> URI Class Initialized
INFO - 2023-08-10 17:59:53 --> Router Class Initialized
INFO - 2023-08-10 17:59:53 --> Output Class Initialized
INFO - 2023-08-10 17:59:53 --> Security Class Initialized
DEBUG - 2023-08-10 17:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:59:53 --> Input Class Initialized
INFO - 2023-08-10 17:59:53 --> Language Class Initialized
INFO - 2023-08-10 17:59:53 --> Loader Class Initialized
INFO - 2023-08-10 17:59:53 --> Helper loaded: url_helper
INFO - 2023-08-10 17:59:53 --> Helper loaded: file_helper
INFO - 2023-08-10 17:59:53 --> Database Driver Class Initialized
INFO - 2023-08-10 17:59:53 --> Email Class Initialized
DEBUG - 2023-08-10 17:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:59:53 --> Controller Class Initialized
INFO - 2023-08-10 17:59:53 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:59:53 --> Helper loaded: form_helper
INFO - 2023-08-10 17:59:53 --> Form Validation Class Initialized
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-10 17:59:53 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 17:59:53 --> Final output sent to browser
DEBUG - 2023-08-10 17:59:53 --> Total execution time: 0.0557
INFO - 2023-08-10 17:59:53 --> Config Class Initialized
INFO - 2023-08-10 17:59:53 --> Hooks Class Initialized
DEBUG - 2023-08-10 17:59:53 --> UTF-8 Support Enabled
INFO - 2023-08-10 17:59:53 --> Utf8 Class Initialized
INFO - 2023-08-10 17:59:53 --> URI Class Initialized
INFO - 2023-08-10 17:59:53 --> Router Class Initialized
INFO - 2023-08-10 17:59:53 --> Output Class Initialized
INFO - 2023-08-10 17:59:53 --> Security Class Initialized
DEBUG - 2023-08-10 17:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 17:59:53 --> Input Class Initialized
INFO - 2023-08-10 17:59:53 --> Language Class Initialized
INFO - 2023-08-10 17:59:53 --> Loader Class Initialized
INFO - 2023-08-10 17:59:53 --> Helper loaded: url_helper
INFO - 2023-08-10 17:59:53 --> Helper loaded: file_helper
INFO - 2023-08-10 17:59:53 --> Database Driver Class Initialized
INFO - 2023-08-10 17:59:53 --> Email Class Initialized
DEBUG - 2023-08-10 17:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 17:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 17:59:53 --> Controller Class Initialized
INFO - 2023-08-10 17:59:53 --> Model "Faq_model" initialized
INFO - 2023-08-10 17:59:53 --> Helper loaded: form_helper
INFO - 2023-08-10 17:59:53 --> Form Validation Class Initialized
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-10 17:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-10 17:59:53 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 17:59:53 --> Final output sent to browser
DEBUG - 2023-08-10 17:59:53 --> Total execution time: 0.0647
INFO - 2023-08-10 18:00:25 --> Config Class Initialized
INFO - 2023-08-10 18:00:25 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:00:25 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:00:25 --> Utf8 Class Initialized
INFO - 2023-08-10 18:00:25 --> URI Class Initialized
INFO - 2023-08-10 18:00:25 --> Router Class Initialized
INFO - 2023-08-10 18:00:25 --> Output Class Initialized
INFO - 2023-08-10 18:00:25 --> Security Class Initialized
DEBUG - 2023-08-10 18:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:00:25 --> Input Class Initialized
INFO - 2023-08-10 18:00:25 --> Language Class Initialized
INFO - 2023-08-10 18:00:25 --> Loader Class Initialized
INFO - 2023-08-10 18:00:25 --> Helper loaded: url_helper
INFO - 2023-08-10 18:00:25 --> Helper loaded: file_helper
INFO - 2023-08-10 18:00:25 --> Database Driver Class Initialized
INFO - 2023-08-10 18:00:25 --> Email Class Initialized
DEBUG - 2023-08-10 18:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:00:25 --> Controller Class Initialized
INFO - 2023-08-10 18:00:25 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:00:25 --> Helper loaded: form_helper
INFO - 2023-08-10 18:00:25 --> Form Validation Class Initialized
ERROR - 2023-08-10 18:00:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-10 18:00:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-10 18:00:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-10 18:00:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-10 18:00:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-10 18:00:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-10 18:00:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-10 18:00:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-10 18:00:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-10 18:00:25 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:00:25 --> Final output sent to browser
DEBUG - 2023-08-10 18:00:25 --> Total execution time: 0.0910
INFO - 2023-08-10 18:00:26 --> Config Class Initialized
INFO - 2023-08-10 18:00:26 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:00:26 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:00:26 --> Utf8 Class Initialized
INFO - 2023-08-10 18:00:26 --> URI Class Initialized
INFO - 2023-08-10 18:00:26 --> Router Class Initialized
INFO - 2023-08-10 18:00:26 --> Output Class Initialized
INFO - 2023-08-10 18:00:26 --> Security Class Initialized
DEBUG - 2023-08-10 18:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:00:26 --> Input Class Initialized
INFO - 2023-08-10 18:00:26 --> Language Class Initialized
INFO - 2023-08-10 18:00:26 --> Loader Class Initialized
INFO - 2023-08-10 18:00:26 --> Helper loaded: url_helper
INFO - 2023-08-10 18:00:26 --> Helper loaded: file_helper
INFO - 2023-08-10 18:00:26 --> Database Driver Class Initialized
INFO - 2023-08-10 18:00:26 --> Email Class Initialized
DEBUG - 2023-08-10 18:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:00:26 --> Controller Class Initialized
INFO - 2023-08-10 18:00:26 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:00:26 --> Helper loaded: form_helper
INFO - 2023-08-10 18:00:26 --> Form Validation Class Initialized
ERROR - 2023-08-10 18:00:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-10 18:00:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-10 18:00:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-10 18:00:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-10 18:00:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-10 18:00:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-10 18:00:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-10 18:00:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-10 18:00:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-10 18:00:26 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:00:26 --> Final output sent to browser
DEBUG - 2023-08-10 18:00:26 --> Total execution time: 0.0497
INFO - 2023-08-10 18:00:42 --> Config Class Initialized
INFO - 2023-08-10 18:00:42 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:00:42 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:00:42 --> Utf8 Class Initialized
INFO - 2023-08-10 18:00:42 --> URI Class Initialized
INFO - 2023-08-10 18:00:42 --> Router Class Initialized
INFO - 2023-08-10 18:00:42 --> Output Class Initialized
INFO - 2023-08-10 18:00:42 --> Security Class Initialized
DEBUG - 2023-08-10 18:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:00:42 --> Input Class Initialized
INFO - 2023-08-10 18:00:42 --> Language Class Initialized
INFO - 2023-08-10 18:00:42 --> Loader Class Initialized
INFO - 2023-08-10 18:00:42 --> Helper loaded: url_helper
INFO - 2023-08-10 18:00:42 --> Helper loaded: file_helper
INFO - 2023-08-10 18:00:42 --> Database Driver Class Initialized
INFO - 2023-08-10 18:00:42 --> Email Class Initialized
DEBUG - 2023-08-10 18:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:00:42 --> Controller Class Initialized
INFO - 2023-08-10 18:00:42 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:00:42 --> Helper loaded: form_helper
INFO - 2023-08-10 18:00:42 --> Form Validation Class Initialized
INFO - 2023-08-10 18:00:42 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:00:42 --> Final output sent to browser
DEBUG - 2023-08-10 18:00:42 --> Total execution time: 0.0975
INFO - 2023-08-10 18:00:43 --> Config Class Initialized
INFO - 2023-08-10 18:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:00:43 --> Utf8 Class Initialized
INFO - 2023-08-10 18:00:43 --> URI Class Initialized
INFO - 2023-08-10 18:00:43 --> Router Class Initialized
INFO - 2023-08-10 18:00:43 --> Output Class Initialized
INFO - 2023-08-10 18:00:43 --> Security Class Initialized
DEBUG - 2023-08-10 18:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:00:43 --> Input Class Initialized
INFO - 2023-08-10 18:00:43 --> Language Class Initialized
INFO - 2023-08-10 18:00:43 --> Loader Class Initialized
INFO - 2023-08-10 18:00:43 --> Helper loaded: url_helper
INFO - 2023-08-10 18:00:43 --> Helper loaded: file_helper
INFO - 2023-08-10 18:00:43 --> Database Driver Class Initialized
INFO - 2023-08-10 18:00:43 --> Email Class Initialized
DEBUG - 2023-08-10 18:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:00:43 --> Controller Class Initialized
INFO - 2023-08-10 18:00:43 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:00:43 --> Helper loaded: form_helper
INFO - 2023-08-10 18:00:43 --> Form Validation Class Initialized
ERROR - 2023-08-10 18:00:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-10 18:00:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-10 18:00:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-10 18:00:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-10 18:00:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-10 18:00:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-10 18:00:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-10 18:00:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-10 18:00:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-10 18:00:43 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:00:43 --> Final output sent to browser
DEBUG - 2023-08-10 18:00:43 --> Total execution time: 0.0502
INFO - 2023-08-10 18:00:45 --> Config Class Initialized
INFO - 2023-08-10 18:00:45 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:00:45 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:00:45 --> Utf8 Class Initialized
INFO - 2023-08-10 18:00:45 --> URI Class Initialized
INFO - 2023-08-10 18:00:45 --> Router Class Initialized
INFO - 2023-08-10 18:00:45 --> Output Class Initialized
INFO - 2023-08-10 18:00:45 --> Security Class Initialized
DEBUG - 2023-08-10 18:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:00:45 --> Input Class Initialized
INFO - 2023-08-10 18:00:45 --> Language Class Initialized
INFO - 2023-08-10 18:00:45 --> Loader Class Initialized
INFO - 2023-08-10 18:00:45 --> Helper loaded: url_helper
INFO - 2023-08-10 18:00:45 --> Helper loaded: file_helper
INFO - 2023-08-10 18:00:45 --> Database Driver Class Initialized
INFO - 2023-08-10 18:00:45 --> Email Class Initialized
DEBUG - 2023-08-10 18:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:00:45 --> Controller Class Initialized
INFO - 2023-08-10 18:00:45 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:00:45 --> Helper loaded: form_helper
INFO - 2023-08-10 18:00:45 --> Form Validation Class Initialized
INFO - 2023-08-10 18:00:45 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:00:45 --> Final output sent to browser
DEBUG - 2023-08-10 18:00:45 --> Total execution time: 0.0524
INFO - 2023-08-10 18:00:46 --> Config Class Initialized
INFO - 2023-08-10 18:00:46 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:00:46 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:00:46 --> Utf8 Class Initialized
INFO - 2023-08-10 18:00:46 --> URI Class Initialized
INFO - 2023-08-10 18:00:46 --> Router Class Initialized
INFO - 2023-08-10 18:00:46 --> Output Class Initialized
INFO - 2023-08-10 18:00:46 --> Security Class Initialized
DEBUG - 2023-08-10 18:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:00:46 --> Input Class Initialized
INFO - 2023-08-10 18:00:46 --> Language Class Initialized
INFO - 2023-08-10 18:00:46 --> Loader Class Initialized
INFO - 2023-08-10 18:00:46 --> Helper loaded: url_helper
INFO - 2023-08-10 18:00:46 --> Helper loaded: file_helper
INFO - 2023-08-10 18:00:46 --> Database Driver Class Initialized
INFO - 2023-08-10 18:00:46 --> Email Class Initialized
DEBUG - 2023-08-10 18:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:00:46 --> Controller Class Initialized
INFO - 2023-08-10 18:00:46 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:00:46 --> Helper loaded: form_helper
INFO - 2023-08-10 18:00:46 --> Form Validation Class Initialized
INFO - 2023-08-10 18:00:46 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:00:46 --> Final output sent to browser
DEBUG - 2023-08-10 18:00:46 --> Total execution time: 0.0463
INFO - 2023-08-10 18:00:52 --> Config Class Initialized
INFO - 2023-08-10 18:00:52 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:00:52 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:00:52 --> Utf8 Class Initialized
INFO - 2023-08-10 18:00:52 --> URI Class Initialized
INFO - 2023-08-10 18:00:52 --> Router Class Initialized
INFO - 2023-08-10 18:00:52 --> Output Class Initialized
INFO - 2023-08-10 18:00:52 --> Security Class Initialized
DEBUG - 2023-08-10 18:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:00:52 --> Input Class Initialized
INFO - 2023-08-10 18:00:52 --> Language Class Initialized
INFO - 2023-08-10 18:00:52 --> Loader Class Initialized
INFO - 2023-08-10 18:00:52 --> Helper loaded: url_helper
INFO - 2023-08-10 18:00:52 --> Helper loaded: file_helper
INFO - 2023-08-10 18:00:52 --> Database Driver Class Initialized
INFO - 2023-08-10 18:00:52 --> Email Class Initialized
DEBUG - 2023-08-10 18:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:00:52 --> Controller Class Initialized
INFO - 2023-08-10 18:00:52 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:00:52 --> Helper loaded: form_helper
INFO - 2023-08-10 18:00:52 --> Form Validation Class Initialized
INFO - 2023-08-10 18:00:52 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:00:52 --> Final output sent to browser
DEBUG - 2023-08-10 18:00:52 --> Total execution time: 0.0540
INFO - 2023-08-10 18:00:53 --> Config Class Initialized
INFO - 2023-08-10 18:00:53 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:00:53 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:00:53 --> Utf8 Class Initialized
INFO - 2023-08-10 18:00:53 --> URI Class Initialized
INFO - 2023-08-10 18:00:53 --> Router Class Initialized
INFO - 2023-08-10 18:00:53 --> Output Class Initialized
INFO - 2023-08-10 18:00:53 --> Security Class Initialized
DEBUG - 2023-08-10 18:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:00:53 --> Input Class Initialized
INFO - 2023-08-10 18:00:53 --> Language Class Initialized
INFO - 2023-08-10 18:00:53 --> Loader Class Initialized
INFO - 2023-08-10 18:00:53 --> Helper loaded: url_helper
INFO - 2023-08-10 18:00:53 --> Helper loaded: file_helper
INFO - 2023-08-10 18:00:53 --> Database Driver Class Initialized
INFO - 2023-08-10 18:00:53 --> Email Class Initialized
DEBUG - 2023-08-10 18:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:00:53 --> Controller Class Initialized
INFO - 2023-08-10 18:00:53 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:00:53 --> Helper loaded: form_helper
INFO - 2023-08-10 18:00:53 --> Form Validation Class Initialized
ERROR - 2023-08-10 18:00:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-10 18:00:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-10 18:00:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-10 18:00:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-10 18:00:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-10 18:00:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-10 18:00:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-10 18:00:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-10 18:00:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-10 18:00:53 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:00:53 --> Final output sent to browser
DEBUG - 2023-08-10 18:00:53 --> Total execution time: 0.0489
INFO - 2023-08-10 18:00:54 --> Config Class Initialized
INFO - 2023-08-10 18:00:54 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:00:54 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:00:54 --> Utf8 Class Initialized
INFO - 2023-08-10 18:00:54 --> URI Class Initialized
INFO - 2023-08-10 18:00:54 --> Router Class Initialized
INFO - 2023-08-10 18:00:54 --> Output Class Initialized
INFO - 2023-08-10 18:00:54 --> Security Class Initialized
DEBUG - 2023-08-10 18:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:00:54 --> Input Class Initialized
INFO - 2023-08-10 18:00:54 --> Language Class Initialized
INFO - 2023-08-10 18:00:54 --> Loader Class Initialized
INFO - 2023-08-10 18:00:54 --> Helper loaded: url_helper
INFO - 2023-08-10 18:00:54 --> Helper loaded: file_helper
INFO - 2023-08-10 18:00:54 --> Database Driver Class Initialized
INFO - 2023-08-10 18:00:54 --> Email Class Initialized
DEBUG - 2023-08-10 18:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:00:54 --> Controller Class Initialized
INFO - 2023-08-10 18:00:54 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:00:54 --> Helper loaded: form_helper
INFO - 2023-08-10 18:00:54 --> Form Validation Class Initialized
ERROR - 2023-08-10 18:00:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-10 18:00:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-10 18:00:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-10 18:00:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-10 18:00:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-10 18:00:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-10 18:00:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-10 18:00:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-10 18:00:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-10 18:00:54 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:00:54 --> Final output sent to browser
DEBUG - 2023-08-10 18:00:54 --> Total execution time: 0.0574
INFO - 2023-08-10 18:00:54 --> Config Class Initialized
INFO - 2023-08-10 18:00:54 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:00:54 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:00:54 --> Utf8 Class Initialized
INFO - 2023-08-10 18:00:55 --> URI Class Initialized
INFO - 2023-08-10 18:00:55 --> Router Class Initialized
INFO - 2023-08-10 18:00:55 --> Output Class Initialized
INFO - 2023-08-10 18:00:55 --> Security Class Initialized
DEBUG - 2023-08-10 18:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:00:55 --> Input Class Initialized
INFO - 2023-08-10 18:00:55 --> Language Class Initialized
INFO - 2023-08-10 18:00:55 --> Loader Class Initialized
INFO - 2023-08-10 18:00:55 --> Helper loaded: url_helper
INFO - 2023-08-10 18:00:55 --> Helper loaded: file_helper
INFO - 2023-08-10 18:00:55 --> Database Driver Class Initialized
INFO - 2023-08-10 18:00:55 --> Email Class Initialized
DEBUG - 2023-08-10 18:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:00:55 --> Controller Class Initialized
INFO - 2023-08-10 18:00:55 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:00:55 --> Helper loaded: form_helper
INFO - 2023-08-10 18:00:55 --> Form Validation Class Initialized
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-10 18:00:55 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:00:55 --> Final output sent to browser
DEBUG - 2023-08-10 18:00:55 --> Total execution time: 0.0504
INFO - 2023-08-10 18:00:55 --> Config Class Initialized
INFO - 2023-08-10 18:00:55 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:00:55 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:00:55 --> Utf8 Class Initialized
INFO - 2023-08-10 18:00:55 --> URI Class Initialized
INFO - 2023-08-10 18:00:55 --> Router Class Initialized
INFO - 2023-08-10 18:00:55 --> Output Class Initialized
INFO - 2023-08-10 18:00:55 --> Security Class Initialized
DEBUG - 2023-08-10 18:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:00:55 --> Input Class Initialized
INFO - 2023-08-10 18:00:55 --> Language Class Initialized
INFO - 2023-08-10 18:00:55 --> Loader Class Initialized
INFO - 2023-08-10 18:00:55 --> Helper loaded: url_helper
INFO - 2023-08-10 18:00:55 --> Helper loaded: file_helper
INFO - 2023-08-10 18:00:55 --> Database Driver Class Initialized
INFO - 2023-08-10 18:00:55 --> Email Class Initialized
DEBUG - 2023-08-10 18:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:00:55 --> Controller Class Initialized
INFO - 2023-08-10 18:00:55 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:00:55 --> Helper loaded: form_helper
INFO - 2023-08-10 18:00:55 --> Form Validation Class Initialized
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-10 18:00:55 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:00:55 --> Final output sent to browser
DEBUG - 2023-08-10 18:00:55 --> Total execution time: 0.0515
INFO - 2023-08-10 18:00:55 --> Config Class Initialized
INFO - 2023-08-10 18:00:55 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:00:55 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:00:55 --> Utf8 Class Initialized
INFO - 2023-08-10 18:00:55 --> URI Class Initialized
INFO - 2023-08-10 18:00:55 --> Router Class Initialized
INFO - 2023-08-10 18:00:55 --> Output Class Initialized
INFO - 2023-08-10 18:00:55 --> Security Class Initialized
DEBUG - 2023-08-10 18:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:00:55 --> Input Class Initialized
INFO - 2023-08-10 18:00:55 --> Language Class Initialized
INFO - 2023-08-10 18:00:55 --> Loader Class Initialized
INFO - 2023-08-10 18:00:55 --> Helper loaded: url_helper
INFO - 2023-08-10 18:00:55 --> Helper loaded: file_helper
INFO - 2023-08-10 18:00:55 --> Database Driver Class Initialized
INFO - 2023-08-10 18:00:55 --> Email Class Initialized
DEBUG - 2023-08-10 18:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:00:55 --> Controller Class Initialized
INFO - 2023-08-10 18:00:55 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:00:55 --> Helper loaded: form_helper
INFO - 2023-08-10 18:00:55 --> Form Validation Class Initialized
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-10 18:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-10 18:00:55 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:00:55 --> Final output sent to browser
DEBUG - 2023-08-10 18:00:55 --> Total execution time: 0.0621
INFO - 2023-08-10 18:00:55 --> Config Class Initialized
INFO - 2023-08-10 18:00:55 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:00:55 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:00:55 --> Utf8 Class Initialized
INFO - 2023-08-10 18:00:55 --> URI Class Initialized
INFO - 2023-08-10 18:00:55 --> Router Class Initialized
INFO - 2023-08-10 18:00:55 --> Output Class Initialized
INFO - 2023-08-10 18:00:55 --> Security Class Initialized
DEBUG - 2023-08-10 18:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:00:55 --> Input Class Initialized
INFO - 2023-08-10 18:00:55 --> Language Class Initialized
INFO - 2023-08-10 18:00:55 --> Loader Class Initialized
INFO - 2023-08-10 18:00:55 --> Helper loaded: url_helper
INFO - 2023-08-10 18:00:55 --> Helper loaded: file_helper
INFO - 2023-08-10 18:00:55 --> Database Driver Class Initialized
INFO - 2023-08-10 18:00:55 --> Email Class Initialized
DEBUG - 2023-08-10 18:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:00:55 --> Controller Class Initialized
INFO - 2023-08-10 18:00:55 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:00:55 --> Helper loaded: form_helper
INFO - 2023-08-10 18:00:55 --> Form Validation Class Initialized
INFO - 2023-08-10 18:00:55 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:00:55 --> Final output sent to browser
DEBUG - 2023-08-10 18:00:55 --> Total execution time: 0.0549
INFO - 2023-08-10 18:02:31 --> Config Class Initialized
INFO - 2023-08-10 18:02:31 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:02:31 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:02:31 --> Utf8 Class Initialized
INFO - 2023-08-10 18:02:31 --> URI Class Initialized
INFO - 2023-08-10 18:02:31 --> Router Class Initialized
INFO - 2023-08-10 18:02:31 --> Output Class Initialized
INFO - 2023-08-10 18:02:31 --> Security Class Initialized
DEBUG - 2023-08-10 18:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:02:31 --> Input Class Initialized
INFO - 2023-08-10 18:02:31 --> Language Class Initialized
INFO - 2023-08-10 18:02:31 --> Loader Class Initialized
INFO - 2023-08-10 18:02:31 --> Helper loaded: url_helper
INFO - 2023-08-10 18:02:31 --> Helper loaded: file_helper
INFO - 2023-08-10 18:02:31 --> Database Driver Class Initialized
INFO - 2023-08-10 18:02:31 --> Email Class Initialized
DEBUG - 2023-08-10 18:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:02:31 --> Controller Class Initialized
INFO - 2023-08-10 18:02:31 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:02:31 --> Helper loaded: form_helper
INFO - 2023-08-10 18:02:31 --> Form Validation Class Initialized
INFO - 2023-08-10 18:02:32 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:02:32 --> Final output sent to browser
DEBUG - 2023-08-10 18:02:32 --> Total execution time: 0.1751
INFO - 2023-08-10 18:02:34 --> Config Class Initialized
INFO - 2023-08-10 18:02:34 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:02:34 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:02:34 --> Utf8 Class Initialized
INFO - 2023-08-10 18:02:34 --> URI Class Initialized
INFO - 2023-08-10 18:02:34 --> Router Class Initialized
INFO - 2023-08-10 18:02:34 --> Output Class Initialized
INFO - 2023-08-10 18:02:34 --> Security Class Initialized
DEBUG - 2023-08-10 18:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:02:34 --> Input Class Initialized
INFO - 2023-08-10 18:02:34 --> Language Class Initialized
INFO - 2023-08-10 18:02:34 --> Loader Class Initialized
INFO - 2023-08-10 18:02:34 --> Helper loaded: url_helper
INFO - 2023-08-10 18:02:34 --> Helper loaded: file_helper
INFO - 2023-08-10 18:02:34 --> Database Driver Class Initialized
INFO - 2023-08-10 18:02:34 --> Email Class Initialized
DEBUG - 2023-08-10 18:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:02:34 --> Controller Class Initialized
INFO - 2023-08-10 18:02:34 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:02:34 --> Helper loaded: form_helper
INFO - 2023-08-10 18:02:34 --> Form Validation Class Initialized
INFO - 2023-08-10 18:02:34 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:02:34 --> Final output sent to browser
DEBUG - 2023-08-10 18:02:34 --> Total execution time: 0.0465
INFO - 2023-08-10 18:02:35 --> Config Class Initialized
INFO - 2023-08-10 18:02:35 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:02:35 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:02:35 --> Utf8 Class Initialized
INFO - 2023-08-10 18:02:35 --> URI Class Initialized
INFO - 2023-08-10 18:02:35 --> Router Class Initialized
INFO - 2023-08-10 18:02:35 --> Output Class Initialized
INFO - 2023-08-10 18:02:35 --> Security Class Initialized
DEBUG - 2023-08-10 18:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:02:35 --> Input Class Initialized
INFO - 2023-08-10 18:02:35 --> Language Class Initialized
INFO - 2023-08-10 18:02:35 --> Loader Class Initialized
INFO - 2023-08-10 18:02:35 --> Helper loaded: url_helper
INFO - 2023-08-10 18:02:35 --> Helper loaded: file_helper
INFO - 2023-08-10 18:02:35 --> Database Driver Class Initialized
INFO - 2023-08-10 18:02:35 --> Email Class Initialized
DEBUG - 2023-08-10 18:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:02:35 --> Controller Class Initialized
INFO - 2023-08-10 18:02:35 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:02:35 --> Helper loaded: form_helper
INFO - 2023-08-10 18:02:35 --> Form Validation Class Initialized
INFO - 2023-08-10 18:02:35 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:02:35 --> Final output sent to browser
DEBUG - 2023-08-10 18:02:35 --> Total execution time: 0.0495
INFO - 2023-08-10 18:03:21 --> Config Class Initialized
INFO - 2023-08-10 18:03:21 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:03:21 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:03:21 --> Utf8 Class Initialized
INFO - 2023-08-10 18:03:21 --> URI Class Initialized
INFO - 2023-08-10 18:03:21 --> Router Class Initialized
INFO - 2023-08-10 18:03:21 --> Output Class Initialized
INFO - 2023-08-10 18:03:21 --> Security Class Initialized
DEBUG - 2023-08-10 18:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:03:21 --> Input Class Initialized
INFO - 2023-08-10 18:03:21 --> Language Class Initialized
INFO - 2023-08-10 18:03:21 --> Loader Class Initialized
INFO - 2023-08-10 18:03:21 --> Helper loaded: url_helper
INFO - 2023-08-10 18:03:21 --> Helper loaded: file_helper
INFO - 2023-08-10 18:03:21 --> Database Driver Class Initialized
INFO - 2023-08-10 18:03:21 --> Email Class Initialized
DEBUG - 2023-08-10 18:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:03:21 --> Controller Class Initialized
INFO - 2023-08-10 18:03:21 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:03:21 --> Helper loaded: form_helper
INFO - 2023-08-10 18:03:21 --> Form Validation Class Initialized
INFO - 2023-08-10 18:03:21 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:03:21 --> Final output sent to browser
DEBUG - 2023-08-10 18:03:21 --> Total execution time: 0.1429
INFO - 2023-08-10 18:03:22 --> Config Class Initialized
INFO - 2023-08-10 18:03:22 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:03:22 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:03:22 --> Utf8 Class Initialized
INFO - 2023-08-10 18:03:22 --> URI Class Initialized
INFO - 2023-08-10 18:03:22 --> Router Class Initialized
INFO - 2023-08-10 18:03:22 --> Output Class Initialized
INFO - 2023-08-10 18:03:22 --> Security Class Initialized
DEBUG - 2023-08-10 18:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:03:22 --> Input Class Initialized
INFO - 2023-08-10 18:03:22 --> Language Class Initialized
INFO - 2023-08-10 18:03:22 --> Loader Class Initialized
INFO - 2023-08-10 18:03:22 --> Helper loaded: url_helper
INFO - 2023-08-10 18:03:22 --> Helper loaded: file_helper
INFO - 2023-08-10 18:03:22 --> Database Driver Class Initialized
INFO - 2023-08-10 18:03:22 --> Email Class Initialized
DEBUG - 2023-08-10 18:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:03:22 --> Controller Class Initialized
INFO - 2023-08-10 18:03:22 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:03:22 --> Helper loaded: form_helper
INFO - 2023-08-10 18:03:22 --> Form Validation Class Initialized
INFO - 2023-08-10 18:03:22 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:03:22 --> Final output sent to browser
DEBUG - 2023-08-10 18:03:22 --> Total execution time: 0.0563
INFO - 2023-08-10 18:06:48 --> Config Class Initialized
INFO - 2023-08-10 18:06:48 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:06:48 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:06:48 --> Utf8 Class Initialized
INFO - 2023-08-10 18:06:48 --> URI Class Initialized
INFO - 2023-08-10 18:06:48 --> Router Class Initialized
INFO - 2023-08-10 18:06:48 --> Output Class Initialized
INFO - 2023-08-10 18:06:48 --> Security Class Initialized
DEBUG - 2023-08-10 18:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:06:48 --> Input Class Initialized
INFO - 2023-08-10 18:06:48 --> Language Class Initialized
INFO - 2023-08-10 18:06:49 --> Loader Class Initialized
INFO - 2023-08-10 18:06:49 --> Helper loaded: url_helper
INFO - 2023-08-10 18:06:49 --> Helper loaded: file_helper
INFO - 2023-08-10 18:06:49 --> Database Driver Class Initialized
INFO - 2023-08-10 18:06:49 --> Email Class Initialized
DEBUG - 2023-08-10 18:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:06:49 --> Controller Class Initialized
INFO - 2023-08-10 18:06:49 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:06:49 --> Helper loaded: form_helper
INFO - 2023-08-10 18:06:49 --> Form Validation Class Initialized
INFO - 2023-08-10 18:06:49 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:06:49 --> Final output sent to browser
DEBUG - 2023-08-10 18:06:49 --> Total execution time: 0.2717
INFO - 2023-08-10 18:06:50 --> Config Class Initialized
INFO - 2023-08-10 18:06:50 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:06:50 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:06:50 --> Utf8 Class Initialized
INFO - 2023-08-10 18:06:50 --> URI Class Initialized
INFO - 2023-08-10 18:06:50 --> Router Class Initialized
INFO - 2023-08-10 18:06:50 --> Output Class Initialized
INFO - 2023-08-10 18:06:50 --> Security Class Initialized
DEBUG - 2023-08-10 18:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:06:50 --> Input Class Initialized
INFO - 2023-08-10 18:06:50 --> Language Class Initialized
INFO - 2023-08-10 18:06:50 --> Loader Class Initialized
INFO - 2023-08-10 18:06:50 --> Helper loaded: url_helper
INFO - 2023-08-10 18:06:50 --> Helper loaded: file_helper
INFO - 2023-08-10 18:06:50 --> Database Driver Class Initialized
INFO - 2023-08-10 18:06:50 --> Email Class Initialized
DEBUG - 2023-08-10 18:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:06:50 --> Controller Class Initialized
INFO - 2023-08-10 18:06:50 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:06:50 --> Helper loaded: form_helper
INFO - 2023-08-10 18:06:50 --> Form Validation Class Initialized
INFO - 2023-08-10 18:06:50 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:06:50 --> Final output sent to browser
DEBUG - 2023-08-10 18:06:50 --> Total execution time: 0.0591
INFO - 2023-08-10 18:06:55 --> Config Class Initialized
INFO - 2023-08-10 18:06:55 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:06:55 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:06:55 --> Utf8 Class Initialized
INFO - 2023-08-10 18:06:55 --> URI Class Initialized
INFO - 2023-08-10 18:06:55 --> Router Class Initialized
INFO - 2023-08-10 18:06:55 --> Output Class Initialized
INFO - 2023-08-10 18:06:55 --> Security Class Initialized
DEBUG - 2023-08-10 18:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:06:55 --> Input Class Initialized
INFO - 2023-08-10 18:06:55 --> Language Class Initialized
INFO - 2023-08-10 18:06:55 --> Loader Class Initialized
INFO - 2023-08-10 18:06:55 --> Helper loaded: url_helper
INFO - 2023-08-10 18:06:55 --> Helper loaded: file_helper
INFO - 2023-08-10 18:06:55 --> Database Driver Class Initialized
INFO - 2023-08-10 18:06:55 --> Email Class Initialized
DEBUG - 2023-08-10 18:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:06:55 --> Controller Class Initialized
INFO - 2023-08-10 18:06:55 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:06:55 --> Helper loaded: form_helper
INFO - 2023-08-10 18:06:55 --> Form Validation Class Initialized
INFO - 2023-08-10 18:06:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 18:06:55 --> Config Class Initialized
INFO - 2023-08-10 18:06:55 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:06:55 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:06:55 --> Utf8 Class Initialized
INFO - 2023-08-10 18:06:55 --> URI Class Initialized
INFO - 2023-08-10 18:06:55 --> Router Class Initialized
INFO - 2023-08-10 18:06:55 --> Output Class Initialized
INFO - 2023-08-10 18:06:55 --> Security Class Initialized
DEBUG - 2023-08-10 18:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:06:55 --> Input Class Initialized
INFO - 2023-08-10 18:06:55 --> Language Class Initialized
INFO - 2023-08-10 18:06:55 --> Loader Class Initialized
INFO - 2023-08-10 18:06:55 --> Helper loaded: url_helper
INFO - 2023-08-10 18:06:55 --> Helper loaded: file_helper
INFO - 2023-08-10 18:06:55 --> Database Driver Class Initialized
INFO - 2023-08-10 18:06:55 --> Email Class Initialized
DEBUG - 2023-08-10 18:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:06:55 --> Controller Class Initialized
INFO - 2023-08-10 18:06:55 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:06:55 --> Helper loaded: form_helper
INFO - 2023-08-10 18:06:55 --> Form Validation Class Initialized
INFO - 2023-08-10 18:06:55 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:06:55 --> Final output sent to browser
DEBUG - 2023-08-10 18:06:55 --> Total execution time: 0.0662
INFO - 2023-08-10 18:07:03 --> Config Class Initialized
INFO - 2023-08-10 18:07:03 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:07:03 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:07:03 --> Utf8 Class Initialized
INFO - 2023-08-10 18:07:03 --> URI Class Initialized
INFO - 2023-08-10 18:07:03 --> Router Class Initialized
INFO - 2023-08-10 18:07:03 --> Output Class Initialized
INFO - 2023-08-10 18:07:03 --> Security Class Initialized
DEBUG - 2023-08-10 18:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:07:03 --> Input Class Initialized
INFO - 2023-08-10 18:07:03 --> Language Class Initialized
INFO - 2023-08-10 18:07:03 --> Loader Class Initialized
INFO - 2023-08-10 18:07:03 --> Helper loaded: url_helper
INFO - 2023-08-10 18:07:03 --> Helper loaded: file_helper
INFO - 2023-08-10 18:07:03 --> Database Driver Class Initialized
INFO - 2023-08-10 18:07:03 --> Email Class Initialized
DEBUG - 2023-08-10 18:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:07:03 --> Controller Class Initialized
INFO - 2023-08-10 18:07:03 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:07:03 --> Helper loaded: form_helper
INFO - 2023-08-10 18:07:03 --> Form Validation Class Initialized
INFO - 2023-08-10 18:07:03 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:07:03 --> Final output sent to browser
DEBUG - 2023-08-10 18:07:03 --> Total execution time: 0.0664
INFO - 2023-08-10 18:07:06 --> Config Class Initialized
INFO - 2023-08-10 18:07:06 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:07:06 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:07:06 --> Utf8 Class Initialized
INFO - 2023-08-10 18:07:06 --> URI Class Initialized
INFO - 2023-08-10 18:07:06 --> Router Class Initialized
INFO - 2023-08-10 18:07:06 --> Output Class Initialized
INFO - 2023-08-10 18:07:06 --> Security Class Initialized
DEBUG - 2023-08-10 18:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:07:06 --> Input Class Initialized
INFO - 2023-08-10 18:07:06 --> Language Class Initialized
INFO - 2023-08-10 18:07:06 --> Loader Class Initialized
INFO - 2023-08-10 18:07:06 --> Helper loaded: url_helper
INFO - 2023-08-10 18:07:06 --> Helper loaded: file_helper
INFO - 2023-08-10 18:07:06 --> Database Driver Class Initialized
INFO - 2023-08-10 18:07:06 --> Email Class Initialized
DEBUG - 2023-08-10 18:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:07:06 --> Controller Class Initialized
INFO - 2023-08-10 18:07:06 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:07:06 --> Helper loaded: form_helper
INFO - 2023-08-10 18:07:06 --> Form Validation Class Initialized
INFO - 2023-08-10 18:07:06 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:07:06 --> Final output sent to browser
DEBUG - 2023-08-10 18:07:06 --> Total execution time: 0.0506
INFO - 2023-08-10 18:07:06 --> Config Class Initialized
INFO - 2023-08-10 18:07:06 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:07:06 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:07:06 --> Utf8 Class Initialized
INFO - 2023-08-10 18:07:06 --> URI Class Initialized
INFO - 2023-08-10 18:07:06 --> Router Class Initialized
INFO - 2023-08-10 18:07:06 --> Output Class Initialized
INFO - 2023-08-10 18:07:06 --> Security Class Initialized
DEBUG - 2023-08-10 18:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:07:06 --> Input Class Initialized
INFO - 2023-08-10 18:07:06 --> Language Class Initialized
INFO - 2023-08-10 18:07:06 --> Loader Class Initialized
INFO - 2023-08-10 18:07:06 --> Helper loaded: url_helper
INFO - 2023-08-10 18:07:06 --> Helper loaded: file_helper
INFO - 2023-08-10 18:07:06 --> Database Driver Class Initialized
INFO - 2023-08-10 18:07:06 --> Email Class Initialized
DEBUG - 2023-08-10 18:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:07:06 --> Controller Class Initialized
INFO - 2023-08-10 18:07:06 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:07:06 --> Helper loaded: form_helper
INFO - 2023-08-10 18:07:06 --> Form Validation Class Initialized
ERROR - 2023-08-10 18:07:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-10 18:07:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-10 18:07:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 59
ERROR - 2023-08-10 18:07:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-10 18:07:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 61
ERROR - 2023-08-10 18:07:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 74
INFO - 2023-08-10 18:07:06 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:07:06 --> Final output sent to browser
DEBUG - 2023-08-10 18:07:06 --> Total execution time: 0.0512
INFO - 2023-08-10 18:07:11 --> Config Class Initialized
INFO - 2023-08-10 18:07:11 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:07:11 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:07:11 --> Utf8 Class Initialized
INFO - 2023-08-10 18:07:11 --> URI Class Initialized
INFO - 2023-08-10 18:07:11 --> Router Class Initialized
INFO - 2023-08-10 18:07:11 --> Output Class Initialized
INFO - 2023-08-10 18:07:11 --> Security Class Initialized
DEBUG - 2023-08-10 18:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:07:11 --> Input Class Initialized
INFO - 2023-08-10 18:07:11 --> Language Class Initialized
INFO - 2023-08-10 18:07:11 --> Loader Class Initialized
INFO - 2023-08-10 18:07:11 --> Helper loaded: url_helper
INFO - 2023-08-10 18:07:11 --> Helper loaded: file_helper
INFO - 2023-08-10 18:07:11 --> Database Driver Class Initialized
INFO - 2023-08-10 18:07:11 --> Email Class Initialized
DEBUG - 2023-08-10 18:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:07:11 --> Controller Class Initialized
INFO - 2023-08-10 18:07:11 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:07:11 --> Helper loaded: form_helper
INFO - 2023-08-10 18:07:11 --> Form Validation Class Initialized
INFO - 2023-08-10 18:07:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 18:07:11 --> Config Class Initialized
INFO - 2023-08-10 18:07:11 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:07:11 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:07:11 --> Utf8 Class Initialized
INFO - 2023-08-10 18:07:11 --> URI Class Initialized
INFO - 2023-08-10 18:07:11 --> Router Class Initialized
INFO - 2023-08-10 18:07:11 --> Output Class Initialized
INFO - 2023-08-10 18:07:11 --> Security Class Initialized
DEBUG - 2023-08-10 18:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:07:11 --> Input Class Initialized
INFO - 2023-08-10 18:07:11 --> Language Class Initialized
INFO - 2023-08-10 18:07:11 --> Loader Class Initialized
INFO - 2023-08-10 18:07:11 --> Helper loaded: url_helper
INFO - 2023-08-10 18:07:11 --> Helper loaded: file_helper
INFO - 2023-08-10 18:07:11 --> Database Driver Class Initialized
INFO - 2023-08-10 18:07:11 --> Email Class Initialized
DEBUG - 2023-08-10 18:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:07:11 --> Controller Class Initialized
INFO - 2023-08-10 18:07:11 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:07:11 --> Helper loaded: form_helper
INFO - 2023-08-10 18:07:11 --> Form Validation Class Initialized
INFO - 2023-08-10 18:07:11 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:07:11 --> Final output sent to browser
DEBUG - 2023-08-10 18:07:11 --> Total execution time: 0.0454
INFO - 2023-08-10 18:07:34 --> Config Class Initialized
INFO - 2023-08-10 18:07:34 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:07:34 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:07:34 --> Utf8 Class Initialized
INFO - 2023-08-10 18:07:34 --> URI Class Initialized
INFO - 2023-08-10 18:07:34 --> Router Class Initialized
INFO - 2023-08-10 18:07:34 --> Output Class Initialized
INFO - 2023-08-10 18:07:34 --> Security Class Initialized
DEBUG - 2023-08-10 18:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:07:34 --> Input Class Initialized
INFO - 2023-08-10 18:07:34 --> Language Class Initialized
INFO - 2023-08-10 18:07:34 --> Loader Class Initialized
INFO - 2023-08-10 18:07:34 --> Helper loaded: url_helper
INFO - 2023-08-10 18:07:34 --> Helper loaded: file_helper
INFO - 2023-08-10 18:07:34 --> Database Driver Class Initialized
INFO - 2023-08-10 18:07:34 --> Email Class Initialized
DEBUG - 2023-08-10 18:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:07:34 --> Controller Class Initialized
INFO - 2023-08-10 18:07:34 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:07:34 --> Helper loaded: form_helper
INFO - 2023-08-10 18:07:34 --> Form Validation Class Initialized
INFO - 2023-08-10 18:07:34 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-10 18:07:34 --> Final output sent to browser
DEBUG - 2023-08-10 18:07:34 --> Total execution time: 0.0959
INFO - 2023-08-10 18:08:10 --> Config Class Initialized
INFO - 2023-08-10 18:08:10 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:08:10 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:08:10 --> Utf8 Class Initialized
INFO - 2023-08-10 18:08:10 --> URI Class Initialized
INFO - 2023-08-10 18:08:10 --> Router Class Initialized
INFO - 2023-08-10 18:08:10 --> Output Class Initialized
INFO - 2023-08-10 18:08:10 --> Security Class Initialized
DEBUG - 2023-08-10 18:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:08:10 --> Input Class Initialized
INFO - 2023-08-10 18:08:10 --> Language Class Initialized
INFO - 2023-08-10 18:08:10 --> Loader Class Initialized
INFO - 2023-08-10 18:08:10 --> Helper loaded: url_helper
INFO - 2023-08-10 18:08:10 --> Helper loaded: file_helper
INFO - 2023-08-10 18:08:10 --> Database Driver Class Initialized
INFO - 2023-08-10 18:08:10 --> Email Class Initialized
DEBUG - 2023-08-10 18:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:08:10 --> Controller Class Initialized
INFO - 2023-08-10 18:08:10 --> Model "Services_model" initialized
INFO - 2023-08-10 18:08:10 --> Helper loaded: form_helper
INFO - 2023-08-10 18:08:10 --> Form Validation Class Initialized
INFO - 2023-08-10 18:08:10 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-10 18:08:10 --> Final output sent to browser
DEBUG - 2023-08-10 18:08:10 --> Total execution time: 0.1046
INFO - 2023-08-10 18:08:10 --> Config Class Initialized
INFO - 2023-08-10 18:08:10 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:08:10 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:08:10 --> Utf8 Class Initialized
INFO - 2023-08-10 18:08:10 --> URI Class Initialized
INFO - 2023-08-10 18:08:10 --> Router Class Initialized
INFO - 2023-08-10 18:08:10 --> Output Class Initialized
INFO - 2023-08-10 18:08:10 --> Security Class Initialized
DEBUG - 2023-08-10 18:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:08:10 --> Input Class Initialized
INFO - 2023-08-10 18:08:10 --> Language Class Initialized
ERROR - 2023-08-10 18:08:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-10 18:08:12 --> Config Class Initialized
INFO - 2023-08-10 18:08:12 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:08:12 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:08:12 --> Utf8 Class Initialized
INFO - 2023-08-10 18:08:12 --> URI Class Initialized
INFO - 2023-08-10 18:08:12 --> Router Class Initialized
INFO - 2023-08-10 18:08:12 --> Output Class Initialized
INFO - 2023-08-10 18:08:12 --> Security Class Initialized
DEBUG - 2023-08-10 18:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:08:12 --> Input Class Initialized
INFO - 2023-08-10 18:08:12 --> Language Class Initialized
INFO - 2023-08-10 18:08:12 --> Loader Class Initialized
INFO - 2023-08-10 18:08:12 --> Helper loaded: url_helper
INFO - 2023-08-10 18:08:12 --> Helper loaded: file_helper
INFO - 2023-08-10 18:08:12 --> Database Driver Class Initialized
INFO - 2023-08-10 18:08:12 --> Email Class Initialized
DEBUG - 2023-08-10 18:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:08:12 --> Controller Class Initialized
INFO - 2023-08-10 18:08:12 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:08:12 --> Helper loaded: form_helper
INFO - 2023-08-10 18:08:12 --> Form Validation Class Initialized
INFO - 2023-08-10 18:08:12 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:08:12 --> Final output sent to browser
DEBUG - 2023-08-10 18:08:12 --> Total execution time: 0.0462
INFO - 2023-08-10 18:11:44 --> Config Class Initialized
INFO - 2023-08-10 18:11:44 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:11:44 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:11:44 --> Utf8 Class Initialized
INFO - 2023-08-10 18:11:44 --> URI Class Initialized
INFO - 2023-08-10 18:11:44 --> Router Class Initialized
INFO - 2023-08-10 18:11:44 --> Output Class Initialized
INFO - 2023-08-10 18:11:44 --> Security Class Initialized
DEBUG - 2023-08-10 18:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:11:44 --> Input Class Initialized
INFO - 2023-08-10 18:11:44 --> Language Class Initialized
INFO - 2023-08-10 18:11:44 --> Loader Class Initialized
INFO - 2023-08-10 18:11:44 --> Helper loaded: url_helper
INFO - 2023-08-10 18:11:44 --> Helper loaded: file_helper
INFO - 2023-08-10 18:11:44 --> Database Driver Class Initialized
INFO - 2023-08-10 18:11:44 --> Email Class Initialized
DEBUG - 2023-08-10 18:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:11:44 --> Controller Class Initialized
INFO - 2023-08-10 18:11:44 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:11:44 --> Helper loaded: form_helper
INFO - 2023-08-10 18:11:44 --> Form Validation Class Initialized
INFO - 2023-08-10 18:11:44 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 18:11:44 --> Final output sent to browser
DEBUG - 2023-08-10 18:11:44 --> Total execution time: 0.3086
INFO - 2023-08-10 18:11:50 --> Config Class Initialized
INFO - 2023-08-10 18:11:50 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:11:50 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:11:50 --> Utf8 Class Initialized
INFO - 2023-08-10 18:11:50 --> URI Class Initialized
INFO - 2023-08-10 18:11:50 --> Router Class Initialized
INFO - 2023-08-10 18:11:50 --> Output Class Initialized
INFO - 2023-08-10 18:11:50 --> Security Class Initialized
DEBUG - 2023-08-10 18:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:11:50 --> Input Class Initialized
INFO - 2023-08-10 18:11:50 --> Language Class Initialized
INFO - 2023-08-10 18:11:50 --> Loader Class Initialized
INFO - 2023-08-10 18:11:50 --> Helper loaded: url_helper
INFO - 2023-08-10 18:11:50 --> Helper loaded: file_helper
INFO - 2023-08-10 18:11:50 --> Database Driver Class Initialized
INFO - 2023-08-10 18:11:50 --> Email Class Initialized
DEBUG - 2023-08-10 18:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:11:50 --> Controller Class Initialized
INFO - 2023-08-10 18:11:50 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:11:50 --> Helper loaded: form_helper
INFO - 2023-08-10 18:11:50 --> Form Validation Class Initialized
INFO - 2023-08-10 18:11:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 18:11:50 --> Config Class Initialized
INFO - 2023-08-10 18:11:50 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:11:50 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:11:50 --> Utf8 Class Initialized
INFO - 2023-08-10 18:11:50 --> URI Class Initialized
INFO - 2023-08-10 18:11:50 --> Router Class Initialized
INFO - 2023-08-10 18:11:50 --> Output Class Initialized
INFO - 2023-08-10 18:11:50 --> Security Class Initialized
DEBUG - 2023-08-10 18:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:11:50 --> Input Class Initialized
INFO - 2023-08-10 18:11:50 --> Language Class Initialized
INFO - 2023-08-10 18:11:50 --> Loader Class Initialized
INFO - 2023-08-10 18:11:50 --> Helper loaded: url_helper
INFO - 2023-08-10 18:11:50 --> Helper loaded: file_helper
INFO - 2023-08-10 18:11:50 --> Database Driver Class Initialized
INFO - 2023-08-10 18:11:50 --> Email Class Initialized
DEBUG - 2023-08-10 18:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:11:50 --> Controller Class Initialized
INFO - 2023-08-10 18:11:50 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:11:50 --> Helper loaded: form_helper
INFO - 2023-08-10 18:11:50 --> Form Validation Class Initialized
INFO - 2023-08-10 18:11:50 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:11:50 --> Final output sent to browser
DEBUG - 2023-08-10 18:11:50 --> Total execution time: 0.1140
INFO - 2023-08-10 18:11:55 --> Config Class Initialized
INFO - 2023-08-10 18:11:55 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:11:56 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:11:56 --> Utf8 Class Initialized
INFO - 2023-08-10 18:11:56 --> URI Class Initialized
INFO - 2023-08-10 18:11:56 --> Router Class Initialized
INFO - 2023-08-10 18:11:56 --> Output Class Initialized
INFO - 2023-08-10 18:11:56 --> Security Class Initialized
DEBUG - 2023-08-10 18:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:11:56 --> Input Class Initialized
INFO - 2023-08-10 18:11:56 --> Language Class Initialized
INFO - 2023-08-10 18:11:56 --> Loader Class Initialized
INFO - 2023-08-10 18:11:56 --> Helper loaded: url_helper
INFO - 2023-08-10 18:11:56 --> Helper loaded: file_helper
INFO - 2023-08-10 18:11:56 --> Database Driver Class Initialized
INFO - 2023-08-10 18:11:56 --> Email Class Initialized
DEBUG - 2023-08-10 18:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:11:56 --> Controller Class Initialized
INFO - 2023-08-10 18:11:56 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:11:56 --> Helper loaded: form_helper
INFO - 2023-08-10 18:11:56 --> Form Validation Class Initialized
INFO - 2023-08-10 18:11:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 18:11:56 --> Final output sent to browser
DEBUG - 2023-08-10 18:11:56 --> Total execution time: 0.0490
INFO - 2023-08-10 18:12:02 --> Config Class Initialized
INFO - 2023-08-10 18:12:02 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:12:02 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:12:02 --> Utf8 Class Initialized
INFO - 2023-08-10 18:12:02 --> URI Class Initialized
INFO - 2023-08-10 18:12:02 --> Router Class Initialized
INFO - 2023-08-10 18:12:02 --> Output Class Initialized
INFO - 2023-08-10 18:12:02 --> Security Class Initialized
DEBUG - 2023-08-10 18:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:12:02 --> Input Class Initialized
INFO - 2023-08-10 18:12:02 --> Language Class Initialized
INFO - 2023-08-10 18:12:02 --> Loader Class Initialized
INFO - 2023-08-10 18:12:02 --> Helper loaded: url_helper
INFO - 2023-08-10 18:12:02 --> Helper loaded: file_helper
INFO - 2023-08-10 18:12:02 --> Database Driver Class Initialized
INFO - 2023-08-10 18:12:02 --> Email Class Initialized
DEBUG - 2023-08-10 18:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:12:02 --> Controller Class Initialized
INFO - 2023-08-10 18:12:02 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:12:02 --> Helper loaded: form_helper
INFO - 2023-08-10 18:12:02 --> Form Validation Class Initialized
INFO - 2023-08-10 18:12:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 18:12:02 --> Config Class Initialized
INFO - 2023-08-10 18:12:02 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:12:02 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:12:02 --> Utf8 Class Initialized
INFO - 2023-08-10 18:12:02 --> URI Class Initialized
INFO - 2023-08-10 18:12:02 --> Router Class Initialized
INFO - 2023-08-10 18:12:02 --> Output Class Initialized
INFO - 2023-08-10 18:12:02 --> Security Class Initialized
DEBUG - 2023-08-10 18:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:12:02 --> Input Class Initialized
INFO - 2023-08-10 18:12:02 --> Language Class Initialized
INFO - 2023-08-10 18:12:02 --> Loader Class Initialized
INFO - 2023-08-10 18:12:02 --> Helper loaded: url_helper
INFO - 2023-08-10 18:12:02 --> Helper loaded: file_helper
INFO - 2023-08-10 18:12:02 --> Database Driver Class Initialized
INFO - 2023-08-10 18:12:02 --> Email Class Initialized
DEBUG - 2023-08-10 18:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:12:02 --> Controller Class Initialized
INFO - 2023-08-10 18:12:02 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:12:02 --> Helper loaded: form_helper
INFO - 2023-08-10 18:12:02 --> Form Validation Class Initialized
INFO - 2023-08-10 18:12:02 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:12:02 --> Final output sent to browser
DEBUG - 2023-08-10 18:12:02 --> Total execution time: 0.0467
INFO - 2023-08-10 18:12:07 --> Config Class Initialized
INFO - 2023-08-10 18:12:07 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:12:07 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:12:07 --> Utf8 Class Initialized
INFO - 2023-08-10 18:12:07 --> URI Class Initialized
INFO - 2023-08-10 18:12:07 --> Router Class Initialized
INFO - 2023-08-10 18:12:07 --> Output Class Initialized
INFO - 2023-08-10 18:12:07 --> Security Class Initialized
DEBUG - 2023-08-10 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:12:07 --> Input Class Initialized
INFO - 2023-08-10 18:12:07 --> Language Class Initialized
INFO - 2023-08-10 18:12:07 --> Loader Class Initialized
INFO - 2023-08-10 18:12:07 --> Helper loaded: url_helper
INFO - 2023-08-10 18:12:07 --> Helper loaded: file_helper
INFO - 2023-08-10 18:12:07 --> Database Driver Class Initialized
INFO - 2023-08-10 18:12:07 --> Email Class Initialized
DEBUG - 2023-08-10 18:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:12:07 --> Controller Class Initialized
INFO - 2023-08-10 18:12:07 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:12:07 --> Helper loaded: form_helper
INFO - 2023-08-10 18:12:07 --> Form Validation Class Initialized
INFO - 2023-08-10 18:12:07 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:12:07 --> Final output sent to browser
DEBUG - 2023-08-10 18:12:07 --> Total execution time: 0.0578
INFO - 2023-08-10 18:12:47 --> Config Class Initialized
INFO - 2023-08-10 18:12:47 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:12:47 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:12:47 --> Utf8 Class Initialized
INFO - 2023-08-10 18:12:47 --> URI Class Initialized
INFO - 2023-08-10 18:12:47 --> Router Class Initialized
INFO - 2023-08-10 18:12:47 --> Output Class Initialized
INFO - 2023-08-10 18:12:47 --> Security Class Initialized
DEBUG - 2023-08-10 18:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:12:47 --> Input Class Initialized
INFO - 2023-08-10 18:12:47 --> Language Class Initialized
INFO - 2023-08-10 18:12:47 --> Loader Class Initialized
INFO - 2023-08-10 18:12:47 --> Helper loaded: url_helper
INFO - 2023-08-10 18:12:47 --> Helper loaded: file_helper
INFO - 2023-08-10 18:12:47 --> Database Driver Class Initialized
INFO - 2023-08-10 18:12:47 --> Email Class Initialized
DEBUG - 2023-08-10 18:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:12:47 --> Controller Class Initialized
INFO - 2023-08-10 18:12:47 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:12:47 --> Helper loaded: form_helper
INFO - 2023-08-10 18:12:47 --> Form Validation Class Initialized
INFO - 2023-08-10 18:12:47 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:12:47 --> Final output sent to browser
DEBUG - 2023-08-10 18:12:47 --> Total execution time: 0.1627
INFO - 2023-08-10 18:12:56 --> Config Class Initialized
INFO - 2023-08-10 18:12:56 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:12:56 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:12:56 --> Utf8 Class Initialized
INFO - 2023-08-10 18:12:56 --> URI Class Initialized
INFO - 2023-08-10 18:12:56 --> Router Class Initialized
INFO - 2023-08-10 18:12:56 --> Output Class Initialized
INFO - 2023-08-10 18:12:56 --> Security Class Initialized
DEBUG - 2023-08-10 18:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:12:56 --> Input Class Initialized
INFO - 2023-08-10 18:12:56 --> Language Class Initialized
INFO - 2023-08-10 18:12:56 --> Loader Class Initialized
INFO - 2023-08-10 18:12:56 --> Helper loaded: url_helper
INFO - 2023-08-10 18:12:56 --> Helper loaded: file_helper
INFO - 2023-08-10 18:12:56 --> Database Driver Class Initialized
INFO - 2023-08-10 18:12:56 --> Email Class Initialized
DEBUG - 2023-08-10 18:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:12:56 --> Controller Class Initialized
INFO - 2023-08-10 18:12:56 --> Model "Services_model" initialized
INFO - 2023-08-10 18:12:56 --> Helper loaded: form_helper
INFO - 2023-08-10 18:12:56 --> Form Validation Class Initialized
INFO - 2023-08-10 18:12:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-10 18:12:56 --> Final output sent to browser
DEBUG - 2023-08-10 18:12:56 --> Total execution time: 0.0943
INFO - 2023-08-10 18:12:56 --> Config Class Initialized
INFO - 2023-08-10 18:12:56 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:12:56 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:12:56 --> Utf8 Class Initialized
INFO - 2023-08-10 18:12:56 --> URI Class Initialized
INFO - 2023-08-10 18:12:56 --> Router Class Initialized
INFO - 2023-08-10 18:12:56 --> Output Class Initialized
INFO - 2023-08-10 18:12:56 --> Security Class Initialized
DEBUG - 2023-08-10 18:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:12:56 --> Input Class Initialized
INFO - 2023-08-10 18:12:56 --> Language Class Initialized
ERROR - 2023-08-10 18:12:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-10 18:12:59 --> Config Class Initialized
INFO - 2023-08-10 18:12:59 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:12:59 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:12:59 --> Utf8 Class Initialized
INFO - 2023-08-10 18:12:59 --> URI Class Initialized
INFO - 2023-08-10 18:12:59 --> Router Class Initialized
INFO - 2023-08-10 18:12:59 --> Output Class Initialized
INFO - 2023-08-10 18:12:59 --> Security Class Initialized
DEBUG - 2023-08-10 18:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:12:59 --> Input Class Initialized
INFO - 2023-08-10 18:12:59 --> Language Class Initialized
INFO - 2023-08-10 18:12:59 --> Loader Class Initialized
INFO - 2023-08-10 18:12:59 --> Helper loaded: url_helper
INFO - 2023-08-10 18:12:59 --> Helper loaded: file_helper
INFO - 2023-08-10 18:12:59 --> Database Driver Class Initialized
INFO - 2023-08-10 18:12:59 --> Email Class Initialized
DEBUG - 2023-08-10 18:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:12:59 --> Controller Class Initialized
INFO - 2023-08-10 18:12:59 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:12:59 --> Helper loaded: form_helper
INFO - 2023-08-10 18:12:59 --> Form Validation Class Initialized
INFO - 2023-08-10 18:12:59 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:12:59 --> Final output sent to browser
DEBUG - 2023-08-10 18:12:59 --> Total execution time: 0.0465
INFO - 2023-08-10 18:13:01 --> Config Class Initialized
INFO - 2023-08-10 18:13:01 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:13:01 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:13:01 --> Utf8 Class Initialized
INFO - 2023-08-10 18:13:01 --> URI Class Initialized
INFO - 2023-08-10 18:13:01 --> Router Class Initialized
INFO - 2023-08-10 18:13:01 --> Output Class Initialized
INFO - 2023-08-10 18:13:01 --> Security Class Initialized
DEBUG - 2023-08-10 18:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:13:01 --> Input Class Initialized
INFO - 2023-08-10 18:13:01 --> Language Class Initialized
INFO - 2023-08-10 18:13:01 --> Loader Class Initialized
INFO - 2023-08-10 18:13:01 --> Helper loaded: url_helper
INFO - 2023-08-10 18:13:01 --> Helper loaded: file_helper
INFO - 2023-08-10 18:13:01 --> Database Driver Class Initialized
INFO - 2023-08-10 18:13:01 --> Email Class Initialized
DEBUG - 2023-08-10 18:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:13:01 --> Controller Class Initialized
INFO - 2023-08-10 18:13:01 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:13:01 --> Helper loaded: form_helper
INFO - 2023-08-10 18:13:01 --> Form Validation Class Initialized
INFO - 2023-08-10 18:13:01 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:13:01 --> Final output sent to browser
DEBUG - 2023-08-10 18:13:01 --> Total execution time: 0.0491
INFO - 2023-08-10 18:13:01 --> Config Class Initialized
INFO - 2023-08-10 18:13:01 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:13:01 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:13:01 --> Utf8 Class Initialized
INFO - 2023-08-10 18:13:01 --> URI Class Initialized
INFO - 2023-08-10 18:13:01 --> Router Class Initialized
INFO - 2023-08-10 18:13:01 --> Output Class Initialized
INFO - 2023-08-10 18:13:01 --> Security Class Initialized
DEBUG - 2023-08-10 18:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:13:01 --> Input Class Initialized
INFO - 2023-08-10 18:13:01 --> Language Class Initialized
INFO - 2023-08-10 18:13:01 --> Loader Class Initialized
INFO - 2023-08-10 18:13:01 --> Helper loaded: url_helper
INFO - 2023-08-10 18:13:01 --> Helper loaded: file_helper
INFO - 2023-08-10 18:13:01 --> Database Driver Class Initialized
INFO - 2023-08-10 18:13:01 --> Email Class Initialized
DEBUG - 2023-08-10 18:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:13:01 --> Controller Class Initialized
INFO - 2023-08-10 18:13:01 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:13:01 --> Helper loaded: form_helper
INFO - 2023-08-10 18:13:01 --> Form Validation Class Initialized
INFO - 2023-08-10 18:13:01 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:13:01 --> Final output sent to browser
DEBUG - 2023-08-10 18:13:01 --> Total execution time: 0.0767
INFO - 2023-08-10 18:13:08 --> Config Class Initialized
INFO - 2023-08-10 18:13:08 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:13:08 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:13:08 --> Utf8 Class Initialized
INFO - 2023-08-10 18:13:08 --> URI Class Initialized
INFO - 2023-08-10 18:13:08 --> Router Class Initialized
INFO - 2023-08-10 18:13:08 --> Output Class Initialized
INFO - 2023-08-10 18:13:08 --> Security Class Initialized
DEBUG - 2023-08-10 18:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:13:08 --> Input Class Initialized
INFO - 2023-08-10 18:13:08 --> Language Class Initialized
INFO - 2023-08-10 18:13:08 --> Loader Class Initialized
INFO - 2023-08-10 18:13:08 --> Helper loaded: url_helper
INFO - 2023-08-10 18:13:08 --> Helper loaded: file_helper
INFO - 2023-08-10 18:13:08 --> Database Driver Class Initialized
INFO - 2023-08-10 18:13:08 --> Email Class Initialized
DEBUG - 2023-08-10 18:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:13:08 --> Controller Class Initialized
INFO - 2023-08-10 18:13:08 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:13:08 --> Helper loaded: form_helper
INFO - 2023-08-10 18:13:08 --> Form Validation Class Initialized
INFO - 2023-08-10 18:13:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 18:13:08 --> Config Class Initialized
INFO - 2023-08-10 18:13:08 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:13:08 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:13:08 --> Utf8 Class Initialized
INFO - 2023-08-10 18:13:08 --> URI Class Initialized
INFO - 2023-08-10 18:13:08 --> Router Class Initialized
INFO - 2023-08-10 18:13:08 --> Output Class Initialized
INFO - 2023-08-10 18:13:08 --> Security Class Initialized
DEBUG - 2023-08-10 18:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:13:08 --> Input Class Initialized
INFO - 2023-08-10 18:13:08 --> Language Class Initialized
INFO - 2023-08-10 18:13:08 --> Loader Class Initialized
INFO - 2023-08-10 18:13:08 --> Helper loaded: url_helper
INFO - 2023-08-10 18:13:08 --> Helper loaded: file_helper
INFO - 2023-08-10 18:13:08 --> Database Driver Class Initialized
INFO - 2023-08-10 18:13:08 --> Email Class Initialized
DEBUG - 2023-08-10 18:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:13:08 --> Controller Class Initialized
INFO - 2023-08-10 18:13:08 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:13:08 --> Helper loaded: form_helper
INFO - 2023-08-10 18:13:08 --> Form Validation Class Initialized
INFO - 2023-08-10 18:13:08 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:13:08 --> Final output sent to browser
DEBUG - 2023-08-10 18:13:08 --> Total execution time: 0.0691
INFO - 2023-08-10 18:13:35 --> Config Class Initialized
INFO - 2023-08-10 18:13:35 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:13:35 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:13:35 --> Utf8 Class Initialized
INFO - 2023-08-10 18:13:35 --> URI Class Initialized
INFO - 2023-08-10 18:13:35 --> Router Class Initialized
INFO - 2023-08-10 18:13:35 --> Output Class Initialized
INFO - 2023-08-10 18:13:35 --> Security Class Initialized
DEBUG - 2023-08-10 18:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:13:35 --> Input Class Initialized
INFO - 2023-08-10 18:13:35 --> Language Class Initialized
INFO - 2023-08-10 18:13:35 --> Loader Class Initialized
INFO - 2023-08-10 18:13:35 --> Helper loaded: url_helper
INFO - 2023-08-10 18:13:35 --> Helper loaded: file_helper
INFO - 2023-08-10 18:13:35 --> Database Driver Class Initialized
INFO - 2023-08-10 18:13:35 --> Email Class Initialized
DEBUG - 2023-08-10 18:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:13:35 --> Controller Class Initialized
INFO - 2023-08-10 18:13:35 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:13:35 --> Helper loaded: form_helper
INFO - 2023-08-10 18:13:35 --> Form Validation Class Initialized
INFO - 2023-08-10 18:13:35 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:13:35 --> Final output sent to browser
DEBUG - 2023-08-10 18:13:35 --> Total execution time: 0.0881
INFO - 2023-08-10 18:13:41 --> Config Class Initialized
INFO - 2023-08-10 18:13:41 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:13:41 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:13:41 --> Utf8 Class Initialized
INFO - 2023-08-10 18:13:41 --> URI Class Initialized
INFO - 2023-08-10 18:13:41 --> Router Class Initialized
INFO - 2023-08-10 18:13:41 --> Output Class Initialized
INFO - 2023-08-10 18:13:41 --> Security Class Initialized
DEBUG - 2023-08-10 18:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:13:41 --> Input Class Initialized
INFO - 2023-08-10 18:13:41 --> Language Class Initialized
INFO - 2023-08-10 18:13:41 --> Loader Class Initialized
INFO - 2023-08-10 18:13:41 --> Helper loaded: url_helper
INFO - 2023-08-10 18:13:41 --> Helper loaded: file_helper
INFO - 2023-08-10 18:13:41 --> Database Driver Class Initialized
INFO - 2023-08-10 18:13:41 --> Email Class Initialized
DEBUG - 2023-08-10 18:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:13:41 --> Controller Class Initialized
INFO - 2023-08-10 18:13:41 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:13:41 --> Helper loaded: form_helper
INFO - 2023-08-10 18:13:41 --> Form Validation Class Initialized
INFO - 2023-08-10 18:13:41 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:13:41 --> Final output sent to browser
DEBUG - 2023-08-10 18:13:41 --> Total execution time: 0.0551
INFO - 2023-08-10 18:13:41 --> Config Class Initialized
INFO - 2023-08-10 18:13:41 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:13:41 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:13:41 --> Utf8 Class Initialized
INFO - 2023-08-10 18:13:41 --> URI Class Initialized
INFO - 2023-08-10 18:13:41 --> Router Class Initialized
INFO - 2023-08-10 18:13:41 --> Output Class Initialized
INFO - 2023-08-10 18:13:41 --> Security Class Initialized
DEBUG - 2023-08-10 18:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:13:41 --> Input Class Initialized
INFO - 2023-08-10 18:13:41 --> Language Class Initialized
INFO - 2023-08-10 18:13:41 --> Loader Class Initialized
INFO - 2023-08-10 18:13:41 --> Helper loaded: url_helper
INFO - 2023-08-10 18:13:41 --> Helper loaded: file_helper
INFO - 2023-08-10 18:13:41 --> Database Driver Class Initialized
INFO - 2023-08-10 18:13:41 --> Email Class Initialized
DEBUG - 2023-08-10 18:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:13:41 --> Controller Class Initialized
INFO - 2023-08-10 18:13:41 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:13:41 --> Helper loaded: form_helper
INFO - 2023-08-10 18:13:41 --> Form Validation Class Initialized
ERROR - 2023-08-10 18:13:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-10 18:13:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-10 18:13:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 59
ERROR - 2023-08-10 18:13:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-10 18:13:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 61
ERROR - 2023-08-10 18:13:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 74
INFO - 2023-08-10 18:13:41 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-10 18:13:41 --> Final output sent to browser
DEBUG - 2023-08-10 18:13:41 --> Total execution time: 0.0525
INFO - 2023-08-10 18:13:48 --> Config Class Initialized
INFO - 2023-08-10 18:13:48 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:13:48 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:13:48 --> Utf8 Class Initialized
INFO - 2023-08-10 18:13:48 --> URI Class Initialized
INFO - 2023-08-10 18:13:48 --> Router Class Initialized
INFO - 2023-08-10 18:13:48 --> Output Class Initialized
INFO - 2023-08-10 18:13:48 --> Security Class Initialized
DEBUG - 2023-08-10 18:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:13:48 --> Input Class Initialized
INFO - 2023-08-10 18:13:48 --> Language Class Initialized
INFO - 2023-08-10 18:13:48 --> Loader Class Initialized
INFO - 2023-08-10 18:13:48 --> Helper loaded: url_helper
INFO - 2023-08-10 18:13:48 --> Helper loaded: file_helper
INFO - 2023-08-10 18:13:48 --> Database Driver Class Initialized
INFO - 2023-08-10 18:13:48 --> Email Class Initialized
DEBUG - 2023-08-10 18:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:13:48 --> Controller Class Initialized
INFO - 2023-08-10 18:13:48 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:13:48 --> Helper loaded: form_helper
INFO - 2023-08-10 18:13:48 --> Form Validation Class Initialized
INFO - 2023-08-10 18:13:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 18:13:48 --> Config Class Initialized
INFO - 2023-08-10 18:13:48 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:13:48 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:13:48 --> Utf8 Class Initialized
INFO - 2023-08-10 18:13:48 --> URI Class Initialized
INFO - 2023-08-10 18:13:48 --> Router Class Initialized
INFO - 2023-08-10 18:13:48 --> Output Class Initialized
INFO - 2023-08-10 18:13:48 --> Security Class Initialized
DEBUG - 2023-08-10 18:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:13:48 --> Input Class Initialized
INFO - 2023-08-10 18:13:48 --> Language Class Initialized
INFO - 2023-08-10 18:13:48 --> Loader Class Initialized
INFO - 2023-08-10 18:13:48 --> Helper loaded: url_helper
INFO - 2023-08-10 18:13:48 --> Helper loaded: file_helper
INFO - 2023-08-10 18:13:48 --> Database Driver Class Initialized
INFO - 2023-08-10 18:13:48 --> Email Class Initialized
DEBUG - 2023-08-10 18:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:13:48 --> Controller Class Initialized
INFO - 2023-08-10 18:13:48 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:13:48 --> Helper loaded: form_helper
INFO - 2023-08-10 18:13:48 --> Form Validation Class Initialized
INFO - 2023-08-10 18:13:48 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:13:48 --> Final output sent to browser
DEBUG - 2023-08-10 18:13:48 --> Total execution time: 0.0500
INFO - 2023-08-10 18:14:25 --> Config Class Initialized
INFO - 2023-08-10 18:14:25 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:14:25 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:14:25 --> Utf8 Class Initialized
INFO - 2023-08-10 18:14:25 --> URI Class Initialized
INFO - 2023-08-10 18:14:25 --> Router Class Initialized
INFO - 2023-08-10 18:14:25 --> Output Class Initialized
INFO - 2023-08-10 18:14:25 --> Security Class Initialized
DEBUG - 2023-08-10 18:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:14:25 --> Input Class Initialized
INFO - 2023-08-10 18:14:25 --> Language Class Initialized
INFO - 2023-08-10 18:14:25 --> Loader Class Initialized
INFO - 2023-08-10 18:14:25 --> Helper loaded: url_helper
INFO - 2023-08-10 18:14:25 --> Helper loaded: file_helper
INFO - 2023-08-10 18:14:25 --> Database Driver Class Initialized
INFO - 2023-08-10 18:14:25 --> Email Class Initialized
DEBUG - 2023-08-10 18:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:14:25 --> Controller Class Initialized
INFO - 2023-08-10 18:14:25 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:14:25 --> Helper loaded: form_helper
INFO - 2023-08-10 18:14:25 --> Form Validation Class Initialized
INFO - 2023-08-10 18:14:25 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:14:25 --> Final output sent to browser
DEBUG - 2023-08-10 18:14:25 --> Total execution time: 0.1420
INFO - 2023-08-10 18:14:34 --> Config Class Initialized
INFO - 2023-08-10 18:14:34 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:14:34 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:14:34 --> Utf8 Class Initialized
INFO - 2023-08-10 18:14:34 --> URI Class Initialized
INFO - 2023-08-10 18:14:34 --> Router Class Initialized
INFO - 2023-08-10 18:14:34 --> Output Class Initialized
INFO - 2023-08-10 18:14:34 --> Security Class Initialized
DEBUG - 2023-08-10 18:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:14:34 --> Input Class Initialized
INFO - 2023-08-10 18:14:34 --> Language Class Initialized
INFO - 2023-08-10 18:14:34 --> Loader Class Initialized
INFO - 2023-08-10 18:14:34 --> Helper loaded: url_helper
INFO - 2023-08-10 18:14:34 --> Helper loaded: file_helper
INFO - 2023-08-10 18:14:34 --> Database Driver Class Initialized
INFO - 2023-08-10 18:14:34 --> Email Class Initialized
DEBUG - 2023-08-10 18:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:14:34 --> Controller Class Initialized
INFO - 2023-08-10 18:14:34 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:14:34 --> Helper loaded: form_helper
INFO - 2023-08-10 18:14:34 --> Form Validation Class Initialized
INFO - 2023-08-10 18:14:34 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-10 18:14:34 --> Final output sent to browser
DEBUG - 2023-08-10 18:14:34 --> Total execution time: 0.1011
INFO - 2023-08-10 18:14:40 --> Config Class Initialized
INFO - 2023-08-10 18:14:40 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:14:40 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:14:40 --> Utf8 Class Initialized
INFO - 2023-08-10 18:14:40 --> URI Class Initialized
INFO - 2023-08-10 18:14:40 --> Router Class Initialized
INFO - 2023-08-10 18:14:40 --> Output Class Initialized
INFO - 2023-08-10 18:14:40 --> Security Class Initialized
DEBUG - 2023-08-10 18:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:14:40 --> Input Class Initialized
INFO - 2023-08-10 18:14:40 --> Language Class Initialized
INFO - 2023-08-10 18:14:40 --> Loader Class Initialized
INFO - 2023-08-10 18:14:40 --> Helper loaded: url_helper
INFO - 2023-08-10 18:14:40 --> Helper loaded: file_helper
INFO - 2023-08-10 18:14:40 --> Database Driver Class Initialized
INFO - 2023-08-10 18:14:40 --> Email Class Initialized
DEBUG - 2023-08-10 18:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:14:40 --> Controller Class Initialized
INFO - 2023-08-10 18:14:40 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:14:40 --> Helper loaded: form_helper
INFO - 2023-08-10 18:14:40 --> Form Validation Class Initialized
INFO - 2023-08-10 18:14:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 18:14:40 --> Config Class Initialized
INFO - 2023-08-10 18:14:40 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:14:40 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:14:40 --> Utf8 Class Initialized
INFO - 2023-08-10 18:14:40 --> URI Class Initialized
INFO - 2023-08-10 18:14:40 --> Router Class Initialized
INFO - 2023-08-10 18:14:40 --> Output Class Initialized
INFO - 2023-08-10 18:14:40 --> Security Class Initialized
DEBUG - 2023-08-10 18:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:14:40 --> Input Class Initialized
INFO - 2023-08-10 18:14:40 --> Language Class Initialized
INFO - 2023-08-10 18:14:40 --> Loader Class Initialized
INFO - 2023-08-10 18:14:40 --> Helper loaded: url_helper
INFO - 2023-08-10 18:14:40 --> Helper loaded: file_helper
INFO - 2023-08-10 18:14:40 --> Database Driver Class Initialized
INFO - 2023-08-10 18:14:40 --> Email Class Initialized
DEBUG - 2023-08-10 18:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:14:40 --> Controller Class Initialized
INFO - 2023-08-10 18:14:40 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:14:40 --> Helper loaded: form_helper
INFO - 2023-08-10 18:14:40 --> Form Validation Class Initialized
INFO - 2023-08-10 18:14:40 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:14:40 --> Final output sent to browser
DEBUG - 2023-08-10 18:14:40 --> Total execution time: 0.0494
INFO - 2023-08-10 18:18:54 --> Config Class Initialized
INFO - 2023-08-10 18:18:54 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:18:54 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:18:54 --> Utf8 Class Initialized
INFO - 2023-08-10 18:18:54 --> URI Class Initialized
INFO - 2023-08-10 18:18:54 --> Router Class Initialized
INFO - 2023-08-10 18:18:54 --> Output Class Initialized
INFO - 2023-08-10 18:18:54 --> Security Class Initialized
DEBUG - 2023-08-10 18:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:18:55 --> Input Class Initialized
INFO - 2023-08-10 18:18:55 --> Language Class Initialized
INFO - 2023-08-10 18:18:55 --> Loader Class Initialized
INFO - 2023-08-10 18:18:55 --> Helper loaded: url_helper
INFO - 2023-08-10 18:18:55 --> Helper loaded: file_helper
INFO - 2023-08-10 18:18:55 --> Database Driver Class Initialized
INFO - 2023-08-10 18:18:55 --> Email Class Initialized
DEBUG - 2023-08-10 18:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:18:55 --> Controller Class Initialized
INFO - 2023-08-10 18:18:55 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:18:55 --> Helper loaded: form_helper
INFO - 2023-08-10 18:18:55 --> Form Validation Class Initialized
INFO - 2023-08-10 18:18:55 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:18:55 --> Final output sent to browser
DEBUG - 2023-08-10 18:18:55 --> Total execution time: 0.4082
INFO - 2023-08-10 18:19:00 --> Config Class Initialized
INFO - 2023-08-10 18:19:00 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:19:00 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:19:00 --> Utf8 Class Initialized
INFO - 2023-08-10 18:19:00 --> URI Class Initialized
INFO - 2023-08-10 18:19:00 --> Router Class Initialized
INFO - 2023-08-10 18:19:00 --> Output Class Initialized
INFO - 2023-08-10 18:19:00 --> Security Class Initialized
DEBUG - 2023-08-10 18:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:19:00 --> Input Class Initialized
INFO - 2023-08-10 18:19:00 --> Language Class Initialized
INFO - 2023-08-10 18:19:00 --> Loader Class Initialized
INFO - 2023-08-10 18:19:00 --> Helper loaded: url_helper
INFO - 2023-08-10 18:19:00 --> Helper loaded: file_helper
INFO - 2023-08-10 18:19:00 --> Database Driver Class Initialized
INFO - 2023-08-10 18:19:00 --> Email Class Initialized
DEBUG - 2023-08-10 18:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:19:00 --> Controller Class Initialized
INFO - 2023-08-10 18:19:00 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:19:00 --> Helper loaded: form_helper
INFO - 2023-08-10 18:19:00 --> Form Validation Class Initialized
INFO - 2023-08-10 18:19:00 --> Config Class Initialized
INFO - 2023-08-10 18:19:00 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:19:00 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:19:00 --> Utf8 Class Initialized
INFO - 2023-08-10 18:19:00 --> URI Class Initialized
INFO - 2023-08-10 18:19:00 --> Router Class Initialized
INFO - 2023-08-10 18:19:00 --> Output Class Initialized
INFO - 2023-08-10 18:19:00 --> Security Class Initialized
DEBUG - 2023-08-10 18:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:19:00 --> Input Class Initialized
INFO - 2023-08-10 18:19:00 --> Language Class Initialized
INFO - 2023-08-10 18:19:00 --> Loader Class Initialized
INFO - 2023-08-10 18:19:00 --> Helper loaded: url_helper
INFO - 2023-08-10 18:19:00 --> Helper loaded: file_helper
INFO - 2023-08-10 18:19:00 --> Database Driver Class Initialized
INFO - 2023-08-10 18:19:00 --> Email Class Initialized
DEBUG - 2023-08-10 18:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:19:00 --> Controller Class Initialized
INFO - 2023-08-10 18:19:00 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:19:00 --> Helper loaded: form_helper
INFO - 2023-08-10 18:19:00 --> Form Validation Class Initialized
INFO - 2023-08-10 18:19:00 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:19:00 --> Final output sent to browser
DEBUG - 2023-08-10 18:19:00 --> Total execution time: 0.0478
INFO - 2023-08-10 18:19:03 --> Config Class Initialized
INFO - 2023-08-10 18:19:03 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:19:03 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:19:03 --> Utf8 Class Initialized
INFO - 2023-08-10 18:19:03 --> URI Class Initialized
INFO - 2023-08-10 18:19:03 --> Router Class Initialized
INFO - 2023-08-10 18:19:03 --> Output Class Initialized
INFO - 2023-08-10 18:19:03 --> Security Class Initialized
DEBUG - 2023-08-10 18:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:19:03 --> Input Class Initialized
INFO - 2023-08-10 18:19:03 --> Language Class Initialized
INFO - 2023-08-10 18:19:03 --> Loader Class Initialized
INFO - 2023-08-10 18:19:03 --> Helper loaded: url_helper
INFO - 2023-08-10 18:19:03 --> Helper loaded: file_helper
INFO - 2023-08-10 18:19:03 --> Database Driver Class Initialized
INFO - 2023-08-10 18:19:03 --> Email Class Initialized
DEBUG - 2023-08-10 18:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:19:03 --> Controller Class Initialized
INFO - 2023-08-10 18:19:03 --> Model "Services_model" initialized
INFO - 2023-08-10 18:19:03 --> Helper loaded: form_helper
INFO - 2023-08-10 18:19:03 --> Form Validation Class Initialized
INFO - 2023-08-10 18:19:03 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-10 18:19:03 --> Final output sent to browser
DEBUG - 2023-08-10 18:19:03 --> Total execution time: 0.0536
INFO - 2023-08-10 18:19:03 --> Config Class Initialized
INFO - 2023-08-10 18:19:03 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:19:03 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:19:03 --> Utf8 Class Initialized
INFO - 2023-08-10 18:19:03 --> URI Class Initialized
INFO - 2023-08-10 18:19:03 --> Router Class Initialized
INFO - 2023-08-10 18:19:03 --> Output Class Initialized
INFO - 2023-08-10 18:19:03 --> Security Class Initialized
DEBUG - 2023-08-10 18:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:19:03 --> Input Class Initialized
INFO - 2023-08-10 18:19:03 --> Language Class Initialized
ERROR - 2023-08-10 18:19:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-10 18:19:05 --> Config Class Initialized
INFO - 2023-08-10 18:19:05 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:19:05 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:19:05 --> Utf8 Class Initialized
INFO - 2023-08-10 18:19:05 --> URI Class Initialized
INFO - 2023-08-10 18:19:05 --> Router Class Initialized
INFO - 2023-08-10 18:19:05 --> Output Class Initialized
INFO - 2023-08-10 18:19:05 --> Security Class Initialized
DEBUG - 2023-08-10 18:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:19:05 --> Input Class Initialized
INFO - 2023-08-10 18:19:05 --> Language Class Initialized
INFO - 2023-08-10 18:19:05 --> Loader Class Initialized
INFO - 2023-08-10 18:19:05 --> Helper loaded: url_helper
INFO - 2023-08-10 18:19:05 --> Helper loaded: file_helper
INFO - 2023-08-10 18:19:05 --> Database Driver Class Initialized
INFO - 2023-08-10 18:19:05 --> Email Class Initialized
DEBUG - 2023-08-10 18:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:19:05 --> Controller Class Initialized
INFO - 2023-08-10 18:19:05 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:19:05 --> Helper loaded: form_helper
INFO - 2023-08-10 18:19:05 --> Form Validation Class Initialized
INFO - 2023-08-10 18:19:05 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:19:05 --> Final output sent to browser
DEBUG - 2023-08-10 18:19:05 --> Total execution time: 0.0474
INFO - 2023-08-10 18:19:10 --> Config Class Initialized
INFO - 2023-08-10 18:19:10 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:19:10 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:19:10 --> Utf8 Class Initialized
INFO - 2023-08-10 18:19:10 --> URI Class Initialized
INFO - 2023-08-10 18:19:10 --> Router Class Initialized
INFO - 2023-08-10 18:19:10 --> Output Class Initialized
INFO - 2023-08-10 18:19:10 --> Security Class Initialized
DEBUG - 2023-08-10 18:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:19:10 --> Input Class Initialized
INFO - 2023-08-10 18:19:10 --> Language Class Initialized
INFO - 2023-08-10 18:19:10 --> Loader Class Initialized
INFO - 2023-08-10 18:19:10 --> Helper loaded: url_helper
INFO - 2023-08-10 18:19:10 --> Helper loaded: file_helper
INFO - 2023-08-10 18:19:10 --> Database Driver Class Initialized
INFO - 2023-08-10 18:19:10 --> Email Class Initialized
DEBUG - 2023-08-10 18:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:19:10 --> Controller Class Initialized
INFO - 2023-08-10 18:19:10 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:19:10 --> Helper loaded: form_helper
INFO - 2023-08-10 18:19:10 --> Form Validation Class Initialized
INFO - 2023-08-10 18:19:10 --> Config Class Initialized
INFO - 2023-08-10 18:19:10 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:19:10 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:19:10 --> Utf8 Class Initialized
INFO - 2023-08-10 18:19:10 --> URI Class Initialized
INFO - 2023-08-10 18:19:10 --> Router Class Initialized
INFO - 2023-08-10 18:19:10 --> Output Class Initialized
INFO - 2023-08-10 18:19:10 --> Security Class Initialized
DEBUG - 2023-08-10 18:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:19:10 --> Input Class Initialized
INFO - 2023-08-10 18:19:10 --> Language Class Initialized
INFO - 2023-08-10 18:19:10 --> Loader Class Initialized
INFO - 2023-08-10 18:19:10 --> Helper loaded: url_helper
INFO - 2023-08-10 18:19:10 --> Helper loaded: file_helper
INFO - 2023-08-10 18:19:10 --> Database Driver Class Initialized
INFO - 2023-08-10 18:19:10 --> Email Class Initialized
DEBUG - 2023-08-10 18:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:19:10 --> Controller Class Initialized
INFO - 2023-08-10 18:19:10 --> Model "Faq_model" initialized
INFO - 2023-08-10 18:19:10 --> Helper loaded: form_helper
INFO - 2023-08-10 18:19:10 --> Form Validation Class Initialized
INFO - 2023-08-10 18:19:10 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-10 18:19:10 --> Final output sent to browser
DEBUG - 2023-08-10 18:19:10 --> Total execution time: 0.0557
INFO - 2023-08-10 18:19:19 --> Config Class Initialized
INFO - 2023-08-10 18:19:19 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:19:19 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:19:19 --> Utf8 Class Initialized
INFO - 2023-08-10 18:19:19 --> URI Class Initialized
INFO - 2023-08-10 18:19:19 --> Router Class Initialized
INFO - 2023-08-10 18:19:19 --> Output Class Initialized
INFO - 2023-08-10 18:19:19 --> Security Class Initialized
DEBUG - 2023-08-10 18:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:19:19 --> Input Class Initialized
INFO - 2023-08-10 18:19:19 --> Language Class Initialized
INFO - 2023-08-10 18:19:19 --> Loader Class Initialized
INFO - 2023-08-10 18:19:19 --> Helper loaded: url_helper
INFO - 2023-08-10 18:19:19 --> Helper loaded: file_helper
INFO - 2023-08-10 18:19:19 --> Database Driver Class Initialized
INFO - 2023-08-10 18:19:19 --> Email Class Initialized
DEBUG - 2023-08-10 18:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:19:19 --> Controller Class Initialized
INFO - 2023-08-10 18:19:19 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:19:19 --> Helper loaded: form_helper
INFO - 2023-08-10 18:19:19 --> Form Validation Class Initialized
INFO - 2023-08-10 18:19:19 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-10 18:19:19 --> Final output sent to browser
DEBUG - 2023-08-10 18:19:19 --> Total execution time: 0.0860
INFO - 2023-08-10 18:23:56 --> Config Class Initialized
INFO - 2023-08-10 18:23:56 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:23:56 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:23:56 --> Utf8 Class Initialized
INFO - 2023-08-10 18:23:56 --> URI Class Initialized
INFO - 2023-08-10 18:23:56 --> Router Class Initialized
INFO - 2023-08-10 18:23:56 --> Output Class Initialized
INFO - 2023-08-10 18:23:56 --> Security Class Initialized
DEBUG - 2023-08-10 18:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:23:56 --> Input Class Initialized
INFO - 2023-08-10 18:23:56 --> Language Class Initialized
INFO - 2023-08-10 18:23:56 --> Loader Class Initialized
INFO - 2023-08-10 18:23:56 --> Helper loaded: url_helper
INFO - 2023-08-10 18:23:56 --> Helper loaded: file_helper
INFO - 2023-08-10 18:23:56 --> Database Driver Class Initialized
INFO - 2023-08-10 18:23:56 --> Email Class Initialized
DEBUG - 2023-08-10 18:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:23:56 --> Controller Class Initialized
INFO - 2023-08-10 18:23:56 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:23:56 --> Helper loaded: form_helper
INFO - 2023-08-10 18:23:56 --> Form Validation Class Initialized
INFO - 2023-08-10 18:23:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-10 18:23:56 --> Final output sent to browser
DEBUG - 2023-08-10 18:23:56 --> Total execution time: 0.0437
INFO - 2023-08-10 18:24:43 --> Config Class Initialized
INFO - 2023-08-10 18:24:43 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:24:43 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:24:43 --> Utf8 Class Initialized
INFO - 2023-08-10 18:24:43 --> URI Class Initialized
INFO - 2023-08-10 18:24:43 --> Router Class Initialized
INFO - 2023-08-10 18:24:43 --> Output Class Initialized
INFO - 2023-08-10 18:24:43 --> Security Class Initialized
DEBUG - 2023-08-10 18:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:24:43 --> Input Class Initialized
INFO - 2023-08-10 18:24:43 --> Language Class Initialized
ERROR - 2023-08-10 18:24:43 --> 404 Page Not Found: admin/Key_highlights/1
INFO - 2023-08-10 18:26:52 --> Config Class Initialized
INFO - 2023-08-10 18:26:52 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:26:52 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:26:52 --> Utf8 Class Initialized
INFO - 2023-08-10 18:26:52 --> URI Class Initialized
INFO - 2023-08-10 18:26:52 --> Router Class Initialized
INFO - 2023-08-10 18:26:52 --> Output Class Initialized
INFO - 2023-08-10 18:26:52 --> Security Class Initialized
DEBUG - 2023-08-10 18:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:26:52 --> Input Class Initialized
INFO - 2023-08-10 18:26:52 --> Language Class Initialized
INFO - 2023-08-10 18:26:52 --> Loader Class Initialized
INFO - 2023-08-10 18:26:52 --> Helper loaded: url_helper
INFO - 2023-08-10 18:26:52 --> Helper loaded: file_helper
INFO - 2023-08-10 18:26:52 --> Database Driver Class Initialized
INFO - 2023-08-10 18:26:52 --> Email Class Initialized
DEBUG - 2023-08-10 18:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:26:52 --> Controller Class Initialized
INFO - 2023-08-10 18:26:52 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:26:52 --> Helper loaded: form_helper
INFO - 2023-08-10 18:26:52 --> Form Validation Class Initialized
INFO - 2023-08-10 18:26:52 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-10 18:26:52 --> Final output sent to browser
DEBUG - 2023-08-10 18:26:52 --> Total execution time: 0.0887
INFO - 2023-08-10 18:31:01 --> Config Class Initialized
INFO - 2023-08-10 18:31:01 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:31:01 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:31:01 --> Utf8 Class Initialized
INFO - 2023-08-10 18:31:01 --> URI Class Initialized
INFO - 2023-08-10 18:31:01 --> Router Class Initialized
INFO - 2023-08-10 18:31:01 --> Output Class Initialized
INFO - 2023-08-10 18:31:01 --> Security Class Initialized
DEBUG - 2023-08-10 18:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:31:01 --> Input Class Initialized
INFO - 2023-08-10 18:31:01 --> Language Class Initialized
INFO - 2023-08-10 18:31:01 --> Loader Class Initialized
INFO - 2023-08-10 18:31:01 --> Helper loaded: url_helper
INFO - 2023-08-10 18:31:01 --> Helper loaded: file_helper
INFO - 2023-08-10 18:31:01 --> Database Driver Class Initialized
INFO - 2023-08-10 18:31:01 --> Email Class Initialized
DEBUG - 2023-08-10 18:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:31:01 --> Controller Class Initialized
INFO - 2023-08-10 18:31:01 --> Model "Training_model" initialized
INFO - 2023-08-10 18:31:01 --> Helper loaded: form_helper
INFO - 2023-08-10 18:31:01 --> Form Validation Class Initialized
INFO - 2023-08-10 18:31:01 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-10 18:31:01 --> Final output sent to browser
DEBUG - 2023-08-10 18:31:01 --> Total execution time: 0.1641
INFO - 2023-08-10 18:31:04 --> Config Class Initialized
INFO - 2023-08-10 18:31:04 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:31:04 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:31:04 --> Utf8 Class Initialized
INFO - 2023-08-10 18:31:04 --> URI Class Initialized
INFO - 2023-08-10 18:31:04 --> Router Class Initialized
INFO - 2023-08-10 18:31:04 --> Output Class Initialized
INFO - 2023-08-10 18:31:04 --> Security Class Initialized
DEBUG - 2023-08-10 18:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:31:04 --> Input Class Initialized
INFO - 2023-08-10 18:31:04 --> Language Class Initialized
INFO - 2023-08-10 18:31:04 --> Loader Class Initialized
INFO - 2023-08-10 18:31:04 --> Helper loaded: url_helper
INFO - 2023-08-10 18:31:04 --> Helper loaded: file_helper
INFO - 2023-08-10 18:31:04 --> Database Driver Class Initialized
INFO - 2023-08-10 18:31:04 --> Email Class Initialized
DEBUG - 2023-08-10 18:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:31:04 --> Controller Class Initialized
INFO - 2023-08-10 18:31:04 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:31:04 --> Helper loaded: form_helper
INFO - 2023-08-10 18:31:04 --> Form Validation Class Initialized
INFO - 2023-08-10 18:31:04 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-10 18:31:04 --> Final output sent to browser
DEBUG - 2023-08-10 18:31:05 --> Total execution time: 0.1703
INFO - 2023-08-10 18:31:05 --> Config Class Initialized
INFO - 2023-08-10 18:31:05 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:31:05 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:31:05 --> Utf8 Class Initialized
INFO - 2023-08-10 18:31:05 --> URI Class Initialized
INFO - 2023-08-10 18:31:05 --> Router Class Initialized
INFO - 2023-08-10 18:31:05 --> Output Class Initialized
INFO - 2023-08-10 18:31:05 --> Security Class Initialized
DEBUG - 2023-08-10 18:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:31:05 --> Input Class Initialized
INFO - 2023-08-10 18:31:05 --> Language Class Initialized
ERROR - 2023-08-10 18:31:05 --> 404 Page Not Found: admin/Key_highlights/images
INFO - 2023-08-10 18:31:07 --> Config Class Initialized
INFO - 2023-08-10 18:31:07 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:31:07 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:31:07 --> Utf8 Class Initialized
INFO - 2023-08-10 18:31:07 --> URI Class Initialized
INFO - 2023-08-10 18:31:07 --> Router Class Initialized
INFO - 2023-08-10 18:31:07 --> Output Class Initialized
INFO - 2023-08-10 18:31:07 --> Security Class Initialized
DEBUG - 2023-08-10 18:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:31:07 --> Input Class Initialized
INFO - 2023-08-10 18:31:07 --> Language Class Initialized
INFO - 2023-08-10 18:31:07 --> Loader Class Initialized
INFO - 2023-08-10 18:31:07 --> Helper loaded: url_helper
INFO - 2023-08-10 18:31:07 --> Helper loaded: file_helper
INFO - 2023-08-10 18:31:07 --> Database Driver Class Initialized
INFO - 2023-08-10 18:31:07 --> Email Class Initialized
DEBUG - 2023-08-10 18:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:31:07 --> Controller Class Initialized
INFO - 2023-08-10 18:31:07 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:31:07 --> Helper loaded: form_helper
INFO - 2023-08-10 18:31:07 --> Form Validation Class Initialized
INFO - 2023-08-10 18:31:07 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_create.php
INFO - 2023-08-10 18:31:07 --> Final output sent to browser
DEBUG - 2023-08-10 18:31:07 --> Total execution time: 0.0434
INFO - 2023-08-10 18:31:08 --> Config Class Initialized
INFO - 2023-08-10 18:31:08 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:31:08 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:31:08 --> Utf8 Class Initialized
INFO - 2023-08-10 18:31:08 --> URI Class Initialized
INFO - 2023-08-10 18:31:08 --> Router Class Initialized
INFO - 2023-08-10 18:31:08 --> Output Class Initialized
INFO - 2023-08-10 18:31:08 --> Security Class Initialized
DEBUG - 2023-08-10 18:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:31:08 --> Input Class Initialized
INFO - 2023-08-10 18:31:08 --> Language Class Initialized
ERROR - 2023-08-10 18:31:08 --> 404 Page Not Found: admin/Key_highlights/add
INFO - 2023-08-10 18:33:39 --> Config Class Initialized
INFO - 2023-08-10 18:33:39 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:33:39 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:33:39 --> Utf8 Class Initialized
INFO - 2023-08-10 18:33:39 --> URI Class Initialized
INFO - 2023-08-10 18:33:39 --> Router Class Initialized
INFO - 2023-08-10 18:33:39 --> Output Class Initialized
INFO - 2023-08-10 18:33:39 --> Security Class Initialized
DEBUG - 2023-08-10 18:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:33:39 --> Input Class Initialized
INFO - 2023-08-10 18:33:39 --> Language Class Initialized
INFO - 2023-08-10 18:33:39 --> Loader Class Initialized
INFO - 2023-08-10 18:33:39 --> Helper loaded: url_helper
INFO - 2023-08-10 18:33:39 --> Helper loaded: file_helper
INFO - 2023-08-10 18:33:39 --> Database Driver Class Initialized
INFO - 2023-08-10 18:33:39 --> Email Class Initialized
DEBUG - 2023-08-10 18:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:33:39 --> Controller Class Initialized
INFO - 2023-08-10 18:33:39 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:33:39 --> Helper loaded: form_helper
INFO - 2023-08-10 18:33:39 --> Form Validation Class Initialized
INFO - 2023-08-10 18:33:39 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-10 18:33:39 --> Final output sent to browser
DEBUG - 2023-08-10 18:33:39 --> Total execution time: 0.1057
INFO - 2023-08-10 18:33:42 --> Config Class Initialized
INFO - 2023-08-10 18:33:42 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:33:42 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:33:42 --> Utf8 Class Initialized
INFO - 2023-08-10 18:33:42 --> URI Class Initialized
INFO - 2023-08-10 18:33:42 --> Router Class Initialized
INFO - 2023-08-10 18:33:43 --> Output Class Initialized
INFO - 2023-08-10 18:33:43 --> Security Class Initialized
DEBUG - 2023-08-10 18:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:33:43 --> Input Class Initialized
INFO - 2023-08-10 18:33:43 --> Language Class Initialized
INFO - 2023-08-10 18:33:43 --> Loader Class Initialized
INFO - 2023-08-10 18:33:43 --> Helper loaded: url_helper
INFO - 2023-08-10 18:33:43 --> Helper loaded: file_helper
INFO - 2023-08-10 18:33:43 --> Database Driver Class Initialized
INFO - 2023-08-10 18:33:43 --> Email Class Initialized
DEBUG - 2023-08-10 18:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:33:43 --> Controller Class Initialized
INFO - 2023-08-10 18:33:43 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:33:43 --> Helper loaded: form_helper
INFO - 2023-08-10 18:33:43 --> Form Validation Class Initialized
INFO - 2023-08-10 18:33:43 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-10 18:33:43 --> Final output sent to browser
DEBUG - 2023-08-10 18:33:43 --> Total execution time: 0.0450
INFO - 2023-08-10 18:33:45 --> Config Class Initialized
INFO - 2023-08-10 18:33:45 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:33:45 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:33:45 --> Utf8 Class Initialized
INFO - 2023-08-10 18:33:45 --> URI Class Initialized
INFO - 2023-08-10 18:33:45 --> Router Class Initialized
INFO - 2023-08-10 18:33:45 --> Output Class Initialized
INFO - 2023-08-10 18:33:45 --> Security Class Initialized
DEBUG - 2023-08-10 18:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:33:45 --> Input Class Initialized
INFO - 2023-08-10 18:33:45 --> Language Class Initialized
INFO - 2023-08-10 18:33:45 --> Loader Class Initialized
INFO - 2023-08-10 18:33:45 --> Helper loaded: url_helper
INFO - 2023-08-10 18:33:45 --> Helper loaded: file_helper
INFO - 2023-08-10 18:33:45 --> Database Driver Class Initialized
INFO - 2023-08-10 18:33:45 --> Email Class Initialized
DEBUG - 2023-08-10 18:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:33:45 --> Controller Class Initialized
INFO - 2023-08-10 18:33:45 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:33:45 --> Helper loaded: form_helper
INFO - 2023-08-10 18:33:45 --> Form Validation Class Initialized
INFO - 2023-08-10 18:33:45 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_create.php
INFO - 2023-08-10 18:33:45 --> Final output sent to browser
DEBUG - 2023-08-10 18:33:45 --> Total execution time: 0.1412
INFO - 2023-08-10 18:35:52 --> Config Class Initialized
INFO - 2023-08-10 18:35:52 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:35:52 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:35:52 --> Utf8 Class Initialized
INFO - 2023-08-10 18:35:52 --> URI Class Initialized
INFO - 2023-08-10 18:35:52 --> Router Class Initialized
INFO - 2023-08-10 18:35:52 --> Output Class Initialized
INFO - 2023-08-10 18:35:52 --> Security Class Initialized
DEBUG - 2023-08-10 18:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:35:52 --> Input Class Initialized
INFO - 2023-08-10 18:35:52 --> Language Class Initialized
ERROR - 2023-08-10 18:35:53 --> Severity: error --> Exception: syntax error, unexpected variable "$training_id", expecting ")" C:\xampp\htdocs\DW\application\controllers\Admin\KeyHighlights.php 29
INFO - 2023-08-10 18:35:54 --> Config Class Initialized
INFO - 2023-08-10 18:35:54 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:35:54 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:35:54 --> Utf8 Class Initialized
INFO - 2023-08-10 18:35:54 --> URI Class Initialized
INFO - 2023-08-10 18:35:54 --> Router Class Initialized
INFO - 2023-08-10 18:35:54 --> Output Class Initialized
INFO - 2023-08-10 18:35:54 --> Security Class Initialized
DEBUG - 2023-08-10 18:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:35:54 --> Input Class Initialized
INFO - 2023-08-10 18:35:54 --> Language Class Initialized
ERROR - 2023-08-10 18:35:54 --> Severity: error --> Exception: syntax error, unexpected variable "$training_id", expecting ")" C:\xampp\htdocs\DW\application\controllers\Admin\KeyHighlights.php 29
INFO - 2023-08-10 18:36:06 --> Config Class Initialized
INFO - 2023-08-10 18:36:06 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:36:06 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:36:06 --> Utf8 Class Initialized
INFO - 2023-08-10 18:36:06 --> URI Class Initialized
INFO - 2023-08-10 18:36:06 --> Router Class Initialized
INFO - 2023-08-10 18:36:06 --> Output Class Initialized
INFO - 2023-08-10 18:36:06 --> Security Class Initialized
DEBUG - 2023-08-10 18:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:36:06 --> Input Class Initialized
INFO - 2023-08-10 18:36:06 --> Language Class Initialized
INFO - 2023-08-10 18:36:06 --> Loader Class Initialized
INFO - 2023-08-10 18:36:06 --> Helper loaded: url_helper
INFO - 2023-08-10 18:36:06 --> Helper loaded: file_helper
INFO - 2023-08-10 18:36:06 --> Database Driver Class Initialized
INFO - 2023-08-10 18:36:06 --> Email Class Initialized
DEBUG - 2023-08-10 18:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:36:06 --> Controller Class Initialized
INFO - 2023-08-10 18:36:06 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:36:06 --> Helper loaded: form_helper
INFO - 2023-08-10 18:36:06 --> Form Validation Class Initialized
INFO - 2023-08-10 18:36:06 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_create.php
INFO - 2023-08-10 18:36:06 --> Final output sent to browser
DEBUG - 2023-08-10 18:36:06 --> Total execution time: 0.2318
INFO - 2023-08-10 18:36:14 --> Config Class Initialized
INFO - 2023-08-10 18:36:14 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:36:14 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:36:14 --> Utf8 Class Initialized
INFO - 2023-08-10 18:36:14 --> URI Class Initialized
INFO - 2023-08-10 18:36:14 --> Router Class Initialized
INFO - 2023-08-10 18:36:14 --> Output Class Initialized
INFO - 2023-08-10 18:36:14 --> Security Class Initialized
DEBUG - 2023-08-10 18:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:36:14 --> Input Class Initialized
INFO - 2023-08-10 18:36:14 --> Language Class Initialized
INFO - 2023-08-10 18:36:14 --> Loader Class Initialized
INFO - 2023-08-10 18:36:14 --> Helper loaded: url_helper
INFO - 2023-08-10 18:36:14 --> Helper loaded: file_helper
INFO - 2023-08-10 18:36:14 --> Database Driver Class Initialized
INFO - 2023-08-10 18:36:14 --> Email Class Initialized
DEBUG - 2023-08-10 18:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:36:14 --> Controller Class Initialized
INFO - 2023-08-10 18:36:14 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:36:14 --> Helper loaded: form_helper
INFO - 2023-08-10 18:36:14 --> Form Validation Class Initialized
INFO - 2023-08-10 18:36:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 18:36:14 --> Config Class Initialized
INFO - 2023-08-10 18:36:14 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:36:14 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:36:14 --> Utf8 Class Initialized
INFO - 2023-08-10 18:36:54 --> Config Class Initialized
INFO - 2023-08-10 18:36:54 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:36:54 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:36:54 --> Utf8 Class Initialized
INFO - 2023-08-10 18:36:54 --> URI Class Initialized
INFO - 2023-08-10 18:36:54 --> Router Class Initialized
INFO - 2023-08-10 18:36:54 --> Output Class Initialized
INFO - 2023-08-10 18:36:54 --> Security Class Initialized
DEBUG - 2023-08-10 18:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:36:54 --> Input Class Initialized
INFO - 2023-08-10 18:36:54 --> Language Class Initialized
INFO - 2023-08-10 18:36:54 --> Loader Class Initialized
INFO - 2023-08-10 18:36:54 --> Helper loaded: url_helper
INFO - 2023-08-10 18:36:54 --> Helper loaded: file_helper
INFO - 2023-08-10 18:36:54 --> Database Driver Class Initialized
INFO - 2023-08-10 18:36:54 --> Email Class Initialized
DEBUG - 2023-08-10 18:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:36:54 --> Controller Class Initialized
INFO - 2023-08-10 18:36:54 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:36:54 --> Helper loaded: form_helper
INFO - 2023-08-10 18:36:54 --> Form Validation Class Initialized
INFO - 2023-08-10 18:36:54 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_create.php
INFO - 2023-08-10 18:36:54 --> Final output sent to browser
DEBUG - 2023-08-10 18:36:54 --> Total execution time: 0.1175
INFO - 2023-08-10 18:37:01 --> Config Class Initialized
INFO - 2023-08-10 18:37:01 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:37:01 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:37:01 --> Utf8 Class Initialized
INFO - 2023-08-10 18:37:01 --> URI Class Initialized
INFO - 2023-08-10 18:37:01 --> Router Class Initialized
INFO - 2023-08-10 18:37:01 --> Output Class Initialized
INFO - 2023-08-10 18:37:01 --> Security Class Initialized
DEBUG - 2023-08-10 18:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:37:01 --> Input Class Initialized
INFO - 2023-08-10 18:37:01 --> Language Class Initialized
ERROR - 2023-08-10 18:37:01 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-10 18:37:01 --> Config Class Initialized
INFO - 2023-08-10 18:37:01 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:37:01 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:37:01 --> Utf8 Class Initialized
INFO - 2023-08-10 18:37:01 --> URI Class Initialized
INFO - 2023-08-10 18:37:01 --> Router Class Initialized
INFO - 2023-08-10 18:37:01 --> Output Class Initialized
INFO - 2023-08-10 18:37:01 --> Security Class Initialized
DEBUG - 2023-08-10 18:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:37:01 --> Input Class Initialized
INFO - 2023-08-10 18:37:01 --> Language Class Initialized
ERROR - 2023-08-10 18:37:01 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-10 18:37:48 --> Config Class Initialized
INFO - 2023-08-10 18:37:48 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:37:48 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:37:48 --> Utf8 Class Initialized
INFO - 2023-08-10 18:37:48 --> URI Class Initialized
INFO - 2023-08-10 18:37:48 --> Router Class Initialized
INFO - 2023-08-10 18:37:48 --> Output Class Initialized
INFO - 2023-08-10 18:37:48 --> Security Class Initialized
DEBUG - 2023-08-10 18:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:37:48 --> Input Class Initialized
INFO - 2023-08-10 18:37:48 --> Language Class Initialized
INFO - 2023-08-10 18:37:48 --> Loader Class Initialized
INFO - 2023-08-10 18:37:48 --> Helper loaded: url_helper
INFO - 2023-08-10 18:37:48 --> Helper loaded: file_helper
INFO - 2023-08-10 18:37:48 --> Database Driver Class Initialized
INFO - 2023-08-10 18:37:48 --> Email Class Initialized
DEBUG - 2023-08-10 18:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:37:48 --> Controller Class Initialized
INFO - 2023-08-10 18:37:48 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:37:48 --> Helper loaded: form_helper
INFO - 2023-08-10 18:37:48 --> Form Validation Class Initialized
INFO - 2023-08-10 18:37:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 18:37:48 --> Config Class Initialized
INFO - 2023-08-10 18:37:48 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:37:48 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:37:48 --> Utf8 Class Initialized
INFO - 2023-08-10 18:37:48 --> URI Class Initialized
INFO - 2023-08-10 18:37:48 --> Router Class Initialized
INFO - 2023-08-10 18:37:48 --> Output Class Initialized
INFO - 2023-08-10 18:37:48 --> Security Class Initialized
DEBUG - 2023-08-10 18:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:37:48 --> Input Class Initialized
INFO - 2023-08-10 18:37:48 --> Language Class Initialized
INFO - 2023-08-10 18:37:48 --> Loader Class Initialized
INFO - 2023-08-10 18:37:48 --> Helper loaded: url_helper
INFO - 2023-08-10 18:37:48 --> Helper loaded: file_helper
INFO - 2023-08-10 18:37:48 --> Database Driver Class Initialized
INFO - 2023-08-10 18:37:48 --> Email Class Initialized
DEBUG - 2023-08-10 18:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:37:48 --> Controller Class Initialized
INFO - 2023-08-10 18:37:48 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:37:48 --> Helper loaded: form_helper
INFO - 2023-08-10 18:37:48 --> Form Validation Class Initialized
INFO - 2023-08-10 18:37:48 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-10 18:37:48 --> Final output sent to browser
DEBUG - 2023-08-10 18:37:48 --> Total execution time: 0.0478
INFO - 2023-08-10 18:37:49 --> Config Class Initialized
INFO - 2023-08-10 18:37:49 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:37:49 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:37:49 --> Utf8 Class Initialized
INFO - 2023-08-10 18:37:49 --> URI Class Initialized
INFO - 2023-08-10 18:37:49 --> Router Class Initialized
INFO - 2023-08-10 18:37:49 --> Output Class Initialized
INFO - 2023-08-10 18:37:49 --> Security Class Initialized
DEBUG - 2023-08-10 18:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:37:49 --> Input Class Initialized
INFO - 2023-08-10 18:37:49 --> Language Class Initialized
ERROR - 2023-08-10 18:37:49 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-10 18:37:49 --> Config Class Initialized
INFO - 2023-08-10 18:37:49 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:37:49 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:37:49 --> Utf8 Class Initialized
INFO - 2023-08-10 18:37:49 --> URI Class Initialized
INFO - 2023-08-10 18:37:49 --> Router Class Initialized
INFO - 2023-08-10 18:37:49 --> Output Class Initialized
INFO - 2023-08-10 18:37:49 --> Security Class Initialized
DEBUG - 2023-08-10 18:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:37:49 --> Input Class Initialized
INFO - 2023-08-10 18:37:49 --> Language Class Initialized
ERROR - 2023-08-10 18:37:49 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-10 18:37:57 --> Config Class Initialized
INFO - 2023-08-10 18:37:57 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:37:57 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:37:57 --> Utf8 Class Initialized
INFO - 2023-08-10 18:37:57 --> URI Class Initialized
INFO - 2023-08-10 18:37:57 --> Router Class Initialized
INFO - 2023-08-10 18:37:57 --> Output Class Initialized
INFO - 2023-08-10 18:37:57 --> Security Class Initialized
DEBUG - 2023-08-10 18:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:37:57 --> Input Class Initialized
INFO - 2023-08-10 18:37:57 --> Language Class Initialized
INFO - 2023-08-10 18:37:57 --> Loader Class Initialized
INFO - 2023-08-10 18:37:57 --> Helper loaded: url_helper
INFO - 2023-08-10 18:37:57 --> Helper loaded: file_helper
INFO - 2023-08-10 18:37:57 --> Database Driver Class Initialized
INFO - 2023-08-10 18:37:57 --> Email Class Initialized
DEBUG - 2023-08-10 18:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:37:57 --> Controller Class Initialized
INFO - 2023-08-10 18:37:57 --> Model "Training_model" initialized
INFO - 2023-08-10 18:37:57 --> Helper loaded: form_helper
INFO - 2023-08-10 18:37:57 --> Form Validation Class Initialized
INFO - 2023-08-10 18:37:57 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-10 18:37:57 --> Final output sent to browser
DEBUG - 2023-08-10 18:37:57 --> Total execution time: 0.0489
INFO - 2023-08-10 18:38:02 --> Config Class Initialized
INFO - 2023-08-10 18:38:02 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:38:02 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:38:02 --> Utf8 Class Initialized
INFO - 2023-08-10 18:38:02 --> URI Class Initialized
INFO - 2023-08-10 18:38:02 --> Router Class Initialized
INFO - 2023-08-10 18:38:02 --> Output Class Initialized
INFO - 2023-08-10 18:38:02 --> Security Class Initialized
DEBUG - 2023-08-10 18:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:38:02 --> Input Class Initialized
INFO - 2023-08-10 18:38:02 --> Language Class Initialized
INFO - 2023-08-10 18:38:02 --> Loader Class Initialized
INFO - 2023-08-10 18:38:02 --> Helper loaded: url_helper
INFO - 2023-08-10 18:38:02 --> Helper loaded: file_helper
INFO - 2023-08-10 18:38:02 --> Database Driver Class Initialized
INFO - 2023-08-10 18:38:02 --> Email Class Initialized
DEBUG - 2023-08-10 18:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:38:02 --> Controller Class Initialized
INFO - 2023-08-10 18:38:02 --> Model "Training_model" initialized
INFO - 2023-08-10 18:38:02 --> Helper loaded: form_helper
INFO - 2023-08-10 18:38:02 --> Form Validation Class Initialized
INFO - 2023-08-10 18:38:02 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_create.php
INFO - 2023-08-10 18:38:02 --> Final output sent to browser
DEBUG - 2023-08-10 18:38:02 --> Total execution time: 0.0501
INFO - 2023-08-10 18:38:02 --> Config Class Initialized
INFO - 2023-08-10 18:38:02 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:38:02 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:38:02 --> Utf8 Class Initialized
INFO - 2023-08-10 18:38:02 --> URI Class Initialized
INFO - 2023-08-10 18:38:02 --> Router Class Initialized
INFO - 2023-08-10 18:38:02 --> Output Class Initialized
INFO - 2023-08-10 18:38:02 --> Security Class Initialized
DEBUG - 2023-08-10 18:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:38:02 --> Input Class Initialized
INFO - 2023-08-10 18:38:02 --> Language Class Initialized
INFO - 2023-08-10 18:38:02 --> Loader Class Initialized
INFO - 2023-08-10 18:38:02 --> Helper loaded: url_helper
INFO - 2023-08-10 18:38:02 --> Helper loaded: file_helper
INFO - 2023-08-10 18:38:02 --> Database Driver Class Initialized
INFO - 2023-08-10 18:38:02 --> Email Class Initialized
DEBUG - 2023-08-10 18:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:38:02 --> Controller Class Initialized
INFO - 2023-08-10 18:38:02 --> Model "Training_model" initialized
INFO - 2023-08-10 18:38:02 --> Helper loaded: form_helper
INFO - 2023-08-10 18:38:02 --> Form Validation Class Initialized
INFO - 2023-08-10 18:38:02 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_create.php
INFO - 2023-08-10 18:38:02 --> Final output sent to browser
DEBUG - 2023-08-10 18:38:02 --> Total execution time: 0.0558
INFO - 2023-08-10 18:38:29 --> Config Class Initialized
INFO - 2023-08-10 18:38:29 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:38:29 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:38:29 --> Utf8 Class Initialized
INFO - 2023-08-10 18:38:29 --> URI Class Initialized
INFO - 2023-08-10 18:38:29 --> Router Class Initialized
INFO - 2023-08-10 18:38:29 --> Output Class Initialized
INFO - 2023-08-10 18:38:29 --> Security Class Initialized
DEBUG - 2023-08-10 18:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:38:29 --> Input Class Initialized
INFO - 2023-08-10 18:38:29 --> Language Class Initialized
INFO - 2023-08-10 18:38:29 --> Loader Class Initialized
INFO - 2023-08-10 18:38:29 --> Helper loaded: url_helper
INFO - 2023-08-10 18:38:29 --> Helper loaded: file_helper
INFO - 2023-08-10 18:38:29 --> Database Driver Class Initialized
INFO - 2023-08-10 18:38:29 --> Email Class Initialized
DEBUG - 2023-08-10 18:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:38:29 --> Controller Class Initialized
INFO - 2023-08-10 18:38:29 --> Model "Training_model" initialized
INFO - 2023-08-10 18:38:29 --> Helper loaded: form_helper
INFO - 2023-08-10 18:38:29 --> Form Validation Class Initialized
INFO - 2023-08-10 18:38:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 18:38:29 --> Config Class Initialized
INFO - 2023-08-10 18:38:29 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:38:29 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:38:29 --> Utf8 Class Initialized
INFO - 2023-08-10 18:38:29 --> URI Class Initialized
INFO - 2023-08-10 18:38:29 --> Router Class Initialized
INFO - 2023-08-10 18:38:29 --> Output Class Initialized
INFO - 2023-08-10 18:38:29 --> Security Class Initialized
DEBUG - 2023-08-10 18:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:38:29 --> Input Class Initialized
INFO - 2023-08-10 18:38:29 --> Language Class Initialized
INFO - 2023-08-10 18:38:29 --> Loader Class Initialized
INFO - 2023-08-10 18:38:29 --> Helper loaded: url_helper
INFO - 2023-08-10 18:38:29 --> Helper loaded: file_helper
INFO - 2023-08-10 18:38:29 --> Database Driver Class Initialized
INFO - 2023-08-10 18:38:29 --> Email Class Initialized
DEBUG - 2023-08-10 18:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:38:29 --> Controller Class Initialized
INFO - 2023-08-10 18:38:29 --> Model "Training_model" initialized
INFO - 2023-08-10 18:38:29 --> Helper loaded: form_helper
INFO - 2023-08-10 18:38:29 --> Form Validation Class Initialized
INFO - 2023-08-10 18:38:29 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-10 18:38:29 --> Final output sent to browser
DEBUG - 2023-08-10 18:38:29 --> Total execution time: 0.0498
INFO - 2023-08-10 18:38:35 --> Config Class Initialized
INFO - 2023-08-10 18:38:35 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:38:35 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:38:35 --> Utf8 Class Initialized
INFO - 2023-08-10 18:38:35 --> URI Class Initialized
INFO - 2023-08-10 18:38:35 --> Router Class Initialized
INFO - 2023-08-10 18:38:35 --> Output Class Initialized
INFO - 2023-08-10 18:38:35 --> Security Class Initialized
DEBUG - 2023-08-10 18:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:38:35 --> Input Class Initialized
INFO - 2023-08-10 18:38:35 --> Language Class Initialized
INFO - 2023-08-10 18:38:35 --> Loader Class Initialized
INFO - 2023-08-10 18:38:35 --> Helper loaded: url_helper
INFO - 2023-08-10 18:38:35 --> Helper loaded: file_helper
INFO - 2023-08-10 18:38:35 --> Database Driver Class Initialized
INFO - 2023-08-10 18:38:35 --> Email Class Initialized
DEBUG - 2023-08-10 18:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:38:35 --> Controller Class Initialized
INFO - 2023-08-10 18:38:35 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:38:35 --> Helper loaded: form_helper
INFO - 2023-08-10 18:38:35 --> Form Validation Class Initialized
INFO - 2023-08-10 18:38:35 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-10 18:38:35 --> Final output sent to browser
DEBUG - 2023-08-10 18:38:35 --> Total execution time: 0.0494
INFO - 2023-08-10 18:38:40 --> Config Class Initialized
INFO - 2023-08-10 18:38:40 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:38:40 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:38:40 --> Utf8 Class Initialized
INFO - 2023-08-10 18:38:40 --> URI Class Initialized
INFO - 2023-08-10 18:38:40 --> Router Class Initialized
INFO - 2023-08-10 18:38:40 --> Output Class Initialized
INFO - 2023-08-10 18:38:40 --> Security Class Initialized
DEBUG - 2023-08-10 18:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:38:40 --> Input Class Initialized
INFO - 2023-08-10 18:38:40 --> Language Class Initialized
INFO - 2023-08-10 18:38:40 --> Loader Class Initialized
INFO - 2023-08-10 18:38:40 --> Helper loaded: url_helper
INFO - 2023-08-10 18:38:40 --> Helper loaded: file_helper
INFO - 2023-08-10 18:38:40 --> Database Driver Class Initialized
INFO - 2023-08-10 18:38:40 --> Email Class Initialized
DEBUG - 2023-08-10 18:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:38:40 --> Controller Class Initialized
INFO - 2023-08-10 18:38:40 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:38:40 --> Helper loaded: form_helper
INFO - 2023-08-10 18:38:40 --> Form Validation Class Initialized
INFO - 2023-08-10 18:38:40 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_create.php
INFO - 2023-08-10 18:38:40 --> Final output sent to browser
DEBUG - 2023-08-10 18:38:40 --> Total execution time: 0.0504
INFO - 2023-08-10 18:38:47 --> Config Class Initialized
INFO - 2023-08-10 18:38:47 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:38:47 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:38:47 --> Utf8 Class Initialized
INFO - 2023-08-10 18:38:47 --> URI Class Initialized
INFO - 2023-08-10 18:38:47 --> Router Class Initialized
INFO - 2023-08-10 18:38:47 --> Output Class Initialized
INFO - 2023-08-10 18:38:47 --> Security Class Initialized
DEBUG - 2023-08-10 18:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:38:47 --> Input Class Initialized
INFO - 2023-08-10 18:38:47 --> Language Class Initialized
INFO - 2023-08-10 18:38:47 --> Loader Class Initialized
INFO - 2023-08-10 18:38:47 --> Helper loaded: url_helper
INFO - 2023-08-10 18:38:47 --> Helper loaded: file_helper
INFO - 2023-08-10 18:38:47 --> Database Driver Class Initialized
INFO - 2023-08-10 18:38:47 --> Email Class Initialized
DEBUG - 2023-08-10 18:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:38:47 --> Controller Class Initialized
INFO - 2023-08-10 18:38:47 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:38:47 --> Helper loaded: form_helper
INFO - 2023-08-10 18:38:47 --> Form Validation Class Initialized
INFO - 2023-08-10 18:38:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-10 18:38:47 --> Config Class Initialized
INFO - 2023-08-10 18:38:47 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:38:47 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:38:47 --> Utf8 Class Initialized
INFO - 2023-08-10 18:38:47 --> URI Class Initialized
INFO - 2023-08-10 18:38:47 --> Router Class Initialized
INFO - 2023-08-10 18:38:47 --> Output Class Initialized
INFO - 2023-08-10 18:38:47 --> Security Class Initialized
DEBUG - 2023-08-10 18:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:38:47 --> Input Class Initialized
INFO - 2023-08-10 18:38:47 --> Language Class Initialized
INFO - 2023-08-10 18:38:47 --> Loader Class Initialized
INFO - 2023-08-10 18:38:47 --> Helper loaded: url_helper
INFO - 2023-08-10 18:38:47 --> Helper loaded: file_helper
INFO - 2023-08-10 18:38:47 --> Database Driver Class Initialized
INFO - 2023-08-10 18:38:47 --> Email Class Initialized
DEBUG - 2023-08-10 18:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:38:47 --> Controller Class Initialized
INFO - 2023-08-10 18:38:47 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:38:47 --> Helper loaded: form_helper
INFO - 2023-08-10 18:38:47 --> Form Validation Class Initialized
INFO - 2023-08-10 18:38:47 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-10 18:38:47 --> Final output sent to browser
DEBUG - 2023-08-10 18:38:47 --> Total execution time: 0.0487
INFO - 2023-08-10 18:42:15 --> Config Class Initialized
INFO - 2023-08-10 18:42:15 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:42:15 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:42:15 --> Utf8 Class Initialized
INFO - 2023-08-10 18:42:15 --> URI Class Initialized
INFO - 2023-08-10 18:42:15 --> Router Class Initialized
INFO - 2023-08-10 18:42:15 --> Output Class Initialized
INFO - 2023-08-10 18:42:15 --> Security Class Initialized
DEBUG - 2023-08-10 18:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:42:15 --> Input Class Initialized
INFO - 2023-08-10 18:42:15 --> Language Class Initialized
INFO - 2023-08-10 18:42:15 --> Loader Class Initialized
INFO - 2023-08-10 18:42:15 --> Helper loaded: url_helper
INFO - 2023-08-10 18:42:15 --> Helper loaded: file_helper
INFO - 2023-08-10 18:42:15 --> Database Driver Class Initialized
INFO - 2023-08-10 18:42:15 --> Email Class Initialized
DEBUG - 2023-08-10 18:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:42:15 --> Controller Class Initialized
INFO - 2023-08-10 18:42:15 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:42:15 --> Helper loaded: form_helper
INFO - 2023-08-10 18:42:15 --> Form Validation Class Initialized
INFO - 2023-08-10 18:42:15 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-10 18:42:15 --> Final output sent to browser
DEBUG - 2023-08-10 18:42:15 --> Total execution time: 0.3811
INFO - 2023-08-10 18:42:21 --> Config Class Initialized
INFO - 2023-08-10 18:42:21 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:42:21 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:42:21 --> Utf8 Class Initialized
INFO - 2023-08-10 18:42:21 --> URI Class Initialized
INFO - 2023-08-10 18:42:21 --> Router Class Initialized
INFO - 2023-08-10 18:42:21 --> Output Class Initialized
INFO - 2023-08-10 18:42:21 --> Security Class Initialized
DEBUG - 2023-08-10 18:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:42:21 --> Input Class Initialized
INFO - 2023-08-10 18:42:21 --> Language Class Initialized
INFO - 2023-08-10 18:42:21 --> Loader Class Initialized
INFO - 2023-08-10 18:42:21 --> Helper loaded: url_helper
INFO - 2023-08-10 18:42:21 --> Helper loaded: file_helper
INFO - 2023-08-10 18:42:21 --> Database Driver Class Initialized
INFO - 2023-08-10 18:42:21 --> Email Class Initialized
DEBUG - 2023-08-10 18:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:42:21 --> Controller Class Initialized
INFO - 2023-08-10 18:42:21 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:42:21 --> Helper loaded: form_helper
INFO - 2023-08-10 18:42:21 --> Form Validation Class Initialized
INFO - 2023-08-10 18:42:21 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-10 18:42:21 --> Final output sent to browser
DEBUG - 2023-08-10 18:42:21 --> Total execution time: 0.0511
INFO - 2023-08-10 18:42:27 --> Config Class Initialized
INFO - 2023-08-10 18:42:27 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:42:27 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:42:27 --> Utf8 Class Initialized
INFO - 2023-08-10 18:42:27 --> URI Class Initialized
INFO - 2023-08-10 18:42:27 --> Router Class Initialized
INFO - 2023-08-10 18:42:27 --> Output Class Initialized
INFO - 2023-08-10 18:42:27 --> Security Class Initialized
DEBUG - 2023-08-10 18:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:42:27 --> Input Class Initialized
INFO - 2023-08-10 18:42:27 --> Language Class Initialized
ERROR - 2023-08-10 18:42:27 --> 404 Page Not Found: admin/Key_highlights/index
INFO - 2023-08-10 18:42:29 --> Config Class Initialized
INFO - 2023-08-10 18:42:29 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:42:29 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:42:29 --> Utf8 Class Initialized
INFO - 2023-08-10 18:42:29 --> URI Class Initialized
INFO - 2023-08-10 18:42:29 --> Router Class Initialized
INFO - 2023-08-10 18:42:29 --> Output Class Initialized
INFO - 2023-08-10 18:42:29 --> Security Class Initialized
DEBUG - 2023-08-10 18:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:42:29 --> Input Class Initialized
INFO - 2023-08-10 18:42:29 --> Language Class Initialized
INFO - 2023-08-10 18:42:29 --> Loader Class Initialized
INFO - 2023-08-10 18:42:29 --> Helper loaded: url_helper
INFO - 2023-08-10 18:42:29 --> Helper loaded: file_helper
INFO - 2023-08-10 18:42:29 --> Database Driver Class Initialized
INFO - 2023-08-10 18:42:29 --> Email Class Initialized
DEBUG - 2023-08-10 18:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:42:29 --> Controller Class Initialized
INFO - 2023-08-10 18:42:29 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:42:29 --> Helper loaded: form_helper
INFO - 2023-08-10 18:42:29 --> Form Validation Class Initialized
INFO - 2023-08-10 18:42:29 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-10 18:42:29 --> Final output sent to browser
DEBUG - 2023-08-10 18:42:29 --> Total execution time: 0.0603
INFO - 2023-08-10 18:42:29 --> Config Class Initialized
INFO - 2023-08-10 18:42:29 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:42:29 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:42:29 --> Utf8 Class Initialized
INFO - 2023-08-10 18:42:29 --> URI Class Initialized
INFO - 2023-08-10 18:42:29 --> Router Class Initialized
INFO - 2023-08-10 18:42:29 --> Output Class Initialized
INFO - 2023-08-10 18:42:29 --> Security Class Initialized
DEBUG - 2023-08-10 18:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:42:29 --> Input Class Initialized
INFO - 2023-08-10 18:42:29 --> Language Class Initialized
INFO - 2023-08-10 18:42:29 --> Loader Class Initialized
INFO - 2023-08-10 18:42:29 --> Helper loaded: url_helper
INFO - 2023-08-10 18:42:29 --> Helper loaded: file_helper
INFO - 2023-08-10 18:42:29 --> Database Driver Class Initialized
INFO - 2023-08-10 18:42:29 --> Email Class Initialized
DEBUG - 2023-08-10 18:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:42:30 --> Controller Class Initialized
INFO - 2023-08-10 18:42:30 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:42:30 --> Helper loaded: form_helper
INFO - 2023-08-10 18:42:30 --> Form Validation Class Initialized
INFO - 2023-08-10 18:42:30 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-10 18:42:30 --> Final output sent to browser
DEBUG - 2023-08-10 18:42:30 --> Total execution time: 0.0467
INFO - 2023-08-10 18:42:30 --> Config Class Initialized
INFO - 2023-08-10 18:42:30 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:42:30 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:42:30 --> Utf8 Class Initialized
INFO - 2023-08-10 18:42:30 --> URI Class Initialized
INFO - 2023-08-10 18:42:30 --> Router Class Initialized
INFO - 2023-08-10 18:42:30 --> Output Class Initialized
INFO - 2023-08-10 18:42:30 --> Security Class Initialized
DEBUG - 2023-08-10 18:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:42:30 --> Input Class Initialized
INFO - 2023-08-10 18:42:30 --> Language Class Initialized
INFO - 2023-08-10 18:42:31 --> Loader Class Initialized
INFO - 2023-08-10 18:42:31 --> Helper loaded: url_helper
INFO - 2023-08-10 18:42:31 --> Helper loaded: file_helper
INFO - 2023-08-10 18:42:31 --> Database Driver Class Initialized
INFO - 2023-08-10 18:42:31 --> Email Class Initialized
DEBUG - 2023-08-10 18:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:42:31 --> Controller Class Initialized
INFO - 2023-08-10 18:42:31 --> Model "Key_highlights_model" initialized
INFO - 2023-08-10 18:42:31 --> Helper loaded: form_helper
INFO - 2023-08-10 18:42:31 --> Form Validation Class Initialized
INFO - 2023-08-10 18:42:31 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_create.php
INFO - 2023-08-10 18:42:31 --> Final output sent to browser
DEBUG - 2023-08-10 18:42:31 --> Total execution time: 0.0469
INFO - 2023-08-10 18:42:34 --> Config Class Initialized
INFO - 2023-08-10 18:42:34 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:42:34 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:42:34 --> Utf8 Class Initialized
INFO - 2023-08-10 18:42:34 --> URI Class Initialized
INFO - 2023-08-10 18:42:34 --> Router Class Initialized
INFO - 2023-08-10 18:42:34 --> Output Class Initialized
INFO - 2023-08-10 18:42:34 --> Security Class Initialized
DEBUG - 2023-08-10 18:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:42:34 --> Input Class Initialized
INFO - 2023-08-10 18:42:34 --> Language Class Initialized
INFO - 2023-08-10 18:42:34 --> Loader Class Initialized
INFO - 2023-08-10 18:42:34 --> Helper loaded: url_helper
INFO - 2023-08-10 18:42:34 --> Helper loaded: file_helper
INFO - 2023-08-10 18:42:34 --> Database Driver Class Initialized
INFO - 2023-08-10 18:42:34 --> Email Class Initialized
DEBUG - 2023-08-10 18:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:42:34 --> Controller Class Initialized
INFO - 2023-08-10 18:42:34 --> Model "Training_model" initialized
INFO - 2023-08-10 18:42:34 --> Helper loaded: form_helper
INFO - 2023-08-10 18:42:34 --> Form Validation Class Initialized
INFO - 2023-08-10 18:42:34 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-10 18:42:34 --> Final output sent to browser
DEBUG - 2023-08-10 18:42:34 --> Total execution time: 0.0519
INFO - 2023-08-10 18:42:44 --> Config Class Initialized
INFO - 2023-08-10 18:42:44 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:42:44 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:42:44 --> Utf8 Class Initialized
INFO - 2023-08-10 18:42:44 --> URI Class Initialized
INFO - 2023-08-10 18:42:44 --> Router Class Initialized
INFO - 2023-08-10 18:42:44 --> Output Class Initialized
INFO - 2023-08-10 18:42:44 --> Security Class Initialized
DEBUG - 2023-08-10 18:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:42:44 --> Input Class Initialized
INFO - 2023-08-10 18:42:44 --> Language Class Initialized
INFO - 2023-08-10 18:42:44 --> Loader Class Initialized
INFO - 2023-08-10 18:42:44 --> Helper loaded: url_helper
INFO - 2023-08-10 18:42:44 --> Helper loaded: file_helper
INFO - 2023-08-10 18:42:44 --> Database Driver Class Initialized
INFO - 2023-08-10 18:42:44 --> Email Class Initialized
DEBUG - 2023-08-10 18:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:42:44 --> Controller Class Initialized
INFO - 2023-08-10 18:42:44 --> Model "Training_model" initialized
INFO - 2023-08-10 18:42:44 --> Helper loaded: form_helper
INFO - 2023-08-10 18:42:45 --> Form Validation Class Initialized
INFO - 2023-08-10 18:42:45 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_edit.php
INFO - 2023-08-10 18:42:45 --> Final output sent to browser
DEBUG - 2023-08-10 18:42:45 --> Total execution time: 0.0974
INFO - 2023-08-10 18:42:45 --> Config Class Initialized
INFO - 2023-08-10 18:42:45 --> Hooks Class Initialized
DEBUG - 2023-08-10 18:42:45 --> UTF-8 Support Enabled
INFO - 2023-08-10 18:42:45 --> Utf8 Class Initialized
INFO - 2023-08-10 18:42:45 --> URI Class Initialized
INFO - 2023-08-10 18:42:45 --> Router Class Initialized
INFO - 2023-08-10 18:42:45 --> Output Class Initialized
INFO - 2023-08-10 18:42:45 --> Security Class Initialized
DEBUG - 2023-08-10 18:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-10 18:42:45 --> Input Class Initialized
INFO - 2023-08-10 18:42:45 --> Language Class Initialized
INFO - 2023-08-10 18:42:45 --> Loader Class Initialized
INFO - 2023-08-10 18:42:45 --> Helper loaded: url_helper
INFO - 2023-08-10 18:42:45 --> Helper loaded: file_helper
INFO - 2023-08-10 18:42:45 --> Database Driver Class Initialized
INFO - 2023-08-10 18:42:45 --> Email Class Initialized
DEBUG - 2023-08-10 18:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-10 18:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-10 18:42:45 --> Controller Class Initialized
INFO - 2023-08-10 18:42:45 --> Model "Training_model" initialized
INFO - 2023-08-10 18:42:45 --> Helper loaded: form_helper
INFO - 2023-08-10 18:42:45 --> Form Validation Class Initialized
ERROR - 2023-08-10 18:42:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 39
ERROR - 2023-08-10 18:42:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 46
ERROR - 2023-08-10 18:42:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 55
ERROR - 2023-08-10 18:42:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 69
ERROR - 2023-08-10 18:42:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 81
ERROR - 2023-08-10 18:42:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 98
ERROR - 2023-08-10 18:42:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 99
ERROR - 2023-08-10 18:42:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 100
ERROR - 2023-08-10 18:42:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 116
ERROR - 2023-08-10 18:42:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 126
ERROR - 2023-08-10 18:42:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 127
INFO - 2023-08-10 18:42:45 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_edit.php
INFO - 2023-08-10 18:42:45 --> Final output sent to browser
DEBUG - 2023-08-10 18:42:45 --> Total execution time: 0.0566
