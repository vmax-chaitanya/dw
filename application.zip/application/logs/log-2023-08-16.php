<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-16 16:24:55 --> Config Class Initialized
INFO - 2023-08-16 16:24:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:24:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:24:55 --> Utf8 Class Initialized
INFO - 2023-08-16 16:24:55 --> URI Class Initialized
INFO - 2023-08-16 16:25:03 --> Config Class Initialized
INFO - 2023-08-16 16:25:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:25:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:25:03 --> Utf8 Class Initialized
INFO - 2023-08-16 16:25:03 --> URI Class Initialized
INFO - 2023-08-16 16:25:03 --> Router Class Initialized
INFO - 2023-08-16 16:25:03 --> Output Class Initialized
INFO - 2023-08-16 16:25:03 --> Security Class Initialized
DEBUG - 2023-08-16 16:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:25:03 --> Input Class Initialized
INFO - 2023-08-16 16:25:03 --> Language Class Initialized
INFO - 2023-08-16 16:25:03 --> Loader Class Initialized
INFO - 2023-08-16 16:25:03 --> Helper loaded: url_helper
INFO - 2023-08-16 16:25:03 --> Helper loaded: file_helper
INFO - 2023-08-16 16:25:03 --> Database Driver Class Initialized
INFO - 2023-08-16 16:25:03 --> Email Class Initialized
DEBUG - 2023-08-16 16:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:25:03 --> Controller Class Initialized
INFO - 2023-08-16 16:25:03 --> Model "Home_model" initialized
INFO - 2023-08-16 16:25:03 --> Helper loaded: form_helper
INFO - 2023-08-16 16:25:03 --> Form Validation Class Initialized
INFO - 2023-08-16 16:25:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-16 16:25:03 --> Final output sent to browser
DEBUG - 2023-08-16 16:25:03 --> Total execution time: 0.1052
INFO - 2023-08-16 16:25:05 --> Config Class Initialized
INFO - 2023-08-16 16:25:05 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:25:05 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:25:05 --> Utf8 Class Initialized
INFO - 2023-08-16 16:25:05 --> URI Class Initialized
INFO - 2023-08-16 16:25:05 --> Router Class Initialized
INFO - 2023-08-16 16:25:05 --> Output Class Initialized
INFO - 2023-08-16 16:25:05 --> Security Class Initialized
DEBUG - 2023-08-16 16:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:25:05 --> Input Class Initialized
INFO - 2023-08-16 16:25:05 --> Language Class Initialized
ERROR - 2023-08-16 16:25:05 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:25:05 --> Config Class Initialized
INFO - 2023-08-16 16:25:05 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:25:05 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:25:05 --> Utf8 Class Initialized
INFO - 2023-08-16 16:25:05 --> URI Class Initialized
INFO - 2023-08-16 16:25:05 --> Router Class Initialized
INFO - 2023-08-16 16:25:05 --> Output Class Initialized
INFO - 2023-08-16 16:25:05 --> Security Class Initialized
DEBUG - 2023-08-16 16:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:25:05 --> Input Class Initialized
INFO - 2023-08-16 16:25:05 --> Language Class Initialized
ERROR - 2023-08-16 16:25:05 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:25:05 --> Config Class Initialized
INFO - 2023-08-16 16:25:05 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:25:05 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:25:05 --> Utf8 Class Initialized
INFO - 2023-08-16 16:25:05 --> URI Class Initialized
INFO - 2023-08-16 16:25:05 --> Router Class Initialized
INFO - 2023-08-16 16:25:05 --> Output Class Initialized
INFO - 2023-08-16 16:25:05 --> Security Class Initialized
DEBUG - 2023-08-16 16:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:25:05 --> Input Class Initialized
INFO - 2023-08-16 16:25:05 --> Language Class Initialized
ERROR - 2023-08-16 16:25:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:25:16 --> Config Class Initialized
INFO - 2023-08-16 16:25:16 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:25:16 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:25:16 --> Utf8 Class Initialized
INFO - 2023-08-16 16:25:16 --> URI Class Initialized
INFO - 2023-08-16 16:25:16 --> Router Class Initialized
INFO - 2023-08-16 16:25:16 --> Output Class Initialized
INFO - 2023-08-16 16:25:16 --> Security Class Initialized
DEBUG - 2023-08-16 16:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:25:16 --> Input Class Initialized
INFO - 2023-08-16 16:25:16 --> Language Class Initialized
ERROR - 2023-08-16 16:25:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:25:34 --> Config Class Initialized
INFO - 2023-08-16 16:25:34 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:25:34 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:25:34 --> Utf8 Class Initialized
INFO - 2023-08-16 16:25:34 --> URI Class Initialized
INFO - 2023-08-16 16:25:34 --> Router Class Initialized
INFO - 2023-08-16 16:25:34 --> Output Class Initialized
INFO - 2023-08-16 16:25:34 --> Security Class Initialized
DEBUG - 2023-08-16 16:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:25:34 --> Input Class Initialized
INFO - 2023-08-16 16:25:34 --> Language Class Initialized
ERROR - 2023-08-16 16:25:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:25:34 --> Config Class Initialized
INFO - 2023-08-16 16:25:34 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:25:34 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:25:34 --> Utf8 Class Initialized
INFO - 2023-08-16 16:25:34 --> URI Class Initialized
INFO - 2023-08-16 16:25:34 --> Router Class Initialized
INFO - 2023-08-16 16:25:35 --> Output Class Initialized
INFO - 2023-08-16 16:25:35 --> Security Class Initialized
DEBUG - 2023-08-16 16:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:25:35 --> Input Class Initialized
INFO - 2023-08-16 16:25:35 --> Language Class Initialized
ERROR - 2023-08-16 16:25:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:25:40 --> Config Class Initialized
INFO - 2023-08-16 16:25:40 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:25:40 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:25:40 --> Utf8 Class Initialized
INFO - 2023-08-16 16:25:40 --> URI Class Initialized
INFO - 2023-08-16 16:25:40 --> Router Class Initialized
INFO - 2023-08-16 16:25:40 --> Output Class Initialized
INFO - 2023-08-16 16:25:40 --> Security Class Initialized
DEBUG - 2023-08-16 16:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:25:40 --> Input Class Initialized
INFO - 2023-08-16 16:25:40 --> Language Class Initialized
INFO - 2023-08-16 16:25:40 --> Loader Class Initialized
INFO - 2023-08-16 16:25:40 --> Helper loaded: url_helper
INFO - 2023-08-16 16:25:40 --> Helper loaded: file_helper
INFO - 2023-08-16 16:25:40 --> Database Driver Class Initialized
INFO - 2023-08-16 16:25:40 --> Email Class Initialized
DEBUG - 2023-08-16 16:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:25:40 --> Controller Class Initialized
INFO - 2023-08-16 16:25:40 --> Model "Home_model" initialized
INFO - 2023-08-16 16:25:40 --> Helper loaded: form_helper
INFO - 2023-08-16 16:25:40 --> Form Validation Class Initialized
INFO - 2023-08-16 16:25:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-16 16:25:40 --> Final output sent to browser
DEBUG - 2023-08-16 16:25:40 --> Total execution time: 0.0524
INFO - 2023-08-16 16:25:40 --> Config Class Initialized
INFO - 2023-08-16 16:25:40 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:25:40 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:25:40 --> Utf8 Class Initialized
INFO - 2023-08-16 16:25:40 --> URI Class Initialized
INFO - 2023-08-16 16:25:40 --> Router Class Initialized
INFO - 2023-08-16 16:25:40 --> Output Class Initialized
INFO - 2023-08-16 16:25:40 --> Security Class Initialized
DEBUG - 2023-08-16 16:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:25:40 --> Input Class Initialized
INFO - 2023-08-16 16:25:40 --> Language Class Initialized
ERROR - 2023-08-16 16:25:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:25:41 --> Config Class Initialized
INFO - 2023-08-16 16:25:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:25:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:25:41 --> Utf8 Class Initialized
INFO - 2023-08-16 16:25:41 --> URI Class Initialized
INFO - 2023-08-16 16:25:41 --> Router Class Initialized
INFO - 2023-08-16 16:25:41 --> Output Class Initialized
INFO - 2023-08-16 16:25:41 --> Security Class Initialized
DEBUG - 2023-08-16 16:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:25:41 --> Input Class Initialized
INFO - 2023-08-16 16:25:41 --> Language Class Initialized
ERROR - 2023-08-16 16:25:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:25:41 --> Config Class Initialized
INFO - 2023-08-16 16:25:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:25:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:25:41 --> Utf8 Class Initialized
INFO - 2023-08-16 16:25:41 --> URI Class Initialized
INFO - 2023-08-16 16:25:41 --> Router Class Initialized
INFO - 2023-08-16 16:25:41 --> Output Class Initialized
INFO - 2023-08-16 16:25:41 --> Security Class Initialized
DEBUG - 2023-08-16 16:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:25:41 --> Input Class Initialized
INFO - 2023-08-16 16:25:41 --> Language Class Initialized
ERROR - 2023-08-16 16:25:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:25:41 --> Config Class Initialized
INFO - 2023-08-16 16:25:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:25:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:25:41 --> Utf8 Class Initialized
INFO - 2023-08-16 16:25:41 --> URI Class Initialized
INFO - 2023-08-16 16:25:41 --> Router Class Initialized
INFO - 2023-08-16 16:25:41 --> Output Class Initialized
INFO - 2023-08-16 16:25:41 --> Security Class Initialized
DEBUG - 2023-08-16 16:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:25:41 --> Input Class Initialized
INFO - 2023-08-16 16:25:41 --> Language Class Initialized
ERROR - 2023-08-16 16:25:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:33:57 --> Config Class Initialized
INFO - 2023-08-16 16:33:57 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:33:57 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:33:57 --> Utf8 Class Initialized
INFO - 2023-08-16 16:33:57 --> URI Class Initialized
INFO - 2023-08-16 16:33:57 --> Router Class Initialized
INFO - 2023-08-16 16:33:57 --> Output Class Initialized
INFO - 2023-08-16 16:33:57 --> Security Class Initialized
DEBUG - 2023-08-16 16:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:33:57 --> Input Class Initialized
INFO - 2023-08-16 16:33:57 --> Language Class Initialized
INFO - 2023-08-16 16:33:57 --> Loader Class Initialized
INFO - 2023-08-16 16:33:57 --> Helper loaded: url_helper
INFO - 2023-08-16 16:33:58 --> Helper loaded: file_helper
INFO - 2023-08-16 16:33:58 --> Database Driver Class Initialized
INFO - 2023-08-16 16:33:58 --> Email Class Initialized
DEBUG - 2023-08-16 16:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:33:58 --> Controller Class Initialized
INFO - 2023-08-16 16:33:58 --> Model "Home_model" initialized
INFO - 2023-08-16 16:33:58 --> Helper loaded: form_helper
INFO - 2023-08-16 16:33:58 --> Form Validation Class Initialized
INFO - 2023-08-16 16:33:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-16 16:33:59 --> Final output sent to browser
DEBUG - 2023-08-16 16:33:59 --> Total execution time: 1.9705
INFO - 2023-08-16 16:33:59 --> Config Class Initialized
INFO - 2023-08-16 16:33:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:33:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:33:59 --> Utf8 Class Initialized
INFO - 2023-08-16 16:33:59 --> URI Class Initialized
INFO - 2023-08-16 16:33:59 --> Router Class Initialized
INFO - 2023-08-16 16:33:59 --> Output Class Initialized
INFO - 2023-08-16 16:33:59 --> Security Class Initialized
DEBUG - 2023-08-16 16:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:33:59 --> Input Class Initialized
INFO - 2023-08-16 16:33:59 --> Language Class Initialized
INFO - 2023-08-16 16:33:59 --> Config Class Initialized
INFO - 2023-08-16 16:33:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:33:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:33:59 --> Utf8 Class Initialized
INFO - 2023-08-16 16:33:59 --> URI Class Initialized
INFO - 2023-08-16 16:33:59 --> Router Class Initialized
INFO - 2023-08-16 16:33:59 --> Output Class Initialized
INFO - 2023-08-16 16:33:59 --> Security Class Initialized
DEBUG - 2023-08-16 16:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:33:59 --> Input Class Initialized
INFO - 2023-08-16 16:33:59 --> Language Class Initialized
INFO - 2023-08-16 16:33:59 --> Config Class Initialized
INFO - 2023-08-16 16:33:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:33:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:33:59 --> Utf8 Class Initialized
INFO - 2023-08-16 16:33:59 --> URI Class Initialized
INFO - 2023-08-16 16:33:59 --> Router Class Initialized
INFO - 2023-08-16 16:33:59 --> Output Class Initialized
INFO - 2023-08-16 16:33:59 --> Security Class Initialized
DEBUG - 2023-08-16 16:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:33:59 --> Input Class Initialized
INFO - 2023-08-16 16:33:59 --> Language Class Initialized
ERROR - 2023-08-16 16:33:59 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 16:33:59 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 16:33:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:34:00 --> Config Class Initialized
INFO - 2023-08-16 16:34:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:00 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:00 --> URI Class Initialized
INFO - 2023-08-16 16:34:00 --> Router Class Initialized
INFO - 2023-08-16 16:34:00 --> Output Class Initialized
INFO - 2023-08-16 16:34:00 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:00 --> Input Class Initialized
INFO - 2023-08-16 16:34:00 --> Language Class Initialized
ERROR - 2023-08-16 16:34:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:34:00 --> Config Class Initialized
INFO - 2023-08-16 16:34:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:00 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:00 --> URI Class Initialized
INFO - 2023-08-16 16:34:00 --> Router Class Initialized
INFO - 2023-08-16 16:34:00 --> Output Class Initialized
INFO - 2023-08-16 16:34:00 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:00 --> Input Class Initialized
INFO - 2023-08-16 16:34:00 --> Language Class Initialized
ERROR - 2023-08-16 16:34:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:34:00 --> Config Class Initialized
INFO - 2023-08-16 16:34:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:00 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:00 --> URI Class Initialized
INFO - 2023-08-16 16:34:00 --> Router Class Initialized
INFO - 2023-08-16 16:34:00 --> Output Class Initialized
INFO - 2023-08-16 16:34:00 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:00 --> Input Class Initialized
INFO - 2023-08-16 16:34:00 --> Language Class Initialized
ERROR - 2023-08-16 16:34:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:34:00 --> Config Class Initialized
INFO - 2023-08-16 16:34:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:00 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:00 --> URI Class Initialized
INFO - 2023-08-16 16:34:00 --> Router Class Initialized
INFO - 2023-08-16 16:34:00 --> Output Class Initialized
INFO - 2023-08-16 16:34:00 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:00 --> Input Class Initialized
INFO - 2023-08-16 16:34:00 --> Language Class Initialized
ERROR - 2023-08-16 16:34:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:34:00 --> Config Class Initialized
INFO - 2023-08-16 16:34:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:00 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:00 --> URI Class Initialized
INFO - 2023-08-16 16:34:00 --> Router Class Initialized
INFO - 2023-08-16 16:34:00 --> Output Class Initialized
INFO - 2023-08-16 16:34:00 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:00 --> Input Class Initialized
INFO - 2023-08-16 16:34:00 --> Language Class Initialized
ERROR - 2023-08-16 16:34:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:34:00 --> Config Class Initialized
INFO - 2023-08-16 16:34:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:00 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:00 --> URI Class Initialized
INFO - 2023-08-16 16:34:00 --> Router Class Initialized
INFO - 2023-08-16 16:34:00 --> Output Class Initialized
INFO - 2023-08-16 16:34:00 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:00 --> Input Class Initialized
INFO - 2023-08-16 16:34:00 --> Language Class Initialized
ERROR - 2023-08-16 16:34:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:34:00 --> Config Class Initialized
INFO - 2023-08-16 16:34:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:00 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:00 --> URI Class Initialized
INFO - 2023-08-16 16:34:00 --> Router Class Initialized
INFO - 2023-08-16 16:34:00 --> Output Class Initialized
INFO - 2023-08-16 16:34:00 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:00 --> Input Class Initialized
INFO - 2023-08-16 16:34:00 --> Language Class Initialized
ERROR - 2023-08-16 16:34:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:34:00 --> Config Class Initialized
INFO - 2023-08-16 16:34:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:00 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:00 --> URI Class Initialized
INFO - 2023-08-16 16:34:00 --> Router Class Initialized
INFO - 2023-08-16 16:34:00 --> Output Class Initialized
INFO - 2023-08-16 16:34:00 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:00 --> Input Class Initialized
INFO - 2023-08-16 16:34:00 --> Language Class Initialized
ERROR - 2023-08-16 16:34:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:34:00 --> Config Class Initialized
INFO - 2023-08-16 16:34:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:00 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:00 --> URI Class Initialized
INFO - 2023-08-16 16:34:00 --> Router Class Initialized
INFO - 2023-08-16 16:34:00 --> Output Class Initialized
INFO - 2023-08-16 16:34:00 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:00 --> Input Class Initialized
INFO - 2023-08-16 16:34:00 --> Language Class Initialized
ERROR - 2023-08-16 16:34:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:34:50 --> Config Class Initialized
INFO - 2023-08-16 16:34:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:50 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:50 --> URI Class Initialized
INFO - 2023-08-16 16:34:50 --> Router Class Initialized
INFO - 2023-08-16 16:34:50 --> Output Class Initialized
INFO - 2023-08-16 16:34:50 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:50 --> Input Class Initialized
INFO - 2023-08-16 16:34:50 --> Language Class Initialized
INFO - 2023-08-16 16:34:50 --> Loader Class Initialized
INFO - 2023-08-16 16:34:50 --> Helper loaded: url_helper
INFO - 2023-08-16 16:34:50 --> Helper loaded: file_helper
INFO - 2023-08-16 16:34:50 --> Database Driver Class Initialized
INFO - 2023-08-16 16:34:50 --> Email Class Initialized
DEBUG - 2023-08-16 16:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:34:50 --> Controller Class Initialized
INFO - 2023-08-16 16:34:50 --> Model "Home_model" initialized
INFO - 2023-08-16 16:34:50 --> Helper loaded: form_helper
INFO - 2023-08-16 16:34:50 --> Form Validation Class Initialized
INFO - 2023-08-16 16:34:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-16 16:34:50 --> Final output sent to browser
DEBUG - 2023-08-16 16:34:51 --> Total execution time: 0.5513
INFO - 2023-08-16 16:34:51 --> Config Class Initialized
INFO - 2023-08-16 16:34:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:51 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:51 --> URI Class Initialized
INFO - 2023-08-16 16:34:51 --> Router Class Initialized
INFO - 2023-08-16 16:34:51 --> Output Class Initialized
INFO - 2023-08-16 16:34:51 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:51 --> Input Class Initialized
INFO - 2023-08-16 16:34:51 --> Language Class Initialized
ERROR - 2023-08-16 16:34:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:34:51 --> Config Class Initialized
INFO - 2023-08-16 16:34:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:51 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:51 --> URI Class Initialized
INFO - 2023-08-16 16:34:51 --> Router Class Initialized
INFO - 2023-08-16 16:34:51 --> Output Class Initialized
INFO - 2023-08-16 16:34:51 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:51 --> Input Class Initialized
INFO - 2023-08-16 16:34:51 --> Language Class Initialized
ERROR - 2023-08-16 16:34:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:34:51 --> Config Class Initialized
INFO - 2023-08-16 16:34:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:51 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:51 --> URI Class Initialized
INFO - 2023-08-16 16:34:51 --> Router Class Initialized
INFO - 2023-08-16 16:34:51 --> Output Class Initialized
INFO - 2023-08-16 16:34:51 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:51 --> Input Class Initialized
INFO - 2023-08-16 16:34:51 --> Language Class Initialized
ERROR - 2023-08-16 16:34:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:34:52 --> Config Class Initialized
INFO - 2023-08-16 16:34:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:52 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:52 --> URI Class Initialized
INFO - 2023-08-16 16:34:52 --> Router Class Initialized
INFO - 2023-08-16 16:34:52 --> Output Class Initialized
INFO - 2023-08-16 16:34:52 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:52 --> Input Class Initialized
INFO - 2023-08-16 16:34:52 --> Language Class Initialized
ERROR - 2023-08-16 16:34:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:34:52 --> Config Class Initialized
INFO - 2023-08-16 16:34:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:52 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:52 --> URI Class Initialized
INFO - 2023-08-16 16:34:52 --> Router Class Initialized
INFO - 2023-08-16 16:34:52 --> Output Class Initialized
INFO - 2023-08-16 16:34:52 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:52 --> Input Class Initialized
INFO - 2023-08-16 16:34:52 --> Language Class Initialized
ERROR - 2023-08-16 16:34:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:34:52 --> Config Class Initialized
INFO - 2023-08-16 16:34:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:52 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:52 --> URI Class Initialized
INFO - 2023-08-16 16:34:52 --> Router Class Initialized
INFO - 2023-08-16 16:34:52 --> Output Class Initialized
INFO - 2023-08-16 16:34:52 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:52 --> Input Class Initialized
INFO - 2023-08-16 16:34:52 --> Language Class Initialized
ERROR - 2023-08-16 16:34:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:34:52 --> Config Class Initialized
INFO - 2023-08-16 16:34:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:52 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:52 --> URI Class Initialized
INFO - 2023-08-16 16:34:52 --> Router Class Initialized
INFO - 2023-08-16 16:34:52 --> Output Class Initialized
INFO - 2023-08-16 16:34:52 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:52 --> Input Class Initialized
INFO - 2023-08-16 16:34:52 --> Language Class Initialized
ERROR - 2023-08-16 16:34:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:34:52 --> Config Class Initialized
INFO - 2023-08-16 16:34:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:34:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:34:52 --> Utf8 Class Initialized
INFO - 2023-08-16 16:34:52 --> URI Class Initialized
INFO - 2023-08-16 16:34:52 --> Router Class Initialized
INFO - 2023-08-16 16:34:52 --> Output Class Initialized
INFO - 2023-08-16 16:34:52 --> Security Class Initialized
DEBUG - 2023-08-16 16:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:34:52 --> Input Class Initialized
INFO - 2023-08-16 16:34:52 --> Language Class Initialized
ERROR - 2023-08-16 16:34:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:36:49 --> Config Class Initialized
INFO - 2023-08-16 16:36:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:36:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:36:50 --> Utf8 Class Initialized
INFO - 2023-08-16 16:36:50 --> URI Class Initialized
INFO - 2023-08-16 16:36:50 --> Router Class Initialized
INFO - 2023-08-16 16:36:50 --> Output Class Initialized
INFO - 2023-08-16 16:36:50 --> Security Class Initialized
DEBUG - 2023-08-16 16:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:36:50 --> Input Class Initialized
INFO - 2023-08-16 16:36:50 --> Language Class Initialized
INFO - 2023-08-16 16:36:50 --> Loader Class Initialized
INFO - 2023-08-16 16:36:50 --> Helper loaded: url_helper
INFO - 2023-08-16 16:36:50 --> Helper loaded: file_helper
INFO - 2023-08-16 16:36:50 --> Database Driver Class Initialized
INFO - 2023-08-16 16:36:50 --> Email Class Initialized
DEBUG - 2023-08-16 16:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:36:50 --> Controller Class Initialized
INFO - 2023-08-16 16:36:50 --> Model "Home_model" initialized
INFO - 2023-08-16 16:36:50 --> Helper loaded: form_helper
INFO - 2023-08-16 16:36:50 --> Form Validation Class Initialized
INFO - 2023-08-16 16:36:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-16 16:36:50 --> Final output sent to browser
DEBUG - 2023-08-16 16:36:50 --> Total execution time: 0.5337
INFO - 2023-08-16 16:36:51 --> Config Class Initialized
INFO - 2023-08-16 16:36:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:36:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:36:51 --> Utf8 Class Initialized
INFO - 2023-08-16 16:36:51 --> URI Class Initialized
INFO - 2023-08-16 16:36:51 --> Router Class Initialized
INFO - 2023-08-16 16:36:51 --> Output Class Initialized
INFO - 2023-08-16 16:36:51 --> Security Class Initialized
DEBUG - 2023-08-16 16:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:36:51 --> Input Class Initialized
INFO - 2023-08-16 16:36:51 --> Language Class Initialized
ERROR - 2023-08-16 16:36:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:36:51 --> Config Class Initialized
INFO - 2023-08-16 16:36:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:36:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:36:51 --> Utf8 Class Initialized
INFO - 2023-08-16 16:36:51 --> URI Class Initialized
INFO - 2023-08-16 16:36:51 --> Router Class Initialized
INFO - 2023-08-16 16:36:51 --> Output Class Initialized
INFO - 2023-08-16 16:36:51 --> Security Class Initialized
DEBUG - 2023-08-16 16:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:36:51 --> Input Class Initialized
INFO - 2023-08-16 16:36:51 --> Language Class Initialized
ERROR - 2023-08-16 16:36:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:36:51 --> Config Class Initialized
INFO - 2023-08-16 16:36:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:36:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:36:51 --> Utf8 Class Initialized
INFO - 2023-08-16 16:36:51 --> URI Class Initialized
INFO - 2023-08-16 16:36:51 --> Router Class Initialized
INFO - 2023-08-16 16:36:51 --> Output Class Initialized
INFO - 2023-08-16 16:36:51 --> Security Class Initialized
DEBUG - 2023-08-16 16:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:36:51 --> Input Class Initialized
INFO - 2023-08-16 16:36:51 --> Language Class Initialized
ERROR - 2023-08-16 16:36:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:36:51 --> Config Class Initialized
INFO - 2023-08-16 16:36:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:36:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:36:51 --> Utf8 Class Initialized
INFO - 2023-08-16 16:36:51 --> URI Class Initialized
INFO - 2023-08-16 16:36:51 --> Router Class Initialized
INFO - 2023-08-16 16:36:51 --> Output Class Initialized
INFO - 2023-08-16 16:36:51 --> Security Class Initialized
DEBUG - 2023-08-16 16:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:36:51 --> Input Class Initialized
INFO - 2023-08-16 16:36:51 --> Language Class Initialized
ERROR - 2023-08-16 16:36:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:36:52 --> Config Class Initialized
INFO - 2023-08-16 16:36:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:36:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:36:52 --> Utf8 Class Initialized
INFO - 2023-08-16 16:36:52 --> URI Class Initialized
INFO - 2023-08-16 16:36:52 --> Router Class Initialized
INFO - 2023-08-16 16:36:52 --> Output Class Initialized
INFO - 2023-08-16 16:36:52 --> Security Class Initialized
DEBUG - 2023-08-16 16:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:36:52 --> Input Class Initialized
INFO - 2023-08-16 16:36:52 --> Language Class Initialized
ERROR - 2023-08-16 16:36:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:40:39 --> Config Class Initialized
INFO - 2023-08-16 16:40:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:40:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:40:39 --> Utf8 Class Initialized
INFO - 2023-08-16 16:40:39 --> URI Class Initialized
INFO - 2023-08-16 16:40:39 --> Router Class Initialized
INFO - 2023-08-16 16:40:39 --> Output Class Initialized
INFO - 2023-08-16 16:40:39 --> Security Class Initialized
DEBUG - 2023-08-16 16:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:40:39 --> Input Class Initialized
INFO - 2023-08-16 16:40:39 --> Language Class Initialized
INFO - 2023-08-16 16:40:39 --> Loader Class Initialized
INFO - 2023-08-16 16:40:39 --> Helper loaded: url_helper
INFO - 2023-08-16 16:40:39 --> Helper loaded: file_helper
INFO - 2023-08-16 16:40:39 --> Database Driver Class Initialized
INFO - 2023-08-16 16:40:39 --> Email Class Initialized
DEBUG - 2023-08-16 16:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:40:39 --> Controller Class Initialized
INFO - 2023-08-16 16:40:39 --> Model "Home_model" initialized
INFO - 2023-08-16 16:40:39 --> Helper loaded: form_helper
INFO - 2023-08-16 16:40:39 --> Form Validation Class Initialized
INFO - 2023-08-16 16:40:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-16 16:40:39 --> Final output sent to browser
DEBUG - 2023-08-16 16:40:40 --> Total execution time: 0.3613
INFO - 2023-08-16 16:40:40 --> Config Class Initialized
INFO - 2023-08-16 16:40:40 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:40:40 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:40:40 --> Utf8 Class Initialized
INFO - 2023-08-16 16:40:40 --> URI Class Initialized
INFO - 2023-08-16 16:40:40 --> Router Class Initialized
INFO - 2023-08-16 16:40:40 --> Output Class Initialized
INFO - 2023-08-16 16:40:40 --> Security Class Initialized
DEBUG - 2023-08-16 16:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:40:40 --> Input Class Initialized
INFO - 2023-08-16 16:40:40 --> Language Class Initialized
ERROR - 2023-08-16 16:40:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:40:40 --> Config Class Initialized
INFO - 2023-08-16 16:40:40 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:40:40 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:40:40 --> Utf8 Class Initialized
INFO - 2023-08-16 16:40:40 --> URI Class Initialized
INFO - 2023-08-16 16:40:40 --> Router Class Initialized
INFO - 2023-08-16 16:40:40 --> Output Class Initialized
INFO - 2023-08-16 16:40:40 --> Security Class Initialized
DEBUG - 2023-08-16 16:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:40:40 --> Input Class Initialized
INFO - 2023-08-16 16:40:40 --> Language Class Initialized
ERROR - 2023-08-16 16:40:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:40:40 --> Config Class Initialized
INFO - 2023-08-16 16:40:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:40:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:40:41 --> Utf8 Class Initialized
INFO - 2023-08-16 16:40:41 --> URI Class Initialized
INFO - 2023-08-16 16:40:41 --> Router Class Initialized
INFO - 2023-08-16 16:40:41 --> Output Class Initialized
INFO - 2023-08-16 16:40:41 --> Security Class Initialized
DEBUG - 2023-08-16 16:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:40:41 --> Input Class Initialized
INFO - 2023-08-16 16:40:41 --> Language Class Initialized
ERROR - 2023-08-16 16:40:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:40:41 --> Config Class Initialized
INFO - 2023-08-16 16:40:41 --> Hooks Class Initialized
INFO - 2023-08-16 16:40:41 --> Config Class Initialized
INFO - 2023-08-16 16:40:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:40:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:40:41 --> Utf8 Class Initialized
INFO - 2023-08-16 16:40:41 --> URI Class Initialized
INFO - 2023-08-16 16:40:41 --> Router Class Initialized
INFO - 2023-08-16 16:40:41 --> Output Class Initialized
INFO - 2023-08-16 16:40:41 --> Security Class Initialized
DEBUG - 2023-08-16 16:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:40:41 --> Input Class Initialized
INFO - 2023-08-16 16:40:41 --> Language Class Initialized
ERROR - 2023-08-16 16:40:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:40:41 --> Config Class Initialized
INFO - 2023-08-16 16:40:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:40:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:40:41 --> Utf8 Class Initialized
INFO - 2023-08-16 16:40:41 --> URI Class Initialized
INFO - 2023-08-16 16:40:41 --> Router Class Initialized
INFO - 2023-08-16 16:40:41 --> Output Class Initialized
INFO - 2023-08-16 16:40:41 --> Security Class Initialized
DEBUG - 2023-08-16 16:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:40:41 --> Input Class Initialized
INFO - 2023-08-16 16:40:41 --> Language Class Initialized
ERROR - 2023-08-16 16:40:41 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 16:40:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:40:41 --> Utf8 Class Initialized
INFO - 2023-08-16 16:40:41 --> URI Class Initialized
INFO - 2023-08-16 16:40:41 --> Router Class Initialized
INFO - 2023-08-16 16:40:41 --> Output Class Initialized
INFO - 2023-08-16 16:40:41 --> Security Class Initialized
DEBUG - 2023-08-16 16:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:40:41 --> Input Class Initialized
INFO - 2023-08-16 16:40:41 --> Language Class Initialized
ERROR - 2023-08-16 16:40:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:40:41 --> Config Class Initialized
INFO - 2023-08-16 16:40:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:40:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:40:41 --> Utf8 Class Initialized
INFO - 2023-08-16 16:40:41 --> URI Class Initialized
INFO - 2023-08-16 16:40:41 --> Router Class Initialized
INFO - 2023-08-16 16:40:41 --> Output Class Initialized
INFO - 2023-08-16 16:40:41 --> Security Class Initialized
DEBUG - 2023-08-16 16:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:40:41 --> Input Class Initialized
INFO - 2023-08-16 16:40:41 --> Language Class Initialized
ERROR - 2023-08-16 16:40:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:40:41 --> Config Class Initialized
INFO - 2023-08-16 16:40:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:40:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:40:41 --> Utf8 Class Initialized
INFO - 2023-08-16 16:40:41 --> URI Class Initialized
INFO - 2023-08-16 16:40:41 --> Router Class Initialized
INFO - 2023-08-16 16:40:41 --> Output Class Initialized
INFO - 2023-08-16 16:40:41 --> Security Class Initialized
DEBUG - 2023-08-16 16:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:40:41 --> Input Class Initialized
INFO - 2023-08-16 16:40:41 --> Language Class Initialized
ERROR - 2023-08-16 16:40:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:41:30 --> Config Class Initialized
INFO - 2023-08-16 16:41:30 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:41:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:41:30 --> Utf8 Class Initialized
INFO - 2023-08-16 16:41:30 --> URI Class Initialized
INFO - 2023-08-16 16:41:30 --> Router Class Initialized
INFO - 2023-08-16 16:41:30 --> Output Class Initialized
INFO - 2023-08-16 16:41:30 --> Security Class Initialized
DEBUG - 2023-08-16 16:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:41:30 --> Input Class Initialized
INFO - 2023-08-16 16:41:30 --> Language Class Initialized
INFO - 2023-08-16 16:41:30 --> Loader Class Initialized
INFO - 2023-08-16 16:41:30 --> Helper loaded: url_helper
INFO - 2023-08-16 16:41:30 --> Helper loaded: file_helper
INFO - 2023-08-16 16:41:30 --> Database Driver Class Initialized
INFO - 2023-08-16 16:41:30 --> Email Class Initialized
DEBUG - 2023-08-16 16:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:41:30 --> Controller Class Initialized
INFO - 2023-08-16 16:41:30 --> Model "Home_model" initialized
INFO - 2023-08-16 16:41:30 --> Helper loaded: form_helper
INFO - 2023-08-16 16:41:30 --> Form Validation Class Initialized
INFO - 2023-08-16 16:41:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-16 16:41:30 --> Final output sent to browser
DEBUG - 2023-08-16 16:41:31 --> Total execution time: 0.3424
INFO - 2023-08-16 16:41:31 --> Config Class Initialized
INFO - 2023-08-16 16:41:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:41:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:41:31 --> Utf8 Class Initialized
INFO - 2023-08-16 16:41:31 --> URI Class Initialized
INFO - 2023-08-16 16:41:31 --> Router Class Initialized
INFO - 2023-08-16 16:41:31 --> Output Class Initialized
INFO - 2023-08-16 16:41:31 --> Security Class Initialized
DEBUG - 2023-08-16 16:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:41:31 --> Input Class Initialized
INFO - 2023-08-16 16:41:31 --> Language Class Initialized
ERROR - 2023-08-16 16:41:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:41:31 --> Config Class Initialized
INFO - 2023-08-16 16:41:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:41:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:41:31 --> Utf8 Class Initialized
INFO - 2023-08-16 16:41:31 --> URI Class Initialized
INFO - 2023-08-16 16:41:31 --> Router Class Initialized
INFO - 2023-08-16 16:41:31 --> Output Class Initialized
INFO - 2023-08-16 16:41:31 --> Security Class Initialized
DEBUG - 2023-08-16 16:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:41:31 --> Input Class Initialized
INFO - 2023-08-16 16:41:31 --> Language Class Initialized
ERROR - 2023-08-16 16:41:31 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:41:31 --> Config Class Initialized
INFO - 2023-08-16 16:41:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:41:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:41:31 --> Utf8 Class Initialized
INFO - 2023-08-16 16:41:31 --> URI Class Initialized
INFO - 2023-08-16 16:41:31 --> Router Class Initialized
INFO - 2023-08-16 16:41:31 --> Output Class Initialized
INFO - 2023-08-16 16:41:31 --> Security Class Initialized
DEBUG - 2023-08-16 16:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:41:31 --> Input Class Initialized
INFO - 2023-08-16 16:41:31 --> Language Class Initialized
ERROR - 2023-08-16 16:41:31 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:41:31 --> Config Class Initialized
INFO - 2023-08-16 16:41:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:41:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:41:31 --> Utf8 Class Initialized
INFO - 2023-08-16 16:41:31 --> URI Class Initialized
INFO - 2023-08-16 16:41:31 --> Router Class Initialized
INFO - 2023-08-16 16:41:31 --> Output Class Initialized
INFO - 2023-08-16 16:41:31 --> Security Class Initialized
DEBUG - 2023-08-16 16:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:41:31 --> Input Class Initialized
INFO - 2023-08-16 16:41:31 --> Language Class Initialized
ERROR - 2023-08-16 16:41:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:41:31 --> Config Class Initialized
INFO - 2023-08-16 16:41:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:41:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:41:31 --> Utf8 Class Initialized
INFO - 2023-08-16 16:41:31 --> URI Class Initialized
INFO - 2023-08-16 16:41:31 --> Router Class Initialized
INFO - 2023-08-16 16:41:31 --> Output Class Initialized
INFO - 2023-08-16 16:41:31 --> Security Class Initialized
DEBUG - 2023-08-16 16:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:41:31 --> Input Class Initialized
INFO - 2023-08-16 16:41:31 --> Language Class Initialized
ERROR - 2023-08-16 16:41:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:41:31 --> Config Class Initialized
INFO - 2023-08-16 16:41:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:41:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:41:31 --> Utf8 Class Initialized
INFO - 2023-08-16 16:41:31 --> URI Class Initialized
INFO - 2023-08-16 16:41:31 --> Router Class Initialized
INFO - 2023-08-16 16:41:31 --> Output Class Initialized
INFO - 2023-08-16 16:41:31 --> Security Class Initialized
DEBUG - 2023-08-16 16:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:41:31 --> Input Class Initialized
INFO - 2023-08-16 16:41:31 --> Language Class Initialized
ERROR - 2023-08-16 16:41:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:41:32 --> Config Class Initialized
INFO - 2023-08-16 16:41:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:41:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:41:32 --> Utf8 Class Initialized
INFO - 2023-08-16 16:41:32 --> URI Class Initialized
INFO - 2023-08-16 16:41:32 --> Router Class Initialized
INFO - 2023-08-16 16:41:32 --> Output Class Initialized
INFO - 2023-08-16 16:41:32 --> Security Class Initialized
DEBUG - 2023-08-16 16:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:41:32 --> Input Class Initialized
INFO - 2023-08-16 16:41:32 --> Language Class Initialized
ERROR - 2023-08-16 16:41:32 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:41:32 --> Config Class Initialized
INFO - 2023-08-16 16:41:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:41:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:41:32 --> Utf8 Class Initialized
INFO - 2023-08-16 16:41:32 --> URI Class Initialized
INFO - 2023-08-16 16:41:32 --> Router Class Initialized
INFO - 2023-08-16 16:41:32 --> Output Class Initialized
INFO - 2023-08-16 16:41:32 --> Security Class Initialized
DEBUG - 2023-08-16 16:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:41:32 --> Input Class Initialized
INFO - 2023-08-16 16:41:32 --> Language Class Initialized
ERROR - 2023-08-16 16:41:32 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:41:32 --> Config Class Initialized
INFO - 2023-08-16 16:41:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:41:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:41:32 --> Utf8 Class Initialized
INFO - 2023-08-16 16:41:32 --> URI Class Initialized
INFO - 2023-08-16 16:41:32 --> Router Class Initialized
INFO - 2023-08-16 16:41:32 --> Output Class Initialized
INFO - 2023-08-16 16:41:32 --> Security Class Initialized
DEBUG - 2023-08-16 16:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:41:32 --> Input Class Initialized
INFO - 2023-08-16 16:41:32 --> Language Class Initialized
ERROR - 2023-08-16 16:41:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:41:32 --> Config Class Initialized
INFO - 2023-08-16 16:41:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:41:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:41:32 --> Utf8 Class Initialized
INFO - 2023-08-16 16:41:32 --> URI Class Initialized
INFO - 2023-08-16 16:41:32 --> Router Class Initialized
INFO - 2023-08-16 16:41:32 --> Output Class Initialized
INFO - 2023-08-16 16:41:32 --> Security Class Initialized
DEBUG - 2023-08-16 16:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:41:32 --> Input Class Initialized
INFO - 2023-08-16 16:41:32 --> Language Class Initialized
ERROR - 2023-08-16 16:41:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:46:45 --> Config Class Initialized
INFO - 2023-08-16 16:46:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:45 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:45 --> URI Class Initialized
INFO - 2023-08-16 16:46:45 --> Router Class Initialized
INFO - 2023-08-16 16:46:45 --> Output Class Initialized
INFO - 2023-08-16 16:46:45 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:45 --> Input Class Initialized
INFO - 2023-08-16 16:46:45 --> Language Class Initialized
INFO - 2023-08-16 16:46:45 --> Loader Class Initialized
INFO - 2023-08-16 16:46:45 --> Helper loaded: url_helper
INFO - 2023-08-16 16:46:45 --> Helper loaded: file_helper
INFO - 2023-08-16 16:46:45 --> Database Driver Class Initialized
INFO - 2023-08-16 16:46:45 --> Email Class Initialized
DEBUG - 2023-08-16 16:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:46:45 --> Controller Class Initialized
INFO - 2023-08-16 16:46:45 --> Model "Home_model" initialized
INFO - 2023-08-16 16:46:45 --> Helper loaded: form_helper
INFO - 2023-08-16 16:46:45 --> Form Validation Class Initialized
INFO - 2023-08-16 16:46:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-16 16:46:46 --> Final output sent to browser
DEBUG - 2023-08-16 16:46:46 --> Total execution time: 0.3514
INFO - 2023-08-16 16:46:46 --> Config Class Initialized
INFO - 2023-08-16 16:46:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:46 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:46 --> URI Class Initialized
INFO - 2023-08-16 16:46:46 --> Router Class Initialized
INFO - 2023-08-16 16:46:46 --> Output Class Initialized
INFO - 2023-08-16 16:46:46 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:46 --> Input Class Initialized
INFO - 2023-08-16 16:46:46 --> Language Class Initialized
ERROR - 2023-08-16 16:46:46 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:46:46 --> Config Class Initialized
INFO - 2023-08-16 16:46:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:46 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:46 --> URI Class Initialized
INFO - 2023-08-16 16:46:46 --> Router Class Initialized
INFO - 2023-08-16 16:46:46 --> Output Class Initialized
INFO - 2023-08-16 16:46:46 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:46 --> Input Class Initialized
INFO - 2023-08-16 16:46:46 --> Language Class Initialized
ERROR - 2023-08-16 16:46:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:46:47 --> Config Class Initialized
INFO - 2023-08-16 16:46:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:47 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:47 --> URI Class Initialized
INFO - 2023-08-16 16:46:47 --> Router Class Initialized
INFO - 2023-08-16 16:46:47 --> Output Class Initialized
INFO - 2023-08-16 16:46:47 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:47 --> Input Class Initialized
INFO - 2023-08-16 16:46:47 --> Language Class Initialized
ERROR - 2023-08-16 16:46:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:46:47 --> Config Class Initialized
INFO - 2023-08-16 16:46:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:47 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:47 --> URI Class Initialized
INFO - 2023-08-16 16:46:47 --> Router Class Initialized
INFO - 2023-08-16 16:46:47 --> Output Class Initialized
INFO - 2023-08-16 16:46:47 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:47 --> Input Class Initialized
INFO - 2023-08-16 16:46:47 --> Language Class Initialized
ERROR - 2023-08-16 16:46:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:46:47 --> Config Class Initialized
INFO - 2023-08-16 16:46:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:47 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:47 --> URI Class Initialized
INFO - 2023-08-16 16:46:47 --> Router Class Initialized
INFO - 2023-08-16 16:46:47 --> Output Class Initialized
INFO - 2023-08-16 16:46:47 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:47 --> Input Class Initialized
INFO - 2023-08-16 16:46:47 --> Language Class Initialized
ERROR - 2023-08-16 16:46:47 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:46:47 --> Config Class Initialized
INFO - 2023-08-16 16:46:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:47 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:47 --> URI Class Initialized
INFO - 2023-08-16 16:46:47 --> Router Class Initialized
INFO - 2023-08-16 16:46:47 --> Output Class Initialized
INFO - 2023-08-16 16:46:47 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:47 --> Input Class Initialized
INFO - 2023-08-16 16:46:47 --> Language Class Initialized
ERROR - 2023-08-16 16:46:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:46:47 --> Config Class Initialized
INFO - 2023-08-16 16:46:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:47 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:47 --> URI Class Initialized
INFO - 2023-08-16 16:46:47 --> Router Class Initialized
INFO - 2023-08-16 16:46:47 --> Output Class Initialized
INFO - 2023-08-16 16:46:47 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:47 --> Input Class Initialized
INFO - 2023-08-16 16:46:47 --> Language Class Initialized
ERROR - 2023-08-16 16:46:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:46:47 --> Config Class Initialized
INFO - 2023-08-16 16:46:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:48 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:48 --> URI Class Initialized
INFO - 2023-08-16 16:46:48 --> Router Class Initialized
INFO - 2023-08-16 16:46:48 --> Output Class Initialized
INFO - 2023-08-16 16:46:48 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:48 --> Input Class Initialized
INFO - 2023-08-16 16:46:48 --> Language Class Initialized
ERROR - 2023-08-16 16:46:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:47:08 --> Config Class Initialized
INFO - 2023-08-16 16:47:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:47:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:09 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:09 --> URI Class Initialized
INFO - 2023-08-16 16:47:09 --> Router Class Initialized
INFO - 2023-08-16 16:47:09 --> Output Class Initialized
INFO - 2023-08-16 16:47:09 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:09 --> Input Class Initialized
INFO - 2023-08-16 16:47:09 --> Language Class Initialized
ERROR - 2023-08-16 16:47:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:47:09 --> Config Class Initialized
INFO - 2023-08-16 16:47:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:47:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:09 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:09 --> URI Class Initialized
INFO - 2023-08-16 16:47:09 --> Router Class Initialized
INFO - 2023-08-16 16:47:09 --> Output Class Initialized
INFO - 2023-08-16 16:47:09 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:09 --> Input Class Initialized
INFO - 2023-08-16 16:47:09 --> Language Class Initialized
ERROR - 2023-08-16 16:47:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:47:09 --> Config Class Initialized
INFO - 2023-08-16 16:47:10 --> Hooks Class Initialized
INFO - 2023-08-16 16:47:10 --> Config Class Initialized
DEBUG - 2023-08-16 16:47:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:10 --> Hooks Class Initialized
INFO - 2023-08-16 16:47:10 --> Utf8 Class Initialized
DEBUG - 2023-08-16 16:47:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:10 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:11 --> URI Class Initialized
INFO - 2023-08-16 16:47:11 --> Router Class Initialized
INFO - 2023-08-16 16:47:11 --> Output Class Initialized
INFO - 2023-08-16 16:47:11 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:11 --> Input Class Initialized
INFO - 2023-08-16 16:47:11 --> Language Class Initialized
ERROR - 2023-08-16 16:47:11 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:47:11 --> URI Class Initialized
INFO - 2023-08-16 16:47:11 --> Router Class Initialized
INFO - 2023-08-16 16:47:11 --> Output Class Initialized
INFO - 2023-08-16 16:47:11 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:11 --> Input Class Initialized
INFO - 2023-08-16 16:47:11 --> Language Class Initialized
ERROR - 2023-08-16 16:47:11 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:47:12 --> Config Class Initialized
INFO - 2023-08-16 16:47:12 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:47:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:12 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:12 --> URI Class Initialized
INFO - 2023-08-16 16:47:12 --> Router Class Initialized
INFO - 2023-08-16 16:47:12 --> Output Class Initialized
INFO - 2023-08-16 16:47:12 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:12 --> Input Class Initialized
INFO - 2023-08-16 16:47:12 --> Language Class Initialized
ERROR - 2023-08-16 16:47:12 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:47:12 --> Config Class Initialized
INFO - 2023-08-16 16:47:12 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:47:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:13 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:13 --> URI Class Initialized
INFO - 2023-08-16 16:47:13 --> Router Class Initialized
INFO - 2023-08-16 16:47:13 --> Output Class Initialized
INFO - 2023-08-16 16:47:13 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:13 --> Input Class Initialized
INFO - 2023-08-16 16:47:13 --> Language Class Initialized
ERROR - 2023-08-16 16:47:13 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:47:14 --> Config Class Initialized
INFO - 2023-08-16 16:47:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:47:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:14 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:14 --> URI Class Initialized
INFO - 2023-08-16 16:47:14 --> Router Class Initialized
INFO - 2023-08-16 16:47:14 --> Output Class Initialized
INFO - 2023-08-16 16:47:14 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:14 --> Input Class Initialized
INFO - 2023-08-16 16:47:14 --> Language Class Initialized
ERROR - 2023-08-16 16:47:14 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:47:29 --> Config Class Initialized
INFO - 2023-08-16 16:47:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:47:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:29 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:29 --> URI Class Initialized
INFO - 2023-08-16 16:47:29 --> Router Class Initialized
INFO - 2023-08-16 16:47:29 --> Output Class Initialized
INFO - 2023-08-16 16:47:29 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:29 --> Input Class Initialized
INFO - 2023-08-16 16:47:29 --> Language Class Initialized
ERROR - 2023-08-16 16:47:29 --> 404 Page Not Found: Indexhtml/index
INFO - 2023-08-16 16:47:32 --> Config Class Initialized
INFO - 2023-08-16 16:47:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:47:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:32 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:32 --> URI Class Initialized
INFO - 2023-08-16 16:47:32 --> Router Class Initialized
INFO - 2023-08-16 16:47:32 --> Output Class Initialized
INFO - 2023-08-16 16:47:32 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:32 --> Input Class Initialized
INFO - 2023-08-16 16:47:32 --> Language Class Initialized
INFO - 2023-08-16 16:47:32 --> Loader Class Initialized
INFO - 2023-08-16 16:47:32 --> Helper loaded: url_helper
INFO - 2023-08-16 16:47:32 --> Helper loaded: file_helper
INFO - 2023-08-16 16:47:32 --> Database Driver Class Initialized
INFO - 2023-08-16 16:47:32 --> Email Class Initialized
DEBUG - 2023-08-16 16:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:47:32 --> Controller Class Initialized
INFO - 2023-08-16 16:47:32 --> Model "Home_model" initialized
INFO - 2023-08-16 16:47:32 --> Helper loaded: form_helper
INFO - 2023-08-16 16:47:32 --> Form Validation Class Initialized
INFO - 2023-08-16 16:47:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-16 16:47:32 --> Final output sent to browser
DEBUG - 2023-08-16 16:47:32 --> Total execution time: 0.0584
INFO - 2023-08-16 16:47:33 --> Config Class Initialized
INFO - 2023-08-16 16:47:33 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:47:33 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:33 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:33 --> URI Class Initialized
INFO - 2023-08-16 16:47:33 --> Router Class Initialized
INFO - 2023-08-16 16:47:33 --> Output Class Initialized
INFO - 2023-08-16 16:47:33 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:33 --> Input Class Initialized
INFO - 2023-08-16 16:47:33 --> Language Class Initialized
ERROR - 2023-08-16 16:47:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:47:34 --> Config Class Initialized
INFO - 2023-08-16 16:47:34 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:47:34 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:34 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:34 --> Config Class Initialized
INFO - 2023-08-16 16:47:34 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:47:34 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:34 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:34 --> URI Class Initialized
INFO - 2023-08-16 16:47:34 --> Router Class Initialized
INFO - 2023-08-16 16:47:34 --> Output Class Initialized
INFO - 2023-08-16 16:47:34 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:34 --> Input Class Initialized
INFO - 2023-08-16 16:47:34 --> Language Class Initialized
ERROR - 2023-08-16 16:47:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:47:34 --> URI Class Initialized
INFO - 2023-08-16 16:47:35 --> Router Class Initialized
INFO - 2023-08-16 16:47:35 --> Output Class Initialized
INFO - 2023-08-16 16:47:35 --> Config Class Initialized
INFO - 2023-08-16 16:47:35 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:47:35 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:35 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:35 --> URI Class Initialized
INFO - 2023-08-16 16:47:35 --> Router Class Initialized
INFO - 2023-08-16 16:47:35 --> Output Class Initialized
INFO - 2023-08-16 16:47:35 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:35 --> Input Class Initialized
INFO - 2023-08-16 16:47:35 --> Language Class Initialized
ERROR - 2023-08-16 16:47:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:47:35 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:35 --> Input Class Initialized
INFO - 2023-08-16 16:47:36 --> Language Class Initialized
ERROR - 2023-08-16 16:47:36 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:47:37 --> Config Class Initialized
INFO - 2023-08-16 16:47:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:47:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:37 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:37 --> URI Class Initialized
INFO - 2023-08-16 16:47:37 --> Router Class Initialized
INFO - 2023-08-16 16:47:37 --> Output Class Initialized
INFO - 2023-08-16 16:47:37 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:38 --> Input Class Initialized
INFO - 2023-08-16 16:47:38 --> Language Class Initialized
ERROR - 2023-08-16 16:47:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:47:38 --> Config Class Initialized
INFO - 2023-08-16 16:47:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:47:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:38 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:38 --> URI Class Initialized
INFO - 2023-08-16 16:47:38 --> Router Class Initialized
INFO - 2023-08-16 16:47:38 --> Output Class Initialized
INFO - 2023-08-16 16:47:38 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:38 --> Input Class Initialized
INFO - 2023-08-16 16:47:38 --> Language Class Initialized
INFO - 2023-08-16 16:47:38 --> Config Class Initialized
INFO - 2023-08-16 16:47:38 --> Hooks Class Initialized
ERROR - 2023-08-16 16:47:38 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 16:47:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:38 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:38 --> URI Class Initialized
INFO - 2023-08-16 16:47:38 --> Router Class Initialized
INFO - 2023-08-16 16:47:38 --> Output Class Initialized
INFO - 2023-08-16 16:47:38 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:38 --> Input Class Initialized
INFO - 2023-08-16 16:47:38 --> Language Class Initialized
ERROR - 2023-08-16 16:47:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:49:23 --> Config Class Initialized
INFO - 2023-08-16 16:49:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:49:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:49:23 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:23 --> URI Class Initialized
INFO - 2023-08-16 16:49:23 --> Router Class Initialized
INFO - 2023-08-16 16:49:23 --> Output Class Initialized
INFO - 2023-08-16 16:49:23 --> Security Class Initialized
DEBUG - 2023-08-16 16:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:23 --> Input Class Initialized
INFO - 2023-08-16 16:49:23 --> Language Class Initialized
INFO - 2023-08-16 16:49:23 --> Loader Class Initialized
INFO - 2023-08-16 16:49:23 --> Helper loaded: url_helper
INFO - 2023-08-16 16:49:23 --> Helper loaded: file_helper
INFO - 2023-08-16 16:49:23 --> Database Driver Class Initialized
INFO - 2023-08-16 16:49:23 --> Email Class Initialized
DEBUG - 2023-08-16 16:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:49:23 --> Controller Class Initialized
INFO - 2023-08-16 16:49:23 --> Model "Home_model" initialized
INFO - 2023-08-16 16:49:23 --> Helper loaded: form_helper
INFO - 2023-08-16 16:49:23 --> Form Validation Class Initialized
INFO - 2023-08-16 16:49:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-16 16:49:23 --> Final output sent to browser
DEBUG - 2023-08-16 16:49:23 --> Total execution time: 0.5860
INFO - 2023-08-16 16:49:24 --> Config Class Initialized
INFO - 2023-08-16 16:49:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:49:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:49:24 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:24 --> URI Class Initialized
INFO - 2023-08-16 16:49:24 --> Router Class Initialized
INFO - 2023-08-16 16:49:24 --> Output Class Initialized
INFO - 2023-08-16 16:49:24 --> Security Class Initialized
DEBUG - 2023-08-16 16:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:24 --> Input Class Initialized
INFO - 2023-08-16 16:49:24 --> Language Class Initialized
ERROR - 2023-08-16 16:49:24 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:49:24 --> Config Class Initialized
INFO - 2023-08-16 16:49:24 --> Hooks Class Initialized
INFO - 2023-08-16 16:49:24 --> Config Class Initialized
INFO - 2023-08-16 16:49:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:49:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:49:24 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:24 --> URI Class Initialized
INFO - 2023-08-16 16:49:24 --> Router Class Initialized
INFO - 2023-08-16 16:49:24 --> Output Class Initialized
INFO - 2023-08-16 16:49:24 --> Security Class Initialized
DEBUG - 2023-08-16 16:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:24 --> Input Class Initialized
INFO - 2023-08-16 16:49:24 --> Language Class Initialized
ERROR - 2023-08-16 16:49:24 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 16:49:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:49:24 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:24 --> URI Class Initialized
INFO - 2023-08-16 16:49:24 --> Router Class Initialized
INFO - 2023-08-16 16:49:24 --> Output Class Initialized
INFO - 2023-08-16 16:49:24 --> Security Class Initialized
DEBUG - 2023-08-16 16:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:24 --> Input Class Initialized
INFO - 2023-08-16 16:49:24 --> Language Class Initialized
ERROR - 2023-08-16 16:49:24 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:49:24 --> Config Class Initialized
INFO - 2023-08-16 16:49:24 --> Config Class Initialized
INFO - 2023-08-16 16:49:24 --> Config Class Initialized
INFO - 2023-08-16 16:49:24 --> Hooks Class Initialized
INFO - 2023-08-16 16:49:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:49:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 16:49:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:49:24 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:24 --> Hooks Class Initialized
INFO - 2023-08-16 16:49:24 --> URI Class Initialized
INFO - 2023-08-16 16:49:24 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:24 --> Config Class Initialized
INFO - 2023-08-16 16:49:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:49:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:49:24 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:24 --> URI Class Initialized
INFO - 2023-08-16 16:49:24 --> Router Class Initialized
INFO - 2023-08-16 16:49:24 --> Output Class Initialized
INFO - 2023-08-16 16:49:24 --> Security Class Initialized
DEBUG - 2023-08-16 16:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:24 --> Input Class Initialized
INFO - 2023-08-16 16:49:24 --> Language Class Initialized
ERROR - 2023-08-16 16:49:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:49:25 --> Router Class Initialized
DEBUG - 2023-08-16 16:49:25 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:49:25 --> Output Class Initialized
INFO - 2023-08-16 16:49:25 --> Security Class Initialized
INFO - 2023-08-16 16:49:25 --> URI Class Initialized
INFO - 2023-08-16 16:49:25 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:25 --> Router Class Initialized
DEBUG - 2023-08-16 16:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:25 --> Output Class Initialized
INFO - 2023-08-16 16:49:25 --> Input Class Initialized
INFO - 2023-08-16 16:49:25 --> URI Class Initialized
INFO - 2023-08-16 16:49:25 --> Security Class Initialized
INFO - 2023-08-16 16:49:25 --> Router Class Initialized
DEBUG - 2023-08-16 16:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:25 --> Language Class Initialized
ERROR - 2023-08-16 16:49:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:49:25 --> Output Class Initialized
INFO - 2023-08-16 16:49:25 --> Input Class Initialized
INFO - 2023-08-16 16:49:25 --> Security Class Initialized
INFO - 2023-08-16 16:49:25 --> Language Class Initialized
DEBUG - 2023-08-16 16:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 16:49:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:49:25 --> Input Class Initialized
INFO - 2023-08-16 16:49:25 --> Language Class Initialized
ERROR - 2023-08-16 16:49:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:49:30 --> Config Class Initialized
INFO - 2023-08-16 16:49:30 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:49:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:49:30 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:30 --> URI Class Initialized
INFO - 2023-08-16 16:49:30 --> Router Class Initialized
INFO - 2023-08-16 16:49:30 --> Output Class Initialized
INFO - 2023-08-16 16:49:30 --> Security Class Initialized
DEBUG - 2023-08-16 16:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:30 --> Input Class Initialized
INFO - 2023-08-16 16:49:30 --> Language Class Initialized
INFO - 2023-08-16 16:49:30 --> Loader Class Initialized
INFO - 2023-08-16 16:49:30 --> Helper loaded: url_helper
INFO - 2023-08-16 16:49:30 --> Helper loaded: file_helper
INFO - 2023-08-16 16:49:30 --> Database Driver Class Initialized
INFO - 2023-08-16 16:49:30 --> Email Class Initialized
DEBUG - 2023-08-16 16:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:49:30 --> Controller Class Initialized
INFO - 2023-08-16 16:49:30 --> Model "Home_model" initialized
INFO - 2023-08-16 16:49:30 --> Helper loaded: form_helper
INFO - 2023-08-16 16:49:30 --> Form Validation Class Initialized
INFO - 2023-08-16 16:49:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-16 16:49:31 --> Final output sent to browser
DEBUG - 2023-08-16 16:49:31 --> Total execution time: 0.6148
INFO - 2023-08-16 16:49:31 --> Config Class Initialized
INFO - 2023-08-16 16:49:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:49:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:49:31 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:31 --> URI Class Initialized
INFO - 2023-08-16 16:49:31 --> Router Class Initialized
INFO - 2023-08-16 16:49:31 --> Output Class Initialized
INFO - 2023-08-16 16:49:31 --> Security Class Initialized
DEBUG - 2023-08-16 16:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:31 --> Input Class Initialized
INFO - 2023-08-16 16:49:31 --> Language Class Initialized
ERROR - 2023-08-16 16:49:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:49:31 --> Config Class Initialized
INFO - 2023-08-16 16:49:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:49:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:49:31 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:32 --> Config Class Initialized
INFO - 2023-08-16 16:49:32 --> Config Class Initialized
INFO - 2023-08-16 16:49:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:49:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:49:32 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:32 --> URI Class Initialized
INFO - 2023-08-16 16:49:32 --> Router Class Initialized
INFO - 2023-08-16 16:49:32 --> Output Class Initialized
INFO - 2023-08-16 16:49:32 --> Security Class Initialized
DEBUG - 2023-08-16 16:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:32 --> Input Class Initialized
INFO - 2023-08-16 16:49:32 --> Language Class Initialized
ERROR - 2023-08-16 16:49:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:49:32 --> URI Class Initialized
INFO - 2023-08-16 16:49:32 --> Router Class Initialized
INFO - 2023-08-16 16:49:32 --> Output Class Initialized
INFO - 2023-08-16 16:49:32 --> Config Class Initialized
INFO - 2023-08-16 16:49:32 --> Security Class Initialized
INFO - 2023-08-16 16:49:32 --> Hooks Class Initialized
INFO - 2023-08-16 16:49:32 --> Config Class Initialized
DEBUG - 2023-08-16 16:49:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:49:32 --> Utf8 Class Initialized
DEBUG - 2023-08-16 16:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:32 --> URI Class Initialized
INFO - 2023-08-16 16:49:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:49:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:49:32 --> Router Class Initialized
INFO - 2023-08-16 16:49:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:49:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:49:32 --> Input Class Initialized
INFO - 2023-08-16 16:49:32 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:32 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:32 --> Output Class Initialized
INFO - 2023-08-16 16:49:32 --> Security Class Initialized
INFO - 2023-08-16 16:49:32 --> URI Class Initialized
INFO - 2023-08-16 16:49:32 --> Language Class Initialized
ERROR - 2023-08-16 16:49:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:49:32 --> URI Class Initialized
DEBUG - 2023-08-16 16:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:32 --> Router Class Initialized
INFO - 2023-08-16 16:49:32 --> Router Class Initialized
INFO - 2023-08-16 16:49:32 --> Output Class Initialized
INFO - 2023-08-16 16:49:32 --> Input Class Initialized
INFO - 2023-08-16 16:49:32 --> Output Class Initialized
INFO - 2023-08-16 16:49:32 --> Language Class Initialized
INFO - 2023-08-16 16:49:32 --> Security Class Initialized
INFO - 2023-08-16 16:49:32 --> Security Class Initialized
DEBUG - 2023-08-16 16:49:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 16:49:32 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:49:32 --> Config Class Initialized
INFO - 2023-08-16 16:49:32 --> Input Class Initialized
INFO - 2023-08-16 16:49:32 --> Hooks Class Initialized
INFO - 2023-08-16 16:49:32 --> Language Class Initialized
DEBUG - 2023-08-16 16:49:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 16:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:32 --> Utf8 Class Initialized
ERROR - 2023-08-16 16:49:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:49:33 --> URI Class Initialized
INFO - 2023-08-16 16:49:33 --> Input Class Initialized
INFO - 2023-08-16 16:49:33 --> Config Class Initialized
INFO - 2023-08-16 16:49:33 --> Router Class Initialized
INFO - 2023-08-16 16:49:33 --> Hooks Class Initialized
INFO - 2023-08-16 16:49:33 --> Language Class Initialized
DEBUG - 2023-08-16 16:49:33 --> UTF-8 Support Enabled
ERROR - 2023-08-16 16:49:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:49:33 --> Output Class Initialized
INFO - 2023-08-16 16:49:33 --> Utf8 Class Initialized
INFO - 2023-08-16 16:49:33 --> Security Class Initialized
INFO - 2023-08-16 16:49:33 --> URI Class Initialized
DEBUG - 2023-08-16 16:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:33 --> Router Class Initialized
INFO - 2023-08-16 16:49:33 --> Input Class Initialized
INFO - 2023-08-16 16:49:33 --> Output Class Initialized
INFO - 2023-08-16 16:49:33 --> Language Class Initialized
ERROR - 2023-08-16 16:49:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:49:33 --> Security Class Initialized
DEBUG - 2023-08-16 16:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:49:33 --> Input Class Initialized
INFO - 2023-08-16 16:49:33 --> Language Class Initialized
ERROR - 2023-08-16 16:49:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:52:19 --> Config Class Initialized
INFO - 2023-08-16 16:52:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:52:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:52:19 --> Utf8 Class Initialized
INFO - 2023-08-16 16:52:19 --> URI Class Initialized
INFO - 2023-08-16 16:52:19 --> Router Class Initialized
INFO - 2023-08-16 16:52:19 --> Output Class Initialized
INFO - 2023-08-16 16:52:20 --> Security Class Initialized
DEBUG - 2023-08-16 16:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:52:20 --> Input Class Initialized
INFO - 2023-08-16 16:52:20 --> Language Class Initialized
INFO - 2023-08-16 16:52:20 --> Loader Class Initialized
INFO - 2023-08-16 16:52:20 --> Helper loaded: url_helper
INFO - 2023-08-16 16:52:20 --> Helper loaded: file_helper
INFO - 2023-08-16 16:52:20 --> Database Driver Class Initialized
INFO - 2023-08-16 16:52:20 --> Email Class Initialized
DEBUG - 2023-08-16 16:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:52:20 --> Controller Class Initialized
INFO - 2023-08-16 16:52:20 --> Model "Home_model" initialized
INFO - 2023-08-16 16:52:20 --> Helper loaded: form_helper
INFO - 2023-08-16 16:52:20 --> Form Validation Class Initialized
INFO - 2023-08-16 16:52:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-16 16:52:20 --> Final output sent to browser
DEBUG - 2023-08-16 16:52:20 --> Total execution time: 0.3675
INFO - 2023-08-16 16:52:20 --> Config Class Initialized
INFO - 2023-08-16 16:52:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:52:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:52:20 --> Utf8 Class Initialized
INFO - 2023-08-16 16:52:20 --> URI Class Initialized
INFO - 2023-08-16 16:52:20 --> Router Class Initialized
INFO - 2023-08-16 16:52:20 --> Output Class Initialized
INFO - 2023-08-16 16:52:20 --> Security Class Initialized
DEBUG - 2023-08-16 16:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:52:20 --> Input Class Initialized
INFO - 2023-08-16 16:52:20 --> Language Class Initialized
ERROR - 2023-08-16 16:52:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:52:20 --> Config Class Initialized
INFO - 2023-08-16 16:52:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:52:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:52:20 --> Utf8 Class Initialized
INFO - 2023-08-16 16:52:20 --> URI Class Initialized
INFO - 2023-08-16 16:52:20 --> Router Class Initialized
INFO - 2023-08-16 16:52:20 --> Output Class Initialized
INFO - 2023-08-16 16:52:20 --> Security Class Initialized
DEBUG - 2023-08-16 16:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:52:20 --> Input Class Initialized
INFO - 2023-08-16 16:52:20 --> Language Class Initialized
ERROR - 2023-08-16 16:52:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:52:21 --> Config Class Initialized
INFO - 2023-08-16 16:52:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:52:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:52:21 --> Utf8 Class Initialized
INFO - 2023-08-16 16:52:21 --> URI Class Initialized
INFO - 2023-08-16 16:52:21 --> Router Class Initialized
INFO - 2023-08-16 16:52:21 --> Output Class Initialized
INFO - 2023-08-16 16:52:21 --> Security Class Initialized
DEBUG - 2023-08-16 16:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:52:21 --> Input Class Initialized
INFO - 2023-08-16 16:52:21 --> Language Class Initialized
ERROR - 2023-08-16 16:52:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:52:21 --> Config Class Initialized
INFO - 2023-08-16 16:52:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:52:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:52:21 --> Utf8 Class Initialized
INFO - 2023-08-16 16:52:21 --> URI Class Initialized
INFO - 2023-08-16 16:52:21 --> Router Class Initialized
INFO - 2023-08-16 16:52:21 --> Output Class Initialized
INFO - 2023-08-16 16:52:21 --> Security Class Initialized
DEBUG - 2023-08-16 16:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:52:21 --> Input Class Initialized
INFO - 2023-08-16 16:52:21 --> Language Class Initialized
ERROR - 2023-08-16 16:52:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:52:21 --> Config Class Initialized
INFO - 2023-08-16 16:52:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:52:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:52:21 --> Utf8 Class Initialized
INFO - 2023-08-16 16:52:21 --> URI Class Initialized
INFO - 2023-08-16 16:52:21 --> Router Class Initialized
INFO - 2023-08-16 16:52:21 --> Output Class Initialized
INFO - 2023-08-16 16:52:21 --> Security Class Initialized
DEBUG - 2023-08-16 16:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:52:21 --> Input Class Initialized
INFO - 2023-08-16 16:52:21 --> Language Class Initialized
ERROR - 2023-08-16 16:52:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:52:21 --> Config Class Initialized
INFO - 2023-08-16 16:52:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:52:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:52:21 --> Utf8 Class Initialized
INFO - 2023-08-16 16:52:21 --> URI Class Initialized
INFO - 2023-08-16 16:52:21 --> Router Class Initialized
INFO - 2023-08-16 16:52:21 --> Output Class Initialized
INFO - 2023-08-16 16:52:21 --> Security Class Initialized
DEBUG - 2023-08-16 16:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:52:21 --> Input Class Initialized
INFO - 2023-08-16 16:52:21 --> Language Class Initialized
ERROR - 2023-08-16 16:52:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:52:21 --> Config Class Initialized
INFO - 2023-08-16 16:52:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:52:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:52:21 --> Utf8 Class Initialized
INFO - 2023-08-16 16:52:21 --> URI Class Initialized
INFO - 2023-08-16 16:52:21 --> Router Class Initialized
INFO - 2023-08-16 16:52:21 --> Output Class Initialized
INFO - 2023-08-16 16:52:21 --> Security Class Initialized
DEBUG - 2023-08-16 16:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:52:21 --> Input Class Initialized
INFO - 2023-08-16 16:52:21 --> Language Class Initialized
ERROR - 2023-08-16 16:52:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:52:21 --> Config Class Initialized
INFO - 2023-08-16 16:52:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:52:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:52:22 --> Utf8 Class Initialized
INFO - 2023-08-16 16:52:22 --> URI Class Initialized
INFO - 2023-08-16 16:52:22 --> Router Class Initialized
INFO - 2023-08-16 16:52:22 --> Output Class Initialized
INFO - 2023-08-16 16:52:22 --> Security Class Initialized
DEBUG - 2023-08-16 16:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:52:22 --> Input Class Initialized
INFO - 2023-08-16 16:52:22 --> Language Class Initialized
ERROR - 2023-08-16 16:52:22 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:54:21 --> Config Class Initialized
INFO - 2023-08-16 16:54:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:21 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:21 --> URI Class Initialized
INFO - 2023-08-16 16:54:21 --> Router Class Initialized
INFO - 2023-08-16 16:54:21 --> Output Class Initialized
INFO - 2023-08-16 16:54:21 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:21 --> Input Class Initialized
INFO - 2023-08-16 16:54:21 --> Language Class Initialized
INFO - 2023-08-16 16:54:21 --> Loader Class Initialized
INFO - 2023-08-16 16:54:21 --> Helper loaded: url_helper
INFO - 2023-08-16 16:54:21 --> Helper loaded: file_helper
INFO - 2023-08-16 16:54:21 --> Database Driver Class Initialized
INFO - 2023-08-16 16:54:21 --> Email Class Initialized
DEBUG - 2023-08-16 16:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:54:21 --> Controller Class Initialized
INFO - 2023-08-16 16:54:21 --> Model "Home_model" initialized
INFO - 2023-08-16 16:54:21 --> Helper loaded: form_helper
INFO - 2023-08-16 16:54:21 --> Form Validation Class Initialized
INFO - 2023-08-16 16:54:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-16 16:54:22 --> Final output sent to browser
DEBUG - 2023-08-16 16:54:22 --> Total execution time: 0.3449
INFO - 2023-08-16 16:54:22 --> Config Class Initialized
INFO - 2023-08-16 16:54:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:22 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:22 --> URI Class Initialized
INFO - 2023-08-16 16:54:22 --> Router Class Initialized
INFO - 2023-08-16 16:54:22 --> Output Class Initialized
INFO - 2023-08-16 16:54:22 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:22 --> Input Class Initialized
INFO - 2023-08-16 16:54:22 --> Language Class Initialized
ERROR - 2023-08-16 16:54:22 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:54:22 --> Config Class Initialized
INFO - 2023-08-16 16:54:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:22 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:22 --> URI Class Initialized
INFO - 2023-08-16 16:54:22 --> Router Class Initialized
INFO - 2023-08-16 16:54:22 --> Output Class Initialized
INFO - 2023-08-16 16:54:22 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:22 --> Input Class Initialized
INFO - 2023-08-16 16:54:22 --> Language Class Initialized
ERROR - 2023-08-16 16:54:22 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:54:22 --> Config Class Initialized
INFO - 2023-08-16 16:54:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:22 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:22 --> URI Class Initialized
INFO - 2023-08-16 16:54:22 --> Router Class Initialized
INFO - 2023-08-16 16:54:22 --> Output Class Initialized
INFO - 2023-08-16 16:54:22 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:22 --> Input Class Initialized
INFO - 2023-08-16 16:54:22 --> Language Class Initialized
ERROR - 2023-08-16 16:54:22 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:54:22 --> Config Class Initialized
INFO - 2023-08-16 16:54:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:22 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:22 --> URI Class Initialized
INFO - 2023-08-16 16:54:22 --> Router Class Initialized
INFO - 2023-08-16 16:54:23 --> Output Class Initialized
INFO - 2023-08-16 16:54:23 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:23 --> Input Class Initialized
INFO - 2023-08-16 16:54:23 --> Language Class Initialized
ERROR - 2023-08-16 16:54:23 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:54:23 --> Config Class Initialized
INFO - 2023-08-16 16:54:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:23 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:23 --> URI Class Initialized
INFO - 2023-08-16 16:54:23 --> Router Class Initialized
INFO - 2023-08-16 16:54:23 --> Output Class Initialized
INFO - 2023-08-16 16:54:23 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:23 --> Input Class Initialized
INFO - 2023-08-16 16:54:23 --> Language Class Initialized
ERROR - 2023-08-16 16:54:23 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:54:23 --> Config Class Initialized
INFO - 2023-08-16 16:54:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:23 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:23 --> URI Class Initialized
INFO - 2023-08-16 16:54:23 --> Router Class Initialized
INFO - 2023-08-16 16:54:23 --> Output Class Initialized
INFO - 2023-08-16 16:54:23 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:23 --> Input Class Initialized
INFO - 2023-08-16 16:54:23 --> Language Class Initialized
ERROR - 2023-08-16 16:54:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:54:23 --> Config Class Initialized
INFO - 2023-08-16 16:54:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:23 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:23 --> URI Class Initialized
INFO - 2023-08-16 16:54:23 --> Router Class Initialized
INFO - 2023-08-16 16:54:23 --> Output Class Initialized
INFO - 2023-08-16 16:54:23 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:23 --> Input Class Initialized
INFO - 2023-08-16 16:54:23 --> Language Class Initialized
ERROR - 2023-08-16 16:54:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:54:23 --> Config Class Initialized
INFO - 2023-08-16 16:54:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:23 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:23 --> URI Class Initialized
INFO - 2023-08-16 16:54:23 --> Router Class Initialized
INFO - 2023-08-16 16:54:23 --> Output Class Initialized
INFO - 2023-08-16 16:54:23 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:23 --> Input Class Initialized
INFO - 2023-08-16 16:54:23 --> Language Class Initialized
ERROR - 2023-08-16 16:54:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:54:23 --> Config Class Initialized
INFO - 2023-08-16 16:54:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:23 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:23 --> URI Class Initialized
INFO - 2023-08-16 16:54:23 --> Router Class Initialized
INFO - 2023-08-16 16:54:23 --> Output Class Initialized
INFO - 2023-08-16 16:54:23 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:23 --> Input Class Initialized
INFO - 2023-08-16 16:54:23 --> Language Class Initialized
ERROR - 2023-08-16 16:54:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:54:23 --> Config Class Initialized
INFO - 2023-08-16 16:54:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:23 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:23 --> URI Class Initialized
INFO - 2023-08-16 16:54:23 --> Router Class Initialized
INFO - 2023-08-16 16:54:23 --> Output Class Initialized
INFO - 2023-08-16 16:54:23 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:23 --> Input Class Initialized
INFO - 2023-08-16 16:54:23 --> Language Class Initialized
ERROR - 2023-08-16 16:54:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:54:24 --> Config Class Initialized
INFO - 2023-08-16 16:54:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:24 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:24 --> URI Class Initialized
INFO - 2023-08-16 16:54:24 --> Router Class Initialized
INFO - 2023-08-16 16:54:24 --> Output Class Initialized
INFO - 2023-08-16 16:54:24 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:24 --> Input Class Initialized
INFO - 2023-08-16 16:54:24 --> Language Class Initialized
ERROR - 2023-08-16 16:54:24 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:54:24 --> Config Class Initialized
INFO - 2023-08-16 16:54:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:24 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:24 --> URI Class Initialized
INFO - 2023-08-16 16:54:24 --> Router Class Initialized
INFO - 2023-08-16 16:54:24 --> Output Class Initialized
INFO - 2023-08-16 16:54:24 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:24 --> Input Class Initialized
INFO - 2023-08-16 16:54:24 --> Language Class Initialized
ERROR - 2023-08-16 16:54:24 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:54:44 --> Config Class Initialized
INFO - 2023-08-16 16:54:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:44 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:44 --> URI Class Initialized
INFO - 2023-08-16 16:54:44 --> Router Class Initialized
INFO - 2023-08-16 16:54:44 --> Output Class Initialized
INFO - 2023-08-16 16:54:44 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:44 --> Input Class Initialized
INFO - 2023-08-16 16:54:44 --> Language Class Initialized
INFO - 2023-08-16 16:54:44 --> Loader Class Initialized
INFO - 2023-08-16 16:54:44 --> Helper loaded: url_helper
INFO - 2023-08-16 16:54:44 --> Helper loaded: file_helper
INFO - 2023-08-16 16:54:44 --> Database Driver Class Initialized
INFO - 2023-08-16 16:54:44 --> Email Class Initialized
DEBUG - 2023-08-16 16:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:54:44 --> Controller Class Initialized
INFO - 2023-08-16 16:54:44 --> Model "Home_model" initialized
INFO - 2023-08-16 16:54:44 --> Helper loaded: form_helper
INFO - 2023-08-16 16:54:44 --> Form Validation Class Initialized
INFO - 2023-08-16 16:54:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-16 16:54:44 --> Final output sent to browser
DEBUG - 2023-08-16 16:54:44 --> Total execution time: 0.3719
INFO - 2023-08-16 16:54:45 --> Config Class Initialized
INFO - 2023-08-16 16:54:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:45 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:45 --> URI Class Initialized
INFO - 2023-08-16 16:54:45 --> Router Class Initialized
INFO - 2023-08-16 16:54:45 --> Output Class Initialized
INFO - 2023-08-16 16:54:45 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:45 --> Input Class Initialized
INFO - 2023-08-16 16:54:45 --> Language Class Initialized
ERROR - 2023-08-16 16:54:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:54:45 --> Config Class Initialized
INFO - 2023-08-16 16:54:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:45 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:45 --> URI Class Initialized
INFO - 2023-08-16 16:54:45 --> Router Class Initialized
INFO - 2023-08-16 16:54:45 --> Output Class Initialized
INFO - 2023-08-16 16:54:45 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:45 --> Input Class Initialized
INFO - 2023-08-16 16:54:45 --> Language Class Initialized
ERROR - 2023-08-16 16:54:45 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:54:45 --> Config Class Initialized
INFO - 2023-08-16 16:54:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:45 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:45 --> URI Class Initialized
INFO - 2023-08-16 16:54:45 --> Router Class Initialized
INFO - 2023-08-16 16:54:45 --> Output Class Initialized
INFO - 2023-08-16 16:54:45 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:45 --> Input Class Initialized
INFO - 2023-08-16 16:54:45 --> Language Class Initialized
ERROR - 2023-08-16 16:54:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:54:45 --> Config Class Initialized
INFO - 2023-08-16 16:54:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:45 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:45 --> URI Class Initialized
INFO - 2023-08-16 16:54:45 --> Router Class Initialized
INFO - 2023-08-16 16:54:45 --> Output Class Initialized
INFO - 2023-08-16 16:54:45 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:45 --> Input Class Initialized
INFO - 2023-08-16 16:54:45 --> Language Class Initialized
ERROR - 2023-08-16 16:54:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:54:46 --> Config Class Initialized
INFO - 2023-08-16 16:54:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:46 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:46 --> URI Class Initialized
INFO - 2023-08-16 16:54:46 --> Router Class Initialized
INFO - 2023-08-16 16:54:46 --> Output Class Initialized
INFO - 2023-08-16 16:54:46 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:46 --> Input Class Initialized
INFO - 2023-08-16 16:54:46 --> Language Class Initialized
ERROR - 2023-08-16 16:54:46 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:54:46 --> Config Class Initialized
INFO - 2023-08-16 16:54:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:46 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:46 --> URI Class Initialized
INFO - 2023-08-16 16:54:46 --> Router Class Initialized
INFO - 2023-08-16 16:54:46 --> Output Class Initialized
INFO - 2023-08-16 16:54:46 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:46 --> Input Class Initialized
INFO - 2023-08-16 16:54:46 --> Language Class Initialized
ERROR - 2023-08-16 16:54:46 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:54:46 --> Config Class Initialized
INFO - 2023-08-16 16:54:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:46 --> Config Class Initialized
INFO - 2023-08-16 16:54:46 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:46 --> Hooks Class Initialized
INFO - 2023-08-16 16:54:46 --> URI Class Initialized
DEBUG - 2023-08-16 16:54:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:46 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:46 --> URI Class Initialized
INFO - 2023-08-16 16:54:46 --> Router Class Initialized
INFO - 2023-08-16 16:54:46 --> Output Class Initialized
INFO - 2023-08-16 16:54:46 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:46 --> Input Class Initialized
INFO - 2023-08-16 16:54:46 --> Language Class Initialized
ERROR - 2023-08-16 16:54:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:54:46 --> Router Class Initialized
INFO - 2023-08-16 16:54:46 --> Output Class Initialized
INFO - 2023-08-16 16:54:46 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:46 --> Input Class Initialized
INFO - 2023-08-16 16:54:46 --> Language Class Initialized
ERROR - 2023-08-16 16:54:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:54:46 --> Config Class Initialized
INFO - 2023-08-16 16:54:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:54:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:54:46 --> Utf8 Class Initialized
INFO - 2023-08-16 16:54:46 --> URI Class Initialized
INFO - 2023-08-16 16:54:46 --> Router Class Initialized
INFO - 2023-08-16 16:54:46 --> Output Class Initialized
INFO - 2023-08-16 16:54:46 --> Security Class Initialized
DEBUG - 2023-08-16 16:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:54:46 --> Input Class Initialized
INFO - 2023-08-16 16:54:46 --> Language Class Initialized
ERROR - 2023-08-16 16:54:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:55:00 --> Config Class Initialized
INFO - 2023-08-16 16:55:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:55:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:55:00 --> Utf8 Class Initialized
INFO - 2023-08-16 16:55:00 --> URI Class Initialized
INFO - 2023-08-16 16:55:00 --> Router Class Initialized
INFO - 2023-08-16 16:55:00 --> Output Class Initialized
INFO - 2023-08-16 16:55:00 --> Security Class Initialized
DEBUG - 2023-08-16 16:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:55:00 --> Input Class Initialized
INFO - 2023-08-16 16:55:00 --> Language Class Initialized
ERROR - 2023-08-16 16:55:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:55:00 --> Config Class Initialized
INFO - 2023-08-16 16:55:00 --> Config Class Initialized
INFO - 2023-08-16 16:55:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:55:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:55:00 --> Utf8 Class Initialized
INFO - 2023-08-16 16:55:00 --> URI Class Initialized
INFO - 2023-08-16 16:55:00 --> Router Class Initialized
INFO - 2023-08-16 16:55:00 --> Output Class Initialized
INFO - 2023-08-16 16:55:00 --> Security Class Initialized
DEBUG - 2023-08-16 16:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:55:00 --> Input Class Initialized
INFO - 2023-08-16 16:55:00 --> Language Class Initialized
ERROR - 2023-08-16 16:55:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:55:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:55:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:55:01 --> Utf8 Class Initialized
INFO - 2023-08-16 16:55:01 --> URI Class Initialized
INFO - 2023-08-16 16:55:01 --> Router Class Initialized
INFO - 2023-08-16 16:55:01 --> Output Class Initialized
INFO - 2023-08-16 16:55:01 --> Security Class Initialized
DEBUG - 2023-08-16 16:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:55:01 --> Input Class Initialized
INFO - 2023-08-16 16:55:01 --> Language Class Initialized
ERROR - 2023-08-16 16:55:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:55:01 --> Config Class Initialized
INFO - 2023-08-16 16:55:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:55:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:55:01 --> Utf8 Class Initialized
INFO - 2023-08-16 16:55:01 --> URI Class Initialized
INFO - 2023-08-16 16:55:01 --> Router Class Initialized
INFO - 2023-08-16 16:55:01 --> Output Class Initialized
INFO - 2023-08-16 16:55:01 --> Security Class Initialized
DEBUG - 2023-08-16 16:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:55:01 --> Input Class Initialized
INFO - 2023-08-16 16:55:01 --> Language Class Initialized
ERROR - 2023-08-16 16:55:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:55:01 --> Config Class Initialized
INFO - 2023-08-16 16:55:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:55:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:55:01 --> Utf8 Class Initialized
INFO - 2023-08-16 16:55:01 --> URI Class Initialized
INFO - 2023-08-16 16:55:01 --> Router Class Initialized
INFO - 2023-08-16 16:55:01 --> Output Class Initialized
INFO - 2023-08-16 16:55:01 --> Security Class Initialized
DEBUG - 2023-08-16 16:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:55:01 --> Input Class Initialized
INFO - 2023-08-16 16:55:01 --> Language Class Initialized
ERROR - 2023-08-16 16:55:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:55:01 --> Config Class Initialized
INFO - 2023-08-16 16:55:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:55:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:55:01 --> Utf8 Class Initialized
INFO - 2023-08-16 16:55:01 --> URI Class Initialized
INFO - 2023-08-16 16:55:01 --> Router Class Initialized
INFO - 2023-08-16 16:55:01 --> Output Class Initialized
INFO - 2023-08-16 16:55:01 --> Security Class Initialized
DEBUG - 2023-08-16 16:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:55:01 --> Input Class Initialized
INFO - 2023-08-16 16:55:01 --> Language Class Initialized
ERROR - 2023-08-16 16:55:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:55:01 --> Config Class Initialized
INFO - 2023-08-16 16:55:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:55:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:55:02 --> Utf8 Class Initialized
INFO - 2023-08-16 16:55:02 --> URI Class Initialized
INFO - 2023-08-16 16:55:02 --> Router Class Initialized
INFO - 2023-08-16 16:55:02 --> Output Class Initialized
INFO - 2023-08-16 16:55:02 --> Security Class Initialized
DEBUG - 2023-08-16 16:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:55:02 --> Input Class Initialized
INFO - 2023-08-16 16:55:02 --> Language Class Initialized
ERROR - 2023-08-16 16:55:02 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 16:56:51 --> Config Class Initialized
INFO - 2023-08-16 16:56:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:56:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:56:51 --> Utf8 Class Initialized
INFO - 2023-08-16 16:56:51 --> URI Class Initialized
INFO - 2023-08-16 16:56:51 --> Router Class Initialized
INFO - 2023-08-16 16:56:51 --> Output Class Initialized
INFO - 2023-08-16 16:56:51 --> Security Class Initialized
DEBUG - 2023-08-16 16:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:56:51 --> Input Class Initialized
INFO - 2023-08-16 16:56:51 --> Language Class Initialized
INFO - 2023-08-16 16:56:51 --> Loader Class Initialized
INFO - 2023-08-16 16:56:51 --> Helper loaded: url_helper
INFO - 2023-08-16 16:56:51 --> Helper loaded: file_helper
INFO - 2023-08-16 16:56:51 --> Database Driver Class Initialized
INFO - 2023-08-16 16:56:51 --> Email Class Initialized
DEBUG - 2023-08-16 16:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 16:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:56:51 --> Controller Class Initialized
INFO - 2023-08-16 16:56:51 --> Model "Home_model" initialized
INFO - 2023-08-16 16:56:51 --> Helper loaded: form_helper
INFO - 2023-08-16 16:56:51 --> Form Validation Class Initialized
INFO - 2023-08-16 16:56:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 16:56:52 --> Final output sent to browser
DEBUG - 2023-08-16 16:56:52 --> Total execution time: 0.5606
INFO - 2023-08-16 16:56:54 --> Config Class Initialized
INFO - 2023-08-16 16:56:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:56:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:56:54 --> Utf8 Class Initialized
INFO - 2023-08-16 16:56:54 --> URI Class Initialized
INFO - 2023-08-16 16:56:54 --> Router Class Initialized
INFO - 2023-08-16 16:56:54 --> Output Class Initialized
INFO - 2023-08-16 16:56:54 --> Security Class Initialized
DEBUG - 2023-08-16 16:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:56:54 --> Input Class Initialized
INFO - 2023-08-16 16:56:54 --> Language Class Initialized
ERROR - 2023-08-16 16:56:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:56:54 --> Config Class Initialized
INFO - 2023-08-16 16:56:54 --> Config Class Initialized
INFO - 2023-08-16 16:56:54 --> Hooks Class Initialized
INFO - 2023-08-16 16:56:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:56:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:56:54 --> Utf8 Class Initialized
INFO - 2023-08-16 16:56:54 --> Config Class Initialized
DEBUG - 2023-08-16 16:56:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:56:54 --> Hooks Class Initialized
INFO - 2023-08-16 16:56:54 --> Utf8 Class Initialized
DEBUG - 2023-08-16 16:56:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:56:54 --> Config Class Initialized
INFO - 2023-08-16 16:56:54 --> URI Class Initialized
INFO - 2023-08-16 16:56:54 --> Router Class Initialized
INFO - 2023-08-16 16:56:54 --> Hooks Class Initialized
INFO - 2023-08-16 16:56:54 --> URI Class Initialized
INFO - 2023-08-16 16:56:54 --> Utf8 Class Initialized
DEBUG - 2023-08-16 16:56:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:56:54 --> Output Class Initialized
INFO - 2023-08-16 16:56:54 --> Security Class Initialized
DEBUG - 2023-08-16 16:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:56:54 --> Router Class Initialized
INFO - 2023-08-16 16:56:54 --> URI Class Initialized
INFO - 2023-08-16 16:56:54 --> Router Class Initialized
INFO - 2023-08-16 16:56:54 --> Output Class Initialized
INFO - 2023-08-16 16:56:54 --> Input Class Initialized
INFO - 2023-08-16 16:56:54 --> Utf8 Class Initialized
INFO - 2023-08-16 16:56:54 --> URI Class Initialized
INFO - 2023-08-16 16:56:54 --> Output Class Initialized
INFO - 2023-08-16 16:56:54 --> Security Class Initialized
INFO - 2023-08-16 16:56:54 --> Language Class Initialized
INFO - 2023-08-16 16:56:54 --> Router Class Initialized
INFO - 2023-08-16 16:56:54 --> Output Class Initialized
INFO - 2023-08-16 16:56:54 --> Security Class Initialized
DEBUG - 2023-08-16 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 16:56:54 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 16:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:56:54 --> Security Class Initialized
INFO - 2023-08-16 16:56:54 --> Input Class Initialized
DEBUG - 2023-08-16 16:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:56:54 --> Input Class Initialized
INFO - 2023-08-16 16:56:54 --> Language Class Initialized
INFO - 2023-08-16 16:56:54 --> Language Class Initialized
ERROR - 2023-08-16 16:56:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:56:54 --> Input Class Initialized
ERROR - 2023-08-16 16:56:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 16:56:54 --> Language Class Initialized
ERROR - 2023-08-16 16:56:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:04:37 --> Config Class Initialized
INFO - 2023-08-16 17:04:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:37 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:37 --> URI Class Initialized
INFO - 2023-08-16 17:04:38 --> Router Class Initialized
INFO - 2023-08-16 17:04:38 --> Output Class Initialized
INFO - 2023-08-16 17:04:38 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:38 --> Input Class Initialized
INFO - 2023-08-16 17:04:38 --> Language Class Initialized
ERROR - 2023-08-16 17:04:38 --> 404 Page Not Found: Training-detail/index
INFO - 2023-08-16 17:04:41 --> Config Class Initialized
INFO - 2023-08-16 17:04:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:41 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:41 --> URI Class Initialized
INFO - 2023-08-16 17:04:41 --> Router Class Initialized
INFO - 2023-08-16 17:04:41 --> Output Class Initialized
INFO - 2023-08-16 17:04:41 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:41 --> Input Class Initialized
INFO - 2023-08-16 17:04:41 --> Language Class Initialized
INFO - 2023-08-16 17:04:41 --> Loader Class Initialized
INFO - 2023-08-16 17:04:41 --> Helper loaded: url_helper
INFO - 2023-08-16 17:04:41 --> Helper loaded: file_helper
INFO - 2023-08-16 17:04:41 --> Database Driver Class Initialized
INFO - 2023-08-16 17:04:41 --> Email Class Initialized
DEBUG - 2023-08-16 17:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:04:41 --> Controller Class Initialized
INFO - 2023-08-16 17:04:41 --> Model "Home_model" initialized
INFO - 2023-08-16 17:04:41 --> Helper loaded: form_helper
INFO - 2023-08-16 17:04:41 --> Form Validation Class Initialized
ERROR - 2023-08-16 17:04:41 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\dw\application\controllers\Home\HomeController.php 68
INFO - 2023-08-16 17:04:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:04:41 --> Final output sent to browser
DEBUG - 2023-08-16 17:04:41 --> Total execution time: 0.2889
INFO - 2023-08-16 17:04:41 --> Config Class Initialized
INFO - 2023-08-16 17:04:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:41 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:41 --> URI Class Initialized
INFO - 2023-08-16 17:04:41 --> Router Class Initialized
INFO - 2023-08-16 17:04:41 --> Output Class Initialized
INFO - 2023-08-16 17:04:41 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:41 --> Input Class Initialized
INFO - 2023-08-16 17:04:41 --> Language Class Initialized
ERROR - 2023-08-16 17:04:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:04:42 --> Config Class Initialized
INFO - 2023-08-16 17:04:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:42 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:42 --> URI Class Initialized
INFO - 2023-08-16 17:04:42 --> Router Class Initialized
INFO - 2023-08-16 17:04:42 --> Output Class Initialized
INFO - 2023-08-16 17:04:42 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:42 --> Input Class Initialized
INFO - 2023-08-16 17:04:42 --> Language Class Initialized
ERROR - 2023-08-16 17:04:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:04:42 --> Config Class Initialized
INFO - 2023-08-16 17:04:42 --> Config Class Initialized
INFO - 2023-08-16 17:04:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:42 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:42 --> URI Class Initialized
INFO - 2023-08-16 17:04:42 --> Router Class Initialized
INFO - 2023-08-16 17:04:42 --> Output Class Initialized
INFO - 2023-08-16 17:04:42 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:42 --> Input Class Initialized
INFO - 2023-08-16 17:04:42 --> Language Class Initialized
ERROR - 2023-08-16 17:04:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:04:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:42 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:42 --> URI Class Initialized
INFO - 2023-08-16 17:04:42 --> Router Class Initialized
INFO - 2023-08-16 17:04:42 --> Config Class Initialized
INFO - 2023-08-16 17:04:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:42 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:42 --> URI Class Initialized
INFO - 2023-08-16 17:04:42 --> Router Class Initialized
INFO - 2023-08-16 17:04:42 --> Output Class Initialized
INFO - 2023-08-16 17:04:42 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:42 --> Input Class Initialized
INFO - 2023-08-16 17:04:42 --> Language Class Initialized
ERROR - 2023-08-16 17:04:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:04:42 --> Config Class Initialized
INFO - 2023-08-16 17:04:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:42 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:42 --> URI Class Initialized
INFO - 2023-08-16 17:04:42 --> Router Class Initialized
INFO - 2023-08-16 17:04:42 --> Output Class Initialized
INFO - 2023-08-16 17:04:42 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:42 --> Input Class Initialized
INFO - 2023-08-16 17:04:42 --> Language Class Initialized
ERROR - 2023-08-16 17:04:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:04:42 --> Config Class Initialized
INFO - 2023-08-16 17:04:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:42 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:42 --> URI Class Initialized
INFO - 2023-08-16 17:04:42 --> Router Class Initialized
INFO - 2023-08-16 17:04:42 --> Output Class Initialized
INFO - 2023-08-16 17:04:42 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:42 --> Input Class Initialized
INFO - 2023-08-16 17:04:42 --> Language Class Initialized
ERROR - 2023-08-16 17:04:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:04:42 --> Config Class Initialized
INFO - 2023-08-16 17:04:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:42 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:42 --> URI Class Initialized
INFO - 2023-08-16 17:04:42 --> Router Class Initialized
INFO - 2023-08-16 17:04:42 --> Output Class Initialized
INFO - 2023-08-16 17:04:42 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:42 --> Input Class Initialized
INFO - 2023-08-16 17:04:42 --> Language Class Initialized
ERROR - 2023-08-16 17:04:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:04:42 --> Output Class Initialized
INFO - 2023-08-16 17:04:42 --> Config Class Initialized
INFO - 2023-08-16 17:04:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:42 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:42 --> URI Class Initialized
INFO - 2023-08-16 17:04:42 --> Router Class Initialized
INFO - 2023-08-16 17:04:42 --> Output Class Initialized
INFO - 2023-08-16 17:04:42 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:42 --> Input Class Initialized
INFO - 2023-08-16 17:04:42 --> Language Class Initialized
ERROR - 2023-08-16 17:04:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:04:43 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:43 --> Input Class Initialized
INFO - 2023-08-16 17:04:43 --> Language Class Initialized
ERROR - 2023-08-16 17:04:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:04:43 --> Config Class Initialized
INFO - 2023-08-16 17:04:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:43 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:43 --> URI Class Initialized
INFO - 2023-08-16 17:04:43 --> Router Class Initialized
INFO - 2023-08-16 17:04:43 --> Output Class Initialized
INFO - 2023-08-16 17:04:43 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:43 --> Input Class Initialized
INFO - 2023-08-16 17:04:43 --> Language Class Initialized
ERROR - 2023-08-16 17:04:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:04:43 --> Config Class Initialized
INFO - 2023-08-16 17:04:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:43 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:43 --> URI Class Initialized
INFO - 2023-08-16 17:04:43 --> Router Class Initialized
INFO - 2023-08-16 17:04:43 --> Output Class Initialized
INFO - 2023-08-16 17:04:43 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:43 --> Input Class Initialized
INFO - 2023-08-16 17:04:43 --> Language Class Initialized
ERROR - 2023-08-16 17:04:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:04:43 --> Config Class Initialized
INFO - 2023-08-16 17:04:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:43 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:43 --> URI Class Initialized
INFO - 2023-08-16 17:04:43 --> Router Class Initialized
INFO - 2023-08-16 17:04:43 --> Output Class Initialized
INFO - 2023-08-16 17:04:43 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:43 --> Input Class Initialized
INFO - 2023-08-16 17:04:43 --> Language Class Initialized
ERROR - 2023-08-16 17:04:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:05:08 --> Config Class Initialized
INFO - 2023-08-16 17:05:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:08 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:08 --> URI Class Initialized
INFO - 2023-08-16 17:05:08 --> Router Class Initialized
INFO - 2023-08-16 17:05:08 --> Output Class Initialized
INFO - 2023-08-16 17:05:08 --> Security Class Initialized
DEBUG - 2023-08-16 17:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:08 --> Input Class Initialized
INFO - 2023-08-16 17:05:08 --> Language Class Initialized
INFO - 2023-08-16 17:05:08 --> Loader Class Initialized
INFO - 2023-08-16 17:05:08 --> Helper loaded: url_helper
INFO - 2023-08-16 17:05:08 --> Helper loaded: file_helper
INFO - 2023-08-16 17:05:09 --> Database Driver Class Initialized
INFO - 2023-08-16 17:05:09 --> Email Class Initialized
DEBUG - 2023-08-16 17:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:05:09 --> Controller Class Initialized
INFO - 2023-08-16 17:05:09 --> Model "Home_model" initialized
INFO - 2023-08-16 17:05:09 --> Helper loaded: form_helper
INFO - 2023-08-16 17:05:09 --> Form Validation Class Initialized
INFO - 2023-08-16 17:05:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:05:09 --> Final output sent to browser
DEBUG - 2023-08-16 17:05:09 --> Total execution time: 0.4481
INFO - 2023-08-16 17:05:09 --> Config Class Initialized
INFO - 2023-08-16 17:05:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:09 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:09 --> URI Class Initialized
INFO - 2023-08-16 17:05:09 --> Router Class Initialized
INFO - 2023-08-16 17:05:09 --> Output Class Initialized
INFO - 2023-08-16 17:05:09 --> Security Class Initialized
DEBUG - 2023-08-16 17:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:09 --> Input Class Initialized
INFO - 2023-08-16 17:05:09 --> Language Class Initialized
INFO - 2023-08-16 17:05:09 --> Config Class Initialized
INFO - 2023-08-16 17:05:09 --> Hooks Class Initialized
ERROR - 2023-08-16 17:05:09 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:05:09 --> Config Class Initialized
DEBUG - 2023-08-16 17:05:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:09 --> Config Class Initialized
INFO - 2023-08-16 17:05:09 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:09 --> Hooks Class Initialized
INFO - 2023-08-16 17:05:10 --> Config Class Initialized
INFO - 2023-08-16 17:05:10 --> Config Class Initialized
INFO - 2023-08-16 17:05:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:10 --> URI Class Initialized
INFO - 2023-08-16 17:05:10 --> Hooks Class Initialized
INFO - 2023-08-16 17:05:10 --> Router Class Initialized
DEBUG - 2023-08-16 17:05:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:10 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:10 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:10 --> Output Class Initialized
INFO - 2023-08-16 17:05:10 --> URI Class Initialized
INFO - 2023-08-16 17:05:10 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:10 --> URI Class Initialized
INFO - 2023-08-16 17:05:10 --> Router Class Initialized
DEBUG - 2023-08-16 17:05:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:10 --> Security Class Initialized
INFO - 2023-08-16 17:05:10 --> Router Class Initialized
INFO - 2023-08-16 17:05:10 --> URI Class Initialized
INFO - 2023-08-16 17:05:10 --> Output Class Initialized
DEBUG - 2023-08-16 17:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:10 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:10 --> Output Class Initialized
INFO - 2023-08-16 17:05:10 --> Security Class Initialized
INFO - 2023-08-16 17:05:10 --> Config Class Initialized
INFO - 2023-08-16 17:05:10 --> Router Class Initialized
INFO - 2023-08-16 17:05:10 --> URI Class Initialized
INFO - 2023-08-16 17:05:10 --> Security Class Initialized
INFO - 2023-08-16 17:05:10 --> Input Class Initialized
DEBUG - 2023-08-16 17:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:10 --> Output Class Initialized
INFO - 2023-08-16 17:05:10 --> Router Class Initialized
INFO - 2023-08-16 17:05:10 --> Input Class Initialized
INFO - 2023-08-16 17:05:10 --> Language Class Initialized
INFO - 2023-08-16 17:05:10 --> Security Class Initialized
INFO - 2023-08-16 17:05:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 17:05:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:05:10 --> Output Class Initialized
DEBUG - 2023-08-16 17:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:10 --> Input Class Initialized
INFO - 2023-08-16 17:05:10 --> Input Class Initialized
DEBUG - 2023-08-16 17:05:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:10 --> Security Class Initialized
INFO - 2023-08-16 17:05:10 --> Language Class Initialized
INFO - 2023-08-16 17:05:10 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:10 --> Language Class Initialized
DEBUG - 2023-08-16 17:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:10 --> Language Class Initialized
INFO - 2023-08-16 17:05:10 --> Config Class Initialized
ERROR - 2023-08-16 17:05:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:05:10 --> Input Class Initialized
INFO - 2023-08-16 17:05:10 --> URI Class Initialized
ERROR - 2023-08-16 17:05:10 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 17:05:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:05:10 --> Hooks Class Initialized
INFO - 2023-08-16 17:05:10 --> Language Class Initialized
INFO - 2023-08-16 17:05:10 --> Router Class Initialized
ERROR - 2023-08-16 17:05:10 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 17:05:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:10 --> Output Class Initialized
INFO - 2023-08-16 17:05:10 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:10 --> Config Class Initialized
INFO - 2023-08-16 17:05:10 --> Security Class Initialized
INFO - 2023-08-16 17:05:10 --> Config Class Initialized
DEBUG - 2023-08-16 17:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:10 --> Hooks Class Initialized
INFO - 2023-08-16 17:05:10 --> Input Class Initialized
INFO - 2023-08-16 17:05:10 --> Hooks Class Initialized
INFO - 2023-08-16 17:05:10 --> Language Class Initialized
INFO - 2023-08-16 17:05:10 --> URI Class Initialized
DEBUG - 2023-08-16 17:05:10 --> UTF-8 Support Enabled
ERROR - 2023-08-16 17:05:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:05:10 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:10 --> Router Class Initialized
DEBUG - 2023-08-16 17:05:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:10 --> Output Class Initialized
INFO - 2023-08-16 17:05:10 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:10 --> URI Class Initialized
INFO - 2023-08-16 17:05:10 --> Security Class Initialized
INFO - 2023-08-16 17:05:10 --> Router Class Initialized
INFO - 2023-08-16 17:05:11 --> Output Class Initialized
INFO - 2023-08-16 17:05:11 --> URI Class Initialized
INFO - 2023-08-16 17:05:11 --> Security Class Initialized
DEBUG - 2023-08-16 17:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 17:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:11 --> Input Class Initialized
INFO - 2023-08-16 17:05:11 --> Input Class Initialized
INFO - 2023-08-16 17:05:11 --> Router Class Initialized
INFO - 2023-08-16 17:05:11 --> Language Class Initialized
INFO - 2023-08-16 17:05:11 --> Language Class Initialized
ERROR - 2023-08-16 17:05:11 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:05:11 --> Output Class Initialized
INFO - 2023-08-16 17:05:11 --> Security Class Initialized
ERROR - 2023-08-16 17:05:11 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 17:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:11 --> Input Class Initialized
INFO - 2023-08-16 17:05:11 --> Language Class Initialized
ERROR - 2023-08-16 17:05:11 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:06:42 --> Config Class Initialized
INFO - 2023-08-16 17:06:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:42 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:42 --> URI Class Initialized
INFO - 2023-08-16 17:06:42 --> Router Class Initialized
INFO - 2023-08-16 17:06:42 --> Output Class Initialized
INFO - 2023-08-16 17:06:42 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:42 --> Input Class Initialized
INFO - 2023-08-16 17:06:42 --> Language Class Initialized
INFO - 2023-08-16 17:06:42 --> Loader Class Initialized
INFO - 2023-08-16 17:06:42 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:42 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:42 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:42 --> Email Class Initialized
DEBUG - 2023-08-16 17:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:42 --> Controller Class Initialized
INFO - 2023-08-16 17:06:42 --> Model "Home_model" initialized
INFO - 2023-08-16 17:06:42 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:43 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:06:43 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:43 --> Total execution time: 0.4453
INFO - 2023-08-16 17:06:43 --> Config Class Initialized
INFO - 2023-08-16 17:06:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:43 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:43 --> URI Class Initialized
INFO - 2023-08-16 17:06:43 --> Router Class Initialized
INFO - 2023-08-16 17:06:43 --> Output Class Initialized
INFO - 2023-08-16 17:06:43 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:43 --> Input Class Initialized
INFO - 2023-08-16 17:06:43 --> Language Class Initialized
ERROR - 2023-08-16 17:06:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:06:43 --> Config Class Initialized
INFO - 2023-08-16 17:06:43 --> Hooks Class Initialized
INFO - 2023-08-16 17:06:44 --> Config Class Initialized
INFO - 2023-08-16 17:06:44 --> Config Class Initialized
INFO - 2023-08-16 17:06:44 --> Config Class Initialized
INFO - 2023-08-16 17:06:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 17:06:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:44 --> Hooks Class Initialized
INFO - 2023-08-16 17:06:44 --> Hooks Class Initialized
INFO - 2023-08-16 17:06:44 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:44 --> Utf8 Class Initialized
DEBUG - 2023-08-16 17:06:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:44 --> URI Class Initialized
INFO - 2023-08-16 17:06:44 --> URI Class Initialized
DEBUG - 2023-08-16 17:06:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:44 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:44 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:44 --> URI Class Initialized
INFO - 2023-08-16 17:06:44 --> Router Class Initialized
INFO - 2023-08-16 17:06:44 --> Output Class Initialized
INFO - 2023-08-16 17:06:44 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:44 --> Input Class Initialized
INFO - 2023-08-16 17:06:44 --> Language Class Initialized
ERROR - 2023-08-16 17:06:44 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:06:44 --> Router Class Initialized
INFO - 2023-08-16 17:06:44 --> Router Class Initialized
INFO - 2023-08-16 17:06:44 --> URI Class Initialized
INFO - 2023-08-16 17:06:44 --> Output Class Initialized
INFO - 2023-08-16 17:06:44 --> Security Class Initialized
INFO - 2023-08-16 17:06:44 --> Router Class Initialized
INFO - 2023-08-16 17:06:44 --> Output Class Initialized
DEBUG - 2023-08-16 17:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:44 --> Output Class Initialized
INFO - 2023-08-16 17:06:44 --> Input Class Initialized
INFO - 2023-08-16 17:06:44 --> Security Class Initialized
INFO - 2023-08-16 17:06:44 --> Language Class Initialized
INFO - 2023-08-16 17:06:44 --> Security Class Initialized
ERROR - 2023-08-16 17:06:44 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 17:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 17:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:44 --> Input Class Initialized
INFO - 2023-08-16 17:06:44 --> Input Class Initialized
INFO - 2023-08-16 17:06:44 --> Language Class Initialized
INFO - 2023-08-16 17:06:44 --> Language Class Initialized
ERROR - 2023-08-16 17:06:44 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 17:06:44 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:08:00 --> Config Class Initialized
INFO - 2023-08-16 17:08:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:08:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:08:00 --> Utf8 Class Initialized
INFO - 2023-08-16 17:08:00 --> URI Class Initialized
INFO - 2023-08-16 17:08:00 --> Router Class Initialized
INFO - 2023-08-16 17:08:00 --> Output Class Initialized
INFO - 2023-08-16 17:08:00 --> Security Class Initialized
DEBUG - 2023-08-16 17:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:08:00 --> Input Class Initialized
INFO - 2023-08-16 17:08:00 --> Language Class Initialized
INFO - 2023-08-16 17:08:00 --> Loader Class Initialized
INFO - 2023-08-16 17:08:00 --> Helper loaded: url_helper
INFO - 2023-08-16 17:08:00 --> Helper loaded: file_helper
INFO - 2023-08-16 17:08:00 --> Database Driver Class Initialized
INFO - 2023-08-16 17:08:00 --> Email Class Initialized
DEBUG - 2023-08-16 17:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:08:00 --> Controller Class Initialized
INFO - 2023-08-16 17:08:00 --> Model "Home_model" initialized
INFO - 2023-08-16 17:08:00 --> Helper loaded: form_helper
INFO - 2023-08-16 17:08:00 --> Form Validation Class Initialized
INFO - 2023-08-16 17:08:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:08:00 --> Final output sent to browser
DEBUG - 2023-08-16 17:08:01 --> Total execution time: 0.3473
INFO - 2023-08-16 17:08:01 --> Config Class Initialized
INFO - 2023-08-16 17:08:01 --> Config Class Initialized
INFO - 2023-08-16 17:08:01 --> Hooks Class Initialized
INFO - 2023-08-16 17:08:01 --> Config Class Initialized
INFO - 2023-08-16 17:08:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:08:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 17:08:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:08:01 --> Utf8 Class Initialized
INFO - 2023-08-16 17:08:01 --> Utf8 Class Initialized
INFO - 2023-08-16 17:08:01 --> Hooks Class Initialized
INFO - 2023-08-16 17:08:01 --> URI Class Initialized
DEBUG - 2023-08-16 17:08:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:08:01 --> URI Class Initialized
INFO - 2023-08-16 17:08:01 --> Utf8 Class Initialized
INFO - 2023-08-16 17:08:01 --> Router Class Initialized
INFO - 2023-08-16 17:08:01 --> Router Class Initialized
INFO - 2023-08-16 17:08:01 --> Output Class Initialized
INFO - 2023-08-16 17:08:01 --> Output Class Initialized
INFO - 2023-08-16 17:08:01 --> URI Class Initialized
INFO - 2023-08-16 17:08:02 --> Security Class Initialized
INFO - 2023-08-16 17:08:02 --> Router Class Initialized
DEBUG - 2023-08-16 17:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:08:02 --> Input Class Initialized
INFO - 2023-08-16 17:08:02 --> Security Class Initialized
INFO - 2023-08-16 17:08:02 --> Language Class Initialized
ERROR - 2023-08-16 17:08:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:08:02 --> Output Class Initialized
DEBUG - 2023-08-16 17:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:08:02 --> Security Class Initialized
INFO - 2023-08-16 17:08:02 --> Input Class Initialized
INFO - 2023-08-16 17:08:02 --> Config Class Initialized
DEBUG - 2023-08-16 17:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:08:02 --> Language Class Initialized
INFO - 2023-08-16 17:08:02 --> Input Class Initialized
ERROR - 2023-08-16 17:08:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:08:02 --> Language Class Initialized
INFO - 2023-08-16 17:08:02 --> Hooks Class Initialized
ERROR - 2023-08-16 17:08:02 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 17:08:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:08:02 --> Config Class Initialized
INFO - 2023-08-16 17:08:02 --> Hooks Class Initialized
INFO - 2023-08-16 17:08:02 --> Utf8 Class Initialized
DEBUG - 2023-08-16 17:08:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:08:02 --> URI Class Initialized
INFO - 2023-08-16 17:08:02 --> Router Class Initialized
INFO - 2023-08-16 17:08:02 --> Output Class Initialized
INFO - 2023-08-16 17:08:02 --> Utf8 Class Initialized
INFO - 2023-08-16 17:08:02 --> Security Class Initialized
INFO - 2023-08-16 17:08:02 --> URI Class Initialized
DEBUG - 2023-08-16 17:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:08:02 --> Router Class Initialized
INFO - 2023-08-16 17:08:02 --> Input Class Initialized
INFO - 2023-08-16 17:08:02 --> Language Class Initialized
INFO - 2023-08-16 17:08:02 --> Output Class Initialized
ERROR - 2023-08-16 17:08:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:08:02 --> Security Class Initialized
DEBUG - 2023-08-16 17:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:08:02 --> Input Class Initialized
INFO - 2023-08-16 17:08:02 --> Language Class Initialized
ERROR - 2023-08-16 17:08:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:09:45 --> Config Class Initialized
INFO - 2023-08-16 17:09:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:45 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:45 --> URI Class Initialized
INFO - 2023-08-16 17:09:45 --> Router Class Initialized
INFO - 2023-08-16 17:09:45 --> Output Class Initialized
INFO - 2023-08-16 17:09:45 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:45 --> Input Class Initialized
INFO - 2023-08-16 17:09:45 --> Language Class Initialized
INFO - 2023-08-16 17:09:45 --> Loader Class Initialized
INFO - 2023-08-16 17:09:45 --> Helper loaded: url_helper
INFO - 2023-08-16 17:09:45 --> Helper loaded: file_helper
INFO - 2023-08-16 17:09:45 --> Database Driver Class Initialized
INFO - 2023-08-16 17:09:45 --> Email Class Initialized
DEBUG - 2023-08-16 17:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:09:45 --> Controller Class Initialized
INFO - 2023-08-16 17:09:45 --> Model "Home_model" initialized
INFO - 2023-08-16 17:09:45 --> Helper loaded: form_helper
INFO - 2023-08-16 17:09:45 --> Form Validation Class Initialized
INFO - 2023-08-16 17:09:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 17:09:45 --> Final output sent to browser
DEBUG - 2023-08-16 17:09:45 --> Total execution time: 0.4805
INFO - 2023-08-16 17:09:46 --> Config Class Initialized
INFO - 2023-08-16 17:09:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:46 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:46 --> URI Class Initialized
INFO - 2023-08-16 17:09:46 --> Router Class Initialized
INFO - 2023-08-16 17:09:46 --> Output Class Initialized
INFO - 2023-08-16 17:09:46 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:46 --> Input Class Initialized
INFO - 2023-08-16 17:09:46 --> Language Class Initialized
ERROR - 2023-08-16 17:09:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:09:46 --> Config Class Initialized
INFO - 2023-08-16 17:09:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:46 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:46 --> URI Class Initialized
INFO - 2023-08-16 17:09:46 --> Router Class Initialized
INFO - 2023-08-16 17:09:46 --> Output Class Initialized
INFO - 2023-08-16 17:09:46 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:46 --> Input Class Initialized
INFO - 2023-08-16 17:09:46 --> Language Class Initialized
ERROR - 2023-08-16 17:09:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:09:46 --> Config Class Initialized
INFO - 2023-08-16 17:09:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:46 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:46 --> URI Class Initialized
INFO - 2023-08-16 17:09:46 --> Router Class Initialized
INFO - 2023-08-16 17:09:46 --> Output Class Initialized
INFO - 2023-08-16 17:09:46 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:46 --> Input Class Initialized
INFO - 2023-08-16 17:09:46 --> Language Class Initialized
ERROR - 2023-08-16 17:09:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:09:46 --> Config Class Initialized
INFO - 2023-08-16 17:09:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:46 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:46 --> URI Class Initialized
INFO - 2023-08-16 17:09:46 --> Router Class Initialized
INFO - 2023-08-16 17:09:46 --> Output Class Initialized
INFO - 2023-08-16 17:09:46 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:46 --> Input Class Initialized
INFO - 2023-08-16 17:09:46 --> Language Class Initialized
ERROR - 2023-08-16 17:09:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:09:46 --> Config Class Initialized
INFO - 2023-08-16 17:09:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:46 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:46 --> URI Class Initialized
INFO - 2023-08-16 17:09:46 --> Router Class Initialized
INFO - 2023-08-16 17:09:46 --> Output Class Initialized
INFO - 2023-08-16 17:09:46 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:46 --> Input Class Initialized
INFO - 2023-08-16 17:09:46 --> Language Class Initialized
ERROR - 2023-08-16 17:09:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:09:46 --> Config Class Initialized
INFO - 2023-08-16 17:09:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:46 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:46 --> URI Class Initialized
INFO - 2023-08-16 17:09:46 --> Router Class Initialized
INFO - 2023-08-16 17:09:46 --> Output Class Initialized
INFO - 2023-08-16 17:09:46 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:46 --> Input Class Initialized
INFO - 2023-08-16 17:09:46 --> Language Class Initialized
ERROR - 2023-08-16 17:09:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:09:47 --> Config Class Initialized
INFO - 2023-08-16 17:09:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:47 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:47 --> URI Class Initialized
INFO - 2023-08-16 17:09:47 --> Router Class Initialized
INFO - 2023-08-16 17:09:47 --> Output Class Initialized
INFO - 2023-08-16 17:09:47 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:47 --> Input Class Initialized
INFO - 2023-08-16 17:09:47 --> Language Class Initialized
ERROR - 2023-08-16 17:09:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:09:47 --> Config Class Initialized
INFO - 2023-08-16 17:09:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:47 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:47 --> URI Class Initialized
INFO - 2023-08-16 17:09:47 --> Router Class Initialized
INFO - 2023-08-16 17:09:47 --> Output Class Initialized
INFO - 2023-08-16 17:09:47 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:47 --> Input Class Initialized
INFO - 2023-08-16 17:09:47 --> Language Class Initialized
ERROR - 2023-08-16 17:09:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:09:54 --> Config Class Initialized
INFO - 2023-08-16 17:09:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:54 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:54 --> URI Class Initialized
INFO - 2023-08-16 17:09:54 --> Router Class Initialized
INFO - 2023-08-16 17:09:54 --> Output Class Initialized
INFO - 2023-08-16 17:09:54 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:54 --> Input Class Initialized
INFO - 2023-08-16 17:09:54 --> Language Class Initialized
INFO - 2023-08-16 17:09:54 --> Loader Class Initialized
INFO - 2023-08-16 17:09:54 --> Helper loaded: url_helper
INFO - 2023-08-16 17:09:54 --> Helper loaded: file_helper
INFO - 2023-08-16 17:09:54 --> Database Driver Class Initialized
INFO - 2023-08-16 17:09:54 --> Email Class Initialized
DEBUG - 2023-08-16 17:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:09:54 --> Controller Class Initialized
INFO - 2023-08-16 17:09:54 --> Model "Home_model" initialized
INFO - 2023-08-16 17:09:54 --> Helper loaded: form_helper
INFO - 2023-08-16 17:09:54 --> Form Validation Class Initialized
INFO - 2023-08-16 17:09:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:09:54 --> Final output sent to browser
DEBUG - 2023-08-16 17:09:54 --> Total execution time: 0.0467
INFO - 2023-08-16 17:09:54 --> Config Class Initialized
INFO - 2023-08-16 17:09:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:54 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:54 --> URI Class Initialized
INFO - 2023-08-16 17:09:54 --> Router Class Initialized
INFO - 2023-08-16 17:09:54 --> Output Class Initialized
INFO - 2023-08-16 17:09:54 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:54 --> Input Class Initialized
INFO - 2023-08-16 17:09:54 --> Language Class Initialized
ERROR - 2023-08-16 17:09:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:09:54 --> Config Class Initialized
INFO - 2023-08-16 17:09:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:54 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:54 --> URI Class Initialized
INFO - 2023-08-16 17:09:54 --> Router Class Initialized
INFO - 2023-08-16 17:09:54 --> Output Class Initialized
INFO - 2023-08-16 17:09:54 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:54 --> Input Class Initialized
INFO - 2023-08-16 17:09:54 --> Language Class Initialized
ERROR - 2023-08-16 17:09:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:09:54 --> Config Class Initialized
INFO - 2023-08-16 17:09:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:54 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:54 --> URI Class Initialized
INFO - 2023-08-16 17:09:54 --> Router Class Initialized
INFO - 2023-08-16 17:09:54 --> Output Class Initialized
INFO - 2023-08-16 17:09:54 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:54 --> Input Class Initialized
INFO - 2023-08-16 17:09:54 --> Language Class Initialized
ERROR - 2023-08-16 17:09:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:09:55 --> Config Class Initialized
INFO - 2023-08-16 17:09:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:55 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:55 --> URI Class Initialized
INFO - 2023-08-16 17:09:55 --> Router Class Initialized
INFO - 2023-08-16 17:09:55 --> Output Class Initialized
INFO - 2023-08-16 17:09:55 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:55 --> Input Class Initialized
INFO - 2023-08-16 17:09:55 --> Language Class Initialized
ERROR - 2023-08-16 17:09:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:09:55 --> Config Class Initialized
INFO - 2023-08-16 17:09:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:55 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:55 --> URI Class Initialized
INFO - 2023-08-16 17:09:55 --> Router Class Initialized
INFO - 2023-08-16 17:09:55 --> Output Class Initialized
INFO - 2023-08-16 17:09:55 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:55 --> Input Class Initialized
INFO - 2023-08-16 17:09:55 --> Language Class Initialized
ERROR - 2023-08-16 17:09:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:09:55 --> Config Class Initialized
INFO - 2023-08-16 17:09:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:55 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:55 --> URI Class Initialized
INFO - 2023-08-16 17:09:55 --> Router Class Initialized
INFO - 2023-08-16 17:09:55 --> Output Class Initialized
INFO - 2023-08-16 17:09:55 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:55 --> Input Class Initialized
INFO - 2023-08-16 17:09:55 --> Language Class Initialized
ERROR - 2023-08-16 17:09:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:09:55 --> Config Class Initialized
INFO - 2023-08-16 17:09:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:55 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:55 --> URI Class Initialized
INFO - 2023-08-16 17:09:55 --> Router Class Initialized
INFO - 2023-08-16 17:09:55 --> Output Class Initialized
INFO - 2023-08-16 17:09:55 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:55 --> Input Class Initialized
INFO - 2023-08-16 17:09:55 --> Language Class Initialized
ERROR - 2023-08-16 17:09:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:09:55 --> Config Class Initialized
INFO - 2023-08-16 17:09:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:55 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:55 --> URI Class Initialized
INFO - 2023-08-16 17:09:55 --> Router Class Initialized
INFO - 2023-08-16 17:09:55 --> Output Class Initialized
INFO - 2023-08-16 17:09:55 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:55 --> Input Class Initialized
INFO - 2023-08-16 17:09:55 --> Language Class Initialized
ERROR - 2023-08-16 17:09:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:10:45 --> Config Class Initialized
INFO - 2023-08-16 17:10:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:10:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:10:45 --> Utf8 Class Initialized
INFO - 2023-08-16 17:10:45 --> URI Class Initialized
INFO - 2023-08-16 17:10:45 --> Router Class Initialized
INFO - 2023-08-16 17:10:45 --> Output Class Initialized
INFO - 2023-08-16 17:10:45 --> Security Class Initialized
DEBUG - 2023-08-16 17:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:10:45 --> Input Class Initialized
INFO - 2023-08-16 17:10:45 --> Language Class Initialized
INFO - 2023-08-16 17:10:45 --> Loader Class Initialized
INFO - 2023-08-16 17:10:45 --> Helper loaded: url_helper
INFO - 2023-08-16 17:10:45 --> Helper loaded: file_helper
INFO - 2023-08-16 17:10:45 --> Database Driver Class Initialized
INFO - 2023-08-16 17:10:45 --> Email Class Initialized
DEBUG - 2023-08-16 17:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:10:45 --> Controller Class Initialized
INFO - 2023-08-16 17:10:45 --> Model "Home_model" initialized
INFO - 2023-08-16 17:10:45 --> Helper loaded: form_helper
INFO - 2023-08-16 17:10:45 --> Form Validation Class Initialized
INFO - 2023-08-16 17:10:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:10:45 --> Final output sent to browser
DEBUG - 2023-08-16 17:10:46 --> Total execution time: 0.3388
INFO - 2023-08-16 17:10:46 --> Config Class Initialized
INFO - 2023-08-16 17:10:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:10:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:10:46 --> Utf8 Class Initialized
INFO - 2023-08-16 17:10:46 --> URI Class Initialized
INFO - 2023-08-16 17:10:46 --> Router Class Initialized
INFO - 2023-08-16 17:10:46 --> Output Class Initialized
INFO - 2023-08-16 17:10:46 --> Security Class Initialized
DEBUG - 2023-08-16 17:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:10:46 --> Input Class Initialized
INFO - 2023-08-16 17:10:46 --> Language Class Initialized
ERROR - 2023-08-16 17:10:46 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:10:46 --> Config Class Initialized
INFO - 2023-08-16 17:10:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:10:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:10:46 --> Utf8 Class Initialized
INFO - 2023-08-16 17:10:46 --> URI Class Initialized
INFO - 2023-08-16 17:10:46 --> Router Class Initialized
INFO - 2023-08-16 17:10:46 --> Output Class Initialized
INFO - 2023-08-16 17:10:46 --> Security Class Initialized
DEBUG - 2023-08-16 17:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:10:46 --> Input Class Initialized
INFO - 2023-08-16 17:10:46 --> Language Class Initialized
ERROR - 2023-08-16 17:10:46 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:10:46 --> Config Class Initialized
INFO - 2023-08-16 17:10:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:10:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:10:46 --> Utf8 Class Initialized
INFO - 2023-08-16 17:10:46 --> URI Class Initialized
INFO - 2023-08-16 17:10:46 --> Router Class Initialized
INFO - 2023-08-16 17:10:46 --> Output Class Initialized
INFO - 2023-08-16 17:10:46 --> Security Class Initialized
DEBUG - 2023-08-16 17:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:10:46 --> Input Class Initialized
INFO - 2023-08-16 17:10:46 --> Language Class Initialized
ERROR - 2023-08-16 17:10:46 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:10:46 --> Config Class Initialized
INFO - 2023-08-16 17:10:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:10:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:10:46 --> Utf8 Class Initialized
INFO - 2023-08-16 17:10:46 --> URI Class Initialized
INFO - 2023-08-16 17:10:46 --> Router Class Initialized
INFO - 2023-08-16 17:10:46 --> Output Class Initialized
INFO - 2023-08-16 17:10:46 --> Security Class Initialized
DEBUG - 2023-08-16 17:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:10:46 --> Input Class Initialized
INFO - 2023-08-16 17:10:46 --> Language Class Initialized
ERROR - 2023-08-16 17:10:46 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:10:46 --> Config Class Initialized
INFO - 2023-08-16 17:10:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:10:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:10:47 --> Utf8 Class Initialized
INFO - 2023-08-16 17:10:47 --> URI Class Initialized
INFO - 2023-08-16 17:10:47 --> Router Class Initialized
INFO - 2023-08-16 17:10:47 --> Output Class Initialized
INFO - 2023-08-16 17:10:47 --> Security Class Initialized
DEBUG - 2023-08-16 17:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:10:47 --> Input Class Initialized
INFO - 2023-08-16 17:10:47 --> Language Class Initialized
ERROR - 2023-08-16 17:10:47 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:10:52 --> Config Class Initialized
INFO - 2023-08-16 17:10:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:10:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:10:52 --> Utf8 Class Initialized
INFO - 2023-08-16 17:10:52 --> URI Class Initialized
INFO - 2023-08-16 17:10:52 --> Router Class Initialized
INFO - 2023-08-16 17:10:52 --> Output Class Initialized
INFO - 2023-08-16 17:10:52 --> Security Class Initialized
DEBUG - 2023-08-16 17:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:10:52 --> Input Class Initialized
INFO - 2023-08-16 17:10:52 --> Language Class Initialized
INFO - 2023-08-16 17:10:52 --> Loader Class Initialized
INFO - 2023-08-16 17:10:52 --> Helper loaded: url_helper
INFO - 2023-08-16 17:10:52 --> Helper loaded: file_helper
INFO - 2023-08-16 17:10:52 --> Database Driver Class Initialized
INFO - 2023-08-16 17:10:52 --> Email Class Initialized
DEBUG - 2023-08-16 17:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:10:52 --> Controller Class Initialized
INFO - 2023-08-16 17:10:52 --> Model "Home_model" initialized
INFO - 2023-08-16 17:10:52 --> Helper loaded: form_helper
INFO - 2023-08-16 17:10:52 --> Form Validation Class Initialized
INFO - 2023-08-16 17:10:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 17:10:52 --> Final output sent to browser
DEBUG - 2023-08-16 17:10:52 --> Total execution time: 0.0514
INFO - 2023-08-16 17:10:57 --> Config Class Initialized
INFO - 2023-08-16 17:10:57 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:10:57 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:10:57 --> Utf8 Class Initialized
INFO - 2023-08-16 17:10:57 --> URI Class Initialized
INFO - 2023-08-16 17:10:57 --> Router Class Initialized
INFO - 2023-08-16 17:10:57 --> Output Class Initialized
INFO - 2023-08-16 17:10:57 --> Security Class Initialized
DEBUG - 2023-08-16 17:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:10:57 --> Input Class Initialized
INFO - 2023-08-16 17:10:57 --> Language Class Initialized
INFO - 2023-08-16 17:10:57 --> Loader Class Initialized
INFO - 2023-08-16 17:10:57 --> Helper loaded: url_helper
INFO - 2023-08-16 17:10:57 --> Helper loaded: file_helper
INFO - 2023-08-16 17:10:57 --> Database Driver Class Initialized
INFO - 2023-08-16 17:10:57 --> Email Class Initialized
DEBUG - 2023-08-16 17:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:10:57 --> Controller Class Initialized
INFO - 2023-08-16 17:10:57 --> Model "Home_model" initialized
INFO - 2023-08-16 17:10:57 --> Helper loaded: form_helper
INFO - 2023-08-16 17:10:57 --> Form Validation Class Initialized
INFO - 2023-08-16 17:10:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:10:57 --> Final output sent to browser
DEBUG - 2023-08-16 17:10:57 --> Total execution time: 0.3156
INFO - 2023-08-16 17:10:58 --> Config Class Initialized
INFO - 2023-08-16 17:10:58 --> Config Class Initialized
INFO - 2023-08-16 17:10:58 --> Hooks Class Initialized
INFO - 2023-08-16 17:10:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:10:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:10:58 --> Config Class Initialized
DEBUG - 2023-08-16 17:10:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:10:58 --> Hooks Class Initialized
INFO - 2023-08-16 17:10:58 --> Utf8 Class Initialized
INFO - 2023-08-16 17:10:58 --> URI Class Initialized
INFO - 2023-08-16 17:10:58 --> Utf8 Class Initialized
DEBUG - 2023-08-16 17:10:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:10:58 --> Router Class Initialized
INFO - 2023-08-16 17:10:58 --> Output Class Initialized
INFO - 2023-08-16 17:10:58 --> URI Class Initialized
INFO - 2023-08-16 17:10:58 --> Utf8 Class Initialized
INFO - 2023-08-16 17:10:58 --> Router Class Initialized
INFO - 2023-08-16 17:10:58 --> URI Class Initialized
INFO - 2023-08-16 17:10:58 --> Security Class Initialized
INFO - 2023-08-16 17:10:58 --> Router Class Initialized
DEBUG - 2023-08-16 17:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:10:58 --> Input Class Initialized
INFO - 2023-08-16 17:10:58 --> Language Class Initialized
INFO - 2023-08-16 17:10:58 --> Output Class Initialized
INFO - 2023-08-16 17:10:58 --> Security Class Initialized
INFO - 2023-08-16 17:10:58 --> Output Class Initialized
DEBUG - 2023-08-16 17:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 17:10:58 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:10:58 --> Security Class Initialized
INFO - 2023-08-16 17:10:58 --> Input Class Initialized
INFO - 2023-08-16 17:10:58 --> Config Class Initialized
DEBUG - 2023-08-16 17:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:10:58 --> Language Class Initialized
INFO - 2023-08-16 17:10:58 --> Input Class Initialized
INFO - 2023-08-16 17:10:58 --> Hooks Class Initialized
ERROR - 2023-08-16 17:10:58 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:10:58 --> Config Class Initialized
INFO - 2023-08-16 17:10:58 --> Language Class Initialized
INFO - 2023-08-16 17:10:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:10:58 --> UTF-8 Support Enabled
ERROR - 2023-08-16 17:10:58 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 17:10:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:10:58 --> Utf8 Class Initialized
INFO - 2023-08-16 17:10:58 --> Utf8 Class Initialized
INFO - 2023-08-16 17:10:58 --> URI Class Initialized
INFO - 2023-08-16 17:10:58 --> Router Class Initialized
INFO - 2023-08-16 17:10:58 --> URI Class Initialized
INFO - 2023-08-16 17:10:58 --> Output Class Initialized
INFO - 2023-08-16 17:10:58 --> Security Class Initialized
INFO - 2023-08-16 17:10:58 --> Router Class Initialized
DEBUG - 2023-08-16 17:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:10:59 --> Input Class Initialized
INFO - 2023-08-16 17:10:59 --> Output Class Initialized
INFO - 2023-08-16 17:10:59 --> Language Class Initialized
INFO - 2023-08-16 17:10:59 --> Security Class Initialized
DEBUG - 2023-08-16 17:10:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 17:10:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:10:59 --> Input Class Initialized
INFO - 2023-08-16 17:10:59 --> Language Class Initialized
ERROR - 2023-08-16 17:10:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:11:53 --> Config Class Initialized
INFO - 2023-08-16 17:11:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:11:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:11:53 --> Utf8 Class Initialized
INFO - 2023-08-16 17:11:53 --> URI Class Initialized
INFO - 2023-08-16 17:11:53 --> Router Class Initialized
INFO - 2023-08-16 17:11:53 --> Output Class Initialized
INFO - 2023-08-16 17:11:53 --> Security Class Initialized
DEBUG - 2023-08-16 17:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:11:53 --> Input Class Initialized
INFO - 2023-08-16 17:11:53 --> Language Class Initialized
INFO - 2023-08-16 17:11:53 --> Loader Class Initialized
INFO - 2023-08-16 17:11:53 --> Helper loaded: url_helper
INFO - 2023-08-16 17:11:53 --> Helper loaded: file_helper
INFO - 2023-08-16 17:11:53 --> Database Driver Class Initialized
INFO - 2023-08-16 17:11:53 --> Email Class Initialized
DEBUG - 2023-08-16 17:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:11:53 --> Controller Class Initialized
INFO - 2023-08-16 17:11:53 --> Model "Home_model" initialized
INFO - 2023-08-16 17:11:53 --> Helper loaded: form_helper
INFO - 2023-08-16 17:11:53 --> Form Validation Class Initialized
INFO - 2023-08-16 17:11:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:11:53 --> Final output sent to browser
DEBUG - 2023-08-16 17:11:53 --> Total execution time: 0.3495
INFO - 2023-08-16 17:11:53 --> Config Class Initialized
INFO - 2023-08-16 17:11:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:11:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:11:53 --> Utf8 Class Initialized
INFO - 2023-08-16 17:11:53 --> URI Class Initialized
INFO - 2023-08-16 17:11:53 --> Router Class Initialized
INFO - 2023-08-16 17:11:53 --> Output Class Initialized
INFO - 2023-08-16 17:11:53 --> Security Class Initialized
DEBUG - 2023-08-16 17:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:11:54 --> Input Class Initialized
INFO - 2023-08-16 17:11:54 --> Language Class Initialized
ERROR - 2023-08-16 17:11:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:11:54 --> Config Class Initialized
INFO - 2023-08-16 17:11:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:11:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:11:54 --> Utf8 Class Initialized
INFO - 2023-08-16 17:11:54 --> URI Class Initialized
INFO - 2023-08-16 17:11:54 --> Router Class Initialized
INFO - 2023-08-16 17:11:54 --> Output Class Initialized
INFO - 2023-08-16 17:11:54 --> Security Class Initialized
DEBUG - 2023-08-16 17:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:11:54 --> Input Class Initialized
INFO - 2023-08-16 17:11:54 --> Language Class Initialized
ERROR - 2023-08-16 17:11:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:11:54 --> Config Class Initialized
INFO - 2023-08-16 17:11:54 --> Config Class Initialized
INFO - 2023-08-16 17:11:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:11:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:11:54 --> Utf8 Class Initialized
INFO - 2023-08-16 17:11:54 --> Config Class Initialized
INFO - 2023-08-16 17:11:54 --> URI Class Initialized
INFO - 2023-08-16 17:11:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:11:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:11:54 --> Utf8 Class Initialized
INFO - 2023-08-16 17:11:54 --> Router Class Initialized
INFO - 2023-08-16 17:11:54 --> Hooks Class Initialized
INFO - 2023-08-16 17:11:54 --> Output Class Initialized
DEBUG - 2023-08-16 17:11:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:11:54 --> Security Class Initialized
INFO - 2023-08-16 17:11:55 --> Utf8 Class Initialized
INFO - 2023-08-16 17:11:55 --> URI Class Initialized
INFO - 2023-08-16 17:11:55 --> URI Class Initialized
INFO - 2023-08-16 17:11:55 --> Router Class Initialized
INFO - 2023-08-16 17:11:55 --> Router Class Initialized
DEBUG - 2023-08-16 17:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:11:55 --> Input Class Initialized
INFO - 2023-08-16 17:11:55 --> Output Class Initialized
INFO - 2023-08-16 17:11:55 --> Language Class Initialized
INFO - 2023-08-16 17:11:55 --> Security Class Initialized
INFO - 2023-08-16 17:11:55 --> Output Class Initialized
INFO - 2023-08-16 17:11:55 --> Security Class Initialized
ERROR - 2023-08-16 17:11:55 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 17:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 17:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:11:55 --> Input Class Initialized
INFO - 2023-08-16 17:11:55 --> Input Class Initialized
INFO - 2023-08-16 17:11:55 --> Language Class Initialized
ERROR - 2023-08-16 17:11:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:11:55 --> Language Class Initialized
ERROR - 2023-08-16 17:11:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:12:20 --> Config Class Initialized
INFO - 2023-08-16 17:12:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:12:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:20 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:20 --> URI Class Initialized
INFO - 2023-08-16 17:12:20 --> Router Class Initialized
INFO - 2023-08-16 17:12:20 --> Output Class Initialized
INFO - 2023-08-16 17:12:20 --> Security Class Initialized
DEBUG - 2023-08-16 17:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:20 --> Input Class Initialized
INFO - 2023-08-16 17:12:20 --> Language Class Initialized
INFO - 2023-08-16 17:12:20 --> Loader Class Initialized
INFO - 2023-08-16 17:12:20 --> Helper loaded: url_helper
INFO - 2023-08-16 17:12:20 --> Helper loaded: file_helper
INFO - 2023-08-16 17:12:20 --> Database Driver Class Initialized
INFO - 2023-08-16 17:12:20 --> Email Class Initialized
DEBUG - 2023-08-16 17:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:12:20 --> Controller Class Initialized
INFO - 2023-08-16 17:12:20 --> Model "Home_model" initialized
INFO - 2023-08-16 17:12:20 --> Helper loaded: form_helper
INFO - 2023-08-16 17:12:20 --> Form Validation Class Initialized
INFO - 2023-08-16 17:12:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:12:20 --> Final output sent to browser
DEBUG - 2023-08-16 17:12:21 --> Total execution time: 0.3487
INFO - 2023-08-16 17:12:21 --> Config Class Initialized
INFO - 2023-08-16 17:12:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:12:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:21 --> Config Class Initialized
INFO - 2023-08-16 17:12:21 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:21 --> Hooks Class Initialized
INFO - 2023-08-16 17:12:21 --> URI Class Initialized
DEBUG - 2023-08-16 17:12:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:21 --> Router Class Initialized
INFO - 2023-08-16 17:12:21 --> Output Class Initialized
INFO - 2023-08-16 17:12:21 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:21 --> Security Class Initialized
DEBUG - 2023-08-16 17:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:21 --> URI Class Initialized
INFO - 2023-08-16 17:12:22 --> Input Class Initialized
INFO - 2023-08-16 17:12:22 --> Language Class Initialized
INFO - 2023-08-16 17:12:22 --> Router Class Initialized
ERROR - 2023-08-16 17:12:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:12:22 --> Output Class Initialized
INFO - 2023-08-16 17:12:22 --> Security Class Initialized
DEBUG - 2023-08-16 17:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:22 --> Input Class Initialized
INFO - 2023-08-16 17:12:22 --> Language Class Initialized
ERROR - 2023-08-16 17:12:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:12:22 --> Config Class Initialized
INFO - 2023-08-16 17:12:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:12:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:22 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:22 --> URI Class Initialized
INFO - 2023-08-16 17:12:22 --> Config Class Initialized
INFO - 2023-08-16 17:12:22 --> Config Class Initialized
INFO - 2023-08-16 17:12:22 --> Router Class Initialized
INFO - 2023-08-16 17:12:22 --> Hooks Class Initialized
INFO - 2023-08-16 17:12:22 --> Output Class Initialized
DEBUG - 2023-08-16 17:12:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:12:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:22 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:22 --> Security Class Initialized
INFO - 2023-08-16 17:12:22 --> URI Class Initialized
DEBUG - 2023-08-16 17:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:22 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:22 --> Input Class Initialized
INFO - 2023-08-16 17:12:22 --> URI Class Initialized
INFO - 2023-08-16 17:12:22 --> Router Class Initialized
INFO - 2023-08-16 17:12:22 --> Router Class Initialized
INFO - 2023-08-16 17:12:22 --> Language Class Initialized
INFO - 2023-08-16 17:12:22 --> Output Class Initialized
INFO - 2023-08-16 17:12:22 --> Output Class Initialized
INFO - 2023-08-16 17:12:22 --> Security Class Initialized
INFO - 2023-08-16 17:12:22 --> Security Class Initialized
DEBUG - 2023-08-16 17:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 17:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:22 --> Input Class Initialized
ERROR - 2023-08-16 17:12:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:12:22 --> Input Class Initialized
INFO - 2023-08-16 17:12:22 --> Language Class Initialized
INFO - 2023-08-16 17:12:22 --> Language Class Initialized
ERROR - 2023-08-16 17:12:22 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 17:12:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:12:40 --> Config Class Initialized
INFO - 2023-08-16 17:12:40 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:12:40 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:40 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:40 --> URI Class Initialized
INFO - 2023-08-16 17:12:40 --> Router Class Initialized
INFO - 2023-08-16 17:12:40 --> Output Class Initialized
INFO - 2023-08-16 17:12:40 --> Security Class Initialized
DEBUG - 2023-08-16 17:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:40 --> Input Class Initialized
INFO - 2023-08-16 17:12:40 --> Language Class Initialized
INFO - 2023-08-16 17:12:40 --> Loader Class Initialized
INFO - 2023-08-16 17:12:40 --> Helper loaded: url_helper
INFO - 2023-08-16 17:12:40 --> Helper loaded: file_helper
INFO - 2023-08-16 17:12:40 --> Database Driver Class Initialized
INFO - 2023-08-16 17:12:40 --> Email Class Initialized
DEBUG - 2023-08-16 17:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:12:40 --> Controller Class Initialized
INFO - 2023-08-16 17:12:40 --> Model "Home_model" initialized
INFO - 2023-08-16 17:12:40 --> Helper loaded: form_helper
INFO - 2023-08-16 17:12:40 --> Form Validation Class Initialized
INFO - 2023-08-16 17:12:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:12:40 --> Final output sent to browser
DEBUG - 2023-08-16 17:12:40 --> Total execution time: 0.3330
INFO - 2023-08-16 17:12:41 --> Config Class Initialized
INFO - 2023-08-16 17:12:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:12:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:41 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:41 --> URI Class Initialized
INFO - 2023-08-16 17:12:41 --> Router Class Initialized
INFO - 2023-08-16 17:12:41 --> Output Class Initialized
INFO - 2023-08-16 17:12:41 --> Security Class Initialized
DEBUG - 2023-08-16 17:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:41 --> Input Class Initialized
INFO - 2023-08-16 17:12:41 --> Language Class Initialized
INFO - 2023-08-16 17:12:41 --> Config Class Initialized
INFO - 2023-08-16 17:12:41 --> Config Class Initialized
INFO - 2023-08-16 17:12:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:12:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:41 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:41 --> URI Class Initialized
INFO - 2023-08-16 17:12:41 --> Router Class Initialized
INFO - 2023-08-16 17:12:41 --> Output Class Initialized
INFO - 2023-08-16 17:12:41 --> Security Class Initialized
DEBUG - 2023-08-16 17:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:41 --> Input Class Initialized
INFO - 2023-08-16 17:12:41 --> Language Class Initialized
ERROR - 2023-08-16 17:12:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:12:41 --> Hooks Class Initialized
INFO - 2023-08-16 17:12:41 --> Config Class Initialized
DEBUG - 2023-08-16 17:12:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:41 --> Hooks Class Initialized
INFO - 2023-08-16 17:12:41 --> Utf8 Class Initialized
DEBUG - 2023-08-16 17:12:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:41 --> URI Class Initialized
INFO - 2023-08-16 17:12:41 --> Router Class Initialized
INFO - 2023-08-16 17:12:41 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:41 --> Output Class Initialized
ERROR - 2023-08-16 17:12:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:12:41 --> URI Class Initialized
INFO - 2023-08-16 17:12:41 --> Security Class Initialized
INFO - 2023-08-16 17:12:41 --> Router Class Initialized
DEBUG - 2023-08-16 17:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:41 --> Input Class Initialized
INFO - 2023-08-16 17:12:41 --> Output Class Initialized
INFO - 2023-08-16 17:12:41 --> Language Class Initialized
INFO - 2023-08-16 17:12:41 --> Security Class Initialized
ERROR - 2023-08-16 17:12:41 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 17:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:41 --> Input Class Initialized
INFO - 2023-08-16 17:12:41 --> Language Class Initialized
ERROR - 2023-08-16 17:12:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:12:41 --> Config Class Initialized
INFO - 2023-08-16 17:12:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:12:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:41 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:41 --> URI Class Initialized
INFO - 2023-08-16 17:12:41 --> Router Class Initialized
INFO - 2023-08-16 17:12:41 --> Output Class Initialized
INFO - 2023-08-16 17:12:41 --> Security Class Initialized
DEBUG - 2023-08-16 17:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:41 --> Input Class Initialized
INFO - 2023-08-16 17:12:41 --> Language Class Initialized
ERROR - 2023-08-16 17:12:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:12:54 --> Config Class Initialized
INFO - 2023-08-16 17:12:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:12:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:54 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:54 --> URI Class Initialized
INFO - 2023-08-16 17:12:54 --> Router Class Initialized
INFO - 2023-08-16 17:12:54 --> Output Class Initialized
INFO - 2023-08-16 17:12:54 --> Security Class Initialized
DEBUG - 2023-08-16 17:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:54 --> Input Class Initialized
INFO - 2023-08-16 17:12:54 --> Language Class Initialized
INFO - 2023-08-16 17:12:54 --> Loader Class Initialized
INFO - 2023-08-16 17:12:54 --> Helper loaded: url_helper
INFO - 2023-08-16 17:12:54 --> Helper loaded: file_helper
INFO - 2023-08-16 17:12:54 --> Database Driver Class Initialized
INFO - 2023-08-16 17:12:54 --> Email Class Initialized
DEBUG - 2023-08-16 17:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:12:54 --> Controller Class Initialized
INFO - 2023-08-16 17:12:54 --> Model "Home_model" initialized
INFO - 2023-08-16 17:12:54 --> Helper loaded: form_helper
INFO - 2023-08-16 17:12:54 --> Form Validation Class Initialized
INFO - 2023-08-16 17:12:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:12:54 --> Final output sent to browser
DEBUG - 2023-08-16 17:12:54 --> Total execution time: 0.3635
INFO - 2023-08-16 17:12:55 --> Config Class Initialized
INFO - 2023-08-16 17:12:55 --> Hooks Class Initialized
INFO - 2023-08-16 17:12:55 --> Config Class Initialized
INFO - 2023-08-16 17:12:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:12:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:55 --> Config Class Initialized
INFO - 2023-08-16 17:12:55 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:55 --> Config Class Initialized
DEBUG - 2023-08-16 17:12:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:55 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:55 --> URI Class Initialized
INFO - 2023-08-16 17:12:55 --> Hooks Class Initialized
INFO - 2023-08-16 17:12:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:12:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 17:12:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:12:55 --> URI Class Initialized
INFO - 2023-08-16 17:12:55 --> Router Class Initialized
INFO - 2023-08-16 17:12:55 --> Router Class Initialized
INFO - 2023-08-16 17:12:55 --> Output Class Initialized
INFO - 2023-08-16 17:12:55 --> Output Class Initialized
INFO - 2023-08-16 17:12:55 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:55 --> Security Class Initialized
INFO - 2023-08-16 17:12:55 --> Utf8 Class Initialized
INFO - 2023-08-16 17:12:55 --> URI Class Initialized
INFO - 2023-08-16 17:12:55 --> URI Class Initialized
INFO - 2023-08-16 17:12:55 --> Router Class Initialized
INFO - 2023-08-16 17:12:55 --> Output Class Initialized
INFO - 2023-08-16 17:12:55 --> Security Class Initialized
DEBUG - 2023-08-16 17:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 17:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:55 --> Input Class Initialized
INFO - 2023-08-16 17:12:55 --> Router Class Initialized
INFO - 2023-08-16 17:12:55 --> Config Class Initialized
INFO - 2023-08-16 17:12:55 --> Input Class Initialized
INFO - 2023-08-16 17:12:55 --> Security Class Initialized
INFO - 2023-08-16 17:12:55 --> Output Class Initialized
INFO - 2023-08-16 17:12:55 --> Language Class Initialized
INFO - 2023-08-16 17:12:55 --> Hooks Class Initialized
INFO - 2023-08-16 17:12:55 --> Language Class Initialized
ERROR - 2023-08-16 17:12:55 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 17:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 17:12:56 --> UTF-8 Support Enabled
ERROR - 2023-08-16 17:12:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:12:56 --> Input Class Initialized
INFO - 2023-08-16 17:12:56 --> Security Class Initialized
INFO - 2023-08-16 17:12:56 --> Language Class Initialized
INFO - 2023-08-16 17:12:56 --> Utf8 Class Initialized
ERROR - 2023-08-16 17:12:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:12:56 --> URI Class Initialized
DEBUG - 2023-08-16 17:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:56 --> Router Class Initialized
INFO - 2023-08-16 17:12:56 --> Input Class Initialized
INFO - 2023-08-16 17:12:56 --> Language Class Initialized
INFO - 2023-08-16 17:12:56 --> Output Class Initialized
ERROR - 2023-08-16 17:12:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:12:56 --> Security Class Initialized
DEBUG - 2023-08-16 17:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:12:56 --> Input Class Initialized
INFO - 2023-08-16 17:12:56 --> Language Class Initialized
ERROR - 2023-08-16 17:12:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:13:04 --> Config Class Initialized
INFO - 2023-08-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:13:04 --> Utf8 Class Initialized
INFO - 2023-08-16 17:13:04 --> URI Class Initialized
INFO - 2023-08-16 17:13:04 --> Router Class Initialized
INFO - 2023-08-16 17:13:04 --> Output Class Initialized
INFO - 2023-08-16 17:13:04 --> Security Class Initialized
DEBUG - 2023-08-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:13:04 --> Input Class Initialized
INFO - 2023-08-16 17:13:04 --> Language Class Initialized
INFO - 2023-08-16 17:13:04 --> Loader Class Initialized
INFO - 2023-08-16 17:13:04 --> Helper loaded: url_helper
INFO - 2023-08-16 17:13:04 --> Helper loaded: file_helper
INFO - 2023-08-16 17:13:04 --> Database Driver Class Initialized
INFO - 2023-08-16 17:13:04 --> Email Class Initialized
DEBUG - 2023-08-16 17:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:13:04 --> Controller Class Initialized
INFO - 2023-08-16 17:13:04 --> Model "Home_model" initialized
INFO - 2023-08-16 17:13:04 --> Helper loaded: form_helper
INFO - 2023-08-16 17:13:04 --> Form Validation Class Initialized
INFO - 2023-08-16 17:13:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:13:04 --> Final output sent to browser
DEBUG - 2023-08-16 17:13:05 --> Total execution time: 0.3475
INFO - 2023-08-16 17:13:06 --> Config Class Initialized
INFO - 2023-08-16 17:13:06 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:13:06 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:13:06 --> Utf8 Class Initialized
INFO - 2023-08-16 17:13:06 --> URI Class Initialized
INFO - 2023-08-16 17:13:06 --> Router Class Initialized
INFO - 2023-08-16 17:13:06 --> Output Class Initialized
INFO - 2023-08-16 17:13:06 --> Security Class Initialized
DEBUG - 2023-08-16 17:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:13:06 --> Input Class Initialized
INFO - 2023-08-16 17:13:06 --> Language Class Initialized
ERROR - 2023-08-16 17:13:06 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:13:06 --> Config Class Initialized
INFO - 2023-08-16 17:13:06 --> Config Class Initialized
INFO - 2023-08-16 17:13:06 --> Config Class Initialized
INFO - 2023-08-16 17:13:06 --> Hooks Class Initialized
INFO - 2023-08-16 17:13:06 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:13:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 17:13:06 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:13:06 --> Hooks Class Initialized
INFO - 2023-08-16 17:13:06 --> Config Class Initialized
INFO - 2023-08-16 17:13:06 --> Utf8 Class Initialized
INFO - 2023-08-16 17:13:06 --> Utf8 Class Initialized
INFO - 2023-08-16 17:13:06 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:13:06 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:13:06 --> Utf8 Class Initialized
INFO - 2023-08-16 17:13:06 --> URI Class Initialized
INFO - 2023-08-16 17:13:06 --> Router Class Initialized
INFO - 2023-08-16 17:13:06 --> Output Class Initialized
INFO - 2023-08-16 17:13:06 --> Security Class Initialized
DEBUG - 2023-08-16 17:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:13:06 --> Input Class Initialized
INFO - 2023-08-16 17:13:06 --> Language Class Initialized
ERROR - 2023-08-16 17:13:06 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:13:06 --> URI Class Initialized
DEBUG - 2023-08-16 17:13:06 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:13:06 --> Router Class Initialized
INFO - 2023-08-16 17:13:06 --> URI Class Initialized
INFO - 2023-08-16 17:13:06 --> Utf8 Class Initialized
INFO - 2023-08-16 17:13:06 --> Output Class Initialized
INFO - 2023-08-16 17:13:06 --> Router Class Initialized
INFO - 2023-08-16 17:13:06 --> Security Class Initialized
INFO - 2023-08-16 17:13:06 --> Output Class Initialized
DEBUG - 2023-08-16 17:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:13:06 --> URI Class Initialized
INFO - 2023-08-16 17:13:06 --> Security Class Initialized
INFO - 2023-08-16 17:13:06 --> Input Class Initialized
DEBUG - 2023-08-16 17:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:13:06 --> Router Class Initialized
INFO - 2023-08-16 17:13:06 --> Input Class Initialized
INFO - 2023-08-16 17:13:06 --> Output Class Initialized
INFO - 2023-08-16 17:13:06 --> Language Class Initialized
INFO - 2023-08-16 17:13:06 --> Security Class Initialized
INFO - 2023-08-16 17:13:06 --> Language Class Initialized
ERROR - 2023-08-16 17:13:06 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 17:13:06 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 17:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:13:06 --> Input Class Initialized
INFO - 2023-08-16 17:13:06 --> Language Class Initialized
ERROR - 2023-08-16 17:13:06 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:13:54 --> Config Class Initialized
INFO - 2023-08-16 17:13:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:13:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:13:54 --> Utf8 Class Initialized
INFO - 2023-08-16 17:13:54 --> URI Class Initialized
INFO - 2023-08-16 17:13:54 --> Router Class Initialized
INFO - 2023-08-16 17:13:54 --> Output Class Initialized
INFO - 2023-08-16 17:13:54 --> Security Class Initialized
DEBUG - 2023-08-16 17:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:13:54 --> Input Class Initialized
INFO - 2023-08-16 17:13:54 --> Language Class Initialized
INFO - 2023-08-16 17:13:54 --> Loader Class Initialized
INFO - 2023-08-16 17:13:54 --> Helper loaded: url_helper
INFO - 2023-08-16 17:13:54 --> Helper loaded: file_helper
INFO - 2023-08-16 17:13:54 --> Database Driver Class Initialized
INFO - 2023-08-16 17:13:54 --> Email Class Initialized
DEBUG - 2023-08-16 17:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:13:54 --> Controller Class Initialized
INFO - 2023-08-16 17:13:54 --> Model "Home_model" initialized
INFO - 2023-08-16 17:13:54 --> Helper loaded: form_helper
INFO - 2023-08-16 17:13:55 --> Form Validation Class Initialized
INFO - 2023-08-16 17:13:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:13:55 --> Final output sent to browser
DEBUG - 2023-08-16 17:13:55 --> Total execution time: 0.4608
INFO - 2023-08-16 17:13:55 --> Config Class Initialized
INFO - 2023-08-16 17:13:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:13:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:13:55 --> Utf8 Class Initialized
INFO - 2023-08-16 17:13:55 --> URI Class Initialized
INFO - 2023-08-16 17:13:55 --> Router Class Initialized
INFO - 2023-08-16 17:13:55 --> Output Class Initialized
INFO - 2023-08-16 17:13:55 --> Security Class Initialized
DEBUG - 2023-08-16 17:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:13:55 --> Input Class Initialized
INFO - 2023-08-16 17:13:55 --> Language Class Initialized
ERROR - 2023-08-16 17:13:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:13:55 --> Config Class Initialized
INFO - 2023-08-16 17:13:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:13:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:13:55 --> Utf8 Class Initialized
INFO - 2023-08-16 17:13:55 --> URI Class Initialized
INFO - 2023-08-16 17:13:55 --> Router Class Initialized
INFO - 2023-08-16 17:13:55 --> Output Class Initialized
INFO - 2023-08-16 17:13:55 --> Security Class Initialized
DEBUG - 2023-08-16 17:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:13:55 --> Input Class Initialized
INFO - 2023-08-16 17:13:55 --> Language Class Initialized
ERROR - 2023-08-16 17:13:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:13:55 --> Config Class Initialized
INFO - 2023-08-16 17:13:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:13:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:13:55 --> Utf8 Class Initialized
INFO - 2023-08-16 17:13:55 --> URI Class Initialized
INFO - 2023-08-16 17:13:55 --> Router Class Initialized
INFO - 2023-08-16 17:13:56 --> Output Class Initialized
INFO - 2023-08-16 17:13:56 --> Security Class Initialized
DEBUG - 2023-08-16 17:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:13:56 --> Input Class Initialized
INFO - 2023-08-16 17:13:56 --> Language Class Initialized
ERROR - 2023-08-16 17:13:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:13:56 --> Config Class Initialized
INFO - 2023-08-16 17:13:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:13:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:13:56 --> Utf8 Class Initialized
INFO - 2023-08-16 17:13:56 --> URI Class Initialized
INFO - 2023-08-16 17:13:56 --> Router Class Initialized
INFO - 2023-08-16 17:13:56 --> Output Class Initialized
INFO - 2023-08-16 17:13:56 --> Security Class Initialized
DEBUG - 2023-08-16 17:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:13:56 --> Input Class Initialized
INFO - 2023-08-16 17:13:56 --> Language Class Initialized
ERROR - 2023-08-16 17:13:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:13:56 --> Config Class Initialized
INFO - 2023-08-16 17:13:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:13:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:13:56 --> Utf8 Class Initialized
INFO - 2023-08-16 17:13:56 --> URI Class Initialized
INFO - 2023-08-16 17:13:56 --> Router Class Initialized
INFO - 2023-08-16 17:13:56 --> Output Class Initialized
INFO - 2023-08-16 17:13:56 --> Security Class Initialized
DEBUG - 2023-08-16 17:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:13:56 --> Input Class Initialized
INFO - 2023-08-16 17:13:56 --> Language Class Initialized
ERROR - 2023-08-16 17:13:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:14:07 --> Config Class Initialized
INFO - 2023-08-16 17:14:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:14:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:14:07 --> Utf8 Class Initialized
INFO - 2023-08-16 17:14:07 --> URI Class Initialized
INFO - 2023-08-16 17:14:07 --> Router Class Initialized
INFO - 2023-08-16 17:14:07 --> Output Class Initialized
INFO - 2023-08-16 17:14:07 --> Security Class Initialized
DEBUG - 2023-08-16 17:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:14:07 --> Input Class Initialized
INFO - 2023-08-16 17:14:07 --> Language Class Initialized
INFO - 2023-08-16 17:14:07 --> Loader Class Initialized
INFO - 2023-08-16 17:14:07 --> Helper loaded: url_helper
INFO - 2023-08-16 17:14:07 --> Helper loaded: file_helper
INFO - 2023-08-16 17:14:07 --> Database Driver Class Initialized
INFO - 2023-08-16 17:14:07 --> Email Class Initialized
DEBUG - 2023-08-16 17:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:14:07 --> Controller Class Initialized
INFO - 2023-08-16 17:14:07 --> Model "Home_model" initialized
INFO - 2023-08-16 17:14:07 --> Helper loaded: form_helper
INFO - 2023-08-16 17:14:07 --> Form Validation Class Initialized
INFO - 2023-08-16 17:14:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 17:14:07 --> Final output sent to browser
DEBUG - 2023-08-16 17:14:07 --> Total execution time: 0.1356
INFO - 2023-08-16 17:14:12 --> Config Class Initialized
INFO - 2023-08-16 17:14:12 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:14:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:14:12 --> Utf8 Class Initialized
INFO - 2023-08-16 17:14:12 --> URI Class Initialized
INFO - 2023-08-16 17:14:12 --> Router Class Initialized
INFO - 2023-08-16 17:14:12 --> Output Class Initialized
INFO - 2023-08-16 17:14:12 --> Security Class Initialized
DEBUG - 2023-08-16 17:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:14:12 --> Input Class Initialized
INFO - 2023-08-16 17:14:12 --> Language Class Initialized
INFO - 2023-08-16 17:14:12 --> Loader Class Initialized
INFO - 2023-08-16 17:14:12 --> Helper loaded: url_helper
INFO - 2023-08-16 17:14:12 --> Helper loaded: file_helper
INFO - 2023-08-16 17:14:12 --> Database Driver Class Initialized
INFO - 2023-08-16 17:14:12 --> Email Class Initialized
DEBUG - 2023-08-16 17:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:14:12 --> Controller Class Initialized
INFO - 2023-08-16 17:14:12 --> Model "Home_model" initialized
INFO - 2023-08-16 17:14:12 --> Helper loaded: form_helper
INFO - 2023-08-16 17:14:12 --> Form Validation Class Initialized
INFO - 2023-08-16 17:14:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:14:12 --> Final output sent to browser
DEBUG - 2023-08-16 17:14:12 --> Total execution time: 0.0442
INFO - 2023-08-16 17:14:12 --> Config Class Initialized
INFO - 2023-08-16 17:14:12 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:14:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:14:12 --> Utf8 Class Initialized
INFO - 2023-08-16 17:14:12 --> URI Class Initialized
INFO - 2023-08-16 17:14:12 --> Router Class Initialized
INFO - 2023-08-16 17:14:12 --> Output Class Initialized
INFO - 2023-08-16 17:14:12 --> Security Class Initialized
DEBUG - 2023-08-16 17:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:14:12 --> Input Class Initialized
INFO - 2023-08-16 17:14:12 --> Language Class Initialized
ERROR - 2023-08-16 17:14:12 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:14:12 --> Config Class Initialized
INFO - 2023-08-16 17:14:12 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:14:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:14:12 --> Utf8 Class Initialized
INFO - 2023-08-16 17:14:12 --> URI Class Initialized
INFO - 2023-08-16 17:14:12 --> Router Class Initialized
INFO - 2023-08-16 17:14:12 --> Output Class Initialized
INFO - 2023-08-16 17:14:12 --> Security Class Initialized
DEBUG - 2023-08-16 17:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:14:12 --> Input Class Initialized
INFO - 2023-08-16 17:14:12 --> Language Class Initialized
ERROR - 2023-08-16 17:14:12 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:14:13 --> Config Class Initialized
INFO - 2023-08-16 17:14:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:14:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:14:13 --> Utf8 Class Initialized
INFO - 2023-08-16 17:14:13 --> URI Class Initialized
INFO - 2023-08-16 17:14:13 --> Router Class Initialized
INFO - 2023-08-16 17:14:13 --> Output Class Initialized
INFO - 2023-08-16 17:14:13 --> Security Class Initialized
DEBUG - 2023-08-16 17:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:14:13 --> Input Class Initialized
INFO - 2023-08-16 17:14:13 --> Language Class Initialized
ERROR - 2023-08-16 17:14:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:14:13 --> Config Class Initialized
INFO - 2023-08-16 17:14:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:14:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:14:13 --> Utf8 Class Initialized
INFO - 2023-08-16 17:14:13 --> URI Class Initialized
INFO - 2023-08-16 17:14:13 --> Router Class Initialized
INFO - 2023-08-16 17:14:13 --> Output Class Initialized
INFO - 2023-08-16 17:14:13 --> Security Class Initialized
DEBUG - 2023-08-16 17:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:14:13 --> Input Class Initialized
INFO - 2023-08-16 17:14:13 --> Language Class Initialized
ERROR - 2023-08-16 17:14:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:14:13 --> Config Class Initialized
INFO - 2023-08-16 17:14:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:14:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:14:13 --> Utf8 Class Initialized
INFO - 2023-08-16 17:14:13 --> URI Class Initialized
INFO - 2023-08-16 17:14:13 --> Router Class Initialized
INFO - 2023-08-16 17:14:13 --> Output Class Initialized
INFO - 2023-08-16 17:14:13 --> Security Class Initialized
DEBUG - 2023-08-16 17:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:14:13 --> Input Class Initialized
INFO - 2023-08-16 17:14:13 --> Language Class Initialized
ERROR - 2023-08-16 17:14:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:14:13 --> Config Class Initialized
INFO - 2023-08-16 17:14:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:14:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:14:13 --> Utf8 Class Initialized
INFO - 2023-08-16 17:14:13 --> URI Class Initialized
INFO - 2023-08-16 17:14:13 --> Router Class Initialized
INFO - 2023-08-16 17:14:13 --> Output Class Initialized
INFO - 2023-08-16 17:14:13 --> Security Class Initialized
DEBUG - 2023-08-16 17:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:14:13 --> Input Class Initialized
INFO - 2023-08-16 17:14:13 --> Language Class Initialized
ERROR - 2023-08-16 17:14:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:35:13 --> Config Class Initialized
INFO - 2023-08-16 17:35:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:35:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:35:13 --> Utf8 Class Initialized
INFO - 2023-08-16 17:35:13 --> URI Class Initialized
INFO - 2023-08-16 17:35:13 --> Router Class Initialized
INFO - 2023-08-16 17:35:13 --> Output Class Initialized
INFO - 2023-08-16 17:35:13 --> Security Class Initialized
DEBUG - 2023-08-16 17:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:35:13 --> Input Class Initialized
INFO - 2023-08-16 17:35:13 --> Language Class Initialized
INFO - 2023-08-16 17:35:13 --> Loader Class Initialized
INFO - 2023-08-16 17:35:13 --> Helper loaded: url_helper
INFO - 2023-08-16 17:35:13 --> Helper loaded: file_helper
INFO - 2023-08-16 17:35:13 --> Database Driver Class Initialized
INFO - 2023-08-16 17:35:13 --> Email Class Initialized
DEBUG - 2023-08-16 17:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:35:13 --> Controller Class Initialized
INFO - 2023-08-16 17:35:13 --> Model "Home_model" initialized
INFO - 2023-08-16 17:35:13 --> Helper loaded: form_helper
INFO - 2023-08-16 17:35:13 --> Form Validation Class Initialized
INFO - 2023-08-16 17:35:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:35:13 --> Final output sent to browser
DEBUG - 2023-08-16 17:35:14 --> Total execution time: 0.1823
INFO - 2023-08-16 17:35:14 --> Config Class Initialized
INFO - 2023-08-16 17:35:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:35:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:35:14 --> Utf8 Class Initialized
INFO - 2023-08-16 17:35:14 --> URI Class Initialized
INFO - 2023-08-16 17:35:14 --> Router Class Initialized
INFO - 2023-08-16 17:35:14 --> Output Class Initialized
INFO - 2023-08-16 17:35:14 --> Security Class Initialized
DEBUG - 2023-08-16 17:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:35:14 --> Input Class Initialized
INFO - 2023-08-16 17:35:14 --> Language Class Initialized
ERROR - 2023-08-16 17:35:14 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:35:14 --> Config Class Initialized
INFO - 2023-08-16 17:35:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:35:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:35:14 --> Utf8 Class Initialized
INFO - 2023-08-16 17:35:14 --> URI Class Initialized
INFO - 2023-08-16 17:35:14 --> Router Class Initialized
INFO - 2023-08-16 17:35:14 --> Output Class Initialized
INFO - 2023-08-16 17:35:14 --> Security Class Initialized
DEBUG - 2023-08-16 17:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:35:14 --> Input Class Initialized
INFO - 2023-08-16 17:35:14 --> Language Class Initialized
ERROR - 2023-08-16 17:35:14 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:35:14 --> Config Class Initialized
INFO - 2023-08-16 17:35:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:35:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:35:14 --> Utf8 Class Initialized
INFO - 2023-08-16 17:35:14 --> URI Class Initialized
INFO - 2023-08-16 17:35:14 --> Router Class Initialized
INFO - 2023-08-16 17:35:14 --> Output Class Initialized
INFO - 2023-08-16 17:35:14 --> Security Class Initialized
DEBUG - 2023-08-16 17:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:35:14 --> Input Class Initialized
INFO - 2023-08-16 17:35:14 --> Language Class Initialized
ERROR - 2023-08-16 17:35:14 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:35:14 --> Config Class Initialized
INFO - 2023-08-16 17:35:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:35:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:35:14 --> Utf8 Class Initialized
INFO - 2023-08-16 17:35:14 --> URI Class Initialized
INFO - 2023-08-16 17:35:14 --> Router Class Initialized
INFO - 2023-08-16 17:35:14 --> Output Class Initialized
INFO - 2023-08-16 17:35:14 --> Security Class Initialized
DEBUG - 2023-08-16 17:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:35:14 --> Input Class Initialized
INFO - 2023-08-16 17:35:14 --> Language Class Initialized
ERROR - 2023-08-16 17:35:14 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:35:14 --> Config Class Initialized
INFO - 2023-08-16 17:35:14 --> Hooks Class Initialized
INFO - 2023-08-16 17:35:14 --> Config Class Initialized
INFO - 2023-08-16 17:35:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:35:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:35:14 --> Utf8 Class Initialized
INFO - 2023-08-16 17:35:14 --> URI Class Initialized
INFO - 2023-08-16 17:35:14 --> Router Class Initialized
INFO - 2023-08-16 17:35:14 --> Output Class Initialized
INFO - 2023-08-16 17:35:14 --> Security Class Initialized
DEBUG - 2023-08-16 17:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:35:14 --> Input Class Initialized
INFO - 2023-08-16 17:35:14 --> Language Class Initialized
ERROR - 2023-08-16 17:35:14 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 17:35:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:35:14 --> Utf8 Class Initialized
INFO - 2023-08-16 17:35:14 --> URI Class Initialized
INFO - 2023-08-16 17:35:14 --> Router Class Initialized
INFO - 2023-08-16 17:35:14 --> Output Class Initialized
INFO - 2023-08-16 17:35:15 --> Security Class Initialized
DEBUG - 2023-08-16 17:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:35:15 --> Input Class Initialized
INFO - 2023-08-16 17:35:15 --> Language Class Initialized
ERROR - 2023-08-16 17:35:15 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:36:18 --> Config Class Initialized
INFO - 2023-08-16 17:36:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:36:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:36:18 --> Utf8 Class Initialized
INFO - 2023-08-16 17:36:18 --> URI Class Initialized
INFO - 2023-08-16 17:36:18 --> Router Class Initialized
INFO - 2023-08-16 17:36:18 --> Output Class Initialized
INFO - 2023-08-16 17:36:18 --> Security Class Initialized
DEBUG - 2023-08-16 17:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:36:18 --> Input Class Initialized
INFO - 2023-08-16 17:36:18 --> Language Class Initialized
INFO - 2023-08-16 17:36:18 --> Loader Class Initialized
INFO - 2023-08-16 17:36:18 --> Helper loaded: url_helper
INFO - 2023-08-16 17:36:18 --> Helper loaded: file_helper
INFO - 2023-08-16 17:36:18 --> Database Driver Class Initialized
INFO - 2023-08-16 17:36:18 --> Email Class Initialized
DEBUG - 2023-08-16 17:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:36:18 --> Controller Class Initialized
INFO - 2023-08-16 17:36:18 --> Model "Home_model" initialized
INFO - 2023-08-16 17:36:18 --> Helper loaded: form_helper
INFO - 2023-08-16 17:36:18 --> Form Validation Class Initialized
INFO - 2023-08-16 17:36:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:36:18 --> Final output sent to browser
DEBUG - 2023-08-16 17:36:18 --> Total execution time: 0.1136
INFO - 2023-08-16 17:36:18 --> Config Class Initialized
INFO - 2023-08-16 17:36:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:36:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:36:18 --> Utf8 Class Initialized
INFO - 2023-08-16 17:36:18 --> URI Class Initialized
INFO - 2023-08-16 17:36:18 --> Router Class Initialized
INFO - 2023-08-16 17:36:18 --> Output Class Initialized
INFO - 2023-08-16 17:36:18 --> Security Class Initialized
DEBUG - 2023-08-16 17:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:36:18 --> Input Class Initialized
INFO - 2023-08-16 17:36:18 --> Language Class Initialized
ERROR - 2023-08-16 17:36:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:36:18 --> Config Class Initialized
INFO - 2023-08-16 17:36:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:36:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:36:18 --> Utf8 Class Initialized
INFO - 2023-08-16 17:36:18 --> URI Class Initialized
INFO - 2023-08-16 17:36:18 --> Router Class Initialized
INFO - 2023-08-16 17:36:18 --> Output Class Initialized
INFO - 2023-08-16 17:36:18 --> Security Class Initialized
DEBUG - 2023-08-16 17:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:36:18 --> Input Class Initialized
INFO - 2023-08-16 17:36:18 --> Language Class Initialized
ERROR - 2023-08-16 17:36:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:36:18 --> Config Class Initialized
INFO - 2023-08-16 17:36:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:36:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:36:18 --> Utf8 Class Initialized
INFO - 2023-08-16 17:36:18 --> URI Class Initialized
INFO - 2023-08-16 17:36:18 --> Router Class Initialized
INFO - 2023-08-16 17:36:18 --> Output Class Initialized
INFO - 2023-08-16 17:36:18 --> Security Class Initialized
DEBUG - 2023-08-16 17:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:36:18 --> Input Class Initialized
INFO - 2023-08-16 17:36:18 --> Language Class Initialized
ERROR - 2023-08-16 17:36:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:36:18 --> Config Class Initialized
INFO - 2023-08-16 17:36:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:36:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:36:18 --> Utf8 Class Initialized
INFO - 2023-08-16 17:36:18 --> URI Class Initialized
INFO - 2023-08-16 17:36:18 --> Router Class Initialized
INFO - 2023-08-16 17:36:18 --> Output Class Initialized
INFO - 2023-08-16 17:36:18 --> Security Class Initialized
DEBUG - 2023-08-16 17:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:36:18 --> Input Class Initialized
INFO - 2023-08-16 17:36:18 --> Language Class Initialized
ERROR - 2023-08-16 17:36:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:36:19 --> Config Class Initialized
INFO - 2023-08-16 17:36:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:36:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:36:19 --> Utf8 Class Initialized
INFO - 2023-08-16 17:36:19 --> URI Class Initialized
INFO - 2023-08-16 17:36:19 --> Router Class Initialized
INFO - 2023-08-16 17:36:19 --> Output Class Initialized
INFO - 2023-08-16 17:36:19 --> Security Class Initialized
DEBUG - 2023-08-16 17:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:36:19 --> Input Class Initialized
INFO - 2023-08-16 17:36:19 --> Language Class Initialized
ERROR - 2023-08-16 17:36:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:38:18 --> Config Class Initialized
INFO - 2023-08-16 17:38:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:38:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:38:18 --> Utf8 Class Initialized
INFO - 2023-08-16 17:38:18 --> URI Class Initialized
INFO - 2023-08-16 17:38:18 --> Router Class Initialized
INFO - 2023-08-16 17:38:18 --> Output Class Initialized
INFO - 2023-08-16 17:38:18 --> Security Class Initialized
DEBUG - 2023-08-16 17:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:38:18 --> Input Class Initialized
INFO - 2023-08-16 17:38:18 --> Language Class Initialized
INFO - 2023-08-16 17:38:18 --> Loader Class Initialized
INFO - 2023-08-16 17:38:18 --> Helper loaded: url_helper
INFO - 2023-08-16 17:38:18 --> Helper loaded: file_helper
INFO - 2023-08-16 17:38:18 --> Database Driver Class Initialized
INFO - 2023-08-16 17:38:18 --> Email Class Initialized
DEBUG - 2023-08-16 17:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:38:18 --> Controller Class Initialized
INFO - 2023-08-16 17:38:18 --> Model "Home_model" initialized
INFO - 2023-08-16 17:38:18 --> Helper loaded: form_helper
INFO - 2023-08-16 17:38:18 --> Form Validation Class Initialized
INFO - 2023-08-16 17:38:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:38:18 --> Final output sent to browser
DEBUG - 2023-08-16 17:38:18 --> Total execution time: 0.1392
INFO - 2023-08-16 17:38:18 --> Config Class Initialized
INFO - 2023-08-16 17:38:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:38:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:38:18 --> Utf8 Class Initialized
INFO - 2023-08-16 17:38:18 --> URI Class Initialized
INFO - 2023-08-16 17:38:18 --> Router Class Initialized
INFO - 2023-08-16 17:38:18 --> Output Class Initialized
INFO - 2023-08-16 17:38:18 --> Security Class Initialized
DEBUG - 2023-08-16 17:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:38:18 --> Input Class Initialized
INFO - 2023-08-16 17:38:18 --> Language Class Initialized
ERROR - 2023-08-16 17:38:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:38:18 --> Config Class Initialized
INFO - 2023-08-16 17:38:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:38:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:38:18 --> Utf8 Class Initialized
INFO - 2023-08-16 17:38:18 --> URI Class Initialized
INFO - 2023-08-16 17:38:18 --> Router Class Initialized
INFO - 2023-08-16 17:38:18 --> Output Class Initialized
INFO - 2023-08-16 17:38:18 --> Security Class Initialized
DEBUG - 2023-08-16 17:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:38:18 --> Input Class Initialized
INFO - 2023-08-16 17:38:18 --> Language Class Initialized
ERROR - 2023-08-16 17:38:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:38:18 --> Config Class Initialized
INFO - 2023-08-16 17:38:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:38:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:38:18 --> Utf8 Class Initialized
INFO - 2023-08-16 17:38:18 --> URI Class Initialized
INFO - 2023-08-16 17:38:18 --> Router Class Initialized
INFO - 2023-08-16 17:38:18 --> Output Class Initialized
INFO - 2023-08-16 17:38:18 --> Security Class Initialized
DEBUG - 2023-08-16 17:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:38:18 --> Input Class Initialized
INFO - 2023-08-16 17:38:18 --> Language Class Initialized
ERROR - 2023-08-16 17:38:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:38:19 --> Config Class Initialized
INFO - 2023-08-16 17:38:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:38:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:38:19 --> Utf8 Class Initialized
INFO - 2023-08-16 17:38:19 --> URI Class Initialized
INFO - 2023-08-16 17:38:19 --> Router Class Initialized
INFO - 2023-08-16 17:38:19 --> Output Class Initialized
INFO - 2023-08-16 17:38:19 --> Security Class Initialized
DEBUG - 2023-08-16 17:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:38:19 --> Input Class Initialized
INFO - 2023-08-16 17:38:19 --> Language Class Initialized
ERROR - 2023-08-16 17:38:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:38:19 --> Config Class Initialized
INFO - 2023-08-16 17:38:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:38:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:38:19 --> Utf8 Class Initialized
INFO - 2023-08-16 17:38:19 --> URI Class Initialized
INFO - 2023-08-16 17:38:19 --> Router Class Initialized
INFO - 2023-08-16 17:38:19 --> Output Class Initialized
INFO - 2023-08-16 17:38:19 --> Security Class Initialized
DEBUG - 2023-08-16 17:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:38:19 --> Input Class Initialized
INFO - 2023-08-16 17:38:19 --> Language Class Initialized
ERROR - 2023-08-16 17:38:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:39:48 --> Config Class Initialized
INFO - 2023-08-16 17:39:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:39:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:39:48 --> Utf8 Class Initialized
INFO - 2023-08-16 17:39:48 --> URI Class Initialized
INFO - 2023-08-16 17:39:48 --> Router Class Initialized
INFO - 2023-08-16 17:39:48 --> Output Class Initialized
INFO - 2023-08-16 17:39:48 --> Security Class Initialized
DEBUG - 2023-08-16 17:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:39:48 --> Input Class Initialized
INFO - 2023-08-16 17:39:48 --> Language Class Initialized
INFO - 2023-08-16 17:39:48 --> Loader Class Initialized
INFO - 2023-08-16 17:39:48 --> Helper loaded: url_helper
INFO - 2023-08-16 17:39:48 --> Helper loaded: file_helper
INFO - 2023-08-16 17:39:48 --> Database Driver Class Initialized
INFO - 2023-08-16 17:39:48 --> Email Class Initialized
DEBUG - 2023-08-16 17:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:39:48 --> Controller Class Initialized
INFO - 2023-08-16 17:39:48 --> Model "Home_model" initialized
INFO - 2023-08-16 17:39:48 --> Helper loaded: form_helper
INFO - 2023-08-16 17:39:48 --> Form Validation Class Initialized
INFO - 2023-08-16 17:39:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 17:39:48 --> Final output sent to browser
DEBUG - 2023-08-16 17:39:48 --> Total execution time: 0.5308
INFO - 2023-08-16 17:39:48 --> Config Class Initialized
INFO - 2023-08-16 17:39:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:39:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:39:48 --> Utf8 Class Initialized
INFO - 2023-08-16 17:39:48 --> URI Class Initialized
INFO - 2023-08-16 17:39:48 --> Router Class Initialized
INFO - 2023-08-16 17:39:48 --> Output Class Initialized
INFO - 2023-08-16 17:39:48 --> Security Class Initialized
DEBUG - 2023-08-16 17:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:39:48 --> Input Class Initialized
INFO - 2023-08-16 17:39:48 --> Language Class Initialized
ERROR - 2023-08-16 17:39:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:39:49 --> Config Class Initialized
INFO - 2023-08-16 17:39:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:39:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:39:49 --> Utf8 Class Initialized
INFO - 2023-08-16 17:39:49 --> URI Class Initialized
INFO - 2023-08-16 17:39:49 --> Router Class Initialized
INFO - 2023-08-16 17:39:49 --> Output Class Initialized
INFO - 2023-08-16 17:39:49 --> Security Class Initialized
DEBUG - 2023-08-16 17:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:39:49 --> Input Class Initialized
INFO - 2023-08-16 17:39:49 --> Language Class Initialized
ERROR - 2023-08-16 17:39:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:39:49 --> Config Class Initialized
INFO - 2023-08-16 17:39:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:39:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:39:49 --> Utf8 Class Initialized
INFO - 2023-08-16 17:39:49 --> URI Class Initialized
INFO - 2023-08-16 17:39:49 --> Router Class Initialized
INFO - 2023-08-16 17:39:49 --> Output Class Initialized
INFO - 2023-08-16 17:39:49 --> Security Class Initialized
DEBUG - 2023-08-16 17:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:39:49 --> Input Class Initialized
INFO - 2023-08-16 17:39:49 --> Language Class Initialized
ERROR - 2023-08-16 17:39:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:39:49 --> Config Class Initialized
INFO - 2023-08-16 17:39:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:39:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:39:49 --> Utf8 Class Initialized
INFO - 2023-08-16 17:39:49 --> URI Class Initialized
INFO - 2023-08-16 17:39:49 --> Router Class Initialized
INFO - 2023-08-16 17:39:49 --> Output Class Initialized
INFO - 2023-08-16 17:39:49 --> Security Class Initialized
DEBUG - 2023-08-16 17:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:39:49 --> Input Class Initialized
INFO - 2023-08-16 17:39:49 --> Language Class Initialized
ERROR - 2023-08-16 17:39:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:39:49 --> Config Class Initialized
INFO - 2023-08-16 17:39:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:39:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:39:49 --> Utf8 Class Initialized
INFO - 2023-08-16 17:39:49 --> URI Class Initialized
INFO - 2023-08-16 17:39:49 --> Router Class Initialized
INFO - 2023-08-16 17:39:49 --> Output Class Initialized
INFO - 2023-08-16 17:39:49 --> Security Class Initialized
DEBUG - 2023-08-16 17:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:39:49 --> Input Class Initialized
INFO - 2023-08-16 17:39:49 --> Language Class Initialized
ERROR - 2023-08-16 17:39:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:40:18 --> Config Class Initialized
INFO - 2023-08-16 17:40:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:40:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:40:18 --> Utf8 Class Initialized
INFO - 2023-08-16 17:40:18 --> URI Class Initialized
INFO - 2023-08-16 17:40:18 --> Router Class Initialized
INFO - 2023-08-16 17:40:18 --> Output Class Initialized
INFO - 2023-08-16 17:40:18 --> Security Class Initialized
DEBUG - 2023-08-16 17:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:40:18 --> Input Class Initialized
INFO - 2023-08-16 17:40:18 --> Language Class Initialized
INFO - 2023-08-16 17:40:19 --> Loader Class Initialized
INFO - 2023-08-16 17:40:19 --> Helper loaded: url_helper
INFO - 2023-08-16 17:40:19 --> Helper loaded: file_helper
INFO - 2023-08-16 17:40:19 --> Database Driver Class Initialized
INFO - 2023-08-16 17:40:19 --> Email Class Initialized
DEBUG - 2023-08-16 17:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:40:19 --> Controller Class Initialized
INFO - 2023-08-16 17:40:19 --> Model "Home_model" initialized
INFO - 2023-08-16 17:40:19 --> Helper loaded: form_helper
INFO - 2023-08-16 17:40:19 --> Form Validation Class Initialized
INFO - 2023-08-16 17:40:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 17:40:19 --> Final output sent to browser
DEBUG - 2023-08-16 17:40:19 --> Total execution time: 0.1829
INFO - 2023-08-16 17:40:19 --> Config Class Initialized
INFO - 2023-08-16 17:40:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:40:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:40:19 --> Utf8 Class Initialized
INFO - 2023-08-16 17:40:19 --> URI Class Initialized
INFO - 2023-08-16 17:40:19 --> Router Class Initialized
INFO - 2023-08-16 17:40:19 --> Output Class Initialized
INFO - 2023-08-16 17:40:19 --> Security Class Initialized
DEBUG - 2023-08-16 17:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:40:19 --> Input Class Initialized
INFO - 2023-08-16 17:40:19 --> Language Class Initialized
ERROR - 2023-08-16 17:40:19 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:40:19 --> Config Class Initialized
INFO - 2023-08-16 17:40:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:40:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:40:19 --> Utf8 Class Initialized
INFO - 2023-08-16 17:40:19 --> URI Class Initialized
INFO - 2023-08-16 17:40:19 --> Router Class Initialized
INFO - 2023-08-16 17:40:19 --> Output Class Initialized
INFO - 2023-08-16 17:40:19 --> Security Class Initialized
DEBUG - 2023-08-16 17:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:40:19 --> Input Class Initialized
INFO - 2023-08-16 17:40:19 --> Language Class Initialized
ERROR - 2023-08-16 17:40:19 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:40:19 --> Config Class Initialized
INFO - 2023-08-16 17:40:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:40:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:40:19 --> Utf8 Class Initialized
INFO - 2023-08-16 17:40:19 --> URI Class Initialized
INFO - 2023-08-16 17:40:19 --> Router Class Initialized
INFO - 2023-08-16 17:40:19 --> Output Class Initialized
INFO - 2023-08-16 17:40:19 --> Security Class Initialized
DEBUG - 2023-08-16 17:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:40:19 --> Input Class Initialized
INFO - 2023-08-16 17:40:19 --> Language Class Initialized
ERROR - 2023-08-16 17:40:19 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:40:19 --> Config Class Initialized
INFO - 2023-08-16 17:40:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:40:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:40:20 --> Utf8 Class Initialized
INFO - 2023-08-16 17:40:20 --> URI Class Initialized
INFO - 2023-08-16 17:40:20 --> Router Class Initialized
INFO - 2023-08-16 17:40:20 --> Output Class Initialized
INFO - 2023-08-16 17:40:20 --> Security Class Initialized
DEBUG - 2023-08-16 17:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:40:20 --> Input Class Initialized
INFO - 2023-08-16 17:40:20 --> Language Class Initialized
ERROR - 2023-08-16 17:40:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:40:20 --> Config Class Initialized
INFO - 2023-08-16 17:40:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:40:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:40:20 --> Utf8 Class Initialized
INFO - 2023-08-16 17:40:20 --> URI Class Initialized
INFO - 2023-08-16 17:40:20 --> Router Class Initialized
INFO - 2023-08-16 17:40:20 --> Output Class Initialized
INFO - 2023-08-16 17:40:20 --> Security Class Initialized
DEBUG - 2023-08-16 17:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:40:20 --> Input Class Initialized
INFO - 2023-08-16 17:40:20 --> Language Class Initialized
ERROR - 2023-08-16 17:40:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 17:40:30 --> Config Class Initialized
INFO - 2023-08-16 17:40:30 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:40:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:40:30 --> Utf8 Class Initialized
INFO - 2023-08-16 17:40:30 --> URI Class Initialized
INFO - 2023-08-16 17:40:31 --> Router Class Initialized
INFO - 2023-08-16 17:40:31 --> Output Class Initialized
INFO - 2023-08-16 17:40:31 --> Security Class Initialized
DEBUG - 2023-08-16 17:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:40:31 --> Input Class Initialized
INFO - 2023-08-16 17:40:31 --> Language Class Initialized
INFO - 2023-08-16 17:40:31 --> Loader Class Initialized
INFO - 2023-08-16 17:40:31 --> Helper loaded: url_helper
INFO - 2023-08-16 17:40:31 --> Helper loaded: file_helper
INFO - 2023-08-16 17:40:31 --> Database Driver Class Initialized
INFO - 2023-08-16 17:40:31 --> Email Class Initialized
DEBUG - 2023-08-16 17:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:40:31 --> Controller Class Initialized
INFO - 2023-08-16 17:40:31 --> Model "Home_model" initialized
INFO - 2023-08-16 17:40:31 --> Helper loaded: form_helper
INFO - 2023-08-16 17:40:31 --> Form Validation Class Initialized
INFO - 2023-08-16 17:40:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 17:40:31 --> Final output sent to browser
DEBUG - 2023-08-16 17:40:31 --> Total execution time: 0.5622
INFO - 2023-08-16 17:40:31 --> Config Class Initialized
INFO - 2023-08-16 17:40:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:40:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:40:31 --> Utf8 Class Initialized
INFO - 2023-08-16 17:40:31 --> URI Class Initialized
INFO - 2023-08-16 17:40:31 --> Router Class Initialized
INFO - 2023-08-16 17:40:31 --> Output Class Initialized
INFO - 2023-08-16 17:40:31 --> Security Class Initialized
DEBUG - 2023-08-16 17:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:40:31 --> Input Class Initialized
INFO - 2023-08-16 17:40:31 --> Language Class Initialized
ERROR - 2023-08-16 17:40:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:40:31 --> Config Class Initialized
INFO - 2023-08-16 17:40:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:40:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:40:31 --> Utf8 Class Initialized
INFO - 2023-08-16 17:40:31 --> URI Class Initialized
INFO - 2023-08-16 17:40:31 --> Router Class Initialized
INFO - 2023-08-16 17:40:31 --> Output Class Initialized
INFO - 2023-08-16 17:40:31 --> Security Class Initialized
DEBUG - 2023-08-16 17:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:40:31 --> Input Class Initialized
INFO - 2023-08-16 17:40:31 --> Language Class Initialized
ERROR - 2023-08-16 17:40:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:40:32 --> Config Class Initialized
INFO - 2023-08-16 17:40:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:40:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:40:32 --> Utf8 Class Initialized
INFO - 2023-08-16 17:40:32 --> URI Class Initialized
INFO - 2023-08-16 17:40:32 --> Router Class Initialized
INFO - 2023-08-16 17:40:32 --> Output Class Initialized
INFO - 2023-08-16 17:40:32 --> Security Class Initialized
DEBUG - 2023-08-16 17:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:40:32 --> Input Class Initialized
INFO - 2023-08-16 17:40:32 --> Language Class Initialized
ERROR - 2023-08-16 17:40:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:40:32 --> Config Class Initialized
INFO - 2023-08-16 17:40:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:40:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:40:32 --> Utf8 Class Initialized
INFO - 2023-08-16 17:40:32 --> URI Class Initialized
INFO - 2023-08-16 17:40:32 --> Router Class Initialized
INFO - 2023-08-16 17:40:32 --> Output Class Initialized
INFO - 2023-08-16 17:40:32 --> Security Class Initialized
DEBUG - 2023-08-16 17:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:40:32 --> Input Class Initialized
INFO - 2023-08-16 17:40:32 --> Language Class Initialized
ERROR - 2023-08-16 17:40:33 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:40:33 --> Config Class Initialized
INFO - 2023-08-16 17:40:33 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:40:33 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:40:33 --> Utf8 Class Initialized
INFO - 2023-08-16 17:40:33 --> URI Class Initialized
INFO - 2023-08-16 17:40:33 --> Router Class Initialized
INFO - 2023-08-16 17:40:33 --> Output Class Initialized
INFO - 2023-08-16 17:40:33 --> Security Class Initialized
DEBUG - 2023-08-16 17:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:40:33 --> Input Class Initialized
INFO - 2023-08-16 17:40:33 --> Language Class Initialized
ERROR - 2023-08-16 17:40:33 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 17:43:37 --> Config Class Initialized
INFO - 2023-08-16 17:43:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:43:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:43:37 --> Utf8 Class Initialized
INFO - 2023-08-16 17:43:37 --> URI Class Initialized
INFO - 2023-08-16 17:43:45 --> Config Class Initialized
INFO - 2023-08-16 17:43:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:43:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:43:45 --> Utf8 Class Initialized
INFO - 2023-08-16 17:43:45 --> URI Class Initialized
INFO - 2023-08-16 17:43:45 --> Router Class Initialized
INFO - 2023-08-16 17:43:45 --> Output Class Initialized
INFO - 2023-08-16 17:43:45 --> Security Class Initialized
DEBUG - 2023-08-16 17:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:43:45 --> Input Class Initialized
INFO - 2023-08-16 17:43:45 --> Language Class Initialized
ERROR - 2023-08-16 17:43:45 --> 404 Page Not Found: DW/admin
INFO - 2023-08-16 17:43:57 --> Config Class Initialized
INFO - 2023-08-16 17:43:57 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:43:57 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:43:57 --> Utf8 Class Initialized
INFO - 2023-08-16 17:43:57 --> URI Class Initialized
INFO - 2023-08-16 17:43:57 --> Router Class Initialized
INFO - 2023-08-16 17:43:57 --> Output Class Initialized
INFO - 2023-08-16 17:43:57 --> Security Class Initialized
DEBUG - 2023-08-16 17:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:43:57 --> Input Class Initialized
INFO - 2023-08-16 17:43:57 --> Language Class Initialized
INFO - 2023-08-16 17:43:58 --> Loader Class Initialized
INFO - 2023-08-16 17:43:58 --> Helper loaded: url_helper
INFO - 2023-08-16 17:43:58 --> Helper loaded: file_helper
INFO - 2023-08-16 17:43:58 --> Database Driver Class Initialized
INFO - 2023-08-16 17:43:58 --> Email Class Initialized
DEBUG - 2023-08-16 17:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:43:58 --> Controller Class Initialized
INFO - 2023-08-16 17:43:58 --> Config Class Initialized
INFO - 2023-08-16 17:43:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:43:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:43:58 --> Utf8 Class Initialized
INFO - 2023-08-16 17:43:58 --> URI Class Initialized
INFO - 2023-08-16 17:43:58 --> Router Class Initialized
INFO - 2023-08-16 17:43:58 --> Output Class Initialized
INFO - 2023-08-16 17:43:58 --> Security Class Initialized
DEBUG - 2023-08-16 17:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:43:58 --> Input Class Initialized
INFO - 2023-08-16 17:43:58 --> Language Class Initialized
INFO - 2023-08-16 17:43:58 --> Loader Class Initialized
INFO - 2023-08-16 17:43:58 --> Helper loaded: url_helper
INFO - 2023-08-16 17:43:58 --> Helper loaded: file_helper
INFO - 2023-08-16 17:43:58 --> Database Driver Class Initialized
INFO - 2023-08-16 17:43:58 --> Email Class Initialized
DEBUG - 2023-08-16 17:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:43:58 --> Controller Class Initialized
INFO - 2023-08-16 17:43:58 --> Model "User_model" initialized
INFO - 2023-08-16 17:43:58 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-16 17:43:58 --> Final output sent to browser
DEBUG - 2023-08-16 17:43:58 --> Total execution time: 0.2678
INFO - 2023-08-16 17:44:02 --> Config Class Initialized
INFO - 2023-08-16 17:44:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:44:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:44:02 --> Utf8 Class Initialized
INFO - 2023-08-16 17:44:02 --> URI Class Initialized
INFO - 2023-08-16 17:44:02 --> Router Class Initialized
INFO - 2023-08-16 17:44:02 --> Output Class Initialized
INFO - 2023-08-16 17:44:02 --> Security Class Initialized
DEBUG - 2023-08-16 17:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:44:02 --> Input Class Initialized
INFO - 2023-08-16 17:44:02 --> Language Class Initialized
ERROR - 2023-08-16 17:44:02 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-16 17:44:08 --> Config Class Initialized
INFO - 2023-08-16 17:44:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:44:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:44:08 --> Utf8 Class Initialized
INFO - 2023-08-16 17:44:08 --> URI Class Initialized
INFO - 2023-08-16 17:44:08 --> Router Class Initialized
INFO - 2023-08-16 17:44:08 --> Output Class Initialized
INFO - 2023-08-16 17:44:08 --> Security Class Initialized
DEBUG - 2023-08-16 17:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:44:08 --> Input Class Initialized
INFO - 2023-08-16 17:44:08 --> Language Class Initialized
INFO - 2023-08-16 17:44:08 --> Loader Class Initialized
INFO - 2023-08-16 17:44:08 --> Helper loaded: url_helper
INFO - 2023-08-16 17:44:08 --> Helper loaded: file_helper
INFO - 2023-08-16 17:44:08 --> Database Driver Class Initialized
INFO - 2023-08-16 17:44:08 --> Email Class Initialized
DEBUG - 2023-08-16 17:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:44:08 --> Controller Class Initialized
INFO - 2023-08-16 17:44:08 --> Model "User_model" initialized
INFO - 2023-08-16 17:44:08 --> Config Class Initialized
INFO - 2023-08-16 17:44:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:44:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:44:08 --> Utf8 Class Initialized
INFO - 2023-08-16 17:44:08 --> URI Class Initialized
INFO - 2023-08-16 17:44:08 --> Router Class Initialized
INFO - 2023-08-16 17:44:08 --> Output Class Initialized
INFO - 2023-08-16 17:44:08 --> Security Class Initialized
DEBUG - 2023-08-16 17:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:44:08 --> Input Class Initialized
INFO - 2023-08-16 17:44:08 --> Language Class Initialized
INFO - 2023-08-16 17:44:08 --> Loader Class Initialized
INFO - 2023-08-16 17:44:08 --> Helper loaded: url_helper
INFO - 2023-08-16 17:44:08 --> Helper loaded: file_helper
INFO - 2023-08-16 17:44:08 --> Database Driver Class Initialized
INFO - 2023-08-16 17:44:08 --> Email Class Initialized
DEBUG - 2023-08-16 17:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:44:08 --> Controller Class Initialized
INFO - 2023-08-16 17:44:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-16 17:44:08 --> Final output sent to browser
DEBUG - 2023-08-16 17:44:08 --> Total execution time: 0.1622
INFO - 2023-08-16 17:44:17 --> Config Class Initialized
INFO - 2023-08-16 17:44:17 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:44:17 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:44:17 --> Utf8 Class Initialized
INFO - 2023-08-16 17:44:17 --> URI Class Initialized
INFO - 2023-08-16 17:44:17 --> Router Class Initialized
INFO - 2023-08-16 17:44:17 --> Output Class Initialized
INFO - 2023-08-16 17:44:17 --> Security Class Initialized
DEBUG - 2023-08-16 17:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:44:17 --> Input Class Initialized
INFO - 2023-08-16 17:44:17 --> Language Class Initialized
INFO - 2023-08-16 17:44:17 --> Loader Class Initialized
INFO - 2023-08-16 17:44:17 --> Helper loaded: url_helper
INFO - 2023-08-16 17:44:17 --> Helper loaded: file_helper
INFO - 2023-08-16 17:44:17 --> Database Driver Class Initialized
INFO - 2023-08-16 17:44:17 --> Email Class Initialized
DEBUG - 2023-08-16 17:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:44:17 --> Controller Class Initialized
INFO - 2023-08-16 17:44:17 --> Model "Training_model" initialized
INFO - 2023-08-16 17:44:17 --> Helper loaded: form_helper
INFO - 2023-08-16 17:44:17 --> Form Validation Class Initialized
INFO - 2023-08-16 17:44:17 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-16 17:44:17 --> Final output sent to browser
DEBUG - 2023-08-16 17:44:17 --> Total execution time: 0.1933
INFO - 2023-08-16 17:44:21 --> Config Class Initialized
INFO - 2023-08-16 17:44:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:44:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:44:21 --> Utf8 Class Initialized
INFO - 2023-08-16 17:44:21 --> URI Class Initialized
INFO - 2023-08-16 17:44:21 --> Router Class Initialized
INFO - 2023-08-16 17:44:21 --> Output Class Initialized
INFO - 2023-08-16 17:44:21 --> Security Class Initialized
DEBUG - 2023-08-16 17:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:44:21 --> Input Class Initialized
INFO - 2023-08-16 17:44:21 --> Language Class Initialized
INFO - 2023-08-16 17:44:21 --> Loader Class Initialized
INFO - 2023-08-16 17:44:21 --> Helper loaded: url_helper
INFO - 2023-08-16 17:44:21 --> Helper loaded: file_helper
INFO - 2023-08-16 17:44:21 --> Database Driver Class Initialized
INFO - 2023-08-16 17:44:21 --> Email Class Initialized
DEBUG - 2023-08-16 17:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 17:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:44:21 --> Controller Class Initialized
INFO - 2023-08-16 17:44:21 --> Model "Key_highlights_model" initialized
INFO - 2023-08-16 17:44:21 --> Helper loaded: form_helper
INFO - 2023-08-16 17:44:21 --> Form Validation Class Initialized
INFO - 2023-08-16 17:44:21 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/key_highlights_list.php
INFO - 2023-08-16 17:44:21 --> Final output sent to browser
DEBUG - 2023-08-16 17:44:21 --> Total execution time: 0.3250
INFO - 2023-08-16 17:44:22 --> Config Class Initialized
INFO - 2023-08-16 17:44:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:44:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:44:22 --> Utf8 Class Initialized
INFO - 2023-08-16 17:44:22 --> URI Class Initialized
INFO - 2023-08-16 17:44:22 --> Router Class Initialized
INFO - 2023-08-16 17:44:22 --> Output Class Initialized
INFO - 2023-08-16 17:44:22 --> Security Class Initialized
DEBUG - 2023-08-16 17:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:44:22 --> Input Class Initialized
INFO - 2023-08-16 17:44:22 --> Language Class Initialized
ERROR - 2023-08-16 17:44:22 --> 404 Page Not Found: admin/Key_highlights/images
INFO - 2023-08-16 18:52:17 --> Config Class Initialized
INFO - 2023-08-16 18:52:17 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:52:17 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:52:17 --> Utf8 Class Initialized
INFO - 2023-08-16 18:52:17 --> URI Class Initialized
INFO - 2023-08-16 18:52:17 --> Router Class Initialized
INFO - 2023-08-16 18:52:17 --> Output Class Initialized
INFO - 2023-08-16 18:52:17 --> Security Class Initialized
DEBUG - 2023-08-16 18:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:52:17 --> Input Class Initialized
INFO - 2023-08-16 18:52:17 --> Language Class Initialized
INFO - 2023-08-16 18:52:17 --> Loader Class Initialized
INFO - 2023-08-16 18:52:17 --> Helper loaded: url_helper
INFO - 2023-08-16 18:52:17 --> Helper loaded: file_helper
INFO - 2023-08-16 18:52:17 --> Database Driver Class Initialized
INFO - 2023-08-16 18:52:17 --> Email Class Initialized
DEBUG - 2023-08-16 18:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 18:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 18:52:17 --> Controller Class Initialized
INFO - 2023-08-16 18:52:17 --> Model "Home_model" initialized
INFO - 2023-08-16 18:52:17 --> Helper loaded: form_helper
INFO - 2023-08-16 18:52:17 --> Form Validation Class Initialized
INFO - 2023-08-16 18:52:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 18:52:17 --> Final output sent to browser
DEBUG - 2023-08-16 18:52:17 --> Total execution time: 0.6835
INFO - 2023-08-16 18:52:18 --> Config Class Initialized
INFO - 2023-08-16 18:52:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:52:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:52:18 --> Utf8 Class Initialized
INFO - 2023-08-16 18:52:18 --> URI Class Initialized
INFO - 2023-08-16 18:52:18 --> Router Class Initialized
INFO - 2023-08-16 18:52:18 --> Output Class Initialized
INFO - 2023-08-16 18:52:18 --> Security Class Initialized
DEBUG - 2023-08-16 18:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:52:18 --> Input Class Initialized
INFO - 2023-08-16 18:52:18 --> Language Class Initialized
ERROR - 2023-08-16 18:52:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:52:18 --> Config Class Initialized
INFO - 2023-08-16 18:52:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:52:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:52:18 --> Utf8 Class Initialized
INFO - 2023-08-16 18:52:18 --> URI Class Initialized
INFO - 2023-08-16 18:52:18 --> Router Class Initialized
INFO - 2023-08-16 18:52:18 --> Output Class Initialized
INFO - 2023-08-16 18:52:18 --> Security Class Initialized
DEBUG - 2023-08-16 18:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:52:18 --> Input Class Initialized
INFO - 2023-08-16 18:52:18 --> Language Class Initialized
ERROR - 2023-08-16 18:52:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:52:18 --> Config Class Initialized
INFO - 2023-08-16 18:52:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:52:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:52:18 --> Utf8 Class Initialized
INFO - 2023-08-16 18:52:18 --> URI Class Initialized
INFO - 2023-08-16 18:52:18 --> Router Class Initialized
INFO - 2023-08-16 18:52:18 --> Output Class Initialized
INFO - 2023-08-16 18:52:18 --> Security Class Initialized
DEBUG - 2023-08-16 18:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:52:18 --> Input Class Initialized
INFO - 2023-08-16 18:52:18 --> Language Class Initialized
ERROR - 2023-08-16 18:52:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:52:19 --> Config Class Initialized
INFO - 2023-08-16 18:52:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:52:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:52:19 --> Utf8 Class Initialized
INFO - 2023-08-16 18:52:19 --> URI Class Initialized
INFO - 2023-08-16 18:52:19 --> Router Class Initialized
INFO - 2023-08-16 18:52:19 --> Output Class Initialized
INFO - 2023-08-16 18:52:19 --> Security Class Initialized
DEBUG - 2023-08-16 18:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:52:19 --> Input Class Initialized
INFO - 2023-08-16 18:52:19 --> Language Class Initialized
ERROR - 2023-08-16 18:52:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:52:19 --> Config Class Initialized
INFO - 2023-08-16 18:52:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:52:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:52:19 --> Utf8 Class Initialized
INFO - 2023-08-16 18:52:19 --> URI Class Initialized
INFO - 2023-08-16 18:52:19 --> Router Class Initialized
INFO - 2023-08-16 18:52:19 --> Output Class Initialized
INFO - 2023-08-16 18:52:19 --> Security Class Initialized
DEBUG - 2023-08-16 18:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:52:19 --> Input Class Initialized
INFO - 2023-08-16 18:52:19 --> Language Class Initialized
ERROR - 2023-08-16 18:52:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:52:19 --> Config Class Initialized
INFO - 2023-08-16 18:52:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:52:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:52:19 --> Utf8 Class Initialized
INFO - 2023-08-16 18:52:19 --> URI Class Initialized
INFO - 2023-08-16 18:52:19 --> Router Class Initialized
INFO - 2023-08-16 18:52:19 --> Output Class Initialized
INFO - 2023-08-16 18:52:19 --> Security Class Initialized
DEBUG - 2023-08-16 18:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:52:19 --> Input Class Initialized
INFO - 2023-08-16 18:52:19 --> Language Class Initialized
ERROR - 2023-08-16 18:52:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:52:19 --> Config Class Initialized
INFO - 2023-08-16 18:52:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:52:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:52:19 --> Utf8 Class Initialized
INFO - 2023-08-16 18:52:19 --> URI Class Initialized
INFO - 2023-08-16 18:52:19 --> Router Class Initialized
INFO - 2023-08-16 18:52:19 --> Output Class Initialized
INFO - 2023-08-16 18:52:19 --> Security Class Initialized
DEBUG - 2023-08-16 18:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:52:19 --> Input Class Initialized
INFO - 2023-08-16 18:52:19 --> Language Class Initialized
ERROR - 2023-08-16 18:52:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:52:19 --> Config Class Initialized
INFO - 2023-08-16 18:52:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:52:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:52:19 --> Utf8 Class Initialized
INFO - 2023-08-16 18:52:19 --> URI Class Initialized
INFO - 2023-08-16 18:52:19 --> Router Class Initialized
INFO - 2023-08-16 18:52:19 --> Output Class Initialized
INFO - 2023-08-16 18:52:19 --> Security Class Initialized
DEBUG - 2023-08-16 18:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:52:19 --> Input Class Initialized
INFO - 2023-08-16 18:52:19 --> Language Class Initialized
ERROR - 2023-08-16 18:52:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:53:01 --> Config Class Initialized
INFO - 2023-08-16 18:53:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:53:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:53:01 --> Utf8 Class Initialized
INFO - 2023-08-16 18:53:01 --> URI Class Initialized
INFO - 2023-08-16 18:53:01 --> Router Class Initialized
INFO - 2023-08-16 18:53:01 --> Output Class Initialized
INFO - 2023-08-16 18:53:01 --> Security Class Initialized
DEBUG - 2023-08-16 18:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:53:01 --> Input Class Initialized
INFO - 2023-08-16 18:53:01 --> Language Class Initialized
INFO - 2023-08-16 18:53:01 --> Loader Class Initialized
INFO - 2023-08-16 18:53:01 --> Helper loaded: url_helper
INFO - 2023-08-16 18:53:01 --> Helper loaded: file_helper
INFO - 2023-08-16 18:53:01 --> Database Driver Class Initialized
INFO - 2023-08-16 18:53:01 --> Email Class Initialized
DEBUG - 2023-08-16 18:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 18:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 18:53:01 --> Controller Class Initialized
INFO - 2023-08-16 18:53:01 --> Model "Home_model" initialized
INFO - 2023-08-16 18:53:01 --> Helper loaded: form_helper
INFO - 2023-08-16 18:53:01 --> Form Validation Class Initialized
INFO - 2023-08-16 18:53:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 18:53:02 --> Final output sent to browser
DEBUG - 2023-08-16 18:53:02 --> Total execution time: 0.1705
INFO - 2023-08-16 18:53:02 --> Config Class Initialized
INFO - 2023-08-16 18:53:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:53:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:53:02 --> Utf8 Class Initialized
INFO - 2023-08-16 18:53:02 --> URI Class Initialized
INFO - 2023-08-16 18:53:02 --> Router Class Initialized
INFO - 2023-08-16 18:53:02 --> Output Class Initialized
INFO - 2023-08-16 18:53:02 --> Security Class Initialized
DEBUG - 2023-08-16 18:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:53:02 --> Input Class Initialized
INFO - 2023-08-16 18:53:02 --> Language Class Initialized
ERROR - 2023-08-16 18:53:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:53:02 --> Config Class Initialized
INFO - 2023-08-16 18:53:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:53:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:53:02 --> Utf8 Class Initialized
INFO - 2023-08-16 18:53:02 --> URI Class Initialized
INFO - 2023-08-16 18:53:02 --> Router Class Initialized
INFO - 2023-08-16 18:53:02 --> Output Class Initialized
INFO - 2023-08-16 18:53:02 --> Security Class Initialized
DEBUG - 2023-08-16 18:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:53:02 --> Input Class Initialized
INFO - 2023-08-16 18:53:02 --> Language Class Initialized
ERROR - 2023-08-16 18:53:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:53:02 --> Config Class Initialized
INFO - 2023-08-16 18:53:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:53:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:53:02 --> Utf8 Class Initialized
INFO - 2023-08-16 18:53:02 --> URI Class Initialized
INFO - 2023-08-16 18:53:02 --> Router Class Initialized
INFO - 2023-08-16 18:53:02 --> Output Class Initialized
INFO - 2023-08-16 18:53:02 --> Security Class Initialized
DEBUG - 2023-08-16 18:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:53:02 --> Input Class Initialized
INFO - 2023-08-16 18:53:02 --> Language Class Initialized
ERROR - 2023-08-16 18:53:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:53:02 --> Config Class Initialized
INFO - 2023-08-16 18:53:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:53:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:53:02 --> Utf8 Class Initialized
INFO - 2023-08-16 18:53:02 --> URI Class Initialized
INFO - 2023-08-16 18:53:02 --> Router Class Initialized
INFO - 2023-08-16 18:53:02 --> Output Class Initialized
INFO - 2023-08-16 18:53:02 --> Security Class Initialized
DEBUG - 2023-08-16 18:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:53:02 --> Input Class Initialized
INFO - 2023-08-16 18:53:02 --> Language Class Initialized
ERROR - 2023-08-16 18:53:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:53:02 --> Config Class Initialized
INFO - 2023-08-16 18:53:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:53:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:53:02 --> Utf8 Class Initialized
INFO - 2023-08-16 18:53:02 --> URI Class Initialized
INFO - 2023-08-16 18:53:02 --> Router Class Initialized
INFO - 2023-08-16 18:53:02 --> Output Class Initialized
INFO - 2023-08-16 18:53:02 --> Security Class Initialized
DEBUG - 2023-08-16 18:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:53:02 --> Input Class Initialized
INFO - 2023-08-16 18:53:02 --> Language Class Initialized
ERROR - 2023-08-16 18:53:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:53:03 --> Config Class Initialized
INFO - 2023-08-16 18:53:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:53:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:53:03 --> Utf8 Class Initialized
INFO - 2023-08-16 18:53:03 --> URI Class Initialized
INFO - 2023-08-16 18:53:03 --> Router Class Initialized
INFO - 2023-08-16 18:53:03 --> Output Class Initialized
INFO - 2023-08-16 18:53:03 --> Security Class Initialized
DEBUG - 2023-08-16 18:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:53:03 --> Input Class Initialized
INFO - 2023-08-16 18:53:03 --> Language Class Initialized
ERROR - 2023-08-16 18:53:03 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:53:03 --> Config Class Initialized
INFO - 2023-08-16 18:53:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:53:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:53:03 --> Utf8 Class Initialized
INFO - 2023-08-16 18:53:03 --> URI Class Initialized
INFO - 2023-08-16 18:53:03 --> Router Class Initialized
INFO - 2023-08-16 18:53:03 --> Output Class Initialized
INFO - 2023-08-16 18:53:03 --> Security Class Initialized
DEBUG - 2023-08-16 18:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:53:03 --> Input Class Initialized
INFO - 2023-08-16 18:53:03 --> Language Class Initialized
ERROR - 2023-08-16 18:53:03 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:53:03 --> Config Class Initialized
INFO - 2023-08-16 18:53:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:53:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:53:03 --> Utf8 Class Initialized
INFO - 2023-08-16 18:53:03 --> URI Class Initialized
INFO - 2023-08-16 18:53:03 --> Router Class Initialized
INFO - 2023-08-16 18:53:03 --> Output Class Initialized
INFO - 2023-08-16 18:53:03 --> Security Class Initialized
DEBUG - 2023-08-16 18:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:53:03 --> Input Class Initialized
INFO - 2023-08-16 18:53:03 --> Language Class Initialized
ERROR - 2023-08-16 18:53:03 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:54:03 --> Config Class Initialized
INFO - 2023-08-16 18:54:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:54:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:54:03 --> Utf8 Class Initialized
INFO - 2023-08-16 18:54:03 --> URI Class Initialized
INFO - 2023-08-16 18:54:03 --> Router Class Initialized
INFO - 2023-08-16 18:54:03 --> Output Class Initialized
INFO - 2023-08-16 18:54:03 --> Security Class Initialized
DEBUG - 2023-08-16 18:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:54:03 --> Input Class Initialized
INFO - 2023-08-16 18:54:03 --> Language Class Initialized
INFO - 2023-08-16 18:54:03 --> Loader Class Initialized
INFO - 2023-08-16 18:54:03 --> Helper loaded: url_helper
INFO - 2023-08-16 18:54:03 --> Helper loaded: file_helper
INFO - 2023-08-16 18:54:03 --> Database Driver Class Initialized
INFO - 2023-08-16 18:54:03 --> Email Class Initialized
DEBUG - 2023-08-16 18:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 18:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 18:54:03 --> Controller Class Initialized
INFO - 2023-08-16 18:54:03 --> Model "Home_model" initialized
INFO - 2023-08-16 18:54:03 --> Helper loaded: form_helper
INFO - 2023-08-16 18:54:03 --> Form Validation Class Initialized
INFO - 2023-08-16 18:54:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 18:54:03 --> Final output sent to browser
DEBUG - 2023-08-16 18:54:03 --> Total execution time: 0.6851
INFO - 2023-08-16 18:54:04 --> Config Class Initialized
INFO - 2023-08-16 18:54:04 --> Config Class Initialized
INFO - 2023-08-16 18:54:04 --> Hooks Class Initialized
INFO - 2023-08-16 18:54:04 --> Config Class Initialized
INFO - 2023-08-16 18:54:04 --> Hooks Class Initialized
INFO - 2023-08-16 18:54:04 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:54:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 18:54:04 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:54:04 --> Utf8 Class Initialized
DEBUG - 2023-08-16 18:54:04 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:54:04 --> URI Class Initialized
INFO - 2023-08-16 18:54:04 --> Router Class Initialized
INFO - 2023-08-16 18:54:04 --> Utf8 Class Initialized
INFO - 2023-08-16 18:54:04 --> Output Class Initialized
INFO - 2023-08-16 18:54:04 --> Utf8 Class Initialized
INFO - 2023-08-16 18:54:04 --> Security Class Initialized
INFO - 2023-08-16 18:54:04 --> URI Class Initialized
INFO - 2023-08-16 18:54:04 --> Router Class Initialized
INFO - 2023-08-16 18:54:04 --> URI Class Initialized
INFO - 2023-08-16 18:54:04 --> Output Class Initialized
INFO - 2023-08-16 18:54:04 --> Router Class Initialized
INFO - 2023-08-16 18:54:04 --> Security Class Initialized
INFO - 2023-08-16 18:54:04 --> Output Class Initialized
DEBUG - 2023-08-16 18:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:54:04 --> Security Class Initialized
INFO - 2023-08-16 18:54:04 --> Input Class Initialized
INFO - 2023-08-16 18:54:04 --> Language Class Initialized
DEBUG - 2023-08-16 18:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 18:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 18:54:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:54:04 --> Input Class Initialized
INFO - 2023-08-16 18:54:04 --> Input Class Initialized
INFO - 2023-08-16 18:54:04 --> Language Class Initialized
INFO - 2023-08-16 18:54:04 --> Language Class Initialized
ERROR - 2023-08-16 18:54:04 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 18:54:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:54:04 --> Config Class Initialized
INFO - 2023-08-16 18:54:04 --> Config Class Initialized
INFO - 2023-08-16 18:54:04 --> Hooks Class Initialized
INFO - 2023-08-16 18:54:04 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:54:04 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:54:04 --> Utf8 Class Initialized
DEBUG - 2023-08-16 18:54:05 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:54:05 --> URI Class Initialized
INFO - 2023-08-16 18:54:05 --> Utf8 Class Initialized
INFO - 2023-08-16 18:54:05 --> URI Class Initialized
INFO - 2023-08-16 18:54:05 --> Router Class Initialized
INFO - 2023-08-16 18:54:05 --> Router Class Initialized
INFO - 2023-08-16 18:54:05 --> Output Class Initialized
INFO - 2023-08-16 18:54:05 --> Output Class Initialized
INFO - 2023-08-16 18:54:05 --> Security Class Initialized
INFO - 2023-08-16 18:54:05 --> Security Class Initialized
DEBUG - 2023-08-16 18:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 18:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:54:05 --> Input Class Initialized
INFO - 2023-08-16 18:54:05 --> Language Class Initialized
INFO - 2023-08-16 18:54:05 --> Input Class Initialized
ERROR - 2023-08-16 18:54:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:54:05 --> Language Class Initialized
ERROR - 2023-08-16 18:54:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:56:50 --> Config Class Initialized
INFO - 2023-08-16 18:56:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:56:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:56:51 --> Utf8 Class Initialized
INFO - 2023-08-16 18:56:51 --> URI Class Initialized
INFO - 2023-08-16 18:56:51 --> Router Class Initialized
INFO - 2023-08-16 18:56:51 --> Output Class Initialized
INFO - 2023-08-16 18:56:51 --> Security Class Initialized
DEBUG - 2023-08-16 18:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:56:51 --> Input Class Initialized
INFO - 2023-08-16 18:56:51 --> Language Class Initialized
INFO - 2023-08-16 18:56:51 --> Loader Class Initialized
INFO - 2023-08-16 18:56:51 --> Helper loaded: url_helper
INFO - 2023-08-16 18:56:51 --> Helper loaded: file_helper
INFO - 2023-08-16 18:56:51 --> Database Driver Class Initialized
INFO - 2023-08-16 18:56:51 --> Email Class Initialized
DEBUG - 2023-08-16 18:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 18:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 18:56:51 --> Controller Class Initialized
INFO - 2023-08-16 18:56:51 --> Model "Home_model" initialized
INFO - 2023-08-16 18:56:51 --> Helper loaded: form_helper
INFO - 2023-08-16 18:56:51 --> Form Validation Class Initialized
INFO - 2023-08-16 18:56:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 18:56:51 --> Final output sent to browser
DEBUG - 2023-08-16 18:56:51 --> Total execution time: 0.4046
INFO - 2023-08-16 18:56:52 --> Config Class Initialized
INFO - 2023-08-16 18:56:52 --> Config Class Initialized
INFO - 2023-08-16 18:56:52 --> Config Class Initialized
INFO - 2023-08-16 18:56:52 --> Hooks Class Initialized
INFO - 2023-08-16 18:56:52 --> Hooks Class Initialized
INFO - 2023-08-16 18:56:52 --> Config Class Initialized
INFO - 2023-08-16 18:56:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:56:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:56:52 --> Utf8 Class Initialized
INFO - 2023-08-16 18:56:52 --> URI Class Initialized
INFO - 2023-08-16 18:56:52 --> Router Class Initialized
INFO - 2023-08-16 18:56:52 --> Output Class Initialized
INFO - 2023-08-16 18:56:52 --> Security Class Initialized
DEBUG - 2023-08-16 18:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:56:52 --> Input Class Initialized
INFO - 2023-08-16 18:56:52 --> Language Class Initialized
ERROR - 2023-08-16 18:56:52 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 18:56:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:56:52 --> Config Class Initialized
INFO - 2023-08-16 18:56:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:56:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 18:56:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:56:52 --> Utf8 Class Initialized
INFO - 2023-08-16 18:56:52 --> Hooks Class Initialized
INFO - 2023-08-16 18:56:52 --> Utf8 Class Initialized
INFO - 2023-08-16 18:56:52 --> URI Class Initialized
DEBUG - 2023-08-16 18:56:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:56:52 --> Utf8 Class Initialized
INFO - 2023-08-16 18:56:52 --> Utf8 Class Initialized
INFO - 2023-08-16 18:56:52 --> URI Class Initialized
INFO - 2023-08-16 18:56:52 --> Router Class Initialized
INFO - 2023-08-16 18:56:52 --> Router Class Initialized
INFO - 2023-08-16 18:56:52 --> URI Class Initialized
INFO - 2023-08-16 18:56:52 --> URI Class Initialized
INFO - 2023-08-16 18:56:52 --> Router Class Initialized
INFO - 2023-08-16 18:56:52 --> Output Class Initialized
INFO - 2023-08-16 18:56:52 --> Router Class Initialized
INFO - 2023-08-16 18:56:52 --> Output Class Initialized
INFO - 2023-08-16 18:56:52 --> Output Class Initialized
INFO - 2023-08-16 18:56:52 --> Security Class Initialized
INFO - 2023-08-16 18:56:52 --> Output Class Initialized
INFO - 2023-08-16 18:56:52 --> Security Class Initialized
INFO - 2023-08-16 18:56:52 --> Security Class Initialized
DEBUG - 2023-08-16 18:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:56:52 --> Security Class Initialized
DEBUG - 2023-08-16 18:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 18:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 18:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:56:52 --> Input Class Initialized
INFO - 2023-08-16 18:56:52 --> Input Class Initialized
INFO - 2023-08-16 18:56:52 --> Language Class Initialized
INFO - 2023-08-16 18:56:52 --> Input Class Initialized
INFO - 2023-08-16 18:56:52 --> Input Class Initialized
ERROR - 2023-08-16 18:56:52 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:56:52 --> Language Class Initialized
INFO - 2023-08-16 18:56:53 --> Language Class Initialized
INFO - 2023-08-16 18:56:53 --> Language Class Initialized
ERROR - 2023-08-16 18:56:53 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 18:56:53 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 18:56:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:57:05 --> Config Class Initialized
INFO - 2023-08-16 18:57:05 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:57:05 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:57:05 --> Utf8 Class Initialized
INFO - 2023-08-16 18:57:05 --> URI Class Initialized
INFO - 2023-08-16 18:57:05 --> Router Class Initialized
INFO - 2023-08-16 18:57:05 --> Output Class Initialized
INFO - 2023-08-16 18:57:05 --> Security Class Initialized
DEBUG - 2023-08-16 18:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:57:05 --> Input Class Initialized
INFO - 2023-08-16 18:57:05 --> Language Class Initialized
INFO - 2023-08-16 18:57:05 --> Loader Class Initialized
INFO - 2023-08-16 18:57:05 --> Helper loaded: url_helper
INFO - 2023-08-16 18:57:05 --> Helper loaded: file_helper
INFO - 2023-08-16 18:57:06 --> Database Driver Class Initialized
INFO - 2023-08-16 18:57:06 --> Email Class Initialized
DEBUG - 2023-08-16 18:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 18:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 18:57:06 --> Controller Class Initialized
INFO - 2023-08-16 18:57:06 --> Model "Home_model" initialized
INFO - 2023-08-16 18:57:06 --> Helper loaded: form_helper
INFO - 2023-08-16 18:57:06 --> Form Validation Class Initialized
INFO - 2023-08-16 18:57:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 18:57:06 --> Final output sent to browser
DEBUG - 2023-08-16 18:57:06 --> Total execution time: 0.7499
INFO - 2023-08-16 18:57:06 --> Config Class Initialized
INFO - 2023-08-16 18:57:06 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:57:06 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:57:06 --> Utf8 Class Initialized
INFO - 2023-08-16 18:57:06 --> URI Class Initialized
INFO - 2023-08-16 18:57:06 --> Router Class Initialized
INFO - 2023-08-16 18:57:06 --> Output Class Initialized
INFO - 2023-08-16 18:57:06 --> Security Class Initialized
DEBUG - 2023-08-16 18:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:57:06 --> Input Class Initialized
INFO - 2023-08-16 18:57:06 --> Language Class Initialized
ERROR - 2023-08-16 18:57:06 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:57:06 --> Config Class Initialized
INFO - 2023-08-16 18:57:07 --> Config Class Initialized
INFO - 2023-08-16 18:57:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:57:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:57:07 --> Config Class Initialized
INFO - 2023-08-16 18:57:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:57:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:57:07 --> Config Class Initialized
INFO - 2023-08-16 18:57:07 --> Utf8 Class Initialized
INFO - 2023-08-16 18:57:07 --> URI Class Initialized
INFO - 2023-08-16 18:57:07 --> Hooks Class Initialized
INFO - 2023-08-16 18:57:07 --> Utf8 Class Initialized
DEBUG - 2023-08-16 18:57:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:57:07 --> Hooks Class Initialized
INFO - 2023-08-16 18:57:07 --> URI Class Initialized
INFO - 2023-08-16 18:57:07 --> Router Class Initialized
INFO - 2023-08-16 18:57:07 --> Output Class Initialized
INFO - 2023-08-16 18:57:07 --> Security Class Initialized
DEBUG - 2023-08-16 18:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:57:07 --> Input Class Initialized
INFO - 2023-08-16 18:57:07 --> Language Class Initialized
ERROR - 2023-08-16 18:57:07 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:57:07 --> Router Class Initialized
DEBUG - 2023-08-16 18:57:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:57:07 --> Utf8 Class Initialized
INFO - 2023-08-16 18:57:07 --> Utf8 Class Initialized
INFO - 2023-08-16 18:57:07 --> Output Class Initialized
INFO - 2023-08-16 18:57:07 --> Security Class Initialized
INFO - 2023-08-16 18:57:07 --> URI Class Initialized
INFO - 2023-08-16 18:57:07 --> Router Class Initialized
DEBUG - 2023-08-16 18:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:57:07 --> URI Class Initialized
INFO - 2023-08-16 18:57:07 --> Input Class Initialized
INFO - 2023-08-16 18:57:07 --> Router Class Initialized
INFO - 2023-08-16 18:57:07 --> Output Class Initialized
INFO - 2023-08-16 18:57:07 --> Language Class Initialized
INFO - 2023-08-16 18:57:07 --> Output Class Initialized
ERROR - 2023-08-16 18:57:07 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:57:07 --> Security Class Initialized
DEBUG - 2023-08-16 18:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:57:07 --> Security Class Initialized
DEBUG - 2023-08-16 18:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:57:07 --> Input Class Initialized
INFO - 2023-08-16 18:57:07 --> Input Class Initialized
INFO - 2023-08-16 18:57:07 --> Language Class Initialized
INFO - 2023-08-16 18:57:07 --> Language Class Initialized
ERROR - 2023-08-16 18:57:07 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 18:57:07 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:57:27 --> Config Class Initialized
INFO - 2023-08-16 18:57:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:57:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:57:27 --> Utf8 Class Initialized
INFO - 2023-08-16 18:57:27 --> URI Class Initialized
INFO - 2023-08-16 18:57:27 --> Router Class Initialized
INFO - 2023-08-16 18:57:27 --> Output Class Initialized
INFO - 2023-08-16 18:57:27 --> Security Class Initialized
DEBUG - 2023-08-16 18:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:57:27 --> Input Class Initialized
INFO - 2023-08-16 18:57:27 --> Language Class Initialized
INFO - 2023-08-16 18:57:27 --> Loader Class Initialized
INFO - 2023-08-16 18:57:27 --> Helper loaded: url_helper
INFO - 2023-08-16 18:57:27 --> Helper loaded: file_helper
INFO - 2023-08-16 18:57:27 --> Database Driver Class Initialized
INFO - 2023-08-16 18:57:27 --> Email Class Initialized
DEBUG - 2023-08-16 18:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 18:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 18:57:27 --> Controller Class Initialized
INFO - 2023-08-16 18:57:27 --> Model "Home_model" initialized
INFO - 2023-08-16 18:57:27 --> Helper loaded: form_helper
INFO - 2023-08-16 18:57:27 --> Form Validation Class Initialized
INFO - 2023-08-16 18:57:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 18:57:27 --> Final output sent to browser
DEBUG - 2023-08-16 18:57:27 --> Total execution time: 0.5248
INFO - 2023-08-16 18:57:28 --> Config Class Initialized
INFO - 2023-08-16 18:57:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:57:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:57:28 --> Utf8 Class Initialized
INFO - 2023-08-16 18:57:28 --> URI Class Initialized
INFO - 2023-08-16 18:57:28 --> Router Class Initialized
INFO - 2023-08-16 18:57:28 --> Output Class Initialized
INFO - 2023-08-16 18:57:28 --> Security Class Initialized
DEBUG - 2023-08-16 18:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:57:28 --> Input Class Initialized
INFO - 2023-08-16 18:57:28 --> Language Class Initialized
ERROR - 2023-08-16 18:57:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:57:28 --> Config Class Initialized
INFO - 2023-08-16 18:57:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:57:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:57:28 --> Utf8 Class Initialized
INFO - 2023-08-16 18:57:28 --> URI Class Initialized
INFO - 2023-08-16 18:57:28 --> Router Class Initialized
INFO - 2023-08-16 18:57:28 --> Output Class Initialized
INFO - 2023-08-16 18:57:28 --> Security Class Initialized
DEBUG - 2023-08-16 18:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:57:28 --> Input Class Initialized
INFO - 2023-08-16 18:57:28 --> Language Class Initialized
ERROR - 2023-08-16 18:57:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:57:28 --> Config Class Initialized
INFO - 2023-08-16 18:57:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:57:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:57:28 --> Utf8 Class Initialized
INFO - 2023-08-16 18:57:28 --> URI Class Initialized
INFO - 2023-08-16 18:57:28 --> Router Class Initialized
INFO - 2023-08-16 18:57:28 --> Output Class Initialized
INFO - 2023-08-16 18:57:28 --> Security Class Initialized
DEBUG - 2023-08-16 18:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:57:28 --> Input Class Initialized
INFO - 2023-08-16 18:57:28 --> Language Class Initialized
ERROR - 2023-08-16 18:57:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:57:28 --> Config Class Initialized
INFO - 2023-08-16 18:57:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:57:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:57:28 --> Utf8 Class Initialized
INFO - 2023-08-16 18:57:28 --> URI Class Initialized
INFO - 2023-08-16 18:57:28 --> Router Class Initialized
INFO - 2023-08-16 18:57:28 --> Output Class Initialized
INFO - 2023-08-16 18:57:28 --> Security Class Initialized
DEBUG - 2023-08-16 18:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:57:29 --> Input Class Initialized
INFO - 2023-08-16 18:57:29 --> Language Class Initialized
ERROR - 2023-08-16 18:57:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:57:29 --> Config Class Initialized
INFO - 2023-08-16 18:57:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:57:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:57:29 --> Utf8 Class Initialized
INFO - 2023-08-16 18:57:29 --> URI Class Initialized
INFO - 2023-08-16 18:57:29 --> Router Class Initialized
INFO - 2023-08-16 18:57:29 --> Output Class Initialized
INFO - 2023-08-16 18:57:29 --> Security Class Initialized
DEBUG - 2023-08-16 18:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:57:29 --> Input Class Initialized
INFO - 2023-08-16 18:57:29 --> Language Class Initialized
ERROR - 2023-08-16 18:57:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:58:04 --> Config Class Initialized
INFO - 2023-08-16 18:58:04 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:58:04 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:58:04 --> Utf8 Class Initialized
INFO - 2023-08-16 18:58:04 --> URI Class Initialized
INFO - 2023-08-16 18:58:04 --> Router Class Initialized
INFO - 2023-08-16 18:58:04 --> Output Class Initialized
INFO - 2023-08-16 18:58:04 --> Security Class Initialized
DEBUG - 2023-08-16 18:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:58:04 --> Input Class Initialized
INFO - 2023-08-16 18:58:04 --> Language Class Initialized
INFO - 2023-08-16 18:58:04 --> Loader Class Initialized
INFO - 2023-08-16 18:58:04 --> Helper loaded: url_helper
INFO - 2023-08-16 18:58:04 --> Helper loaded: file_helper
INFO - 2023-08-16 18:58:04 --> Database Driver Class Initialized
INFO - 2023-08-16 18:58:04 --> Email Class Initialized
DEBUG - 2023-08-16 18:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 18:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 18:58:04 --> Controller Class Initialized
INFO - 2023-08-16 18:58:04 --> Model "Home_model" initialized
INFO - 2023-08-16 18:58:04 --> Helper loaded: form_helper
INFO - 2023-08-16 18:58:04 --> Form Validation Class Initialized
INFO - 2023-08-16 18:58:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 18:58:04 --> Final output sent to browser
DEBUG - 2023-08-16 18:58:04 --> Total execution time: 0.1690
INFO - 2023-08-16 18:58:05 --> Config Class Initialized
INFO - 2023-08-16 18:58:05 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:58:05 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:58:05 --> Utf8 Class Initialized
INFO - 2023-08-16 18:58:05 --> URI Class Initialized
INFO - 2023-08-16 18:58:05 --> Router Class Initialized
INFO - 2023-08-16 18:58:05 --> Output Class Initialized
INFO - 2023-08-16 18:58:05 --> Security Class Initialized
DEBUG - 2023-08-16 18:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:58:05 --> Input Class Initialized
INFO - 2023-08-16 18:58:05 --> Language Class Initialized
ERROR - 2023-08-16 18:58:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:58:05 --> Config Class Initialized
INFO - 2023-08-16 18:58:05 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:58:05 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:58:05 --> Utf8 Class Initialized
INFO - 2023-08-16 18:58:05 --> URI Class Initialized
INFO - 2023-08-16 18:58:05 --> Router Class Initialized
INFO - 2023-08-16 18:58:05 --> Output Class Initialized
INFO - 2023-08-16 18:58:05 --> Security Class Initialized
DEBUG - 2023-08-16 18:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:58:05 --> Input Class Initialized
INFO - 2023-08-16 18:58:05 --> Language Class Initialized
ERROR - 2023-08-16 18:58:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:58:05 --> Config Class Initialized
INFO - 2023-08-16 18:58:05 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:58:05 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:58:05 --> Utf8 Class Initialized
INFO - 2023-08-16 18:58:05 --> URI Class Initialized
INFO - 2023-08-16 18:58:05 --> Router Class Initialized
INFO - 2023-08-16 18:58:05 --> Output Class Initialized
INFO - 2023-08-16 18:58:05 --> Security Class Initialized
DEBUG - 2023-08-16 18:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:58:05 --> Input Class Initialized
INFO - 2023-08-16 18:58:05 --> Language Class Initialized
ERROR - 2023-08-16 18:58:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:58:05 --> Config Class Initialized
INFO - 2023-08-16 18:58:05 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:58:05 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:58:05 --> Utf8 Class Initialized
INFO - 2023-08-16 18:58:05 --> URI Class Initialized
INFO - 2023-08-16 18:58:05 --> Router Class Initialized
INFO - 2023-08-16 18:58:05 --> Output Class Initialized
INFO - 2023-08-16 18:58:05 --> Security Class Initialized
DEBUG - 2023-08-16 18:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:58:05 --> Input Class Initialized
INFO - 2023-08-16 18:58:05 --> Language Class Initialized
ERROR - 2023-08-16 18:58:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:58:05 --> Config Class Initialized
INFO - 2023-08-16 18:58:05 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:58:05 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:58:05 --> Utf8 Class Initialized
INFO - 2023-08-16 18:58:05 --> URI Class Initialized
INFO - 2023-08-16 18:58:05 --> Router Class Initialized
INFO - 2023-08-16 18:58:05 --> Output Class Initialized
INFO - 2023-08-16 18:58:05 --> Security Class Initialized
DEBUG - 2023-08-16 18:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:58:05 --> Input Class Initialized
INFO - 2023-08-16 18:58:05 --> Language Class Initialized
ERROR - 2023-08-16 18:58:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:59:01 --> Config Class Initialized
INFO - 2023-08-16 18:59:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:01 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:01 --> URI Class Initialized
INFO - 2023-08-16 18:59:01 --> Router Class Initialized
INFO - 2023-08-16 18:59:01 --> Output Class Initialized
INFO - 2023-08-16 18:59:01 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:01 --> Input Class Initialized
INFO - 2023-08-16 18:59:01 --> Language Class Initialized
INFO - 2023-08-16 18:59:01 --> Loader Class Initialized
INFO - 2023-08-16 18:59:01 --> Helper loaded: url_helper
INFO - 2023-08-16 18:59:01 --> Helper loaded: file_helper
INFO - 2023-08-16 18:59:01 --> Database Driver Class Initialized
INFO - 2023-08-16 18:59:01 --> Email Class Initialized
DEBUG - 2023-08-16 18:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 18:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 18:59:01 --> Controller Class Initialized
INFO - 2023-08-16 18:59:01 --> Model "Home_model" initialized
INFO - 2023-08-16 18:59:01 --> Helper loaded: form_helper
INFO - 2023-08-16 18:59:01 --> Form Validation Class Initialized
INFO - 2023-08-16 18:59:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 18:59:01 --> Final output sent to browser
DEBUG - 2023-08-16 18:59:01 --> Total execution time: 0.4108
INFO - 2023-08-16 18:59:02 --> Config Class Initialized
INFO - 2023-08-16 18:59:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:02 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:02 --> URI Class Initialized
INFO - 2023-08-16 18:59:02 --> Router Class Initialized
INFO - 2023-08-16 18:59:02 --> Output Class Initialized
INFO - 2023-08-16 18:59:02 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:02 --> Input Class Initialized
INFO - 2023-08-16 18:59:02 --> Language Class Initialized
ERROR - 2023-08-16 18:59:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:59:02 --> Config Class Initialized
INFO - 2023-08-16 18:59:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:02 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:02 --> URI Class Initialized
INFO - 2023-08-16 18:59:02 --> Router Class Initialized
INFO - 2023-08-16 18:59:02 --> Output Class Initialized
INFO - 2023-08-16 18:59:02 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:02 --> Input Class Initialized
INFO - 2023-08-16 18:59:02 --> Language Class Initialized
ERROR - 2023-08-16 18:59:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:59:02 --> Config Class Initialized
INFO - 2023-08-16 18:59:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:02 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:02 --> URI Class Initialized
INFO - 2023-08-16 18:59:02 --> Router Class Initialized
INFO - 2023-08-16 18:59:02 --> Output Class Initialized
INFO - 2023-08-16 18:59:02 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:02 --> Input Class Initialized
INFO - 2023-08-16 18:59:02 --> Language Class Initialized
ERROR - 2023-08-16 18:59:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:59:02 --> Config Class Initialized
INFO - 2023-08-16 18:59:02 --> Config Class Initialized
INFO - 2023-08-16 18:59:02 --> Config Class Initialized
INFO - 2023-08-16 18:59:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:02 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:02 --> URI Class Initialized
INFO - 2023-08-16 18:59:02 --> Router Class Initialized
INFO - 2023-08-16 18:59:02 --> Output Class Initialized
INFO - 2023-08-16 18:59:02 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:02 --> Input Class Initialized
INFO - 2023-08-16 18:59:02 --> Language Class Initialized
ERROR - 2023-08-16 18:59:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:59:02 --> Config Class Initialized
INFO - 2023-08-16 18:59:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:02 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:02 --> URI Class Initialized
INFO - 2023-08-16 18:59:02 --> Router Class Initialized
INFO - 2023-08-16 18:59:02 --> Output Class Initialized
INFO - 2023-08-16 18:59:02 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:02 --> Input Class Initialized
INFO - 2023-08-16 18:59:02 --> Language Class Initialized
ERROR - 2023-08-16 18:59:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:59:02 --> Config Class Initialized
INFO - 2023-08-16 18:59:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:02 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:02 --> URI Class Initialized
INFO - 2023-08-16 18:59:02 --> Router Class Initialized
INFO - 2023-08-16 18:59:02 --> Output Class Initialized
INFO - 2023-08-16 18:59:02 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:02 --> Input Class Initialized
INFO - 2023-08-16 18:59:02 --> Language Class Initialized
ERROR - 2023-08-16 18:59:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:59:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:02 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:02 --> URI Class Initialized
INFO - 2023-08-16 18:59:02 --> Router Class Initialized
INFO - 2023-08-16 18:59:02 --> Output Class Initialized
INFO - 2023-08-16 18:59:02 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:02 --> Input Class Initialized
INFO - 2023-08-16 18:59:02 --> Language Class Initialized
ERROR - 2023-08-16 18:59:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:59:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:02 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:02 --> URI Class Initialized
INFO - 2023-08-16 18:59:02 --> Router Class Initialized
INFO - 2023-08-16 18:59:02 --> Output Class Initialized
INFO - 2023-08-16 18:59:02 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:02 --> Input Class Initialized
INFO - 2023-08-16 18:59:02 --> Language Class Initialized
ERROR - 2023-08-16 18:59:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:59:26 --> Config Class Initialized
INFO - 2023-08-16 18:59:26 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:26 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:26 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:26 --> URI Class Initialized
INFO - 2023-08-16 18:59:26 --> Router Class Initialized
INFO - 2023-08-16 18:59:26 --> Output Class Initialized
INFO - 2023-08-16 18:59:26 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:26 --> Input Class Initialized
INFO - 2023-08-16 18:59:26 --> Language Class Initialized
INFO - 2023-08-16 18:59:26 --> Loader Class Initialized
INFO - 2023-08-16 18:59:26 --> Helper loaded: url_helper
INFO - 2023-08-16 18:59:26 --> Helper loaded: file_helper
INFO - 2023-08-16 18:59:26 --> Database Driver Class Initialized
INFO - 2023-08-16 18:59:26 --> Email Class Initialized
DEBUG - 2023-08-16 18:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 18:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 18:59:27 --> Controller Class Initialized
INFO - 2023-08-16 18:59:27 --> Model "Home_model" initialized
INFO - 2023-08-16 18:59:27 --> Helper loaded: form_helper
INFO - 2023-08-16 18:59:27 --> Form Validation Class Initialized
INFO - 2023-08-16 18:59:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 18:59:27 --> Final output sent to browser
DEBUG - 2023-08-16 18:59:27 --> Total execution time: 0.4107
INFO - 2023-08-16 18:59:27 --> Config Class Initialized
INFO - 2023-08-16 18:59:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:27 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:27 --> URI Class Initialized
INFO - 2023-08-16 18:59:27 --> Router Class Initialized
INFO - 2023-08-16 18:59:27 --> Output Class Initialized
INFO - 2023-08-16 18:59:27 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:27 --> Input Class Initialized
INFO - 2023-08-16 18:59:27 --> Language Class Initialized
ERROR - 2023-08-16 18:59:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:59:27 --> Config Class Initialized
INFO - 2023-08-16 18:59:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:27 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:27 --> URI Class Initialized
INFO - 2023-08-16 18:59:27 --> Router Class Initialized
INFO - 2023-08-16 18:59:27 --> Output Class Initialized
INFO - 2023-08-16 18:59:27 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:27 --> Input Class Initialized
INFO - 2023-08-16 18:59:27 --> Language Class Initialized
ERROR - 2023-08-16 18:59:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:59:27 --> Config Class Initialized
INFO - 2023-08-16 18:59:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:28 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:28 --> URI Class Initialized
INFO - 2023-08-16 18:59:28 --> Router Class Initialized
INFO - 2023-08-16 18:59:28 --> Output Class Initialized
INFO - 2023-08-16 18:59:28 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:28 --> Input Class Initialized
INFO - 2023-08-16 18:59:28 --> Language Class Initialized
ERROR - 2023-08-16 18:59:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:59:28 --> Config Class Initialized
INFO - 2023-08-16 18:59:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:28 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:28 --> URI Class Initialized
INFO - 2023-08-16 18:59:28 --> Router Class Initialized
INFO - 2023-08-16 18:59:28 --> Output Class Initialized
INFO - 2023-08-16 18:59:28 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:28 --> Input Class Initialized
INFO - 2023-08-16 18:59:28 --> Language Class Initialized
ERROR - 2023-08-16 18:59:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 18:59:28 --> Config Class Initialized
INFO - 2023-08-16 18:59:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 18:59:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 18:59:28 --> Utf8 Class Initialized
INFO - 2023-08-16 18:59:28 --> URI Class Initialized
INFO - 2023-08-16 18:59:28 --> Router Class Initialized
INFO - 2023-08-16 18:59:28 --> Output Class Initialized
INFO - 2023-08-16 18:59:28 --> Security Class Initialized
DEBUG - 2023-08-16 18:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 18:59:28 --> Input Class Initialized
INFO - 2023-08-16 18:59:28 --> Language Class Initialized
ERROR - 2023-08-16 18:59:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:01:26 --> Config Class Initialized
INFO - 2023-08-16 19:01:26 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:01:26 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:01:26 --> Utf8 Class Initialized
INFO - 2023-08-16 19:01:26 --> URI Class Initialized
INFO - 2023-08-16 19:01:26 --> Router Class Initialized
INFO - 2023-08-16 19:01:26 --> Output Class Initialized
INFO - 2023-08-16 19:01:26 --> Security Class Initialized
DEBUG - 2023-08-16 19:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:01:26 --> Input Class Initialized
INFO - 2023-08-16 19:01:26 --> Language Class Initialized
INFO - 2023-08-16 19:01:26 --> Loader Class Initialized
INFO - 2023-08-16 19:01:26 --> Helper loaded: url_helper
INFO - 2023-08-16 19:01:26 --> Helper loaded: file_helper
INFO - 2023-08-16 19:01:26 --> Database Driver Class Initialized
INFO - 2023-08-16 19:01:26 --> Email Class Initialized
DEBUG - 2023-08-16 19:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:01:27 --> Controller Class Initialized
INFO - 2023-08-16 19:01:27 --> Model "Home_model" initialized
INFO - 2023-08-16 19:01:27 --> Helper loaded: form_helper
INFO - 2023-08-16 19:01:27 --> Form Validation Class Initialized
INFO - 2023-08-16 19:01:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:01:27 --> Final output sent to browser
DEBUG - 2023-08-16 19:01:27 --> Total execution time: 0.4077
INFO - 2023-08-16 19:01:27 --> Config Class Initialized
INFO - 2023-08-16 19:01:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:01:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:01:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:01:27 --> URI Class Initialized
INFO - 2023-08-16 19:01:27 --> Router Class Initialized
INFO - 2023-08-16 19:01:27 --> Output Class Initialized
INFO - 2023-08-16 19:01:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:01:27 --> Input Class Initialized
INFO - 2023-08-16 19:01:27 --> Language Class Initialized
ERROR - 2023-08-16 19:01:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:01:27 --> Config Class Initialized
INFO - 2023-08-16 19:01:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:01:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:01:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:01:27 --> URI Class Initialized
INFO - 2023-08-16 19:01:27 --> Router Class Initialized
INFO - 2023-08-16 19:01:27 --> Output Class Initialized
INFO - 2023-08-16 19:01:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:01:27 --> Input Class Initialized
INFO - 2023-08-16 19:01:27 --> Language Class Initialized
ERROR - 2023-08-16 19:01:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:01:27 --> Config Class Initialized
INFO - 2023-08-16 19:01:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:01:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:01:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:01:27 --> URI Class Initialized
INFO - 2023-08-16 19:01:27 --> Router Class Initialized
INFO - 2023-08-16 19:01:27 --> Output Class Initialized
INFO - 2023-08-16 19:01:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:01:27 --> Input Class Initialized
INFO - 2023-08-16 19:01:27 --> Language Class Initialized
ERROR - 2023-08-16 19:01:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:01:27 --> Config Class Initialized
INFO - 2023-08-16 19:01:27 --> Hooks Class Initialized
INFO - 2023-08-16 19:01:28 --> Config Class Initialized
INFO - 2023-08-16 19:01:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:01:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:01:28 --> Utf8 Class Initialized
INFO - 2023-08-16 19:01:28 --> URI Class Initialized
INFO - 2023-08-16 19:01:28 --> Router Class Initialized
INFO - 2023-08-16 19:01:28 --> Output Class Initialized
INFO - 2023-08-16 19:01:28 --> Security Class Initialized
DEBUG - 2023-08-16 19:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:01:28 --> Input Class Initialized
INFO - 2023-08-16 19:01:28 --> Language Class Initialized
ERROR - 2023-08-16 19:01:28 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:01:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:01:28 --> Config Class Initialized
INFO - 2023-08-16 19:01:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:01:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:01:28 --> Utf8 Class Initialized
INFO - 2023-08-16 19:01:28 --> URI Class Initialized
INFO - 2023-08-16 19:01:28 --> Router Class Initialized
INFO - 2023-08-16 19:01:28 --> Output Class Initialized
INFO - 2023-08-16 19:01:28 --> Security Class Initialized
DEBUG - 2023-08-16 19:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:01:28 --> Input Class Initialized
INFO - 2023-08-16 19:01:28 --> Language Class Initialized
ERROR - 2023-08-16 19:01:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:01:28 --> Config Class Initialized
INFO - 2023-08-16 19:01:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:01:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:01:28 --> Utf8 Class Initialized
INFO - 2023-08-16 19:01:28 --> URI Class Initialized
INFO - 2023-08-16 19:01:28 --> Router Class Initialized
INFO - 2023-08-16 19:01:28 --> Output Class Initialized
INFO - 2023-08-16 19:01:28 --> Security Class Initialized
DEBUG - 2023-08-16 19:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:01:28 --> Input Class Initialized
INFO - 2023-08-16 19:01:28 --> Language Class Initialized
ERROR - 2023-08-16 19:01:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:01:28 --> Config Class Initialized
INFO - 2023-08-16 19:01:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:01:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:01:28 --> Utf8 Class Initialized
INFO - 2023-08-16 19:01:28 --> URI Class Initialized
INFO - 2023-08-16 19:01:28 --> Router Class Initialized
INFO - 2023-08-16 19:01:28 --> Output Class Initialized
INFO - 2023-08-16 19:01:28 --> Security Class Initialized
DEBUG - 2023-08-16 19:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:01:28 --> Input Class Initialized
INFO - 2023-08-16 19:01:28 --> Language Class Initialized
ERROR - 2023-08-16 19:01:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:01:28 --> Config Class Initialized
INFO - 2023-08-16 19:01:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:01:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:01:28 --> Utf8 Class Initialized
INFO - 2023-08-16 19:01:28 --> URI Class Initialized
INFO - 2023-08-16 19:01:28 --> Router Class Initialized
INFO - 2023-08-16 19:01:28 --> Output Class Initialized
INFO - 2023-08-16 19:01:28 --> Security Class Initialized
DEBUG - 2023-08-16 19:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:01:28 --> Input Class Initialized
INFO - 2023-08-16 19:01:28 --> Language Class Initialized
ERROR - 2023-08-16 19:01:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:01:28 --> Config Class Initialized
INFO - 2023-08-16 19:01:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:01:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:01:28 --> Utf8 Class Initialized
INFO - 2023-08-16 19:01:28 --> URI Class Initialized
INFO - 2023-08-16 19:01:28 --> Router Class Initialized
INFO - 2023-08-16 19:01:28 --> Output Class Initialized
INFO - 2023-08-16 19:01:28 --> Security Class Initialized
DEBUG - 2023-08-16 19:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:01:28 --> Input Class Initialized
INFO - 2023-08-16 19:01:28 --> Language Class Initialized
ERROR - 2023-08-16 19:01:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:01:28 --> Utf8 Class Initialized
INFO - 2023-08-16 19:01:28 --> URI Class Initialized
INFO - 2023-08-16 19:01:28 --> Router Class Initialized
INFO - 2023-08-16 19:01:28 --> Output Class Initialized
INFO - 2023-08-16 19:01:28 --> Security Class Initialized
DEBUG - 2023-08-16 19:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:01:28 --> Input Class Initialized
INFO - 2023-08-16 19:01:28 --> Language Class Initialized
ERROR - 2023-08-16 19:01:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:01:28 --> Config Class Initialized
INFO - 2023-08-16 19:01:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:01:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:01:28 --> Utf8 Class Initialized
INFO - 2023-08-16 19:01:28 --> URI Class Initialized
INFO - 2023-08-16 19:01:28 --> Router Class Initialized
INFO - 2023-08-16 19:01:28 --> Output Class Initialized
INFO - 2023-08-16 19:01:29 --> Security Class Initialized
DEBUG - 2023-08-16 19:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:01:29 --> Input Class Initialized
INFO - 2023-08-16 19:01:29 --> Language Class Initialized
ERROR - 2023-08-16 19:01:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:01:29 --> Config Class Initialized
INFO - 2023-08-16 19:01:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:01:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:01:29 --> Utf8 Class Initialized
INFO - 2023-08-16 19:01:29 --> URI Class Initialized
INFO - 2023-08-16 19:01:29 --> Router Class Initialized
INFO - 2023-08-16 19:01:29 --> Output Class Initialized
INFO - 2023-08-16 19:01:29 --> Security Class Initialized
DEBUG - 2023-08-16 19:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:01:29 --> Input Class Initialized
INFO - 2023-08-16 19:01:29 --> Language Class Initialized
ERROR - 2023-08-16 19:01:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:12 --> Config Class Initialized
INFO - 2023-08-16 19:02:12 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:12 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:12 --> URI Class Initialized
INFO - 2023-08-16 19:02:12 --> Router Class Initialized
INFO - 2023-08-16 19:02:12 --> Output Class Initialized
INFO - 2023-08-16 19:02:12 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:12 --> Input Class Initialized
INFO - 2023-08-16 19:02:12 --> Language Class Initialized
INFO - 2023-08-16 19:02:12 --> Loader Class Initialized
INFO - 2023-08-16 19:02:12 --> Helper loaded: url_helper
INFO - 2023-08-16 19:02:12 --> Helper loaded: file_helper
INFO - 2023-08-16 19:02:12 --> Database Driver Class Initialized
INFO - 2023-08-16 19:02:12 --> Email Class Initialized
DEBUG - 2023-08-16 19:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:02:12 --> Controller Class Initialized
INFO - 2023-08-16 19:02:12 --> Model "Home_model" initialized
INFO - 2023-08-16 19:02:12 --> Helper loaded: form_helper
INFO - 2023-08-16 19:02:12 --> Form Validation Class Initialized
INFO - 2023-08-16 19:02:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:02:12 --> Final output sent to browser
DEBUG - 2023-08-16 19:02:12 --> Total execution time: 0.4997
INFO - 2023-08-16 19:02:12 --> Config Class Initialized
INFO - 2023-08-16 19:02:12 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:12 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:12 --> URI Class Initialized
INFO - 2023-08-16 19:02:12 --> Router Class Initialized
INFO - 2023-08-16 19:02:12 --> Output Class Initialized
INFO - 2023-08-16 19:02:12 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:12 --> Input Class Initialized
INFO - 2023-08-16 19:02:12 --> Language Class Initialized
ERROR - 2023-08-16 19:02:12 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:13 --> Config Class Initialized
INFO - 2023-08-16 19:02:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:13 --> URI Class Initialized
INFO - 2023-08-16 19:02:13 --> Router Class Initialized
INFO - 2023-08-16 19:02:13 --> Output Class Initialized
INFO - 2023-08-16 19:02:13 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:13 --> Input Class Initialized
INFO - 2023-08-16 19:02:13 --> Language Class Initialized
ERROR - 2023-08-16 19:02:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:13 --> Config Class Initialized
INFO - 2023-08-16 19:02:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:13 --> URI Class Initialized
INFO - 2023-08-16 19:02:13 --> Router Class Initialized
INFO - 2023-08-16 19:02:13 --> Output Class Initialized
INFO - 2023-08-16 19:02:13 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:13 --> Input Class Initialized
INFO - 2023-08-16 19:02:13 --> Language Class Initialized
ERROR - 2023-08-16 19:02:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:13 --> Config Class Initialized
INFO - 2023-08-16 19:02:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:13 --> URI Class Initialized
INFO - 2023-08-16 19:02:13 --> Router Class Initialized
INFO - 2023-08-16 19:02:13 --> Output Class Initialized
INFO - 2023-08-16 19:02:13 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:13 --> Input Class Initialized
INFO - 2023-08-16 19:02:13 --> Language Class Initialized
ERROR - 2023-08-16 19:02:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:13 --> Config Class Initialized
INFO - 2023-08-16 19:02:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:13 --> URI Class Initialized
INFO - 2023-08-16 19:02:13 --> Router Class Initialized
INFO - 2023-08-16 19:02:13 --> Output Class Initialized
INFO - 2023-08-16 19:02:13 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:13 --> Input Class Initialized
INFO - 2023-08-16 19:02:13 --> Language Class Initialized
ERROR - 2023-08-16 19:02:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:13 --> Config Class Initialized
INFO - 2023-08-16 19:02:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:13 --> URI Class Initialized
INFO - 2023-08-16 19:02:13 --> Router Class Initialized
INFO - 2023-08-16 19:02:13 --> Output Class Initialized
INFO - 2023-08-16 19:02:13 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:13 --> Input Class Initialized
INFO - 2023-08-16 19:02:13 --> Language Class Initialized
ERROR - 2023-08-16 19:02:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:13 --> Config Class Initialized
INFO - 2023-08-16 19:02:13 --> Config Class Initialized
INFO - 2023-08-16 19:02:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:13 --> Hooks Class Initialized
INFO - 2023-08-16 19:02:13 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:02:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:13 --> URI Class Initialized
INFO - 2023-08-16 19:02:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:13 --> Router Class Initialized
INFO - 2023-08-16 19:02:13 --> URI Class Initialized
INFO - 2023-08-16 19:02:13 --> Output Class Initialized
INFO - 2023-08-16 19:02:13 --> Router Class Initialized
INFO - 2023-08-16 19:02:13 --> Security Class Initialized
INFO - 2023-08-16 19:02:13 --> Output Class Initialized
DEBUG - 2023-08-16 19:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:13 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:13 --> Input Class Initialized
INFO - 2023-08-16 19:02:13 --> Language Class Initialized
INFO - 2023-08-16 19:02:13 --> Input Class Initialized
INFO - 2023-08-16 19:02:13 --> Language Class Initialized
ERROR - 2023-08-16 19:02:13 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:02:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:14 --> Config Class Initialized
INFO - 2023-08-16 19:02:14 --> Config Class Initialized
INFO - 2023-08-16 19:02:14 --> Hooks Class Initialized
INFO - 2023-08-16 19:02:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:02:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:14 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:14 --> Config Class Initialized
INFO - 2023-08-16 19:02:14 --> URI Class Initialized
INFO - 2023-08-16 19:02:14 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:14 --> Router Class Initialized
INFO - 2023-08-16 19:02:14 --> URI Class Initialized
INFO - 2023-08-16 19:02:14 --> Output Class Initialized
INFO - 2023-08-16 19:02:14 --> Router Class Initialized
INFO - 2023-08-16 19:02:14 --> Hooks Class Initialized
INFO - 2023-08-16 19:02:14 --> Output Class Initialized
INFO - 2023-08-16 19:02:14 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:14 --> Security Class Initialized
INFO - 2023-08-16 19:02:14 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:14 --> URI Class Initialized
DEBUG - 2023-08-16 19:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:14 --> Router Class Initialized
INFO - 2023-08-16 19:02:14 --> Output Class Initialized
DEBUG - 2023-08-16 19:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:14 --> Input Class Initialized
INFO - 2023-08-16 19:02:14 --> Input Class Initialized
INFO - 2023-08-16 19:02:14 --> Security Class Initialized
INFO - 2023-08-16 19:02:14 --> Language Class Initialized
DEBUG - 2023-08-16 19:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:14 --> Input Class Initialized
ERROR - 2023-08-16 19:02:14 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:14 --> Language Class Initialized
INFO - 2023-08-16 19:02:14 --> Language Class Initialized
ERROR - 2023-08-16 19:02:14 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:02:14 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:35 --> Config Class Initialized
INFO - 2023-08-16 19:02:35 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:35 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:35 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:35 --> URI Class Initialized
INFO - 2023-08-16 19:02:35 --> Router Class Initialized
INFO - 2023-08-16 19:02:35 --> Output Class Initialized
INFO - 2023-08-16 19:02:35 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:35 --> Input Class Initialized
INFO - 2023-08-16 19:02:35 --> Language Class Initialized
INFO - 2023-08-16 19:02:35 --> Loader Class Initialized
INFO - 2023-08-16 19:02:35 --> Helper loaded: url_helper
INFO - 2023-08-16 19:02:36 --> Helper loaded: file_helper
INFO - 2023-08-16 19:02:36 --> Database Driver Class Initialized
INFO - 2023-08-16 19:02:36 --> Email Class Initialized
DEBUG - 2023-08-16 19:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:02:36 --> Controller Class Initialized
INFO - 2023-08-16 19:02:36 --> Model "Home_model" initialized
INFO - 2023-08-16 19:02:36 --> Helper loaded: form_helper
INFO - 2023-08-16 19:02:36 --> Form Validation Class Initialized
INFO - 2023-08-16 19:02:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:02:36 --> Final output sent to browser
DEBUG - 2023-08-16 19:02:36 --> Total execution time: 0.4144
INFO - 2023-08-16 19:02:36 --> Config Class Initialized
INFO - 2023-08-16 19:02:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:37 --> Config Class Initialized
INFO - 2023-08-16 19:02:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:37 --> URI Class Initialized
INFO - 2023-08-16 19:02:37 --> Router Class Initialized
INFO - 2023-08-16 19:02:37 --> Output Class Initialized
INFO - 2023-08-16 19:02:37 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:37 --> Input Class Initialized
INFO - 2023-08-16 19:02:37 --> Language Class Initialized
ERROR - 2023-08-16 19:02:37 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:37 --> URI Class Initialized
INFO - 2023-08-16 19:02:37 --> Config Class Initialized
INFO - 2023-08-16 19:02:37 --> Router Class Initialized
INFO - 2023-08-16 19:02:37 --> Config Class Initialized
INFO - 2023-08-16 19:02:37 --> Output Class Initialized
INFO - 2023-08-16 19:02:37 --> Config Class Initialized
INFO - 2023-08-16 19:02:37 --> Security Class Initialized
INFO - 2023-08-16 19:02:37 --> Hooks Class Initialized
INFO - 2023-08-16 19:02:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:37 --> Config Class Initialized
DEBUG - 2023-08-16 19:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:37 --> Hooks Class Initialized
INFO - 2023-08-16 19:02:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:37 --> Hooks Class Initialized
INFO - 2023-08-16 19:02:37 --> Input Class Initialized
DEBUG - 2023-08-16 19:02:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:02:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:02:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:37 --> Language Class Initialized
ERROR - 2023-08-16 19:02:37 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:37 --> URI Class Initialized
INFO - 2023-08-16 19:02:37 --> URI Class Initialized
INFO - 2023-08-16 19:02:37 --> URI Class Initialized
INFO - 2023-08-16 19:02:37 --> URI Class Initialized
INFO - 2023-08-16 19:02:37 --> Router Class Initialized
INFO - 2023-08-16 19:02:37 --> Router Class Initialized
INFO - 2023-08-16 19:02:37 --> Router Class Initialized
INFO - 2023-08-16 19:02:37 --> Output Class Initialized
INFO - 2023-08-16 19:02:37 --> Config Class Initialized
INFO - 2023-08-16 19:02:37 --> Output Class Initialized
INFO - 2023-08-16 19:02:37 --> Router Class Initialized
INFO - 2023-08-16 19:02:37 --> Security Class Initialized
INFO - 2023-08-16 19:02:37 --> Output Class Initialized
INFO - 2023-08-16 19:02:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:02:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:38 --> Security Class Initialized
INFO - 2023-08-16 19:02:38 --> Output Class Initialized
INFO - 2023-08-16 19:02:38 --> Security Class Initialized
INFO - 2023-08-16 19:02:38 --> Config Class Initialized
DEBUG - 2023-08-16 19:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:38 --> Security Class Initialized
INFO - 2023-08-16 19:02:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:38 --> Input Class Initialized
INFO - 2023-08-16 19:02:38 --> Input Class Initialized
DEBUG - 2023-08-16 19:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:38 --> Language Class Initialized
INFO - 2023-08-16 19:02:38 --> Language Class Initialized
INFO - 2023-08-16 19:02:38 --> Input Class Initialized
INFO - 2023-08-16 19:02:38 --> URI Class Initialized
ERROR - 2023-08-16 19:02:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:38 --> Utf8 Class Initialized
ERROR - 2023-08-16 19:02:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:38 --> Language Class Initialized
INFO - 2023-08-16 19:02:38 --> Router Class Initialized
INFO - 2023-08-16 19:02:38 --> Input Class Initialized
INFO - 2023-08-16 19:02:38 --> URI Class Initialized
INFO - 2023-08-16 19:02:38 --> Language Class Initialized
ERROR - 2023-08-16 19:02:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:38 --> Output Class Initialized
INFO - 2023-08-16 19:02:38 --> Router Class Initialized
ERROR - 2023-08-16 19:02:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:38 --> Config Class Initialized
INFO - 2023-08-16 19:02:38 --> Hooks Class Initialized
INFO - 2023-08-16 19:02:38 --> Output Class Initialized
DEBUG - 2023-08-16 19:02:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:38 --> Security Class Initialized
INFO - 2023-08-16 19:02:38 --> URI Class Initialized
INFO - 2023-08-16 19:02:38 --> Router Class Initialized
INFO - 2023-08-16 19:02:38 --> Security Class Initialized
INFO - 2023-08-16 19:02:38 --> Config Class Initialized
INFO - 2023-08-16 19:02:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:02:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:38 --> Input Class Initialized
INFO - 2023-08-16 19:02:38 --> Output Class Initialized
INFO - 2023-08-16 19:02:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:38 --> Security Class Initialized
INFO - 2023-08-16 19:02:38 --> Language Class Initialized
DEBUG - 2023-08-16 19:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:38 --> URI Class Initialized
DEBUG - 2023-08-16 19:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:38 --> Input Class Initialized
ERROR - 2023-08-16 19:02:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:38 --> Config Class Initialized
INFO - 2023-08-16 19:02:38 --> Router Class Initialized
INFO - 2023-08-16 19:02:38 --> Language Class Initialized
INFO - 2023-08-16 19:02:38 --> Input Class Initialized
INFO - 2023-08-16 19:02:38 --> Hooks Class Initialized
INFO - 2023-08-16 19:02:38 --> Output Class Initialized
ERROR - 2023-08-16 19:02:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:38 --> Language Class Initialized
INFO - 2023-08-16 19:02:38 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:02:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 19:02:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:38 --> Input Class Initialized
INFO - 2023-08-16 19:02:38 --> URI Class Initialized
INFO - 2023-08-16 19:02:38 --> Language Class Initialized
INFO - 2023-08-16 19:02:38 --> Router Class Initialized
ERROR - 2023-08-16 19:02:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:38 --> Output Class Initialized
INFO - 2023-08-16 19:02:38 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:38 --> Input Class Initialized
INFO - 2023-08-16 19:02:38 --> Language Class Initialized
ERROR - 2023-08-16 19:02:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:46 --> Config Class Initialized
INFO - 2023-08-16 19:02:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:46 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:46 --> URI Class Initialized
INFO - 2023-08-16 19:02:46 --> Router Class Initialized
INFO - 2023-08-16 19:02:46 --> Output Class Initialized
INFO - 2023-08-16 19:02:46 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:46 --> Input Class Initialized
INFO - 2023-08-16 19:02:46 --> Language Class Initialized
INFO - 2023-08-16 19:02:46 --> Loader Class Initialized
INFO - 2023-08-16 19:02:46 --> Helper loaded: url_helper
INFO - 2023-08-16 19:02:46 --> Helper loaded: file_helper
INFO - 2023-08-16 19:02:46 --> Database Driver Class Initialized
INFO - 2023-08-16 19:02:46 --> Email Class Initialized
DEBUG - 2023-08-16 19:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:02:46 --> Controller Class Initialized
INFO - 2023-08-16 19:02:46 --> Model "Home_model" initialized
INFO - 2023-08-16 19:02:46 --> Helper loaded: form_helper
INFO - 2023-08-16 19:02:46 --> Form Validation Class Initialized
INFO - 2023-08-16 19:02:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:02:46 --> Final output sent to browser
DEBUG - 2023-08-16 19:02:46 --> Total execution time: 0.3903
INFO - 2023-08-16 19:02:47 --> Config Class Initialized
INFO - 2023-08-16 19:02:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:47 --> Config Class Initialized
INFO - 2023-08-16 19:02:47 --> Hooks Class Initialized
INFO - 2023-08-16 19:02:47 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:02:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:47 --> Config Class Initialized
INFO - 2023-08-16 19:02:47 --> URI Class Initialized
INFO - 2023-08-16 19:02:47 --> Config Class Initialized
INFO - 2023-08-16 19:02:47 --> Hooks Class Initialized
INFO - 2023-08-16 19:02:47 --> Hooks Class Initialized
INFO - 2023-08-16 19:02:47 --> Router Class Initialized
DEBUG - 2023-08-16 19:02:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:47 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:02:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:48 --> Output Class Initialized
INFO - 2023-08-16 19:02:48 --> Security Class Initialized
INFO - 2023-08-16 19:02:48 --> URI Class Initialized
INFO - 2023-08-16 19:02:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:48 --> Config Class Initialized
INFO - 2023-08-16 19:02:48 --> Router Class Initialized
INFO - 2023-08-16 19:02:48 --> URI Class Initialized
DEBUG - 2023-08-16 19:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:48 --> Config Class Initialized
INFO - 2023-08-16 19:02:48 --> Output Class Initialized
INFO - 2023-08-16 19:02:48 --> Router Class Initialized
INFO - 2023-08-16 19:02:48 --> Hooks Class Initialized
INFO - 2023-08-16 19:02:48 --> URI Class Initialized
INFO - 2023-08-16 19:02:48 --> Security Class Initialized
INFO - 2023-08-16 19:02:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:02:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:48 --> Input Class Initialized
INFO - 2023-08-16 19:02:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:48 --> Router Class Initialized
INFO - 2023-08-16 19:02:48 --> Output Class Initialized
INFO - 2023-08-16 19:02:48 --> Input Class Initialized
INFO - 2023-08-16 19:02:48 --> Language Class Initialized
INFO - 2023-08-16 19:02:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:48 --> URI Class Initialized
INFO - 2023-08-16 19:02:48 --> Language Class Initialized
ERROR - 2023-08-16 19:02:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:48 --> URI Class Initialized
INFO - 2023-08-16 19:02:48 --> Output Class Initialized
INFO - 2023-08-16 19:02:48 --> Config Class Initialized
INFO - 2023-08-16 19:02:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:48 --> URI Class Initialized
INFO - 2023-08-16 19:02:48 --> Router Class Initialized
INFO - 2023-08-16 19:02:48 --> Output Class Initialized
INFO - 2023-08-16 19:02:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:48 --> Input Class Initialized
INFO - 2023-08-16 19:02:48 --> Language Class Initialized
ERROR - 2023-08-16 19:02:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:48 --> Security Class Initialized
ERROR - 2023-08-16 19:02:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:48 --> Config Class Initialized
INFO - 2023-08-16 19:02:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:48 --> URI Class Initialized
INFO - 2023-08-16 19:02:48 --> Router Class Initialized
INFO - 2023-08-16 19:02:48 --> Output Class Initialized
INFO - 2023-08-16 19:02:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:48 --> Input Class Initialized
INFO - 2023-08-16 19:02:48 --> Language Class Initialized
ERROR - 2023-08-16 19:02:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:48 --> Config Class Initialized
INFO - 2023-08-16 19:02:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:48 --> URI Class Initialized
INFO - 2023-08-16 19:02:48 --> Router Class Initialized
INFO - 2023-08-16 19:02:48 --> Output Class Initialized
INFO - 2023-08-16 19:02:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:48 --> Input Class Initialized
INFO - 2023-08-16 19:02:48 --> Language Class Initialized
ERROR - 2023-08-16 19:02:48 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:48 --> Input Class Initialized
INFO - 2023-08-16 19:02:48 --> Security Class Initialized
INFO - 2023-08-16 19:02:48 --> Router Class Initialized
INFO - 2023-08-16 19:02:48 --> Output Class Initialized
DEBUG - 2023-08-16 19:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:48 --> Router Class Initialized
INFO - 2023-08-16 19:02:48 --> Config Class Initialized
INFO - 2023-08-16 19:02:48 --> Config Class Initialized
INFO - 2023-08-16 19:02:48 --> Language Class Initialized
INFO - 2023-08-16 19:02:48 --> Output Class Initialized
INFO - 2023-08-16 19:02:48 --> Input Class Initialized
INFO - 2023-08-16 19:02:48 --> Security Class Initialized
INFO - 2023-08-16 19:02:48 --> Hooks Class Initialized
INFO - 2023-08-16 19:02:48 --> Security Class Initialized
ERROR - 2023-08-16 19:02:48 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:02:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:02:48 --> URI Class Initialized
INFO - 2023-08-16 19:02:48 --> Router Class Initialized
INFO - 2023-08-16 19:02:48 --> Output Class Initialized
INFO - 2023-08-16 19:02:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:48 --> Input Class Initialized
INFO - 2023-08-16 19:02:48 --> Language Class Initialized
ERROR - 2023-08-16 19:02:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:48 --> Input Class Initialized
INFO - 2023-08-16 19:02:48 --> Language Class Initialized
DEBUG - 2023-08-16 19:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:02:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:02:48 --> Language Class Initialized
INFO - 2023-08-16 19:02:48 --> Input Class Initialized
INFO - 2023-08-16 19:02:48 --> Utf8 Class Initialized
ERROR - 2023-08-16 19:02:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:48 --> Language Class Initialized
ERROR - 2023-08-16 19:02:48 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:02:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:02:48 --> URI Class Initialized
INFO - 2023-08-16 19:02:48 --> Router Class Initialized
INFO - 2023-08-16 19:02:48 --> Output Class Initialized
INFO - 2023-08-16 19:02:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:02:48 --> Input Class Initialized
INFO - 2023-08-16 19:02:49 --> Language Class Initialized
ERROR - 2023-08-16 19:02:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:03:28 --> Config Class Initialized
INFO - 2023-08-16 19:03:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:03:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:28 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:28 --> URI Class Initialized
INFO - 2023-08-16 19:03:28 --> Router Class Initialized
INFO - 2023-08-16 19:03:28 --> Output Class Initialized
INFO - 2023-08-16 19:03:28 --> Security Class Initialized
DEBUG - 2023-08-16 19:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:28 --> Input Class Initialized
INFO - 2023-08-16 19:03:28 --> Language Class Initialized
INFO - 2023-08-16 19:03:28 --> Loader Class Initialized
INFO - 2023-08-16 19:03:28 --> Helper loaded: url_helper
INFO - 2023-08-16 19:03:29 --> Helper loaded: file_helper
INFO - 2023-08-16 19:03:29 --> Database Driver Class Initialized
INFO - 2023-08-16 19:03:29 --> Email Class Initialized
DEBUG - 2023-08-16 19:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:03:29 --> Controller Class Initialized
INFO - 2023-08-16 19:03:29 --> Model "Home_model" initialized
INFO - 2023-08-16 19:03:29 --> Helper loaded: form_helper
INFO - 2023-08-16 19:03:29 --> Form Validation Class Initialized
INFO - 2023-08-16 19:03:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:03:29 --> Final output sent to browser
DEBUG - 2023-08-16 19:03:29 --> Total execution time: 0.4301
INFO - 2023-08-16 19:03:29 --> Config Class Initialized
INFO - 2023-08-16 19:03:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:03:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:29 --> Config Class Initialized
INFO - 2023-08-16 19:03:29 --> Hooks Class Initialized
INFO - 2023-08-16 19:03:29 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:30 --> URI Class Initialized
INFO - 2023-08-16 19:03:30 --> Config Class Initialized
INFO - 2023-08-16 19:03:30 --> Router Class Initialized
DEBUG - 2023-08-16 19:03:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:30 --> Config Class Initialized
INFO - 2023-08-16 19:03:30 --> Output Class Initialized
INFO - 2023-08-16 19:03:30 --> Hooks Class Initialized
INFO - 2023-08-16 19:03:30 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:30 --> Security Class Initialized
INFO - 2023-08-16 19:03:30 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:03:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:30 --> URI Class Initialized
DEBUG - 2023-08-16 19:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:30 --> Input Class Initialized
DEBUG - 2023-08-16 19:03:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:30 --> Router Class Initialized
INFO - 2023-08-16 19:03:30 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:30 --> Language Class Initialized
INFO - 2023-08-16 19:03:30 --> Output Class Initialized
INFO - 2023-08-16 19:03:30 --> Security Class Initialized
DEBUG - 2023-08-16 19:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:30 --> Input Class Initialized
INFO - 2023-08-16 19:03:30 --> Language Class Initialized
ERROR - 2023-08-16 19:03:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:03:30 --> Config Class Initialized
INFO - 2023-08-16 19:03:30 --> Hooks Class Initialized
ERROR - 2023-08-16 19:03:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:03:30 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:30 --> Config Class Initialized
DEBUG - 2023-08-16 19:03:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:30 --> URI Class Initialized
INFO - 2023-08-16 19:03:30 --> Config Class Initialized
INFO - 2023-08-16 19:03:30 --> Hooks Class Initialized
INFO - 2023-08-16 19:03:30 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:30 --> Hooks Class Initialized
INFO - 2023-08-16 19:03:30 --> URI Class Initialized
INFO - 2023-08-16 19:03:30 --> Router Class Initialized
INFO - 2023-08-16 19:03:30 --> Config Class Initialized
DEBUG - 2023-08-16 19:03:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:30 --> URI Class Initialized
DEBUG - 2023-08-16 19:03:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:30 --> Router Class Initialized
INFO - 2023-08-16 19:03:30 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:30 --> Output Class Initialized
INFO - 2023-08-16 19:03:30 --> Hooks Class Initialized
INFO - 2023-08-16 19:03:30 --> Router Class Initialized
INFO - 2023-08-16 19:03:30 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:30 --> Security Class Initialized
DEBUG - 2023-08-16 19:03:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:30 --> Output Class Initialized
INFO - 2023-08-16 19:03:30 --> Output Class Initialized
INFO - 2023-08-16 19:03:30 --> URI Class Initialized
DEBUG - 2023-08-16 19:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:30 --> Input Class Initialized
INFO - 2023-08-16 19:03:30 --> Language Class Initialized
ERROR - 2023-08-16 19:03:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:03:30 --> Security Class Initialized
INFO - 2023-08-16 19:03:30 --> Security Class Initialized
INFO - 2023-08-16 19:03:30 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:30 --> Config Class Initialized
DEBUG - 2023-08-16 19:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:30 --> URI Class Initialized
INFO - 2023-08-16 19:03:30 --> URI Class Initialized
INFO - 2023-08-16 19:03:30 --> Router Class Initialized
INFO - 2023-08-16 19:03:30 --> Router Class Initialized
DEBUG - 2023-08-16 19:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:30 --> Output Class Initialized
INFO - 2023-08-16 19:03:30 --> Router Class Initialized
INFO - 2023-08-16 19:03:30 --> Input Class Initialized
INFO - 2023-08-16 19:03:30 --> Hooks Class Initialized
INFO - 2023-08-16 19:03:30 --> Output Class Initialized
INFO - 2023-08-16 19:03:30 --> Input Class Initialized
INFO - 2023-08-16 19:03:30 --> Security Class Initialized
INFO - 2023-08-16 19:03:30 --> Language Class Initialized
INFO - 2023-08-16 19:03:30 --> Output Class Initialized
INFO - 2023-08-16 19:03:30 --> Security Class Initialized
DEBUG - 2023-08-16 19:03:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:30 --> Security Class Initialized
INFO - 2023-08-16 19:03:30 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:30 --> Language Class Initialized
ERROR - 2023-08-16 19:03:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:03:30 --> Input Class Initialized
INFO - 2023-08-16 19:03:30 --> URI Class Initialized
ERROR - 2023-08-16 19:03:30 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:30 --> Language Class Initialized
INFO - 2023-08-16 19:03:30 --> Router Class Initialized
DEBUG - 2023-08-16 19:03:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 19:03:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:03:31 --> Input Class Initialized
INFO - 2023-08-16 19:03:31 --> Input Class Initialized
INFO - 2023-08-16 19:03:31 --> Language Class Initialized
ERROR - 2023-08-16 19:03:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:03:31 --> Config Class Initialized
INFO - 2023-08-16 19:03:31 --> Config Class Initialized
INFO - 2023-08-16 19:03:31 --> Output Class Initialized
INFO - 2023-08-16 19:03:31 --> Security Class Initialized
INFO - 2023-08-16 19:03:31 --> Hooks Class Initialized
INFO - 2023-08-16 19:03:31 --> Language Class Initialized
INFO - 2023-08-16 19:03:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:03:31 --> UTF-8 Support Enabled
ERROR - 2023-08-16 19:03:31 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:03:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:31 --> Input Class Initialized
INFO - 2023-08-16 19:03:31 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:31 --> Language Class Initialized
INFO - 2023-08-16 19:03:31 --> URI Class Initialized
INFO - 2023-08-16 19:03:31 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:31 --> URI Class Initialized
ERROR - 2023-08-16 19:03:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:03:31 --> Router Class Initialized
INFO - 2023-08-16 19:03:31 --> Router Class Initialized
INFO - 2023-08-16 19:03:31 --> Output Class Initialized
INFO - 2023-08-16 19:03:31 --> Output Class Initialized
INFO - 2023-08-16 19:03:31 --> Security Class Initialized
INFO - 2023-08-16 19:03:31 --> Security Class Initialized
DEBUG - 2023-08-16 19:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:31 --> Input Class Initialized
DEBUG - 2023-08-16 19:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:31 --> Language Class Initialized
INFO - 2023-08-16 19:03:31 --> Input Class Initialized
ERROR - 2023-08-16 19:03:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:03:31 --> Language Class Initialized
ERROR - 2023-08-16 19:03:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:03:42 --> Config Class Initialized
INFO - 2023-08-16 19:03:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:03:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:42 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:42 --> URI Class Initialized
INFO - 2023-08-16 19:03:42 --> Router Class Initialized
INFO - 2023-08-16 19:03:42 --> Output Class Initialized
INFO - 2023-08-16 19:03:42 --> Security Class Initialized
DEBUG - 2023-08-16 19:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:42 --> Input Class Initialized
INFO - 2023-08-16 19:03:42 --> Language Class Initialized
ERROR - 2023-08-16 19:03:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:03:42 --> Config Class Initialized
INFO - 2023-08-16 19:03:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:03:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:42 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:42 --> URI Class Initialized
INFO - 2023-08-16 19:03:42 --> Router Class Initialized
INFO - 2023-08-16 19:03:42 --> Output Class Initialized
INFO - 2023-08-16 19:03:42 --> Security Class Initialized
DEBUG - 2023-08-16 19:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:42 --> Config Class Initialized
INFO - 2023-08-16 19:03:42 --> Hooks Class Initialized
INFO - 2023-08-16 19:03:42 --> Input Class Initialized
INFO - 2023-08-16 19:03:42 --> Config Class Initialized
DEBUG - 2023-08-16 19:03:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:43 --> Config Class Initialized
INFO - 2023-08-16 19:03:43 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:43 --> Language Class Initialized
INFO - 2023-08-16 19:03:43 --> Hooks Class Initialized
INFO - 2023-08-16 19:03:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:03:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:43 --> URI Class Initialized
INFO - 2023-08-16 19:03:43 --> Router Class Initialized
ERROR - 2023-08-16 19:03:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:03:43 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:43 --> URI Class Initialized
INFO - 2023-08-16 19:03:43 --> Router Class Initialized
INFO - 2023-08-16 19:03:43 --> Output Class Initialized
INFO - 2023-08-16 19:03:43 --> Security Class Initialized
DEBUG - 2023-08-16 19:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:43 --> Input Class Initialized
INFO - 2023-08-16 19:03:43 --> Language Class Initialized
ERROR - 2023-08-16 19:03:43 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 19:03:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:43 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:44 --> Output Class Initialized
INFO - 2023-08-16 19:03:44 --> URI Class Initialized
INFO - 2023-08-16 19:03:44 --> Security Class Initialized
INFO - 2023-08-16 19:03:44 --> Router Class Initialized
DEBUG - 2023-08-16 19:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:44 --> Output Class Initialized
INFO - 2023-08-16 19:03:44 --> Security Class Initialized
INFO - 2023-08-16 19:03:44 --> Input Class Initialized
DEBUG - 2023-08-16 19:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:44 --> Language Class Initialized
INFO - 2023-08-16 19:03:44 --> Input Class Initialized
ERROR - 2023-08-16 19:03:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:03:44 --> Language Class Initialized
ERROR - 2023-08-16 19:03:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:03:44 --> Config Class Initialized
INFO - 2023-08-16 19:03:44 --> Hooks Class Initialized
INFO - 2023-08-16 19:03:44 --> Config Class Initialized
DEBUG - 2023-08-16 19:03:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:44 --> Hooks Class Initialized
INFO - 2023-08-16 19:03:44 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:03:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:03:44 --> URI Class Initialized
INFO - 2023-08-16 19:03:44 --> Utf8 Class Initialized
INFO - 2023-08-16 19:03:44 --> URI Class Initialized
INFO - 2023-08-16 19:03:44 --> Router Class Initialized
INFO - 2023-08-16 19:03:44 --> Output Class Initialized
INFO - 2023-08-16 19:03:44 --> Router Class Initialized
INFO - 2023-08-16 19:03:44 --> Security Class Initialized
DEBUG - 2023-08-16 19:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:44 --> Output Class Initialized
INFO - 2023-08-16 19:03:44 --> Input Class Initialized
INFO - 2023-08-16 19:03:44 --> Security Class Initialized
INFO - 2023-08-16 19:03:44 --> Language Class Initialized
DEBUG - 2023-08-16 19:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:03:44 --> Input Class Initialized
ERROR - 2023-08-16 19:03:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:03:44 --> Language Class Initialized
ERROR - 2023-08-16 19:03:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:07:18 --> Config Class Initialized
INFO - 2023-08-16 19:07:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:07:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:18 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:18 --> URI Class Initialized
INFO - 2023-08-16 19:07:18 --> Router Class Initialized
INFO - 2023-08-16 19:07:18 --> Output Class Initialized
INFO - 2023-08-16 19:07:18 --> Security Class Initialized
DEBUG - 2023-08-16 19:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:18 --> Input Class Initialized
INFO - 2023-08-16 19:07:18 --> Language Class Initialized
INFO - 2023-08-16 19:07:18 --> Loader Class Initialized
INFO - 2023-08-16 19:07:18 --> Helper loaded: url_helper
INFO - 2023-08-16 19:07:18 --> Helper loaded: file_helper
INFO - 2023-08-16 19:07:18 --> Database Driver Class Initialized
INFO - 2023-08-16 19:07:18 --> Email Class Initialized
DEBUG - 2023-08-16 19:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:07:18 --> Controller Class Initialized
INFO - 2023-08-16 19:07:18 --> Model "Home_model" initialized
INFO - 2023-08-16 19:07:18 --> Helper loaded: form_helper
INFO - 2023-08-16 19:07:18 --> Form Validation Class Initialized
INFO - 2023-08-16 19:07:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:07:18 --> Final output sent to browser
DEBUG - 2023-08-16 19:07:19 --> Total execution time: 0.5729
INFO - 2023-08-16 19:07:20 --> Config Class Initialized
INFO - 2023-08-16 19:07:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:07:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:20 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:21 --> URI Class Initialized
INFO - 2023-08-16 19:07:21 --> Router Class Initialized
INFO - 2023-08-16 19:07:21 --> Output Class Initialized
INFO - 2023-08-16 19:07:21 --> Security Class Initialized
DEBUG - 2023-08-16 19:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:21 --> Input Class Initialized
INFO - 2023-08-16 19:07:22 --> Language Class Initialized
ERROR - 2023-08-16 19:07:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:07:22 --> Config Class Initialized
INFO - 2023-08-16 19:07:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:07:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:23 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:23 --> URI Class Initialized
INFO - 2023-08-16 19:07:23 --> Router Class Initialized
INFO - 2023-08-16 19:07:23 --> Output Class Initialized
INFO - 2023-08-16 19:07:23 --> Security Class Initialized
DEBUG - 2023-08-16 19:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:23 --> Input Class Initialized
INFO - 2023-08-16 19:07:23 --> Language Class Initialized
ERROR - 2023-08-16 19:07:23 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:07:23 --> Config Class Initialized
INFO - 2023-08-16 19:07:23 --> Config Class Initialized
INFO - 2023-08-16 19:07:23 --> Config Class Initialized
INFO - 2023-08-16 19:07:23 --> Config Class Initialized
INFO - 2023-08-16 19:07:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:07:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:23 --> Hooks Class Initialized
INFO - 2023-08-16 19:07:23 --> Config Class Initialized
INFO - 2023-08-16 19:07:23 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:23 --> Hooks Class Initialized
INFO - 2023-08-16 19:07:23 --> Hooks Class Initialized
INFO - 2023-08-16 19:07:23 --> URI Class Initialized
INFO - 2023-08-16 19:07:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:07:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:07:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:07:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:23 --> Router Class Initialized
DEBUG - 2023-08-16 19:07:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:23 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:23 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:23 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:23 --> Config Class Initialized
INFO - 2023-08-16 19:07:23 --> URI Class Initialized
INFO - 2023-08-16 19:07:23 --> Router Class Initialized
INFO - 2023-08-16 19:07:23 --> Output Class Initialized
INFO - 2023-08-16 19:07:23 --> Security Class Initialized
DEBUG - 2023-08-16 19:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:23 --> Input Class Initialized
INFO - 2023-08-16 19:07:23 --> Language Class Initialized
ERROR - 2023-08-16 19:07:23 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:07:23 --> Config Class Initialized
INFO - 2023-08-16 19:07:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:07:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:23 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:23 --> URI Class Initialized
INFO - 2023-08-16 19:07:23 --> Router Class Initialized
INFO - 2023-08-16 19:07:23 --> Output Class Initialized
INFO - 2023-08-16 19:07:23 --> Security Class Initialized
DEBUG - 2023-08-16 19:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:23 --> Output Class Initialized
INFO - 2023-08-16 19:07:23 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:23 --> Hooks Class Initialized
INFO - 2023-08-16 19:07:23 --> Security Class Initialized
DEBUG - 2023-08-16 19:07:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:23 --> Input Class Initialized
INFO - 2023-08-16 19:07:23 --> URI Class Initialized
INFO - 2023-08-16 19:07:23 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:23 --> URI Class Initialized
INFO - 2023-08-16 19:07:23 --> URI Class Initialized
INFO - 2023-08-16 19:07:23 --> Language Class Initialized
INFO - 2023-08-16 19:07:23 --> Router Class Initialized
DEBUG - 2023-08-16 19:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 19:07:23 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:07:23 --> Output Class Initialized
INFO - 2023-08-16 19:07:23 --> Router Class Initialized
INFO - 2023-08-16 19:07:23 --> Router Class Initialized
INFO - 2023-08-16 19:07:23 --> Output Class Initialized
INFO - 2023-08-16 19:07:23 --> Security Class Initialized
INFO - 2023-08-16 19:07:23 --> URI Class Initialized
INFO - 2023-08-16 19:07:23 --> Config Class Initialized
INFO - 2023-08-16 19:07:23 --> Security Class Initialized
INFO - 2023-08-16 19:07:23 --> Input Class Initialized
INFO - 2023-08-16 19:07:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:23 --> Output Class Initialized
DEBUG - 2023-08-16 19:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:23 --> Language Class Initialized
INFO - 2023-08-16 19:07:23 --> Router Class Initialized
INFO - 2023-08-16 19:07:23 --> Output Class Initialized
INFO - 2023-08-16 19:07:23 --> Security Class Initialized
DEBUG - 2023-08-16 19:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:23 --> Input Class Initialized
INFO - 2023-08-16 19:07:23 --> Language Class Initialized
ERROR - 2023-08-16 19:07:23 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:07:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:24 --> Config Class Initialized
INFO - 2023-08-16 19:07:24 --> Security Class Initialized
INFO - 2023-08-16 19:07:24 --> Input Class Initialized
ERROR - 2023-08-16 19:07:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:07:24 --> Hooks Class Initialized
INFO - 2023-08-16 19:07:24 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:24 --> Input Class Initialized
DEBUG - 2023-08-16 19:07:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:24 --> Config Class Initialized
INFO - 2023-08-16 19:07:24 --> URI Class Initialized
INFO - 2023-08-16 19:07:24 --> Language Class Initialized
INFO - 2023-08-16 19:07:24 --> Router Class Initialized
DEBUG - 2023-08-16 19:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:24 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:24 --> Hooks Class Initialized
INFO - 2023-08-16 19:07:24 --> Output Class Initialized
INFO - 2023-08-16 19:07:24 --> Input Class Initialized
INFO - 2023-08-16 19:07:24 --> URI Class Initialized
DEBUG - 2023-08-16 19:07:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:24 --> Language Class Initialized
ERROR - 2023-08-16 19:07:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:07:24 --> Language Class Initialized
ERROR - 2023-08-16 19:07:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:07:24 --> Router Class Initialized
INFO - 2023-08-16 19:07:24 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:24 --> Output Class Initialized
ERROR - 2023-08-16 19:07:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:07:24 --> Config Class Initialized
INFO - 2023-08-16 19:07:24 --> Security Class Initialized
INFO - 2023-08-16 19:07:24 --> Security Class Initialized
INFO - 2023-08-16 19:07:24 --> URI Class Initialized
INFO - 2023-08-16 19:07:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:24 --> Config Class Initialized
INFO - 2023-08-16 19:07:24 --> Config Class Initialized
INFO - 2023-08-16 19:07:24 --> Input Class Initialized
DEBUG - 2023-08-16 19:07:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:24 --> Router Class Initialized
INFO - 2023-08-16 19:07:24 --> Hooks Class Initialized
INFO - 2023-08-16 19:07:24 --> Language Class Initialized
DEBUG - 2023-08-16 19:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:24 --> Utf8 Class Initialized
ERROR - 2023-08-16 19:07:24 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:07:24 --> Hooks Class Initialized
INFO - 2023-08-16 19:07:24 --> URI Class Initialized
DEBUG - 2023-08-16 19:07:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:07:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:24 --> Router Class Initialized
INFO - 2023-08-16 19:07:24 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:24 --> Output Class Initialized
INFO - 2023-08-16 19:07:24 --> Output Class Initialized
INFO - 2023-08-16 19:07:24 --> Input Class Initialized
INFO - 2023-08-16 19:07:24 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:24 --> Security Class Initialized
INFO - 2023-08-16 19:07:24 --> Config Class Initialized
INFO - 2023-08-16 19:07:24 --> Hooks Class Initialized
INFO - 2023-08-16 19:07:24 --> Language Class Initialized
DEBUG - 2023-08-16 19:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:24 --> URI Class Initialized
INFO - 2023-08-16 19:07:24 --> Security Class Initialized
DEBUG - 2023-08-16 19:07:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:24 --> URI Class Initialized
INFO - 2023-08-16 19:07:24 --> Input Class Initialized
ERROR - 2023-08-16 19:07:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:07:24 --> Router Class Initialized
DEBUG - 2023-08-16 19:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:24 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:24 --> Router Class Initialized
INFO - 2023-08-16 19:07:24 --> URI Class Initialized
INFO - 2023-08-16 19:07:24 --> Input Class Initialized
INFO - 2023-08-16 19:07:24 --> Language Class Initialized
INFO - 2023-08-16 19:07:24 --> Output Class Initialized
INFO - 2023-08-16 19:07:24 --> Output Class Initialized
INFO - 2023-08-16 19:07:24 --> Language Class Initialized
INFO - 2023-08-16 19:07:24 --> Router Class Initialized
INFO - 2023-08-16 19:07:24 --> Config Class Initialized
INFO - 2023-08-16 19:07:24 --> Security Class Initialized
INFO - 2023-08-16 19:07:24 --> Hooks Class Initialized
ERROR - 2023-08-16 19:07:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:07:24 --> Security Class Initialized
ERROR - 2023-08-16 19:07:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:07:24 --> Output Class Initialized
DEBUG - 2023-08-16 19:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:24 --> Config Class Initialized
DEBUG - 2023-08-16 19:07:25 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:07:25 --> Input Class Initialized
INFO - 2023-08-16 19:07:25 --> Input Class Initialized
INFO - 2023-08-16 19:07:25 --> Security Class Initialized
INFO - 2023-08-16 19:07:25 --> Hooks Class Initialized
INFO - 2023-08-16 19:07:25 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:25 --> Language Class Initialized
INFO - 2023-08-16 19:07:25 --> Language Class Initialized
DEBUG - 2023-08-16 19:07:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 19:07:25 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:07:25 --> URI Class Initialized
INFO - 2023-08-16 19:07:25 --> Input Class Initialized
INFO - 2023-08-16 19:07:25 --> Utf8 Class Initialized
INFO - 2023-08-16 19:07:25 --> URI Class Initialized
ERROR - 2023-08-16 19:07:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:07:25 --> Language Class Initialized
INFO - 2023-08-16 19:07:25 --> Router Class Initialized
INFO - 2023-08-16 19:07:25 --> Output Class Initialized
ERROR - 2023-08-16 19:07:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:07:25 --> Router Class Initialized
INFO - 2023-08-16 19:07:25 --> Security Class Initialized
INFO - 2023-08-16 19:07:26 --> Output Class Initialized
DEBUG - 2023-08-16 19:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:07:26 --> Input Class Initialized
INFO - 2023-08-16 19:07:26 --> Security Class Initialized
INFO - 2023-08-16 19:07:26 --> Language Class Initialized
DEBUG - 2023-08-16 19:07:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 19:07:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:07:26 --> Input Class Initialized
INFO - 2023-08-16 19:07:26 --> Language Class Initialized
ERROR - 2023-08-16 19:07:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:08:56 --> Config Class Initialized
INFO - 2023-08-16 19:08:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:08:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:08:56 --> Utf8 Class Initialized
INFO - 2023-08-16 19:08:56 --> URI Class Initialized
INFO - 2023-08-16 19:08:56 --> Router Class Initialized
INFO - 2023-08-16 19:08:56 --> Output Class Initialized
INFO - 2023-08-16 19:08:56 --> Security Class Initialized
DEBUG - 2023-08-16 19:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:08:56 --> Input Class Initialized
INFO - 2023-08-16 19:08:56 --> Language Class Initialized
INFO - 2023-08-16 19:08:56 --> Loader Class Initialized
INFO - 2023-08-16 19:08:56 --> Helper loaded: url_helper
INFO - 2023-08-16 19:08:56 --> Helper loaded: file_helper
INFO - 2023-08-16 19:08:56 --> Database Driver Class Initialized
INFO - 2023-08-16 19:08:56 --> Email Class Initialized
DEBUG - 2023-08-16 19:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:08:56 --> Controller Class Initialized
INFO - 2023-08-16 19:08:57 --> Model "Home_model" initialized
INFO - 2023-08-16 19:08:57 --> Helper loaded: form_helper
INFO - 2023-08-16 19:08:57 --> Form Validation Class Initialized
INFO - 2023-08-16 19:08:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:08:57 --> Final output sent to browser
DEBUG - 2023-08-16 19:08:57 --> Total execution time: 0.4576
INFO - 2023-08-16 19:08:59 --> Config Class Initialized
INFO - 2023-08-16 19:08:59 --> Hooks Class Initialized
INFO - 2023-08-16 19:08:59 --> Config Class Initialized
DEBUG - 2023-08-16 19:08:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:08:59 --> Utf8 Class Initialized
INFO - 2023-08-16 19:08:59 --> Config Class Initialized
INFO - 2023-08-16 19:09:00 --> URI Class Initialized
INFO - 2023-08-16 19:09:00 --> Hooks Class Initialized
INFO - 2023-08-16 19:09:00 --> Router Class Initialized
INFO - 2023-08-16 19:09:00 --> Hooks Class Initialized
INFO - 2023-08-16 19:09:00 --> Output Class Initialized
DEBUG - 2023-08-16 19:09:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:09:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:00 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:01 --> Security Class Initialized
INFO - 2023-08-16 19:09:01 --> URI Class Initialized
INFO - 2023-08-16 19:09:01 --> Router Class Initialized
INFO - 2023-08-16 19:09:01 --> Output Class Initialized
DEBUG - 2023-08-16 19:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:01 --> Input Class Initialized
INFO - 2023-08-16 19:09:01 --> Config Class Initialized
INFO - 2023-08-16 19:09:01 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:01 --> URI Class Initialized
INFO - 2023-08-16 19:09:01 --> Security Class Initialized
INFO - 2023-08-16 19:09:01 --> Router Class Initialized
INFO - 2023-08-16 19:09:01 --> Hooks Class Initialized
INFO - 2023-08-16 19:09:01 --> Language Class Initialized
DEBUG - 2023-08-16 19:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:01 --> Input Class Initialized
DEBUG - 2023-08-16 19:09:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:01 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:01 --> Config Class Initialized
INFO - 2023-08-16 19:09:01 --> Hooks Class Initialized
INFO - 2023-08-16 19:09:01 --> Output Class Initialized
ERROR - 2023-08-16 19:09:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:01 --> Language Class Initialized
INFO - 2023-08-16 19:09:01 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:01 --> Input Class Initialized
INFO - 2023-08-16 19:09:01 --> Language Class Initialized
ERROR - 2023-08-16 19:09:01 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:09:01 --> UTF-8 Support Enabled
ERROR - 2023-08-16 19:09:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:01 --> URI Class Initialized
INFO - 2023-08-16 19:09:01 --> Router Class Initialized
INFO - 2023-08-16 19:09:02 --> Config Class Initialized
INFO - 2023-08-16 19:09:02 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:02 --> Hooks Class Initialized
INFO - 2023-08-16 19:09:02 --> URI Class Initialized
DEBUG - 2023-08-16 19:09:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:02 --> Output Class Initialized
INFO - 2023-08-16 19:09:02 --> Config Class Initialized
INFO - 2023-08-16 19:09:02 --> Config Class Initialized
INFO - 2023-08-16 19:09:02 --> Router Class Initialized
INFO - 2023-08-16 19:09:02 --> Security Class Initialized
INFO - 2023-08-16 19:09:02 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:02 --> Output Class Initialized
INFO - 2023-08-16 19:09:02 --> URI Class Initialized
INFO - 2023-08-16 19:09:02 --> Hooks Class Initialized
INFO - 2023-08-16 19:09:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:09:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:02 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:02 --> Input Class Initialized
DEBUG - 2023-08-16 19:09:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:02 --> Security Class Initialized
INFO - 2023-08-16 19:09:02 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:02 --> Router Class Initialized
INFO - 2023-08-16 19:09:02 --> URI Class Initialized
DEBUG - 2023-08-16 19:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:02 --> URI Class Initialized
INFO - 2023-08-16 19:09:02 --> Input Class Initialized
INFO - 2023-08-16 19:09:02 --> Config Class Initialized
INFO - 2023-08-16 19:09:02 --> Router Class Initialized
INFO - 2023-08-16 19:09:02 --> Hooks Class Initialized
INFO - 2023-08-16 19:09:02 --> Output Class Initialized
INFO - 2023-08-16 19:09:02 --> Router Class Initialized
INFO - 2023-08-16 19:09:02 --> Language Class Initialized
DEBUG - 2023-08-16 19:09:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:02 --> Output Class Initialized
INFO - 2023-08-16 19:09:02 --> Security Class Initialized
INFO - 2023-08-16 19:09:02 --> Language Class Initialized
INFO - 2023-08-16 19:09:02 --> Output Class Initialized
ERROR - 2023-08-16 19:09:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:02 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:02 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:02 --> Input Class Initialized
INFO - 2023-08-16 19:09:02 --> Config Class Initialized
INFO - 2023-08-16 19:09:02 --> Language Class Initialized
INFO - 2023-08-16 19:09:02 --> Input Class Initialized
ERROR - 2023-08-16 19:09:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:02 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:02 --> URI Class Initialized
INFO - 2023-08-16 19:09:02 --> Router Class Initialized
INFO - 2023-08-16 19:09:02 --> Language Class Initialized
INFO - 2023-08-16 19:09:02 --> Output Class Initialized
INFO - 2023-08-16 19:09:02 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:02 --> Input Class Initialized
ERROR - 2023-08-16 19:09:02 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:09:02 --> Config Class Initialized
INFO - 2023-08-16 19:09:02 --> Security Class Initialized
INFO - 2023-08-16 19:09:02 --> Language Class Initialized
ERROR - 2023-08-16 19:09:02 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:09:02 --> Config Class Initialized
INFO - 2023-08-16 19:09:02 --> URI Class Initialized
DEBUG - 2023-08-16 19:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 19:09:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:02 --> Router Class Initialized
INFO - 2023-08-16 19:09:02 --> Input Class Initialized
INFO - 2023-08-16 19:09:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:02 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:02 --> URI Class Initialized
INFO - 2023-08-16 19:09:02 --> Router Class Initialized
INFO - 2023-08-16 19:09:02 --> Output Class Initialized
INFO - 2023-08-16 19:09:02 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:02 --> Input Class Initialized
INFO - 2023-08-16 19:09:02 --> Language Class Initialized
ERROR - 2023-08-16 19:09:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:02 --> Output Class Initialized
INFO - 2023-08-16 19:09:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:03 --> Config Class Initialized
INFO - 2023-08-16 19:09:03 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:03 --> Language Class Initialized
INFO - 2023-08-16 19:09:03 --> Security Class Initialized
INFO - 2023-08-16 19:09:03 --> Config Class Initialized
INFO - 2023-08-16 19:09:03 --> Config Class Initialized
INFO - 2023-08-16 19:09:03 --> Hooks Class Initialized
ERROR - 2023-08-16 19:09:03 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:03 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:03 --> URI Class Initialized
INFO - 2023-08-16 19:09:03 --> Router Class Initialized
INFO - 2023-08-16 19:09:03 --> Output Class Initialized
INFO - 2023-08-16 19:09:03 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:03 --> Input Class Initialized
INFO - 2023-08-16 19:09:03 --> Language Class Initialized
ERROR - 2023-08-16 19:09:03 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 19:09:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:03 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:03 --> URI Class Initialized
INFO - 2023-08-16 19:09:03 --> Router Class Initialized
INFO - 2023-08-16 19:09:03 --> Output Class Initialized
INFO - 2023-08-16 19:09:03 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:03 --> Input Class Initialized
INFO - 2023-08-16 19:09:03 --> Language Class Initialized
ERROR - 2023-08-16 19:09:03 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:03 --> Input Class Initialized
INFO - 2023-08-16 19:09:03 --> Language Class Initialized
ERROR - 2023-08-16 19:09:03 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:09:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:03 --> Config Class Initialized
INFO - 2023-08-16 19:09:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:03 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:03 --> URI Class Initialized
INFO - 2023-08-16 19:09:03 --> Router Class Initialized
INFO - 2023-08-16 19:09:03 --> Output Class Initialized
INFO - 2023-08-16 19:09:03 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:03 --> Input Class Initialized
INFO - 2023-08-16 19:09:03 --> Language Class Initialized
ERROR - 2023-08-16 19:09:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:09:03 --> Config Class Initialized
INFO - 2023-08-16 19:09:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:03 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:03 --> URI Class Initialized
INFO - 2023-08-16 19:09:03 --> Router Class Initialized
INFO - 2023-08-16 19:09:03 --> Output Class Initialized
INFO - 2023-08-16 19:09:03 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:03 --> Input Class Initialized
INFO - 2023-08-16 19:09:03 --> Language Class Initialized
ERROR - 2023-08-16 19:09:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:09:03 --> Config Class Initialized
INFO - 2023-08-16 19:09:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:03 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:03 --> URI Class Initialized
INFO - 2023-08-16 19:09:03 --> Router Class Initialized
INFO - 2023-08-16 19:09:03 --> Output Class Initialized
INFO - 2023-08-16 19:09:03 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:03 --> Input Class Initialized
INFO - 2023-08-16 19:09:03 --> Language Class Initialized
ERROR - 2023-08-16 19:09:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:09:03 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:03 --> URI Class Initialized
INFO - 2023-08-16 19:09:03 --> Router Class Initialized
INFO - 2023-08-16 19:09:03 --> URI Class Initialized
INFO - 2023-08-16 19:09:03 --> Output Class Initialized
INFO - 2023-08-16 19:09:03 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:03 --> Input Class Initialized
INFO - 2023-08-16 19:09:03 --> Language Class Initialized
ERROR - 2023-08-16 19:09:03 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:03 --> Router Class Initialized
INFO - 2023-08-16 19:09:03 --> Output Class Initialized
INFO - 2023-08-16 19:09:03 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:03 --> Input Class Initialized
INFO - 2023-08-16 19:09:03 --> Language Class Initialized
ERROR - 2023-08-16 19:09:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:09:37 --> Config Class Initialized
INFO - 2023-08-16 19:09:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:37 --> URI Class Initialized
INFO - 2023-08-16 19:09:37 --> Router Class Initialized
INFO - 2023-08-16 19:09:37 --> Output Class Initialized
INFO - 2023-08-16 19:09:37 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:37 --> Input Class Initialized
INFO - 2023-08-16 19:09:37 --> Language Class Initialized
INFO - 2023-08-16 19:09:37 --> Loader Class Initialized
INFO - 2023-08-16 19:09:37 --> Helper loaded: url_helper
INFO - 2023-08-16 19:09:37 --> Helper loaded: file_helper
INFO - 2023-08-16 19:09:37 --> Database Driver Class Initialized
INFO - 2023-08-16 19:09:37 --> Email Class Initialized
DEBUG - 2023-08-16 19:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:09:37 --> Controller Class Initialized
INFO - 2023-08-16 19:09:37 --> Model "Home_model" initialized
INFO - 2023-08-16 19:09:37 --> Helper loaded: form_helper
INFO - 2023-08-16 19:09:37 --> Form Validation Class Initialized
INFO - 2023-08-16 19:09:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:09:37 --> Final output sent to browser
DEBUG - 2023-08-16 19:09:37 --> Total execution time: 0.5079
INFO - 2023-08-16 19:09:37 --> Config Class Initialized
INFO - 2023-08-16 19:09:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:37 --> URI Class Initialized
INFO - 2023-08-16 19:09:37 --> Router Class Initialized
INFO - 2023-08-16 19:09:37 --> Output Class Initialized
INFO - 2023-08-16 19:09:37 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:37 --> Input Class Initialized
INFO - 2023-08-16 19:09:37 --> Language Class Initialized
ERROR - 2023-08-16 19:09:37 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:38 --> Config Class Initialized
INFO - 2023-08-16 19:09:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:38 --> URI Class Initialized
INFO - 2023-08-16 19:09:38 --> Router Class Initialized
INFO - 2023-08-16 19:09:38 --> Output Class Initialized
INFO - 2023-08-16 19:09:38 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:38 --> Input Class Initialized
INFO - 2023-08-16 19:09:38 --> Language Class Initialized
ERROR - 2023-08-16 19:09:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:38 --> Config Class Initialized
INFO - 2023-08-16 19:09:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:38 --> URI Class Initialized
INFO - 2023-08-16 19:09:38 --> Router Class Initialized
INFO - 2023-08-16 19:09:38 --> Output Class Initialized
INFO - 2023-08-16 19:09:38 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:38 --> Input Class Initialized
INFO - 2023-08-16 19:09:38 --> Language Class Initialized
ERROR - 2023-08-16 19:09:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:38 --> Config Class Initialized
INFO - 2023-08-16 19:09:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:38 --> URI Class Initialized
INFO - 2023-08-16 19:09:38 --> Router Class Initialized
INFO - 2023-08-16 19:09:38 --> Output Class Initialized
INFO - 2023-08-16 19:09:38 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:38 --> Input Class Initialized
INFO - 2023-08-16 19:09:38 --> Language Class Initialized
ERROR - 2023-08-16 19:09:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:38 --> Config Class Initialized
INFO - 2023-08-16 19:09:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:38 --> Config Class Initialized
INFO - 2023-08-16 19:09:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:38 --> URI Class Initialized
INFO - 2023-08-16 19:09:38 --> Router Class Initialized
INFO - 2023-08-16 19:09:38 --> Output Class Initialized
INFO - 2023-08-16 19:09:38 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:38 --> Input Class Initialized
INFO - 2023-08-16 19:09:38 --> Language Class Initialized
ERROR - 2023-08-16 19:09:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:38 --> URI Class Initialized
INFO - 2023-08-16 19:09:38 --> Router Class Initialized
INFO - 2023-08-16 19:09:38 --> Config Class Initialized
INFO - 2023-08-16 19:09:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:38 --> URI Class Initialized
INFO - 2023-08-16 19:09:38 --> Router Class Initialized
INFO - 2023-08-16 19:09:38 --> Output Class Initialized
INFO - 2023-08-16 19:09:38 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:38 --> Input Class Initialized
INFO - 2023-08-16 19:09:38 --> Language Class Initialized
ERROR - 2023-08-16 19:09:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:38 --> Output Class Initialized
INFO - 2023-08-16 19:09:38 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:38 --> Config Class Initialized
INFO - 2023-08-16 19:09:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:38 --> URI Class Initialized
INFO - 2023-08-16 19:09:38 --> Router Class Initialized
INFO - 2023-08-16 19:09:38 --> Output Class Initialized
INFO - 2023-08-16 19:09:38 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:38 --> Input Class Initialized
INFO - 2023-08-16 19:09:38 --> Language Class Initialized
ERROR - 2023-08-16 19:09:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:39 --> Input Class Initialized
INFO - 2023-08-16 19:09:39 --> Language Class Initialized
ERROR - 2023-08-16 19:09:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:39 --> Config Class Initialized
INFO - 2023-08-16 19:09:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:39 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:39 --> URI Class Initialized
INFO - 2023-08-16 19:09:39 --> Router Class Initialized
INFO - 2023-08-16 19:09:39 --> Output Class Initialized
INFO - 2023-08-16 19:09:39 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:39 --> Input Class Initialized
INFO - 2023-08-16 19:09:39 --> Language Class Initialized
ERROR - 2023-08-16 19:09:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:39 --> Config Class Initialized
INFO - 2023-08-16 19:09:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:39 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:39 --> URI Class Initialized
INFO - 2023-08-16 19:09:39 --> Router Class Initialized
INFO - 2023-08-16 19:09:39 --> Output Class Initialized
INFO - 2023-08-16 19:09:39 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:39 --> Input Class Initialized
INFO - 2023-08-16 19:09:39 --> Language Class Initialized
ERROR - 2023-08-16 19:09:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:39 --> Config Class Initialized
INFO - 2023-08-16 19:09:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:39 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:39 --> URI Class Initialized
INFO - 2023-08-16 19:09:39 --> Router Class Initialized
INFO - 2023-08-16 19:09:39 --> Output Class Initialized
INFO - 2023-08-16 19:09:39 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:39 --> Input Class Initialized
INFO - 2023-08-16 19:09:39 --> Language Class Initialized
ERROR - 2023-08-16 19:09:40 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:09:58 --> Config Class Initialized
INFO - 2023-08-16 19:09:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:58 --> Utf8 Class Initialized
INFO - 2023-08-16 19:09:58 --> URI Class Initialized
INFO - 2023-08-16 19:09:58 --> Router Class Initialized
INFO - 2023-08-16 19:09:58 --> Output Class Initialized
INFO - 2023-08-16 19:09:58 --> Security Class Initialized
DEBUG - 2023-08-16 19:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:09:58 --> Input Class Initialized
INFO - 2023-08-16 19:09:58 --> Language Class Initialized
INFO - 2023-08-16 19:09:58 --> Loader Class Initialized
INFO - 2023-08-16 19:09:58 --> Helper loaded: url_helper
INFO - 2023-08-16 19:09:58 --> Helper loaded: file_helper
INFO - 2023-08-16 19:09:58 --> Database Driver Class Initialized
INFO - 2023-08-16 19:09:58 --> Email Class Initialized
DEBUG - 2023-08-16 19:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:09:59 --> Controller Class Initialized
INFO - 2023-08-16 19:09:59 --> Model "Home_model" initialized
INFO - 2023-08-16 19:09:59 --> Helper loaded: form_helper
INFO - 2023-08-16 19:09:59 --> Form Validation Class Initialized
INFO - 2023-08-16 19:09:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:09:59 --> Final output sent to browser
DEBUG - 2023-08-16 19:09:59 --> Total execution time: 0.8792
INFO - 2023-08-16 19:09:59 --> Config Class Initialized
INFO - 2023-08-16 19:09:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:09:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:09:59 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:00 --> URI Class Initialized
INFO - 2023-08-16 19:10:00 --> Router Class Initialized
INFO - 2023-08-16 19:10:00 --> Output Class Initialized
INFO - 2023-08-16 19:10:00 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:00 --> Input Class Initialized
INFO - 2023-08-16 19:10:00 --> Language Class Initialized
ERROR - 2023-08-16 19:10:00 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:00 --> Config Class Initialized
INFO - 2023-08-16 19:10:00 --> Config Class Initialized
INFO - 2023-08-16 19:10:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:00 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:00 --> URI Class Initialized
INFO - 2023-08-16 19:10:00 --> Router Class Initialized
INFO - 2023-08-16 19:10:00 --> Output Class Initialized
INFO - 2023-08-16 19:10:00 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:00 --> Input Class Initialized
INFO - 2023-08-16 19:10:00 --> Language Class Initialized
ERROR - 2023-08-16 19:10:00 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:00 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:00 --> Config Class Initialized
INFO - 2023-08-16 19:10:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:00 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:00 --> URI Class Initialized
INFO - 2023-08-16 19:10:00 --> Router Class Initialized
INFO - 2023-08-16 19:10:00 --> Output Class Initialized
INFO - 2023-08-16 19:10:00 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:00 --> Input Class Initialized
INFO - 2023-08-16 19:10:00 --> Language Class Initialized
ERROR - 2023-08-16 19:10:00 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:00 --> URI Class Initialized
INFO - 2023-08-16 19:10:00 --> Router Class Initialized
INFO - 2023-08-16 19:10:00 --> Output Class Initialized
INFO - 2023-08-16 19:10:00 --> Security Class Initialized
INFO - 2023-08-16 19:10:00 --> Config Class Initialized
INFO - 2023-08-16 19:10:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:00 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:00 --> URI Class Initialized
INFO - 2023-08-16 19:10:00 --> Router Class Initialized
INFO - 2023-08-16 19:10:00 --> Output Class Initialized
INFO - 2023-08-16 19:10:00 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:00 --> Input Class Initialized
INFO - 2023-08-16 19:10:00 --> Language Class Initialized
ERROR - 2023-08-16 19:10:00 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:01 --> Config Class Initialized
INFO - 2023-08-16 19:10:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:01 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:01 --> URI Class Initialized
INFO - 2023-08-16 19:10:01 --> Router Class Initialized
INFO - 2023-08-16 19:10:01 --> Output Class Initialized
INFO - 2023-08-16 19:10:01 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:01 --> Input Class Initialized
INFO - 2023-08-16 19:10:01 --> Language Class Initialized
ERROR - 2023-08-16 19:10:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:01 --> Config Class Initialized
INFO - 2023-08-16 19:10:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:01 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:01 --> URI Class Initialized
INFO - 2023-08-16 19:10:01 --> Router Class Initialized
INFO - 2023-08-16 19:10:01 --> Output Class Initialized
INFO - 2023-08-16 19:10:01 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:01 --> Input Class Initialized
INFO - 2023-08-16 19:10:01 --> Language Class Initialized
ERROR - 2023-08-16 19:10:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:01 --> Input Class Initialized
INFO - 2023-08-16 19:10:01 --> Language Class Initialized
ERROR - 2023-08-16 19:10:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:01 --> Config Class Initialized
INFO - 2023-08-16 19:10:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:01 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:01 --> URI Class Initialized
INFO - 2023-08-16 19:10:01 --> Router Class Initialized
INFO - 2023-08-16 19:10:01 --> Output Class Initialized
INFO - 2023-08-16 19:10:01 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:01 --> Input Class Initialized
INFO - 2023-08-16 19:10:01 --> Language Class Initialized
ERROR - 2023-08-16 19:10:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:01 --> Config Class Initialized
INFO - 2023-08-16 19:10:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:01 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:01 --> URI Class Initialized
INFO - 2023-08-16 19:10:01 --> Router Class Initialized
INFO - 2023-08-16 19:10:01 --> Output Class Initialized
INFO - 2023-08-16 19:10:01 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:01 --> Input Class Initialized
INFO - 2023-08-16 19:10:01 --> Language Class Initialized
ERROR - 2023-08-16 19:10:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:01 --> Config Class Initialized
INFO - 2023-08-16 19:10:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:01 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:01 --> URI Class Initialized
INFO - 2023-08-16 19:10:01 --> Router Class Initialized
INFO - 2023-08-16 19:10:01 --> Output Class Initialized
INFO - 2023-08-16 19:10:01 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:01 --> Input Class Initialized
INFO - 2023-08-16 19:10:02 --> Language Class Initialized
ERROR - 2023-08-16 19:10:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:02 --> Config Class Initialized
INFO - 2023-08-16 19:10:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:02 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:02 --> URI Class Initialized
INFO - 2023-08-16 19:10:02 --> Router Class Initialized
INFO - 2023-08-16 19:10:02 --> Output Class Initialized
INFO - 2023-08-16 19:10:02 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:02 --> Input Class Initialized
INFO - 2023-08-16 19:10:02 --> Language Class Initialized
ERROR - 2023-08-16 19:10:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:36 --> Config Class Initialized
INFO - 2023-08-16 19:10:36 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:36 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:36 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:36 --> URI Class Initialized
INFO - 2023-08-16 19:10:36 --> Router Class Initialized
INFO - 2023-08-16 19:10:36 --> Output Class Initialized
INFO - 2023-08-16 19:10:36 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:36 --> Input Class Initialized
INFO - 2023-08-16 19:10:36 --> Language Class Initialized
INFO - 2023-08-16 19:10:36 --> Loader Class Initialized
INFO - 2023-08-16 19:10:36 --> Helper loaded: url_helper
INFO - 2023-08-16 19:10:36 --> Helper loaded: file_helper
INFO - 2023-08-16 19:10:36 --> Database Driver Class Initialized
INFO - 2023-08-16 19:10:37 --> Email Class Initialized
DEBUG - 2023-08-16 19:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:10:37 --> Controller Class Initialized
INFO - 2023-08-16 19:10:37 --> Model "Home_model" initialized
INFO - 2023-08-16 19:10:37 --> Helper loaded: form_helper
INFO - 2023-08-16 19:10:37 --> Form Validation Class Initialized
INFO - 2023-08-16 19:10:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:10:37 --> Final output sent to browser
DEBUG - 2023-08-16 19:10:37 --> Total execution time: 0.7505
INFO - 2023-08-16 19:10:37 --> Config Class Initialized
INFO - 2023-08-16 19:10:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:37 --> URI Class Initialized
INFO - 2023-08-16 19:10:37 --> Router Class Initialized
INFO - 2023-08-16 19:10:37 --> Output Class Initialized
INFO - 2023-08-16 19:10:37 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:37 --> Input Class Initialized
INFO - 2023-08-16 19:10:37 --> Language Class Initialized
ERROR - 2023-08-16 19:10:37 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:37 --> Config Class Initialized
INFO - 2023-08-16 19:10:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:37 --> URI Class Initialized
INFO - 2023-08-16 19:10:37 --> Router Class Initialized
INFO - 2023-08-16 19:10:37 --> Output Class Initialized
INFO - 2023-08-16 19:10:37 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:37 --> Input Class Initialized
INFO - 2023-08-16 19:10:37 --> Language Class Initialized
ERROR - 2023-08-16 19:10:37 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:37 --> Config Class Initialized
INFO - 2023-08-16 19:10:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:37 --> URI Class Initialized
INFO - 2023-08-16 19:10:37 --> Router Class Initialized
INFO - 2023-08-16 19:10:37 --> Output Class Initialized
INFO - 2023-08-16 19:10:37 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:37 --> Input Class Initialized
INFO - 2023-08-16 19:10:37 --> Language Class Initialized
ERROR - 2023-08-16 19:10:37 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:38 --> Config Class Initialized
INFO - 2023-08-16 19:10:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:38 --> URI Class Initialized
INFO - 2023-08-16 19:10:38 --> Router Class Initialized
INFO - 2023-08-16 19:10:38 --> Output Class Initialized
INFO - 2023-08-16 19:10:38 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:38 --> Input Class Initialized
INFO - 2023-08-16 19:10:38 --> Language Class Initialized
ERROR - 2023-08-16 19:10:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:38 --> Config Class Initialized
INFO - 2023-08-16 19:10:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:38 --> URI Class Initialized
INFO - 2023-08-16 19:10:38 --> Router Class Initialized
INFO - 2023-08-16 19:10:38 --> Output Class Initialized
INFO - 2023-08-16 19:10:38 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:39 --> Input Class Initialized
INFO - 2023-08-16 19:10:39 --> Language Class Initialized
ERROR - 2023-08-16 19:10:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:39 --> Config Class Initialized
INFO - 2023-08-16 19:10:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:39 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:39 --> URI Class Initialized
INFO - 2023-08-16 19:10:39 --> Router Class Initialized
INFO - 2023-08-16 19:10:39 --> Output Class Initialized
INFO - 2023-08-16 19:10:39 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:39 --> Input Class Initialized
INFO - 2023-08-16 19:10:39 --> Language Class Initialized
ERROR - 2023-08-16 19:10:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:39 --> Config Class Initialized
INFO - 2023-08-16 19:10:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:39 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:39 --> URI Class Initialized
INFO - 2023-08-16 19:10:39 --> Router Class Initialized
INFO - 2023-08-16 19:10:39 --> Output Class Initialized
INFO - 2023-08-16 19:10:39 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:39 --> Input Class Initialized
INFO - 2023-08-16 19:10:39 --> Language Class Initialized
ERROR - 2023-08-16 19:10:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:46 --> Config Class Initialized
INFO - 2023-08-16 19:10:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:46 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:46 --> URI Class Initialized
INFO - 2023-08-16 19:10:46 --> Router Class Initialized
INFO - 2023-08-16 19:10:46 --> Output Class Initialized
INFO - 2023-08-16 19:10:46 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:46 --> Input Class Initialized
INFO - 2023-08-16 19:10:46 --> Language Class Initialized
INFO - 2023-08-16 19:10:46 --> Loader Class Initialized
INFO - 2023-08-16 19:10:46 --> Helper loaded: url_helper
INFO - 2023-08-16 19:10:46 --> Helper loaded: file_helper
INFO - 2023-08-16 19:10:46 --> Database Driver Class Initialized
INFO - 2023-08-16 19:10:46 --> Email Class Initialized
DEBUG - 2023-08-16 19:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:10:47 --> Controller Class Initialized
INFO - 2023-08-16 19:10:47 --> Model "Home_model" initialized
INFO - 2023-08-16 19:10:47 --> Helper loaded: form_helper
INFO - 2023-08-16 19:10:47 --> Form Validation Class Initialized
INFO - 2023-08-16 19:10:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:10:47 --> Final output sent to browser
DEBUG - 2023-08-16 19:10:47 --> Total execution time: 0.6216
INFO - 2023-08-16 19:10:48 --> Config Class Initialized
INFO - 2023-08-16 19:10:48 --> Config Class Initialized
INFO - 2023-08-16 19:10:48 --> Hooks Class Initialized
INFO - 2023-08-16 19:10:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:10:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:49 --> URI Class Initialized
INFO - 2023-08-16 19:10:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:49 --> Router Class Initialized
INFO - 2023-08-16 19:10:49 --> Output Class Initialized
INFO - 2023-08-16 19:10:49 --> URI Class Initialized
INFO - 2023-08-16 19:10:49 --> Security Class Initialized
INFO - 2023-08-16 19:10:49 --> Router Class Initialized
DEBUG - 2023-08-16 19:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:49 --> Input Class Initialized
INFO - 2023-08-16 19:10:49 --> Output Class Initialized
INFO - 2023-08-16 19:10:49 --> Language Class Initialized
ERROR - 2023-08-16 19:10:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:49 --> Input Class Initialized
INFO - 2023-08-16 19:10:49 --> Language Class Initialized
ERROR - 2023-08-16 19:10:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:49 --> Config Class Initialized
INFO - 2023-08-16 19:10:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:49 --> URI Class Initialized
INFO - 2023-08-16 19:10:49 --> Router Class Initialized
INFO - 2023-08-16 19:10:49 --> Output Class Initialized
INFO - 2023-08-16 19:10:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:49 --> Input Class Initialized
INFO - 2023-08-16 19:10:49 --> Language Class Initialized
ERROR - 2023-08-16 19:10:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:10:49 --> Config Class Initialized
INFO - 2023-08-16 19:10:49 --> Config Class Initialized
INFO - 2023-08-16 19:10:49 --> Hooks Class Initialized
INFO - 2023-08-16 19:10:49 --> Config Class Initialized
INFO - 2023-08-16 19:10:50 --> Hooks Class Initialized
INFO - 2023-08-16 19:10:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:10:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:10:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:50 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:10:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:10:50 --> URI Class Initialized
INFO - 2023-08-16 19:10:50 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:50 --> Router Class Initialized
INFO - 2023-08-16 19:10:50 --> Output Class Initialized
INFO - 2023-08-16 19:10:50 --> URI Class Initialized
INFO - 2023-08-16 19:10:50 --> Router Class Initialized
INFO - 2023-08-16 19:10:50 --> Utf8 Class Initialized
INFO - 2023-08-16 19:10:50 --> Output Class Initialized
INFO - 2023-08-16 19:10:50 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:50 --> URI Class Initialized
INFO - 2023-08-16 19:10:50 --> Input Class Initialized
INFO - 2023-08-16 19:10:50 --> Router Class Initialized
INFO - 2023-08-16 19:10:50 --> Output Class Initialized
INFO - 2023-08-16 19:10:50 --> Security Class Initialized
INFO - 2023-08-16 19:10:50 --> Security Class Initialized
DEBUG - 2023-08-16 19:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:50 --> Input Class Initialized
INFO - 2023-08-16 19:10:50 --> Language Class Initialized
INFO - 2023-08-16 19:10:50 --> Language Class Initialized
ERROR - 2023-08-16 19:10:50 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:10:50 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:10:51 --> Input Class Initialized
INFO - 2023-08-16 19:10:51 --> Language Class Initialized
ERROR - 2023-08-16 19:10:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:11:13 --> Config Class Initialized
INFO - 2023-08-16 19:11:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:11:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:11:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:11:13 --> URI Class Initialized
INFO - 2023-08-16 19:11:13 --> Router Class Initialized
INFO - 2023-08-16 19:11:13 --> Output Class Initialized
INFO - 2023-08-16 19:11:13 --> Security Class Initialized
DEBUG - 2023-08-16 19:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:11:13 --> Input Class Initialized
INFO - 2023-08-16 19:11:13 --> Language Class Initialized
INFO - 2023-08-16 19:11:14 --> Loader Class Initialized
INFO - 2023-08-16 19:11:14 --> Helper loaded: url_helper
INFO - 2023-08-16 19:11:14 --> Helper loaded: file_helper
INFO - 2023-08-16 19:11:14 --> Database Driver Class Initialized
INFO - 2023-08-16 19:11:14 --> Email Class Initialized
DEBUG - 2023-08-16 19:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:11:14 --> Controller Class Initialized
INFO - 2023-08-16 19:11:14 --> Model "Home_model" initialized
INFO - 2023-08-16 19:11:14 --> Helper loaded: form_helper
INFO - 2023-08-16 19:11:14 --> Form Validation Class Initialized
INFO - 2023-08-16 19:11:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:11:14 --> Final output sent to browser
DEBUG - 2023-08-16 19:11:14 --> Total execution time: 0.7438
INFO - 2023-08-16 19:11:14 --> Config Class Initialized
INFO - 2023-08-16 19:11:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:11:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:11:14 --> Utf8 Class Initialized
INFO - 2023-08-16 19:11:14 --> URI Class Initialized
INFO - 2023-08-16 19:11:14 --> Router Class Initialized
INFO - 2023-08-16 19:11:14 --> Output Class Initialized
INFO - 2023-08-16 19:11:14 --> Security Class Initialized
DEBUG - 2023-08-16 19:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:11:14 --> Input Class Initialized
INFO - 2023-08-16 19:11:14 --> Language Class Initialized
ERROR - 2023-08-16 19:11:14 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:11:15 --> Config Class Initialized
INFO - 2023-08-16 19:11:15 --> Hooks Class Initialized
INFO - 2023-08-16 19:11:15 --> Config Class Initialized
INFO - 2023-08-16 19:11:15 --> Config Class Initialized
INFO - 2023-08-16 19:11:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:11:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:11:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:11:15 --> URI Class Initialized
INFO - 2023-08-16 19:11:15 --> Router Class Initialized
INFO - 2023-08-16 19:11:15 --> Output Class Initialized
INFO - 2023-08-16 19:11:15 --> Security Class Initialized
DEBUG - 2023-08-16 19:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:11:15 --> Input Class Initialized
INFO - 2023-08-16 19:11:15 --> Language Class Initialized
ERROR - 2023-08-16 19:11:15 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:11:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:11:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:11:15 --> Config Class Initialized
INFO - 2023-08-16 19:11:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:11:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:11:15 --> Hooks Class Initialized
INFO - 2023-08-16 19:11:15 --> URI Class Initialized
INFO - 2023-08-16 19:11:15 --> Router Class Initialized
INFO - 2023-08-16 19:11:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:11:15 --> Config Class Initialized
INFO - 2023-08-16 19:11:15 --> Output Class Initialized
DEBUG - 2023-08-16 19:11:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:11:15 --> Hooks Class Initialized
INFO - 2023-08-16 19:11:15 --> URI Class Initialized
INFO - 2023-08-16 19:11:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:11:15 --> Security Class Initialized
INFO - 2023-08-16 19:11:15 --> URI Class Initialized
DEBUG - 2023-08-16 19:11:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:11:15 --> Router Class Initialized
INFO - 2023-08-16 19:11:15 --> Input Class Initialized
INFO - 2023-08-16 19:11:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:11:15 --> Router Class Initialized
INFO - 2023-08-16 19:11:15 --> URI Class Initialized
INFO - 2023-08-16 19:11:15 --> Output Class Initialized
INFO - 2023-08-16 19:11:15 --> Language Class Initialized
INFO - 2023-08-16 19:11:15 --> Router Class Initialized
INFO - 2023-08-16 19:11:15 --> Output Class Initialized
INFO - 2023-08-16 19:11:15 --> Output Class Initialized
INFO - 2023-08-16 19:11:15 --> Security Class Initialized
ERROR - 2023-08-16 19:11:15 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:11:15 --> Security Class Initialized
INFO - 2023-08-16 19:11:15 --> Security Class Initialized
DEBUG - 2023-08-16 19:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:11:15 --> Input Class Initialized
DEBUG - 2023-08-16 19:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:11:15 --> Language Class Initialized
INFO - 2023-08-16 19:11:15 --> Input Class Initialized
INFO - 2023-08-16 19:11:15 --> Input Class Initialized
INFO - 2023-08-16 19:11:15 --> Language Class Initialized
INFO - 2023-08-16 19:11:15 --> Language Class Initialized
ERROR - 2023-08-16 19:11:15 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:11:15 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:11:15 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:11:53 --> Config Class Initialized
INFO - 2023-08-16 19:11:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:11:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:11:53 --> Utf8 Class Initialized
INFO - 2023-08-16 19:11:53 --> URI Class Initialized
INFO - 2023-08-16 19:11:53 --> Router Class Initialized
INFO - 2023-08-16 19:11:53 --> Output Class Initialized
INFO - 2023-08-16 19:11:53 --> Security Class Initialized
DEBUG - 2023-08-16 19:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:11:53 --> Input Class Initialized
INFO - 2023-08-16 19:11:53 --> Language Class Initialized
INFO - 2023-08-16 19:11:53 --> Loader Class Initialized
INFO - 2023-08-16 19:11:53 --> Helper loaded: url_helper
INFO - 2023-08-16 19:11:53 --> Helper loaded: file_helper
INFO - 2023-08-16 19:11:53 --> Database Driver Class Initialized
INFO - 2023-08-16 19:11:53 --> Email Class Initialized
DEBUG - 2023-08-16 19:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:11:53 --> Controller Class Initialized
INFO - 2023-08-16 19:11:53 --> Model "Home_model" initialized
INFO - 2023-08-16 19:11:53 --> Helper loaded: form_helper
INFO - 2023-08-16 19:11:53 --> Form Validation Class Initialized
INFO - 2023-08-16 19:11:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:11:53 --> Final output sent to browser
DEBUG - 2023-08-16 19:11:53 --> Total execution time: 0.5151
INFO - 2023-08-16 19:11:54 --> Config Class Initialized
INFO - 2023-08-16 19:11:54 --> Hooks Class Initialized
INFO - 2023-08-16 19:11:54 --> Config Class Initialized
INFO - 2023-08-16 19:11:54 --> Config Class Initialized
DEBUG - 2023-08-16 19:11:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:11:54 --> Hooks Class Initialized
INFO - 2023-08-16 19:11:54 --> Config Class Initialized
INFO - 2023-08-16 19:11:54 --> Hooks Class Initialized
INFO - 2023-08-16 19:11:54 --> Utf8 Class Initialized
INFO - 2023-08-16 19:11:54 --> Config Class Initialized
INFO - 2023-08-16 19:11:54 --> Hooks Class Initialized
INFO - 2023-08-16 19:11:54 --> URI Class Initialized
DEBUG - 2023-08-16 19:11:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:11:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:11:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:11:54 --> Utf8 Class Initialized
INFO - 2023-08-16 19:11:54 --> Router Class Initialized
INFO - 2023-08-16 19:11:54 --> URI Class Initialized
DEBUG - 2023-08-16 19:11:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:11:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:11:54 --> Utf8 Class Initialized
INFO - 2023-08-16 19:11:54 --> Router Class Initialized
INFO - 2023-08-16 19:11:54 --> Output Class Initialized
INFO - 2023-08-16 19:11:54 --> Security Class Initialized
DEBUG - 2023-08-16 19:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:11:54 --> Input Class Initialized
INFO - 2023-08-16 19:11:54 --> Language Class Initialized
ERROR - 2023-08-16 19:11:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:11:54 --> Utf8 Class Initialized
INFO - 2023-08-16 19:11:54 --> Output Class Initialized
INFO - 2023-08-16 19:11:54 --> URI Class Initialized
INFO - 2023-08-16 19:11:54 --> Utf8 Class Initialized
INFO - 2023-08-16 19:11:54 --> URI Class Initialized
INFO - 2023-08-16 19:11:54 --> URI Class Initialized
INFO - 2023-08-16 19:11:54 --> Router Class Initialized
INFO - 2023-08-16 19:11:54 --> Router Class Initialized
INFO - 2023-08-16 19:11:54 --> Output Class Initialized
INFO - 2023-08-16 19:11:54 --> Security Class Initialized
INFO - 2023-08-16 19:11:54 --> Security Class Initialized
INFO - 2023-08-16 19:11:54 --> Router Class Initialized
INFO - 2023-08-16 19:11:54 --> Output Class Initialized
DEBUG - 2023-08-16 19:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:11:55 --> Input Class Initialized
INFO - 2023-08-16 19:11:55 --> Output Class Initialized
INFO - 2023-08-16 19:11:55 --> Input Class Initialized
INFO - 2023-08-16 19:11:55 --> Language Class Initialized
ERROR - 2023-08-16 19:11:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:11:55 --> Security Class Initialized
INFO - 2023-08-16 19:11:55 --> Security Class Initialized
DEBUG - 2023-08-16 19:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:11:55 --> Language Class Initialized
INFO - 2023-08-16 19:11:55 --> Input Class Initialized
DEBUG - 2023-08-16 19:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:11:55 --> Input Class Initialized
INFO - 2023-08-16 19:11:55 --> Language Class Initialized
ERROR - 2023-08-16 19:11:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:11:55 --> Language Class Initialized
ERROR - 2023-08-16 19:11:55 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:11:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:12:07 --> Config Class Initialized
INFO - 2023-08-16 19:12:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:12:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:07 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:07 --> URI Class Initialized
INFO - 2023-08-16 19:12:07 --> Router Class Initialized
INFO - 2023-08-16 19:12:07 --> Output Class Initialized
INFO - 2023-08-16 19:12:07 --> Security Class Initialized
DEBUG - 2023-08-16 19:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:07 --> Input Class Initialized
INFO - 2023-08-16 19:12:07 --> Language Class Initialized
INFO - 2023-08-16 19:12:07 --> Loader Class Initialized
INFO - 2023-08-16 19:12:07 --> Helper loaded: url_helper
INFO - 2023-08-16 19:12:07 --> Helper loaded: file_helper
INFO - 2023-08-16 19:12:07 --> Database Driver Class Initialized
INFO - 2023-08-16 19:12:07 --> Email Class Initialized
DEBUG - 2023-08-16 19:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:12:07 --> Controller Class Initialized
INFO - 2023-08-16 19:12:07 --> Model "Home_model" initialized
INFO - 2023-08-16 19:12:07 --> Helper loaded: form_helper
INFO - 2023-08-16 19:12:07 --> Form Validation Class Initialized
INFO - 2023-08-16 19:12:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:12:08 --> Final output sent to browser
DEBUG - 2023-08-16 19:12:08 --> Total execution time: 0.5308
INFO - 2023-08-16 19:12:08 --> Config Class Initialized
INFO - 2023-08-16 19:12:08 --> Hooks Class Initialized
INFO - 2023-08-16 19:12:08 --> Config Class Initialized
DEBUG - 2023-08-16 19:12:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:08 --> Config Class Initialized
INFO - 2023-08-16 19:12:08 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:08 --> Config Class Initialized
INFO - 2023-08-16 19:12:08 --> Config Class Initialized
INFO - 2023-08-16 19:12:08 --> Hooks Class Initialized
INFO - 2023-08-16 19:12:08 --> URI Class Initialized
INFO - 2023-08-16 19:12:08 --> Hooks Class Initialized
INFO - 2023-08-16 19:12:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:12:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:12:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:09 --> Router Class Initialized
DEBUG - 2023-08-16 19:12:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:09 --> Output Class Initialized
INFO - 2023-08-16 19:12:09 --> Hooks Class Initialized
INFO - 2023-08-16 19:12:09 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:09 --> Security Class Initialized
INFO - 2023-08-16 19:12:09 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:09 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:12:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:09 --> URI Class Initialized
INFO - 2023-08-16 19:12:09 --> Router Class Initialized
DEBUG - 2023-08-16 19:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:09 --> URI Class Initialized
INFO - 2023-08-16 19:12:09 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:09 --> URI Class Initialized
INFO - 2023-08-16 19:12:09 --> URI Class Initialized
INFO - 2023-08-16 19:12:09 --> Output Class Initialized
INFO - 2023-08-16 19:12:09 --> Input Class Initialized
INFO - 2023-08-16 19:12:09 --> Security Class Initialized
INFO - 2023-08-16 19:12:09 --> Router Class Initialized
DEBUG - 2023-08-16 19:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:09 --> Router Class Initialized
INFO - 2023-08-16 19:12:09 --> Language Class Initialized
INFO - 2023-08-16 19:12:09 --> Output Class Initialized
INFO - 2023-08-16 19:12:09 --> Router Class Initialized
INFO - 2023-08-16 19:12:09 --> Output Class Initialized
ERROR - 2023-08-16 19:12:09 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:12:09 --> Input Class Initialized
INFO - 2023-08-16 19:12:09 --> Language Class Initialized
INFO - 2023-08-16 19:12:09 --> Security Class Initialized
INFO - 2023-08-16 19:12:09 --> Security Class Initialized
DEBUG - 2023-08-16 19:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:09 --> Input Class Initialized
INFO - 2023-08-16 19:12:09 --> Output Class Initialized
INFO - 2023-08-16 19:12:09 --> Language Class Initialized
ERROR - 2023-08-16 19:12:09 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:12:09 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:12:09 --> Input Class Initialized
INFO - 2023-08-16 19:12:09 --> Language Class Initialized
ERROR - 2023-08-16 19:12:09 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:12:09 --> Security Class Initialized
DEBUG - 2023-08-16 19:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:09 --> Input Class Initialized
INFO - 2023-08-16 19:12:09 --> Language Class Initialized
ERROR - 2023-08-16 19:12:09 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:12:11 --> Config Class Initialized
INFO - 2023-08-16 19:12:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:12:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:12 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:12 --> URI Class Initialized
INFO - 2023-08-16 19:12:12 --> Router Class Initialized
INFO - 2023-08-16 19:12:12 --> Output Class Initialized
INFO - 2023-08-16 19:12:12 --> Security Class Initialized
DEBUG - 2023-08-16 19:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:12 --> Input Class Initialized
INFO - 2023-08-16 19:12:12 --> Language Class Initialized
INFO - 2023-08-16 19:12:12 --> Loader Class Initialized
INFO - 2023-08-16 19:12:12 --> Helper loaded: url_helper
INFO - 2023-08-16 19:12:12 --> Helper loaded: file_helper
INFO - 2023-08-16 19:12:12 --> Database Driver Class Initialized
INFO - 2023-08-16 19:12:12 --> Email Class Initialized
DEBUG - 2023-08-16 19:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:12:12 --> Controller Class Initialized
INFO - 2023-08-16 19:12:12 --> Model "Home_model" initialized
INFO - 2023-08-16 19:12:12 --> Helper loaded: form_helper
INFO - 2023-08-16 19:12:12 --> Form Validation Class Initialized
INFO - 2023-08-16 19:12:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:12:12 --> Final output sent to browser
DEBUG - 2023-08-16 19:12:12 --> Total execution time: 0.4031
INFO - 2023-08-16 19:12:12 --> Config Class Initialized
INFO - 2023-08-16 19:12:13 --> Config Class Initialized
INFO - 2023-08-16 19:12:13 --> Config Class Initialized
INFO - 2023-08-16 19:12:13 --> Config Class Initialized
INFO - 2023-08-16 19:12:13 --> Hooks Class Initialized
INFO - 2023-08-16 19:12:13 --> Config Class Initialized
INFO - 2023-08-16 19:12:13 --> Hooks Class Initialized
INFO - 2023-08-16 19:12:13 --> Hooks Class Initialized
INFO - 2023-08-16 19:12:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:12:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:13 --> URI Class Initialized
INFO - 2023-08-16 19:12:13 --> Router Class Initialized
INFO - 2023-08-16 19:12:13 --> Output Class Initialized
INFO - 2023-08-16 19:12:13 --> Security Class Initialized
DEBUG - 2023-08-16 19:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:13 --> Input Class Initialized
INFO - 2023-08-16 19:12:13 --> Language Class Initialized
ERROR - 2023-08-16 19:12:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:12:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:12:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:12:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:12:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:12:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:13 --> URI Class Initialized
INFO - 2023-08-16 19:12:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:13 --> URI Class Initialized
INFO - 2023-08-16 19:12:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:13 --> Router Class Initialized
INFO - 2023-08-16 19:12:13 --> URI Class Initialized
INFO - 2023-08-16 19:12:13 --> URI Class Initialized
INFO - 2023-08-16 19:12:13 --> Router Class Initialized
INFO - 2023-08-16 19:12:13 --> Output Class Initialized
INFO - 2023-08-16 19:12:13 --> Output Class Initialized
INFO - 2023-08-16 19:12:13 --> Security Class Initialized
INFO - 2023-08-16 19:12:13 --> Router Class Initialized
DEBUG - 2023-08-16 19:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:13 --> Router Class Initialized
INFO - 2023-08-16 19:12:13 --> Security Class Initialized
INFO - 2023-08-16 19:12:13 --> Input Class Initialized
INFO - 2023-08-16 19:12:13 --> Output Class Initialized
INFO - 2023-08-16 19:12:13 --> Language Class Initialized
INFO - 2023-08-16 19:12:13 --> Security Class Initialized
INFO - 2023-08-16 19:12:13 --> Output Class Initialized
DEBUG - 2023-08-16 19:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:13 --> Input Class Initialized
DEBUG - 2023-08-16 19:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:13 --> Language Class Initialized
ERROR - 2023-08-16 19:12:13 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:12:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:12:13 --> Security Class Initialized
INFO - 2023-08-16 19:12:13 --> Input Class Initialized
DEBUG - 2023-08-16 19:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:13 --> Language Class Initialized
INFO - 2023-08-16 19:12:13 --> Input Class Initialized
ERROR - 2023-08-16 19:12:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:12:13 --> Language Class Initialized
ERROR - 2023-08-16 19:12:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:12:20 --> Config Class Initialized
INFO - 2023-08-16 19:12:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:12:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:20 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:20 --> URI Class Initialized
INFO - 2023-08-16 19:12:20 --> Router Class Initialized
INFO - 2023-08-16 19:12:20 --> Output Class Initialized
INFO - 2023-08-16 19:12:20 --> Security Class Initialized
DEBUG - 2023-08-16 19:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:20 --> Input Class Initialized
INFO - 2023-08-16 19:12:20 --> Language Class Initialized
INFO - 2023-08-16 19:12:20 --> Loader Class Initialized
INFO - 2023-08-16 19:12:20 --> Helper loaded: url_helper
INFO - 2023-08-16 19:12:20 --> Helper loaded: file_helper
INFO - 2023-08-16 19:12:20 --> Database Driver Class Initialized
INFO - 2023-08-16 19:12:20 --> Email Class Initialized
DEBUG - 2023-08-16 19:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:12:21 --> Controller Class Initialized
INFO - 2023-08-16 19:12:21 --> Model "Home_model" initialized
INFO - 2023-08-16 19:12:21 --> Helper loaded: form_helper
INFO - 2023-08-16 19:12:21 --> Form Validation Class Initialized
INFO - 2023-08-16 19:12:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:12:21 --> Final output sent to browser
DEBUG - 2023-08-16 19:12:21 --> Total execution time: 0.4153
INFO - 2023-08-16 19:12:21 --> Config Class Initialized
INFO - 2023-08-16 19:12:21 --> Hooks Class Initialized
INFO - 2023-08-16 19:12:21 --> Config Class Initialized
DEBUG - 2023-08-16 19:12:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:22 --> Config Class Initialized
INFO - 2023-08-16 19:12:22 --> Hooks Class Initialized
INFO - 2023-08-16 19:12:22 --> Hooks Class Initialized
INFO - 2023-08-16 19:12:22 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:12:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:22 --> URI Class Initialized
DEBUG - 2023-08-16 19:12:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:22 --> Router Class Initialized
INFO - 2023-08-16 19:12:22 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:22 --> URI Class Initialized
INFO - 2023-08-16 19:12:22 --> Output Class Initialized
INFO - 2023-08-16 19:12:22 --> Security Class Initialized
INFO - 2023-08-16 19:12:22 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:22 --> Router Class Initialized
INFO - 2023-08-16 19:12:22 --> Input Class Initialized
INFO - 2023-08-16 19:12:22 --> Output Class Initialized
INFO - 2023-08-16 19:12:22 --> Language Class Initialized
INFO - 2023-08-16 19:12:22 --> URI Class Initialized
INFO - 2023-08-16 19:12:22 --> Security Class Initialized
ERROR - 2023-08-16 19:12:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:12:22 --> Router Class Initialized
DEBUG - 2023-08-16 19:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:22 --> Config Class Initialized
INFO - 2023-08-16 19:12:22 --> Output Class Initialized
INFO - 2023-08-16 19:12:22 --> Input Class Initialized
INFO - 2023-08-16 19:12:22 --> Config Class Initialized
INFO - 2023-08-16 19:12:22 --> Config Class Initialized
INFO - 2023-08-16 19:12:22 --> Language Class Initialized
INFO - 2023-08-16 19:12:22 --> Security Class Initialized
INFO - 2023-08-16 19:12:22 --> Hooks Class Initialized
INFO - 2023-08-16 19:12:22 --> Hooks Class Initialized
INFO - 2023-08-16 19:12:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:12:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:22 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:12:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:22 --> URI Class Initialized
DEBUG - 2023-08-16 19:12:22 --> UTF-8 Support Enabled
ERROR - 2023-08-16 19:12:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:12:22 --> Input Class Initialized
INFO - 2023-08-16 19:12:22 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:22 --> Router Class Initialized
INFO - 2023-08-16 19:12:22 --> Language Class Initialized
INFO - 2023-08-16 19:12:22 --> Utf8 Class Initialized
ERROR - 2023-08-16 19:12:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:12:22 --> URI Class Initialized
INFO - 2023-08-16 19:12:22 --> Output Class Initialized
INFO - 2023-08-16 19:12:22 --> Security Class Initialized
INFO - 2023-08-16 19:12:22 --> Router Class Initialized
INFO - 2023-08-16 19:12:22 --> URI Class Initialized
INFO - 2023-08-16 19:12:22 --> Output Class Initialized
INFO - 2023-08-16 19:12:22 --> Router Class Initialized
INFO - 2023-08-16 19:12:22 --> Output Class Initialized
INFO - 2023-08-16 19:12:22 --> Security Class Initialized
DEBUG - 2023-08-16 19:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:22 --> Input Class Initialized
INFO - 2023-08-16 19:12:22 --> Language Class Initialized
INFO - 2023-08-16 19:12:22 --> Input Class Initialized
INFO - 2023-08-16 19:12:22 --> Security Class Initialized
INFO - 2023-08-16 19:12:22 --> Language Class Initialized
ERROR - 2023-08-16 19:12:22 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:22 --> Input Class Initialized
INFO - 2023-08-16 19:12:23 --> Language Class Initialized
ERROR - 2023-08-16 19:12:23 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:12:23 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:12:46 --> Config Class Initialized
INFO - 2023-08-16 19:12:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:12:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:46 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:46 --> URI Class Initialized
INFO - 2023-08-16 19:12:46 --> Router Class Initialized
INFO - 2023-08-16 19:12:46 --> Output Class Initialized
INFO - 2023-08-16 19:12:46 --> Security Class Initialized
DEBUG - 2023-08-16 19:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:46 --> Input Class Initialized
INFO - 2023-08-16 19:12:46 --> Language Class Initialized
ERROR - 2023-08-16 19:12:46 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:12:47 --> Config Class Initialized
INFO - 2023-08-16 19:12:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:12:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:47 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:47 --> URI Class Initialized
INFO - 2023-08-16 19:12:47 --> Router Class Initialized
INFO - 2023-08-16 19:12:47 --> Output Class Initialized
INFO - 2023-08-16 19:12:47 --> Security Class Initialized
DEBUG - 2023-08-16 19:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:47 --> Input Class Initialized
INFO - 2023-08-16 19:12:47 --> Language Class Initialized
ERROR - 2023-08-16 19:12:47 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:12:47 --> Config Class Initialized
INFO - 2023-08-16 19:12:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:12:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:47 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:47 --> URI Class Initialized
INFO - 2023-08-16 19:12:47 --> Router Class Initialized
INFO - 2023-08-16 19:12:47 --> Output Class Initialized
INFO - 2023-08-16 19:12:47 --> Security Class Initialized
DEBUG - 2023-08-16 19:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:47 --> Input Class Initialized
INFO - 2023-08-16 19:12:47 --> Language Class Initialized
ERROR - 2023-08-16 19:12:47 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:12:47 --> Config Class Initialized
INFO - 2023-08-16 19:12:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:12:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:47 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:47 --> URI Class Initialized
INFO - 2023-08-16 19:12:47 --> Router Class Initialized
INFO - 2023-08-16 19:12:47 --> Output Class Initialized
INFO - 2023-08-16 19:12:47 --> Security Class Initialized
DEBUG - 2023-08-16 19:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:48 --> Input Class Initialized
INFO - 2023-08-16 19:12:48 --> Language Class Initialized
ERROR - 2023-08-16 19:12:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:12:48 --> Config Class Initialized
INFO - 2023-08-16 19:12:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:12:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:48 --> URI Class Initialized
INFO - 2023-08-16 19:12:48 --> Router Class Initialized
INFO - 2023-08-16 19:12:48 --> Output Class Initialized
INFO - 2023-08-16 19:12:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:48 --> Input Class Initialized
INFO - 2023-08-16 19:12:48 --> Language Class Initialized
ERROR - 2023-08-16 19:12:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:12:48 --> Config Class Initialized
INFO - 2023-08-16 19:12:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:12:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:48 --> URI Class Initialized
INFO - 2023-08-16 19:12:48 --> Router Class Initialized
INFO - 2023-08-16 19:12:48 --> Output Class Initialized
INFO - 2023-08-16 19:12:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:48 --> Input Class Initialized
INFO - 2023-08-16 19:12:48 --> Language Class Initialized
ERROR - 2023-08-16 19:12:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:12:48 --> Config Class Initialized
INFO - 2023-08-16 19:12:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:12:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:12:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:12:48 --> URI Class Initialized
INFO - 2023-08-16 19:12:48 --> Router Class Initialized
INFO - 2023-08-16 19:12:48 --> Output Class Initialized
INFO - 2023-08-16 19:12:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:12:48 --> Input Class Initialized
INFO - 2023-08-16 19:12:48 --> Language Class Initialized
ERROR - 2023-08-16 19:12:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:13:53 --> Config Class Initialized
INFO - 2023-08-16 19:13:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:13:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:53 --> Utf8 Class Initialized
INFO - 2023-08-16 19:13:53 --> URI Class Initialized
INFO - 2023-08-16 19:13:53 --> Router Class Initialized
INFO - 2023-08-16 19:13:53 --> Output Class Initialized
INFO - 2023-08-16 19:13:53 --> Security Class Initialized
DEBUG - 2023-08-16 19:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:13:53 --> Input Class Initialized
INFO - 2023-08-16 19:13:53 --> Language Class Initialized
INFO - 2023-08-16 19:13:53 --> Loader Class Initialized
INFO - 2023-08-16 19:13:53 --> Helper loaded: url_helper
INFO - 2023-08-16 19:13:53 --> Helper loaded: file_helper
INFO - 2023-08-16 19:13:53 --> Database Driver Class Initialized
INFO - 2023-08-16 19:13:53 --> Email Class Initialized
DEBUG - 2023-08-16 19:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:13:53 --> Controller Class Initialized
INFO - 2023-08-16 19:13:53 --> Model "Home_model" initialized
INFO - 2023-08-16 19:13:53 --> Helper loaded: form_helper
INFO - 2023-08-16 19:13:53 --> Form Validation Class Initialized
INFO - 2023-08-16 19:13:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:13:53 --> Final output sent to browser
DEBUG - 2023-08-16 19:13:53 --> Total execution time: 0.1499
INFO - 2023-08-16 19:13:53 --> Config Class Initialized
INFO - 2023-08-16 19:13:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:13:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:53 --> Utf8 Class Initialized
INFO - 2023-08-16 19:13:53 --> URI Class Initialized
INFO - 2023-08-16 19:13:53 --> Router Class Initialized
INFO - 2023-08-16 19:13:53 --> Output Class Initialized
INFO - 2023-08-16 19:13:53 --> Security Class Initialized
DEBUG - 2023-08-16 19:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:13:53 --> Input Class Initialized
INFO - 2023-08-16 19:13:53 --> Language Class Initialized
ERROR - 2023-08-16 19:13:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:13:54 --> Config Class Initialized
INFO - 2023-08-16 19:13:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:13:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:54 --> Utf8 Class Initialized
INFO - 2023-08-16 19:13:54 --> URI Class Initialized
INFO - 2023-08-16 19:13:54 --> Router Class Initialized
INFO - 2023-08-16 19:13:54 --> Output Class Initialized
INFO - 2023-08-16 19:13:54 --> Config Class Initialized
INFO - 2023-08-16 19:13:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:13:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:55 --> Utf8 Class Initialized
INFO - 2023-08-16 19:13:55 --> URI Class Initialized
INFO - 2023-08-16 19:13:55 --> Router Class Initialized
INFO - 2023-08-16 19:13:55 --> Output Class Initialized
INFO - 2023-08-16 19:13:55 --> Security Class Initialized
DEBUG - 2023-08-16 19:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:13:55 --> Input Class Initialized
INFO - 2023-08-16 19:13:55 --> Language Class Initialized
ERROR - 2023-08-16 19:13:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:13:55 --> Security Class Initialized
DEBUG - 2023-08-16 19:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:13:55 --> Input Class Initialized
INFO - 2023-08-16 19:13:55 --> Language Class Initialized
ERROR - 2023-08-16 19:13:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:13:55 --> Config Class Initialized
INFO - 2023-08-16 19:13:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:13:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:55 --> Utf8 Class Initialized
INFO - 2023-08-16 19:13:55 --> URI Class Initialized
INFO - 2023-08-16 19:13:55 --> Router Class Initialized
INFO - 2023-08-16 19:13:55 --> Output Class Initialized
INFO - 2023-08-16 19:13:55 --> Security Class Initialized
DEBUG - 2023-08-16 19:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:13:55 --> Input Class Initialized
INFO - 2023-08-16 19:13:55 --> Language Class Initialized
ERROR - 2023-08-16 19:13:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:13:55 --> Config Class Initialized
INFO - 2023-08-16 19:13:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:13:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:55 --> Utf8 Class Initialized
INFO - 2023-08-16 19:13:55 --> URI Class Initialized
INFO - 2023-08-16 19:13:55 --> Router Class Initialized
INFO - 2023-08-16 19:13:55 --> Output Class Initialized
INFO - 2023-08-16 19:13:55 --> Security Class Initialized
DEBUG - 2023-08-16 19:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:13:55 --> Input Class Initialized
INFO - 2023-08-16 19:13:55 --> Language Class Initialized
ERROR - 2023-08-16 19:13:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:13:56 --> Config Class Initialized
INFO - 2023-08-16 19:13:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:13:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:56 --> Utf8 Class Initialized
INFO - 2023-08-16 19:13:56 --> URI Class Initialized
INFO - 2023-08-16 19:13:56 --> Router Class Initialized
INFO - 2023-08-16 19:13:56 --> Output Class Initialized
INFO - 2023-08-16 19:13:56 --> Security Class Initialized
DEBUG - 2023-08-16 19:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:13:56 --> Input Class Initialized
INFO - 2023-08-16 19:13:56 --> Language Class Initialized
ERROR - 2023-08-16 19:13:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:13:56 --> Config Class Initialized
INFO - 2023-08-16 19:13:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:13:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:56 --> Utf8 Class Initialized
INFO - 2023-08-16 19:13:56 --> URI Class Initialized
INFO - 2023-08-16 19:13:56 --> Router Class Initialized
INFO - 2023-08-16 19:13:56 --> Config Class Initialized
INFO - 2023-08-16 19:13:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:13:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:56 --> Utf8 Class Initialized
INFO - 2023-08-16 19:13:56 --> URI Class Initialized
INFO - 2023-08-16 19:13:56 --> Config Class Initialized
INFO - 2023-08-16 19:13:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:13:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:56 --> Utf8 Class Initialized
INFO - 2023-08-16 19:13:56 --> URI Class Initialized
INFO - 2023-08-16 19:13:56 --> Router Class Initialized
INFO - 2023-08-16 19:13:56 --> Output Class Initialized
INFO - 2023-08-16 19:13:56 --> Security Class Initialized
DEBUG - 2023-08-16 19:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:13:56 --> Input Class Initialized
INFO - 2023-08-16 19:13:56 --> Config Class Initialized
INFO - 2023-08-16 19:13:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:13:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:56 --> Utf8 Class Initialized
INFO - 2023-08-16 19:13:56 --> URI Class Initialized
INFO - 2023-08-16 19:13:56 --> Router Class Initialized
INFO - 2023-08-16 19:13:56 --> Output Class Initialized
INFO - 2023-08-16 19:13:56 --> Security Class Initialized
DEBUG - 2023-08-16 19:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:13:56 --> Input Class Initialized
INFO - 2023-08-16 19:13:56 --> Language Class Initialized
ERROR - 2023-08-16 19:13:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:13:57 --> Config Class Initialized
INFO - 2023-08-16 19:13:57 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:13:57 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:57 --> Utf8 Class Initialized
INFO - 2023-08-16 19:13:57 --> URI Class Initialized
INFO - 2023-08-16 19:13:57 --> Router Class Initialized
INFO - 2023-08-16 19:13:57 --> Output Class Initialized
INFO - 2023-08-16 19:13:57 --> Security Class Initialized
DEBUG - 2023-08-16 19:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:13:57 --> Input Class Initialized
INFO - 2023-08-16 19:13:57 --> Language Class Initialized
ERROR - 2023-08-16 19:13:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:13:57 --> Config Class Initialized
INFO - 2023-08-16 19:13:57 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:13:57 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:57 --> Utf8 Class Initialized
INFO - 2023-08-16 19:13:57 --> URI Class Initialized
INFO - 2023-08-16 19:13:57 --> Router Class Initialized
INFO - 2023-08-16 19:13:57 --> Output Class Initialized
INFO - 2023-08-16 19:13:57 --> Security Class Initialized
DEBUG - 2023-08-16 19:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:13:57 --> Input Class Initialized
INFO - 2023-08-16 19:13:57 --> Language Class Initialized
ERROR - 2023-08-16 19:13:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:13:57 --> Config Class Initialized
INFO - 2023-08-16 19:13:57 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:13:57 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:57 --> Utf8 Class Initialized
INFO - 2023-08-16 19:13:57 --> URI Class Initialized
INFO - 2023-08-16 19:13:57 --> Router Class Initialized
INFO - 2023-08-16 19:13:57 --> Output Class Initialized
INFO - 2023-08-16 19:13:57 --> Security Class Initialized
DEBUG - 2023-08-16 19:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:13:57 --> Input Class Initialized
INFO - 2023-08-16 19:13:57 --> Language Class Initialized
ERROR - 2023-08-16 19:13:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:13:57 --> Config Class Initialized
INFO - 2023-08-16 19:13:57 --> Language Class Initialized
ERROR - 2023-08-16 19:13:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:13:57 --> Hooks Class Initialized
INFO - 2023-08-16 19:13:57 --> Output Class Initialized
INFO - 2023-08-16 19:13:57 --> Security Class Initialized
DEBUG - 2023-08-16 19:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:13:57 --> Input Class Initialized
INFO - 2023-08-16 19:13:57 --> Language Class Initialized
ERROR - 2023-08-16 19:13:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:13:57 --> Router Class Initialized
DEBUG - 2023-08-16 19:13:57 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:13:57 --> Output Class Initialized
INFO - 2023-08-16 19:13:57 --> Utf8 Class Initialized
INFO - 2023-08-16 19:14:49 --> Config Class Initialized
INFO - 2023-08-16 19:14:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:14:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:14:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:14:49 --> URI Class Initialized
INFO - 2023-08-16 19:14:49 --> Router Class Initialized
INFO - 2023-08-16 19:14:49 --> Output Class Initialized
INFO - 2023-08-16 19:14:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:14:49 --> Input Class Initialized
INFO - 2023-08-16 19:14:49 --> Language Class Initialized
INFO - 2023-08-16 19:14:49 --> Loader Class Initialized
INFO - 2023-08-16 19:14:50 --> Helper loaded: url_helper
INFO - 2023-08-16 19:14:50 --> Helper loaded: file_helper
INFO - 2023-08-16 19:14:50 --> Database Driver Class Initialized
INFO - 2023-08-16 19:14:50 --> Email Class Initialized
DEBUG - 2023-08-16 19:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:14:50 --> Controller Class Initialized
INFO - 2023-08-16 19:14:50 --> Model "Home_model" initialized
INFO - 2023-08-16 19:14:50 --> Helper loaded: form_helper
INFO - 2023-08-16 19:14:50 --> Form Validation Class Initialized
INFO - 2023-08-16 19:14:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:14:50 --> Final output sent to browser
DEBUG - 2023-08-16 19:14:50 --> Total execution time: 0.7071
INFO - 2023-08-16 19:14:52 --> Config Class Initialized
INFO - 2023-08-16 19:14:53 --> Config Class Initialized
INFO - 2023-08-16 19:14:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:14:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:14:53 --> Utf8 Class Initialized
INFO - 2023-08-16 19:14:53 --> URI Class Initialized
INFO - 2023-08-16 19:14:53 --> Router Class Initialized
INFO - 2023-08-16 19:14:53 --> Output Class Initialized
INFO - 2023-08-16 19:14:53 --> Security Class Initialized
DEBUG - 2023-08-16 19:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:14:53 --> Input Class Initialized
INFO - 2023-08-16 19:14:53 --> Language Class Initialized
ERROR - 2023-08-16 19:14:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:14:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:14:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:14:53 --> Utf8 Class Initialized
INFO - 2023-08-16 19:14:53 --> URI Class Initialized
INFO - 2023-08-16 19:14:53 --> Config Class Initialized
INFO - 2023-08-16 19:14:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:14:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:14:54 --> Config Class Initialized
INFO - 2023-08-16 19:14:54 --> Hooks Class Initialized
INFO - 2023-08-16 19:14:54 --> Config Class Initialized
INFO - 2023-08-16 19:14:54 --> Utf8 Class Initialized
INFO - 2023-08-16 19:14:54 --> Router Class Initialized
INFO - 2023-08-16 19:14:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:14:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:14:54 --> URI Class Initialized
DEBUG - 2023-08-16 19:14:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:14:54 --> Router Class Initialized
INFO - 2023-08-16 19:14:54 --> Utf8 Class Initialized
INFO - 2023-08-16 19:14:54 --> Utf8 Class Initialized
INFO - 2023-08-16 19:14:54 --> URI Class Initialized
INFO - 2023-08-16 19:14:54 --> Output Class Initialized
INFO - 2023-08-16 19:14:54 --> Router Class Initialized
INFO - 2023-08-16 19:14:54 --> Security Class Initialized
INFO - 2023-08-16 19:14:54 --> Output Class Initialized
INFO - 2023-08-16 19:14:54 --> Output Class Initialized
INFO - 2023-08-16 19:14:54 --> URI Class Initialized
INFO - 2023-08-16 19:14:54 --> Security Class Initialized
DEBUG - 2023-08-16 19:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:14:54 --> Security Class Initialized
DEBUG - 2023-08-16 19:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:14:54 --> Input Class Initialized
INFO - 2023-08-16 19:14:54 --> Language Class Initialized
ERROR - 2023-08-16 19:14:54 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:14:54 --> Router Class Initialized
INFO - 2023-08-16 19:14:54 --> Input Class Initialized
INFO - 2023-08-16 19:14:54 --> Language Class Initialized
ERROR - 2023-08-16 19:14:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:14:55 --> Config Class Initialized
INFO - 2023-08-16 19:14:55 --> Input Class Initialized
INFO - 2023-08-16 19:14:55 --> Output Class Initialized
INFO - 2023-08-16 19:14:55 --> Security Class Initialized
INFO - 2023-08-16 19:14:55 --> Config Class Initialized
INFO - 2023-08-16 19:14:55 --> Config Class Initialized
DEBUG - 2023-08-16 19:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:14:55 --> Config Class Initialized
INFO - 2023-08-16 19:14:55 --> Hooks Class Initialized
INFO - 2023-08-16 19:14:55 --> Language Class Initialized
DEBUG - 2023-08-16 19:14:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:14:55 --> Hooks Class Initialized
INFO - 2023-08-16 19:14:55 --> Hooks Class Initialized
INFO - 2023-08-16 19:14:55 --> Input Class Initialized
ERROR - 2023-08-16 19:14:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:14:55 --> Utf8 Class Initialized
INFO - 2023-08-16 19:14:55 --> URI Class Initialized
DEBUG - 2023-08-16 19:14:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:14:55 --> Router Class Initialized
INFO - 2023-08-16 19:14:55 --> Language Class Initialized
INFO - 2023-08-16 19:14:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:14:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:14:55 --> Utf8 Class Initialized
INFO - 2023-08-16 19:14:55 --> URI Class Initialized
INFO - 2023-08-16 19:14:55 --> Router Class Initialized
INFO - 2023-08-16 19:14:55 --> Output Class Initialized
INFO - 2023-08-16 19:14:55 --> Security Class Initialized
DEBUG - 2023-08-16 19:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:14:55 --> Input Class Initialized
INFO - 2023-08-16 19:14:55 --> Language Class Initialized
ERROR - 2023-08-16 19:14:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:14:55 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:14:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:14:55 --> Utf8 Class Initialized
INFO - 2023-08-16 19:14:55 --> Output Class Initialized
ERROR - 2023-08-16 19:14:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:14:55 --> URI Class Initialized
INFO - 2023-08-16 19:14:55 --> URI Class Initialized
INFO - 2023-08-16 19:14:55 --> Config Class Initialized
INFO - 2023-08-16 19:14:55 --> Security Class Initialized
INFO - 2023-08-16 19:14:55 --> Config Class Initialized
INFO - 2023-08-16 19:14:55 --> Router Class Initialized
INFO - 2023-08-16 19:14:55 --> Router Class Initialized
INFO - 2023-08-16 19:14:55 --> Hooks Class Initialized
INFO - 2023-08-16 19:14:55 --> Hooks Class Initialized
INFO - 2023-08-16 19:14:55 --> Config Class Initialized
DEBUG - 2023-08-16 19:14:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:14:55 --> Hooks Class Initialized
INFO - 2023-08-16 19:14:55 --> Output Class Initialized
DEBUG - 2023-08-16 19:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:14:55 --> Security Class Initialized
INFO - 2023-08-16 19:14:55 --> Output Class Initialized
INFO - 2023-08-16 19:14:55 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:14:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:14:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:14:55 --> Input Class Initialized
INFO - 2023-08-16 19:14:55 --> Language Class Initialized
ERROR - 2023-08-16 19:14:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:14:55 --> Input Class Initialized
INFO - 2023-08-16 19:14:55 --> Security Class Initialized
INFO - 2023-08-16 19:14:55 --> URI Class Initialized
INFO - 2023-08-16 19:14:55 --> Language Class Initialized
ERROR - 2023-08-16 19:14:55 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:14:56 --> Config Class Initialized
INFO - 2023-08-16 19:14:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:14:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:14:56 --> Utf8 Class Initialized
INFO - 2023-08-16 19:14:56 --> URI Class Initialized
INFO - 2023-08-16 19:14:56 --> Router Class Initialized
INFO - 2023-08-16 19:14:57 --> Output Class Initialized
INFO - 2023-08-16 19:14:57 --> Security Class Initialized
DEBUG - 2023-08-16 19:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:14:57 --> Input Class Initialized
INFO - 2023-08-16 19:14:57 --> Language Class Initialized
ERROR - 2023-08-16 19:14:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:15:03 --> Config Class Initialized
INFO - 2023-08-16 19:15:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:15:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:15:03 --> Utf8 Class Initialized
INFO - 2023-08-16 19:15:03 --> URI Class Initialized
INFO - 2023-08-16 19:15:03 --> Router Class Initialized
INFO - 2023-08-16 19:15:03 --> Output Class Initialized
INFO - 2023-08-16 19:15:03 --> Security Class Initialized
DEBUG - 2023-08-16 19:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:15:03 --> Input Class Initialized
INFO - 2023-08-16 19:15:03 --> Language Class Initialized
INFO - 2023-08-16 19:15:03 --> Loader Class Initialized
INFO - 2023-08-16 19:15:03 --> Helper loaded: url_helper
INFO - 2023-08-16 19:15:03 --> Helper loaded: file_helper
INFO - 2023-08-16 19:15:03 --> Database Driver Class Initialized
INFO - 2023-08-16 19:15:03 --> Email Class Initialized
DEBUG - 2023-08-16 19:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:15:03 --> Controller Class Initialized
INFO - 2023-08-16 19:15:03 --> Model "Home_model" initialized
INFO - 2023-08-16 19:15:03 --> Helper loaded: form_helper
INFO - 2023-08-16 19:15:03 --> Form Validation Class Initialized
INFO - 2023-08-16 19:15:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:15:03 --> Final output sent to browser
DEBUG - 2023-08-16 19:15:04 --> Total execution time: 0.4234
INFO - 2023-08-16 19:15:06 --> Config Class Initialized
INFO - 2023-08-16 19:15:06 --> Config Class Initialized
INFO - 2023-08-16 19:15:06 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:15:06 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:15:06 --> Hooks Class Initialized
INFO - 2023-08-16 19:15:07 --> Utf8 Class Initialized
INFO - 2023-08-16 19:15:08 --> Config Class Initialized
DEBUG - 2023-08-16 19:15:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:15:08 --> Config Class Initialized
INFO - 2023-08-16 19:15:08 --> Hooks Class Initialized
INFO - 2023-08-16 19:15:08 --> Utf8 Class Initialized
INFO - 2023-08-16 19:15:08 --> URI Class Initialized
INFO - 2023-08-16 19:15:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:15:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:15:08 --> Config Class Initialized
INFO - 2023-08-16 19:15:08 --> Router Class Initialized
INFO - 2023-08-16 19:15:08 --> URI Class Initialized
INFO - 2023-08-16 19:15:08 --> Utf8 Class Initialized
INFO - 2023-08-16 19:15:08 --> Router Class Initialized
DEBUG - 2023-08-16 19:15:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:15:08 --> Output Class Initialized
INFO - 2023-08-16 19:15:08 --> Hooks Class Initialized
INFO - 2023-08-16 19:15:09 --> Output Class Initialized
DEBUG - 2023-08-16 19:15:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:15:09 --> Utf8 Class Initialized
INFO - 2023-08-16 19:15:09 --> URI Class Initialized
INFO - 2023-08-16 19:15:09 --> URI Class Initialized
INFO - 2023-08-16 19:15:09 --> Config Class Initialized
INFO - 2023-08-16 19:15:09 --> Router Class Initialized
INFO - 2023-08-16 19:15:09 --> Security Class Initialized
INFO - 2023-08-16 19:15:09 --> Hooks Class Initialized
INFO - 2023-08-16 19:15:09 --> Security Class Initialized
INFO - 2023-08-16 19:15:09 --> Utf8 Class Initialized
INFO - 2023-08-16 19:15:09 --> Output Class Initialized
INFO - 2023-08-16 19:15:09 --> Router Class Initialized
INFO - 2023-08-16 19:15:09 --> URI Class Initialized
DEBUG - 2023-08-16 19:15:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:15:09 --> Router Class Initialized
INFO - 2023-08-16 19:15:09 --> Output Class Initialized
INFO - 2023-08-16 19:15:09 --> Security Class Initialized
DEBUG - 2023-08-16 19:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:15:09 --> Input Class Initialized
INFO - 2023-08-16 19:15:09 --> Language Class Initialized
ERROR - 2023-08-16 19:15:09 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:15:09 --> Output Class Initialized
INFO - 2023-08-16 19:15:09 --> Input Class Initialized
INFO - 2023-08-16 19:15:09 --> Utf8 Class Initialized
INFO - 2023-08-16 19:15:09 --> Security Class Initialized
INFO - 2023-08-16 19:15:09 --> Language Class Initialized
ERROR - 2023-08-16 19:15:09 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:15:09 --> Config Class Initialized
INFO - 2023-08-16 19:15:09 --> URI Class Initialized
INFO - 2023-08-16 19:15:09 --> Input Class Initialized
DEBUG - 2023-08-16 19:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:15:09 --> Security Class Initialized
INFO - 2023-08-16 19:15:09 --> Router Class Initialized
INFO - 2023-08-16 19:15:09 --> Hooks Class Initialized
INFO - 2023-08-16 19:15:09 --> Language Class Initialized
DEBUG - 2023-08-16 19:15:09 --> UTF-8 Support Enabled
ERROR - 2023-08-16 19:15:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:15:10 --> Output Class Initialized
INFO - 2023-08-16 19:15:10 --> Security Class Initialized
INFO - 2023-08-16 19:15:10 --> Utf8 Class Initialized
INFO - 2023-08-16 19:15:10 --> Input Class Initialized
INFO - 2023-08-16 19:15:10 --> Config Class Initialized
DEBUG - 2023-08-16 19:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:15:10 --> Language Class Initialized
INFO - 2023-08-16 19:15:10 --> Input Class Initialized
INFO - 2023-08-16 19:15:10 --> URI Class Initialized
ERROR - 2023-08-16 19:15:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:15:10 --> Config Class Initialized
DEBUG - 2023-08-16 19:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:15:10 --> Hooks Class Initialized
INFO - 2023-08-16 19:15:10 --> Hooks Class Initialized
INFO - 2023-08-16 19:15:10 --> Language Class Initialized
DEBUG - 2023-08-16 19:15:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:15:10 --> Input Class Initialized
INFO - 2023-08-16 19:15:10 --> Language Class Initialized
ERROR - 2023-08-16 19:15:10 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:15:10 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:15:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:15:10 --> Utf8 Class Initialized
INFO - 2023-08-16 19:15:10 --> Utf8 Class Initialized
INFO - 2023-08-16 19:15:10 --> URI Class Initialized
INFO - 2023-08-16 19:15:10 --> Router Class Initialized
INFO - 2023-08-16 19:15:11 --> Output Class Initialized
INFO - 2023-08-16 19:15:11 --> Output Class Initialized
INFO - 2023-08-16 19:15:11 --> Config Class Initialized
INFO - 2023-08-16 19:15:11 --> URI Class Initialized
INFO - 2023-08-16 19:15:11 --> Config Class Initialized
INFO - 2023-08-16 19:15:11 --> Security Class Initialized
INFO - 2023-08-16 19:15:11 --> Security Class Initialized
INFO - 2023-08-16 19:15:11 --> Hooks Class Initialized
INFO - 2023-08-16 19:15:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:15:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:15:11 --> Router Class Initialized
INFO - 2023-08-16 19:15:11 --> Output Class Initialized
INFO - 2023-08-16 19:15:11 --> Security Class Initialized
DEBUG - 2023-08-16 19:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:15:11 --> Input Class Initialized
INFO - 2023-08-16 19:15:11 --> Language Class Initialized
ERROR - 2023-08-16 19:15:11 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 19:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:15:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:15:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:15:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:15:11 --> Config Class Initialized
INFO - 2023-08-16 19:15:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:15:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:15:11 --> Utf8 Class Initialized
INFO - 2023-08-16 19:15:11 --> URI Class Initialized
INFO - 2023-08-16 19:15:11 --> Router Class Initialized
INFO - 2023-08-16 19:15:11 --> Output Class Initialized
INFO - 2023-08-16 19:15:11 --> Security Class Initialized
DEBUG - 2023-08-16 19:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:15:11 --> Input Class Initialized
INFO - 2023-08-16 19:15:11 --> Language Class Initialized
ERROR - 2023-08-16 19:15:11 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:15:11 --> Input Class Initialized
INFO - 2023-08-16 19:15:11 --> Utf8 Class Initialized
INFO - 2023-08-16 19:15:11 --> Input Class Initialized
INFO - 2023-08-16 19:15:11 --> Language Class Initialized
INFO - 2023-08-16 19:15:11 --> Utf8 Class Initialized
INFO - 2023-08-16 19:15:11 --> Language Class Initialized
ERROR - 2023-08-16 19:15:12 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:15:12 --> Utf8 Class Initialized
ERROR - 2023-08-16 19:15:12 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:15:12 --> URI Class Initialized
INFO - 2023-08-16 19:15:12 --> URI Class Initialized
INFO - 2023-08-16 19:15:12 --> Router Class Initialized
INFO - 2023-08-16 19:15:12 --> Router Class Initialized
INFO - 2023-08-16 19:15:12 --> URI Class Initialized
INFO - 2023-08-16 19:15:12 --> Output Class Initialized
INFO - 2023-08-16 19:15:12 --> Router Class Initialized
INFO - 2023-08-16 19:15:12 --> Security Class Initialized
INFO - 2023-08-16 19:15:12 --> Output Class Initialized
INFO - 2023-08-16 19:15:12 --> Security Class Initialized
INFO - 2023-08-16 19:15:12 --> Output Class Initialized
DEBUG - 2023-08-16 19:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:15:12 --> Security Class Initialized
DEBUG - 2023-08-16 19:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:15:12 --> Input Class Initialized
INFO - 2023-08-16 19:15:12 --> Input Class Initialized
INFO - 2023-08-16 19:15:12 --> Language Class Initialized
INFO - 2023-08-16 19:15:12 --> Input Class Initialized
INFO - 2023-08-16 19:15:12 --> Language Class Initialized
ERROR - 2023-08-16 19:15:12 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:15:12 --> Language Class Initialized
ERROR - 2023-08-16 19:15:12 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-16 19:15:12 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:16:10 --> Config Class Initialized
INFO - 2023-08-16 19:16:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:16:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:10 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:10 --> URI Class Initialized
INFO - 2023-08-16 19:16:10 --> Router Class Initialized
INFO - 2023-08-16 19:16:10 --> Output Class Initialized
INFO - 2023-08-16 19:16:10 --> Security Class Initialized
DEBUG - 2023-08-16 19:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:11 --> Input Class Initialized
INFO - 2023-08-16 19:16:11 --> Language Class Initialized
INFO - 2023-08-16 19:16:11 --> Loader Class Initialized
INFO - 2023-08-16 19:16:11 --> Helper loaded: url_helper
INFO - 2023-08-16 19:16:11 --> Helper loaded: file_helper
INFO - 2023-08-16 19:16:11 --> Database Driver Class Initialized
INFO - 2023-08-16 19:16:11 --> Email Class Initialized
DEBUG - 2023-08-16 19:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:16:11 --> Controller Class Initialized
INFO - 2023-08-16 19:16:11 --> Model "Home_model" initialized
INFO - 2023-08-16 19:16:11 --> Helper loaded: form_helper
INFO - 2023-08-16 19:16:11 --> Form Validation Class Initialized
INFO - 2023-08-16 19:16:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:16:11 --> Final output sent to browser
DEBUG - 2023-08-16 19:16:11 --> Total execution time: 0.4949
INFO - 2023-08-16 19:16:12 --> Config Class Initialized
INFO - 2023-08-16 19:16:14 --> Hooks Class Initialized
INFO - 2023-08-16 19:16:14 --> Config Class Initialized
INFO - 2023-08-16 19:16:14 --> Config Class Initialized
INFO - 2023-08-16 19:16:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:16:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:14 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:14 --> URI Class Initialized
INFO - 2023-08-16 19:16:14 --> Router Class Initialized
INFO - 2023-08-16 19:16:14 --> Output Class Initialized
INFO - 2023-08-16 19:16:14 --> Security Class Initialized
DEBUG - 2023-08-16 19:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:14 --> Input Class Initialized
INFO - 2023-08-16 19:16:14 --> Language Class Initialized
ERROR - 2023-08-16 19:16:14 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:16:14 --> Config Class Initialized
INFO - 2023-08-16 19:16:15 --> Config Class Initialized
INFO - 2023-08-16 19:16:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:16:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:15 --> URI Class Initialized
INFO - 2023-08-16 19:16:15 --> Router Class Initialized
INFO - 2023-08-16 19:16:15 --> Output Class Initialized
INFO - 2023-08-16 19:16:15 --> Security Class Initialized
DEBUG - 2023-08-16 19:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:15 --> Input Class Initialized
INFO - 2023-08-16 19:16:15 --> Language Class Initialized
INFO - 2023-08-16 19:16:15 --> Config Class Initialized
INFO - 2023-08-16 19:16:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:16:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:15 --> URI Class Initialized
INFO - 2023-08-16 19:16:15 --> Router Class Initialized
INFO - 2023-08-16 19:16:15 --> Output Class Initialized
INFO - 2023-08-16 19:16:15 --> Security Class Initialized
DEBUG - 2023-08-16 19:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:15 --> Input Class Initialized
INFO - 2023-08-16 19:16:15 --> Language Class Initialized
ERROR - 2023-08-16 19:16:15 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:16:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:16:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:15 --> Config Class Initialized
INFO - 2023-08-16 19:16:16 --> Hooks Class Initialized
ERROR - 2023-08-16 19:16:16 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:16:16 --> Config Class Initialized
INFO - 2023-08-16 19:16:16 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:16 --> URI Class Initialized
INFO - 2023-08-16 19:16:16 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:16:16 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:16 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:16 --> URI Class Initialized
INFO - 2023-08-16 19:16:16 --> Router Class Initialized
INFO - 2023-08-16 19:16:16 --> Output Class Initialized
INFO - 2023-08-16 19:16:16 --> Security Class Initialized
DEBUG - 2023-08-16 19:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:16 --> Input Class Initialized
INFO - 2023-08-16 19:16:16 --> Language Class Initialized
ERROR - 2023-08-16 19:16:16 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:16:16 --> Router Class Initialized
INFO - 2023-08-16 19:16:16 --> Output Class Initialized
INFO - 2023-08-16 19:16:17 --> Security Class Initialized
INFO - 2023-08-16 19:16:17 --> Hooks Class Initialized
INFO - 2023-08-16 19:16:17 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:17 --> URI Class Initialized
DEBUG - 2023-08-16 19:16:17 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:17 --> Config Class Initialized
DEBUG - 2023-08-16 19:16:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:17 --> Router Class Initialized
INFO - 2023-08-16 19:16:17 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:17 --> Config Class Initialized
INFO - 2023-08-16 19:16:17 --> Input Class Initialized
INFO - 2023-08-16 19:16:17 --> Output Class Initialized
INFO - 2023-08-16 19:16:17 --> Hooks Class Initialized
INFO - 2023-08-16 19:16:17 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:17 --> URI Class Initialized
INFO - 2023-08-16 19:16:17 --> Security Class Initialized
INFO - 2023-08-16 19:16:17 --> Language Class Initialized
INFO - 2023-08-16 19:16:17 --> URI Class Initialized
DEBUG - 2023-08-16 19:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:17 --> Input Class Initialized
INFO - 2023-08-16 19:16:17 --> Language Class Initialized
ERROR - 2023-08-16 19:16:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:16:17 --> Hooks Class Initialized
INFO - 2023-08-16 19:16:17 --> Router Class Initialized
ERROR - 2023-08-16 19:16:17 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:16:17 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:18 --> Config Class Initialized
INFO - 2023-08-16 19:16:19 --> Hooks Class Initialized
INFO - 2023-08-16 19:16:19 --> Config Class Initialized
DEBUG - 2023-08-16 19:16:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:19 --> Hooks Class Initialized
INFO - 2023-08-16 19:16:19 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:19 --> URI Class Initialized
DEBUG - 2023-08-16 19:16:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:19 --> Router Class Initialized
INFO - 2023-08-16 19:16:19 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:19 --> Output Class Initialized
INFO - 2023-08-16 19:16:19 --> URI Class Initialized
INFO - 2023-08-16 19:16:19 --> Security Class Initialized
INFO - 2023-08-16 19:16:19 --> Router Class Initialized
DEBUG - 2023-08-16 19:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:19 --> Output Class Initialized
INFO - 2023-08-16 19:16:19 --> Input Class Initialized
INFO - 2023-08-16 19:16:19 --> Security Class Initialized
INFO - 2023-08-16 19:16:19 --> Language Class Initialized
DEBUG - 2023-08-16 19:16:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 19:16:19 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:16:19 --> Input Class Initialized
INFO - 2023-08-16 19:16:19 --> Language Class Initialized
ERROR - 2023-08-16 19:16:19 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:16:43 --> Config Class Initialized
INFO - 2023-08-16 19:16:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:16:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:43 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:43 --> URI Class Initialized
INFO - 2023-08-16 19:16:43 --> Router Class Initialized
INFO - 2023-08-16 19:16:43 --> Output Class Initialized
INFO - 2023-08-16 19:16:43 --> Security Class Initialized
DEBUG - 2023-08-16 19:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:43 --> Input Class Initialized
INFO - 2023-08-16 19:16:43 --> Language Class Initialized
INFO - 2023-08-16 19:16:43 --> Loader Class Initialized
INFO - 2023-08-16 19:16:43 --> Helper loaded: url_helper
INFO - 2023-08-16 19:16:43 --> Helper loaded: file_helper
INFO - 2023-08-16 19:16:43 --> Database Driver Class Initialized
INFO - 2023-08-16 19:16:43 --> Email Class Initialized
DEBUG - 2023-08-16 19:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:16:43 --> Controller Class Initialized
INFO - 2023-08-16 19:16:43 --> Model "Home_model" initialized
INFO - 2023-08-16 19:16:43 --> Helper loaded: form_helper
INFO - 2023-08-16 19:16:43 --> Form Validation Class Initialized
INFO - 2023-08-16 19:16:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:16:43 --> Final output sent to browser
DEBUG - 2023-08-16 19:16:44 --> Total execution time: 0.4323
INFO - 2023-08-16 19:16:44 --> Config Class Initialized
INFO - 2023-08-16 19:16:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:16:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:44 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:44 --> URI Class Initialized
INFO - 2023-08-16 19:16:44 --> Router Class Initialized
INFO - 2023-08-16 19:16:44 --> Output Class Initialized
INFO - 2023-08-16 19:16:44 --> Security Class Initialized
DEBUG - 2023-08-16 19:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:44 --> Input Class Initialized
INFO - 2023-08-16 19:16:44 --> Language Class Initialized
ERROR - 2023-08-16 19:16:44 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:16:44 --> Config Class Initialized
INFO - 2023-08-16 19:16:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:16:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:44 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:44 --> URI Class Initialized
INFO - 2023-08-16 19:16:44 --> Router Class Initialized
INFO - 2023-08-16 19:16:44 --> Output Class Initialized
INFO - 2023-08-16 19:16:44 --> Security Class Initialized
DEBUG - 2023-08-16 19:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:44 --> Input Class Initialized
INFO - 2023-08-16 19:16:44 --> Language Class Initialized
ERROR - 2023-08-16 19:16:44 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:16:45 --> Config Class Initialized
INFO - 2023-08-16 19:16:46 --> Config Class Initialized
INFO - 2023-08-16 19:16:46 --> Hooks Class Initialized
INFO - 2023-08-16 19:16:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:16:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:16:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:46 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:47 --> Config Class Initialized
INFO - 2023-08-16 19:16:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:16:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:48 --> URI Class Initialized
INFO - 2023-08-16 19:16:48 --> Router Class Initialized
INFO - 2023-08-16 19:16:48 --> Output Class Initialized
INFO - 2023-08-16 19:16:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:48 --> Input Class Initialized
INFO - 2023-08-16 19:16:48 --> Language Class Initialized
ERROR - 2023-08-16 19:16:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:16:48 --> Config Class Initialized
INFO - 2023-08-16 19:16:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:16:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:48 --> URI Class Initialized
INFO - 2023-08-16 19:16:48 --> Router Class Initialized
INFO - 2023-08-16 19:16:48 --> Output Class Initialized
INFO - 2023-08-16 19:16:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:48 --> Input Class Initialized
INFO - 2023-08-16 19:16:48 --> Language Class Initialized
ERROR - 2023-08-16 19:16:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:16:49 --> Config Class Initialized
INFO - 2023-08-16 19:16:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:16:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:49 --> URI Class Initialized
INFO - 2023-08-16 19:16:49 --> Router Class Initialized
INFO - 2023-08-16 19:16:49 --> Output Class Initialized
INFO - 2023-08-16 19:16:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:49 --> Input Class Initialized
INFO - 2023-08-16 19:16:49 --> Language Class Initialized
ERROR - 2023-08-16 19:16:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:16:49 --> Config Class Initialized
INFO - 2023-08-16 19:16:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:16:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:16:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:16:49 --> URI Class Initialized
INFO - 2023-08-16 19:16:49 --> Router Class Initialized
INFO - 2023-08-16 19:16:49 --> Output Class Initialized
INFO - 2023-08-16 19:16:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:16:49 --> Input Class Initialized
INFO - 2023-08-16 19:16:49 --> Language Class Initialized
ERROR - 2023-08-16 19:16:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:07 --> Config Class Initialized
INFO - 2023-08-16 19:17:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:07 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:07 --> URI Class Initialized
INFO - 2023-08-16 19:17:07 --> Router Class Initialized
INFO - 2023-08-16 19:17:07 --> Output Class Initialized
INFO - 2023-08-16 19:17:07 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:07 --> Input Class Initialized
INFO - 2023-08-16 19:17:07 --> Language Class Initialized
INFO - 2023-08-16 19:17:07 --> Loader Class Initialized
INFO - 2023-08-16 19:17:07 --> Helper loaded: url_helper
INFO - 2023-08-16 19:17:07 --> Helper loaded: file_helper
INFO - 2023-08-16 19:17:07 --> Database Driver Class Initialized
INFO - 2023-08-16 19:17:08 --> Email Class Initialized
DEBUG - 2023-08-16 19:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:17:08 --> Controller Class Initialized
INFO - 2023-08-16 19:17:08 --> Model "Home_model" initialized
INFO - 2023-08-16 19:17:08 --> Helper loaded: form_helper
INFO - 2023-08-16 19:17:08 --> Form Validation Class Initialized
INFO - 2023-08-16 19:17:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:17:08 --> Final output sent to browser
DEBUG - 2023-08-16 19:17:08 --> Total execution time: 0.4353
INFO - 2023-08-16 19:17:08 --> Config Class Initialized
INFO - 2023-08-16 19:17:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:08 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:08 --> URI Class Initialized
INFO - 2023-08-16 19:17:08 --> Router Class Initialized
INFO - 2023-08-16 19:17:08 --> Output Class Initialized
INFO - 2023-08-16 19:17:08 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:08 --> Input Class Initialized
INFO - 2023-08-16 19:17:08 --> Language Class Initialized
ERROR - 2023-08-16 19:17:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:09 --> Config Class Initialized
INFO - 2023-08-16 19:17:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:09 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:09 --> URI Class Initialized
INFO - 2023-08-16 19:17:09 --> Router Class Initialized
INFO - 2023-08-16 19:17:09 --> Output Class Initialized
INFO - 2023-08-16 19:17:09 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:09 --> Input Class Initialized
INFO - 2023-08-16 19:17:09 --> Language Class Initialized
ERROR - 2023-08-16 19:17:09 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:09 --> Config Class Initialized
INFO - 2023-08-16 19:17:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:09 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:09 --> URI Class Initialized
INFO - 2023-08-16 19:17:09 --> Router Class Initialized
INFO - 2023-08-16 19:17:09 --> Output Class Initialized
INFO - 2023-08-16 19:17:09 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:09 --> Input Class Initialized
INFO - 2023-08-16 19:17:09 --> Language Class Initialized
ERROR - 2023-08-16 19:17:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:17:09 --> Config Class Initialized
INFO - 2023-08-16 19:17:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:09 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:09 --> URI Class Initialized
INFO - 2023-08-16 19:17:09 --> Router Class Initialized
INFO - 2023-08-16 19:17:09 --> Output Class Initialized
INFO - 2023-08-16 19:17:09 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:09 --> Input Class Initialized
INFO - 2023-08-16 19:17:09 --> Language Class Initialized
ERROR - 2023-08-16 19:17:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:17:09 --> Config Class Initialized
INFO - 2023-08-16 19:17:09 --> Config Class Initialized
INFO - 2023-08-16 19:17:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:09 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:09 --> URI Class Initialized
INFO - 2023-08-16 19:17:09 --> Router Class Initialized
INFO - 2023-08-16 19:17:09 --> Output Class Initialized
INFO - 2023-08-16 19:17:09 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:09 --> Input Class Initialized
INFO - 2023-08-16 19:17:09 --> Language Class Initialized
ERROR - 2023-08-16 19:17:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:17:09 --> Config Class Initialized
INFO - 2023-08-16 19:17:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:09 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:09 --> URI Class Initialized
INFO - 2023-08-16 19:17:09 --> Router Class Initialized
INFO - 2023-08-16 19:17:09 --> Output Class Initialized
INFO - 2023-08-16 19:17:09 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:09 --> Input Class Initialized
INFO - 2023-08-16 19:17:09 --> Language Class Initialized
ERROR - 2023-08-16 19:17:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:17:09 --> Hooks Class Initialized
INFO - 2023-08-16 19:17:09 --> Config Class Initialized
INFO - 2023-08-16 19:17:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:09 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:09 --> URI Class Initialized
INFO - 2023-08-16 19:17:09 --> Router Class Initialized
INFO - 2023-08-16 19:17:09 --> Output Class Initialized
INFO - 2023-08-16 19:17:09 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:09 --> Input Class Initialized
INFO - 2023-08-16 19:17:09 --> Language Class Initialized
ERROR - 2023-08-16 19:17:09 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 19:17:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:10 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:10 --> URI Class Initialized
INFO - 2023-08-16 19:17:10 --> Router Class Initialized
INFO - 2023-08-16 19:17:10 --> Config Class Initialized
INFO - 2023-08-16 19:17:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:10 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:10 --> URI Class Initialized
INFO - 2023-08-16 19:17:10 --> Router Class Initialized
INFO - 2023-08-16 19:17:10 --> Output Class Initialized
INFO - 2023-08-16 19:17:10 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:10 --> Input Class Initialized
INFO - 2023-08-16 19:17:10 --> Language Class Initialized
ERROR - 2023-08-16 19:17:10 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:17:10 --> Config Class Initialized
INFO - 2023-08-16 19:17:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:10 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:10 --> URI Class Initialized
INFO - 2023-08-16 19:17:10 --> Router Class Initialized
INFO - 2023-08-16 19:17:10 --> Output Class Initialized
INFO - 2023-08-16 19:17:10 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:10 --> Input Class Initialized
INFO - 2023-08-16 19:17:10 --> Language Class Initialized
ERROR - 2023-08-16 19:17:10 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:17:10 --> Config Class Initialized
INFO - 2023-08-16 19:17:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:10 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:10 --> URI Class Initialized
INFO - 2023-08-16 19:17:10 --> Router Class Initialized
INFO - 2023-08-16 19:17:10 --> Output Class Initialized
INFO - 2023-08-16 19:17:10 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:10 --> Input Class Initialized
INFO - 2023-08-16 19:17:10 --> Language Class Initialized
ERROR - 2023-08-16 19:17:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:10 --> Output Class Initialized
INFO - 2023-08-16 19:17:10 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:11 --> Input Class Initialized
INFO - 2023-08-16 19:17:11 --> Language Class Initialized
ERROR - 2023-08-16 19:17:11 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:11 --> Config Class Initialized
INFO - 2023-08-16 19:17:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:11 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:11 --> URI Class Initialized
INFO - 2023-08-16 19:17:11 --> Router Class Initialized
INFO - 2023-08-16 19:17:11 --> Output Class Initialized
INFO - 2023-08-16 19:17:11 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:11 --> Input Class Initialized
INFO - 2023-08-16 19:17:11 --> Language Class Initialized
ERROR - 2023-08-16 19:17:11 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:11 --> Config Class Initialized
INFO - 2023-08-16 19:17:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:11 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:11 --> URI Class Initialized
INFO - 2023-08-16 19:17:11 --> Router Class Initialized
INFO - 2023-08-16 19:17:11 --> Output Class Initialized
INFO - 2023-08-16 19:17:11 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:11 --> Input Class Initialized
INFO - 2023-08-16 19:17:11 --> Language Class Initialized
ERROR - 2023-08-16 19:17:11 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:12 --> Config Class Initialized
INFO - 2023-08-16 19:17:12 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:12 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:13 --> URI Class Initialized
INFO - 2023-08-16 19:17:13 --> Router Class Initialized
INFO - 2023-08-16 19:17:13 --> Output Class Initialized
INFO - 2023-08-16 19:17:13 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:13 --> Input Class Initialized
INFO - 2023-08-16 19:17:13 --> Language Class Initialized
ERROR - 2023-08-16 19:17:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:39 --> Config Class Initialized
INFO - 2023-08-16 19:17:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:39 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:39 --> URI Class Initialized
INFO - 2023-08-16 19:17:39 --> Router Class Initialized
INFO - 2023-08-16 19:17:40 --> Output Class Initialized
INFO - 2023-08-16 19:17:40 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:40 --> Input Class Initialized
INFO - 2023-08-16 19:17:40 --> Language Class Initialized
INFO - 2023-08-16 19:17:40 --> Loader Class Initialized
INFO - 2023-08-16 19:17:40 --> Helper loaded: url_helper
INFO - 2023-08-16 19:17:40 --> Helper loaded: file_helper
INFO - 2023-08-16 19:17:40 --> Database Driver Class Initialized
INFO - 2023-08-16 19:17:40 --> Email Class Initialized
DEBUG - 2023-08-16 19:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:17:40 --> Controller Class Initialized
INFO - 2023-08-16 19:17:40 --> Model "Home_model" initialized
INFO - 2023-08-16 19:17:40 --> Helper loaded: form_helper
INFO - 2023-08-16 19:17:40 --> Form Validation Class Initialized
INFO - 2023-08-16 19:17:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:17:40 --> Final output sent to browser
DEBUG - 2023-08-16 19:17:40 --> Total execution time: 0.9489
INFO - 2023-08-16 19:17:41 --> Config Class Initialized
INFO - 2023-08-16 19:17:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:41 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:41 --> URI Class Initialized
INFO - 2023-08-16 19:17:41 --> Router Class Initialized
INFO - 2023-08-16 19:17:41 --> Output Class Initialized
INFO - 2023-08-16 19:17:41 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:41 --> Input Class Initialized
INFO - 2023-08-16 19:17:41 --> Language Class Initialized
ERROR - 2023-08-16 19:17:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:41 --> Config Class Initialized
INFO - 2023-08-16 19:17:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:41 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:41 --> URI Class Initialized
INFO - 2023-08-16 19:17:41 --> Router Class Initialized
INFO - 2023-08-16 19:17:41 --> Output Class Initialized
INFO - 2023-08-16 19:17:41 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:41 --> Input Class Initialized
INFO - 2023-08-16 19:17:41 --> Language Class Initialized
ERROR - 2023-08-16 19:17:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:17:42 --> Config Class Initialized
INFO - 2023-08-16 19:17:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:42 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:42 --> Config Class Initialized
INFO - 2023-08-16 19:17:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:42 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:42 --> URI Class Initialized
INFO - 2023-08-16 19:17:42 --> Router Class Initialized
INFO - 2023-08-16 19:17:42 --> Output Class Initialized
INFO - 2023-08-16 19:17:42 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:42 --> Input Class Initialized
INFO - 2023-08-16 19:17:42 --> Language Class Initialized
ERROR - 2023-08-16 19:17:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:42 --> URI Class Initialized
INFO - 2023-08-16 19:17:42 --> Router Class Initialized
INFO - 2023-08-16 19:17:43 --> Config Class Initialized
INFO - 2023-08-16 19:17:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:43 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:43 --> URI Class Initialized
INFO - 2023-08-16 19:17:43 --> Router Class Initialized
INFO - 2023-08-16 19:17:43 --> Output Class Initialized
INFO - 2023-08-16 19:17:43 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:43 --> Input Class Initialized
INFO - 2023-08-16 19:17:43 --> Language Class Initialized
INFO - 2023-08-16 19:17:43 --> Output Class Initialized
INFO - 2023-08-16 19:17:43 --> Config Class Initialized
INFO - 2023-08-16 19:17:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:43 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:43 --> URI Class Initialized
INFO - 2023-08-16 19:17:43 --> Router Class Initialized
INFO - 2023-08-16 19:17:43 --> Output Class Initialized
INFO - 2023-08-16 19:17:43 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:43 --> Input Class Initialized
INFO - 2023-08-16 19:17:43 --> Language Class Initialized
ERROR - 2023-08-16 19:17:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:43 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 19:17:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:43 --> Input Class Initialized
INFO - 2023-08-16 19:17:43 --> Language Class Initialized
ERROR - 2023-08-16 19:17:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:43 --> Config Class Initialized
INFO - 2023-08-16 19:17:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:44 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:44 --> URI Class Initialized
INFO - 2023-08-16 19:17:44 --> Router Class Initialized
INFO - 2023-08-16 19:17:44 --> Output Class Initialized
INFO - 2023-08-16 19:17:44 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:44 --> Input Class Initialized
INFO - 2023-08-16 19:17:44 --> Language Class Initialized
ERROR - 2023-08-16 19:17:44 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:44 --> Config Class Initialized
INFO - 2023-08-16 19:17:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:44 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:44 --> URI Class Initialized
INFO - 2023-08-16 19:17:44 --> Router Class Initialized
INFO - 2023-08-16 19:17:44 --> Output Class Initialized
INFO - 2023-08-16 19:17:45 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:45 --> Input Class Initialized
INFO - 2023-08-16 19:17:45 --> Language Class Initialized
ERROR - 2023-08-16 19:17:45 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:17:45 --> Config Class Initialized
INFO - 2023-08-16 19:17:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:45 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:45 --> URI Class Initialized
INFO - 2023-08-16 19:17:45 --> Router Class Initialized
INFO - 2023-08-16 19:17:45 --> Output Class Initialized
INFO - 2023-08-16 19:17:45 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:45 --> Input Class Initialized
INFO - 2023-08-16 19:17:45 --> Language Class Initialized
ERROR - 2023-08-16 19:17:45 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:49 --> Config Class Initialized
INFO - 2023-08-16 19:17:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:49 --> URI Class Initialized
INFO - 2023-08-16 19:17:49 --> Router Class Initialized
INFO - 2023-08-16 19:17:49 --> Output Class Initialized
INFO - 2023-08-16 19:17:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:49 --> Input Class Initialized
INFO - 2023-08-16 19:17:49 --> Language Class Initialized
INFO - 2023-08-16 19:17:49 --> Loader Class Initialized
INFO - 2023-08-16 19:17:49 --> Helper loaded: url_helper
INFO - 2023-08-16 19:17:49 --> Helper loaded: file_helper
INFO - 2023-08-16 19:17:49 --> Database Driver Class Initialized
INFO - 2023-08-16 19:17:49 --> Email Class Initialized
DEBUG - 2023-08-16 19:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:17:49 --> Controller Class Initialized
INFO - 2023-08-16 19:17:49 --> Model "Home_model" initialized
INFO - 2023-08-16 19:17:49 --> Helper loaded: form_helper
INFO - 2023-08-16 19:17:49 --> Form Validation Class Initialized
INFO - 2023-08-16 19:17:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:17:49 --> Final output sent to browser
DEBUG - 2023-08-16 19:17:50 --> Total execution time: 0.1731
INFO - 2023-08-16 19:17:50 --> Config Class Initialized
INFO - 2023-08-16 19:17:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:50 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:50 --> URI Class Initialized
INFO - 2023-08-16 19:17:50 --> Router Class Initialized
INFO - 2023-08-16 19:17:50 --> Output Class Initialized
INFO - 2023-08-16 19:17:50 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:50 --> Input Class Initialized
INFO - 2023-08-16 19:17:50 --> Language Class Initialized
ERROR - 2023-08-16 19:17:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:50 --> Config Class Initialized
INFO - 2023-08-16 19:17:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:50 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:50 --> URI Class Initialized
INFO - 2023-08-16 19:17:50 --> Router Class Initialized
INFO - 2023-08-16 19:17:50 --> Output Class Initialized
INFO - 2023-08-16 19:17:50 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:50 --> Input Class Initialized
INFO - 2023-08-16 19:17:50 --> Language Class Initialized
ERROR - 2023-08-16 19:17:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:50 --> Config Class Initialized
INFO - 2023-08-16 19:17:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:50 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:50 --> URI Class Initialized
INFO - 2023-08-16 19:17:50 --> Router Class Initialized
INFO - 2023-08-16 19:17:50 --> Output Class Initialized
INFO - 2023-08-16 19:17:50 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:51 --> Input Class Initialized
INFO - 2023-08-16 19:17:51 --> Language Class Initialized
ERROR - 2023-08-16 19:17:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:51 --> Config Class Initialized
INFO - 2023-08-16 19:17:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:51 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:51 --> URI Class Initialized
INFO - 2023-08-16 19:17:51 --> Router Class Initialized
INFO - 2023-08-16 19:17:51 --> Output Class Initialized
INFO - 2023-08-16 19:17:51 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:51 --> Input Class Initialized
INFO - 2023-08-16 19:17:51 --> Language Class Initialized
ERROR - 2023-08-16 19:17:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:51 --> Config Class Initialized
INFO - 2023-08-16 19:17:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:51 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:51 --> URI Class Initialized
INFO - 2023-08-16 19:17:51 --> Router Class Initialized
INFO - 2023-08-16 19:17:51 --> Output Class Initialized
INFO - 2023-08-16 19:17:51 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:51 --> Input Class Initialized
INFO - 2023-08-16 19:17:51 --> Language Class Initialized
ERROR - 2023-08-16 19:17:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:17:51 --> Config Class Initialized
INFO - 2023-08-16 19:17:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:17:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:17:51 --> Utf8 Class Initialized
INFO - 2023-08-16 19:17:51 --> URI Class Initialized
INFO - 2023-08-16 19:17:51 --> Router Class Initialized
INFO - 2023-08-16 19:17:51 --> Output Class Initialized
INFO - 2023-08-16 19:17:51 --> Security Class Initialized
DEBUG - 2023-08-16 19:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:17:51 --> Input Class Initialized
INFO - 2023-08-16 19:17:51 --> Language Class Initialized
ERROR - 2023-08-16 19:17:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:31 --> Config Class Initialized
INFO - 2023-08-16 19:18:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:31 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:31 --> URI Class Initialized
INFO - 2023-08-16 19:18:31 --> Router Class Initialized
INFO - 2023-08-16 19:18:31 --> Output Class Initialized
INFO - 2023-08-16 19:18:31 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:31 --> Input Class Initialized
INFO - 2023-08-16 19:18:31 --> Language Class Initialized
INFO - 2023-08-16 19:18:31 --> Loader Class Initialized
INFO - 2023-08-16 19:18:31 --> Helper loaded: url_helper
INFO - 2023-08-16 19:18:31 --> Helper loaded: file_helper
INFO - 2023-08-16 19:18:31 --> Database Driver Class Initialized
INFO - 2023-08-16 19:18:31 --> Email Class Initialized
DEBUG - 2023-08-16 19:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:18:31 --> Controller Class Initialized
INFO - 2023-08-16 19:18:31 --> Model "Home_model" initialized
INFO - 2023-08-16 19:18:31 --> Helper loaded: form_helper
INFO - 2023-08-16 19:18:31 --> Form Validation Class Initialized
INFO - 2023-08-16 19:18:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:18:31 --> Final output sent to browser
DEBUG - 2023-08-16 19:18:31 --> Total execution time: 0.1591
INFO - 2023-08-16 19:18:31 --> Config Class Initialized
INFO - 2023-08-16 19:18:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:31 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:31 --> URI Class Initialized
INFO - 2023-08-16 19:18:31 --> Router Class Initialized
INFO - 2023-08-16 19:18:31 --> Output Class Initialized
INFO - 2023-08-16 19:18:31 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:31 --> Input Class Initialized
INFO - 2023-08-16 19:18:31 --> Language Class Initialized
ERROR - 2023-08-16 19:18:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:31 --> Config Class Initialized
INFO - 2023-08-16 19:18:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:31 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:31 --> URI Class Initialized
INFO - 2023-08-16 19:18:31 --> Router Class Initialized
INFO - 2023-08-16 19:18:31 --> Output Class Initialized
INFO - 2023-08-16 19:18:31 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:31 --> Input Class Initialized
INFO - 2023-08-16 19:18:31 --> Language Class Initialized
ERROR - 2023-08-16 19:18:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:31 --> Config Class Initialized
INFO - 2023-08-16 19:18:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:31 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:31 --> URI Class Initialized
INFO - 2023-08-16 19:18:31 --> Router Class Initialized
INFO - 2023-08-16 19:18:31 --> Output Class Initialized
INFO - 2023-08-16 19:18:31 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:31 --> Input Class Initialized
INFO - 2023-08-16 19:18:31 --> Language Class Initialized
ERROR - 2023-08-16 19:18:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:31 --> Config Class Initialized
INFO - 2023-08-16 19:18:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:31 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:31 --> URI Class Initialized
INFO - 2023-08-16 19:18:31 --> Router Class Initialized
INFO - 2023-08-16 19:18:31 --> Output Class Initialized
INFO - 2023-08-16 19:18:31 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:31 --> Input Class Initialized
INFO - 2023-08-16 19:18:31 --> Language Class Initialized
ERROR - 2023-08-16 19:18:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:32 --> Config Class Initialized
INFO - 2023-08-16 19:18:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:32 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:32 --> URI Class Initialized
INFO - 2023-08-16 19:18:32 --> Router Class Initialized
INFO - 2023-08-16 19:18:32 --> Output Class Initialized
INFO - 2023-08-16 19:18:32 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:32 --> Input Class Initialized
INFO - 2023-08-16 19:18:32 --> Language Class Initialized
ERROR - 2023-08-16 19:18:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:33 --> Config Class Initialized
INFO - 2023-08-16 19:18:33 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:33 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:33 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:33 --> URI Class Initialized
INFO - 2023-08-16 19:18:33 --> Router Class Initialized
INFO - 2023-08-16 19:18:33 --> Output Class Initialized
INFO - 2023-08-16 19:18:33 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:33 --> Input Class Initialized
INFO - 2023-08-16 19:18:33 --> Language Class Initialized
ERROR - 2023-08-16 19:18:33 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:53 --> Config Class Initialized
INFO - 2023-08-16 19:18:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:53 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:53 --> URI Class Initialized
INFO - 2023-08-16 19:18:53 --> Router Class Initialized
INFO - 2023-08-16 19:18:53 --> Output Class Initialized
INFO - 2023-08-16 19:18:53 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:53 --> Input Class Initialized
INFO - 2023-08-16 19:18:53 --> Language Class Initialized
INFO - 2023-08-16 19:18:53 --> Loader Class Initialized
INFO - 2023-08-16 19:18:53 --> Helper loaded: url_helper
INFO - 2023-08-16 19:18:53 --> Helper loaded: file_helper
INFO - 2023-08-16 19:18:53 --> Database Driver Class Initialized
INFO - 2023-08-16 19:18:53 --> Email Class Initialized
DEBUG - 2023-08-16 19:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:18:53 --> Controller Class Initialized
INFO - 2023-08-16 19:18:53 --> Model "Home_model" initialized
INFO - 2023-08-16 19:18:53 --> Helper loaded: form_helper
INFO - 2023-08-16 19:18:53 --> Form Validation Class Initialized
INFO - 2023-08-16 19:18:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:18:53 --> Final output sent to browser
DEBUG - 2023-08-16 19:18:54 --> Total execution time: 0.2165
INFO - 2023-08-16 19:18:54 --> Config Class Initialized
INFO - 2023-08-16 19:18:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:54 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:54 --> URI Class Initialized
INFO - 2023-08-16 19:18:54 --> Router Class Initialized
INFO - 2023-08-16 19:18:54 --> Output Class Initialized
INFO - 2023-08-16 19:18:54 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:54 --> Input Class Initialized
INFO - 2023-08-16 19:18:54 --> Language Class Initialized
ERROR - 2023-08-16 19:18:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:54 --> Config Class Initialized
INFO - 2023-08-16 19:18:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:54 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:54 --> URI Class Initialized
INFO - 2023-08-16 19:18:54 --> Router Class Initialized
INFO - 2023-08-16 19:18:54 --> Output Class Initialized
INFO - 2023-08-16 19:18:54 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:54 --> Input Class Initialized
INFO - 2023-08-16 19:18:54 --> Language Class Initialized
ERROR - 2023-08-16 19:18:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:54 --> Config Class Initialized
INFO - 2023-08-16 19:18:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:54 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:54 --> URI Class Initialized
INFO - 2023-08-16 19:18:54 --> Router Class Initialized
INFO - 2023-08-16 19:18:54 --> Output Class Initialized
INFO - 2023-08-16 19:18:54 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:54 --> Input Class Initialized
INFO - 2023-08-16 19:18:55 --> Language Class Initialized
ERROR - 2023-08-16 19:18:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:55 --> Config Class Initialized
INFO - 2023-08-16 19:18:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:55 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:55 --> URI Class Initialized
INFO - 2023-08-16 19:18:55 --> Router Class Initialized
INFO - 2023-08-16 19:18:55 --> Output Class Initialized
INFO - 2023-08-16 19:18:55 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:55 --> Input Class Initialized
INFO - 2023-08-16 19:18:55 --> Language Class Initialized
ERROR - 2023-08-16 19:18:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:55 --> Config Class Initialized
INFO - 2023-08-16 19:18:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:55 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:55 --> URI Class Initialized
INFO - 2023-08-16 19:18:55 --> Router Class Initialized
INFO - 2023-08-16 19:18:55 --> Output Class Initialized
INFO - 2023-08-16 19:18:55 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:55 --> Input Class Initialized
INFO - 2023-08-16 19:18:55 --> Language Class Initialized
ERROR - 2023-08-16 19:18:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:55 --> Config Class Initialized
INFO - 2023-08-16 19:18:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:55 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:55 --> URI Class Initialized
INFO - 2023-08-16 19:18:55 --> Router Class Initialized
INFO - 2023-08-16 19:18:55 --> Output Class Initialized
INFO - 2023-08-16 19:18:55 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:55 --> Input Class Initialized
INFO - 2023-08-16 19:18:55 --> Language Class Initialized
ERROR - 2023-08-16 19:18:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:58 --> Config Class Initialized
INFO - 2023-08-16 19:18:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:58 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:58 --> URI Class Initialized
INFO - 2023-08-16 19:18:58 --> Router Class Initialized
INFO - 2023-08-16 19:18:58 --> Output Class Initialized
INFO - 2023-08-16 19:18:58 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:58 --> Input Class Initialized
INFO - 2023-08-16 19:18:58 --> Language Class Initialized
INFO - 2023-08-16 19:18:58 --> Loader Class Initialized
INFO - 2023-08-16 19:18:58 --> Helper loaded: url_helper
INFO - 2023-08-16 19:18:58 --> Helper loaded: file_helper
INFO - 2023-08-16 19:18:58 --> Database Driver Class Initialized
INFO - 2023-08-16 19:18:58 --> Email Class Initialized
DEBUG - 2023-08-16 19:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:18:58 --> Controller Class Initialized
INFO - 2023-08-16 19:18:58 --> Model "Home_model" initialized
INFO - 2023-08-16 19:18:58 --> Helper loaded: form_helper
INFO - 2023-08-16 19:18:58 --> Form Validation Class Initialized
INFO - 2023-08-16 19:18:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:18:58 --> Final output sent to browser
DEBUG - 2023-08-16 19:18:58 --> Total execution time: 0.0520
INFO - 2023-08-16 19:18:58 --> Config Class Initialized
INFO - 2023-08-16 19:18:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:58 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:58 --> URI Class Initialized
INFO - 2023-08-16 19:18:58 --> Router Class Initialized
INFO - 2023-08-16 19:18:58 --> Output Class Initialized
INFO - 2023-08-16 19:18:58 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:58 --> Input Class Initialized
INFO - 2023-08-16 19:18:58 --> Language Class Initialized
ERROR - 2023-08-16 19:18:58 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:58 --> Config Class Initialized
INFO - 2023-08-16 19:18:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:58 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:58 --> URI Class Initialized
INFO - 2023-08-16 19:18:58 --> Router Class Initialized
INFO - 2023-08-16 19:18:58 --> Output Class Initialized
INFO - 2023-08-16 19:18:58 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:58 --> Input Class Initialized
INFO - 2023-08-16 19:18:58 --> Language Class Initialized
ERROR - 2023-08-16 19:18:58 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:58 --> Config Class Initialized
INFO - 2023-08-16 19:18:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:58 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:58 --> URI Class Initialized
INFO - 2023-08-16 19:18:58 --> Router Class Initialized
INFO - 2023-08-16 19:18:58 --> Output Class Initialized
INFO - 2023-08-16 19:18:58 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:58 --> Input Class Initialized
INFO - 2023-08-16 19:18:58 --> Language Class Initialized
ERROR - 2023-08-16 19:18:58 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:59 --> Config Class Initialized
INFO - 2023-08-16 19:18:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:59 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:59 --> URI Class Initialized
INFO - 2023-08-16 19:18:59 --> Router Class Initialized
INFO - 2023-08-16 19:18:59 --> Output Class Initialized
INFO - 2023-08-16 19:18:59 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:59 --> Input Class Initialized
INFO - 2023-08-16 19:18:59 --> Language Class Initialized
ERROR - 2023-08-16 19:18:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:59 --> Config Class Initialized
INFO - 2023-08-16 19:18:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:59 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:59 --> URI Class Initialized
INFO - 2023-08-16 19:18:59 --> Router Class Initialized
INFO - 2023-08-16 19:18:59 --> Output Class Initialized
INFO - 2023-08-16 19:18:59 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:59 --> Input Class Initialized
INFO - 2023-08-16 19:18:59 --> Language Class Initialized
ERROR - 2023-08-16 19:18:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:18:59 --> Config Class Initialized
INFO - 2023-08-16 19:18:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:18:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:18:59 --> Utf8 Class Initialized
INFO - 2023-08-16 19:18:59 --> URI Class Initialized
INFO - 2023-08-16 19:18:59 --> Router Class Initialized
INFO - 2023-08-16 19:18:59 --> Output Class Initialized
INFO - 2023-08-16 19:18:59 --> Security Class Initialized
DEBUG - 2023-08-16 19:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:18:59 --> Input Class Initialized
INFO - 2023-08-16 19:18:59 --> Language Class Initialized
ERROR - 2023-08-16 19:18:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:21:01 --> Config Class Initialized
INFO - 2023-08-16 19:21:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:21:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:21:01 --> Utf8 Class Initialized
INFO - 2023-08-16 19:21:01 --> URI Class Initialized
INFO - 2023-08-16 19:21:01 --> Router Class Initialized
INFO - 2023-08-16 19:21:01 --> Output Class Initialized
INFO - 2023-08-16 19:21:01 --> Security Class Initialized
DEBUG - 2023-08-16 19:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:21:01 --> Input Class Initialized
INFO - 2023-08-16 19:21:01 --> Language Class Initialized
INFO - 2023-08-16 19:21:01 --> Loader Class Initialized
INFO - 2023-08-16 19:21:01 --> Helper loaded: url_helper
INFO - 2023-08-16 19:21:01 --> Helper loaded: file_helper
INFO - 2023-08-16 19:21:01 --> Database Driver Class Initialized
INFO - 2023-08-16 19:21:01 --> Email Class Initialized
DEBUG - 2023-08-16 19:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:21:01 --> Controller Class Initialized
INFO - 2023-08-16 19:21:01 --> Model "Home_model" initialized
INFO - 2023-08-16 19:21:01 --> Helper loaded: form_helper
INFO - 2023-08-16 19:21:01 --> Form Validation Class Initialized
INFO - 2023-08-16 19:21:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:21:01 --> Final output sent to browser
DEBUG - 2023-08-16 19:21:01 --> Total execution time: 0.5095
INFO - 2023-08-16 19:21:01 --> Config Class Initialized
INFO - 2023-08-16 19:21:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:21:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:21:01 --> Utf8 Class Initialized
INFO - 2023-08-16 19:21:01 --> URI Class Initialized
INFO - 2023-08-16 19:21:01 --> Router Class Initialized
INFO - 2023-08-16 19:21:01 --> Output Class Initialized
INFO - 2023-08-16 19:21:01 --> Security Class Initialized
DEBUG - 2023-08-16 19:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:21:01 --> Input Class Initialized
INFO - 2023-08-16 19:21:01 --> Language Class Initialized
ERROR - 2023-08-16 19:21:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:21:01 --> Config Class Initialized
INFO - 2023-08-16 19:21:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:21:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:21:01 --> Utf8 Class Initialized
INFO - 2023-08-16 19:21:01 --> URI Class Initialized
INFO - 2023-08-16 19:21:01 --> Router Class Initialized
INFO - 2023-08-16 19:21:01 --> Output Class Initialized
INFO - 2023-08-16 19:21:01 --> Security Class Initialized
DEBUG - 2023-08-16 19:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:21:01 --> Input Class Initialized
INFO - 2023-08-16 19:21:01 --> Language Class Initialized
ERROR - 2023-08-16 19:21:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:21:02 --> Config Class Initialized
INFO - 2023-08-16 19:21:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:21:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:21:02 --> Utf8 Class Initialized
INFO - 2023-08-16 19:21:02 --> URI Class Initialized
INFO - 2023-08-16 19:21:02 --> Router Class Initialized
INFO - 2023-08-16 19:21:02 --> Output Class Initialized
INFO - 2023-08-16 19:21:02 --> Security Class Initialized
DEBUG - 2023-08-16 19:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:21:02 --> Input Class Initialized
INFO - 2023-08-16 19:21:02 --> Language Class Initialized
ERROR - 2023-08-16 19:21:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:21:03 --> Config Class Initialized
INFO - 2023-08-16 19:21:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:21:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:21:03 --> Utf8 Class Initialized
INFO - 2023-08-16 19:21:03 --> URI Class Initialized
INFO - 2023-08-16 19:21:03 --> Router Class Initialized
INFO - 2023-08-16 19:21:03 --> Output Class Initialized
INFO - 2023-08-16 19:21:03 --> Security Class Initialized
DEBUG - 2023-08-16 19:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:21:03 --> Input Class Initialized
INFO - 2023-08-16 19:21:03 --> Language Class Initialized
ERROR - 2023-08-16 19:21:03 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:21:03 --> Config Class Initialized
INFO - 2023-08-16 19:21:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:21:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:21:03 --> Utf8 Class Initialized
INFO - 2023-08-16 19:21:03 --> URI Class Initialized
INFO - 2023-08-16 19:21:03 --> Router Class Initialized
INFO - 2023-08-16 19:21:03 --> Output Class Initialized
INFO - 2023-08-16 19:21:03 --> Security Class Initialized
DEBUG - 2023-08-16 19:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:21:03 --> Input Class Initialized
INFO - 2023-08-16 19:21:03 --> Language Class Initialized
ERROR - 2023-08-16 19:21:03 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:21:03 --> Config Class Initialized
INFO - 2023-08-16 19:21:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:21:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:21:03 --> Utf8 Class Initialized
INFO - 2023-08-16 19:21:03 --> URI Class Initialized
INFO - 2023-08-16 19:21:03 --> Router Class Initialized
INFO - 2023-08-16 19:21:03 --> Output Class Initialized
INFO - 2023-08-16 19:21:03 --> Security Class Initialized
DEBUG - 2023-08-16 19:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:21:03 --> Input Class Initialized
INFO - 2023-08-16 19:21:03 --> Language Class Initialized
ERROR - 2023-08-16 19:21:03 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:21:48 --> Config Class Initialized
INFO - 2023-08-16 19:21:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:21:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:21:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:21:48 --> URI Class Initialized
INFO - 2023-08-16 19:21:48 --> Router Class Initialized
INFO - 2023-08-16 19:21:48 --> Output Class Initialized
INFO - 2023-08-16 19:21:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:21:48 --> Input Class Initialized
INFO - 2023-08-16 19:21:48 --> Language Class Initialized
INFO - 2023-08-16 19:21:48 --> Loader Class Initialized
INFO - 2023-08-16 19:21:48 --> Helper loaded: url_helper
INFO - 2023-08-16 19:21:48 --> Helper loaded: file_helper
INFO - 2023-08-16 19:21:48 --> Database Driver Class Initialized
INFO - 2023-08-16 19:21:48 --> Email Class Initialized
DEBUG - 2023-08-16 19:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:21:48 --> Controller Class Initialized
INFO - 2023-08-16 19:21:48 --> Model "Home_model" initialized
INFO - 2023-08-16 19:21:48 --> Helper loaded: form_helper
INFO - 2023-08-16 19:21:48 --> Form Validation Class Initialized
INFO - 2023-08-16 19:21:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:21:48 --> Final output sent to browser
DEBUG - 2023-08-16 19:21:48 --> Total execution time: 0.1730
INFO - 2023-08-16 19:21:49 --> Config Class Initialized
INFO - 2023-08-16 19:21:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:21:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:21:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:21:49 --> URI Class Initialized
INFO - 2023-08-16 19:21:49 --> Router Class Initialized
INFO - 2023-08-16 19:21:49 --> Output Class Initialized
INFO - 2023-08-16 19:21:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:21:49 --> Input Class Initialized
INFO - 2023-08-16 19:21:49 --> Language Class Initialized
ERROR - 2023-08-16 19:21:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:21:49 --> Config Class Initialized
INFO - 2023-08-16 19:21:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:21:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:21:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:21:49 --> URI Class Initialized
INFO - 2023-08-16 19:21:49 --> Router Class Initialized
INFO - 2023-08-16 19:21:49 --> Output Class Initialized
INFO - 2023-08-16 19:21:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:21:49 --> Input Class Initialized
INFO - 2023-08-16 19:21:49 --> Language Class Initialized
ERROR - 2023-08-16 19:21:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:21:49 --> Config Class Initialized
INFO - 2023-08-16 19:21:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:21:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:21:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:21:49 --> URI Class Initialized
INFO - 2023-08-16 19:21:49 --> Router Class Initialized
INFO - 2023-08-16 19:21:49 --> Output Class Initialized
INFO - 2023-08-16 19:21:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:21:49 --> Input Class Initialized
INFO - 2023-08-16 19:21:49 --> Language Class Initialized
ERROR - 2023-08-16 19:21:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:21:49 --> Config Class Initialized
INFO - 2023-08-16 19:21:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:21:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:21:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:21:49 --> URI Class Initialized
INFO - 2023-08-16 19:21:49 --> Router Class Initialized
INFO - 2023-08-16 19:21:49 --> Output Class Initialized
INFO - 2023-08-16 19:21:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:21:49 --> Input Class Initialized
INFO - 2023-08-16 19:21:49 --> Language Class Initialized
ERROR - 2023-08-16 19:21:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:21:49 --> Config Class Initialized
INFO - 2023-08-16 19:21:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:21:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:21:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:21:49 --> URI Class Initialized
INFO - 2023-08-16 19:21:49 --> Router Class Initialized
INFO - 2023-08-16 19:21:49 --> Output Class Initialized
INFO - 2023-08-16 19:21:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:21:49 --> Input Class Initialized
INFO - 2023-08-16 19:21:49 --> Language Class Initialized
ERROR - 2023-08-16 19:21:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:21:50 --> Config Class Initialized
INFO - 2023-08-16 19:21:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:21:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:21:50 --> Utf8 Class Initialized
INFO - 2023-08-16 19:21:50 --> URI Class Initialized
INFO - 2023-08-16 19:21:50 --> Router Class Initialized
INFO - 2023-08-16 19:21:50 --> Output Class Initialized
INFO - 2023-08-16 19:21:50 --> Security Class Initialized
DEBUG - 2023-08-16 19:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:21:50 --> Input Class Initialized
INFO - 2023-08-16 19:21:50 --> Language Class Initialized
ERROR - 2023-08-16 19:21:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:23:47 --> Config Class Initialized
INFO - 2023-08-16 19:23:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:23:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:23:47 --> Utf8 Class Initialized
INFO - 2023-08-16 19:23:47 --> URI Class Initialized
INFO - 2023-08-16 19:23:47 --> Router Class Initialized
INFO - 2023-08-16 19:23:48 --> Output Class Initialized
INFO - 2023-08-16 19:23:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:23:48 --> Input Class Initialized
INFO - 2023-08-16 19:23:48 --> Language Class Initialized
INFO - 2023-08-16 19:23:48 --> Loader Class Initialized
INFO - 2023-08-16 19:23:48 --> Helper loaded: url_helper
INFO - 2023-08-16 19:23:48 --> Helper loaded: file_helper
INFO - 2023-08-16 19:23:48 --> Database Driver Class Initialized
INFO - 2023-08-16 19:23:48 --> Email Class Initialized
DEBUG - 2023-08-16 19:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:23:48 --> Controller Class Initialized
INFO - 2023-08-16 19:23:48 --> Model "Home_model" initialized
INFO - 2023-08-16 19:23:48 --> Helper loaded: form_helper
INFO - 2023-08-16 19:23:48 --> Form Validation Class Initialized
INFO - 2023-08-16 19:23:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:23:48 --> Final output sent to browser
DEBUG - 2023-08-16 19:23:48 --> Total execution time: 0.4842
INFO - 2023-08-16 19:23:48 --> Config Class Initialized
INFO - 2023-08-16 19:23:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:23:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:23:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:23:48 --> URI Class Initialized
INFO - 2023-08-16 19:23:48 --> Router Class Initialized
INFO - 2023-08-16 19:23:48 --> Output Class Initialized
INFO - 2023-08-16 19:23:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:23:48 --> Input Class Initialized
INFO - 2023-08-16 19:23:48 --> Language Class Initialized
INFO - 2023-08-16 19:23:49 --> Config Class Initialized
INFO - 2023-08-16 19:23:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:23:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:23:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:23:49 --> URI Class Initialized
INFO - 2023-08-16 19:23:49 --> Router Class Initialized
INFO - 2023-08-16 19:23:49 --> Output Class Initialized
INFO - 2023-08-16 19:23:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:23:49 --> Input Class Initialized
INFO - 2023-08-16 19:23:49 --> Language Class Initialized
ERROR - 2023-08-16 19:23:49 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:23:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:23:49 --> Config Class Initialized
INFO - 2023-08-16 19:23:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:23:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:23:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:23:49 --> URI Class Initialized
INFO - 2023-08-16 19:23:49 --> Router Class Initialized
INFO - 2023-08-16 19:23:49 --> Output Class Initialized
INFO - 2023-08-16 19:23:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:23:49 --> Input Class Initialized
INFO - 2023-08-16 19:23:49 --> Language Class Initialized
ERROR - 2023-08-16 19:23:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:23:49 --> Config Class Initialized
INFO - 2023-08-16 19:23:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:23:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:23:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:23:49 --> Config Class Initialized
INFO - 2023-08-16 19:23:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:23:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:23:49 --> Utf8 Class Initialized
INFO - 2023-08-16 19:23:49 --> URI Class Initialized
INFO - 2023-08-16 19:23:49 --> Router Class Initialized
INFO - 2023-08-16 19:23:49 --> Output Class Initialized
INFO - 2023-08-16 19:23:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:23:49 --> Input Class Initialized
INFO - 2023-08-16 19:23:49 --> Language Class Initialized
ERROR - 2023-08-16 19:23:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:23:49 --> URI Class Initialized
INFO - 2023-08-16 19:23:50 --> Router Class Initialized
INFO - 2023-08-16 19:23:50 --> Config Class Initialized
INFO - 2023-08-16 19:23:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:23:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:23:50 --> Utf8 Class Initialized
INFO - 2023-08-16 19:23:50 --> URI Class Initialized
INFO - 2023-08-16 19:23:50 --> Router Class Initialized
INFO - 2023-08-16 19:23:50 --> Output Class Initialized
INFO - 2023-08-16 19:23:50 --> Security Class Initialized
DEBUG - 2023-08-16 19:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:23:50 --> Input Class Initialized
INFO - 2023-08-16 19:23:50 --> Language Class Initialized
ERROR - 2023-08-16 19:23:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:23:50 --> Config Class Initialized
INFO - 2023-08-16 19:23:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:23:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:23:50 --> Utf8 Class Initialized
INFO - 2023-08-16 19:23:50 --> URI Class Initialized
INFO - 2023-08-16 19:23:50 --> Router Class Initialized
INFO - 2023-08-16 19:23:50 --> Output Class Initialized
INFO - 2023-08-16 19:23:50 --> Security Class Initialized
DEBUG - 2023-08-16 19:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:23:50 --> Input Class Initialized
INFO - 2023-08-16 19:23:50 --> Language Class Initialized
ERROR - 2023-08-16 19:23:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:23:50 --> Output Class Initialized
INFO - 2023-08-16 19:23:50 --> Security Class Initialized
DEBUG - 2023-08-16 19:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:23:50 --> Input Class Initialized
INFO - 2023-08-16 19:23:50 --> Language Class Initialized
ERROR - 2023-08-16 19:23:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:23:50 --> Config Class Initialized
INFO - 2023-08-16 19:23:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:23:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:23:50 --> Utf8 Class Initialized
INFO - 2023-08-16 19:23:50 --> URI Class Initialized
INFO - 2023-08-16 19:23:50 --> Router Class Initialized
INFO - 2023-08-16 19:23:50 --> Output Class Initialized
INFO - 2023-08-16 19:23:50 --> Security Class Initialized
DEBUG - 2023-08-16 19:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:23:50 --> Input Class Initialized
INFO - 2023-08-16 19:23:50 --> Language Class Initialized
ERROR - 2023-08-16 19:23:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:23:50 --> Config Class Initialized
INFO - 2023-08-16 19:23:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:23:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:23:50 --> Utf8 Class Initialized
INFO - 2023-08-16 19:23:50 --> URI Class Initialized
INFO - 2023-08-16 19:23:50 --> Router Class Initialized
INFO - 2023-08-16 19:23:50 --> Output Class Initialized
INFO - 2023-08-16 19:23:50 --> Security Class Initialized
DEBUG - 2023-08-16 19:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:23:50 --> Input Class Initialized
INFO - 2023-08-16 19:23:50 --> Language Class Initialized
ERROR - 2023-08-16 19:23:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:24:41 --> Config Class Initialized
INFO - 2023-08-16 19:24:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:24:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:24:42 --> Utf8 Class Initialized
INFO - 2023-08-16 19:24:42 --> URI Class Initialized
INFO - 2023-08-16 19:24:42 --> Router Class Initialized
INFO - 2023-08-16 19:24:42 --> Output Class Initialized
INFO - 2023-08-16 19:24:42 --> Security Class Initialized
DEBUG - 2023-08-16 19:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:24:42 --> Input Class Initialized
INFO - 2023-08-16 19:24:42 --> Language Class Initialized
INFO - 2023-08-16 19:24:42 --> Loader Class Initialized
INFO - 2023-08-16 19:24:42 --> Helper loaded: url_helper
INFO - 2023-08-16 19:24:42 --> Helper loaded: file_helper
INFO - 2023-08-16 19:24:42 --> Database Driver Class Initialized
INFO - 2023-08-16 19:24:42 --> Email Class Initialized
DEBUG - 2023-08-16 19:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:24:42 --> Controller Class Initialized
INFO - 2023-08-16 19:24:42 --> Model "Home_model" initialized
INFO - 2023-08-16 19:24:42 --> Helper loaded: form_helper
INFO - 2023-08-16 19:24:42 --> Form Validation Class Initialized
INFO - 2023-08-16 19:24:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:24:42 --> Final output sent to browser
DEBUG - 2023-08-16 19:24:42 --> Total execution time: 0.4387
INFO - 2023-08-16 19:24:43 --> Config Class Initialized
INFO - 2023-08-16 19:24:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:24:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:24:43 --> Utf8 Class Initialized
INFO - 2023-08-16 19:24:43 --> URI Class Initialized
INFO - 2023-08-16 19:24:43 --> Router Class Initialized
INFO - 2023-08-16 19:24:43 --> Output Class Initialized
INFO - 2023-08-16 19:24:43 --> Security Class Initialized
DEBUG - 2023-08-16 19:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:24:43 --> Input Class Initialized
INFO - 2023-08-16 19:24:43 --> Language Class Initialized
ERROR - 2023-08-16 19:24:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:24:43 --> Config Class Initialized
INFO - 2023-08-16 19:24:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:24:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:24:43 --> Utf8 Class Initialized
INFO - 2023-08-16 19:24:43 --> URI Class Initialized
INFO - 2023-08-16 19:24:43 --> Router Class Initialized
INFO - 2023-08-16 19:24:43 --> Output Class Initialized
INFO - 2023-08-16 19:24:43 --> Security Class Initialized
DEBUG - 2023-08-16 19:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:24:43 --> Input Class Initialized
INFO - 2023-08-16 19:24:43 --> Language Class Initialized
ERROR - 2023-08-16 19:24:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:24:43 --> Config Class Initialized
INFO - 2023-08-16 19:24:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:24:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:24:43 --> Utf8 Class Initialized
INFO - 2023-08-16 19:24:43 --> URI Class Initialized
INFO - 2023-08-16 19:24:43 --> Router Class Initialized
INFO - 2023-08-16 19:24:43 --> Output Class Initialized
INFO - 2023-08-16 19:24:43 --> Security Class Initialized
DEBUG - 2023-08-16 19:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:24:43 --> Input Class Initialized
INFO - 2023-08-16 19:24:43 --> Language Class Initialized
ERROR - 2023-08-16 19:24:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:24:43 --> Config Class Initialized
INFO - 2023-08-16 19:24:44 --> Config Class Initialized
INFO - 2023-08-16 19:24:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:24:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:24:44 --> Utf8 Class Initialized
INFO - 2023-08-16 19:24:44 --> URI Class Initialized
INFO - 2023-08-16 19:24:44 --> Router Class Initialized
INFO - 2023-08-16 19:24:44 --> Output Class Initialized
INFO - 2023-08-16 19:24:44 --> Security Class Initialized
DEBUG - 2023-08-16 19:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:24:44 --> Input Class Initialized
INFO - 2023-08-16 19:24:44 --> Language Class Initialized
ERROR - 2023-08-16 19:24:44 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:24:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:24:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:24:44 --> Config Class Initialized
INFO - 2023-08-16 19:24:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:24:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:24:44 --> Utf8 Class Initialized
INFO - 2023-08-16 19:24:44 --> URI Class Initialized
INFO - 2023-08-16 19:24:44 --> Router Class Initialized
INFO - 2023-08-16 19:24:44 --> Output Class Initialized
INFO - 2023-08-16 19:24:44 --> Security Class Initialized
DEBUG - 2023-08-16 19:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:24:44 --> Input Class Initialized
INFO - 2023-08-16 19:24:44 --> Language Class Initialized
ERROR - 2023-08-16 19:24:44 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:24:44 --> Utf8 Class Initialized
INFO - 2023-08-16 19:24:44 --> URI Class Initialized
INFO - 2023-08-16 19:24:44 --> Router Class Initialized
INFO - 2023-08-16 19:24:44 --> Output Class Initialized
INFO - 2023-08-16 19:24:44 --> Security Class Initialized
DEBUG - 2023-08-16 19:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:24:44 --> Input Class Initialized
INFO - 2023-08-16 19:24:44 --> Language Class Initialized
ERROR - 2023-08-16 19:24:44 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:24:44 --> Config Class Initialized
INFO - 2023-08-16 19:24:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:24:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:24:44 --> Utf8 Class Initialized
INFO - 2023-08-16 19:24:44 --> URI Class Initialized
INFO - 2023-08-16 19:24:44 --> Router Class Initialized
INFO - 2023-08-16 19:24:44 --> Output Class Initialized
INFO - 2023-08-16 19:24:44 --> Security Class Initialized
DEBUG - 2023-08-16 19:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:24:44 --> Input Class Initialized
INFO - 2023-08-16 19:24:44 --> Language Class Initialized
ERROR - 2023-08-16 19:24:44 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:25:12 --> Config Class Initialized
INFO - 2023-08-16 19:25:12 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:25:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:25:12 --> Utf8 Class Initialized
INFO - 2023-08-16 19:25:12 --> URI Class Initialized
INFO - 2023-08-16 19:25:12 --> Router Class Initialized
INFO - 2023-08-16 19:25:12 --> Output Class Initialized
INFO - 2023-08-16 19:25:12 --> Security Class Initialized
DEBUG - 2023-08-16 19:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:25:12 --> Input Class Initialized
INFO - 2023-08-16 19:25:12 --> Language Class Initialized
INFO - 2023-08-16 19:25:12 --> Loader Class Initialized
INFO - 2023-08-16 19:25:12 --> Helper loaded: url_helper
INFO - 2023-08-16 19:25:12 --> Helper loaded: file_helper
INFO - 2023-08-16 19:25:12 --> Database Driver Class Initialized
INFO - 2023-08-16 19:25:12 --> Email Class Initialized
DEBUG - 2023-08-16 19:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:25:12 --> Controller Class Initialized
INFO - 2023-08-16 19:25:12 --> Model "Home_model" initialized
INFO - 2023-08-16 19:25:12 --> Helper loaded: form_helper
INFO - 2023-08-16 19:25:12 --> Form Validation Class Initialized
INFO - 2023-08-16 19:25:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:25:12 --> Final output sent to browser
DEBUG - 2023-08-16 19:25:13 --> Total execution time: 0.4280
INFO - 2023-08-16 19:25:13 --> Config Class Initialized
INFO - 2023-08-16 19:25:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:25:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:25:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:25:13 --> URI Class Initialized
INFO - 2023-08-16 19:25:13 --> Router Class Initialized
INFO - 2023-08-16 19:25:13 --> Output Class Initialized
INFO - 2023-08-16 19:25:13 --> Security Class Initialized
DEBUG - 2023-08-16 19:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:25:13 --> Input Class Initialized
INFO - 2023-08-16 19:25:13 --> Language Class Initialized
ERROR - 2023-08-16 19:25:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:25:13 --> Config Class Initialized
INFO - 2023-08-16 19:25:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:25:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:25:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:25:13 --> URI Class Initialized
INFO - 2023-08-16 19:25:13 --> Router Class Initialized
INFO - 2023-08-16 19:25:13 --> Output Class Initialized
INFO - 2023-08-16 19:25:13 --> Security Class Initialized
DEBUG - 2023-08-16 19:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:25:13 --> Input Class Initialized
INFO - 2023-08-16 19:25:13 --> Language Class Initialized
ERROR - 2023-08-16 19:25:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:25:13 --> Config Class Initialized
INFO - 2023-08-16 19:25:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:25:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:25:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:25:13 --> URI Class Initialized
INFO - 2023-08-16 19:25:13 --> Router Class Initialized
INFO - 2023-08-16 19:25:13 --> Output Class Initialized
INFO - 2023-08-16 19:25:13 --> Security Class Initialized
DEBUG - 2023-08-16 19:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:25:13 --> Input Class Initialized
INFO - 2023-08-16 19:25:13 --> Language Class Initialized
ERROR - 2023-08-16 19:25:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:25:13 --> Config Class Initialized
INFO - 2023-08-16 19:25:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:25:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:25:14 --> Utf8 Class Initialized
INFO - 2023-08-16 19:25:14 --> URI Class Initialized
INFO - 2023-08-16 19:25:14 --> Router Class Initialized
INFO - 2023-08-16 19:25:14 --> Output Class Initialized
INFO - 2023-08-16 19:25:14 --> Security Class Initialized
DEBUG - 2023-08-16 19:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:25:14 --> Input Class Initialized
INFO - 2023-08-16 19:25:14 --> Language Class Initialized
ERROR - 2023-08-16 19:25:14 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:25:14 --> Config Class Initialized
INFO - 2023-08-16 19:25:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:25:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:25:14 --> Utf8 Class Initialized
INFO - 2023-08-16 19:25:14 --> URI Class Initialized
INFO - 2023-08-16 19:25:14 --> Router Class Initialized
INFO - 2023-08-16 19:25:14 --> Output Class Initialized
INFO - 2023-08-16 19:25:14 --> Security Class Initialized
DEBUG - 2023-08-16 19:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:25:14 --> Input Class Initialized
INFO - 2023-08-16 19:25:14 --> Language Class Initialized
ERROR - 2023-08-16 19:25:14 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:25:15 --> Config Class Initialized
INFO - 2023-08-16 19:25:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:25:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:25:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:25:15 --> URI Class Initialized
INFO - 2023-08-16 19:25:15 --> Router Class Initialized
INFO - 2023-08-16 19:25:15 --> Output Class Initialized
INFO - 2023-08-16 19:25:15 --> Security Class Initialized
DEBUG - 2023-08-16 19:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:25:15 --> Input Class Initialized
INFO - 2023-08-16 19:25:15 --> Language Class Initialized
ERROR - 2023-08-16 19:25:15 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:25:30 --> Config Class Initialized
INFO - 2023-08-16 19:25:30 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:25:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:25:30 --> Utf8 Class Initialized
INFO - 2023-08-16 19:25:30 --> URI Class Initialized
INFO - 2023-08-16 19:25:30 --> Router Class Initialized
INFO - 2023-08-16 19:25:30 --> Output Class Initialized
INFO - 2023-08-16 19:25:30 --> Security Class Initialized
DEBUG - 2023-08-16 19:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:25:30 --> Input Class Initialized
INFO - 2023-08-16 19:25:30 --> Language Class Initialized
INFO - 2023-08-16 19:25:30 --> Loader Class Initialized
INFO - 2023-08-16 19:25:30 --> Helper loaded: url_helper
INFO - 2023-08-16 19:25:30 --> Helper loaded: file_helper
INFO - 2023-08-16 19:25:30 --> Database Driver Class Initialized
INFO - 2023-08-16 19:25:30 --> Email Class Initialized
DEBUG - 2023-08-16 19:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:25:30 --> Controller Class Initialized
INFO - 2023-08-16 19:25:30 --> Model "Home_model" initialized
INFO - 2023-08-16 19:25:30 --> Helper loaded: form_helper
INFO - 2023-08-16 19:25:30 --> Form Validation Class Initialized
INFO - 2023-08-16 19:25:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:25:30 --> Final output sent to browser
DEBUG - 2023-08-16 19:25:31 --> Total execution time: 0.2091
INFO - 2023-08-16 19:25:31 --> Config Class Initialized
INFO - 2023-08-16 19:25:31 --> Config Class Initialized
INFO - 2023-08-16 19:25:31 --> Hooks Class Initialized
INFO - 2023-08-16 19:25:31 --> Config Class Initialized
DEBUG - 2023-08-16 19:25:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:25:31 --> Utf8 Class Initialized
INFO - 2023-08-16 19:25:31 --> URI Class Initialized
INFO - 2023-08-16 19:25:31 --> Router Class Initialized
INFO - 2023-08-16 19:25:31 --> Output Class Initialized
INFO - 2023-08-16 19:25:31 --> Security Class Initialized
DEBUG - 2023-08-16 19:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:25:31 --> Input Class Initialized
INFO - 2023-08-16 19:25:31 --> Language Class Initialized
ERROR - 2023-08-16 19:25:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:25:31 --> Hooks Class Initialized
INFO - 2023-08-16 19:25:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:25:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:25:31 --> Config Class Initialized
INFO - 2023-08-16 19:25:31 --> Hooks Class Initialized
INFO - 2023-08-16 19:25:31 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:25:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:25:31 --> Utf8 Class Initialized
INFO - 2023-08-16 19:25:31 --> URI Class Initialized
INFO - 2023-08-16 19:25:32 --> Router Class Initialized
INFO - 2023-08-16 19:25:32 --> Output Class Initialized
INFO - 2023-08-16 19:25:32 --> Security Class Initialized
DEBUG - 2023-08-16 19:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:25:32 --> Input Class Initialized
INFO - 2023-08-16 19:25:32 --> Language Class Initialized
ERROR - 2023-08-16 19:25:32 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:25:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:25:32 --> URI Class Initialized
INFO - 2023-08-16 19:25:32 --> Config Class Initialized
INFO - 2023-08-16 19:25:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:25:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:25:32 --> Utf8 Class Initialized
INFO - 2023-08-16 19:25:32 --> URI Class Initialized
INFO - 2023-08-16 19:25:32 --> Router Class Initialized
INFO - 2023-08-16 19:25:32 --> Output Class Initialized
INFO - 2023-08-16 19:25:32 --> Security Class Initialized
DEBUG - 2023-08-16 19:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:25:32 --> Input Class Initialized
INFO - 2023-08-16 19:25:32 --> Language Class Initialized
ERROR - 2023-08-16 19:25:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:25:32 --> Utf8 Class Initialized
INFO - 2023-08-16 19:25:32 --> Config Class Initialized
INFO - 2023-08-16 19:25:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:25:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:25:32 --> Utf8 Class Initialized
INFO - 2023-08-16 19:25:32 --> URI Class Initialized
INFO - 2023-08-16 19:25:32 --> Router Class Initialized
INFO - 2023-08-16 19:25:32 --> Output Class Initialized
INFO - 2023-08-16 19:25:32 --> Security Class Initialized
DEBUG - 2023-08-16 19:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:25:32 --> Input Class Initialized
INFO - 2023-08-16 19:25:32 --> Language Class Initialized
ERROR - 2023-08-16 19:25:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:25:32 --> Router Class Initialized
INFO - 2023-08-16 19:25:32 --> URI Class Initialized
INFO - 2023-08-16 19:25:32 --> Output Class Initialized
INFO - 2023-08-16 19:25:32 --> Router Class Initialized
INFO - 2023-08-16 19:25:32 --> Security Class Initialized
DEBUG - 2023-08-16 19:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:25:32 --> Input Class Initialized
INFO - 2023-08-16 19:25:32 --> Language Class Initialized
ERROR - 2023-08-16 19:25:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:25:32 --> Output Class Initialized
INFO - 2023-08-16 19:25:32 --> Security Class Initialized
DEBUG - 2023-08-16 19:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:25:32 --> Input Class Initialized
INFO - 2023-08-16 19:25:32 --> Language Class Initialized
ERROR - 2023-08-16 19:25:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:26:19 --> Config Class Initialized
INFO - 2023-08-16 19:26:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:26:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:19 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:19 --> URI Class Initialized
INFO - 2023-08-16 19:26:19 --> Router Class Initialized
INFO - 2023-08-16 19:26:19 --> Output Class Initialized
INFO - 2023-08-16 19:26:19 --> Security Class Initialized
DEBUG - 2023-08-16 19:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:19 --> Input Class Initialized
INFO - 2023-08-16 19:26:19 --> Language Class Initialized
INFO - 2023-08-16 19:26:19 --> Loader Class Initialized
INFO - 2023-08-16 19:26:19 --> Helper loaded: url_helper
INFO - 2023-08-16 19:26:19 --> Helper loaded: file_helper
INFO - 2023-08-16 19:26:19 --> Database Driver Class Initialized
INFO - 2023-08-16 19:26:19 --> Email Class Initialized
DEBUG - 2023-08-16 19:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:26:19 --> Controller Class Initialized
INFO - 2023-08-16 19:26:19 --> Model "Home_model" initialized
INFO - 2023-08-16 19:26:19 --> Helper loaded: form_helper
INFO - 2023-08-16 19:26:19 --> Form Validation Class Initialized
INFO - 2023-08-16 19:26:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:26:19 --> Final output sent to browser
DEBUG - 2023-08-16 19:26:19 --> Total execution time: 0.2380
INFO - 2023-08-16 19:26:20 --> Config Class Initialized
INFO - 2023-08-16 19:26:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:26:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:20 --> Config Class Initialized
INFO - 2023-08-16 19:26:20 --> Hooks Class Initialized
INFO - 2023-08-16 19:26:20 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:26:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:20 --> URI Class Initialized
INFO - 2023-08-16 19:26:20 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:20 --> Router Class Initialized
INFO - 2023-08-16 19:26:20 --> URI Class Initialized
INFO - 2023-08-16 19:26:20 --> Output Class Initialized
INFO - 2023-08-16 19:26:20 --> Router Class Initialized
INFO - 2023-08-16 19:26:20 --> Security Class Initialized
INFO - 2023-08-16 19:26:20 --> Output Class Initialized
DEBUG - 2023-08-16 19:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:20 --> Security Class Initialized
INFO - 2023-08-16 19:26:20 --> Input Class Initialized
DEBUG - 2023-08-16 19:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:20 --> Input Class Initialized
INFO - 2023-08-16 19:26:20 --> Language Class Initialized
INFO - 2023-08-16 19:26:20 --> Language Class Initialized
ERROR - 2023-08-16 19:26:20 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:26:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:26:20 --> Config Class Initialized
INFO - 2023-08-16 19:26:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:26:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:20 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:20 --> URI Class Initialized
INFO - 2023-08-16 19:26:20 --> Router Class Initialized
INFO - 2023-08-16 19:26:20 --> Output Class Initialized
INFO - 2023-08-16 19:26:20 --> Security Class Initialized
DEBUG - 2023-08-16 19:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:20 --> Input Class Initialized
INFO - 2023-08-16 19:26:20 --> Language Class Initialized
ERROR - 2023-08-16 19:26:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:26:20 --> Config Class Initialized
INFO - 2023-08-16 19:26:20 --> Config Class Initialized
INFO - 2023-08-16 19:26:20 --> Hooks Class Initialized
INFO - 2023-08-16 19:26:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:26:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:20 --> Config Class Initialized
INFO - 2023-08-16 19:26:20 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:26:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:26:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:20 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:20 --> URI Class Initialized
INFO - 2023-08-16 19:26:20 --> URI Class Initialized
INFO - 2023-08-16 19:26:20 --> Router Class Initialized
INFO - 2023-08-16 19:26:20 --> Router Class Initialized
INFO - 2023-08-16 19:26:20 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:20 --> Output Class Initialized
INFO - 2023-08-16 19:26:20 --> URI Class Initialized
INFO - 2023-08-16 19:26:20 --> Output Class Initialized
INFO - 2023-08-16 19:26:20 --> Security Class Initialized
INFO - 2023-08-16 19:26:20 --> Security Class Initialized
DEBUG - 2023-08-16 19:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:20 --> Input Class Initialized
DEBUG - 2023-08-16 19:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:20 --> Router Class Initialized
INFO - 2023-08-16 19:26:20 --> Input Class Initialized
INFO - 2023-08-16 19:26:20 --> Language Class Initialized
INFO - 2023-08-16 19:26:20 --> Output Class Initialized
ERROR - 2023-08-16 19:26:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:26:20 --> Language Class Initialized
INFO - 2023-08-16 19:26:20 --> Security Class Initialized
ERROR - 2023-08-16 19:26:20 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:21 --> Input Class Initialized
INFO - 2023-08-16 19:26:21 --> Language Class Initialized
ERROR - 2023-08-16 19:26:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:26:30 --> Config Class Initialized
INFO - 2023-08-16 19:26:30 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:26:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:30 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:30 --> URI Class Initialized
INFO - 2023-08-16 19:26:30 --> Router Class Initialized
INFO - 2023-08-16 19:26:30 --> Output Class Initialized
INFO - 2023-08-16 19:26:30 --> Security Class Initialized
DEBUG - 2023-08-16 19:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:30 --> Input Class Initialized
INFO - 2023-08-16 19:26:30 --> Language Class Initialized
INFO - 2023-08-16 19:26:30 --> Loader Class Initialized
INFO - 2023-08-16 19:26:30 --> Helper loaded: url_helper
INFO - 2023-08-16 19:26:30 --> Helper loaded: file_helper
INFO - 2023-08-16 19:26:30 --> Database Driver Class Initialized
INFO - 2023-08-16 19:26:30 --> Email Class Initialized
DEBUG - 2023-08-16 19:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:26:30 --> Controller Class Initialized
INFO - 2023-08-16 19:26:30 --> Model "Home_model" initialized
INFO - 2023-08-16 19:26:30 --> Helper loaded: form_helper
INFO - 2023-08-16 19:26:30 --> Form Validation Class Initialized
INFO - 2023-08-16 19:26:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:26:30 --> Final output sent to browser
DEBUG - 2023-08-16 19:26:30 --> Total execution time: 0.4630
INFO - 2023-08-16 19:26:31 --> Config Class Initialized
INFO - 2023-08-16 19:26:31 --> Hooks Class Initialized
INFO - 2023-08-16 19:26:31 --> Config Class Initialized
INFO - 2023-08-16 19:26:31 --> Config Class Initialized
DEBUG - 2023-08-16 19:26:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:31 --> Config Class Initialized
INFO - 2023-08-16 19:26:31 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:31 --> Hooks Class Initialized
INFO - 2023-08-16 19:26:31 --> Config Class Initialized
INFO - 2023-08-16 19:26:31 --> Config Class Initialized
INFO - 2023-08-16 19:26:31 --> Hooks Class Initialized
INFO - 2023-08-16 19:26:31 --> URI Class Initialized
INFO - 2023-08-16 19:26:31 --> Hooks Class Initialized
INFO - 2023-08-16 19:26:31 --> Router Class Initialized
DEBUG - 2023-08-16 19:26:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:26:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:31 --> Hooks Class Initialized
INFO - 2023-08-16 19:26:31 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:26:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:32 --> Output Class Initialized
DEBUG - 2023-08-16 19:26:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:32 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:32 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:32 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:26:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:32 --> URI Class Initialized
INFO - 2023-08-16 19:26:32 --> URI Class Initialized
INFO - 2023-08-16 19:26:32 --> URI Class Initialized
INFO - 2023-08-16 19:26:32 --> URI Class Initialized
INFO - 2023-08-16 19:26:32 --> Router Class Initialized
INFO - 2023-08-16 19:26:32 --> Output Class Initialized
INFO - 2023-08-16 19:26:32 --> Security Class Initialized
DEBUG - 2023-08-16 19:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:32 --> Input Class Initialized
INFO - 2023-08-16 19:26:32 --> Language Class Initialized
ERROR - 2023-08-16 19:26:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:26:32 --> Security Class Initialized
INFO - 2023-08-16 19:26:32 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:32 --> Router Class Initialized
INFO - 2023-08-16 19:26:32 --> URI Class Initialized
INFO - 2023-08-16 19:26:32 --> Output Class Initialized
INFO - 2023-08-16 19:26:32 --> Router Class Initialized
INFO - 2023-08-16 19:26:32 --> Router Class Initialized
INFO - 2023-08-16 19:26:32 --> Input Class Initialized
INFO - 2023-08-16 19:26:32 --> Security Class Initialized
INFO - 2023-08-16 19:26:32 --> Router Class Initialized
INFO - 2023-08-16 19:26:32 --> Language Class Initialized
INFO - 2023-08-16 19:26:32 --> Output Class Initialized
INFO - 2023-08-16 19:26:32 --> Output Class Initialized
INFO - 2023-08-16 19:26:32 --> Security Class Initialized
ERROR - 2023-08-16 19:26:32 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:32 --> Security Class Initialized
DEBUG - 2023-08-16 19:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:32 --> Output Class Initialized
INFO - 2023-08-16 19:26:32 --> Input Class Initialized
DEBUG - 2023-08-16 19:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:32 --> Input Class Initialized
INFO - 2023-08-16 19:26:32 --> Language Class Initialized
ERROR - 2023-08-16 19:26:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:26:32 --> Input Class Initialized
INFO - 2023-08-16 19:26:32 --> Language Class Initialized
INFO - 2023-08-16 19:26:32 --> Security Class Initialized
ERROR - 2023-08-16 19:26:32 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:32 --> Language Class Initialized
INFO - 2023-08-16 19:26:32 --> Input Class Initialized
ERROR - 2023-08-16 19:26:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:26:32 --> Language Class Initialized
ERROR - 2023-08-16 19:26:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:26:50 --> Config Class Initialized
INFO - 2023-08-16 19:26:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:26:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:50 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:50 --> URI Class Initialized
INFO - 2023-08-16 19:26:50 --> Router Class Initialized
INFO - 2023-08-16 19:26:50 --> Output Class Initialized
INFO - 2023-08-16 19:26:50 --> Security Class Initialized
DEBUG - 2023-08-16 19:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:50 --> Input Class Initialized
INFO - 2023-08-16 19:26:50 --> Language Class Initialized
INFO - 2023-08-16 19:26:50 --> Loader Class Initialized
INFO - 2023-08-16 19:26:50 --> Helper loaded: url_helper
INFO - 2023-08-16 19:26:50 --> Helper loaded: file_helper
INFO - 2023-08-16 19:26:50 --> Database Driver Class Initialized
INFO - 2023-08-16 19:26:50 --> Email Class Initialized
DEBUG - 2023-08-16 19:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:26:51 --> Controller Class Initialized
INFO - 2023-08-16 19:26:51 --> Model "Home_model" initialized
INFO - 2023-08-16 19:26:51 --> Helper loaded: form_helper
INFO - 2023-08-16 19:26:51 --> Form Validation Class Initialized
INFO - 2023-08-16 19:26:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:26:51 --> Final output sent to browser
DEBUG - 2023-08-16 19:26:51 --> Total execution time: 0.4466
INFO - 2023-08-16 19:26:51 --> Config Class Initialized
INFO - 2023-08-16 19:26:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:26:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:52 --> Config Class Initialized
INFO - 2023-08-16 19:26:52 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:52 --> Hooks Class Initialized
INFO - 2023-08-16 19:26:52 --> URI Class Initialized
DEBUG - 2023-08-16 19:26:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:52 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:52 --> Router Class Initialized
INFO - 2023-08-16 19:26:52 --> URI Class Initialized
INFO - 2023-08-16 19:26:52 --> Output Class Initialized
INFO - 2023-08-16 19:26:52 --> Router Class Initialized
INFO - 2023-08-16 19:26:52 --> Security Class Initialized
INFO - 2023-08-16 19:26:52 --> Output Class Initialized
DEBUG - 2023-08-16 19:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:52 --> Security Class Initialized
DEBUG - 2023-08-16 19:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:52 --> Input Class Initialized
INFO - 2023-08-16 19:26:52 --> Input Class Initialized
INFO - 2023-08-16 19:26:52 --> Language Class Initialized
INFO - 2023-08-16 19:26:52 --> Language Class Initialized
ERROR - 2023-08-16 19:26:52 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:26:52 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:26:52 --> Config Class Initialized
INFO - 2023-08-16 19:26:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:26:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:52 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:52 --> URI Class Initialized
INFO - 2023-08-16 19:26:52 --> Router Class Initialized
INFO - 2023-08-16 19:26:52 --> Output Class Initialized
INFO - 2023-08-16 19:26:52 --> Security Class Initialized
DEBUG - 2023-08-16 19:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:52 --> Input Class Initialized
INFO - 2023-08-16 19:26:52 --> Language Class Initialized
ERROR - 2023-08-16 19:26:52 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:26:52 --> Config Class Initialized
INFO - 2023-08-16 19:26:52 --> Config Class Initialized
INFO - 2023-08-16 19:26:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:26:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:52 --> Config Class Initialized
INFO - 2023-08-16 19:26:52 --> Hooks Class Initialized
INFO - 2023-08-16 19:26:52 --> Hooks Class Initialized
INFO - 2023-08-16 19:26:52 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:52 --> URI Class Initialized
DEBUG - 2023-08-16 19:26:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:52 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:52 --> URI Class Initialized
INFO - 2023-08-16 19:26:52 --> Router Class Initialized
INFO - 2023-08-16 19:26:52 --> Output Class Initialized
INFO - 2023-08-16 19:26:52 --> Security Class Initialized
DEBUG - 2023-08-16 19:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:52 --> Input Class Initialized
INFO - 2023-08-16 19:26:52 --> Language Class Initialized
ERROR - 2023-08-16 19:26:52 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:26:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:26:52 --> Router Class Initialized
INFO - 2023-08-16 19:26:52 --> Utf8 Class Initialized
INFO - 2023-08-16 19:26:52 --> Output Class Initialized
INFO - 2023-08-16 19:26:52 --> Security Class Initialized
INFO - 2023-08-16 19:26:52 --> URI Class Initialized
DEBUG - 2023-08-16 19:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:53 --> Input Class Initialized
INFO - 2023-08-16 19:26:53 --> Router Class Initialized
INFO - 2023-08-16 19:26:53 --> Language Class Initialized
ERROR - 2023-08-16 19:26:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:26:53 --> Output Class Initialized
INFO - 2023-08-16 19:26:53 --> Security Class Initialized
DEBUG - 2023-08-16 19:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:26:53 --> Input Class Initialized
INFO - 2023-08-16 19:26:53 --> Language Class Initialized
ERROR - 2023-08-16 19:26:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:27:12 --> Config Class Initialized
INFO - 2023-08-16 19:27:12 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:27:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:27:12 --> Utf8 Class Initialized
INFO - 2023-08-16 19:27:12 --> URI Class Initialized
INFO - 2023-08-16 19:27:13 --> Router Class Initialized
INFO - 2023-08-16 19:27:13 --> Output Class Initialized
INFO - 2023-08-16 19:27:13 --> Security Class Initialized
DEBUG - 2023-08-16 19:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:27:13 --> Input Class Initialized
INFO - 2023-08-16 19:27:13 --> Language Class Initialized
INFO - 2023-08-16 19:27:13 --> Loader Class Initialized
INFO - 2023-08-16 19:27:13 --> Helper loaded: url_helper
INFO - 2023-08-16 19:27:13 --> Helper loaded: file_helper
INFO - 2023-08-16 19:27:13 --> Database Driver Class Initialized
INFO - 2023-08-16 19:27:13 --> Email Class Initialized
DEBUG - 2023-08-16 19:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:27:13 --> Controller Class Initialized
INFO - 2023-08-16 19:27:13 --> Model "Home_model" initialized
INFO - 2023-08-16 19:27:13 --> Helper loaded: form_helper
INFO - 2023-08-16 19:27:13 --> Form Validation Class Initialized
INFO - 2023-08-16 19:27:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:27:13 --> Final output sent to browser
DEBUG - 2023-08-16 19:27:13 --> Total execution time: 0.4959
INFO - 2023-08-16 19:27:14 --> Config Class Initialized
INFO - 2023-08-16 19:27:14 --> Config Class Initialized
INFO - 2023-08-16 19:27:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:27:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:27:14 --> Utf8 Class Initialized
INFO - 2023-08-16 19:27:14 --> URI Class Initialized
INFO - 2023-08-16 19:27:14 --> Router Class Initialized
INFO - 2023-08-16 19:27:14 --> Output Class Initialized
INFO - 2023-08-16 19:27:14 --> Security Class Initialized
DEBUG - 2023-08-16 19:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:27:14 --> Input Class Initialized
INFO - 2023-08-16 19:27:14 --> Language Class Initialized
ERROR - 2023-08-16 19:27:14 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:27:14 --> Hooks Class Initialized
INFO - 2023-08-16 19:27:14 --> Config Class Initialized
INFO - 2023-08-16 19:27:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:27:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:27:14 --> Utf8 Class Initialized
INFO - 2023-08-16 19:27:14 --> URI Class Initialized
INFO - 2023-08-16 19:27:14 --> Router Class Initialized
INFO - 2023-08-16 19:27:14 --> Output Class Initialized
INFO - 2023-08-16 19:27:14 --> Security Class Initialized
DEBUG - 2023-08-16 19:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:27:14 --> Input Class Initialized
INFO - 2023-08-16 19:27:14 --> Language Class Initialized
ERROR - 2023-08-16 19:27:14 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:27:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:27:14 --> Utf8 Class Initialized
INFO - 2023-08-16 19:27:14 --> URI Class Initialized
INFO - 2023-08-16 19:27:14 --> Router Class Initialized
INFO - 2023-08-16 19:27:14 --> Output Class Initialized
INFO - 2023-08-16 19:27:14 --> Security Class Initialized
DEBUG - 2023-08-16 19:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:27:14 --> Input Class Initialized
INFO - 2023-08-16 19:27:14 --> Language Class Initialized
ERROR - 2023-08-16 19:27:15 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:27:15 --> Config Class Initialized
INFO - 2023-08-16 19:27:15 --> Config Class Initialized
INFO - 2023-08-16 19:27:15 --> Hooks Class Initialized
INFO - 2023-08-16 19:27:15 --> Hooks Class Initialized
INFO - 2023-08-16 19:27:15 --> Config Class Initialized
DEBUG - 2023-08-16 19:27:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:27:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:27:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:27:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:27:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:27:15 --> URI Class Initialized
INFO - 2023-08-16 19:27:15 --> Router Class Initialized
INFO - 2023-08-16 19:27:15 --> URI Class Initialized
DEBUG - 2023-08-16 19:27:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:27:15 --> Router Class Initialized
INFO - 2023-08-16 19:27:15 --> Output Class Initialized
INFO - 2023-08-16 19:27:15 --> Output Class Initialized
INFO - 2023-08-16 19:27:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:27:15 --> Security Class Initialized
INFO - 2023-08-16 19:27:15 --> URI Class Initialized
INFO - 2023-08-16 19:27:15 --> Security Class Initialized
INFO - 2023-08-16 19:27:15 --> Router Class Initialized
DEBUG - 2023-08-16 19:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:27:15 --> Input Class Initialized
INFO - 2023-08-16 19:27:15 --> Input Class Initialized
INFO - 2023-08-16 19:27:15 --> Output Class Initialized
INFO - 2023-08-16 19:27:15 --> Language Class Initialized
INFO - 2023-08-16 19:27:15 --> Language Class Initialized
ERROR - 2023-08-16 19:27:15 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:27:15 --> Security Class Initialized
ERROR - 2023-08-16 19:27:15 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:27:15 --> Input Class Initialized
INFO - 2023-08-16 19:27:15 --> Language Class Initialized
ERROR - 2023-08-16 19:27:15 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:27:27 --> Config Class Initialized
INFO - 2023-08-16 19:27:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:27:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:27:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:27:27 --> URI Class Initialized
INFO - 2023-08-16 19:27:27 --> Router Class Initialized
INFO - 2023-08-16 19:27:27 --> Output Class Initialized
INFO - 2023-08-16 19:27:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:27:27 --> Input Class Initialized
INFO - 2023-08-16 19:27:27 --> Language Class Initialized
INFO - 2023-08-16 19:27:27 --> Loader Class Initialized
INFO - 2023-08-16 19:27:27 --> Helper loaded: url_helper
INFO - 2023-08-16 19:27:27 --> Helper loaded: file_helper
INFO - 2023-08-16 19:27:27 --> Database Driver Class Initialized
INFO - 2023-08-16 19:27:27 --> Email Class Initialized
DEBUG - 2023-08-16 19:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:27:27 --> Controller Class Initialized
INFO - 2023-08-16 19:27:27 --> Model "Home_model" initialized
INFO - 2023-08-16 19:27:27 --> Helper loaded: form_helper
INFO - 2023-08-16 19:27:27 --> Form Validation Class Initialized
INFO - 2023-08-16 19:27:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:27:27 --> Final output sent to browser
DEBUG - 2023-08-16 19:27:28 --> Total execution time: 0.4554
INFO - 2023-08-16 19:27:28 --> Config Class Initialized
INFO - 2023-08-16 19:27:28 --> Hooks Class Initialized
INFO - 2023-08-16 19:27:28 --> Config Class Initialized
DEBUG - 2023-08-16 19:27:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:27:28 --> Utf8 Class Initialized
INFO - 2023-08-16 19:27:28 --> Hooks Class Initialized
INFO - 2023-08-16 19:27:28 --> URI Class Initialized
DEBUG - 2023-08-16 19:27:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:27:28 --> Utf8 Class Initialized
INFO - 2023-08-16 19:27:29 --> URI Class Initialized
INFO - 2023-08-16 19:27:29 --> Router Class Initialized
INFO - 2023-08-16 19:27:29 --> Router Class Initialized
INFO - 2023-08-16 19:27:29 --> Output Class Initialized
INFO - 2023-08-16 19:27:29 --> Security Class Initialized
INFO - 2023-08-16 19:27:29 --> Output Class Initialized
DEBUG - 2023-08-16 19:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:27:29 --> Security Class Initialized
INFO - 2023-08-16 19:27:29 --> Input Class Initialized
DEBUG - 2023-08-16 19:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:27:29 --> Language Class Initialized
INFO - 2023-08-16 19:27:29 --> Input Class Initialized
ERROR - 2023-08-16 19:27:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:27:29 --> Language Class Initialized
ERROR - 2023-08-16 19:27:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:27:29 --> Config Class Initialized
INFO - 2023-08-16 19:27:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:27:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:27:29 --> Utf8 Class Initialized
INFO - 2023-08-16 19:27:29 --> URI Class Initialized
INFO - 2023-08-16 19:27:29 --> Router Class Initialized
INFO - 2023-08-16 19:27:29 --> Output Class Initialized
INFO - 2023-08-16 19:27:29 --> Security Class Initialized
DEBUG - 2023-08-16 19:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:27:29 --> Input Class Initialized
INFO - 2023-08-16 19:27:29 --> Language Class Initialized
ERROR - 2023-08-16 19:27:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:27:29 --> Config Class Initialized
INFO - 2023-08-16 19:27:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:27:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:27:29 --> Utf8 Class Initialized
INFO - 2023-08-16 19:27:29 --> URI Class Initialized
INFO - 2023-08-16 19:27:29 --> Router Class Initialized
INFO - 2023-08-16 19:27:29 --> Output Class Initialized
INFO - 2023-08-16 19:27:29 --> Security Class Initialized
DEBUG - 2023-08-16 19:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:27:29 --> Input Class Initialized
INFO - 2023-08-16 19:27:29 --> Language Class Initialized
ERROR - 2023-08-16 19:27:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:27:29 --> Config Class Initialized
INFO - 2023-08-16 19:27:29 --> Config Class Initialized
INFO - 2023-08-16 19:27:29 --> Hooks Class Initialized
INFO - 2023-08-16 19:27:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:27:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:27:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:27:30 --> Utf8 Class Initialized
INFO - 2023-08-16 19:27:30 --> Utf8 Class Initialized
INFO - 2023-08-16 19:27:30 --> URI Class Initialized
INFO - 2023-08-16 19:27:30 --> URI Class Initialized
INFO - 2023-08-16 19:27:30 --> Router Class Initialized
INFO - 2023-08-16 19:27:30 --> Router Class Initialized
INFO - 2023-08-16 19:27:30 --> Output Class Initialized
INFO - 2023-08-16 19:27:30 --> Output Class Initialized
INFO - 2023-08-16 19:27:30 --> Security Class Initialized
INFO - 2023-08-16 19:27:30 --> Security Class Initialized
DEBUG - 2023-08-16 19:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:27:30 --> Input Class Initialized
INFO - 2023-08-16 19:27:30 --> Input Class Initialized
INFO - 2023-08-16 19:27:30 --> Language Class Initialized
INFO - 2023-08-16 19:27:30 --> Language Class Initialized
ERROR - 2023-08-16 19:27:30 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:27:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:28:00 --> Config Class Initialized
INFO - 2023-08-16 19:28:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:28:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:28:00 --> Config Class Initialized
INFO - 2023-08-16 19:28:00 --> Hooks Class Initialized
INFO - 2023-08-16 19:28:00 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:28:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:28:00 --> Utf8 Class Initialized
INFO - 2023-08-16 19:28:00 --> URI Class Initialized
INFO - 2023-08-16 19:28:01 --> Config Class Initialized
INFO - 2023-08-16 19:28:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:28:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:28:01 --> Utf8 Class Initialized
INFO - 2023-08-16 19:28:01 --> URI Class Initialized
INFO - 2023-08-16 19:28:01 --> Router Class Initialized
INFO - 2023-08-16 19:28:01 --> Output Class Initialized
INFO - 2023-08-16 19:28:01 --> Security Class Initialized
DEBUG - 2023-08-16 19:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:28:01 --> Input Class Initialized
INFO - 2023-08-16 19:28:01 --> Language Class Initialized
ERROR - 2023-08-16 19:28:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:28:01 --> Config Class Initialized
INFO - 2023-08-16 19:28:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:28:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:28:01 --> Utf8 Class Initialized
INFO - 2023-08-16 19:28:01 --> URI Class Initialized
INFO - 2023-08-16 19:28:01 --> Router Class Initialized
INFO - 2023-08-16 19:28:01 --> Output Class Initialized
INFO - 2023-08-16 19:28:01 --> Security Class Initialized
DEBUG - 2023-08-16 19:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:28:01 --> Input Class Initialized
INFO - 2023-08-16 19:28:01 --> Language Class Initialized
ERROR - 2023-08-16 19:28:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:28:01 --> Config Class Initialized
INFO - 2023-08-16 19:28:01 --> Config Class Initialized
INFO - 2023-08-16 19:28:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:28:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:28:01 --> Utf8 Class Initialized
INFO - 2023-08-16 19:28:01 --> URI Class Initialized
INFO - 2023-08-16 19:28:01 --> Router Class Initialized
INFO - 2023-08-16 19:28:01 --> Output Class Initialized
INFO - 2023-08-16 19:28:01 --> Security Class Initialized
DEBUG - 2023-08-16 19:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:28:01 --> Input Class Initialized
INFO - 2023-08-16 19:28:01 --> Language Class Initialized
ERROR - 2023-08-16 19:28:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:28:01 --> URI Class Initialized
INFO - 2023-08-16 19:28:01 --> Router Class Initialized
INFO - 2023-08-16 19:28:01 --> Output Class Initialized
INFO - 2023-08-16 19:28:01 --> Security Class Initialized
DEBUG - 2023-08-16 19:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:28:01 --> Input Class Initialized
INFO - 2023-08-16 19:28:01 --> Language Class Initialized
ERROR - 2023-08-16 19:28:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:28:01 --> Router Class Initialized
INFO - 2023-08-16 19:28:01 --> Hooks Class Initialized
INFO - 2023-08-16 19:28:01 --> Config Class Initialized
INFO - 2023-08-16 19:28:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:28:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:28:01 --> Utf8 Class Initialized
INFO - 2023-08-16 19:28:01 --> URI Class Initialized
INFO - 2023-08-16 19:28:01 --> Router Class Initialized
INFO - 2023-08-16 19:28:01 --> Output Class Initialized
INFO - 2023-08-16 19:28:01 --> Security Class Initialized
DEBUG - 2023-08-16 19:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:28:01 --> Input Class Initialized
INFO - 2023-08-16 19:28:01 --> Language Class Initialized
ERROR - 2023-08-16 19:28:01 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 19:28:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:28:02 --> Output Class Initialized
INFO - 2023-08-16 19:28:02 --> Utf8 Class Initialized
INFO - 2023-08-16 19:28:02 --> URI Class Initialized
INFO - 2023-08-16 19:28:02 --> Router Class Initialized
INFO - 2023-08-16 19:28:02 --> Security Class Initialized
INFO - 2023-08-16 19:28:03 --> Output Class Initialized
INFO - 2023-08-16 19:28:03 --> Security Class Initialized
DEBUG - 2023-08-16 19:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:28:03 --> Input Class Initialized
INFO - 2023-08-16 19:28:04 --> Input Class Initialized
INFO - 2023-08-16 19:28:04 --> Language Class Initialized
INFO - 2023-08-16 19:28:04 --> Language Class Initialized
ERROR - 2023-08-16 19:28:04 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-16 19:28:05 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:29:45 --> Config Class Initialized
INFO - 2023-08-16 19:29:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:29:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:29:45 --> Utf8 Class Initialized
INFO - 2023-08-16 19:29:45 --> URI Class Initialized
INFO - 2023-08-16 19:29:45 --> Router Class Initialized
INFO - 2023-08-16 19:29:45 --> Output Class Initialized
INFO - 2023-08-16 19:29:45 --> Security Class Initialized
DEBUG - 2023-08-16 19:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:29:45 --> Input Class Initialized
INFO - 2023-08-16 19:29:45 --> Language Class Initialized
INFO - 2023-08-16 19:29:45 --> Loader Class Initialized
INFO - 2023-08-16 19:29:45 --> Helper loaded: url_helper
INFO - 2023-08-16 19:29:45 --> Helper loaded: file_helper
INFO - 2023-08-16 19:29:46 --> Database Driver Class Initialized
INFO - 2023-08-16 19:29:46 --> Email Class Initialized
DEBUG - 2023-08-16 19:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:29:46 --> Controller Class Initialized
INFO - 2023-08-16 19:29:46 --> Model "Home_model" initialized
INFO - 2023-08-16 19:29:46 --> Helper loaded: form_helper
INFO - 2023-08-16 19:29:46 --> Form Validation Class Initialized
INFO - 2023-08-16 19:29:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:29:46 --> Final output sent to browser
DEBUG - 2023-08-16 19:29:46 --> Total execution time: 0.8575
INFO - 2023-08-16 19:29:47 --> Config Class Initialized
INFO - 2023-08-16 19:29:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:29:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:29:47 --> Utf8 Class Initialized
INFO - 2023-08-16 19:29:48 --> URI Class Initialized
INFO - 2023-08-16 19:29:48 --> Router Class Initialized
INFO - 2023-08-16 19:29:48 --> Output Class Initialized
INFO - 2023-08-16 19:29:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:29:48 --> Input Class Initialized
INFO - 2023-08-16 19:29:48 --> Language Class Initialized
ERROR - 2023-08-16 19:29:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:29:48 --> Config Class Initialized
INFO - 2023-08-16 19:29:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:29:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:29:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:29:48 --> URI Class Initialized
INFO - 2023-08-16 19:29:48 --> Router Class Initialized
INFO - 2023-08-16 19:29:48 --> Output Class Initialized
INFO - 2023-08-16 19:29:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:29:48 --> Input Class Initialized
INFO - 2023-08-16 19:29:48 --> Language Class Initialized
ERROR - 2023-08-16 19:29:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:29:48 --> Config Class Initialized
INFO - 2023-08-16 19:29:48 --> Config Class Initialized
INFO - 2023-08-16 19:29:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:29:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:29:48 --> Config Class Initialized
INFO - 2023-08-16 19:29:48 --> Hooks Class Initialized
INFO - 2023-08-16 19:29:48 --> Config Class Initialized
INFO - 2023-08-16 19:29:48 --> Hooks Class Initialized
INFO - 2023-08-16 19:29:48 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:29:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:29:48 --> URI Class Initialized
DEBUG - 2023-08-16 19:29:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:29:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:29:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:29:48 --> Router Class Initialized
INFO - 2023-08-16 19:29:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:29:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:29:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:29:48 --> URI Class Initialized
INFO - 2023-08-16 19:29:48 --> URI Class Initialized
INFO - 2023-08-16 19:29:48 --> Output Class Initialized
INFO - 2023-08-16 19:29:48 --> Router Class Initialized
INFO - 2023-08-16 19:29:48 --> Security Class Initialized
INFO - 2023-08-16 19:29:48 --> Router Class Initialized
DEBUG - 2023-08-16 19:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:29:48 --> URI Class Initialized
INFO - 2023-08-16 19:29:48 --> Output Class Initialized
INFO - 2023-08-16 19:29:48 --> Input Class Initialized
INFO - 2023-08-16 19:29:48 --> Output Class Initialized
INFO - 2023-08-16 19:29:49 --> Language Class Initialized
ERROR - 2023-08-16 19:29:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:29:49 --> Security Class Initialized
INFO - 2023-08-16 19:29:49 --> Router Class Initialized
INFO - 2023-08-16 19:29:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:29:49 --> Input Class Initialized
INFO - 2023-08-16 19:29:49 --> Language Class Initialized
ERROR - 2023-08-16 19:29:49 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:29:49 --> Output Class Initialized
INFO - 2023-08-16 19:29:49 --> Input Class Initialized
INFO - 2023-08-16 19:29:49 --> Security Class Initialized
DEBUG - 2023-08-16 19:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:29:49 --> Language Class Initialized
INFO - 2023-08-16 19:29:49 --> Input Class Initialized
ERROR - 2023-08-16 19:29:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:29:49 --> Language Class Initialized
ERROR - 2023-08-16 19:29:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:29:56 --> Config Class Initialized
INFO - 2023-08-16 19:29:56 --> Hooks Class Initialized
INFO - 2023-08-16 19:29:57 --> Config Class Initialized
INFO - 2023-08-16 19:29:57 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:29:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:29:58 --> Config Class Initialized
DEBUG - 2023-08-16 19:29:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:29:58 --> Utf8 Class Initialized
INFO - 2023-08-16 19:29:58 --> Config Class Initialized
INFO - 2023-08-16 19:29:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:29:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:29:58 --> Utf8 Class Initialized
INFO - 2023-08-16 19:29:58 --> URI Class Initialized
INFO - 2023-08-16 19:29:58 --> Router Class Initialized
INFO - 2023-08-16 19:29:58 --> Output Class Initialized
INFO - 2023-08-16 19:29:58 --> Security Class Initialized
DEBUG - 2023-08-16 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:29:58 --> Input Class Initialized
INFO - 2023-08-16 19:29:58 --> Language Class Initialized
ERROR - 2023-08-16 19:29:58 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:29:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:29:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:29:59 --> URI Class Initialized
INFO - 2023-08-16 19:29:59 --> Utf8 Class Initialized
INFO - 2023-08-16 19:29:59 --> Utf8 Class Initialized
INFO - 2023-08-16 19:29:59 --> Config Class Initialized
INFO - 2023-08-16 19:30:00 --> Hooks Class Initialized
INFO - 2023-08-16 19:30:00 --> URI Class Initialized
INFO - 2023-08-16 19:30:00 --> Router Class Initialized
INFO - 2023-08-16 19:30:00 --> URI Class Initialized
INFO - 2023-08-16 19:30:00 --> Output Class Initialized
INFO - 2023-08-16 19:30:00 --> Router Class Initialized
DEBUG - 2023-08-16 19:30:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:30:00 --> Config Class Initialized
INFO - 2023-08-16 19:30:00 --> Router Class Initialized
INFO - 2023-08-16 19:30:00 --> Output Class Initialized
INFO - 2023-08-16 19:30:00 --> Security Class Initialized
INFO - 2023-08-16 19:30:00 --> Utf8 Class Initialized
INFO - 2023-08-16 19:30:00 --> Hooks Class Initialized
INFO - 2023-08-16 19:30:00 --> Config Class Initialized
INFO - 2023-08-16 19:30:00 --> Output Class Initialized
DEBUG - 2023-08-16 19:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:30:00 --> Security Class Initialized
INFO - 2023-08-16 19:30:00 --> URI Class Initialized
INFO - 2023-08-16 19:30:00 --> Input Class Initialized
INFO - 2023-08-16 19:30:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:30:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:30:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:30:00 --> Security Class Initialized
DEBUG - 2023-08-16 19:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:30:00 --> Utf8 Class Initialized
INFO - 2023-08-16 19:30:00 --> Language Class Initialized
INFO - 2023-08-16 19:30:00 --> Input Class Initialized
INFO - 2023-08-16 19:30:00 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:30:00 --> Router Class Initialized
INFO - 2023-08-16 19:30:00 --> Language Class Initialized
ERROR - 2023-08-16 19:30:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:30:00 --> URI Class Initialized
INFO - 2023-08-16 19:30:00 --> Input Class Initialized
INFO - 2023-08-16 19:30:00 --> Output Class Initialized
INFO - 2023-08-16 19:30:00 --> Security Class Initialized
INFO - 2023-08-16 19:30:00 --> Router Class Initialized
ERROR - 2023-08-16 19:30:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:30:00 --> URI Class Initialized
INFO - 2023-08-16 19:30:00 --> Output Class Initialized
DEBUG - 2023-08-16 19:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:30:00 --> Input Class Initialized
INFO - 2023-08-16 19:30:00 --> Language Class Initialized
ERROR - 2023-08-16 19:30:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:30:00 --> Language Class Initialized
INFO - 2023-08-16 19:30:00 --> Security Class Initialized
ERROR - 2023-08-16 19:30:00 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 19:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:30:00 --> Router Class Initialized
INFO - 2023-08-16 19:30:00 --> Output Class Initialized
INFO - 2023-08-16 19:30:00 --> Input Class Initialized
INFO - 2023-08-16 19:30:00 --> Security Class Initialized
INFO - 2023-08-16 19:30:00 --> Language Class Initialized
ERROR - 2023-08-16 19:30:00 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 19:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:30:00 --> Input Class Initialized
INFO - 2023-08-16 19:30:00 --> Language Class Initialized
ERROR - 2023-08-16 19:30:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:30:40 --> Config Class Initialized
INFO - 2023-08-16 19:30:40 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:30:40 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:30:40 --> Utf8 Class Initialized
INFO - 2023-08-16 19:30:40 --> URI Class Initialized
INFO - 2023-08-16 19:30:40 --> Router Class Initialized
INFO - 2023-08-16 19:30:40 --> Output Class Initialized
INFO - 2023-08-16 19:30:40 --> Security Class Initialized
DEBUG - 2023-08-16 19:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:30:40 --> Input Class Initialized
INFO - 2023-08-16 19:30:40 --> Language Class Initialized
INFO - 2023-08-16 19:30:40 --> Loader Class Initialized
INFO - 2023-08-16 19:30:40 --> Helper loaded: url_helper
INFO - 2023-08-16 19:30:40 --> Helper loaded: file_helper
INFO - 2023-08-16 19:30:40 --> Database Driver Class Initialized
INFO - 2023-08-16 19:30:40 --> Email Class Initialized
DEBUG - 2023-08-16 19:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:30:40 --> Controller Class Initialized
INFO - 2023-08-16 19:30:40 --> Model "Home_model" initialized
INFO - 2023-08-16 19:30:40 --> Helper loaded: form_helper
INFO - 2023-08-16 19:30:40 --> Form Validation Class Initialized
INFO - 2023-08-16 19:30:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:30:40 --> Final output sent to browser
DEBUG - 2023-08-16 19:30:40 --> Total execution time: 0.4384
INFO - 2023-08-16 19:30:41 --> Config Class Initialized
INFO - 2023-08-16 19:30:42 --> Config Class Initialized
INFO - 2023-08-16 19:30:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:30:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:30:42 --> Hooks Class Initialized
INFO - 2023-08-16 19:30:42 --> Config Class Initialized
INFO - 2023-08-16 19:30:42 --> Hooks Class Initialized
INFO - 2023-08-16 19:30:42 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:30:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:30:42 --> Config Class Initialized
INFO - 2023-08-16 19:30:42 --> URI Class Initialized
DEBUG - 2023-08-16 19:30:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:30:42 --> Utf8 Class Initialized
INFO - 2023-08-16 19:30:42 --> Utf8 Class Initialized
INFO - 2023-08-16 19:30:42 --> Hooks Class Initialized
INFO - 2023-08-16 19:30:42 --> Config Class Initialized
INFO - 2023-08-16 19:30:42 --> URI Class Initialized
INFO - 2023-08-16 19:30:42 --> URI Class Initialized
INFO - 2023-08-16 19:30:42 --> Config Class Initialized
INFO - 2023-08-16 19:30:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:30:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:30:43 --> Utf8 Class Initialized
INFO - 2023-08-16 19:30:43 --> URI Class Initialized
INFO - 2023-08-16 19:30:43 --> Router Class Initialized
INFO - 2023-08-16 19:30:43 --> Output Class Initialized
INFO - 2023-08-16 19:30:43 --> Security Class Initialized
DEBUG - 2023-08-16 19:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:30:43 --> Input Class Initialized
INFO - 2023-08-16 19:30:43 --> Language Class Initialized
ERROR - 2023-08-16 19:30:43 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:30:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:30:43 --> Router Class Initialized
INFO - 2023-08-16 19:30:43 --> Router Class Initialized
INFO - 2023-08-16 19:30:43 --> Router Class Initialized
INFO - 2023-08-16 19:30:43 --> Hooks Class Initialized
INFO - 2023-08-16 19:30:43 --> Utf8 Class Initialized
INFO - 2023-08-16 19:30:43 --> URI Class Initialized
INFO - 2023-08-16 19:30:43 --> Output Class Initialized
INFO - 2023-08-16 19:30:43 --> Security Class Initialized
INFO - 2023-08-16 19:30:43 --> Output Class Initialized
DEBUG - 2023-08-16 19:30:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:30:43 --> Utf8 Class Initialized
INFO - 2023-08-16 19:30:43 --> Router Class Initialized
INFO - 2023-08-16 19:30:43 --> Output Class Initialized
INFO - 2023-08-16 19:30:43 --> Security Class Initialized
DEBUG - 2023-08-16 19:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:30:43 --> Input Class Initialized
INFO - 2023-08-16 19:30:43 --> Language Class Initialized
ERROR - 2023-08-16 19:30:43 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:30:43 --> Output Class Initialized
INFO - 2023-08-16 19:30:43 --> Input Class Initialized
INFO - 2023-08-16 19:30:43 --> Security Class Initialized
INFO - 2023-08-16 19:30:43 --> URI Class Initialized
INFO - 2023-08-16 19:30:43 --> Security Class Initialized
INFO - 2023-08-16 19:30:43 --> Language Class Initialized
DEBUG - 2023-08-16 19:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:30:43 --> Router Class Initialized
INFO - 2023-08-16 19:30:43 --> Input Class Initialized
INFO - 2023-08-16 19:30:43 --> Input Class Initialized
INFO - 2023-08-16 19:30:43 --> Language Class Initialized
ERROR - 2023-08-16 19:30:43 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:30:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:30:43 --> Output Class Initialized
INFO - 2023-08-16 19:30:43 --> Language Class Initialized
INFO - 2023-08-16 19:30:43 --> Security Class Initialized
ERROR - 2023-08-16 19:30:43 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:30:43 --> Input Class Initialized
INFO - 2023-08-16 19:30:43 --> Language Class Initialized
ERROR - 2023-08-16 19:30:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:31:35 --> Config Class Initialized
INFO - 2023-08-16 19:31:36 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:31:36 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:31:36 --> Utf8 Class Initialized
INFO - 2023-08-16 19:31:36 --> URI Class Initialized
INFO - 2023-08-16 19:31:36 --> Router Class Initialized
INFO - 2023-08-16 19:31:36 --> Output Class Initialized
INFO - 2023-08-16 19:31:36 --> Security Class Initialized
DEBUG - 2023-08-16 19:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:31:36 --> Input Class Initialized
INFO - 2023-08-16 19:31:36 --> Language Class Initialized
ERROR - 2023-08-16 19:31:36 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:31:36 --> Config Class Initialized
INFO - 2023-08-16 19:31:36 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:31:36 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:31:36 --> Config Class Initialized
INFO - 2023-08-16 19:31:36 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:31:36 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:31:36 --> Utf8 Class Initialized
INFO - 2023-08-16 19:31:36 --> URI Class Initialized
INFO - 2023-08-16 19:31:36 --> Router Class Initialized
INFO - 2023-08-16 19:31:36 --> Output Class Initialized
INFO - 2023-08-16 19:31:36 --> Security Class Initialized
DEBUG - 2023-08-16 19:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:31:36 --> Input Class Initialized
INFO - 2023-08-16 19:31:36 --> Language Class Initialized
ERROR - 2023-08-16 19:31:36 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:31:36 --> Utf8 Class Initialized
INFO - 2023-08-16 19:31:37 --> Config Class Initialized
INFO - 2023-08-16 19:31:37 --> Config Class Initialized
INFO - 2023-08-16 19:31:37 --> Hooks Class Initialized
INFO - 2023-08-16 19:31:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:31:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:31:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:31:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:31:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:31:37 --> URI Class Initialized
INFO - 2023-08-16 19:31:37 --> URI Class Initialized
INFO - 2023-08-16 19:31:37 --> Router Class Initialized
INFO - 2023-08-16 19:31:37 --> Router Class Initialized
INFO - 2023-08-16 19:31:37 --> Output Class Initialized
INFO - 2023-08-16 19:31:37 --> Output Class Initialized
INFO - 2023-08-16 19:31:37 --> Security Class Initialized
INFO - 2023-08-16 19:31:37 --> Security Class Initialized
DEBUG - 2023-08-16 19:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:31:37 --> Input Class Initialized
INFO - 2023-08-16 19:31:37 --> Input Class Initialized
INFO - 2023-08-16 19:31:37 --> Language Class Initialized
INFO - 2023-08-16 19:31:37 --> Language Class Initialized
ERROR - 2023-08-16 19:31:37 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-16 19:31:37 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:31:37 --> URI Class Initialized
INFO - 2023-08-16 19:31:37 --> Config Class Initialized
INFO - 2023-08-16 19:31:37 --> Config Class Initialized
INFO - 2023-08-16 19:31:37 --> Hooks Class Initialized
INFO - 2023-08-16 19:31:37 --> Router Class Initialized
INFO - 2023-08-16 19:31:37 --> Output Class Initialized
INFO - 2023-08-16 19:31:37 --> Security Class Initialized
DEBUG - 2023-08-16 19:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:31:37 --> Input Class Initialized
INFO - 2023-08-16 19:31:37 --> Language Class Initialized
ERROR - 2023-08-16 19:31:37 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:31:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:31:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:31:37 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:31:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:31:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:31:37 --> URI Class Initialized
INFO - 2023-08-16 19:31:37 --> Router Class Initialized
INFO - 2023-08-16 19:31:37 --> Output Class Initialized
INFO - 2023-08-16 19:31:37 --> Security Class Initialized
DEBUG - 2023-08-16 19:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:31:37 --> Input Class Initialized
INFO - 2023-08-16 19:31:37 --> Language Class Initialized
ERROR - 2023-08-16 19:31:37 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:31:37 --> URI Class Initialized
INFO - 2023-08-16 19:31:37 --> Router Class Initialized
INFO - 2023-08-16 19:31:37 --> Output Class Initialized
INFO - 2023-08-16 19:31:37 --> Security Class Initialized
DEBUG - 2023-08-16 19:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:31:37 --> Input Class Initialized
INFO - 2023-08-16 19:31:37 --> Language Class Initialized
ERROR - 2023-08-16 19:31:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:33:46 --> Config Class Initialized
INFO - 2023-08-16 19:33:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:33:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:33:46 --> Utf8 Class Initialized
INFO - 2023-08-16 19:33:46 --> URI Class Initialized
INFO - 2023-08-16 19:33:46 --> Router Class Initialized
INFO - 2023-08-16 19:33:46 --> Output Class Initialized
INFO - 2023-08-16 19:33:46 --> Security Class Initialized
DEBUG - 2023-08-16 19:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:33:46 --> Input Class Initialized
INFO - 2023-08-16 19:33:46 --> Language Class Initialized
INFO - 2023-08-16 19:33:46 --> Loader Class Initialized
INFO - 2023-08-16 19:33:46 --> Helper loaded: url_helper
INFO - 2023-08-16 19:33:46 --> Helper loaded: file_helper
INFO - 2023-08-16 19:33:46 --> Database Driver Class Initialized
INFO - 2023-08-16 19:33:46 --> Email Class Initialized
DEBUG - 2023-08-16 19:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:33:46 --> Controller Class Initialized
INFO - 2023-08-16 19:33:46 --> Model "Home_model" initialized
INFO - 2023-08-16 19:33:46 --> Helper loaded: form_helper
INFO - 2023-08-16 19:33:46 --> Form Validation Class Initialized
INFO - 2023-08-16 19:33:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:33:46 --> Final output sent to browser
DEBUG - 2023-08-16 19:33:46 --> Total execution time: 0.4653
INFO - 2023-08-16 19:33:47 --> Config Class Initialized
INFO - 2023-08-16 19:33:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:33:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:33:47 --> Utf8 Class Initialized
INFO - 2023-08-16 19:33:47 --> URI Class Initialized
INFO - 2023-08-16 19:33:47 --> Router Class Initialized
INFO - 2023-08-16 19:33:47 --> Output Class Initialized
INFO - 2023-08-16 19:33:47 --> Security Class Initialized
DEBUG - 2023-08-16 19:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:33:47 --> Input Class Initialized
INFO - 2023-08-16 19:33:47 --> Language Class Initialized
ERROR - 2023-08-16 19:33:47 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:33:47 --> Config Class Initialized
INFO - 2023-08-16 19:33:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:33:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:33:47 --> Utf8 Class Initialized
INFO - 2023-08-16 19:33:47 --> URI Class Initialized
INFO - 2023-08-16 19:33:47 --> Router Class Initialized
INFO - 2023-08-16 19:33:47 --> Output Class Initialized
INFO - 2023-08-16 19:33:47 --> Security Class Initialized
DEBUG - 2023-08-16 19:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:33:47 --> Input Class Initialized
INFO - 2023-08-16 19:33:47 --> Language Class Initialized
ERROR - 2023-08-16 19:33:47 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:33:47 --> Config Class Initialized
INFO - 2023-08-16 19:33:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:33:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:33:47 --> Utf8 Class Initialized
INFO - 2023-08-16 19:33:47 --> URI Class Initialized
INFO - 2023-08-16 19:33:47 --> Router Class Initialized
INFO - 2023-08-16 19:33:47 --> Output Class Initialized
INFO - 2023-08-16 19:33:47 --> Security Class Initialized
DEBUG - 2023-08-16 19:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:33:47 --> Input Class Initialized
INFO - 2023-08-16 19:33:47 --> Language Class Initialized
ERROR - 2023-08-16 19:33:47 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:33:47 --> Config Class Initialized
INFO - 2023-08-16 19:33:47 --> Config Class Initialized
INFO - 2023-08-16 19:33:47 --> Hooks Class Initialized
INFO - 2023-08-16 19:33:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:33:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:33:47 --> Utf8 Class Initialized
INFO - 2023-08-16 19:33:47 --> URI Class Initialized
INFO - 2023-08-16 19:33:47 --> Router Class Initialized
INFO - 2023-08-16 19:33:47 --> Output Class Initialized
INFO - 2023-08-16 19:33:47 --> Security Class Initialized
DEBUG - 2023-08-16 19:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:33:47 --> Input Class Initialized
INFO - 2023-08-16 19:33:47 --> Language Class Initialized
ERROR - 2023-08-16 19:33:47 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-16 19:33:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:33:47 --> Utf8 Class Initialized
INFO - 2023-08-16 19:33:47 --> URI Class Initialized
INFO - 2023-08-16 19:33:48 --> Router Class Initialized
INFO - 2023-08-16 19:33:48 --> Output Class Initialized
INFO - 2023-08-16 19:33:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:33:48 --> Input Class Initialized
INFO - 2023-08-16 19:33:48 --> Language Class Initialized
ERROR - 2023-08-16 19:33:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:33:48 --> Config Class Initialized
INFO - 2023-08-16 19:33:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:33:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:33:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:33:48 --> URI Class Initialized
INFO - 2023-08-16 19:33:48 --> Router Class Initialized
INFO - 2023-08-16 19:33:48 --> Output Class Initialized
INFO - 2023-08-16 19:33:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:33:48 --> Input Class Initialized
INFO - 2023-08-16 19:33:48 --> Language Class Initialized
ERROR - 2023-08-16 19:33:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:33:48 --> Config Class Initialized
INFO - 2023-08-16 19:33:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:33:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:33:48 --> Utf8 Class Initialized
INFO - 2023-08-16 19:33:48 --> URI Class Initialized
INFO - 2023-08-16 19:33:48 --> Router Class Initialized
INFO - 2023-08-16 19:33:48 --> Output Class Initialized
INFO - 2023-08-16 19:33:48 --> Security Class Initialized
DEBUG - 2023-08-16 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:33:48 --> Input Class Initialized
INFO - 2023-08-16 19:33:48 --> Language Class Initialized
ERROR - 2023-08-16 19:33:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:34:40 --> Config Class Initialized
INFO - 2023-08-16 19:34:40 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:34:40 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:34:40 --> Utf8 Class Initialized
INFO - 2023-08-16 19:34:40 --> URI Class Initialized
INFO - 2023-08-16 19:34:40 --> Router Class Initialized
INFO - 2023-08-16 19:34:40 --> Output Class Initialized
INFO - 2023-08-16 19:34:40 --> Security Class Initialized
DEBUG - 2023-08-16 19:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:34:40 --> Input Class Initialized
INFO - 2023-08-16 19:34:40 --> Language Class Initialized
INFO - 2023-08-16 19:34:40 --> Loader Class Initialized
INFO - 2023-08-16 19:34:40 --> Helper loaded: url_helper
INFO - 2023-08-16 19:34:40 --> Helper loaded: file_helper
INFO - 2023-08-16 19:34:40 --> Database Driver Class Initialized
INFO - 2023-08-16 19:34:40 --> Email Class Initialized
DEBUG - 2023-08-16 19:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:34:40 --> Controller Class Initialized
INFO - 2023-08-16 19:34:40 --> Model "Home_model" initialized
INFO - 2023-08-16 19:34:40 --> Helper loaded: form_helper
INFO - 2023-08-16 19:34:41 --> Form Validation Class Initialized
INFO - 2023-08-16 19:34:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:34:41 --> Final output sent to browser
DEBUG - 2023-08-16 19:34:41 --> Total execution time: 0.8351
INFO - 2023-08-16 19:34:41 --> Config Class Initialized
INFO - 2023-08-16 19:34:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:34:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:34:41 --> Utf8 Class Initialized
INFO - 2023-08-16 19:34:41 --> URI Class Initialized
INFO - 2023-08-16 19:34:41 --> Router Class Initialized
INFO - 2023-08-16 19:34:41 --> Output Class Initialized
INFO - 2023-08-16 19:34:41 --> Security Class Initialized
DEBUG - 2023-08-16 19:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:34:41 --> Input Class Initialized
INFO - 2023-08-16 19:34:41 --> Language Class Initialized
ERROR - 2023-08-16 19:34:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:34:41 --> Config Class Initialized
INFO - 2023-08-16 19:34:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:34:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:34:41 --> Utf8 Class Initialized
INFO - 2023-08-16 19:34:41 --> URI Class Initialized
INFO - 2023-08-16 19:34:41 --> Router Class Initialized
INFO - 2023-08-16 19:34:41 --> Output Class Initialized
INFO - 2023-08-16 19:34:41 --> Security Class Initialized
DEBUG - 2023-08-16 19:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:34:41 --> Input Class Initialized
INFO - 2023-08-16 19:34:41 --> Language Class Initialized
ERROR - 2023-08-16 19:34:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:34:41 --> Config Class Initialized
INFO - 2023-08-16 19:34:42 --> Hooks Class Initialized
INFO - 2023-08-16 19:34:42 --> Config Class Initialized
DEBUG - 2023-08-16 19:34:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:34:42 --> Utf8 Class Initialized
INFO - 2023-08-16 19:34:42 --> URI Class Initialized
INFO - 2023-08-16 19:34:42 --> Router Class Initialized
INFO - 2023-08-16 19:34:42 --> Output Class Initialized
INFO - 2023-08-16 19:34:42 --> Security Class Initialized
DEBUG - 2023-08-16 19:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:34:42 --> Input Class Initialized
INFO - 2023-08-16 19:34:42 --> Language Class Initialized
ERROR - 2023-08-16 19:34:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:34:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:34:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:34:42 --> Utf8 Class Initialized
INFO - 2023-08-16 19:34:42 --> URI Class Initialized
INFO - 2023-08-16 19:34:42 --> Router Class Initialized
INFO - 2023-08-16 19:34:42 --> Output Class Initialized
INFO - 2023-08-16 19:34:42 --> Security Class Initialized
DEBUG - 2023-08-16 19:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:34:42 --> Input Class Initialized
INFO - 2023-08-16 19:34:42 --> Language Class Initialized
ERROR - 2023-08-16 19:34:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:34:43 --> Config Class Initialized
INFO - 2023-08-16 19:34:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:34:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:34:43 --> Utf8 Class Initialized
INFO - 2023-08-16 19:34:43 --> URI Class Initialized
INFO - 2023-08-16 19:34:43 --> Router Class Initialized
INFO - 2023-08-16 19:34:43 --> Output Class Initialized
INFO - 2023-08-16 19:34:43 --> Security Class Initialized
DEBUG - 2023-08-16 19:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:34:43 --> Input Class Initialized
INFO - 2023-08-16 19:34:43 --> Language Class Initialized
ERROR - 2023-08-16 19:34:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:34:43 --> Config Class Initialized
INFO - 2023-08-16 19:34:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:34:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:34:43 --> Utf8 Class Initialized
INFO - 2023-08-16 19:34:43 --> URI Class Initialized
INFO - 2023-08-16 19:34:43 --> Router Class Initialized
INFO - 2023-08-16 19:34:43 --> Output Class Initialized
INFO - 2023-08-16 19:34:43 --> Security Class Initialized
DEBUG - 2023-08-16 19:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:34:43 --> Input Class Initialized
INFO - 2023-08-16 19:34:43 --> Language Class Initialized
ERROR - 2023-08-16 19:34:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:38:26 --> Config Class Initialized
INFO - 2023-08-16 19:38:26 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:38:26 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:38:26 --> Utf8 Class Initialized
INFO - 2023-08-16 19:38:26 --> URI Class Initialized
INFO - 2023-08-16 19:38:26 --> Router Class Initialized
INFO - 2023-08-16 19:38:26 --> Output Class Initialized
INFO - 2023-08-16 19:38:26 --> Security Class Initialized
DEBUG - 2023-08-16 19:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:38:26 --> Input Class Initialized
INFO - 2023-08-16 19:38:26 --> Language Class Initialized
INFO - 2023-08-16 19:38:26 --> Loader Class Initialized
INFO - 2023-08-16 19:38:26 --> Helper loaded: url_helper
INFO - 2023-08-16 19:38:26 --> Helper loaded: file_helper
INFO - 2023-08-16 19:38:26 --> Database Driver Class Initialized
INFO - 2023-08-16 19:38:26 --> Email Class Initialized
DEBUG - 2023-08-16 19:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:38:26 --> Controller Class Initialized
INFO - 2023-08-16 19:38:26 --> Model "Home_model" initialized
INFO - 2023-08-16 19:38:26 --> Helper loaded: form_helper
INFO - 2023-08-16 19:38:26 --> Form Validation Class Initialized
INFO - 2023-08-16 19:38:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:38:26 --> Final output sent to browser
DEBUG - 2023-08-16 19:38:26 --> Total execution time: 0.1092
INFO - 2023-08-16 19:38:26 --> Config Class Initialized
INFO - 2023-08-16 19:38:26 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:38:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:38:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:38:27 --> URI Class Initialized
INFO - 2023-08-16 19:38:27 --> Router Class Initialized
INFO - 2023-08-16 19:38:27 --> Output Class Initialized
INFO - 2023-08-16 19:38:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:38:27 --> Input Class Initialized
INFO - 2023-08-16 19:38:27 --> Language Class Initialized
ERROR - 2023-08-16 19:38:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:38:27 --> Config Class Initialized
INFO - 2023-08-16 19:38:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:38:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:38:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:38:27 --> URI Class Initialized
INFO - 2023-08-16 19:38:27 --> Router Class Initialized
INFO - 2023-08-16 19:38:27 --> Output Class Initialized
INFO - 2023-08-16 19:38:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:38:27 --> Input Class Initialized
INFO - 2023-08-16 19:38:27 --> Language Class Initialized
ERROR - 2023-08-16 19:38:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:38:27 --> Config Class Initialized
INFO - 2023-08-16 19:38:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:38:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:38:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:38:27 --> URI Class Initialized
INFO - 2023-08-16 19:38:27 --> Router Class Initialized
INFO - 2023-08-16 19:38:27 --> Output Class Initialized
INFO - 2023-08-16 19:38:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:38:27 --> Input Class Initialized
INFO - 2023-08-16 19:38:27 --> Language Class Initialized
ERROR - 2023-08-16 19:38:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:38:27 --> Config Class Initialized
INFO - 2023-08-16 19:38:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:38:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:38:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:38:27 --> URI Class Initialized
INFO - 2023-08-16 19:38:27 --> Router Class Initialized
INFO - 2023-08-16 19:38:27 --> Output Class Initialized
INFO - 2023-08-16 19:38:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:38:27 --> Input Class Initialized
INFO - 2023-08-16 19:38:27 --> Language Class Initialized
ERROR - 2023-08-16 19:38:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:38:27 --> Config Class Initialized
INFO - 2023-08-16 19:38:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:38:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:38:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:38:27 --> URI Class Initialized
INFO - 2023-08-16 19:38:27 --> Router Class Initialized
INFO - 2023-08-16 19:38:27 --> Output Class Initialized
INFO - 2023-08-16 19:38:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:38:27 --> Input Class Initialized
INFO - 2023-08-16 19:38:27 --> Language Class Initialized
ERROR - 2023-08-16 19:38:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:38:27 --> Config Class Initialized
INFO - 2023-08-16 19:38:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:38:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:38:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:38:27 --> URI Class Initialized
INFO - 2023-08-16 19:38:27 --> Router Class Initialized
INFO - 2023-08-16 19:38:27 --> Output Class Initialized
INFO - 2023-08-16 19:38:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:38:27 --> Input Class Initialized
INFO - 2023-08-16 19:38:27 --> Language Class Initialized
ERROR - 2023-08-16 19:38:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:38:27 --> Config Class Initialized
INFO - 2023-08-16 19:38:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:38:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:38:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:38:27 --> URI Class Initialized
INFO - 2023-08-16 19:38:27 --> Router Class Initialized
INFO - 2023-08-16 19:38:27 --> Output Class Initialized
INFO - 2023-08-16 19:38:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:38:27 --> Input Class Initialized
INFO - 2023-08-16 19:38:27 --> Language Class Initialized
ERROR - 2023-08-16 19:38:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:38:27 --> Config Class Initialized
INFO - 2023-08-16 19:38:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:38:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:38:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:38:27 --> URI Class Initialized
INFO - 2023-08-16 19:38:27 --> Router Class Initialized
INFO - 2023-08-16 19:38:27 --> Output Class Initialized
INFO - 2023-08-16 19:38:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:38:27 --> Input Class Initialized
INFO - 2023-08-16 19:38:27 --> Language Class Initialized
ERROR - 2023-08-16 19:38:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:38:27 --> Config Class Initialized
INFO - 2023-08-16 19:38:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:38:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:38:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:38:27 --> URI Class Initialized
INFO - 2023-08-16 19:38:27 --> Router Class Initialized
INFO - 2023-08-16 19:38:27 --> Output Class Initialized
INFO - 2023-08-16 19:38:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:38:27 --> Input Class Initialized
INFO - 2023-08-16 19:38:27 --> Language Class Initialized
ERROR - 2023-08-16 19:38:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:39:22 --> Config Class Initialized
INFO - 2023-08-16 19:39:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:39:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:39:22 --> Utf8 Class Initialized
INFO - 2023-08-16 19:39:22 --> URI Class Initialized
INFO - 2023-08-16 19:39:22 --> Router Class Initialized
INFO - 2023-08-16 19:39:22 --> Output Class Initialized
INFO - 2023-08-16 19:39:22 --> Security Class Initialized
DEBUG - 2023-08-16 19:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:39:22 --> Input Class Initialized
INFO - 2023-08-16 19:39:22 --> Language Class Initialized
ERROR - 2023-08-16 19:39:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:39:22 --> Config Class Initialized
INFO - 2023-08-16 19:39:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:39:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:39:22 --> Utf8 Class Initialized
INFO - 2023-08-16 19:39:22 --> URI Class Initialized
INFO - 2023-08-16 19:39:22 --> Router Class Initialized
INFO - 2023-08-16 19:39:22 --> Output Class Initialized
INFO - 2023-08-16 19:39:22 --> Security Class Initialized
DEBUG - 2023-08-16 19:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:39:22 --> Input Class Initialized
INFO - 2023-08-16 19:39:22 --> Language Class Initialized
ERROR - 2023-08-16 19:39:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:39:22 --> Config Class Initialized
INFO - 2023-08-16 19:39:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:39:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:39:22 --> Utf8 Class Initialized
INFO - 2023-08-16 19:39:22 --> URI Class Initialized
INFO - 2023-08-16 19:39:22 --> Router Class Initialized
INFO - 2023-08-16 19:39:22 --> Output Class Initialized
INFO - 2023-08-16 19:39:22 --> Security Class Initialized
DEBUG - 2023-08-16 19:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:39:22 --> Input Class Initialized
INFO - 2023-08-16 19:39:22 --> Language Class Initialized
ERROR - 2023-08-16 19:39:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:39:22 --> Config Class Initialized
INFO - 2023-08-16 19:39:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:39:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:39:22 --> Utf8 Class Initialized
INFO - 2023-08-16 19:39:22 --> URI Class Initialized
INFO - 2023-08-16 19:39:22 --> Router Class Initialized
INFO - 2023-08-16 19:39:22 --> Output Class Initialized
INFO - 2023-08-16 19:39:22 --> Security Class Initialized
DEBUG - 2023-08-16 19:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:39:22 --> Input Class Initialized
INFO - 2023-08-16 19:39:22 --> Language Class Initialized
ERROR - 2023-08-16 19:39:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:39:22 --> Config Class Initialized
INFO - 2023-08-16 19:39:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:39:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:39:22 --> Utf8 Class Initialized
INFO - 2023-08-16 19:39:22 --> URI Class Initialized
INFO - 2023-08-16 19:39:22 --> Router Class Initialized
INFO - 2023-08-16 19:39:22 --> Output Class Initialized
INFO - 2023-08-16 19:39:22 --> Security Class Initialized
DEBUG - 2023-08-16 19:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:39:22 --> Input Class Initialized
INFO - 2023-08-16 19:39:22 --> Language Class Initialized
ERROR - 2023-08-16 19:39:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:39:22 --> Config Class Initialized
INFO - 2023-08-16 19:39:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:39:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:39:22 --> Utf8 Class Initialized
INFO - 2023-08-16 19:39:22 --> URI Class Initialized
INFO - 2023-08-16 19:39:22 --> Router Class Initialized
INFO - 2023-08-16 19:39:22 --> Output Class Initialized
INFO - 2023-08-16 19:39:22 --> Security Class Initialized
DEBUG - 2023-08-16 19:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:39:22 --> Input Class Initialized
INFO - 2023-08-16 19:39:22 --> Language Class Initialized
ERROR - 2023-08-16 19:39:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:39:22 --> Config Class Initialized
INFO - 2023-08-16 19:39:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:39:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:39:22 --> Utf8 Class Initialized
INFO - 2023-08-16 19:39:22 --> URI Class Initialized
INFO - 2023-08-16 19:39:22 --> Router Class Initialized
INFO - 2023-08-16 19:39:22 --> Output Class Initialized
INFO - 2023-08-16 19:39:22 --> Security Class Initialized
DEBUG - 2023-08-16 19:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:39:22 --> Input Class Initialized
INFO - 2023-08-16 19:39:22 --> Language Class Initialized
ERROR - 2023-08-16 19:39:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 19:42:44 --> Config Class Initialized
INFO - 2023-08-16 19:42:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:42:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:42:44 --> Utf8 Class Initialized
INFO - 2023-08-16 19:42:44 --> URI Class Initialized
INFO - 2023-08-16 19:42:44 --> Router Class Initialized
INFO - 2023-08-16 19:42:44 --> Output Class Initialized
INFO - 2023-08-16 19:42:44 --> Security Class Initialized
DEBUG - 2023-08-16 19:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:42:44 --> Input Class Initialized
INFO - 2023-08-16 19:42:44 --> Language Class Initialized
INFO - 2023-08-16 19:42:44 --> Loader Class Initialized
INFO - 2023-08-16 19:42:44 --> Helper loaded: url_helper
INFO - 2023-08-16 19:42:44 --> Helper loaded: file_helper
INFO - 2023-08-16 19:42:44 --> Database Driver Class Initialized
INFO - 2023-08-16 19:42:44 --> Email Class Initialized
DEBUG - 2023-08-16 19:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:42:44 --> Controller Class Initialized
INFO - 2023-08-16 19:42:44 --> Model "Home_model" initialized
INFO - 2023-08-16 19:42:44 --> Helper loaded: form_helper
INFO - 2023-08-16 19:42:44 --> Form Validation Class Initialized
INFO - 2023-08-16 19:42:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:42:45 --> Final output sent to browser
DEBUG - 2023-08-16 19:42:45 --> Total execution time: 0.8773
INFO - 2023-08-16 19:42:46 --> Config Class Initialized
INFO - 2023-08-16 19:42:46 --> Config Class Initialized
INFO - 2023-08-16 19:42:46 --> Hooks Class Initialized
INFO - 2023-08-16 19:42:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:42:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:42:46 --> Utf8 Class Initialized
INFO - 2023-08-16 19:42:46 --> URI Class Initialized
INFO - 2023-08-16 19:42:46 --> Router Class Initialized
INFO - 2023-08-16 19:42:46 --> Output Class Initialized
INFO - 2023-08-16 19:42:46 --> Security Class Initialized
DEBUG - 2023-08-16 19:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:42:46 --> Input Class Initialized
INFO - 2023-08-16 19:42:46 --> Language Class Initialized
ERROR - 2023-08-16 19:42:46 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:42:46 --> Config Class Initialized
INFO - 2023-08-16 19:42:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:42:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:42:46 --> Config Class Initialized
INFO - 2023-08-16 19:42:46 --> Hooks Class Initialized
INFO - 2023-08-16 19:42:46 --> Utf8 Class Initialized
INFO - 2023-08-16 19:42:46 --> Config Class Initialized
INFO - 2023-08-16 19:42:46 --> URI Class Initialized
DEBUG - 2023-08-16 19:42:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:42:46 --> Config Class Initialized
INFO - 2023-08-16 19:42:46 --> Router Class Initialized
DEBUG - 2023-08-16 19:42:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:42:46 --> Hooks Class Initialized
INFO - 2023-08-16 19:42:46 --> Output Class Initialized
INFO - 2023-08-16 19:42:46 --> Security Class Initialized
DEBUG - 2023-08-16 19:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:42:46 --> Input Class Initialized
INFO - 2023-08-16 19:42:46 --> Language Class Initialized
ERROR - 2023-08-16 19:42:46 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:42:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:42:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:42:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:42:46 --> Utf8 Class Initialized
INFO - 2023-08-16 19:42:46 --> Utf8 Class Initialized
INFO - 2023-08-16 19:42:46 --> URI Class Initialized
INFO - 2023-08-16 19:42:46 --> URI Class Initialized
INFO - 2023-08-16 19:42:46 --> Utf8 Class Initialized
INFO - 2023-08-16 19:42:46 --> Utf8 Class Initialized
INFO - 2023-08-16 19:42:46 --> URI Class Initialized
INFO - 2023-08-16 19:42:46 --> Router Class Initialized
INFO - 2023-08-16 19:42:47 --> Router Class Initialized
INFO - 2023-08-16 19:42:47 --> URI Class Initialized
INFO - 2023-08-16 19:42:47 --> Router Class Initialized
INFO - 2023-08-16 19:42:47 --> Output Class Initialized
INFO - 2023-08-16 19:42:47 --> Security Class Initialized
DEBUG - 2023-08-16 19:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:42:47 --> Input Class Initialized
INFO - 2023-08-16 19:42:47 --> Language Class Initialized
ERROR - 2023-08-16 19:42:47 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:42:47 --> Output Class Initialized
INFO - 2023-08-16 19:42:47 --> Output Class Initialized
INFO - 2023-08-16 19:42:47 --> Router Class Initialized
INFO - 2023-08-16 19:42:47 --> Security Class Initialized
DEBUG - 2023-08-16 19:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:42:47 --> Security Class Initialized
INFO - 2023-08-16 19:42:47 --> Output Class Initialized
INFO - 2023-08-16 19:42:47 --> Input Class Initialized
INFO - 2023-08-16 19:42:47 --> Security Class Initialized
INFO - 2023-08-16 19:42:47 --> Language Class Initialized
DEBUG - 2023-08-16 19:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:42:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 19:42:47 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:42:47 --> Input Class Initialized
INFO - 2023-08-16 19:42:47 --> Language Class Initialized
INFO - 2023-08-16 19:42:47 --> Input Class Initialized
ERROR - 2023-08-16 19:42:47 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:42:47 --> Language Class Initialized
ERROR - 2023-08-16 19:42:47 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:43:30 --> Config Class Initialized
INFO - 2023-08-16 19:43:30 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:43:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:43:30 --> Utf8 Class Initialized
INFO - 2023-08-16 19:43:30 --> URI Class Initialized
INFO - 2023-08-16 19:43:30 --> Router Class Initialized
INFO - 2023-08-16 19:43:30 --> Output Class Initialized
INFO - 2023-08-16 19:43:30 --> Security Class Initialized
DEBUG - 2023-08-16 19:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:43:30 --> Input Class Initialized
INFO - 2023-08-16 19:43:30 --> Language Class Initialized
INFO - 2023-08-16 19:43:30 --> Loader Class Initialized
INFO - 2023-08-16 19:43:30 --> Helper loaded: url_helper
INFO - 2023-08-16 19:43:30 --> Helper loaded: file_helper
INFO - 2023-08-16 19:43:30 --> Database Driver Class Initialized
INFO - 2023-08-16 19:43:30 --> Email Class Initialized
DEBUG - 2023-08-16 19:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:43:30 --> Controller Class Initialized
INFO - 2023-08-16 19:43:30 --> Model "Home_model" initialized
INFO - 2023-08-16 19:43:30 --> Helper loaded: form_helper
INFO - 2023-08-16 19:43:30 --> Form Validation Class Initialized
INFO - 2023-08-16 19:43:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:43:30 --> Final output sent to browser
DEBUG - 2023-08-16 19:43:31 --> Total execution time: 0.5703
INFO - 2023-08-16 19:43:31 --> Config Class Initialized
INFO - 2023-08-16 19:43:31 --> Hooks Class Initialized
INFO - 2023-08-16 19:43:31 --> Config Class Initialized
DEBUG - 2023-08-16 19:43:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:43:31 --> Utf8 Class Initialized
INFO - 2023-08-16 19:43:31 --> Hooks Class Initialized
INFO - 2023-08-16 19:43:31 --> URI Class Initialized
INFO - 2023-08-16 19:43:31 --> Router Class Initialized
DEBUG - 2023-08-16 19:43:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:43:32 --> Output Class Initialized
INFO - 2023-08-16 19:43:32 --> Utf8 Class Initialized
INFO - 2023-08-16 19:43:32 --> Security Class Initialized
INFO - 2023-08-16 19:43:32 --> URI Class Initialized
DEBUG - 2023-08-16 19:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:43:32 --> Router Class Initialized
INFO - 2023-08-16 19:43:32 --> Input Class Initialized
INFO - 2023-08-16 19:43:32 --> Output Class Initialized
INFO - 2023-08-16 19:43:32 --> Language Class Initialized
INFO - 2023-08-16 19:43:32 --> Security Class Initialized
DEBUG - 2023-08-16 19:43:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 19:43:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:43:32 --> Input Class Initialized
INFO - 2023-08-16 19:43:32 --> Language Class Initialized
ERROR - 2023-08-16 19:43:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:43:32 --> Config Class Initialized
INFO - 2023-08-16 19:43:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:43:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:43:32 --> Utf8 Class Initialized
INFO - 2023-08-16 19:43:32 --> URI Class Initialized
INFO - 2023-08-16 19:43:32 --> Router Class Initialized
INFO - 2023-08-16 19:43:32 --> Output Class Initialized
INFO - 2023-08-16 19:43:32 --> Security Class Initialized
DEBUG - 2023-08-16 19:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:43:32 --> Input Class Initialized
INFO - 2023-08-16 19:43:32 --> Language Class Initialized
ERROR - 2023-08-16 19:43:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:43:32 --> Config Class Initialized
INFO - 2023-08-16 19:43:32 --> Hooks Class Initialized
INFO - 2023-08-16 19:43:32 --> Config Class Initialized
INFO - 2023-08-16 19:43:32 --> Config Class Initialized
DEBUG - 2023-08-16 19:43:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:43:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:43:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:43:32 --> Utf8 Class Initialized
INFO - 2023-08-16 19:43:32 --> Hooks Class Initialized
INFO - 2023-08-16 19:43:32 --> URI Class Initialized
DEBUG - 2023-08-16 19:43:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:43:32 --> Utf8 Class Initialized
INFO - 2023-08-16 19:43:32 --> Utf8 Class Initialized
INFO - 2023-08-16 19:43:32 --> URI Class Initialized
INFO - 2023-08-16 19:43:32 --> URI Class Initialized
INFO - 2023-08-16 19:43:32 --> Router Class Initialized
INFO - 2023-08-16 19:43:32 --> Router Class Initialized
INFO - 2023-08-16 19:43:32 --> Output Class Initialized
INFO - 2023-08-16 19:43:32 --> Output Class Initialized
INFO - 2023-08-16 19:43:32 --> Security Class Initialized
INFO - 2023-08-16 19:43:32 --> Router Class Initialized
INFO - 2023-08-16 19:43:32 --> Security Class Initialized
DEBUG - 2023-08-16 19:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:43:32 --> Output Class Initialized
DEBUG - 2023-08-16 19:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:43:32 --> Security Class Initialized
INFO - 2023-08-16 19:43:32 --> Input Class Initialized
INFO - 2023-08-16 19:43:32 --> Input Class Initialized
INFO - 2023-08-16 19:43:32 --> Language Class Initialized
INFO - 2023-08-16 19:43:33 --> Language Class Initialized
DEBUG - 2023-08-16 19:43:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 19:43:33 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-16 19:43:33 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:43:33 --> Input Class Initialized
INFO - 2023-08-16 19:43:33 --> Language Class Initialized
ERROR - 2023-08-16 19:43:33 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:44:23 --> Config Class Initialized
INFO - 2023-08-16 19:44:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:44:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:44:23 --> Utf8 Class Initialized
INFO - 2023-08-16 19:44:23 --> URI Class Initialized
INFO - 2023-08-16 19:44:23 --> Router Class Initialized
INFO - 2023-08-16 19:44:23 --> Output Class Initialized
INFO - 2023-08-16 19:44:23 --> Security Class Initialized
DEBUG - 2023-08-16 19:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:44:23 --> Input Class Initialized
INFO - 2023-08-16 19:44:23 --> Language Class Initialized
INFO - 2023-08-16 19:44:23 --> Loader Class Initialized
INFO - 2023-08-16 19:44:23 --> Helper loaded: url_helper
INFO - 2023-08-16 19:44:23 --> Helper loaded: file_helper
INFO - 2023-08-16 19:44:23 --> Database Driver Class Initialized
INFO - 2023-08-16 19:44:23 --> Email Class Initialized
DEBUG - 2023-08-16 19:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:44:23 --> Controller Class Initialized
INFO - 2023-08-16 19:44:23 --> Model "Home_model" initialized
INFO - 2023-08-16 19:44:23 --> Helper loaded: form_helper
INFO - 2023-08-16 19:44:23 --> Form Validation Class Initialized
INFO - 2023-08-16 19:44:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-16 19:44:23 --> Final output sent to browser
DEBUG - 2023-08-16 19:44:23 --> Total execution time: 0.4678
INFO - 2023-08-16 19:44:24 --> Config Class Initialized
INFO - 2023-08-16 19:44:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:44:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:44:24 --> Utf8 Class Initialized
INFO - 2023-08-16 19:44:24 --> URI Class Initialized
INFO - 2023-08-16 19:44:24 --> Router Class Initialized
INFO - 2023-08-16 19:44:25 --> Output Class Initialized
INFO - 2023-08-16 19:44:25 --> Security Class Initialized
DEBUG - 2023-08-16 19:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:44:25 --> Input Class Initialized
INFO - 2023-08-16 19:44:25 --> Language Class Initialized
ERROR - 2023-08-16 19:44:25 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:44:25 --> Config Class Initialized
INFO - 2023-08-16 19:44:25 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:44:25 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:44:25 --> Config Class Initialized
INFO - 2023-08-16 19:44:25 --> Hooks Class Initialized
INFO - 2023-08-16 19:44:25 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:44:25 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:44:25 --> Utf8 Class Initialized
INFO - 2023-08-16 19:44:25 --> URI Class Initialized
INFO - 2023-08-16 19:44:25 --> Config Class Initialized
INFO - 2023-08-16 19:44:25 --> Config Class Initialized
INFO - 2023-08-16 19:44:25 --> URI Class Initialized
INFO - 2023-08-16 19:44:25 --> Hooks Class Initialized
INFO - 2023-08-16 19:44:25 --> Router Class Initialized
INFO - 2023-08-16 19:44:25 --> Hooks Class Initialized
INFO - 2023-08-16 19:44:25 --> Config Class Initialized
DEBUG - 2023-08-16 19:44:25 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:44:25 --> Router Class Initialized
DEBUG - 2023-08-16 19:44:25 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:44:25 --> Output Class Initialized
INFO - 2023-08-16 19:44:25 --> Hooks Class Initialized
INFO - 2023-08-16 19:44:25 --> Output Class Initialized
INFO - 2023-08-16 19:44:25 --> Utf8 Class Initialized
INFO - 2023-08-16 19:44:25 --> Utf8 Class Initialized
INFO - 2023-08-16 19:44:25 --> URI Class Initialized
INFO - 2023-08-16 19:44:25 --> Router Class Initialized
INFO - 2023-08-16 19:44:25 --> Output Class Initialized
INFO - 2023-08-16 19:44:25 --> Security Class Initialized
DEBUG - 2023-08-16 19:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:44:25 --> Input Class Initialized
INFO - 2023-08-16 19:44:25 --> Language Class Initialized
ERROR - 2023-08-16 19:44:25 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:44:25 --> Security Class Initialized
INFO - 2023-08-16 19:44:25 --> URI Class Initialized
INFO - 2023-08-16 19:44:25 --> Security Class Initialized
DEBUG - 2023-08-16 19:44:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:44:25 --> Input Class Initialized
INFO - 2023-08-16 19:44:25 --> Router Class Initialized
INFO - 2023-08-16 19:44:25 --> Utf8 Class Initialized
INFO - 2023-08-16 19:44:25 --> Input Class Initialized
INFO - 2023-08-16 19:44:25 --> Language Class Initialized
ERROR - 2023-08-16 19:44:25 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:44:25 --> Language Class Initialized
INFO - 2023-08-16 19:44:25 --> URI Class Initialized
ERROR - 2023-08-16 19:44:25 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:44:25 --> Router Class Initialized
INFO - 2023-08-16 19:44:25 --> Output Class Initialized
INFO - 2023-08-16 19:44:25 --> Security Class Initialized
INFO - 2023-08-16 19:44:25 --> Output Class Initialized
DEBUG - 2023-08-16 19:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:44:25 --> Security Class Initialized
INFO - 2023-08-16 19:44:25 --> Input Class Initialized
DEBUG - 2023-08-16 19:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:44:26 --> Language Class Initialized
INFO - 2023-08-16 19:44:26 --> Input Class Initialized
ERROR - 2023-08-16 19:44:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:44:26 --> Language Class Initialized
ERROR - 2023-08-16 19:44:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-16 19:46:21 --> Config Class Initialized
INFO - 2023-08-16 19:46:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:46:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:46:22 --> Utf8 Class Initialized
INFO - 2023-08-16 19:46:22 --> URI Class Initialized
INFO - 2023-08-16 19:46:22 --> Router Class Initialized
INFO - 2023-08-16 19:46:22 --> Output Class Initialized
INFO - 2023-08-16 19:46:22 --> Security Class Initialized
DEBUG - 2023-08-16 19:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:46:22 --> Input Class Initialized
INFO - 2023-08-16 19:46:22 --> Language Class Initialized
INFO - 2023-08-16 19:46:22 --> Loader Class Initialized
INFO - 2023-08-16 19:46:22 --> Helper loaded: url_helper
INFO - 2023-08-16 19:46:22 --> Helper loaded: file_helper
INFO - 2023-08-16 19:46:22 --> Database Driver Class Initialized
INFO - 2023-08-16 19:46:22 --> Email Class Initialized
DEBUG - 2023-08-16 19:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:46:22 --> Controller Class Initialized
INFO - 2023-08-16 19:46:22 --> Model "Home_model" initialized
INFO - 2023-08-16 19:46:22 --> Helper loaded: form_helper
INFO - 2023-08-16 19:46:22 --> Form Validation Class Initialized
INFO - 2023-08-16 19:46:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 19:46:22 --> Final output sent to browser
DEBUG - 2023-08-16 19:46:22 --> Total execution time: 0.4489
INFO - 2023-08-16 19:46:23 --> Config Class Initialized
INFO - 2023-08-16 19:46:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:46:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:46:23 --> Utf8 Class Initialized
INFO - 2023-08-16 19:46:23 --> URI Class Initialized
INFO - 2023-08-16 19:46:23 --> Router Class Initialized
INFO - 2023-08-16 19:46:23 --> Output Class Initialized
INFO - 2023-08-16 19:46:23 --> Security Class Initialized
DEBUG - 2023-08-16 19:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:46:23 --> Input Class Initialized
INFO - 2023-08-16 19:46:23 --> Language Class Initialized
ERROR - 2023-08-16 19:46:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:46:23 --> Config Class Initialized
INFO - 2023-08-16 19:46:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:46:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:46:23 --> Utf8 Class Initialized
INFO - 2023-08-16 19:46:23 --> URI Class Initialized
INFO - 2023-08-16 19:46:23 --> Router Class Initialized
INFO - 2023-08-16 19:46:23 --> Output Class Initialized
INFO - 2023-08-16 19:46:23 --> Security Class Initialized
DEBUG - 2023-08-16 19:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:46:23 --> Input Class Initialized
INFO - 2023-08-16 19:46:23 --> Language Class Initialized
ERROR - 2023-08-16 19:46:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:46:23 --> Config Class Initialized
INFO - 2023-08-16 19:46:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:46:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:46:23 --> Config Class Initialized
INFO - 2023-08-16 19:46:23 --> Config Class Initialized
INFO - 2023-08-16 19:46:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:46:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:46:23 --> Utf8 Class Initialized
INFO - 2023-08-16 19:46:23 --> URI Class Initialized
INFO - 2023-08-16 19:46:23 --> Router Class Initialized
INFO - 2023-08-16 19:46:23 --> Output Class Initialized
INFO - 2023-08-16 19:46:23 --> Security Class Initialized
DEBUG - 2023-08-16 19:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:46:23 --> Input Class Initialized
INFO - 2023-08-16 19:46:23 --> Language Class Initialized
ERROR - 2023-08-16 19:46:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:46:23 --> Utf8 Class Initialized
INFO - 2023-08-16 19:46:23 --> URI Class Initialized
INFO - 2023-08-16 19:46:24 --> Hooks Class Initialized
INFO - 2023-08-16 19:46:24 --> Router Class Initialized
DEBUG - 2023-08-16 19:46:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:46:24 --> Output Class Initialized
INFO - 2023-08-16 19:46:24 --> Utf8 Class Initialized
INFO - 2023-08-16 19:46:24 --> Security Class Initialized
INFO - 2023-08-16 19:46:24 --> URI Class Initialized
DEBUG - 2023-08-16 19:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:46:24 --> Router Class Initialized
INFO - 2023-08-16 19:46:24 --> Output Class Initialized
INFO - 2023-08-16 19:46:24 --> Input Class Initialized
INFO - 2023-08-16 19:46:24 --> Security Class Initialized
DEBUG - 2023-08-16 19:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:46:24 --> Language Class Initialized
INFO - 2023-08-16 19:46:24 --> Input Class Initialized
INFO - 2023-08-16 19:46:24 --> Language Class Initialized
ERROR - 2023-08-16 19:46:24 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 19:46:24 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:50:13 --> Config Class Initialized
INFO - 2023-08-16 19:50:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:50:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:13 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:13 --> URI Class Initialized
INFO - 2023-08-16 19:50:13 --> Router Class Initialized
INFO - 2023-08-16 19:50:13 --> Output Class Initialized
INFO - 2023-08-16 19:50:13 --> Security Class Initialized
DEBUG - 2023-08-16 19:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:13 --> Input Class Initialized
INFO - 2023-08-16 19:50:13 --> Language Class Initialized
INFO - 2023-08-16 19:50:13 --> Loader Class Initialized
INFO - 2023-08-16 19:50:13 --> Helper loaded: url_helper
INFO - 2023-08-16 19:50:13 --> Helper loaded: file_helper
INFO - 2023-08-16 19:50:13 --> Database Driver Class Initialized
INFO - 2023-08-16 19:50:13 --> Email Class Initialized
DEBUG - 2023-08-16 19:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:50:13 --> Controller Class Initialized
INFO - 2023-08-16 19:50:13 --> Model "Home_model" initialized
INFO - 2023-08-16 19:50:13 --> Helper loaded: form_helper
INFO - 2023-08-16 19:50:13 --> Form Validation Class Initialized
INFO - 2023-08-16 19:50:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 19:50:13 --> Final output sent to browser
DEBUG - 2023-08-16 19:50:14 --> Total execution time: 0.5631
INFO - 2023-08-16 19:50:14 --> Config Class Initialized
INFO - 2023-08-16 19:50:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:50:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:14 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:14 --> URI Class Initialized
INFO - 2023-08-16 19:50:14 --> Router Class Initialized
INFO - 2023-08-16 19:50:14 --> Output Class Initialized
INFO - 2023-08-16 19:50:14 --> Security Class Initialized
DEBUG - 2023-08-16 19:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:14 --> Input Class Initialized
INFO - 2023-08-16 19:50:14 --> Language Class Initialized
ERROR - 2023-08-16 19:50:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:50:15 --> Config Class Initialized
INFO - 2023-08-16 19:50:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:50:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:15 --> Config Class Initialized
INFO - 2023-08-16 19:50:15 --> Config Class Initialized
INFO - 2023-08-16 19:50:15 --> Hooks Class Initialized
INFO - 2023-08-16 19:50:15 --> Config Class Initialized
INFO - 2023-08-16 19:50:15 --> URI Class Initialized
INFO - 2023-08-16 19:50:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:50:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:50:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:15 --> Config Class Initialized
DEBUG - 2023-08-16 19:50:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:15 --> Router Class Initialized
INFO - 2023-08-16 19:50:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:15 --> Hooks Class Initialized
INFO - 2023-08-16 19:50:15 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:15 --> URI Class Initialized
INFO - 2023-08-16 19:50:15 --> Output Class Initialized
INFO - 2023-08-16 19:50:15 --> URI Class Initialized
INFO - 2023-08-16 19:50:15 --> URI Class Initialized
INFO - 2023-08-16 19:50:15 --> Router Class Initialized
INFO - 2023-08-16 19:50:15 --> Output Class Initialized
INFO - 2023-08-16 19:50:15 --> Security Class Initialized
DEBUG - 2023-08-16 19:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:15 --> Input Class Initialized
INFO - 2023-08-16 19:50:15 --> Language Class Initialized
ERROR - 2023-08-16 19:50:15 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 19:50:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:15 --> Router Class Initialized
INFO - 2023-08-16 19:50:15 --> Router Class Initialized
INFO - 2023-08-16 19:50:15 --> Security Class Initialized
INFO - 2023-08-16 19:50:15 --> Output Class Initialized
INFO - 2023-08-16 19:50:15 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:15 --> URI Class Initialized
INFO - 2023-08-16 19:50:15 --> Output Class Initialized
INFO - 2023-08-16 19:50:15 --> Input Class Initialized
INFO - 2023-08-16 19:50:15 --> Security Class Initialized
DEBUG - 2023-08-16 19:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:15 --> Router Class Initialized
INFO - 2023-08-16 19:50:15 --> Input Class Initialized
INFO - 2023-08-16 19:50:15 --> Security Class Initialized
INFO - 2023-08-16 19:50:15 --> Output Class Initialized
INFO - 2023-08-16 19:50:15 --> Security Class Initialized
INFO - 2023-08-16 19:50:15 --> Language Class Initialized
DEBUG - 2023-08-16 19:50:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 19:50:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:50:15 --> Language Class Initialized
ERROR - 2023-08-16 19:50:15 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 19:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:15 --> Input Class Initialized
INFO - 2023-08-16 19:50:15 --> Input Class Initialized
INFO - 2023-08-16 19:50:15 --> Language Class Initialized
INFO - 2023-08-16 19:50:15 --> Language Class Initialized
ERROR - 2023-08-16 19:50:15 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 19:50:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:50:35 --> Config Class Initialized
INFO - 2023-08-16 19:50:35 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:50:35 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:35 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:35 --> URI Class Initialized
INFO - 2023-08-16 19:50:35 --> Router Class Initialized
INFO - 2023-08-16 19:50:35 --> Output Class Initialized
INFO - 2023-08-16 19:50:35 --> Security Class Initialized
DEBUG - 2023-08-16 19:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:35 --> Input Class Initialized
INFO - 2023-08-16 19:50:35 --> Language Class Initialized
INFO - 2023-08-16 19:50:35 --> Loader Class Initialized
INFO - 2023-08-16 19:50:35 --> Helper loaded: url_helper
INFO - 2023-08-16 19:50:35 --> Helper loaded: file_helper
INFO - 2023-08-16 19:50:35 --> Database Driver Class Initialized
INFO - 2023-08-16 19:50:35 --> Email Class Initialized
DEBUG - 2023-08-16 19:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:50:35 --> Controller Class Initialized
INFO - 2023-08-16 19:50:35 --> Model "Home_model" initialized
INFO - 2023-08-16 19:50:35 --> Helper loaded: form_helper
INFO - 2023-08-16 19:50:35 --> Form Validation Class Initialized
INFO - 2023-08-16 19:50:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 19:50:35 --> Final output sent to browser
DEBUG - 2023-08-16 19:50:35 --> Total execution time: 0.5550
INFO - 2023-08-16 19:50:36 --> Config Class Initialized
INFO - 2023-08-16 19:50:36 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:50:36 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:36 --> Config Class Initialized
INFO - 2023-08-16 19:50:36 --> Hooks Class Initialized
INFO - 2023-08-16 19:50:36 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:36 --> Config Class Initialized
INFO - 2023-08-16 19:50:36 --> Config Class Initialized
DEBUG - 2023-08-16 19:50:36 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:36 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:36 --> Hooks Class Initialized
INFO - 2023-08-16 19:50:37 --> Hooks Class Initialized
INFO - 2023-08-16 19:50:37 --> URI Class Initialized
DEBUG - 2023-08-16 19:50:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:37 --> URI Class Initialized
INFO - 2023-08-16 19:50:37 --> Router Class Initialized
INFO - 2023-08-16 19:50:37 --> Output Class Initialized
INFO - 2023-08-16 19:50:37 --> Security Class Initialized
DEBUG - 2023-08-16 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:37 --> Input Class Initialized
INFO - 2023-08-16 19:50:37 --> Language Class Initialized
ERROR - 2023-08-16 19:50:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:50:37 --> URI Class Initialized
DEBUG - 2023-08-16 19:50:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:37 --> Config Class Initialized
INFO - 2023-08-16 19:50:37 --> Router Class Initialized
INFO - 2023-08-16 19:50:37 --> URI Class Initialized
INFO - 2023-08-16 19:50:37 --> Router Class Initialized
INFO - 2023-08-16 19:50:37 --> Config Class Initialized
INFO - 2023-08-16 19:50:37 --> Hooks Class Initialized
INFO - 2023-08-16 19:50:37 --> Config Class Initialized
INFO - 2023-08-16 19:50:37 --> Hooks Class Initialized
INFO - 2023-08-16 19:50:37 --> Output Class Initialized
INFO - 2023-08-16 19:50:37 --> Router Class Initialized
INFO - 2023-08-16 19:50:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:50:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:37 --> URI Class Initialized
INFO - 2023-08-16 19:50:37 --> Router Class Initialized
INFO - 2023-08-16 19:50:37 --> Output Class Initialized
INFO - 2023-08-16 19:50:37 --> Security Class Initialized
DEBUG - 2023-08-16 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:37 --> Input Class Initialized
INFO - 2023-08-16 19:50:37 --> Language Class Initialized
ERROR - 2023-08-16 19:50:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:50:37 --> Output Class Initialized
DEBUG - 2023-08-16 19:50:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:50:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:37 --> Output Class Initialized
INFO - 2023-08-16 19:50:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:37 --> Security Class Initialized
INFO - 2023-08-16 19:50:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:37 --> Security Class Initialized
INFO - 2023-08-16 19:50:37 --> URI Class Initialized
INFO - 2023-08-16 19:50:37 --> Security Class Initialized
INFO - 2023-08-16 19:50:37 --> Config Class Initialized
INFO - 2023-08-16 19:50:37 --> URI Class Initialized
INFO - 2023-08-16 19:50:37 --> Router Class Initialized
DEBUG - 2023-08-16 19:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:37 --> Hooks Class Initialized
INFO - 2023-08-16 19:50:37 --> Input Class Initialized
DEBUG - 2023-08-16 19:50:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:37 --> Router Class Initialized
INFO - 2023-08-16 19:50:37 --> Output Class Initialized
INFO - 2023-08-16 19:50:37 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:37 --> Input Class Initialized
INFO - 2023-08-16 19:50:37 --> URI Class Initialized
INFO - 2023-08-16 19:50:37 --> Input Class Initialized
INFO - 2023-08-16 19:50:37 --> Security Class Initialized
DEBUG - 2023-08-16 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:37 --> Input Class Initialized
INFO - 2023-08-16 19:50:37 --> Language Class Initialized
ERROR - 2023-08-16 19:50:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:50:37 --> Language Class Initialized
INFO - 2023-08-16 19:50:37 --> Output Class Initialized
INFO - 2023-08-16 19:50:37 --> Security Class Initialized
ERROR - 2023-08-16 19:50:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:50:37 --> Language Class Initialized
INFO - 2023-08-16 19:50:37 --> Language Class Initialized
INFO - 2023-08-16 19:50:37 --> Router Class Initialized
DEBUG - 2023-08-16 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:37 --> Config Class Initialized
INFO - 2023-08-16 19:50:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:50:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:37 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:37 --> URI Class Initialized
INFO - 2023-08-16 19:50:37 --> Router Class Initialized
INFO - 2023-08-16 19:50:37 --> Output Class Initialized
INFO - 2023-08-16 19:50:37 --> Security Class Initialized
DEBUG - 2023-08-16 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:37 --> Input Class Initialized
INFO - 2023-08-16 19:50:37 --> Language Class Initialized
ERROR - 2023-08-16 19:50:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:50:37 --> Output Class Initialized
ERROR - 2023-08-16 19:50:37 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 19:50:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:50:37 --> Input Class Initialized
INFO - 2023-08-16 19:50:37 --> Config Class Initialized
INFO - 2023-08-16 19:50:37 --> Security Class Initialized
INFO - 2023-08-16 19:50:37 --> Language Class Initialized
DEBUG - 2023-08-16 19:50:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 19:50:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:50:38 --> Hooks Class Initialized
INFO - 2023-08-16 19:50:38 --> Config Class Initialized
DEBUG - 2023-08-16 19:50:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:38 --> Config Class Initialized
INFO - 2023-08-16 19:50:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:38 --> Hooks Class Initialized
INFO - 2023-08-16 19:50:38 --> Input Class Initialized
INFO - 2023-08-16 19:50:38 --> URI Class Initialized
INFO - 2023-08-16 19:50:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:50:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:38 --> Router Class Initialized
DEBUG - 2023-08-16 19:50:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:50:38 --> Language Class Initialized
INFO - 2023-08-16 19:50:38 --> Utf8 Class Initialized
ERROR - 2023-08-16 19:50:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:50:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:50:38 --> Output Class Initialized
INFO - 2023-08-16 19:50:38 --> URI Class Initialized
INFO - 2023-08-16 19:50:38 --> Router Class Initialized
INFO - 2023-08-16 19:50:38 --> Output Class Initialized
INFO - 2023-08-16 19:50:38 --> URI Class Initialized
INFO - 2023-08-16 19:50:38 --> Security Class Initialized
INFO - 2023-08-16 19:50:38 --> Security Class Initialized
DEBUG - 2023-08-16 19:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:38 --> Router Class Initialized
INFO - 2023-08-16 19:50:38 --> Output Class Initialized
INFO - 2023-08-16 19:50:38 --> Input Class Initialized
INFO - 2023-08-16 19:50:38 --> Security Class Initialized
INFO - 2023-08-16 19:50:38 --> Language Class Initialized
INFO - 2023-08-16 19:50:38 --> Input Class Initialized
ERROR - 2023-08-16 19:50:38 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 19:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:50:38 --> Language Class Initialized
INFO - 2023-08-16 19:50:38 --> Input Class Initialized
ERROR - 2023-08-16 19:50:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:50:38 --> Language Class Initialized
ERROR - 2023-08-16 19:50:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:52:54 --> Config Class Initialized
INFO - 2023-08-16 19:52:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:52:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:52:54 --> Utf8 Class Initialized
INFO - 2023-08-16 19:52:54 --> URI Class Initialized
INFO - 2023-08-16 19:52:54 --> Router Class Initialized
INFO - 2023-08-16 19:52:54 --> Output Class Initialized
INFO - 2023-08-16 19:52:54 --> Security Class Initialized
DEBUG - 2023-08-16 19:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:52:54 --> Input Class Initialized
INFO - 2023-08-16 19:52:54 --> Language Class Initialized
INFO - 2023-08-16 19:52:55 --> Loader Class Initialized
INFO - 2023-08-16 19:52:55 --> Helper loaded: url_helper
INFO - 2023-08-16 19:52:55 --> Helper loaded: file_helper
INFO - 2023-08-16 19:52:55 --> Database Driver Class Initialized
INFO - 2023-08-16 19:52:55 --> Email Class Initialized
DEBUG - 2023-08-16 19:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:52:55 --> Controller Class Initialized
INFO - 2023-08-16 19:52:55 --> Model "Home_model" initialized
INFO - 2023-08-16 19:52:55 --> Helper loaded: form_helper
INFO - 2023-08-16 19:52:55 --> Form Validation Class Initialized
INFO - 2023-08-16 19:52:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 19:52:55 --> Final output sent to browser
DEBUG - 2023-08-16 19:52:55 --> Total execution time: 0.5872
INFO - 2023-08-16 19:52:56 --> Config Class Initialized
INFO - 2023-08-16 19:52:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:52:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:52:56 --> Config Class Initialized
INFO - 2023-08-16 19:52:56 --> Config Class Initialized
INFO - 2023-08-16 19:52:56 --> Hooks Class Initialized
INFO - 2023-08-16 19:52:56 --> Hooks Class Initialized
INFO - 2023-08-16 19:52:56 --> Config Class Initialized
INFO - 2023-08-16 19:52:56 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:52:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:52:56 --> Config Class Initialized
INFO - 2023-08-16 19:52:56 --> Hooks Class Initialized
INFO - 2023-08-16 19:52:56 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:52:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:52:56 --> URI Class Initialized
DEBUG - 2023-08-16 19:52:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:52:56 --> Config Class Initialized
INFO - 2023-08-16 19:52:56 --> Hooks Class Initialized
INFO - 2023-08-16 19:52:56 --> Utf8 Class Initialized
INFO - 2023-08-16 19:52:56 --> Utf8 Class Initialized
INFO - 2023-08-16 19:52:56 --> URI Class Initialized
INFO - 2023-08-16 19:52:56 --> Router Class Initialized
INFO - 2023-08-16 19:52:56 --> Output Class Initialized
INFO - 2023-08-16 19:52:56 --> Security Class Initialized
DEBUG - 2023-08-16 19:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:52:56 --> Input Class Initialized
INFO - 2023-08-16 19:52:56 --> Language Class Initialized
ERROR - 2023-08-16 19:52:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:52:56 --> Router Class Initialized
INFO - 2023-08-16 19:52:56 --> URI Class Initialized
INFO - 2023-08-16 19:52:56 --> Router Class Initialized
INFO - 2023-08-16 19:52:56 --> Output Class Initialized
INFO - 2023-08-16 19:52:56 --> Security Class Initialized
DEBUG - 2023-08-16 19:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:52:56 --> Input Class Initialized
INFO - 2023-08-16 19:52:56 --> Language Class Initialized
ERROR - 2023-08-16 19:52:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:52:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:52:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:52:56 --> Utf8 Class Initialized
INFO - 2023-08-16 19:52:56 --> URI Class Initialized
INFO - 2023-08-16 19:52:56 --> Router Class Initialized
INFO - 2023-08-16 19:52:56 --> Output Class Initialized
INFO - 2023-08-16 19:52:56 --> Security Class Initialized
DEBUG - 2023-08-16 19:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:52:56 --> Input Class Initialized
INFO - 2023-08-16 19:52:56 --> Language Class Initialized
ERROR - 2023-08-16 19:52:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:52:56 --> Output Class Initialized
INFO - 2023-08-16 19:52:56 --> Security Class Initialized
INFO - 2023-08-16 19:52:57 --> URI Class Initialized
DEBUG - 2023-08-16 19:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:52:57 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:52:57 --> Input Class Initialized
INFO - 2023-08-16 19:52:57 --> Utf8 Class Initialized
INFO - 2023-08-16 19:52:57 --> URI Class Initialized
INFO - 2023-08-16 19:52:57 --> Router Class Initialized
INFO - 2023-08-16 19:52:57 --> Output Class Initialized
INFO - 2023-08-16 19:52:57 --> Security Class Initialized
DEBUG - 2023-08-16 19:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:52:57 --> Input Class Initialized
INFO - 2023-08-16 19:52:57 --> Language Class Initialized
ERROR - 2023-08-16 19:52:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:52:57 --> Router Class Initialized
INFO - 2023-08-16 19:52:57 --> Language Class Initialized
INFO - 2023-08-16 19:52:57 --> Output Class Initialized
INFO - 2023-08-16 19:52:57 --> Security Class Initialized
DEBUG - 2023-08-16 19:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:52:57 --> Input Class Initialized
INFO - 2023-08-16 19:52:57 --> Language Class Initialized
ERROR - 2023-08-16 19:52:57 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 19:52:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:55:25 --> Config Class Initialized
INFO - 2023-08-16 19:55:25 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:55:25 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:55:25 --> Utf8 Class Initialized
INFO - 2023-08-16 19:55:25 --> URI Class Initialized
INFO - 2023-08-16 19:55:25 --> Router Class Initialized
INFO - 2023-08-16 19:55:25 --> Output Class Initialized
INFO - 2023-08-16 19:55:25 --> Security Class Initialized
DEBUG - 2023-08-16 19:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:55:25 --> Input Class Initialized
INFO - 2023-08-16 19:55:25 --> Language Class Initialized
INFO - 2023-08-16 19:55:25 --> Loader Class Initialized
INFO - 2023-08-16 19:55:25 --> Helper loaded: url_helper
INFO - 2023-08-16 19:55:25 --> Helper loaded: file_helper
INFO - 2023-08-16 19:55:25 --> Database Driver Class Initialized
INFO - 2023-08-16 19:55:25 --> Email Class Initialized
DEBUG - 2023-08-16 19:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:55:26 --> Controller Class Initialized
INFO - 2023-08-16 19:55:26 --> Model "Home_model" initialized
INFO - 2023-08-16 19:55:26 --> Helper loaded: form_helper
INFO - 2023-08-16 19:55:26 --> Form Validation Class Initialized
INFO - 2023-08-16 19:55:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 19:55:26 --> Final output sent to browser
DEBUG - 2023-08-16 19:55:26 --> Total execution time: 0.4505
INFO - 2023-08-16 19:55:26 --> Config Class Initialized
INFO - 2023-08-16 19:55:26 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:55:26 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:55:26 --> Utf8 Class Initialized
INFO - 2023-08-16 19:55:26 --> URI Class Initialized
INFO - 2023-08-16 19:55:26 --> Router Class Initialized
INFO - 2023-08-16 19:55:26 --> Output Class Initialized
INFO - 2023-08-16 19:55:26 --> Security Class Initialized
DEBUG - 2023-08-16 19:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:55:26 --> Input Class Initialized
INFO - 2023-08-16 19:55:26 --> Language Class Initialized
ERROR - 2023-08-16 19:55:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:55:26 --> Config Class Initialized
INFO - 2023-08-16 19:55:26 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:55:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:55:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:55:27 --> URI Class Initialized
INFO - 2023-08-16 19:55:27 --> Router Class Initialized
INFO - 2023-08-16 19:55:27 --> Output Class Initialized
INFO - 2023-08-16 19:55:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:55:27 --> Input Class Initialized
INFO - 2023-08-16 19:55:27 --> Language Class Initialized
ERROR - 2023-08-16 19:55:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:55:27 --> Config Class Initialized
INFO - 2023-08-16 19:55:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:55:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:55:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:55:27 --> URI Class Initialized
INFO - 2023-08-16 19:55:27 --> Router Class Initialized
INFO - 2023-08-16 19:55:27 --> Output Class Initialized
INFO - 2023-08-16 19:55:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:55:27 --> Input Class Initialized
INFO - 2023-08-16 19:55:27 --> Language Class Initialized
ERROR - 2023-08-16 19:55:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:55:27 --> Config Class Initialized
INFO - 2023-08-16 19:55:27 --> Hooks Class Initialized
INFO - 2023-08-16 19:55:27 --> Config Class Initialized
DEBUG - 2023-08-16 19:55:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:55:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:55:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:55:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:55:27 --> Utf8 Class Initialized
INFO - 2023-08-16 19:55:27 --> URI Class Initialized
INFO - 2023-08-16 19:55:27 --> Router Class Initialized
INFO - 2023-08-16 19:55:27 --> Output Class Initialized
INFO - 2023-08-16 19:55:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:55:27 --> Input Class Initialized
INFO - 2023-08-16 19:55:27 --> Language Class Initialized
ERROR - 2023-08-16 19:55:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:55:27 --> URI Class Initialized
INFO - 2023-08-16 19:55:27 --> Router Class Initialized
INFO - 2023-08-16 19:55:27 --> Output Class Initialized
INFO - 2023-08-16 19:55:27 --> Security Class Initialized
DEBUG - 2023-08-16 19:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:55:27 --> Input Class Initialized
INFO - 2023-08-16 19:55:27 --> Language Class Initialized
ERROR - 2023-08-16 19:55:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:55:27 --> Config Class Initialized
INFO - 2023-08-16 19:55:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:55:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:55:28 --> Utf8 Class Initialized
INFO - 2023-08-16 19:55:28 --> URI Class Initialized
INFO - 2023-08-16 19:55:28 --> Router Class Initialized
INFO - 2023-08-16 19:55:28 --> Output Class Initialized
INFO - 2023-08-16 19:55:28 --> Security Class Initialized
DEBUG - 2023-08-16 19:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:55:28 --> Input Class Initialized
INFO - 2023-08-16 19:55:28 --> Language Class Initialized
ERROR - 2023-08-16 19:55:28 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:56:19 --> Config Class Initialized
INFO - 2023-08-16 19:56:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:56:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:56:19 --> Utf8 Class Initialized
INFO - 2023-08-16 19:56:19 --> URI Class Initialized
INFO - 2023-08-16 19:56:19 --> Router Class Initialized
INFO - 2023-08-16 19:56:19 --> Output Class Initialized
INFO - 2023-08-16 19:56:19 --> Security Class Initialized
DEBUG - 2023-08-16 19:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:56:19 --> Input Class Initialized
INFO - 2023-08-16 19:56:19 --> Language Class Initialized
INFO - 2023-08-16 19:56:19 --> Loader Class Initialized
INFO - 2023-08-16 19:56:19 --> Helper loaded: url_helper
INFO - 2023-08-16 19:56:19 --> Helper loaded: file_helper
INFO - 2023-08-16 19:56:19 --> Database Driver Class Initialized
INFO - 2023-08-16 19:56:19 --> Email Class Initialized
DEBUG - 2023-08-16 19:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:56:19 --> Controller Class Initialized
INFO - 2023-08-16 19:56:19 --> Model "Home_model" initialized
INFO - 2023-08-16 19:56:19 --> Helper loaded: form_helper
INFO - 2023-08-16 19:56:19 --> Form Validation Class Initialized
INFO - 2023-08-16 19:56:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 19:56:19 --> Final output sent to browser
DEBUG - 2023-08-16 19:56:20 --> Total execution time: 0.4756
INFO - 2023-08-16 19:56:20 --> Config Class Initialized
INFO - 2023-08-16 19:56:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:56:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:56:20 --> Utf8 Class Initialized
INFO - 2023-08-16 19:56:20 --> URI Class Initialized
INFO - 2023-08-16 19:56:20 --> Router Class Initialized
INFO - 2023-08-16 19:56:20 --> Output Class Initialized
INFO - 2023-08-16 19:56:20 --> Security Class Initialized
DEBUG - 2023-08-16 19:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:56:20 --> Input Class Initialized
INFO - 2023-08-16 19:56:20 --> Language Class Initialized
ERROR - 2023-08-16 19:56:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:56:20 --> Config Class Initialized
INFO - 2023-08-16 19:56:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:56:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:56:20 --> Utf8 Class Initialized
INFO - 2023-08-16 19:56:20 --> URI Class Initialized
INFO - 2023-08-16 19:56:20 --> Router Class Initialized
INFO - 2023-08-16 19:56:20 --> Output Class Initialized
INFO - 2023-08-16 19:56:20 --> Security Class Initialized
DEBUG - 2023-08-16 19:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:56:20 --> Input Class Initialized
INFO - 2023-08-16 19:56:20 --> Language Class Initialized
ERROR - 2023-08-16 19:56:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:56:20 --> Config Class Initialized
INFO - 2023-08-16 19:56:20 --> Config Class Initialized
INFO - 2023-08-16 19:56:20 --> Config Class Initialized
INFO - 2023-08-16 19:56:20 --> Hooks Class Initialized
INFO - 2023-08-16 19:56:20 --> Hooks Class Initialized
INFO - 2023-08-16 19:56:20 --> Config Class Initialized
INFO - 2023-08-16 19:56:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:56:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:56:20 --> Hooks Class Initialized
INFO - 2023-08-16 19:56:21 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:56:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:56:21 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:56:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:56:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:56:21 --> URI Class Initialized
INFO - 2023-08-16 19:56:21 --> URI Class Initialized
INFO - 2023-08-16 19:56:21 --> Utf8 Class Initialized
INFO - 2023-08-16 19:56:21 --> URI Class Initialized
INFO - 2023-08-16 19:56:21 --> Utf8 Class Initialized
INFO - 2023-08-16 19:56:21 --> Router Class Initialized
INFO - 2023-08-16 19:56:21 --> Router Class Initialized
INFO - 2023-08-16 19:56:21 --> Output Class Initialized
INFO - 2023-08-16 19:56:21 --> Output Class Initialized
INFO - 2023-08-16 19:56:21 --> Router Class Initialized
INFO - 2023-08-16 19:56:21 --> URI Class Initialized
INFO - 2023-08-16 19:56:21 --> Security Class Initialized
INFO - 2023-08-16 19:56:21 --> Security Class Initialized
DEBUG - 2023-08-16 19:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:56:21 --> Output Class Initialized
INFO - 2023-08-16 19:56:21 --> Input Class Initialized
INFO - 2023-08-16 19:56:21 --> Router Class Initialized
INFO - 2023-08-16 19:56:21 --> Language Class Initialized
DEBUG - 2023-08-16 19:56:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 19:56:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:56:21 --> Output Class Initialized
INFO - 2023-08-16 19:56:21 --> Security Class Initialized
INFO - 2023-08-16 19:56:21 --> Security Class Initialized
INFO - 2023-08-16 19:56:21 --> Input Class Initialized
DEBUG - 2023-08-16 19:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:56:21 --> Input Class Initialized
INFO - 2023-08-16 19:56:21 --> Input Class Initialized
INFO - 2023-08-16 19:56:21 --> Language Class Initialized
ERROR - 2023-08-16 19:56:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:56:21 --> Language Class Initialized
INFO - 2023-08-16 19:56:21 --> Language Class Initialized
ERROR - 2023-08-16 19:56:21 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 19:56:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:57:06 --> Config Class Initialized
INFO - 2023-08-16 19:57:06 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:57:06 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:57:06 --> Utf8 Class Initialized
INFO - 2023-08-16 19:57:06 --> URI Class Initialized
INFO - 2023-08-16 19:57:06 --> Router Class Initialized
INFO - 2023-08-16 19:57:06 --> Output Class Initialized
INFO - 2023-08-16 19:57:06 --> Security Class Initialized
DEBUG - 2023-08-16 19:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:57:06 --> Input Class Initialized
INFO - 2023-08-16 19:57:06 --> Language Class Initialized
INFO - 2023-08-16 19:57:06 --> Loader Class Initialized
INFO - 2023-08-16 19:57:06 --> Helper loaded: url_helper
INFO - 2023-08-16 19:57:06 --> Helper loaded: file_helper
INFO - 2023-08-16 19:57:06 --> Database Driver Class Initialized
INFO - 2023-08-16 19:57:06 --> Email Class Initialized
DEBUG - 2023-08-16 19:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:57:06 --> Controller Class Initialized
INFO - 2023-08-16 19:57:07 --> Model "Home_model" initialized
INFO - 2023-08-16 19:57:07 --> Helper loaded: form_helper
INFO - 2023-08-16 19:57:07 --> Form Validation Class Initialized
INFO - 2023-08-16 19:57:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 19:57:07 --> Final output sent to browser
DEBUG - 2023-08-16 19:57:07 --> Total execution time: 0.4933
INFO - 2023-08-16 19:57:07 --> Config Class Initialized
INFO - 2023-08-16 19:57:07 --> Config Class Initialized
INFO - 2023-08-16 19:57:07 --> Hooks Class Initialized
INFO - 2023-08-16 19:57:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:57:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:57:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:57:08 --> Utf8 Class Initialized
INFO - 2023-08-16 19:57:08 --> Config Class Initialized
INFO - 2023-08-16 19:57:08 --> Utf8 Class Initialized
INFO - 2023-08-16 19:57:08 --> URI Class Initialized
INFO - 2023-08-16 19:57:08 --> Hooks Class Initialized
INFO - 2023-08-16 19:57:08 --> Router Class Initialized
INFO - 2023-08-16 19:57:08 --> Config Class Initialized
INFO - 2023-08-16 19:57:08 --> Output Class Initialized
INFO - 2023-08-16 19:57:08 --> URI Class Initialized
DEBUG - 2023-08-16 19:57:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:57:08 --> Utf8 Class Initialized
INFO - 2023-08-16 19:57:08 --> Security Class Initialized
INFO - 2023-08-16 19:57:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:57:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:57:08 --> URI Class Initialized
DEBUG - 2023-08-16 19:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:57:08 --> Router Class Initialized
INFO - 2023-08-16 19:57:08 --> Input Class Initialized
INFO - 2023-08-16 19:57:08 --> Utf8 Class Initialized
INFO - 2023-08-16 19:57:08 --> Router Class Initialized
INFO - 2023-08-16 19:57:08 --> Output Class Initialized
INFO - 2023-08-16 19:57:08 --> Language Class Initialized
INFO - 2023-08-16 19:57:08 --> Security Class Initialized
INFO - 2023-08-16 19:57:08 --> URI Class Initialized
INFO - 2023-08-16 19:57:08 --> Output Class Initialized
ERROR - 2023-08-16 19:57:08 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 19:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:57:08 --> Input Class Initialized
INFO - 2023-08-16 19:57:08 --> Language Class Initialized
ERROR - 2023-08-16 19:57:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:57:08 --> Security Class Initialized
INFO - 2023-08-16 19:57:08 --> Router Class Initialized
INFO - 2023-08-16 19:57:08 --> Output Class Initialized
INFO - 2023-08-16 19:57:08 --> Security Class Initialized
DEBUG - 2023-08-16 19:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:57:08 --> Input Class Initialized
INFO - 2023-08-16 19:57:08 --> Language Class Initialized
ERROR - 2023-08-16 19:57:08 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 19:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:57:08 --> Input Class Initialized
INFO - 2023-08-16 19:57:08 --> Language Class Initialized
ERROR - 2023-08-16 19:57:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:57:08 --> Config Class Initialized
INFO - 2023-08-16 19:57:08 --> Hooks Class Initialized
INFO - 2023-08-16 19:57:08 --> Config Class Initialized
DEBUG - 2023-08-16 19:57:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:57:09 --> Utf8 Class Initialized
INFO - 2023-08-16 19:57:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:57:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:57:09 --> URI Class Initialized
INFO - 2023-08-16 19:57:09 --> Router Class Initialized
INFO - 2023-08-16 19:57:09 --> Utf8 Class Initialized
INFO - 2023-08-16 19:57:09 --> Output Class Initialized
INFO - 2023-08-16 19:57:09 --> URI Class Initialized
INFO - 2023-08-16 19:57:09 --> Security Class Initialized
INFO - 2023-08-16 19:57:09 --> Router Class Initialized
DEBUG - 2023-08-16 19:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:57:09 --> Output Class Initialized
INFO - 2023-08-16 19:57:09 --> Input Class Initialized
INFO - 2023-08-16 19:57:09 --> Security Class Initialized
INFO - 2023-08-16 19:57:09 --> Language Class Initialized
ERROR - 2023-08-16 19:57:09 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 19:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:57:09 --> Input Class Initialized
INFO - 2023-08-16 19:57:09 --> Language Class Initialized
ERROR - 2023-08-16 19:57:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:58:22 --> Config Class Initialized
INFO - 2023-08-16 19:58:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:58:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:58:23 --> Utf8 Class Initialized
INFO - 2023-08-16 19:58:23 --> URI Class Initialized
INFO - 2023-08-16 19:58:23 --> Router Class Initialized
INFO - 2023-08-16 19:58:23 --> Output Class Initialized
INFO - 2023-08-16 19:58:23 --> Security Class Initialized
DEBUG - 2023-08-16 19:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:58:23 --> Input Class Initialized
INFO - 2023-08-16 19:58:23 --> Language Class Initialized
INFO - 2023-08-16 19:58:23 --> Loader Class Initialized
INFO - 2023-08-16 19:58:23 --> Helper loaded: url_helper
INFO - 2023-08-16 19:58:23 --> Helper loaded: file_helper
INFO - 2023-08-16 19:58:23 --> Database Driver Class Initialized
INFO - 2023-08-16 19:58:23 --> Email Class Initialized
DEBUG - 2023-08-16 19:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:58:23 --> Controller Class Initialized
INFO - 2023-08-16 19:58:23 --> Model "Home_model" initialized
INFO - 2023-08-16 19:58:23 --> Helper loaded: form_helper
INFO - 2023-08-16 19:58:23 --> Form Validation Class Initialized
INFO - 2023-08-16 19:58:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 19:58:23 --> Final output sent to browser
DEBUG - 2023-08-16 19:58:23 --> Total execution time: 0.4601
INFO - 2023-08-16 19:58:24 --> Config Class Initialized
INFO - 2023-08-16 19:58:24 --> Config Class Initialized
INFO - 2023-08-16 19:58:24 --> Hooks Class Initialized
INFO - 2023-08-16 19:58:24 --> Config Class Initialized
INFO - 2023-08-16 19:58:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:58:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:58:24 --> Hooks Class Initialized
INFO - 2023-08-16 19:58:24 --> Utf8 Class Initialized
DEBUG - 2023-08-16 19:58:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:58:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:58:24 --> Utf8 Class Initialized
INFO - 2023-08-16 19:58:24 --> Utf8 Class Initialized
INFO - 2023-08-16 19:58:24 --> URI Class Initialized
INFO - 2023-08-16 19:58:24 --> URI Class Initialized
INFO - 2023-08-16 19:58:24 --> URI Class Initialized
INFO - 2023-08-16 19:58:24 --> Router Class Initialized
INFO - 2023-08-16 19:58:24 --> Router Class Initialized
INFO - 2023-08-16 19:58:24 --> Output Class Initialized
INFO - 2023-08-16 19:58:24 --> Router Class Initialized
INFO - 2023-08-16 19:58:24 --> Output Class Initialized
INFO - 2023-08-16 19:58:24 --> Security Class Initialized
INFO - 2023-08-16 19:58:24 --> Output Class Initialized
INFO - 2023-08-16 19:58:24 --> Security Class Initialized
DEBUG - 2023-08-16 19:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:58:24 --> Input Class Initialized
INFO - 2023-08-16 19:58:24 --> Language Class Initialized
ERROR - 2023-08-16 19:58:24 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 19:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:58:24 --> Input Class Initialized
INFO - 2023-08-16 19:58:24 --> Security Class Initialized
INFO - 2023-08-16 19:58:24 --> Language Class Initialized
INFO - 2023-08-16 19:58:24 --> Config Class Initialized
INFO - 2023-08-16 19:58:24 --> Config Class Initialized
INFO - 2023-08-16 19:58:24 --> Config Class Initialized
ERROR - 2023-08-16 19:58:24 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:58:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:58:24 --> Hooks Class Initialized
INFO - 2023-08-16 19:58:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:58:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:58:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 19:58:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:58:24 --> Input Class Initialized
INFO - 2023-08-16 19:58:24 --> Utf8 Class Initialized
INFO - 2023-08-16 19:58:24 --> Utf8 Class Initialized
INFO - 2023-08-16 19:58:24 --> Utf8 Class Initialized
INFO - 2023-08-16 19:58:24 --> URI Class Initialized
INFO - 2023-08-16 19:58:25 --> URI Class Initialized
INFO - 2023-08-16 19:58:25 --> Language Class Initialized
INFO - 2023-08-16 19:58:25 --> Router Class Initialized
INFO - 2023-08-16 19:58:25 --> URI Class Initialized
ERROR - 2023-08-16 19:58:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:58:25 --> Router Class Initialized
INFO - 2023-08-16 19:58:25 --> Router Class Initialized
INFO - 2023-08-16 19:58:25 --> Output Class Initialized
INFO - 2023-08-16 19:58:25 --> Output Class Initialized
INFO - 2023-08-16 19:58:25 --> Security Class Initialized
INFO - 2023-08-16 19:58:25 --> Security Class Initialized
INFO - 2023-08-16 19:58:25 --> Output Class Initialized
DEBUG - 2023-08-16 19:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:58:25 --> Security Class Initialized
INFO - 2023-08-16 19:58:25 --> Input Class Initialized
DEBUG - 2023-08-16 19:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 19:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:58:25 --> Language Class Initialized
INFO - 2023-08-16 19:58:25 --> Input Class Initialized
INFO - 2023-08-16 19:58:25 --> Input Class Initialized
INFO - 2023-08-16 19:58:25 --> Language Class Initialized
ERROR - 2023-08-16 19:58:25 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 19:58:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:58:25 --> Language Class Initialized
ERROR - 2023-08-16 19:58:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:59:38 --> Config Class Initialized
INFO - 2023-08-16 19:59:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:59:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:59:38 --> Utf8 Class Initialized
INFO - 2023-08-16 19:59:38 --> URI Class Initialized
INFO - 2023-08-16 19:59:38 --> Router Class Initialized
INFO - 2023-08-16 19:59:38 --> Output Class Initialized
INFO - 2023-08-16 19:59:38 --> Security Class Initialized
DEBUG - 2023-08-16 19:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:59:38 --> Input Class Initialized
INFO - 2023-08-16 19:59:38 --> Language Class Initialized
INFO - 2023-08-16 19:59:38 --> Loader Class Initialized
INFO - 2023-08-16 19:59:38 --> Helper loaded: url_helper
INFO - 2023-08-16 19:59:38 --> Helper loaded: file_helper
INFO - 2023-08-16 19:59:38 --> Database Driver Class Initialized
INFO - 2023-08-16 19:59:38 --> Email Class Initialized
DEBUG - 2023-08-16 19:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 19:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 19:59:38 --> Controller Class Initialized
INFO - 2023-08-16 19:59:38 --> Model "Home_model" initialized
INFO - 2023-08-16 19:59:38 --> Helper loaded: form_helper
INFO - 2023-08-16 19:59:38 --> Form Validation Class Initialized
INFO - 2023-08-16 19:59:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 19:59:38 --> Final output sent to browser
DEBUG - 2023-08-16 19:59:38 --> Total execution time: 0.4998
INFO - 2023-08-16 19:59:39 --> Config Class Initialized
INFO - 2023-08-16 19:59:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:59:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:59:39 --> Utf8 Class Initialized
INFO - 2023-08-16 19:59:39 --> URI Class Initialized
INFO - 2023-08-16 19:59:39 --> Router Class Initialized
INFO - 2023-08-16 19:59:39 --> Output Class Initialized
INFO - 2023-08-16 19:59:39 --> Security Class Initialized
DEBUG - 2023-08-16 19:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:59:39 --> Input Class Initialized
INFO - 2023-08-16 19:59:39 --> Language Class Initialized
ERROR - 2023-08-16 19:59:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:59:39 --> Config Class Initialized
INFO - 2023-08-16 19:59:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:59:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:59:39 --> Utf8 Class Initialized
INFO - 2023-08-16 19:59:39 --> URI Class Initialized
INFO - 2023-08-16 19:59:39 --> Router Class Initialized
INFO - 2023-08-16 19:59:39 --> Output Class Initialized
INFO - 2023-08-16 19:59:39 --> Security Class Initialized
DEBUG - 2023-08-16 19:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:59:39 --> Input Class Initialized
INFO - 2023-08-16 19:59:39 --> Language Class Initialized
ERROR - 2023-08-16 19:59:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:59:39 --> Config Class Initialized
INFO - 2023-08-16 19:59:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:59:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:59:39 --> Utf8 Class Initialized
INFO - 2023-08-16 19:59:39 --> URI Class Initialized
INFO - 2023-08-16 19:59:39 --> Router Class Initialized
INFO - 2023-08-16 19:59:39 --> Output Class Initialized
INFO - 2023-08-16 19:59:39 --> Security Class Initialized
DEBUG - 2023-08-16 19:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:59:39 --> Input Class Initialized
INFO - 2023-08-16 19:59:39 --> Language Class Initialized
ERROR - 2023-08-16 19:59:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:59:39 --> Config Class Initialized
INFO - 2023-08-16 19:59:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:59:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:59:39 --> Utf8 Class Initialized
INFO - 2023-08-16 19:59:39 --> URI Class Initialized
INFO - 2023-08-16 19:59:39 --> Router Class Initialized
INFO - 2023-08-16 19:59:39 --> Output Class Initialized
INFO - 2023-08-16 19:59:39 --> Security Class Initialized
DEBUG - 2023-08-16 19:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:59:39 --> Input Class Initialized
INFO - 2023-08-16 19:59:39 --> Language Class Initialized
ERROR - 2023-08-16 19:59:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:59:40 --> Config Class Initialized
INFO - 2023-08-16 19:59:40 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:59:40 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:59:40 --> Utf8 Class Initialized
INFO - 2023-08-16 19:59:40 --> URI Class Initialized
INFO - 2023-08-16 19:59:40 --> Router Class Initialized
INFO - 2023-08-16 19:59:40 --> Output Class Initialized
INFO - 2023-08-16 19:59:40 --> Security Class Initialized
DEBUG - 2023-08-16 19:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:59:40 --> Input Class Initialized
INFO - 2023-08-16 19:59:40 --> Language Class Initialized
ERROR - 2023-08-16 19:59:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:59:40 --> Config Class Initialized
INFO - 2023-08-16 19:59:40 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:59:40 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:59:40 --> Utf8 Class Initialized
INFO - 2023-08-16 19:59:40 --> URI Class Initialized
INFO - 2023-08-16 19:59:40 --> Router Class Initialized
INFO - 2023-08-16 19:59:40 --> Output Class Initialized
INFO - 2023-08-16 19:59:40 --> Security Class Initialized
DEBUG - 2023-08-16 19:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:59:40 --> Input Class Initialized
INFO - 2023-08-16 19:59:40 --> Language Class Initialized
ERROR - 2023-08-16 19:59:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 19:59:40 --> Config Class Initialized
INFO - 2023-08-16 19:59:40 --> Hooks Class Initialized
DEBUG - 2023-08-16 19:59:40 --> UTF-8 Support Enabled
INFO - 2023-08-16 19:59:40 --> Utf8 Class Initialized
INFO - 2023-08-16 19:59:40 --> URI Class Initialized
INFO - 2023-08-16 19:59:40 --> Router Class Initialized
INFO - 2023-08-16 19:59:40 --> Output Class Initialized
INFO - 2023-08-16 19:59:40 --> Security Class Initialized
DEBUG - 2023-08-16 19:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 19:59:40 --> Input Class Initialized
INFO - 2023-08-16 19:59:40 --> Language Class Initialized
ERROR - 2023-08-16 19:59:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:00:43 --> Config Class Initialized
INFO - 2023-08-16 20:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:00:43 --> Utf8 Class Initialized
INFO - 2023-08-16 20:00:43 --> URI Class Initialized
INFO - 2023-08-16 20:00:43 --> Router Class Initialized
INFO - 2023-08-16 20:00:43 --> Output Class Initialized
INFO - 2023-08-16 20:00:43 --> Security Class Initialized
DEBUG - 2023-08-16 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:00:43 --> Input Class Initialized
INFO - 2023-08-16 20:00:43 --> Language Class Initialized
INFO - 2023-08-16 20:00:43 --> Loader Class Initialized
INFO - 2023-08-16 20:00:43 --> Helper loaded: url_helper
INFO - 2023-08-16 20:00:43 --> Helper loaded: file_helper
INFO - 2023-08-16 20:00:43 --> Database Driver Class Initialized
INFO - 2023-08-16 20:00:43 --> Email Class Initialized
DEBUG - 2023-08-16 20:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:00:43 --> Controller Class Initialized
INFO - 2023-08-16 20:00:43 --> Model "Home_model" initialized
INFO - 2023-08-16 20:00:43 --> Helper loaded: form_helper
INFO - 2023-08-16 20:00:43 --> Form Validation Class Initialized
INFO - 2023-08-16 20:00:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:00:44 --> Final output sent to browser
DEBUG - 2023-08-16 20:00:44 --> Total execution time: 0.8646
INFO - 2023-08-16 20:00:44 --> Config Class Initialized
INFO - 2023-08-16 20:00:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:00:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:00:44 --> Utf8 Class Initialized
INFO - 2023-08-16 20:00:44 --> URI Class Initialized
INFO - 2023-08-16 20:00:44 --> Router Class Initialized
INFO - 2023-08-16 20:00:44 --> Output Class Initialized
INFO - 2023-08-16 20:00:44 --> Security Class Initialized
DEBUG - 2023-08-16 20:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:00:44 --> Input Class Initialized
INFO - 2023-08-16 20:00:44 --> Language Class Initialized
ERROR - 2023-08-16 20:00:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:00:44 --> Config Class Initialized
INFO - 2023-08-16 20:00:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:00:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:00:44 --> Utf8 Class Initialized
INFO - 2023-08-16 20:00:44 --> URI Class Initialized
INFO - 2023-08-16 20:00:44 --> Router Class Initialized
INFO - 2023-08-16 20:00:44 --> Output Class Initialized
INFO - 2023-08-16 20:00:44 --> Security Class Initialized
DEBUG - 2023-08-16 20:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:00:44 --> Input Class Initialized
INFO - 2023-08-16 20:00:44 --> Language Class Initialized
INFO - 2023-08-16 20:00:44 --> Config Class Initialized
INFO - 2023-08-16 20:00:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:00:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:00:44 --> Utf8 Class Initialized
INFO - 2023-08-16 20:00:44 --> URI Class Initialized
INFO - 2023-08-16 20:00:44 --> Router Class Initialized
INFO - 2023-08-16 20:00:44 --> Output Class Initialized
INFO - 2023-08-16 20:00:44 --> Security Class Initialized
INFO - 2023-08-16 20:00:44 --> Config Class Initialized
INFO - 2023-08-16 20:00:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:00:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:00:44 --> Utf8 Class Initialized
INFO - 2023-08-16 20:00:44 --> URI Class Initialized
INFO - 2023-08-16 20:00:44 --> Router Class Initialized
INFO - 2023-08-16 20:00:44 --> Output Class Initialized
INFO - 2023-08-16 20:00:44 --> Security Class Initialized
DEBUG - 2023-08-16 20:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:00:44 --> Input Class Initialized
INFO - 2023-08-16 20:00:44 --> Language Class Initialized
ERROR - 2023-08-16 20:00:44 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 20:00:44 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 20:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:00:45 --> Input Class Initialized
INFO - 2023-08-16 20:00:45 --> Language Class Initialized
INFO - 2023-08-16 20:00:45 --> Config Class Initialized
INFO - 2023-08-16 20:00:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:00:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:00:45 --> Utf8 Class Initialized
INFO - 2023-08-16 20:00:45 --> URI Class Initialized
INFO - 2023-08-16 20:00:45 --> Router Class Initialized
INFO - 2023-08-16 20:00:45 --> Output Class Initialized
INFO - 2023-08-16 20:00:45 --> Security Class Initialized
DEBUG - 2023-08-16 20:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:00:45 --> Input Class Initialized
INFO - 2023-08-16 20:00:45 --> Language Class Initialized
ERROR - 2023-08-16 20:00:45 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 20:00:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:00:45 --> Config Class Initialized
INFO - 2023-08-16 20:00:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:00:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:00:45 --> Utf8 Class Initialized
INFO - 2023-08-16 20:00:45 --> URI Class Initialized
INFO - 2023-08-16 20:00:45 --> Router Class Initialized
INFO - 2023-08-16 20:00:45 --> Output Class Initialized
INFO - 2023-08-16 20:00:45 --> Security Class Initialized
DEBUG - 2023-08-16 20:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:00:45 --> Input Class Initialized
INFO - 2023-08-16 20:00:45 --> Language Class Initialized
ERROR - 2023-08-16 20:00:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:00:59 --> Config Class Initialized
INFO - 2023-08-16 20:01:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:01:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:01:00 --> Utf8 Class Initialized
INFO - 2023-08-16 20:01:00 --> URI Class Initialized
INFO - 2023-08-16 20:01:00 --> Router Class Initialized
INFO - 2023-08-16 20:01:00 --> Output Class Initialized
INFO - 2023-08-16 20:01:00 --> Security Class Initialized
DEBUG - 2023-08-16 20:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:01:00 --> Input Class Initialized
INFO - 2023-08-16 20:01:00 --> Language Class Initialized
ERROR - 2023-08-16 20:01:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:01:00 --> Config Class Initialized
INFO - 2023-08-16 20:01:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:01:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:01:00 --> Utf8 Class Initialized
INFO - 2023-08-16 20:01:00 --> URI Class Initialized
INFO - 2023-08-16 20:01:00 --> Router Class Initialized
INFO - 2023-08-16 20:01:00 --> Output Class Initialized
INFO - 2023-08-16 20:01:00 --> Security Class Initialized
DEBUG - 2023-08-16 20:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:01:00 --> Input Class Initialized
INFO - 2023-08-16 20:01:00 --> Language Class Initialized
ERROR - 2023-08-16 20:01:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:01:02 --> Config Class Initialized
INFO - 2023-08-16 20:01:02 --> Config Class Initialized
INFO - 2023-08-16 20:01:03 --> Config Class Initialized
INFO - 2023-08-16 20:01:03 --> Hooks Class Initialized
INFO - 2023-08-16 20:01:03 --> Hooks Class Initialized
INFO - 2023-08-16 20:01:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:01:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:01:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:01:03 --> Utf8 Class Initialized
INFO - 2023-08-16 20:01:04 --> URI Class Initialized
DEBUG - 2023-08-16 20:01:04 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:01:04 --> Router Class Initialized
INFO - 2023-08-16 20:01:04 --> Utf8 Class Initialized
INFO - 2023-08-16 20:01:04 --> Output Class Initialized
INFO - 2023-08-16 20:01:04 --> Utf8 Class Initialized
INFO - 2023-08-16 20:01:04 --> URI Class Initialized
INFO - 2023-08-16 20:01:04 --> URI Class Initialized
INFO - 2023-08-16 20:01:04 --> Security Class Initialized
INFO - 2023-08-16 20:01:04 --> Router Class Initialized
DEBUG - 2023-08-16 20:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:01:04 --> Router Class Initialized
INFO - 2023-08-16 20:01:04 --> Input Class Initialized
INFO - 2023-08-16 20:01:04 --> Output Class Initialized
INFO - 2023-08-16 20:01:04 --> Output Class Initialized
INFO - 2023-08-16 20:01:04 --> Security Class Initialized
INFO - 2023-08-16 20:01:04 --> Language Class Initialized
INFO - 2023-08-16 20:01:04 --> Config Class Initialized
INFO - 2023-08-16 20:01:04 --> Config Class Initialized
INFO - 2023-08-16 20:01:04 --> Security Class Initialized
DEBUG - 2023-08-16 20:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:01:04 --> Input Class Initialized
ERROR - 2023-08-16 20:01:04 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 20:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:01:04 --> Input Class Initialized
INFO - 2023-08-16 20:01:04 --> Language Class Initialized
ERROR - 2023-08-16 20:01:04 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:01:04 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:01:04 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:01:04 --> Hooks Class Initialized
INFO - 2023-08-16 20:01:04 --> Utf8 Class Initialized
INFO - 2023-08-16 20:01:04 --> Language Class Initialized
DEBUG - 2023-08-16 20:01:04 --> UTF-8 Support Enabled
ERROR - 2023-08-16 20:01:04 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:01:04 --> Utf8 Class Initialized
INFO - 2023-08-16 20:01:04 --> URI Class Initialized
INFO - 2023-08-16 20:01:04 --> URI Class Initialized
INFO - 2023-08-16 20:01:04 --> Router Class Initialized
INFO - 2023-08-16 20:01:04 --> Router Class Initialized
INFO - 2023-08-16 20:01:04 --> Output Class Initialized
INFO - 2023-08-16 20:01:04 --> Output Class Initialized
INFO - 2023-08-16 20:01:04 --> Security Class Initialized
DEBUG - 2023-08-16 20:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:01:04 --> Security Class Initialized
INFO - 2023-08-16 20:01:04 --> Input Class Initialized
DEBUG - 2023-08-16 20:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:01:04 --> Language Class Initialized
INFO - 2023-08-16 20:01:04 --> Input Class Initialized
ERROR - 2023-08-16 20:01:04 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:01:04 --> Language Class Initialized
ERROR - 2023-08-16 20:01:04 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:01:52 --> Config Class Initialized
INFO - 2023-08-16 20:01:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:01:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:01:52 --> Utf8 Class Initialized
INFO - 2023-08-16 20:01:52 --> URI Class Initialized
INFO - 2023-08-16 20:01:52 --> Router Class Initialized
INFO - 2023-08-16 20:01:52 --> Output Class Initialized
INFO - 2023-08-16 20:01:52 --> Security Class Initialized
DEBUG - 2023-08-16 20:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:01:52 --> Input Class Initialized
INFO - 2023-08-16 20:01:52 --> Language Class Initialized
INFO - 2023-08-16 20:01:52 --> Loader Class Initialized
INFO - 2023-08-16 20:01:52 --> Helper loaded: url_helper
INFO - 2023-08-16 20:01:52 --> Helper loaded: file_helper
INFO - 2023-08-16 20:01:52 --> Database Driver Class Initialized
INFO - 2023-08-16 20:01:52 --> Email Class Initialized
DEBUG - 2023-08-16 20:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:01:53 --> Controller Class Initialized
INFO - 2023-08-16 20:01:53 --> Model "Home_model" initialized
INFO - 2023-08-16 20:01:53 --> Helper loaded: form_helper
INFO - 2023-08-16 20:01:53 --> Form Validation Class Initialized
INFO - 2023-08-16 20:01:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:01:53 --> Final output sent to browser
DEBUG - 2023-08-16 20:01:53 --> Total execution time: 0.8938
INFO - 2023-08-16 20:01:54 --> Config Class Initialized
INFO - 2023-08-16 20:01:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:01:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:01:54 --> Utf8 Class Initialized
INFO - 2023-08-16 20:01:54 --> URI Class Initialized
INFO - 2023-08-16 20:01:54 --> Router Class Initialized
INFO - 2023-08-16 20:01:54 --> Output Class Initialized
INFO - 2023-08-16 20:01:54 --> Security Class Initialized
DEBUG - 2023-08-16 20:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:01:54 --> Input Class Initialized
INFO - 2023-08-16 20:01:54 --> Language Class Initialized
ERROR - 2023-08-16 20:01:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:01:54 --> Config Class Initialized
INFO - 2023-08-16 20:01:54 --> Config Class Initialized
INFO - 2023-08-16 20:01:54 --> Config Class Initialized
INFO - 2023-08-16 20:01:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:01:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:01:54 --> Utf8 Class Initialized
INFO - 2023-08-16 20:01:54 --> URI Class Initialized
INFO - 2023-08-16 20:01:54 --> Router Class Initialized
INFO - 2023-08-16 20:01:54 --> Output Class Initialized
INFO - 2023-08-16 20:01:54 --> Security Class Initialized
DEBUG - 2023-08-16 20:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:01:54 --> Input Class Initialized
INFO - 2023-08-16 20:01:54 --> Language Class Initialized
ERROR - 2023-08-16 20:01:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:01:54 --> Hooks Class Initialized
INFO - 2023-08-16 20:01:54 --> Config Class Initialized
INFO - 2023-08-16 20:01:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:01:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:01:54 --> Config Class Initialized
INFO - 2023-08-16 20:01:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:01:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:01:54 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:01:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:01:54 --> Hooks Class Initialized
INFO - 2023-08-16 20:01:54 --> Utf8 Class Initialized
INFO - 2023-08-16 20:01:54 --> Utf8 Class Initialized
INFO - 2023-08-16 20:01:54 --> URI Class Initialized
INFO - 2023-08-16 20:01:54 --> URI Class Initialized
INFO - 2023-08-16 20:01:54 --> Router Class Initialized
DEBUG - 2023-08-16 20:01:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:01:54 --> Utf8 Class Initialized
INFO - 2023-08-16 20:01:54 --> URI Class Initialized
INFO - 2023-08-16 20:01:54 --> URI Class Initialized
INFO - 2023-08-16 20:01:54 --> Router Class Initialized
INFO - 2023-08-16 20:01:54 --> Output Class Initialized
INFO - 2023-08-16 20:01:54 --> Output Class Initialized
INFO - 2023-08-16 20:01:55 --> Router Class Initialized
INFO - 2023-08-16 20:01:55 --> Router Class Initialized
INFO - 2023-08-16 20:01:55 --> Security Class Initialized
DEBUG - 2023-08-16 20:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:01:55 --> Input Class Initialized
INFO - 2023-08-16 20:01:55 --> Language Class Initialized
ERROR - 2023-08-16 20:01:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:01:55 --> Output Class Initialized
INFO - 2023-08-16 20:01:55 --> Security Class Initialized
INFO - 2023-08-16 20:01:55 --> Security Class Initialized
DEBUG - 2023-08-16 20:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:01:55 --> Output Class Initialized
INFO - 2023-08-16 20:01:55 --> Input Class Initialized
DEBUG - 2023-08-16 20:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:01:55 --> Security Class Initialized
INFO - 2023-08-16 20:01:55 --> Input Class Initialized
INFO - 2023-08-16 20:01:55 --> Language Class Initialized
INFO - 2023-08-16 20:01:55 --> Language Class Initialized
ERROR - 2023-08-16 20:01:55 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 20:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 20:01:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:01:55 --> Input Class Initialized
INFO - 2023-08-16 20:01:55 --> Language Class Initialized
ERROR - 2023-08-16 20:01:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:02:06 --> Config Class Initialized
INFO - 2023-08-16 20:02:06 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:02:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:02:07 --> Config Class Initialized
INFO - 2023-08-16 20:02:07 --> Utf8 Class Initialized
INFO - 2023-08-16 20:02:07 --> URI Class Initialized
INFO - 2023-08-16 20:02:07 --> Router Class Initialized
INFO - 2023-08-16 20:02:07 --> Output Class Initialized
INFO - 2023-08-16 20:02:07 --> Security Class Initialized
DEBUG - 2023-08-16 20:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:02:07 --> Input Class Initialized
INFO - 2023-08-16 20:02:07 --> Language Class Initialized
ERROR - 2023-08-16 20:02:07 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:02:07 --> Config Class Initialized
INFO - 2023-08-16 20:02:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:02:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:02:07 --> Utf8 Class Initialized
INFO - 2023-08-16 20:02:07 --> URI Class Initialized
INFO - 2023-08-16 20:02:07 --> Router Class Initialized
INFO - 2023-08-16 20:02:07 --> Output Class Initialized
INFO - 2023-08-16 20:02:07 --> Security Class Initialized
DEBUG - 2023-08-16 20:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:02:07 --> Input Class Initialized
INFO - 2023-08-16 20:02:07 --> Language Class Initialized
ERROR - 2023-08-16 20:02:07 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:02:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:02:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:02:08 --> Utf8 Class Initialized
INFO - 2023-08-16 20:02:08 --> URI Class Initialized
INFO - 2023-08-16 20:02:08 --> Router Class Initialized
INFO - 2023-08-16 20:02:08 --> Output Class Initialized
INFO - 2023-08-16 20:02:08 --> Security Class Initialized
DEBUG - 2023-08-16 20:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:02:08 --> Input Class Initialized
INFO - 2023-08-16 20:02:08 --> Language Class Initialized
ERROR - 2023-08-16 20:02:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:02:09 --> Config Class Initialized
INFO - 2023-08-16 20:02:10 --> Config Class Initialized
INFO - 2023-08-16 20:02:10 --> Config Class Initialized
INFO - 2023-08-16 20:02:11 --> Hooks Class Initialized
INFO - 2023-08-16 20:02:11 --> Hooks Class Initialized
INFO - 2023-08-16 20:02:11 --> Config Class Initialized
INFO - 2023-08-16 20:02:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:02:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:02:11 --> Utf8 Class Initialized
INFO - 2023-08-16 20:02:11 --> URI Class Initialized
INFO - 2023-08-16 20:02:11 --> Router Class Initialized
INFO - 2023-08-16 20:02:11 --> Output Class Initialized
INFO - 2023-08-16 20:02:11 --> Security Class Initialized
DEBUG - 2023-08-16 20:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:02:11 --> Input Class Initialized
INFO - 2023-08-16 20:02:11 --> Language Class Initialized
ERROR - 2023-08-16 20:02:11 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 20:02:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:02:11 --> Hooks Class Initialized
INFO - 2023-08-16 20:02:11 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:02:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:02:11 --> Utf8 Class Initialized
INFO - 2023-08-16 20:02:11 --> URI Class Initialized
DEBUG - 2023-08-16 20:02:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:02:12 --> Router Class Initialized
INFO - 2023-08-16 20:02:12 --> Utf8 Class Initialized
INFO - 2023-08-16 20:02:12 --> URI Class Initialized
INFO - 2023-08-16 20:02:12 --> Output Class Initialized
INFO - 2023-08-16 20:02:12 --> Router Class Initialized
INFO - 2023-08-16 20:02:12 --> URI Class Initialized
INFO - 2023-08-16 20:02:12 --> Output Class Initialized
INFO - 2023-08-16 20:02:12 --> Security Class Initialized
INFO - 2023-08-16 20:02:12 --> Security Class Initialized
INFO - 2023-08-16 20:02:12 --> Router Class Initialized
DEBUG - 2023-08-16 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:02:12 --> Output Class Initialized
DEBUG - 2023-08-16 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:02:12 --> Security Class Initialized
INFO - 2023-08-16 20:02:12 --> Input Class Initialized
INFO - 2023-08-16 20:02:12 --> Input Class Initialized
INFO - 2023-08-16 20:02:12 --> Language Class Initialized
INFO - 2023-08-16 20:02:12 --> Language Class Initialized
DEBUG - 2023-08-16 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:02:12 --> Input Class Initialized
ERROR - 2023-08-16 20:02:13 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:02:13 --> Language Class Initialized
ERROR - 2023-08-16 20:02:13 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-16 20:02:13 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:03:25 --> Config Class Initialized
INFO - 2023-08-16 20:03:25 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:03:26 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:03:26 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:26 --> URI Class Initialized
INFO - 2023-08-16 20:03:26 --> Router Class Initialized
INFO - 2023-08-16 20:03:26 --> Output Class Initialized
INFO - 2023-08-16 20:03:26 --> Security Class Initialized
DEBUG - 2023-08-16 20:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:03:26 --> Input Class Initialized
INFO - 2023-08-16 20:03:26 --> Language Class Initialized
INFO - 2023-08-16 20:03:26 --> Loader Class Initialized
INFO - 2023-08-16 20:03:26 --> Helper loaded: url_helper
INFO - 2023-08-16 20:03:26 --> Helper loaded: file_helper
INFO - 2023-08-16 20:03:26 --> Database Driver Class Initialized
INFO - 2023-08-16 20:03:26 --> Email Class Initialized
DEBUG - 2023-08-16 20:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:03:26 --> Controller Class Initialized
INFO - 2023-08-16 20:03:26 --> Model "Home_model" initialized
INFO - 2023-08-16 20:03:26 --> Helper loaded: form_helper
INFO - 2023-08-16 20:03:26 --> Form Validation Class Initialized
INFO - 2023-08-16 20:03:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:03:26 --> Final output sent to browser
DEBUG - 2023-08-16 20:03:26 --> Total execution time: 0.5014
INFO - 2023-08-16 20:03:27 --> Config Class Initialized
INFO - 2023-08-16 20:03:28 --> Config Class Initialized
INFO - 2023-08-16 20:03:28 --> Hooks Class Initialized
INFO - 2023-08-16 20:03:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:03:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:03:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:03:28 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:29 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:29 --> URI Class Initialized
INFO - 2023-08-16 20:03:29 --> URI Class Initialized
INFO - 2023-08-16 20:03:29 --> Router Class Initialized
INFO - 2023-08-16 20:03:29 --> Router Class Initialized
INFO - 2023-08-16 20:03:29 --> Output Class Initialized
INFO - 2023-08-16 20:03:29 --> Output Class Initialized
INFO - 2023-08-16 20:03:29 --> Security Class Initialized
INFO - 2023-08-16 20:03:29 --> Security Class Initialized
DEBUG - 2023-08-16 20:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 20:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:03:29 --> Input Class Initialized
INFO - 2023-08-16 20:03:29 --> Input Class Initialized
INFO - 2023-08-16 20:03:29 --> Language Class Initialized
INFO - 2023-08-16 20:03:29 --> Language Class Initialized
ERROR - 2023-08-16 20:03:29 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 20:03:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:03:30 --> Config Class Initialized
INFO - 2023-08-16 20:03:30 --> Config Class Initialized
INFO - 2023-08-16 20:03:30 --> Hooks Class Initialized
INFO - 2023-08-16 20:03:30 --> Hooks Class Initialized
INFO - 2023-08-16 20:03:30 --> Config Class Initialized
INFO - 2023-08-16 20:03:30 --> Hooks Class Initialized
INFO - 2023-08-16 20:03:30 --> Config Class Initialized
INFO - 2023-08-16 20:03:30 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:03:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:03:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:03:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:03:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:03:30 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:30 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:30 --> Config Class Initialized
INFO - 2023-08-16 20:03:31 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:31 --> Config Class Initialized
INFO - 2023-08-16 20:03:31 --> Hooks Class Initialized
INFO - 2023-08-16 20:03:31 --> URI Class Initialized
INFO - 2023-08-16 20:03:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:03:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:03:31 --> URI Class Initialized
INFO - 2023-08-16 20:03:31 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:03:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:03:31 --> URI Class Initialized
INFO - 2023-08-16 20:03:31 --> Router Class Initialized
INFO - 2023-08-16 20:03:31 --> Router Class Initialized
INFO - 2023-08-16 20:03:31 --> URI Class Initialized
INFO - 2023-08-16 20:03:31 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:31 --> Router Class Initialized
INFO - 2023-08-16 20:03:31 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:31 --> URI Class Initialized
INFO - 2023-08-16 20:03:31 --> Output Class Initialized
INFO - 2023-08-16 20:03:31 --> URI Class Initialized
INFO - 2023-08-16 20:03:31 --> Output Class Initialized
INFO - 2023-08-16 20:03:31 --> Output Class Initialized
INFO - 2023-08-16 20:03:31 --> Router Class Initialized
INFO - 2023-08-16 20:03:31 --> Router Class Initialized
INFO - 2023-08-16 20:03:31 --> Security Class Initialized
INFO - 2023-08-16 20:03:31 --> Router Class Initialized
INFO - 2023-08-16 20:03:31 --> Security Class Initialized
INFO - 2023-08-16 20:03:31 --> Output Class Initialized
DEBUG - 2023-08-16 20:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:03:31 --> Output Class Initialized
INFO - 2023-08-16 20:03:31 --> Security Class Initialized
INFO - 2023-08-16 20:03:31 --> Output Class Initialized
DEBUG - 2023-08-16 20:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:03:31 --> Input Class Initialized
INFO - 2023-08-16 20:03:31 --> Security Class Initialized
DEBUG - 2023-08-16 20:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:03:31 --> Security Class Initialized
DEBUG - 2023-08-16 20:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:03:31 --> Security Class Initialized
INFO - 2023-08-16 20:03:31 --> Language Class Initialized
INFO - 2023-08-16 20:03:31 --> Input Class Initialized
DEBUG - 2023-08-16 20:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:03:31 --> Input Class Initialized
INFO - 2023-08-16 20:03:31 --> Language Class Initialized
INFO - 2023-08-16 20:03:31 --> Input Class Initialized
DEBUG - 2023-08-16 20:03:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 20:03:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:03:31 --> Language Class Initialized
ERROR - 2023-08-16 20:03:31 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:03:31 --> Input Class Initialized
ERROR - 2023-08-16 20:03:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:03:31 --> Language Class Initialized
INFO - 2023-08-16 20:03:31 --> Input Class Initialized
INFO - 2023-08-16 20:03:31 --> Language Class Initialized
INFO - 2023-08-16 20:03:31 --> Language Class Initialized
ERROR - 2023-08-16 20:03:31 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-16 20:03:31 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 20:03:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:03:47 --> Config Class Initialized
INFO - 2023-08-16 20:03:47 --> Hooks Class Initialized
INFO - 2023-08-16 20:03:47 --> Config Class Initialized
INFO - 2023-08-16 20:03:47 --> Config Class Initialized
DEBUG - 2023-08-16 20:03:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:03:47 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:47 --> URI Class Initialized
INFO - 2023-08-16 20:03:47 --> Router Class Initialized
INFO - 2023-08-16 20:03:47 --> Output Class Initialized
INFO - 2023-08-16 20:03:47 --> Security Class Initialized
DEBUG - 2023-08-16 20:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:03:47 --> Input Class Initialized
INFO - 2023-08-16 20:03:47 --> Language Class Initialized
ERROR - 2023-08-16 20:03:47 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:03:47 --> Config Class Initialized
INFO - 2023-08-16 20:03:47 --> Hooks Class Initialized
INFO - 2023-08-16 20:03:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:03:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:03:47 --> Hooks Class Initialized
INFO - 2023-08-16 20:03:47 --> Config Class Initialized
INFO - 2023-08-16 20:03:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:03:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:03:47 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:47 --> URI Class Initialized
INFO - 2023-08-16 20:03:47 --> Router Class Initialized
INFO - 2023-08-16 20:03:47 --> Output Class Initialized
INFO - 2023-08-16 20:03:47 --> Security Class Initialized
DEBUG - 2023-08-16 20:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:03:47 --> Input Class Initialized
INFO - 2023-08-16 20:03:47 --> Language Class Initialized
ERROR - 2023-08-16 20:03:47 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 20:03:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:03:47 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:47 --> URI Class Initialized
INFO - 2023-08-16 20:03:47 --> Router Class Initialized
INFO - 2023-08-16 20:03:47 --> Output Class Initialized
INFO - 2023-08-16 20:03:47 --> Security Class Initialized
DEBUG - 2023-08-16 20:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:03:47 --> Input Class Initialized
INFO - 2023-08-16 20:03:47 --> Language Class Initialized
ERROR - 2023-08-16 20:03:47 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 20:03:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:03:47 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:47 --> Config Class Initialized
INFO - 2023-08-16 20:03:48 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:48 --> URI Class Initialized
INFO - 2023-08-16 20:03:48 --> URI Class Initialized
INFO - 2023-08-16 20:03:48 --> Hooks Class Initialized
INFO - 2023-08-16 20:03:48 --> Router Class Initialized
INFO - 2023-08-16 20:03:48 --> Config Class Initialized
INFO - 2023-08-16 20:03:48 --> Router Class Initialized
INFO - 2023-08-16 20:03:48 --> Output Class Initialized
INFO - 2023-08-16 20:03:48 --> Output Class Initialized
INFO - 2023-08-16 20:03:48 --> Security Class Initialized
DEBUG - 2023-08-16 20:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:03:48 --> Input Class Initialized
INFO - 2023-08-16 20:03:48 --> Language Class Initialized
ERROR - 2023-08-16 20:03:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:03:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:03:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:03:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:03:48 --> Security Class Initialized
INFO - 2023-08-16 20:03:48 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:48 --> Utf8 Class Initialized
INFO - 2023-08-16 20:03:48 --> URI Class Initialized
INFO - 2023-08-16 20:03:48 --> Router Class Initialized
DEBUG - 2023-08-16 20:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:03:48 --> URI Class Initialized
INFO - 2023-08-16 20:03:48 --> Input Class Initialized
INFO - 2023-08-16 20:03:48 --> Router Class Initialized
INFO - 2023-08-16 20:03:48 --> Language Class Initialized
INFO - 2023-08-16 20:03:48 --> Output Class Initialized
INFO - 2023-08-16 20:03:48 --> Output Class Initialized
INFO - 2023-08-16 20:03:48 --> Security Class Initialized
INFO - 2023-08-16 20:03:48 --> Security Class Initialized
DEBUG - 2023-08-16 20:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 20:03:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 20:03:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:03:48 --> Input Class Initialized
INFO - 2023-08-16 20:03:48 --> Input Class Initialized
INFO - 2023-08-16 20:03:48 --> Language Class Initialized
INFO - 2023-08-16 20:03:48 --> Language Class Initialized
ERROR - 2023-08-16 20:03:48 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-16 20:03:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:04:28 --> Config Class Initialized
INFO - 2023-08-16 20:04:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:28 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:28 --> URI Class Initialized
INFO - 2023-08-16 20:04:28 --> Router Class Initialized
INFO - 2023-08-16 20:04:28 --> Output Class Initialized
INFO - 2023-08-16 20:04:28 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:28 --> Input Class Initialized
INFO - 2023-08-16 20:04:28 --> Language Class Initialized
INFO - 2023-08-16 20:04:28 --> Loader Class Initialized
INFO - 2023-08-16 20:04:28 --> Helper loaded: url_helper
INFO - 2023-08-16 20:04:28 --> Helper loaded: file_helper
INFO - 2023-08-16 20:04:28 --> Database Driver Class Initialized
INFO - 2023-08-16 20:04:28 --> Email Class Initialized
DEBUG - 2023-08-16 20:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:04:28 --> Controller Class Initialized
INFO - 2023-08-16 20:04:28 --> Model "Home_model" initialized
INFO - 2023-08-16 20:04:28 --> Helper loaded: form_helper
INFO - 2023-08-16 20:04:28 --> Form Validation Class Initialized
INFO - 2023-08-16 20:04:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:04:28 --> Final output sent to browser
DEBUG - 2023-08-16 20:04:28 --> Total execution time: 0.4689
INFO - 2023-08-16 20:04:29 --> Config Class Initialized
INFO - 2023-08-16 20:04:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:29 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:29 --> URI Class Initialized
INFO - 2023-08-16 20:04:29 --> Router Class Initialized
INFO - 2023-08-16 20:04:29 --> Output Class Initialized
INFO - 2023-08-16 20:04:29 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:29 --> Input Class Initialized
INFO - 2023-08-16 20:04:29 --> Language Class Initialized
ERROR - 2023-08-16 20:04:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:04:29 --> Config Class Initialized
INFO - 2023-08-16 20:04:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:29 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:29 --> URI Class Initialized
INFO - 2023-08-16 20:04:29 --> Router Class Initialized
INFO - 2023-08-16 20:04:29 --> Output Class Initialized
INFO - 2023-08-16 20:04:29 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:29 --> Input Class Initialized
INFO - 2023-08-16 20:04:29 --> Language Class Initialized
ERROR - 2023-08-16 20:04:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:04:29 --> Config Class Initialized
INFO - 2023-08-16 20:04:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:29 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:29 --> URI Class Initialized
INFO - 2023-08-16 20:04:29 --> Router Class Initialized
INFO - 2023-08-16 20:04:29 --> Output Class Initialized
INFO - 2023-08-16 20:04:29 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:29 --> Input Class Initialized
INFO - 2023-08-16 20:04:29 --> Language Class Initialized
ERROR - 2023-08-16 20:04:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:04:29 --> Config Class Initialized
INFO - 2023-08-16 20:04:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:29 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:29 --> URI Class Initialized
INFO - 2023-08-16 20:04:29 --> Router Class Initialized
INFO - 2023-08-16 20:04:29 --> Output Class Initialized
INFO - 2023-08-16 20:04:29 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:29 --> Input Class Initialized
INFO - 2023-08-16 20:04:29 --> Language Class Initialized
ERROR - 2023-08-16 20:04:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:04:29 --> Config Class Initialized
INFO - 2023-08-16 20:04:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:29 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:29 --> URI Class Initialized
INFO - 2023-08-16 20:04:29 --> Router Class Initialized
INFO - 2023-08-16 20:04:29 --> Output Class Initialized
INFO - 2023-08-16 20:04:29 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:29 --> Input Class Initialized
INFO - 2023-08-16 20:04:29 --> Language Class Initialized
ERROR - 2023-08-16 20:04:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:04:29 --> Config Class Initialized
INFO - 2023-08-16 20:04:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:29 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:29 --> URI Class Initialized
INFO - 2023-08-16 20:04:29 --> Router Class Initialized
INFO - 2023-08-16 20:04:29 --> Output Class Initialized
INFO - 2023-08-16 20:04:29 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:29 --> Input Class Initialized
INFO - 2023-08-16 20:04:29 --> Language Class Initialized
ERROR - 2023-08-16 20:04:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:04:29 --> Config Class Initialized
INFO - 2023-08-16 20:04:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:29 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:29 --> URI Class Initialized
INFO - 2023-08-16 20:04:29 --> Router Class Initialized
INFO - 2023-08-16 20:04:29 --> Output Class Initialized
INFO - 2023-08-16 20:04:29 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:29 --> Input Class Initialized
INFO - 2023-08-16 20:04:29 --> Language Class Initialized
ERROR - 2023-08-16 20:04:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:04:30 --> Config Class Initialized
INFO - 2023-08-16 20:04:30 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:30 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:30 --> URI Class Initialized
INFO - 2023-08-16 20:04:30 --> Router Class Initialized
INFO - 2023-08-16 20:04:30 --> Output Class Initialized
INFO - 2023-08-16 20:04:30 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:30 --> Input Class Initialized
INFO - 2023-08-16 20:04:30 --> Language Class Initialized
ERROR - 2023-08-16 20:04:30 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:04:30 --> Config Class Initialized
INFO - 2023-08-16 20:04:30 --> Config Class Initialized
INFO - 2023-08-16 20:04:30 --> Config Class Initialized
INFO - 2023-08-16 20:04:30 --> Hooks Class Initialized
INFO - 2023-08-16 20:04:30 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:04:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:30 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:30 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:30 --> URI Class Initialized
INFO - 2023-08-16 20:04:30 --> URI Class Initialized
INFO - 2023-08-16 20:04:30 --> Router Class Initialized
INFO - 2023-08-16 20:04:30 --> Router Class Initialized
INFO - 2023-08-16 20:04:30 --> Output Class Initialized
INFO - 2023-08-16 20:04:30 --> Output Class Initialized
INFO - 2023-08-16 20:04:30 --> Security Class Initialized
INFO - 2023-08-16 20:04:30 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 20:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:30 --> Input Class Initialized
INFO - 2023-08-16 20:04:30 --> Input Class Initialized
INFO - 2023-08-16 20:04:30 --> Language Class Initialized
INFO - 2023-08-16 20:04:30 --> Language Class Initialized
ERROR - 2023-08-16 20:04:30 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 20:04:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:04:30 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:30 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:30 --> URI Class Initialized
INFO - 2023-08-16 20:04:30 --> Router Class Initialized
INFO - 2023-08-16 20:04:30 --> Output Class Initialized
INFO - 2023-08-16 20:04:30 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:30 --> Input Class Initialized
INFO - 2023-08-16 20:04:30 --> Language Class Initialized
ERROR - 2023-08-16 20:04:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:04:31 --> Config Class Initialized
INFO - 2023-08-16 20:04:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:31 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:31 --> URI Class Initialized
INFO - 2023-08-16 20:04:31 --> Router Class Initialized
INFO - 2023-08-16 20:04:31 --> Output Class Initialized
INFO - 2023-08-16 20:04:31 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:31 --> Input Class Initialized
INFO - 2023-08-16 20:04:31 --> Language Class Initialized
ERROR - 2023-08-16 20:04:31 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:04:31 --> Config Class Initialized
INFO - 2023-08-16 20:04:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:31 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:31 --> URI Class Initialized
INFO - 2023-08-16 20:04:31 --> Router Class Initialized
INFO - 2023-08-16 20:04:31 --> Output Class Initialized
INFO - 2023-08-16 20:04:31 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:31 --> Input Class Initialized
INFO - 2023-08-16 20:04:31 --> Language Class Initialized
ERROR - 2023-08-16 20:04:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:04:31 --> Config Class Initialized
INFO - 2023-08-16 20:04:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:31 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:31 --> URI Class Initialized
INFO - 2023-08-16 20:04:31 --> Router Class Initialized
INFO - 2023-08-16 20:04:31 --> Output Class Initialized
INFO - 2023-08-16 20:04:31 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:31 --> Input Class Initialized
INFO - 2023-08-16 20:04:31 --> Language Class Initialized
ERROR - 2023-08-16 20:04:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:04:32 --> Config Class Initialized
INFO - 2023-08-16 20:04:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:04:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:04:32 --> Utf8 Class Initialized
INFO - 2023-08-16 20:04:32 --> URI Class Initialized
INFO - 2023-08-16 20:04:32 --> Router Class Initialized
INFO - 2023-08-16 20:04:32 --> Output Class Initialized
INFO - 2023-08-16 20:04:32 --> Security Class Initialized
DEBUG - 2023-08-16 20:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:04:32 --> Input Class Initialized
INFO - 2023-08-16 20:04:32 --> Language Class Initialized
ERROR - 2023-08-16 20:04:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:05 --> Config Class Initialized
INFO - 2023-08-16 20:05:05 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:05 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:05 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:05 --> URI Class Initialized
INFO - 2023-08-16 20:05:05 --> Router Class Initialized
INFO - 2023-08-16 20:05:05 --> Output Class Initialized
INFO - 2023-08-16 20:05:05 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:05 --> Input Class Initialized
INFO - 2023-08-16 20:05:05 --> Language Class Initialized
INFO - 2023-08-16 20:05:05 --> Loader Class Initialized
INFO - 2023-08-16 20:05:05 --> Helper loaded: url_helper
INFO - 2023-08-16 20:05:05 --> Helper loaded: file_helper
INFO - 2023-08-16 20:05:05 --> Database Driver Class Initialized
INFO - 2023-08-16 20:05:05 --> Email Class Initialized
DEBUG - 2023-08-16 20:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:05:05 --> Controller Class Initialized
INFO - 2023-08-16 20:05:05 --> Model "Home_model" initialized
INFO - 2023-08-16 20:05:05 --> Helper loaded: form_helper
INFO - 2023-08-16 20:05:06 --> Form Validation Class Initialized
INFO - 2023-08-16 20:05:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:05:06 --> Final output sent to browser
DEBUG - 2023-08-16 20:05:06 --> Total execution time: 0.4849
INFO - 2023-08-16 20:05:06 --> Config Class Initialized
INFO - 2023-08-16 20:05:06 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:06 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:06 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:06 --> URI Class Initialized
INFO - 2023-08-16 20:05:06 --> Router Class Initialized
INFO - 2023-08-16 20:05:06 --> Output Class Initialized
INFO - 2023-08-16 20:05:06 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:06 --> Input Class Initialized
INFO - 2023-08-16 20:05:06 --> Language Class Initialized
ERROR - 2023-08-16 20:05:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:07 --> Config Class Initialized
INFO - 2023-08-16 20:05:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:07 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:07 --> URI Class Initialized
INFO - 2023-08-16 20:05:07 --> Router Class Initialized
INFO - 2023-08-16 20:05:07 --> Output Class Initialized
INFO - 2023-08-16 20:05:07 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:07 --> Input Class Initialized
INFO - 2023-08-16 20:05:07 --> Language Class Initialized
ERROR - 2023-08-16 20:05:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:07 --> Config Class Initialized
INFO - 2023-08-16 20:05:07 --> Config Class Initialized
INFO - 2023-08-16 20:05:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:07 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:07 --> URI Class Initialized
INFO - 2023-08-16 20:05:07 --> Router Class Initialized
INFO - 2023-08-16 20:05:07 --> Output Class Initialized
INFO - 2023-08-16 20:05:07 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:07 --> Input Class Initialized
INFO - 2023-08-16 20:05:07 --> Language Class Initialized
ERROR - 2023-08-16 20:05:07 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:05:07 --> Config Class Initialized
INFO - 2023-08-16 20:05:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:07 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:07 --> URI Class Initialized
INFO - 2023-08-16 20:05:07 --> Router Class Initialized
INFO - 2023-08-16 20:05:07 --> Output Class Initialized
INFO - 2023-08-16 20:05:07 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:07 --> Input Class Initialized
INFO - 2023-08-16 20:05:07 --> Language Class Initialized
ERROR - 2023-08-16 20:05:07 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:05:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:07 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:07 --> URI Class Initialized
INFO - 2023-08-16 20:05:07 --> Router Class Initialized
INFO - 2023-08-16 20:05:07 --> Output Class Initialized
INFO - 2023-08-16 20:05:07 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:07 --> Input Class Initialized
INFO - 2023-08-16 20:05:07 --> Language Class Initialized
ERROR - 2023-08-16 20:05:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:08 --> Config Class Initialized
INFO - 2023-08-16 20:05:08 --> Hooks Class Initialized
INFO - 2023-08-16 20:05:08 --> Config Class Initialized
INFO - 2023-08-16 20:05:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:08 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:08 --> URI Class Initialized
INFO - 2023-08-16 20:05:08 --> Router Class Initialized
INFO - 2023-08-16 20:05:08 --> Output Class Initialized
INFO - 2023-08-16 20:05:08 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:08 --> Input Class Initialized
INFO - 2023-08-16 20:05:08 --> Language Class Initialized
ERROR - 2023-08-16 20:05:08 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 20:05:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:08 --> Config Class Initialized
INFO - 2023-08-16 20:05:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:08 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:08 --> URI Class Initialized
INFO - 2023-08-16 20:05:08 --> Router Class Initialized
INFO - 2023-08-16 20:05:08 --> Output Class Initialized
INFO - 2023-08-16 20:05:08 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:08 --> Input Class Initialized
INFO - 2023-08-16 20:05:08 --> Language Class Initialized
ERROR - 2023-08-16 20:05:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:05:08 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:08 --> Config Class Initialized
INFO - 2023-08-16 20:05:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:08 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:08 --> URI Class Initialized
INFO - 2023-08-16 20:05:08 --> Router Class Initialized
INFO - 2023-08-16 20:05:08 --> Output Class Initialized
INFO - 2023-08-16 20:05:08 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:08 --> Input Class Initialized
INFO - 2023-08-16 20:05:08 --> Language Class Initialized
ERROR - 2023-08-16 20:05:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:05:08 --> URI Class Initialized
INFO - 2023-08-16 20:05:08 --> Config Class Initialized
INFO - 2023-08-16 20:05:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:08 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:08 --> URI Class Initialized
INFO - 2023-08-16 20:05:08 --> Router Class Initialized
INFO - 2023-08-16 20:05:08 --> Output Class Initialized
INFO - 2023-08-16 20:05:08 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:08 --> Input Class Initialized
INFO - 2023-08-16 20:05:08 --> Language Class Initialized
ERROR - 2023-08-16 20:05:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:05:09 --> Router Class Initialized
INFO - 2023-08-16 20:05:09 --> Config Class Initialized
INFO - 2023-08-16 20:05:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:09 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:09 --> URI Class Initialized
INFO - 2023-08-16 20:05:09 --> Router Class Initialized
INFO - 2023-08-16 20:05:09 --> Output Class Initialized
INFO - 2023-08-16 20:05:09 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:09 --> Input Class Initialized
INFO - 2023-08-16 20:05:09 --> Language Class Initialized
ERROR - 2023-08-16 20:05:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:09 --> Output Class Initialized
INFO - 2023-08-16 20:05:09 --> Config Class Initialized
INFO - 2023-08-16 20:05:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:09 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:09 --> URI Class Initialized
INFO - 2023-08-16 20:05:09 --> Router Class Initialized
INFO - 2023-08-16 20:05:09 --> Output Class Initialized
INFO - 2023-08-16 20:05:09 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:09 --> Input Class Initialized
INFO - 2023-08-16 20:05:09 --> Language Class Initialized
ERROR - 2023-08-16 20:05:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:09 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:09 --> Config Class Initialized
INFO - 2023-08-16 20:05:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:09 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:09 --> URI Class Initialized
INFO - 2023-08-16 20:05:09 --> Router Class Initialized
INFO - 2023-08-16 20:05:09 --> Output Class Initialized
INFO - 2023-08-16 20:05:09 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:09 --> Input Class Initialized
INFO - 2023-08-16 20:05:09 --> Language Class Initialized
ERROR - 2023-08-16 20:05:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:09 --> Input Class Initialized
INFO - 2023-08-16 20:05:09 --> Language Class Initialized
ERROR - 2023-08-16 20:05:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:05:10 --> Config Class Initialized
INFO - 2023-08-16 20:05:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:10 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:10 --> URI Class Initialized
INFO - 2023-08-16 20:05:10 --> Router Class Initialized
INFO - 2023-08-16 20:05:10 --> Output Class Initialized
INFO - 2023-08-16 20:05:10 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:10 --> Input Class Initialized
INFO - 2023-08-16 20:05:10 --> Language Class Initialized
ERROR - 2023-08-16 20:05:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:10 --> Config Class Initialized
INFO - 2023-08-16 20:05:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:10 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:10 --> URI Class Initialized
INFO - 2023-08-16 20:05:10 --> Router Class Initialized
INFO - 2023-08-16 20:05:10 --> Output Class Initialized
INFO - 2023-08-16 20:05:10 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:10 --> Input Class Initialized
INFO - 2023-08-16 20:05:10 --> Language Class Initialized
ERROR - 2023-08-16 20:05:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:10 --> Config Class Initialized
INFO - 2023-08-16 20:05:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:10 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:10 --> URI Class Initialized
INFO - 2023-08-16 20:05:10 --> Router Class Initialized
INFO - 2023-08-16 20:05:10 --> Output Class Initialized
INFO - 2023-08-16 20:05:10 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:10 --> Input Class Initialized
INFO - 2023-08-16 20:05:10 --> Language Class Initialized
ERROR - 2023-08-16 20:05:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:21 --> Config Class Initialized
INFO - 2023-08-16 20:05:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:21 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:21 --> URI Class Initialized
INFO - 2023-08-16 20:05:21 --> Router Class Initialized
INFO - 2023-08-16 20:05:21 --> Output Class Initialized
INFO - 2023-08-16 20:05:21 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:21 --> Input Class Initialized
INFO - 2023-08-16 20:05:21 --> Language Class Initialized
INFO - 2023-08-16 20:05:21 --> Loader Class Initialized
INFO - 2023-08-16 20:05:21 --> Helper loaded: url_helper
INFO - 2023-08-16 20:05:21 --> Helper loaded: file_helper
INFO - 2023-08-16 20:05:21 --> Database Driver Class Initialized
INFO - 2023-08-16 20:05:21 --> Email Class Initialized
DEBUG - 2023-08-16 20:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:05:21 --> Controller Class Initialized
INFO - 2023-08-16 20:05:21 --> Model "Home_model" initialized
INFO - 2023-08-16 20:05:21 --> Helper loaded: form_helper
INFO - 2023-08-16 20:05:21 --> Form Validation Class Initialized
INFO - 2023-08-16 20:05:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:05:21 --> Final output sent to browser
DEBUG - 2023-08-16 20:05:22 --> Total execution time: 0.4953
INFO - 2023-08-16 20:05:22 --> Config Class Initialized
INFO - 2023-08-16 20:05:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:22 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:22 --> URI Class Initialized
INFO - 2023-08-16 20:05:22 --> Router Class Initialized
INFO - 2023-08-16 20:05:22 --> Output Class Initialized
INFO - 2023-08-16 20:05:22 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:22 --> Input Class Initialized
INFO - 2023-08-16 20:05:22 --> Language Class Initialized
ERROR - 2023-08-16 20:05:22 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:22 --> Config Class Initialized
INFO - 2023-08-16 20:05:23 --> Hooks Class Initialized
INFO - 2023-08-16 20:05:23 --> Config Class Initialized
INFO - 2023-08-16 20:05:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:05:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:24 --> Config Class Initialized
INFO - 2023-08-16 20:05:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:24 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:24 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:24 --> Config Class Initialized
INFO - 2023-08-16 20:05:24 --> Config Class Initialized
INFO - 2023-08-16 20:05:24 --> Config Class Initialized
INFO - 2023-08-16 20:05:24 --> Hooks Class Initialized
INFO - 2023-08-16 20:05:24 --> Hooks Class Initialized
INFO - 2023-08-16 20:05:24 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:24 --> URI Class Initialized
INFO - 2023-08-16 20:05:24 --> URI Class Initialized
INFO - 2023-08-16 20:05:25 --> Router Class Initialized
DEBUG - 2023-08-16 20:05:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:05:25 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:25 --> URI Class Initialized
INFO - 2023-08-16 20:05:25 --> Hooks Class Initialized
INFO - 2023-08-16 20:05:25 --> Router Class Initialized
INFO - 2023-08-16 20:05:25 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:25 --> Output Class Initialized
INFO - 2023-08-16 20:05:25 --> Router Class Initialized
DEBUG - 2023-08-16 20:05:25 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:25 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:25 --> URI Class Initialized
INFO - 2023-08-16 20:05:25 --> Router Class Initialized
INFO - 2023-08-16 20:05:25 --> Output Class Initialized
INFO - 2023-08-16 20:05:25 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:25 --> Input Class Initialized
INFO - 2023-08-16 20:05:25 --> Language Class Initialized
ERROR - 2023-08-16 20:05:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:25 --> URI Class Initialized
INFO - 2023-08-16 20:05:25 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:25 --> Output Class Initialized
INFO - 2023-08-16 20:05:25 --> Output Class Initialized
INFO - 2023-08-16 20:05:25 --> Security Class Initialized
INFO - 2023-08-16 20:05:25 --> Router Class Initialized
INFO - 2023-08-16 20:05:25 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 20:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:25 --> Security Class Initialized
INFO - 2023-08-16 20:05:25 --> Input Class Initialized
INFO - 2023-08-16 20:05:25 --> Config Class Initialized
DEBUG - 2023-08-16 20:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:25 --> URI Class Initialized
INFO - 2023-08-16 20:05:25 --> Hooks Class Initialized
INFO - 2023-08-16 20:05:25 --> Output Class Initialized
INFO - 2023-08-16 20:05:25 --> Router Class Initialized
INFO - 2023-08-16 20:05:25 --> Input Class Initialized
INFO - 2023-08-16 20:05:25 --> Language Class Initialized
DEBUG - 2023-08-16 20:05:25 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:25 --> Output Class Initialized
INFO - 2023-08-16 20:05:25 --> Input Class Initialized
INFO - 2023-08-16 20:05:25 --> Security Class Initialized
INFO - 2023-08-16 20:05:25 --> Language Class Initialized
INFO - 2023-08-16 20:05:25 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:25 --> Security Class Initialized
INFO - 2023-08-16 20:05:25 --> Language Class Initialized
ERROR - 2023-08-16 20:05:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:25 --> URI Class Initialized
ERROR - 2023-08-16 20:05:25 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 20:05:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 20:05:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:05:25 --> Router Class Initialized
DEBUG - 2023-08-16 20:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:25 --> Output Class Initialized
INFO - 2023-08-16 20:05:25 --> Input Class Initialized
INFO - 2023-08-16 20:05:25 --> Config Class Initialized
INFO - 2023-08-16 20:05:25 --> Language Class Initialized
ERROR - 2023-08-16 20:05:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:25 --> Security Class Initialized
INFO - 2023-08-16 20:05:25 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:25 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:25 --> Config Class Initialized
INFO - 2023-08-16 20:05:25 --> Input Class Initialized
INFO - 2023-08-16 20:05:25 --> Config Class Initialized
DEBUG - 2023-08-16 20:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:26 --> Config Class Initialized
INFO - 2023-08-16 20:05:26 --> Language Class Initialized
INFO - 2023-08-16 20:05:26 --> Hooks Class Initialized
INFO - 2023-08-16 20:05:26 --> Hooks Class Initialized
INFO - 2023-08-16 20:05:26 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:26 --> URI Class Initialized
DEBUG - 2023-08-16 20:05:26 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:26 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:26 --> UTF-8 Support Enabled
ERROR - 2023-08-16 20:05:26 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 20:05:26 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:26 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:26 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:26 --> Input Class Initialized
INFO - 2023-08-16 20:05:26 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:26 --> Router Class Initialized
INFO - 2023-08-16 20:05:26 --> URI Class Initialized
INFO - 2023-08-16 20:05:26 --> URI Class Initialized
INFO - 2023-08-16 20:05:26 --> Language Class Initialized
INFO - 2023-08-16 20:05:26 --> URI Class Initialized
INFO - 2023-08-16 20:05:26 --> Router Class Initialized
INFO - 2023-08-16 20:05:26 --> Router Class Initialized
INFO - 2023-08-16 20:05:26 --> Output Class Initialized
INFO - 2023-08-16 20:05:26 --> Config Class Initialized
ERROR - 2023-08-16 20:05:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:05:26 --> Router Class Initialized
INFO - 2023-08-16 20:05:26 --> Output Class Initialized
INFO - 2023-08-16 20:05:26 --> Output Class Initialized
INFO - 2023-08-16 20:05:26 --> Hooks Class Initialized
INFO - 2023-08-16 20:05:26 --> Security Class Initialized
DEBUG - 2023-08-16 20:05:26 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:05:26 --> Security Class Initialized
INFO - 2023-08-16 20:05:26 --> Security Class Initialized
INFO - 2023-08-16 20:05:26 --> Output Class Initialized
DEBUG - 2023-08-16 20:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:26 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:26 --> Input Class Initialized
DEBUG - 2023-08-16 20:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:26 --> Input Class Initialized
INFO - 2023-08-16 20:05:26 --> Security Class Initialized
INFO - 2023-08-16 20:05:26 --> Language Class Initialized
INFO - 2023-08-16 20:05:26 --> Input Class Initialized
INFO - 2023-08-16 20:05:26 --> URI Class Initialized
DEBUG - 2023-08-16 20:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:26 --> Language Class Initialized
INFO - 2023-08-16 20:05:26 --> Config Class Initialized
ERROR - 2023-08-16 20:05:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:05:26 --> Input Class Initialized
INFO - 2023-08-16 20:05:26 --> Router Class Initialized
INFO - 2023-08-16 20:05:26 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:05:27 --> UTF-8 Support Enabled
ERROR - 2023-08-16 20:05:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:05:27 --> Language Class Initialized
INFO - 2023-08-16 20:05:27 --> Utf8 Class Initialized
INFO - 2023-08-16 20:05:27 --> Language Class Initialized
INFO - 2023-08-16 20:05:27 --> Output Class Initialized
ERROR - 2023-08-16 20:05:27 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-16 20:05:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:05:27 --> URI Class Initialized
INFO - 2023-08-16 20:05:27 --> Security Class Initialized
INFO - 2023-08-16 20:05:27 --> Router Class Initialized
DEBUG - 2023-08-16 20:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:05:27 --> Output Class Initialized
INFO - 2023-08-16 20:05:27 --> Input Class Initialized
INFO - 2023-08-16 20:05:27 --> Security Class Initialized
INFO - 2023-08-16 20:05:27 --> Language Class Initialized
DEBUG - 2023-08-16 20:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 20:05:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:05:27 --> Input Class Initialized
INFO - 2023-08-16 20:05:27 --> Language Class Initialized
ERROR - 2023-08-16 20:05:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:06:07 --> Config Class Initialized
INFO - 2023-08-16 20:06:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:06:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:06:07 --> Utf8 Class Initialized
INFO - 2023-08-16 20:06:07 --> URI Class Initialized
INFO - 2023-08-16 20:06:07 --> Router Class Initialized
INFO - 2023-08-16 20:06:07 --> Output Class Initialized
INFO - 2023-08-16 20:06:07 --> Security Class Initialized
DEBUG - 2023-08-16 20:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:06:07 --> Input Class Initialized
INFO - 2023-08-16 20:06:07 --> Language Class Initialized
INFO - 2023-08-16 20:06:07 --> Loader Class Initialized
INFO - 2023-08-16 20:06:07 --> Helper loaded: url_helper
INFO - 2023-08-16 20:06:07 --> Helper loaded: file_helper
INFO - 2023-08-16 20:06:07 --> Database Driver Class Initialized
INFO - 2023-08-16 20:06:08 --> Email Class Initialized
DEBUG - 2023-08-16 20:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:06:08 --> Controller Class Initialized
INFO - 2023-08-16 20:06:08 --> Model "Home_model" initialized
INFO - 2023-08-16 20:06:08 --> Helper loaded: form_helper
INFO - 2023-08-16 20:06:08 --> Form Validation Class Initialized
INFO - 2023-08-16 20:06:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:06:08 --> Final output sent to browser
DEBUG - 2023-08-16 20:06:08 --> Total execution time: 0.6164
INFO - 2023-08-16 20:06:09 --> Config Class Initialized
INFO - 2023-08-16 20:06:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:06:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:06:10 --> Utf8 Class Initialized
INFO - 2023-08-16 20:06:11 --> Config Class Initialized
INFO - 2023-08-16 20:06:11 --> URI Class Initialized
INFO - 2023-08-16 20:06:11 --> Config Class Initialized
INFO - 2023-08-16 20:06:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:06:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:06:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:06:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:06:11 --> Utf8 Class Initialized
INFO - 2023-08-16 20:06:11 --> Config Class Initialized
INFO - 2023-08-16 20:06:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:06:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:06:11 --> Utf8 Class Initialized
INFO - 2023-08-16 20:06:11 --> URI Class Initialized
INFO - 2023-08-16 20:06:11 --> Router Class Initialized
INFO - 2023-08-16 20:06:11 --> Output Class Initialized
INFO - 2023-08-16 20:06:11 --> Security Class Initialized
DEBUG - 2023-08-16 20:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:06:11 --> Input Class Initialized
INFO - 2023-08-16 20:06:11 --> Language Class Initialized
ERROR - 2023-08-16 20:06:11 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:06:11 --> Utf8 Class Initialized
INFO - 2023-08-16 20:06:11 --> Config Class Initialized
INFO - 2023-08-16 20:06:11 --> Router Class Initialized
INFO - 2023-08-16 20:06:11 --> Config Class Initialized
INFO - 2023-08-16 20:06:11 --> Hooks Class Initialized
INFO - 2023-08-16 20:06:11 --> Hooks Class Initialized
INFO - 2023-08-16 20:06:11 --> Output Class Initialized
INFO - 2023-08-16 20:06:11 --> Security Class Initialized
DEBUG - 2023-08-16 20:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:06:11 --> Input Class Initialized
INFO - 2023-08-16 20:06:11 --> Language Class Initialized
ERROR - 2023-08-16 20:06:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:06:11 --> URI Class Initialized
INFO - 2023-08-16 20:06:11 --> URI Class Initialized
DEBUG - 2023-08-16 20:06:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:06:12 --> Config Class Initialized
INFO - 2023-08-16 20:06:12 --> Router Class Initialized
INFO - 2023-08-16 20:06:12 --> Config Class Initialized
DEBUG - 2023-08-16 20:06:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:06:12 --> Utf8 Class Initialized
INFO - 2023-08-16 20:06:12 --> Router Class Initialized
INFO - 2023-08-16 20:06:12 --> Hooks Class Initialized
INFO - 2023-08-16 20:06:12 --> Hooks Class Initialized
INFO - 2023-08-16 20:06:12 --> Output Class Initialized
INFO - 2023-08-16 20:06:12 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:06:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:06:12 --> URI Class Initialized
INFO - 2023-08-16 20:06:12 --> Output Class Initialized
INFO - 2023-08-16 20:06:12 --> Security Class Initialized
INFO - 2023-08-16 20:06:12 --> URI Class Initialized
INFO - 2023-08-16 20:06:12 --> Router Class Initialized
INFO - 2023-08-16 20:06:12 --> Output Class Initialized
INFO - 2023-08-16 20:06:12 --> Security Class Initialized
DEBUG - 2023-08-16 20:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:06:12 --> Input Class Initialized
INFO - 2023-08-16 20:06:12 --> Language Class Initialized
ERROR - 2023-08-16 20:06:12 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 20:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:06:12 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:06:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:06:12 --> Config Class Initialized
INFO - 2023-08-16 20:06:12 --> Router Class Initialized
INFO - 2023-08-16 20:06:12 --> URI Class Initialized
INFO - 2023-08-16 20:06:12 --> Hooks Class Initialized
INFO - 2023-08-16 20:06:12 --> Security Class Initialized
INFO - 2023-08-16 20:06:12 --> Utf8 Class Initialized
INFO - 2023-08-16 20:06:12 --> Input Class Initialized
INFO - 2023-08-16 20:06:12 --> Output Class Initialized
INFO - 2023-08-16 20:06:12 --> Security Class Initialized
DEBUG - 2023-08-16 20:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:06:12 --> Input Class Initialized
INFO - 2023-08-16 20:06:12 --> Language Class Initialized
ERROR - 2023-08-16 20:06:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:06:12 --> Router Class Initialized
INFO - 2023-08-16 20:06:12 --> Language Class Initialized
INFO - 2023-08-16 20:06:12 --> URI Class Initialized
ERROR - 2023-08-16 20:06:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:06:12 --> Output Class Initialized
DEBUG - 2023-08-16 20:06:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:06:12 --> Router Class Initialized
INFO - 2023-08-16 20:06:12 --> Output Class Initialized
INFO - 2023-08-16 20:06:12 --> Security Class Initialized
DEBUG - 2023-08-16 20:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:06:12 --> Input Class Initialized
INFO - 2023-08-16 20:06:12 --> Language Class Initialized
ERROR - 2023-08-16 20:06:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:06:12 --> Utf8 Class Initialized
INFO - 2023-08-16 20:06:12 --> Config Class Initialized
INFO - 2023-08-16 20:06:12 --> Security Class Initialized
INFO - 2023-08-16 20:06:12 --> URI Class Initialized
INFO - 2023-08-16 20:06:12 --> Input Class Initialized
INFO - 2023-08-16 20:06:12 --> Config Class Initialized
INFO - 2023-08-16 20:06:12 --> Hooks Class Initialized
INFO - 2023-08-16 20:06:12 --> Config Class Initialized
DEBUG - 2023-08-16 20:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:06:12 --> Language Class Initialized
ERROR - 2023-08-16 20:06:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:06:12 --> Hooks Class Initialized
INFO - 2023-08-16 20:06:12 --> Input Class Initialized
DEBUG - 2023-08-16 20:06:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:06:12 --> Utf8 Class Initialized
INFO - 2023-08-16 20:06:12 --> URI Class Initialized
INFO - 2023-08-16 20:06:12 --> Router Class Initialized
INFO - 2023-08-16 20:06:12 --> Output Class Initialized
INFO - 2023-08-16 20:06:12 --> Security Class Initialized
DEBUG - 2023-08-16 20:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:06:12 --> Input Class Initialized
INFO - 2023-08-16 20:06:12 --> Language Class Initialized
ERROR - 2023-08-16 20:06:12 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:06:12 --> Router Class Initialized
INFO - 2023-08-16 20:06:12 --> Config Class Initialized
INFO - 2023-08-16 20:06:12 --> Output Class Initialized
DEBUG - 2023-08-16 20:06:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:06:12 --> Security Class Initialized
INFO - 2023-08-16 20:06:12 --> Hooks Class Initialized
INFO - 2023-08-16 20:06:13 --> Language Class Initialized
INFO - 2023-08-16 20:06:13 --> Utf8 Class Initialized
INFO - 2023-08-16 20:06:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 20:06:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:06:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:06:13 --> Utf8 Class Initialized
INFO - 2023-08-16 20:06:13 --> URI Class Initialized
INFO - 2023-08-16 20:06:13 --> Input Class Initialized
ERROR - 2023-08-16 20:06:13 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:06:13 --> Language Class Initialized
INFO - 2023-08-16 20:06:13 --> Router Class Initialized
INFO - 2023-08-16 20:06:13 --> Utf8 Class Initialized
INFO - 2023-08-16 20:06:13 --> URI Class Initialized
INFO - 2023-08-16 20:06:13 --> Output Class Initialized
INFO - 2023-08-16 20:06:13 --> Security Class Initialized
ERROR - 2023-08-16 20:06:13 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:06:13 --> URI Class Initialized
DEBUG - 2023-08-16 20:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:06:13 --> Router Class Initialized
INFO - 2023-08-16 20:06:13 --> Router Class Initialized
INFO - 2023-08-16 20:06:13 --> Output Class Initialized
INFO - 2023-08-16 20:06:13 --> Input Class Initialized
INFO - 2023-08-16 20:06:13 --> Output Class Initialized
INFO - 2023-08-16 20:06:13 --> Language Class Initialized
INFO - 2023-08-16 20:06:13 --> Security Class Initialized
ERROR - 2023-08-16 20:06:13 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:06:13 --> Security Class Initialized
DEBUG - 2023-08-16 20:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 20:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:06:13 --> Input Class Initialized
INFO - 2023-08-16 20:06:13 --> Input Class Initialized
INFO - 2023-08-16 20:06:13 --> Language Class Initialized
INFO - 2023-08-16 20:06:13 --> Language Class Initialized
ERROR - 2023-08-16 20:06:13 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-16 20:06:13 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:07:01 --> Config Class Initialized
INFO - 2023-08-16 20:07:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:01 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:01 --> URI Class Initialized
INFO - 2023-08-16 20:07:01 --> Router Class Initialized
INFO - 2023-08-16 20:07:01 --> Output Class Initialized
INFO - 2023-08-16 20:07:01 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:01 --> Input Class Initialized
INFO - 2023-08-16 20:07:01 --> Language Class Initialized
INFO - 2023-08-16 20:07:01 --> Loader Class Initialized
INFO - 2023-08-16 20:07:01 --> Helper loaded: url_helper
INFO - 2023-08-16 20:07:01 --> Helper loaded: file_helper
INFO - 2023-08-16 20:07:01 --> Database Driver Class Initialized
INFO - 2023-08-16 20:07:01 --> Email Class Initialized
DEBUG - 2023-08-16 20:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:07:01 --> Controller Class Initialized
INFO - 2023-08-16 20:07:01 --> Model "Home_model" initialized
INFO - 2023-08-16 20:07:01 --> Helper loaded: form_helper
INFO - 2023-08-16 20:07:01 --> Form Validation Class Initialized
INFO - 2023-08-16 20:07:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:07:01 --> Final output sent to browser
DEBUG - 2023-08-16 20:07:02 --> Total execution time: 0.7241
INFO - 2023-08-16 20:07:03 --> Config Class Initialized
INFO - 2023-08-16 20:07:03 --> Config Class Initialized
INFO - 2023-08-16 20:07:03 --> Config Class Initialized
INFO - 2023-08-16 20:07:03 --> Hooks Class Initialized
INFO - 2023-08-16 20:07:03 --> Hooks Class Initialized
INFO - 2023-08-16 20:07:03 --> Config Class Initialized
DEBUG - 2023-08-16 20:07:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:03 --> Hooks Class Initialized
INFO - 2023-08-16 20:07:03 --> Config Class Initialized
DEBUG - 2023-08-16 20:07:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:03 --> Hooks Class Initialized
INFO - 2023-08-16 20:07:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:03 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:07:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:03 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:03 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:07:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:03 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:03 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:03 --> URI Class Initialized
INFO - 2023-08-16 20:07:03 --> URI Class Initialized
INFO - 2023-08-16 20:07:03 --> URI Class Initialized
INFO - 2023-08-16 20:07:03 --> Router Class Initialized
INFO - 2023-08-16 20:07:04 --> URI Class Initialized
INFO - 2023-08-16 20:07:04 --> Router Class Initialized
INFO - 2023-08-16 20:07:04 --> URI Class Initialized
INFO - 2023-08-16 20:07:04 --> Router Class Initialized
INFO - 2023-08-16 20:07:04 --> Output Class Initialized
INFO - 2023-08-16 20:07:04 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:04 --> Input Class Initialized
INFO - 2023-08-16 20:07:04 --> Language Class Initialized
ERROR - 2023-08-16 20:07:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:07:04 --> Router Class Initialized
INFO - 2023-08-16 20:07:04 --> Output Class Initialized
INFO - 2023-08-16 20:07:04 --> Output Class Initialized
INFO - 2023-08-16 20:07:04 --> Config Class Initialized
INFO - 2023-08-16 20:07:04 --> Security Class Initialized
INFO - 2023-08-16 20:07:04 --> Router Class Initialized
INFO - 2023-08-16 20:07:04 --> Output Class Initialized
INFO - 2023-08-16 20:07:04 --> Security Class Initialized
INFO - 2023-08-16 20:07:04 --> Hooks Class Initialized
INFO - 2023-08-16 20:07:04 --> Output Class Initialized
DEBUG - 2023-08-16 20:07:04 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:04 --> Security Class Initialized
INFO - 2023-08-16 20:07:04 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 20:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 20:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:04 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:04 --> Config Class Initialized
INFO - 2023-08-16 20:07:04 --> Input Class Initialized
DEBUG - 2023-08-16 20:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:04 --> URI Class Initialized
INFO - 2023-08-16 20:07:04 --> Input Class Initialized
INFO - 2023-08-16 20:07:04 --> Router Class Initialized
INFO - 2023-08-16 20:07:04 --> Language Class Initialized
INFO - 2023-08-16 20:07:04 --> Input Class Initialized
INFO - 2023-08-16 20:07:04 --> Hooks Class Initialized
INFO - 2023-08-16 20:07:04 --> Input Class Initialized
INFO - 2023-08-16 20:07:04 --> Output Class Initialized
INFO - 2023-08-16 20:07:04 --> Language Class Initialized
INFO - 2023-08-16 20:07:04 --> Security Class Initialized
INFO - 2023-08-16 20:07:04 --> Language Class Initialized
INFO - 2023-08-16 20:07:04 --> Language Class Initialized
ERROR - 2023-08-16 20:07:04 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 20:07:04 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 20:07:04 --> UTF-8 Support Enabled
ERROR - 2023-08-16 20:07:04 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 20:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:05 --> Input Class Initialized
ERROR - 2023-08-16 20:07:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:07:05 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:05 --> Language Class Initialized
INFO - 2023-08-16 20:07:05 --> URI Class Initialized
ERROR - 2023-08-16 20:07:05 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:07:05 --> Router Class Initialized
INFO - 2023-08-16 20:07:05 --> Output Class Initialized
INFO - 2023-08-16 20:07:05 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:05 --> Input Class Initialized
INFO - 2023-08-16 20:07:05 --> Language Class Initialized
ERROR - 2023-08-16 20:07:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:07:05 --> Config Class Initialized
INFO - 2023-08-16 20:07:05 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:05 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:05 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:05 --> URI Class Initialized
INFO - 2023-08-16 20:07:05 --> Router Class Initialized
INFO - 2023-08-16 20:07:05 --> Output Class Initialized
INFO - 2023-08-16 20:07:06 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:06 --> Input Class Initialized
INFO - 2023-08-16 20:07:06 --> Language Class Initialized
ERROR - 2023-08-16 20:07:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:07:06 --> Config Class Initialized
INFO - 2023-08-16 20:07:06 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:06 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:06 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:06 --> URI Class Initialized
INFO - 2023-08-16 20:07:06 --> Router Class Initialized
INFO - 2023-08-16 20:07:06 --> Output Class Initialized
INFO - 2023-08-16 20:07:06 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:06 --> Input Class Initialized
INFO - 2023-08-16 20:07:06 --> Language Class Initialized
ERROR - 2023-08-16 20:07:06 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:07:06 --> Config Class Initialized
INFO - 2023-08-16 20:07:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:07 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:07 --> URI Class Initialized
INFO - 2023-08-16 20:07:07 --> Router Class Initialized
INFO - 2023-08-16 20:07:07 --> Output Class Initialized
INFO - 2023-08-16 20:07:07 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:07 --> Input Class Initialized
INFO - 2023-08-16 20:07:07 --> Language Class Initialized
ERROR - 2023-08-16 20:07:07 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:07:07 --> Config Class Initialized
INFO - 2023-08-16 20:07:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:07 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:07 --> URI Class Initialized
INFO - 2023-08-16 20:07:07 --> Router Class Initialized
INFO - 2023-08-16 20:07:07 --> Output Class Initialized
INFO - 2023-08-16 20:07:07 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:07 --> Input Class Initialized
INFO - 2023-08-16 20:07:08 --> Language Class Initialized
ERROR - 2023-08-16 20:07:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:07:08 --> Config Class Initialized
INFO - 2023-08-16 20:07:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:08 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:08 --> URI Class Initialized
INFO - 2023-08-16 20:07:08 --> Router Class Initialized
INFO - 2023-08-16 20:07:08 --> Output Class Initialized
INFO - 2023-08-16 20:07:08 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:08 --> Input Class Initialized
INFO - 2023-08-16 20:07:08 --> Language Class Initialized
ERROR - 2023-08-16 20:07:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:07:09 --> Config Class Initialized
INFO - 2023-08-16 20:07:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:09 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:09 --> URI Class Initialized
INFO - 2023-08-16 20:07:09 --> Router Class Initialized
INFO - 2023-08-16 20:07:09 --> Output Class Initialized
INFO - 2023-08-16 20:07:09 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:09 --> Input Class Initialized
INFO - 2023-08-16 20:07:09 --> Language Class Initialized
ERROR - 2023-08-16 20:07:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:07:10 --> Config Class Initialized
INFO - 2023-08-16 20:07:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:10 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:10 --> URI Class Initialized
INFO - 2023-08-16 20:07:10 --> Router Class Initialized
INFO - 2023-08-16 20:07:10 --> Output Class Initialized
INFO - 2023-08-16 20:07:10 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:10 --> Input Class Initialized
INFO - 2023-08-16 20:07:10 --> Language Class Initialized
ERROR - 2023-08-16 20:07:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:07:10 --> Config Class Initialized
INFO - 2023-08-16 20:07:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:10 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:10 --> URI Class Initialized
INFO - 2023-08-16 20:07:10 --> Router Class Initialized
INFO - 2023-08-16 20:07:10 --> Output Class Initialized
INFO - 2023-08-16 20:07:10 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:11 --> Input Class Initialized
INFO - 2023-08-16 20:07:11 --> Language Class Initialized
ERROR - 2023-08-16 20:07:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:07:11 --> Config Class Initialized
INFO - 2023-08-16 20:07:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:11 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:11 --> URI Class Initialized
INFO - 2023-08-16 20:07:11 --> Router Class Initialized
INFO - 2023-08-16 20:07:11 --> Output Class Initialized
INFO - 2023-08-16 20:07:11 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:11 --> Input Class Initialized
INFO - 2023-08-16 20:07:11 --> Language Class Initialized
ERROR - 2023-08-16 20:07:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:07:16 --> Config Class Initialized
INFO - 2023-08-16 20:07:16 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:16 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:16 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:16 --> URI Class Initialized
INFO - 2023-08-16 20:07:16 --> Router Class Initialized
INFO - 2023-08-16 20:07:16 --> Output Class Initialized
INFO - 2023-08-16 20:07:16 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:16 --> Input Class Initialized
INFO - 2023-08-16 20:07:16 --> Language Class Initialized
INFO - 2023-08-16 20:07:16 --> Loader Class Initialized
INFO - 2023-08-16 20:07:16 --> Helper loaded: url_helper
INFO - 2023-08-16 20:07:16 --> Helper loaded: file_helper
INFO - 2023-08-16 20:07:16 --> Database Driver Class Initialized
INFO - 2023-08-16 20:07:16 --> Email Class Initialized
DEBUG - 2023-08-16 20:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:07:16 --> Controller Class Initialized
INFO - 2023-08-16 20:07:16 --> Model "Home_model" initialized
INFO - 2023-08-16 20:07:16 --> Helper loaded: form_helper
INFO - 2023-08-16 20:07:16 --> Form Validation Class Initialized
INFO - 2023-08-16 20:07:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:07:16 --> Final output sent to browser
DEBUG - 2023-08-16 20:07:16 --> Total execution time: 0.1893
INFO - 2023-08-16 20:07:17 --> Config Class Initialized
INFO - 2023-08-16 20:07:17 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:18 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:18 --> URI Class Initialized
INFO - 2023-08-16 20:07:18 --> Router Class Initialized
INFO - 2023-08-16 20:07:18 --> Output Class Initialized
INFO - 2023-08-16 20:07:18 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:18 --> Input Class Initialized
INFO - 2023-08-16 20:07:18 --> Language Class Initialized
ERROR - 2023-08-16 20:07:18 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:07:18 --> Config Class Initialized
INFO - 2023-08-16 20:07:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:18 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:18 --> URI Class Initialized
INFO - 2023-08-16 20:07:18 --> Router Class Initialized
INFO - 2023-08-16 20:07:18 --> Output Class Initialized
INFO - 2023-08-16 20:07:18 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:18 --> Input Class Initialized
INFO - 2023-08-16 20:07:18 --> Language Class Initialized
ERROR - 2023-08-16 20:07:18 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:07:18 --> Config Class Initialized
INFO - 2023-08-16 20:07:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:18 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:18 --> URI Class Initialized
INFO - 2023-08-16 20:07:18 --> Router Class Initialized
INFO - 2023-08-16 20:07:18 --> Output Class Initialized
INFO - 2023-08-16 20:07:18 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:18 --> Input Class Initialized
INFO - 2023-08-16 20:07:18 --> Language Class Initialized
ERROR - 2023-08-16 20:07:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:07:18 --> Config Class Initialized
INFO - 2023-08-16 20:07:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:18 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:18 --> URI Class Initialized
INFO - 2023-08-16 20:07:18 --> Router Class Initialized
INFO - 2023-08-16 20:07:18 --> Output Class Initialized
INFO - 2023-08-16 20:07:18 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:18 --> Input Class Initialized
INFO - 2023-08-16 20:07:18 --> Language Class Initialized
ERROR - 2023-08-16 20:07:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:07:18 --> Config Class Initialized
INFO - 2023-08-16 20:07:18 --> Config Class Initialized
INFO - 2023-08-16 20:07:18 --> Config Class Initialized
INFO - 2023-08-16 20:07:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:18 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:18 --> URI Class Initialized
INFO - 2023-08-16 20:07:18 --> Router Class Initialized
INFO - 2023-08-16 20:07:18 --> Output Class Initialized
INFO - 2023-08-16 20:07:18 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:18 --> Input Class Initialized
INFO - 2023-08-16 20:07:18 --> Language Class Initialized
ERROR - 2023-08-16 20:07:18 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:07:18 --> Config Class Initialized
INFO - 2023-08-16 20:07:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:18 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:18 --> URI Class Initialized
INFO - 2023-08-16 20:07:18 --> Router Class Initialized
INFO - 2023-08-16 20:07:18 --> Output Class Initialized
INFO - 2023-08-16 20:07:18 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:18 --> Input Class Initialized
INFO - 2023-08-16 20:07:18 --> Language Class Initialized
ERROR - 2023-08-16 20:07:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:07:18 --> Config Class Initialized
INFO - 2023-08-16 20:07:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:18 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:18 --> URI Class Initialized
INFO - 2023-08-16 20:07:18 --> Router Class Initialized
INFO - 2023-08-16 20:07:18 --> Output Class Initialized
INFO - 2023-08-16 20:07:18 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:18 --> Input Class Initialized
INFO - 2023-08-16 20:07:18 --> Language Class Initialized
ERROR - 2023-08-16 20:07:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:07:18 --> Config Class Initialized
INFO - 2023-08-16 20:07:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:18 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:18 --> URI Class Initialized
INFO - 2023-08-16 20:07:18 --> Router Class Initialized
INFO - 2023-08-16 20:07:18 --> Output Class Initialized
INFO - 2023-08-16 20:07:18 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:18 --> Input Class Initialized
INFO - 2023-08-16 20:07:18 --> Language Class Initialized
ERROR - 2023-08-16 20:07:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:07:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:07:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:18 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:18 --> URI Class Initialized
INFO - 2023-08-16 20:07:18 --> Router Class Initialized
INFO - 2023-08-16 20:07:18 --> Output Class Initialized
INFO - 2023-08-16 20:07:18 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:18 --> Input Class Initialized
INFO - 2023-08-16 20:07:18 --> Language Class Initialized
ERROR - 2023-08-16 20:07:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:07:18 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:19 --> URI Class Initialized
INFO - 2023-08-16 20:07:19 --> Router Class Initialized
INFO - 2023-08-16 20:07:19 --> Output Class Initialized
INFO - 2023-08-16 20:07:19 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:20 --> Input Class Initialized
INFO - 2023-08-16 20:07:20 --> Language Class Initialized
ERROR - 2023-08-16 20:07:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:07:20 --> Config Class Initialized
INFO - 2023-08-16 20:07:20 --> Hooks Class Initialized
INFO - 2023-08-16 20:07:20 --> Config Class Initialized
DEBUG - 2023-08-16 20:07:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:20 --> Config Class Initialized
INFO - 2023-08-16 20:07:20 --> Hooks Class Initialized
INFO - 2023-08-16 20:07:20 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:20 --> Hooks Class Initialized
INFO - 2023-08-16 20:07:20 --> URI Class Initialized
DEBUG - 2023-08-16 20:07:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:07:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:07:20 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:20 --> Router Class Initialized
INFO - 2023-08-16 20:07:20 --> URI Class Initialized
INFO - 2023-08-16 20:07:20 --> Output Class Initialized
INFO - 2023-08-16 20:07:20 --> Utf8 Class Initialized
INFO - 2023-08-16 20:07:20 --> URI Class Initialized
INFO - 2023-08-16 20:07:20 --> Router Class Initialized
INFO - 2023-08-16 20:07:20 --> Security Class Initialized
INFO - 2023-08-16 20:07:20 --> Output Class Initialized
INFO - 2023-08-16 20:07:20 --> Security Class Initialized
DEBUG - 2023-08-16 20:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:20 --> Input Class Initialized
INFO - 2023-08-16 20:07:20 --> Router Class Initialized
INFO - 2023-08-16 20:07:20 --> Language Class Initialized
ERROR - 2023-08-16 20:07:20 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 20:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:20 --> Output Class Initialized
INFO - 2023-08-16 20:07:20 --> Input Class Initialized
INFO - 2023-08-16 20:07:20 --> Language Class Initialized
INFO - 2023-08-16 20:07:20 --> Security Class Initialized
ERROR - 2023-08-16 20:07:20 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 20:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:07:21 --> Input Class Initialized
INFO - 2023-08-16 20:07:21 --> Language Class Initialized
ERROR - 2023-08-16 20:07:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:10:10 --> Config Class Initialized
INFO - 2023-08-16 20:10:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:10:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:10:10 --> Utf8 Class Initialized
INFO - 2023-08-16 20:10:10 --> URI Class Initialized
INFO - 2023-08-16 20:10:10 --> Router Class Initialized
INFO - 2023-08-16 20:10:10 --> Output Class Initialized
INFO - 2023-08-16 20:10:10 --> Security Class Initialized
DEBUG - 2023-08-16 20:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:10 --> Input Class Initialized
INFO - 2023-08-16 20:10:10 --> Language Class Initialized
INFO - 2023-08-16 20:10:10 --> Loader Class Initialized
INFO - 2023-08-16 20:10:10 --> Helper loaded: url_helper
INFO - 2023-08-16 20:10:10 --> Helper loaded: file_helper
INFO - 2023-08-16 20:10:10 --> Database Driver Class Initialized
INFO - 2023-08-16 20:10:10 --> Email Class Initialized
DEBUG - 2023-08-16 20:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:10:10 --> Controller Class Initialized
INFO - 2023-08-16 20:10:10 --> Model "Home_model" initialized
INFO - 2023-08-16 20:10:11 --> Helper loaded: form_helper
INFO - 2023-08-16 20:10:11 --> Form Validation Class Initialized
INFO - 2023-08-16 20:10:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:10:11 --> Final output sent to browser
DEBUG - 2023-08-16 20:10:11 --> Total execution time: 0.9627
INFO - 2023-08-16 20:10:12 --> Config Class Initialized
INFO - 2023-08-16 20:10:13 --> Config Class Initialized
INFO - 2023-08-16 20:10:13 --> Hooks Class Initialized
INFO - 2023-08-16 20:10:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:10:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:10:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:10:14 --> Utf8 Class Initialized
INFO - 2023-08-16 20:10:14 --> Utf8 Class Initialized
INFO - 2023-08-16 20:10:14 --> URI Class Initialized
INFO - 2023-08-16 20:10:14 --> URI Class Initialized
INFO - 2023-08-16 20:10:14 --> Router Class Initialized
INFO - 2023-08-16 20:10:14 --> Router Class Initialized
INFO - 2023-08-16 20:10:14 --> Output Class Initialized
INFO - 2023-08-16 20:10:14 --> Security Class Initialized
INFO - 2023-08-16 20:10:14 --> Output Class Initialized
DEBUG - 2023-08-16 20:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:14 --> Security Class Initialized
INFO - 2023-08-16 20:10:14 --> Input Class Initialized
DEBUG - 2023-08-16 20:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:14 --> Language Class Initialized
INFO - 2023-08-16 20:10:14 --> Input Class Initialized
INFO - 2023-08-16 20:10:14 --> Language Class Initialized
ERROR - 2023-08-16 20:10:14 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-16 20:10:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:10:14 --> Config Class Initialized
INFO - 2023-08-16 20:10:14 --> Hooks Class Initialized
INFO - 2023-08-16 20:10:14 --> Config Class Initialized
INFO - 2023-08-16 20:10:14 --> Config Class Initialized
INFO - 2023-08-16 20:10:15 --> Hooks Class Initialized
INFO - 2023-08-16 20:10:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:10:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:10:15 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:10:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:10:15 --> Utf8 Class Initialized
INFO - 2023-08-16 20:10:15 --> Config Class Initialized
INFO - 2023-08-16 20:10:15 --> Utf8 Class Initialized
INFO - 2023-08-16 20:10:15 --> URI Class Initialized
INFO - 2023-08-16 20:10:15 --> URI Class Initialized
INFO - 2023-08-16 20:10:15 --> Router Class Initialized
INFO - 2023-08-16 20:10:15 --> Config Class Initialized
INFO - 2023-08-16 20:10:15 --> URI Class Initialized
INFO - 2023-08-16 20:10:15 --> Hooks Class Initialized
INFO - 2023-08-16 20:10:15 --> Output Class Initialized
INFO - 2023-08-16 20:10:15 --> Router Class Initialized
INFO - 2023-08-16 20:10:15 --> Hooks Class Initialized
INFO - 2023-08-16 20:10:15 --> Security Class Initialized
DEBUG - 2023-08-16 20:10:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:10:15 --> Utf8 Class Initialized
INFO - 2023-08-16 20:10:15 --> URI Class Initialized
INFO - 2023-08-16 20:10:15 --> Router Class Initialized
INFO - 2023-08-16 20:10:15 --> Output Class Initialized
INFO - 2023-08-16 20:10:15 --> Security Class Initialized
DEBUG - 2023-08-16 20:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:15 --> Input Class Initialized
INFO - 2023-08-16 20:10:15 --> Language Class Initialized
ERROR - 2023-08-16 20:10:15 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 20:10:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:10:15 --> Router Class Initialized
INFO - 2023-08-16 20:10:15 --> Utf8 Class Initialized
INFO - 2023-08-16 20:10:15 --> Output Class Initialized
INFO - 2023-08-16 20:10:15 --> Output Class Initialized
DEBUG - 2023-08-16 20:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:15 --> Security Class Initialized
INFO - 2023-08-16 20:10:15 --> Security Class Initialized
DEBUG - 2023-08-16 20:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:15 --> Input Class Initialized
INFO - 2023-08-16 20:10:15 --> Input Class Initialized
INFO - 2023-08-16 20:10:15 --> Language Class Initialized
DEBUG - 2023-08-16 20:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:15 --> URI Class Initialized
INFO - 2023-08-16 20:10:15 --> Language Class Initialized
ERROR - 2023-08-16 20:10:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:10:15 --> Input Class Initialized
INFO - 2023-08-16 20:10:15 --> Language Class Initialized
ERROR - 2023-08-16 20:10:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:10:15 --> Router Class Initialized
INFO - 2023-08-16 20:10:15 --> Output Class Initialized
ERROR - 2023-08-16 20:10:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:10:15 --> Security Class Initialized
DEBUG - 2023-08-16 20:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:15 --> Input Class Initialized
INFO - 2023-08-16 20:10:15 --> Language Class Initialized
ERROR - 2023-08-16 20:10:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:10:52 --> Config Class Initialized
INFO - 2023-08-16 20:10:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:10:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:10:52 --> Utf8 Class Initialized
INFO - 2023-08-16 20:10:52 --> URI Class Initialized
INFO - 2023-08-16 20:10:52 --> Router Class Initialized
INFO - 2023-08-16 20:10:52 --> Output Class Initialized
INFO - 2023-08-16 20:10:52 --> Security Class Initialized
DEBUG - 2023-08-16 20:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:52 --> Input Class Initialized
INFO - 2023-08-16 20:10:52 --> Language Class Initialized
INFO - 2023-08-16 20:10:53 --> Loader Class Initialized
INFO - 2023-08-16 20:10:53 --> Helper loaded: url_helper
INFO - 2023-08-16 20:10:53 --> Helper loaded: file_helper
INFO - 2023-08-16 20:10:53 --> Database Driver Class Initialized
INFO - 2023-08-16 20:10:53 --> Email Class Initialized
DEBUG - 2023-08-16 20:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:10:53 --> Controller Class Initialized
INFO - 2023-08-16 20:10:53 --> Model "Home_model" initialized
INFO - 2023-08-16 20:10:53 --> Helper loaded: form_helper
INFO - 2023-08-16 20:10:53 --> Form Validation Class Initialized
INFO - 2023-08-16 20:10:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:10:53 --> Final output sent to browser
DEBUG - 2023-08-16 20:10:53 --> Total execution time: 0.4803
INFO - 2023-08-16 20:10:53 --> Config Class Initialized
INFO - 2023-08-16 20:10:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:10:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:10:53 --> Config Class Initialized
INFO - 2023-08-16 20:10:53 --> Hooks Class Initialized
INFO - 2023-08-16 20:10:54 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:10:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:10:54 --> URI Class Initialized
INFO - 2023-08-16 20:10:54 --> Router Class Initialized
INFO - 2023-08-16 20:10:54 --> Utf8 Class Initialized
INFO - 2023-08-16 20:10:54 --> Output Class Initialized
INFO - 2023-08-16 20:10:54 --> URI Class Initialized
INFO - 2023-08-16 20:10:54 --> Security Class Initialized
INFO - 2023-08-16 20:10:54 --> Router Class Initialized
DEBUG - 2023-08-16 20:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:54 --> Output Class Initialized
INFO - 2023-08-16 20:10:54 --> Security Class Initialized
INFO - 2023-08-16 20:10:54 --> Input Class Initialized
DEBUG - 2023-08-16 20:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:54 --> Input Class Initialized
INFO - 2023-08-16 20:10:54 --> Config Class Initialized
INFO - 2023-08-16 20:10:54 --> Language Class Initialized
ERROR - 2023-08-16 20:10:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:10:54 --> Language Class Initialized
INFO - 2023-08-16 20:10:54 --> Config Class Initialized
INFO - 2023-08-16 20:10:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:10:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:10:54 --> Utf8 Class Initialized
INFO - 2023-08-16 20:10:54 --> URI Class Initialized
INFO - 2023-08-16 20:10:54 --> Router Class Initialized
INFO - 2023-08-16 20:10:54 --> Output Class Initialized
INFO - 2023-08-16 20:10:54 --> Security Class Initialized
DEBUG - 2023-08-16 20:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:54 --> Input Class Initialized
INFO - 2023-08-16 20:10:54 --> Language Class Initialized
ERROR - 2023-08-16 20:10:54 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 20:10:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:10:54 --> Config Class Initialized
INFO - 2023-08-16 20:10:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:10:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:10:54 --> Config Class Initialized
INFO - 2023-08-16 20:10:54 --> Utf8 Class Initialized
INFO - 2023-08-16 20:10:54 --> URI Class Initialized
INFO - 2023-08-16 20:10:54 --> Hooks Class Initialized
INFO - 2023-08-16 20:10:54 --> Hooks Class Initialized
INFO - 2023-08-16 20:10:54 --> Router Class Initialized
DEBUG - 2023-08-16 20:10:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:10:54 --> Output Class Initialized
DEBUG - 2023-08-16 20:10:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:10:54 --> Utf8 Class Initialized
INFO - 2023-08-16 20:10:54 --> Utf8 Class Initialized
INFO - 2023-08-16 20:10:54 --> Security Class Initialized
INFO - 2023-08-16 20:10:54 --> URI Class Initialized
DEBUG - 2023-08-16 20:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:54 --> URI Class Initialized
INFO - 2023-08-16 20:10:54 --> Input Class Initialized
INFO - 2023-08-16 20:10:55 --> Language Class Initialized
INFO - 2023-08-16 20:10:55 --> Router Class Initialized
INFO - 2023-08-16 20:10:55 --> Router Class Initialized
INFO - 2023-08-16 20:10:55 --> Output Class Initialized
ERROR - 2023-08-16 20:10:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:10:55 --> Security Class Initialized
INFO - 2023-08-16 20:10:55 --> Output Class Initialized
DEBUG - 2023-08-16 20:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:55 --> Security Class Initialized
INFO - 2023-08-16 20:10:55 --> Input Class Initialized
DEBUG - 2023-08-16 20:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:10:55 --> Language Class Initialized
ERROR - 2023-08-16 20:10:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:10:55 --> Input Class Initialized
INFO - 2023-08-16 20:10:55 --> Language Class Initialized
ERROR - 2023-08-16 20:10:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:11:08 --> Config Class Initialized
INFO - 2023-08-16 20:11:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:08 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:08 --> URI Class Initialized
INFO - 2023-08-16 20:11:08 --> Router Class Initialized
INFO - 2023-08-16 20:11:08 --> Output Class Initialized
INFO - 2023-08-16 20:11:08 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:08 --> Input Class Initialized
INFO - 2023-08-16 20:11:08 --> Language Class Initialized
INFO - 2023-08-16 20:11:08 --> Loader Class Initialized
INFO - 2023-08-16 20:11:08 --> Helper loaded: url_helper
INFO - 2023-08-16 20:11:08 --> Helper loaded: file_helper
INFO - 2023-08-16 20:11:08 --> Database Driver Class Initialized
INFO - 2023-08-16 20:11:08 --> Email Class Initialized
DEBUG - 2023-08-16 20:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:11:08 --> Controller Class Initialized
INFO - 2023-08-16 20:11:08 --> Model "Home_model" initialized
INFO - 2023-08-16 20:11:08 --> Helper loaded: form_helper
INFO - 2023-08-16 20:11:08 --> Form Validation Class Initialized
INFO - 2023-08-16 20:11:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:11:08 --> Final output sent to browser
DEBUG - 2023-08-16 20:11:08 --> Total execution time: 0.4978
INFO - 2023-08-16 20:11:08 --> Config Class Initialized
INFO - 2023-08-16 20:11:09 --> Hooks Class Initialized
INFO - 2023-08-16 20:11:09 --> Config Class Initialized
DEBUG - 2023-08-16 20:11:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:09 --> Hooks Class Initialized
INFO - 2023-08-16 20:11:09 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:11:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:09 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:09 --> URI Class Initialized
INFO - 2023-08-16 20:11:09 --> URI Class Initialized
INFO - 2023-08-16 20:11:09 --> Router Class Initialized
INFO - 2023-08-16 20:11:09 --> Router Class Initialized
INFO - 2023-08-16 20:11:09 --> Output Class Initialized
INFO - 2023-08-16 20:11:09 --> Output Class Initialized
INFO - 2023-08-16 20:11:09 --> Security Class Initialized
INFO - 2023-08-16 20:11:09 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 20:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:09 --> Input Class Initialized
INFO - 2023-08-16 20:11:09 --> Input Class Initialized
INFO - 2023-08-16 20:11:09 --> Language Class Initialized
INFO - 2023-08-16 20:11:09 --> Language Class Initialized
ERROR - 2023-08-16 20:11:09 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 20:11:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:11:09 --> Config Class Initialized
INFO - 2023-08-16 20:11:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:09 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:09 --> URI Class Initialized
INFO - 2023-08-16 20:11:09 --> Router Class Initialized
INFO - 2023-08-16 20:11:09 --> Output Class Initialized
INFO - 2023-08-16 20:11:09 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:09 --> Input Class Initialized
INFO - 2023-08-16 20:11:09 --> Language Class Initialized
ERROR - 2023-08-16 20:11:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:11:09 --> Config Class Initialized
INFO - 2023-08-16 20:11:09 --> Hooks Class Initialized
INFO - 2023-08-16 20:11:09 --> Config Class Initialized
INFO - 2023-08-16 20:11:09 --> Hooks Class Initialized
INFO - 2023-08-16 20:11:09 --> Config Class Initialized
INFO - 2023-08-16 20:11:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:11:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:10 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:11:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:10 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:10 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:10 --> URI Class Initialized
INFO - 2023-08-16 20:11:10 --> URI Class Initialized
INFO - 2023-08-16 20:11:10 --> Router Class Initialized
INFO - 2023-08-16 20:11:10 --> Output Class Initialized
INFO - 2023-08-16 20:11:10 --> Router Class Initialized
INFO - 2023-08-16 20:11:10 --> Security Class Initialized
INFO - 2023-08-16 20:11:10 --> URI Class Initialized
DEBUG - 2023-08-16 20:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:10 --> Router Class Initialized
INFO - 2023-08-16 20:11:10 --> Output Class Initialized
INFO - 2023-08-16 20:11:10 --> Security Class Initialized
INFO - 2023-08-16 20:11:10 --> Input Class Initialized
DEBUG - 2023-08-16 20:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:10 --> Input Class Initialized
INFO - 2023-08-16 20:11:10 --> Language Class Initialized
INFO - 2023-08-16 20:11:10 --> Output Class Initialized
ERROR - 2023-08-16 20:11:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:11:10 --> Language Class Initialized
INFO - 2023-08-16 20:11:10 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 20:11:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:11:10 --> Input Class Initialized
INFO - 2023-08-16 20:11:10 --> Language Class Initialized
ERROR - 2023-08-16 20:11:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:11:17 --> Config Class Initialized
INFO - 2023-08-16 20:11:17 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:17 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:17 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:17 --> URI Class Initialized
INFO - 2023-08-16 20:11:17 --> Router Class Initialized
INFO - 2023-08-16 20:11:17 --> Output Class Initialized
INFO - 2023-08-16 20:11:17 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:17 --> Input Class Initialized
INFO - 2023-08-16 20:11:17 --> Language Class Initialized
ERROR - 2023-08-16 20:11:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:11:17 --> Config Class Initialized
INFO - 2023-08-16 20:11:17 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:17 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:17 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:17 --> URI Class Initialized
INFO - 2023-08-16 20:11:17 --> Router Class Initialized
INFO - 2023-08-16 20:11:17 --> Output Class Initialized
INFO - 2023-08-16 20:11:17 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:17 --> Input Class Initialized
INFO - 2023-08-16 20:11:17 --> Language Class Initialized
ERROR - 2023-08-16 20:11:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:11:18 --> Config Class Initialized
INFO - 2023-08-16 20:11:18 --> Config Class Initialized
INFO - 2023-08-16 20:11:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:18 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:18 --> URI Class Initialized
INFO - 2023-08-16 20:11:18 --> Router Class Initialized
INFO - 2023-08-16 20:11:18 --> Output Class Initialized
INFO - 2023-08-16 20:11:18 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:18 --> Input Class Initialized
INFO - 2023-08-16 20:11:18 --> Language Class Initialized
ERROR - 2023-08-16 20:11:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:11:18 --> Hooks Class Initialized
INFO - 2023-08-16 20:11:18 --> Config Class Initialized
INFO - 2023-08-16 20:11:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:18 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:18 --> URI Class Initialized
INFO - 2023-08-16 20:11:18 --> Router Class Initialized
INFO - 2023-08-16 20:11:18 --> Output Class Initialized
INFO - 2023-08-16 20:11:18 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:18 --> Input Class Initialized
INFO - 2023-08-16 20:11:18 --> Language Class Initialized
ERROR - 2023-08-16 20:11:18 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 20:11:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:18 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:18 --> URI Class Initialized
INFO - 2023-08-16 20:11:18 --> Router Class Initialized
INFO - 2023-08-16 20:11:18 --> Output Class Initialized
INFO - 2023-08-16 20:11:18 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:18 --> Input Class Initialized
INFO - 2023-08-16 20:11:18 --> Language Class Initialized
ERROR - 2023-08-16 20:11:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:11:18 --> Config Class Initialized
INFO - 2023-08-16 20:11:18 --> Config Class Initialized
INFO - 2023-08-16 20:11:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:18 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:18 --> URI Class Initialized
INFO - 2023-08-16 20:11:18 --> Router Class Initialized
INFO - 2023-08-16 20:11:18 --> Output Class Initialized
INFO - 2023-08-16 20:11:18 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:18 --> Input Class Initialized
INFO - 2023-08-16 20:11:18 --> Language Class Initialized
ERROR - 2023-08-16 20:11:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:11:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:19 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:19 --> URI Class Initialized
INFO - 2023-08-16 20:11:19 --> Router Class Initialized
INFO - 2023-08-16 20:11:19 --> Output Class Initialized
INFO - 2023-08-16 20:11:19 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:19 --> Input Class Initialized
INFO - 2023-08-16 20:11:19 --> Language Class Initialized
ERROR - 2023-08-16 20:11:19 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:11:56 --> Config Class Initialized
INFO - 2023-08-16 20:11:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:56 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:56 --> URI Class Initialized
INFO - 2023-08-16 20:11:56 --> Router Class Initialized
INFO - 2023-08-16 20:11:56 --> Output Class Initialized
INFO - 2023-08-16 20:11:56 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:56 --> Input Class Initialized
INFO - 2023-08-16 20:11:56 --> Language Class Initialized
INFO - 2023-08-16 20:11:56 --> Loader Class Initialized
INFO - 2023-08-16 20:11:56 --> Helper loaded: url_helper
INFO - 2023-08-16 20:11:56 --> Helper loaded: file_helper
INFO - 2023-08-16 20:11:56 --> Database Driver Class Initialized
INFO - 2023-08-16 20:11:57 --> Email Class Initialized
DEBUG - 2023-08-16 20:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:11:57 --> Controller Class Initialized
INFO - 2023-08-16 20:11:57 --> Model "Home_model" initialized
INFO - 2023-08-16 20:11:57 --> Helper loaded: form_helper
INFO - 2023-08-16 20:11:57 --> Form Validation Class Initialized
INFO - 2023-08-16 20:11:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:11:57 --> Final output sent to browser
DEBUG - 2023-08-16 20:11:57 --> Total execution time: 1.1383
INFO - 2023-08-16 20:11:58 --> Config Class Initialized
INFO - 2023-08-16 20:11:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:58 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:58 --> URI Class Initialized
INFO - 2023-08-16 20:11:58 --> Router Class Initialized
INFO - 2023-08-16 20:11:58 --> Output Class Initialized
INFO - 2023-08-16 20:11:58 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:58 --> Input Class Initialized
INFO - 2023-08-16 20:11:58 --> Language Class Initialized
ERROR - 2023-08-16 20:11:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:11:58 --> Config Class Initialized
INFO - 2023-08-16 20:11:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:58 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:58 --> URI Class Initialized
INFO - 2023-08-16 20:11:58 --> Router Class Initialized
INFO - 2023-08-16 20:11:58 --> Output Class Initialized
INFO - 2023-08-16 20:11:58 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:58 --> Input Class Initialized
INFO - 2023-08-16 20:11:58 --> Language Class Initialized
ERROR - 2023-08-16 20:11:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:11:58 --> Config Class Initialized
INFO - 2023-08-16 20:11:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:58 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:58 --> URI Class Initialized
INFO - 2023-08-16 20:11:58 --> Router Class Initialized
INFO - 2023-08-16 20:11:58 --> Output Class Initialized
INFO - 2023-08-16 20:11:58 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:58 --> Input Class Initialized
INFO - 2023-08-16 20:11:59 --> Language Class Initialized
ERROR - 2023-08-16 20:11:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:11:59 --> Config Class Initialized
INFO - 2023-08-16 20:11:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:59 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:59 --> URI Class Initialized
INFO - 2023-08-16 20:11:59 --> Router Class Initialized
INFO - 2023-08-16 20:11:59 --> Output Class Initialized
INFO - 2023-08-16 20:11:59 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:59 --> Input Class Initialized
INFO - 2023-08-16 20:11:59 --> Language Class Initialized
ERROR - 2023-08-16 20:11:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:11:59 --> Config Class Initialized
INFO - 2023-08-16 20:11:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:11:59 --> Utf8 Class Initialized
INFO - 2023-08-16 20:11:59 --> URI Class Initialized
INFO - 2023-08-16 20:11:59 --> Router Class Initialized
INFO - 2023-08-16 20:11:59 --> Output Class Initialized
INFO - 2023-08-16 20:11:59 --> Security Class Initialized
DEBUG - 2023-08-16 20:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:11:59 --> Input Class Initialized
INFO - 2023-08-16 20:11:59 --> Language Class Initialized
ERROR - 2023-08-16 20:11:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:11:59 --> Config Class Initialized
INFO - 2023-08-16 20:11:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:11:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:12:36 --> Config Class Initialized
INFO - 2023-08-16 20:12:36 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:12:36 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:12:36 --> Utf8 Class Initialized
INFO - 2023-08-16 20:12:36 --> URI Class Initialized
INFO - 2023-08-16 20:12:36 --> Router Class Initialized
INFO - 2023-08-16 20:12:36 --> Output Class Initialized
INFO - 2023-08-16 20:12:36 --> Security Class Initialized
DEBUG - 2023-08-16 20:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:12:36 --> Input Class Initialized
INFO - 2023-08-16 20:12:36 --> Language Class Initialized
INFO - 2023-08-16 20:12:36 --> Loader Class Initialized
INFO - 2023-08-16 20:12:36 --> Helper loaded: url_helper
INFO - 2023-08-16 20:12:36 --> Helper loaded: file_helper
INFO - 2023-08-16 20:12:36 --> Database Driver Class Initialized
INFO - 2023-08-16 20:12:36 --> Email Class Initialized
DEBUG - 2023-08-16 20:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:12:36 --> Controller Class Initialized
INFO - 2023-08-16 20:12:36 --> Model "Home_model" initialized
INFO - 2023-08-16 20:12:36 --> Helper loaded: form_helper
INFO - 2023-08-16 20:12:36 --> Form Validation Class Initialized
INFO - 2023-08-16 20:12:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:12:37 --> Final output sent to browser
DEBUG - 2023-08-16 20:12:37 --> Total execution time: 0.8870
INFO - 2023-08-16 20:12:37 --> Config Class Initialized
INFO - 2023-08-16 20:12:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:12:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:12:37 --> Utf8 Class Initialized
INFO - 2023-08-16 20:12:37 --> URI Class Initialized
INFO - 2023-08-16 20:12:37 --> Router Class Initialized
INFO - 2023-08-16 20:12:37 --> Output Class Initialized
INFO - 2023-08-16 20:12:37 --> Security Class Initialized
DEBUG - 2023-08-16 20:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:12:38 --> Input Class Initialized
INFO - 2023-08-16 20:12:38 --> Language Class Initialized
ERROR - 2023-08-16 20:12:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:12:38 --> Config Class Initialized
INFO - 2023-08-16 20:12:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:12:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:12:38 --> Utf8 Class Initialized
INFO - 2023-08-16 20:12:38 --> URI Class Initialized
INFO - 2023-08-16 20:12:38 --> Router Class Initialized
INFO - 2023-08-16 20:12:38 --> Output Class Initialized
INFO - 2023-08-16 20:12:38 --> Security Class Initialized
DEBUG - 2023-08-16 20:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:12:38 --> Input Class Initialized
INFO - 2023-08-16 20:12:38 --> Language Class Initialized
ERROR - 2023-08-16 20:12:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:12:38 --> Config Class Initialized
INFO - 2023-08-16 20:12:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:12:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:12:38 --> Utf8 Class Initialized
INFO - 2023-08-16 20:12:38 --> URI Class Initialized
INFO - 2023-08-16 20:12:38 --> Router Class Initialized
INFO - 2023-08-16 20:12:38 --> Output Class Initialized
INFO - 2023-08-16 20:12:38 --> Security Class Initialized
DEBUG - 2023-08-16 20:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:12:38 --> Input Class Initialized
INFO - 2023-08-16 20:12:39 --> Language Class Initialized
ERROR - 2023-08-16 20:12:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:12:39 --> Config Class Initialized
INFO - 2023-08-16 20:12:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:12:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:12:39 --> Utf8 Class Initialized
INFO - 2023-08-16 20:12:39 --> URI Class Initialized
INFO - 2023-08-16 20:12:39 --> Router Class Initialized
INFO - 2023-08-16 20:12:39 --> Output Class Initialized
INFO - 2023-08-16 20:12:39 --> Security Class Initialized
DEBUG - 2023-08-16 20:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:12:39 --> Input Class Initialized
INFO - 2023-08-16 20:12:39 --> Language Class Initialized
ERROR - 2023-08-16 20:12:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:12:39 --> Config Class Initialized
INFO - 2023-08-16 20:12:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:12:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:12:39 --> Utf8 Class Initialized
INFO - 2023-08-16 20:12:39 --> URI Class Initialized
INFO - 2023-08-16 20:12:39 --> Router Class Initialized
INFO - 2023-08-16 20:12:39 --> Output Class Initialized
INFO - 2023-08-16 20:12:39 --> Security Class Initialized
DEBUG - 2023-08-16 20:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:12:39 --> Input Class Initialized
INFO - 2023-08-16 20:12:39 --> Language Class Initialized
ERROR - 2023-08-16 20:12:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:12:39 --> Config Class Initialized
INFO - 2023-08-16 20:12:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:12:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:12:39 --> Utf8 Class Initialized
INFO - 2023-08-16 20:12:39 --> URI Class Initialized
INFO - 2023-08-16 20:12:39 --> Router Class Initialized
INFO - 2023-08-16 20:12:39 --> Output Class Initialized
INFO - 2023-08-16 20:12:39 --> Security Class Initialized
DEBUG - 2023-08-16 20:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:12:39 --> Input Class Initialized
INFO - 2023-08-16 20:12:39 --> Language Class Initialized
ERROR - 2023-08-16 20:12:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:13:01 --> Config Class Initialized
INFO - 2023-08-16 20:13:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:02 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:02 --> URI Class Initialized
INFO - 2023-08-16 20:13:02 --> Router Class Initialized
INFO - 2023-08-16 20:13:02 --> Output Class Initialized
INFO - 2023-08-16 20:13:02 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:02 --> Input Class Initialized
INFO - 2023-08-16 20:13:02 --> Language Class Initialized
ERROR - 2023-08-16 20:13:02 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:13:03 --> Config Class Initialized
INFO - 2023-08-16 20:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:03 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:03 --> URI Class Initialized
INFO - 2023-08-16 20:13:03 --> Router Class Initialized
INFO - 2023-08-16 20:13:03 --> Output Class Initialized
INFO - 2023-08-16 20:13:03 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:03 --> Input Class Initialized
INFO - 2023-08-16 20:13:03 --> Language Class Initialized
ERROR - 2023-08-16 20:13:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:13:03 --> Config Class Initialized
INFO - 2023-08-16 20:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:03 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:03 --> URI Class Initialized
INFO - 2023-08-16 20:13:03 --> Router Class Initialized
INFO - 2023-08-16 20:13:03 --> Output Class Initialized
INFO - 2023-08-16 20:13:03 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:03 --> Input Class Initialized
INFO - 2023-08-16 20:13:03 --> Language Class Initialized
ERROR - 2023-08-16 20:13:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:13:03 --> Config Class Initialized
INFO - 2023-08-16 20:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:03 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:03 --> URI Class Initialized
INFO - 2023-08-16 20:13:03 --> Router Class Initialized
INFO - 2023-08-16 20:13:03 --> Output Class Initialized
INFO - 2023-08-16 20:13:03 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:03 --> Input Class Initialized
INFO - 2023-08-16 20:13:03 --> Language Class Initialized
ERROR - 2023-08-16 20:13:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:13:03 --> Config Class Initialized
INFO - 2023-08-16 20:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:03 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:03 --> URI Class Initialized
INFO - 2023-08-16 20:13:03 --> Router Class Initialized
INFO - 2023-08-16 20:13:03 --> Output Class Initialized
INFO - 2023-08-16 20:13:03 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:03 --> Input Class Initialized
INFO - 2023-08-16 20:13:03 --> Language Class Initialized
ERROR - 2023-08-16 20:13:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:13:03 --> Config Class Initialized
INFO - 2023-08-16 20:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:03 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:03 --> URI Class Initialized
INFO - 2023-08-16 20:13:03 --> Router Class Initialized
INFO - 2023-08-16 20:13:03 --> Output Class Initialized
INFO - 2023-08-16 20:13:03 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:03 --> Input Class Initialized
INFO - 2023-08-16 20:13:03 --> Language Class Initialized
ERROR - 2023-08-16 20:13:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:13:03 --> Config Class Initialized
INFO - 2023-08-16 20:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:04 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:04 --> URI Class Initialized
INFO - 2023-08-16 20:13:04 --> Router Class Initialized
INFO - 2023-08-16 20:13:04 --> Output Class Initialized
INFO - 2023-08-16 20:13:04 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:04 --> Input Class Initialized
INFO - 2023-08-16 20:13:04 --> Language Class Initialized
ERROR - 2023-08-16 20:13:04 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:13:47 --> Config Class Initialized
INFO - 2023-08-16 20:13:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:47 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:47 --> URI Class Initialized
INFO - 2023-08-16 20:13:47 --> Router Class Initialized
INFO - 2023-08-16 20:13:47 --> Output Class Initialized
INFO - 2023-08-16 20:13:47 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:47 --> Input Class Initialized
INFO - 2023-08-16 20:13:47 --> Language Class Initialized
INFO - 2023-08-16 20:13:47 --> Loader Class Initialized
INFO - 2023-08-16 20:13:47 --> Helper loaded: url_helper
INFO - 2023-08-16 20:13:47 --> Helper loaded: file_helper
INFO - 2023-08-16 20:13:47 --> Database Driver Class Initialized
INFO - 2023-08-16 20:13:47 --> Email Class Initialized
DEBUG - 2023-08-16 20:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:13:47 --> Controller Class Initialized
INFO - 2023-08-16 20:13:47 --> Model "Home_model" initialized
INFO - 2023-08-16 20:13:47 --> Helper loaded: form_helper
INFO - 2023-08-16 20:13:47 --> Form Validation Class Initialized
INFO - 2023-08-16 20:13:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:13:47 --> Final output sent to browser
DEBUG - 2023-08-16 20:13:47 --> Total execution time: 0.1949
INFO - 2023-08-16 20:13:48 --> Config Class Initialized
INFO - 2023-08-16 20:13:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:48 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:48 --> URI Class Initialized
INFO - 2023-08-16 20:13:48 --> Router Class Initialized
INFO - 2023-08-16 20:13:48 --> Output Class Initialized
INFO - 2023-08-16 20:13:48 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:48 --> Input Class Initialized
INFO - 2023-08-16 20:13:48 --> Language Class Initialized
ERROR - 2023-08-16 20:13:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:13:48 --> Config Class Initialized
INFO - 2023-08-16 20:13:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:48 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:48 --> URI Class Initialized
INFO - 2023-08-16 20:13:48 --> Router Class Initialized
INFO - 2023-08-16 20:13:48 --> Output Class Initialized
INFO - 2023-08-16 20:13:48 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:48 --> Input Class Initialized
INFO - 2023-08-16 20:13:48 --> Language Class Initialized
ERROR - 2023-08-16 20:13:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:13:48 --> Config Class Initialized
INFO - 2023-08-16 20:13:48 --> Hooks Class Initialized
INFO - 2023-08-16 20:13:48 --> Config Class Initialized
INFO - 2023-08-16 20:13:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:48 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:48 --> URI Class Initialized
INFO - 2023-08-16 20:13:48 --> Router Class Initialized
INFO - 2023-08-16 20:13:48 --> Output Class Initialized
INFO - 2023-08-16 20:13:48 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:48 --> Input Class Initialized
INFO - 2023-08-16 20:13:48 --> Language Class Initialized
ERROR - 2023-08-16 20:13:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:13:48 --> Config Class Initialized
INFO - 2023-08-16 20:13:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:48 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:48 --> URI Class Initialized
INFO - 2023-08-16 20:13:48 --> Router Class Initialized
INFO - 2023-08-16 20:13:48 --> Output Class Initialized
INFO - 2023-08-16 20:13:48 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:48 --> Input Class Initialized
INFO - 2023-08-16 20:13:48 --> Language Class Initialized
ERROR - 2023-08-16 20:13:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:13:48 --> Config Class Initialized
INFO - 2023-08-16 20:13:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:48 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:48 --> URI Class Initialized
INFO - 2023-08-16 20:13:48 --> Router Class Initialized
INFO - 2023-08-16 20:13:48 --> Output Class Initialized
INFO - 2023-08-16 20:13:48 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:48 --> Input Class Initialized
INFO - 2023-08-16 20:13:48 --> Language Class Initialized
ERROR - 2023-08-16 20:13:48 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 20:13:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:49 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:49 --> Config Class Initialized
INFO - 2023-08-16 20:13:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:49 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:49 --> URI Class Initialized
INFO - 2023-08-16 20:13:49 --> Router Class Initialized
INFO - 2023-08-16 20:13:49 --> Output Class Initialized
INFO - 2023-08-16 20:13:49 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:49 --> Input Class Initialized
INFO - 2023-08-16 20:13:49 --> Language Class Initialized
ERROR - 2023-08-16 20:13:49 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:13:49 --> URI Class Initialized
INFO - 2023-08-16 20:13:49 --> Router Class Initialized
INFO - 2023-08-16 20:13:49 --> Output Class Initialized
INFO - 2023-08-16 20:13:50 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:50 --> Config Class Initialized
INFO - 2023-08-16 20:13:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:50 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:50 --> URI Class Initialized
INFO - 2023-08-16 20:13:50 --> Router Class Initialized
INFO - 2023-08-16 20:13:50 --> Output Class Initialized
INFO - 2023-08-16 20:13:50 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:50 --> Input Class Initialized
INFO - 2023-08-16 20:13:50 --> Language Class Initialized
ERROR - 2023-08-16 20:13:50 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:13:50 --> Input Class Initialized
INFO - 2023-08-16 20:13:50 --> Config Class Initialized
INFO - 2023-08-16 20:13:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:50 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:50 --> URI Class Initialized
INFO - 2023-08-16 20:13:50 --> Router Class Initialized
INFO - 2023-08-16 20:13:50 --> Output Class Initialized
INFO - 2023-08-16 20:13:50 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:50 --> Input Class Initialized
INFO - 2023-08-16 20:13:50 --> Language Class Initialized
ERROR - 2023-08-16 20:13:50 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:13:50 --> Language Class Initialized
ERROR - 2023-08-16 20:13:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:13:51 --> Config Class Initialized
INFO - 2023-08-16 20:13:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:51 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:51 --> URI Class Initialized
INFO - 2023-08-16 20:13:51 --> Router Class Initialized
INFO - 2023-08-16 20:13:51 --> Output Class Initialized
INFO - 2023-08-16 20:13:51 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:51 --> Input Class Initialized
INFO - 2023-08-16 20:13:51 --> Language Class Initialized
ERROR - 2023-08-16 20:13:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:13:51 --> Config Class Initialized
INFO - 2023-08-16 20:13:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:51 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:51 --> URI Class Initialized
INFO - 2023-08-16 20:13:51 --> Router Class Initialized
INFO - 2023-08-16 20:13:51 --> Output Class Initialized
INFO - 2023-08-16 20:13:51 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:51 --> Input Class Initialized
INFO - 2023-08-16 20:13:51 --> Language Class Initialized
ERROR - 2023-08-16 20:13:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:13:51 --> Config Class Initialized
INFO - 2023-08-16 20:13:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:52 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:52 --> URI Class Initialized
INFO - 2023-08-16 20:13:52 --> Router Class Initialized
INFO - 2023-08-16 20:13:52 --> Output Class Initialized
INFO - 2023-08-16 20:13:52 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:53 --> Input Class Initialized
INFO - 2023-08-16 20:13:53 --> Language Class Initialized
ERROR - 2023-08-16 20:13:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:13:54 --> Config Class Initialized
INFO - 2023-08-16 20:13:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:54 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:54 --> URI Class Initialized
INFO - 2023-08-16 20:13:54 --> Router Class Initialized
INFO - 2023-08-16 20:13:54 --> Output Class Initialized
INFO - 2023-08-16 20:13:54 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:54 --> Input Class Initialized
INFO - 2023-08-16 20:13:54 --> Language Class Initialized
ERROR - 2023-08-16 20:13:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:13:54 --> Config Class Initialized
INFO - 2023-08-16 20:13:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:54 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:54 --> URI Class Initialized
INFO - 2023-08-16 20:13:54 --> Router Class Initialized
INFO - 2023-08-16 20:13:54 --> Output Class Initialized
INFO - 2023-08-16 20:13:54 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:54 --> Input Class Initialized
INFO - 2023-08-16 20:13:54 --> Language Class Initialized
ERROR - 2023-08-16 20:13:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:13:55 --> Config Class Initialized
INFO - 2023-08-16 20:13:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:13:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:13:55 --> Utf8 Class Initialized
INFO - 2023-08-16 20:13:55 --> URI Class Initialized
INFO - 2023-08-16 20:13:55 --> Router Class Initialized
INFO - 2023-08-16 20:13:55 --> Output Class Initialized
INFO - 2023-08-16 20:13:56 --> Security Class Initialized
DEBUG - 2023-08-16 20:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:13:56 --> Input Class Initialized
INFO - 2023-08-16 20:13:56 --> Language Class Initialized
ERROR - 2023-08-16 20:13:56 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:15:58 --> Config Class Initialized
INFO - 2023-08-16 20:15:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:15:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:15:58 --> Utf8 Class Initialized
INFO - 2023-08-16 20:15:58 --> URI Class Initialized
INFO - 2023-08-16 20:15:58 --> Router Class Initialized
INFO - 2023-08-16 20:15:58 --> Output Class Initialized
INFO - 2023-08-16 20:15:58 --> Security Class Initialized
DEBUG - 2023-08-16 20:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:15:58 --> Input Class Initialized
INFO - 2023-08-16 20:15:58 --> Language Class Initialized
INFO - 2023-08-16 20:15:58 --> Loader Class Initialized
INFO - 2023-08-16 20:15:59 --> Helper loaded: url_helper
INFO - 2023-08-16 20:15:59 --> Helper loaded: file_helper
INFO - 2023-08-16 20:15:59 --> Database Driver Class Initialized
INFO - 2023-08-16 20:15:59 --> Email Class Initialized
DEBUG - 2023-08-16 20:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:15:59 --> Controller Class Initialized
INFO - 2023-08-16 20:15:59 --> Model "Home_model" initialized
INFO - 2023-08-16 20:15:59 --> Helper loaded: form_helper
INFO - 2023-08-16 20:15:59 --> Form Validation Class Initialized
INFO - 2023-08-16 20:15:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:15:59 --> Final output sent to browser
DEBUG - 2023-08-16 20:15:59 --> Total execution time: 0.7800
INFO - 2023-08-16 20:16:00 --> Config Class Initialized
INFO - 2023-08-16 20:16:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:00 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:00 --> URI Class Initialized
INFO - 2023-08-16 20:16:00 --> Router Class Initialized
INFO - 2023-08-16 20:16:00 --> Output Class Initialized
INFO - 2023-08-16 20:16:00 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:00 --> Input Class Initialized
INFO - 2023-08-16 20:16:00 --> Language Class Initialized
ERROR - 2023-08-16 20:16:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:00 --> Config Class Initialized
INFO - 2023-08-16 20:16:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:00 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:00 --> URI Class Initialized
INFO - 2023-08-16 20:16:00 --> Router Class Initialized
INFO - 2023-08-16 20:16:00 --> Output Class Initialized
INFO - 2023-08-16 20:16:00 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:00 --> Input Class Initialized
INFO - 2023-08-16 20:16:00 --> Language Class Initialized
ERROR - 2023-08-16 20:16:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:00 --> Config Class Initialized
INFO - 2023-08-16 20:16:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:00 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:00 --> URI Class Initialized
INFO - 2023-08-16 20:16:00 --> Router Class Initialized
INFO - 2023-08-16 20:16:00 --> Output Class Initialized
INFO - 2023-08-16 20:16:00 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:00 --> Input Class Initialized
INFO - 2023-08-16 20:16:00 --> Language Class Initialized
ERROR - 2023-08-16 20:16:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:00 --> Config Class Initialized
INFO - 2023-08-16 20:16:00 --> Hooks Class Initialized
INFO - 2023-08-16 20:16:00 --> Config Class Initialized
INFO - 2023-08-16 20:16:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:00 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:00 --> URI Class Initialized
INFO - 2023-08-16 20:16:00 --> Router Class Initialized
INFO - 2023-08-16 20:16:00 --> Output Class Initialized
INFO - 2023-08-16 20:16:00 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:00 --> Input Class Initialized
INFO - 2023-08-16 20:16:00 --> Language Class Initialized
ERROR - 2023-08-16 20:16:00 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 20:16:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:01 --> Config Class Initialized
INFO - 2023-08-16 20:16:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:01 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:01 --> URI Class Initialized
INFO - 2023-08-16 20:16:01 --> Router Class Initialized
INFO - 2023-08-16 20:16:01 --> Output Class Initialized
INFO - 2023-08-16 20:16:01 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:01 --> Input Class Initialized
INFO - 2023-08-16 20:16:01 --> Language Class Initialized
ERROR - 2023-08-16 20:16:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:01 --> Config Class Initialized
INFO - 2023-08-16 20:16:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:01 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:01 --> URI Class Initialized
INFO - 2023-08-16 20:16:01 --> Router Class Initialized
INFO - 2023-08-16 20:16:01 --> Output Class Initialized
INFO - 2023-08-16 20:16:01 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:01 --> Input Class Initialized
INFO - 2023-08-16 20:16:01 --> Language Class Initialized
ERROR - 2023-08-16 20:16:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:01 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:01 --> URI Class Initialized
INFO - 2023-08-16 20:16:01 --> Router Class Initialized
INFO - 2023-08-16 20:16:01 --> Config Class Initialized
INFO - 2023-08-16 20:16:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:01 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:01 --> URI Class Initialized
INFO - 2023-08-16 20:16:01 --> Router Class Initialized
INFO - 2023-08-16 20:16:01 --> Output Class Initialized
INFO - 2023-08-16 20:16:01 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:01 --> Input Class Initialized
INFO - 2023-08-16 20:16:01 --> Language Class Initialized
ERROR - 2023-08-16 20:16:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:01 --> Output Class Initialized
INFO - 2023-08-16 20:16:01 --> Config Class Initialized
INFO - 2023-08-16 20:16:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:01 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:01 --> URI Class Initialized
INFO - 2023-08-16 20:16:01 --> Router Class Initialized
INFO - 2023-08-16 20:16:01 --> Output Class Initialized
INFO - 2023-08-16 20:16:01 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:01 --> Input Class Initialized
INFO - 2023-08-16 20:16:01 --> Language Class Initialized
ERROR - 2023-08-16 20:16:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:01 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:02 --> Input Class Initialized
INFO - 2023-08-16 20:16:02 --> Language Class Initialized
ERROR - 2023-08-16 20:16:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:02 --> Config Class Initialized
INFO - 2023-08-16 20:16:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:02 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:02 --> URI Class Initialized
INFO - 2023-08-16 20:16:02 --> Router Class Initialized
INFO - 2023-08-16 20:16:02 --> Output Class Initialized
INFO - 2023-08-16 20:16:02 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:02 --> Input Class Initialized
INFO - 2023-08-16 20:16:02 --> Language Class Initialized
ERROR - 2023-08-16 20:16:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:02 --> Config Class Initialized
INFO - 2023-08-16 20:16:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:02 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:02 --> URI Class Initialized
INFO - 2023-08-16 20:16:02 --> Router Class Initialized
INFO - 2023-08-16 20:16:02 --> Output Class Initialized
INFO - 2023-08-16 20:16:02 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:02 --> Input Class Initialized
INFO - 2023-08-16 20:16:02 --> Language Class Initialized
ERROR - 2023-08-16 20:16:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:03 --> Config Class Initialized
INFO - 2023-08-16 20:16:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:03 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:03 --> URI Class Initialized
INFO - 2023-08-16 20:16:03 --> Router Class Initialized
INFO - 2023-08-16 20:16:04 --> Output Class Initialized
INFO - 2023-08-16 20:16:04 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:04 --> Input Class Initialized
INFO - 2023-08-16 20:16:04 --> Language Class Initialized
ERROR - 2023-08-16 20:16:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:04 --> Config Class Initialized
INFO - 2023-08-16 20:16:04 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:04 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:04 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:04 --> URI Class Initialized
INFO - 2023-08-16 20:16:04 --> Router Class Initialized
INFO - 2023-08-16 20:16:04 --> Output Class Initialized
INFO - 2023-08-16 20:16:04 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:04 --> Input Class Initialized
INFO - 2023-08-16 20:16:04 --> Language Class Initialized
ERROR - 2023-08-16 20:16:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:17 --> Config Class Initialized
INFO - 2023-08-16 20:16:17 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:17 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:17 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:17 --> URI Class Initialized
INFO - 2023-08-16 20:16:17 --> Router Class Initialized
INFO - 2023-08-16 20:16:17 --> Output Class Initialized
INFO - 2023-08-16 20:16:17 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:18 --> Input Class Initialized
INFO - 2023-08-16 20:16:18 --> Language Class Initialized
INFO - 2023-08-16 20:16:18 --> Loader Class Initialized
INFO - 2023-08-16 20:16:18 --> Helper loaded: url_helper
INFO - 2023-08-16 20:16:18 --> Helper loaded: file_helper
INFO - 2023-08-16 20:16:18 --> Database Driver Class Initialized
INFO - 2023-08-16 20:16:18 --> Email Class Initialized
DEBUG - 2023-08-16 20:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:16:18 --> Controller Class Initialized
INFO - 2023-08-16 20:16:18 --> Model "Home_model" initialized
INFO - 2023-08-16 20:16:18 --> Helper loaded: form_helper
INFO - 2023-08-16 20:16:18 --> Form Validation Class Initialized
INFO - 2023-08-16 20:16:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:16:18 --> Final output sent to browser
DEBUG - 2023-08-16 20:16:18 --> Total execution time: 1.1979
INFO - 2023-08-16 20:16:19 --> Config Class Initialized
INFO - 2023-08-16 20:16:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:19 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:19 --> URI Class Initialized
INFO - 2023-08-16 20:16:19 --> Router Class Initialized
INFO - 2023-08-16 20:16:19 --> Output Class Initialized
INFO - 2023-08-16 20:16:19 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:20 --> Input Class Initialized
INFO - 2023-08-16 20:16:20 --> Language Class Initialized
ERROR - 2023-08-16 20:16:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:20 --> Config Class Initialized
INFO - 2023-08-16 20:16:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:20 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:20 --> URI Class Initialized
INFO - 2023-08-16 20:16:20 --> Router Class Initialized
INFO - 2023-08-16 20:16:20 --> Output Class Initialized
INFO - 2023-08-16 20:16:20 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:20 --> Input Class Initialized
INFO - 2023-08-16 20:16:20 --> Language Class Initialized
ERROR - 2023-08-16 20:16:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:20 --> Config Class Initialized
INFO - 2023-08-16 20:16:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:20 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:20 --> URI Class Initialized
INFO - 2023-08-16 20:16:20 --> Router Class Initialized
INFO - 2023-08-16 20:16:20 --> Output Class Initialized
INFO - 2023-08-16 20:16:20 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:20 --> Input Class Initialized
INFO - 2023-08-16 20:16:20 --> Language Class Initialized
ERROR - 2023-08-16 20:16:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:20 --> Config Class Initialized
INFO - 2023-08-16 20:16:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:21 --> Config Class Initialized
INFO - 2023-08-16 20:16:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:21 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:21 --> URI Class Initialized
INFO - 2023-08-16 20:16:21 --> Router Class Initialized
INFO - 2023-08-16 20:16:21 --> Output Class Initialized
INFO - 2023-08-16 20:16:21 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:21 --> Input Class Initialized
INFO - 2023-08-16 20:16:21 --> Language Class Initialized
ERROR - 2023-08-16 20:16:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:21 --> Config Class Initialized
INFO - 2023-08-16 20:16:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:21 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:21 --> URI Class Initialized
INFO - 2023-08-16 20:16:21 --> Router Class Initialized
INFO - 2023-08-16 20:16:21 --> Output Class Initialized
INFO - 2023-08-16 20:16:21 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:21 --> Input Class Initialized
INFO - 2023-08-16 20:16:21 --> Language Class Initialized
ERROR - 2023-08-16 20:16:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:21 --> Config Class Initialized
INFO - 2023-08-16 20:16:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:21 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:21 --> URI Class Initialized
INFO - 2023-08-16 20:16:21 --> Router Class Initialized
INFO - 2023-08-16 20:16:21 --> Output Class Initialized
INFO - 2023-08-16 20:16:21 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:21 --> Input Class Initialized
INFO - 2023-08-16 20:16:21 --> Language Class Initialized
ERROR - 2023-08-16 20:16:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:21 --> Config Class Initialized
INFO - 2023-08-16 20:16:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:21 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:21 --> URI Class Initialized
INFO - 2023-08-16 20:16:21 --> Router Class Initialized
INFO - 2023-08-16 20:16:21 --> Output Class Initialized
INFO - 2023-08-16 20:16:21 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:21 --> Input Class Initialized
INFO - 2023-08-16 20:16:21 --> Language Class Initialized
ERROR - 2023-08-16 20:16:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:21 --> Config Class Initialized
INFO - 2023-08-16 20:16:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:21 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:21 --> URI Class Initialized
INFO - 2023-08-16 20:16:21 --> Router Class Initialized
INFO - 2023-08-16 20:16:21 --> Output Class Initialized
INFO - 2023-08-16 20:16:21 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:21 --> Input Class Initialized
INFO - 2023-08-16 20:16:21 --> Language Class Initialized
ERROR - 2023-08-16 20:16:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:21 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:22 --> Config Class Initialized
INFO - 2023-08-16 20:16:22 --> URI Class Initialized
INFO - 2023-08-16 20:16:22 --> Router Class Initialized
INFO - 2023-08-16 20:16:22 --> Hooks Class Initialized
INFO - 2023-08-16 20:16:22 --> Config Class Initialized
DEBUG - 2023-08-16 20:16:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:22 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:23 --> URI Class Initialized
INFO - 2023-08-16 20:16:23 --> Router Class Initialized
INFO - 2023-08-16 20:16:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:23 --> Config Class Initialized
INFO - 2023-08-16 20:16:23 --> Hooks Class Initialized
INFO - 2023-08-16 20:16:23 --> Output Class Initialized
DEBUG - 2023-08-16 20:16:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:23 --> Security Class Initialized
INFO - 2023-08-16 20:16:23 --> Output Class Initialized
DEBUG - 2023-08-16 20:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:23 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:23 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:23 --> Input Class Initialized
INFO - 2023-08-16 20:16:23 --> URI Class Initialized
INFO - 2023-08-16 20:16:23 --> Security Class Initialized
INFO - 2023-08-16 20:16:23 --> URI Class Initialized
INFO - 2023-08-16 20:16:23 --> Router Class Initialized
INFO - 2023-08-16 20:16:23 --> Language Class Initialized
INFO - 2023-08-16 20:16:23 --> Router Class Initialized
DEBUG - 2023-08-16 20:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 20:16:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:23 --> Output Class Initialized
INFO - 2023-08-16 20:16:23 --> Security Class Initialized
INFO - 2023-08-16 20:16:23 --> Output Class Initialized
INFO - 2023-08-16 20:16:23 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:23 --> Input Class Initialized
INFO - 2023-08-16 20:16:23 --> Language Class Initialized
DEBUG - 2023-08-16 20:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:23 --> Config Class Initialized
INFO - 2023-08-16 20:16:23 --> Hooks Class Initialized
INFO - 2023-08-16 20:16:23 --> Input Class Initialized
INFO - 2023-08-16 20:16:23 --> Input Class Initialized
DEBUG - 2023-08-16 20:16:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:23 --> Utf8 Class Initialized
ERROR - 2023-08-16 20:16:23 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:23 --> URI Class Initialized
INFO - 2023-08-16 20:16:23 --> Language Class Initialized
INFO - 2023-08-16 20:16:23 --> Language Class Initialized
ERROR - 2023-08-16 20:16:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:23 --> Router Class Initialized
ERROR - 2023-08-16 20:16:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:23 --> Output Class Initialized
INFO - 2023-08-16 20:16:23 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:23 --> Input Class Initialized
INFO - 2023-08-16 20:16:23 --> Language Class Initialized
ERROR - 2023-08-16 20:16:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:36 --> Config Class Initialized
INFO - 2023-08-16 20:16:36 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:36 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:36 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:36 --> URI Class Initialized
INFO - 2023-08-16 20:16:36 --> Router Class Initialized
INFO - 2023-08-16 20:16:37 --> Output Class Initialized
INFO - 2023-08-16 20:16:37 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:37 --> Input Class Initialized
INFO - 2023-08-16 20:16:37 --> Language Class Initialized
INFO - 2023-08-16 20:16:37 --> Loader Class Initialized
INFO - 2023-08-16 20:16:37 --> Helper loaded: url_helper
INFO - 2023-08-16 20:16:37 --> Helper loaded: file_helper
INFO - 2023-08-16 20:16:37 --> Database Driver Class Initialized
INFO - 2023-08-16 20:16:37 --> Email Class Initialized
DEBUG - 2023-08-16 20:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:16:37 --> Controller Class Initialized
INFO - 2023-08-16 20:16:37 --> Model "Home_model" initialized
INFO - 2023-08-16 20:16:37 --> Helper loaded: form_helper
INFO - 2023-08-16 20:16:37 --> Form Validation Class Initialized
INFO - 2023-08-16 20:16:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:16:37 --> Final output sent to browser
DEBUG - 2023-08-16 20:16:37 --> Total execution time: 0.9180
INFO - 2023-08-16 20:16:39 --> Config Class Initialized
INFO - 2023-08-16 20:16:39 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:39 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:39 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:39 --> Config Class Initialized
INFO - 2023-08-16 20:16:39 --> URI Class Initialized
INFO - 2023-08-16 20:16:40 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:40 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:40 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:40 --> URI Class Initialized
INFO - 2023-08-16 20:16:40 --> Router Class Initialized
INFO - 2023-08-16 20:16:40 --> Output Class Initialized
INFO - 2023-08-16 20:16:40 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:40 --> Input Class Initialized
INFO - 2023-08-16 20:16:40 --> Language Class Initialized
ERROR - 2023-08-16 20:16:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:40 --> Router Class Initialized
INFO - 2023-08-16 20:16:40 --> Output Class Initialized
INFO - 2023-08-16 20:16:40 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:40 --> Config Class Initialized
INFO - 2023-08-16 20:16:40 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:40 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:40 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:40 --> URI Class Initialized
INFO - 2023-08-16 20:16:40 --> Router Class Initialized
INFO - 2023-08-16 20:16:40 --> Output Class Initialized
INFO - 2023-08-16 20:16:40 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:40 --> Input Class Initialized
INFO - 2023-08-16 20:16:40 --> Language Class Initialized
ERROR - 2023-08-16 20:16:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:41 --> Input Class Initialized
INFO - 2023-08-16 20:16:41 --> Config Class Initialized
INFO - 2023-08-16 20:16:41 --> Hooks Class Initialized
INFO - 2023-08-16 20:16:41 --> Language Class Initialized
ERROR - 2023-08-16 20:16:41 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 20:16:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:41 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:41 --> URI Class Initialized
INFO - 2023-08-16 20:16:41 --> Router Class Initialized
INFO - 2023-08-16 20:16:41 --> Output Class Initialized
INFO - 2023-08-16 20:16:42 --> Config Class Initialized
INFO - 2023-08-16 20:16:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:42 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:42 --> URI Class Initialized
INFO - 2023-08-16 20:16:42 --> Router Class Initialized
INFO - 2023-08-16 20:16:42 --> Config Class Initialized
INFO - 2023-08-16 20:16:42 --> Security Class Initialized
INFO - 2023-08-16 20:16:42 --> Config Class Initialized
INFO - 2023-08-16 20:16:42 --> Config Class Initialized
INFO - 2023-08-16 20:16:42 --> Hooks Class Initialized
INFO - 2023-08-16 20:16:42 --> Config Class Initialized
INFO - 2023-08-16 20:16:42 --> Hooks Class Initialized
INFO - 2023-08-16 20:16:42 --> Output Class Initialized
DEBUG - 2023-08-16 20:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 20:16:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:42 --> Input Class Initialized
INFO - 2023-08-16 20:16:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:42 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:16:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:42 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:42 --> Hooks Class Initialized
INFO - 2023-08-16 20:16:42 --> Security Class Initialized
INFO - 2023-08-16 20:16:42 --> Language Class Initialized
INFO - 2023-08-16 20:16:42 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:42 --> URI Class Initialized
DEBUG - 2023-08-16 20:16:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:42 --> URI Class Initialized
INFO - 2023-08-16 20:16:42 --> URI Class Initialized
ERROR - 2023-08-16 20:16:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:42 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:42 --> Input Class Initialized
INFO - 2023-08-16 20:16:42 --> Router Class Initialized
INFO - 2023-08-16 20:16:42 --> Router Class Initialized
INFO - 2023-08-16 20:16:42 --> Output Class Initialized
INFO - 2023-08-16 20:16:42 --> Output Class Initialized
INFO - 2023-08-16 20:16:42 --> Language Class Initialized
INFO - 2023-08-16 20:16:42 --> Security Class Initialized
INFO - 2023-08-16 20:16:42 --> URI Class Initialized
DEBUG - 2023-08-16 20:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:42 --> Router Class Initialized
INFO - 2023-08-16 20:16:42 --> Security Class Initialized
ERROR - 2023-08-16 20:16:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:42 --> Output Class Initialized
INFO - 2023-08-16 20:16:42 --> Router Class Initialized
INFO - 2023-08-16 20:16:42 --> Config Class Initialized
INFO - 2023-08-16 20:16:42 --> Hooks Class Initialized
INFO - 2023-08-16 20:16:42 --> Output Class Initialized
INFO - 2023-08-16 20:16:42 --> Security Class Initialized
INFO - 2023-08-16 20:16:42 --> Input Class Initialized
INFO - 2023-08-16 20:16:43 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:43 --> Language Class Initialized
DEBUG - 2023-08-16 20:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:43 --> Input Class Initialized
ERROR - 2023-08-16 20:16:43 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 20:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:43 --> Input Class Initialized
INFO - 2023-08-16 20:16:43 --> Language Class Initialized
ERROR - 2023-08-16 20:16:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:43 --> Language Class Initialized
DEBUG - 2023-08-16 20:16:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:43 --> Config Class Initialized
INFO - 2023-08-16 20:16:43 --> Input Class Initialized
ERROR - 2023-08-16 20:16:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:43 --> Language Class Initialized
INFO - 2023-08-16 20:16:43 --> Hooks Class Initialized
INFO - 2023-08-16 20:16:43 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:43 --> URI Class Initialized
INFO - 2023-08-16 20:16:43 --> Config Class Initialized
ERROR - 2023-08-16 20:16:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:16:43 --> Config Class Initialized
DEBUG - 2023-08-16 20:16:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:43 --> Hooks Class Initialized
INFO - 2023-08-16 20:16:43 --> Router Class Initialized
DEBUG - 2023-08-16 20:16:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:16:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:16:43 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:43 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:43 --> Output Class Initialized
INFO - 2023-08-16 20:16:43 --> Security Class Initialized
INFO - 2023-08-16 20:16:43 --> Utf8 Class Initialized
INFO - 2023-08-16 20:16:43 --> URI Class Initialized
INFO - 2023-08-16 20:16:44 --> URI Class Initialized
DEBUG - 2023-08-16 20:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:44 --> Router Class Initialized
INFO - 2023-08-16 20:16:44 --> URI Class Initialized
INFO - 2023-08-16 20:16:44 --> Router Class Initialized
INFO - 2023-08-16 20:16:44 --> Output Class Initialized
INFO - 2023-08-16 20:16:44 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:44 --> Input Class Initialized
INFO - 2023-08-16 20:16:44 --> Language Class Initialized
ERROR - 2023-08-16 20:16:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:44 --> Input Class Initialized
INFO - 2023-08-16 20:16:44 --> Router Class Initialized
INFO - 2023-08-16 20:16:44 --> Output Class Initialized
INFO - 2023-08-16 20:16:44 --> Output Class Initialized
INFO - 2023-08-16 20:16:44 --> Security Class Initialized
DEBUG - 2023-08-16 20:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:16:44 --> Security Class Initialized
INFO - 2023-08-16 20:16:44 --> Language Class Initialized
DEBUG - 2023-08-16 20:16:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 20:16:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:16:44 --> Input Class Initialized
INFO - 2023-08-16 20:16:44 --> Input Class Initialized
INFO - 2023-08-16 20:16:44 --> Language Class Initialized
INFO - 2023-08-16 20:16:44 --> Language Class Initialized
ERROR - 2023-08-16 20:16:44 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-16 20:16:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:17:08 --> Config Class Initialized
INFO - 2023-08-16 20:17:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:17:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:08 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:08 --> URI Class Initialized
INFO - 2023-08-16 20:17:08 --> Router Class Initialized
INFO - 2023-08-16 20:17:08 --> Output Class Initialized
INFO - 2023-08-16 20:17:08 --> Security Class Initialized
DEBUG - 2023-08-16 20:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:08 --> Input Class Initialized
INFO - 2023-08-16 20:17:08 --> Language Class Initialized
INFO - 2023-08-16 20:17:08 --> Loader Class Initialized
INFO - 2023-08-16 20:17:08 --> Helper loaded: url_helper
INFO - 2023-08-16 20:17:08 --> Helper loaded: file_helper
INFO - 2023-08-16 20:17:08 --> Database Driver Class Initialized
INFO - 2023-08-16 20:17:08 --> Email Class Initialized
DEBUG - 2023-08-16 20:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:17:08 --> Controller Class Initialized
INFO - 2023-08-16 20:17:08 --> Model "Home_model" initialized
INFO - 2023-08-16 20:17:08 --> Helper loaded: form_helper
INFO - 2023-08-16 20:17:08 --> Form Validation Class Initialized
INFO - 2023-08-16 20:17:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:17:08 --> Final output sent to browser
DEBUG - 2023-08-16 20:17:08 --> Total execution time: 0.4584
INFO - 2023-08-16 20:17:10 --> Config Class Initialized
INFO - 2023-08-16 20:17:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:17:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:11 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:11 --> URI Class Initialized
INFO - 2023-08-16 20:17:11 --> Router Class Initialized
INFO - 2023-08-16 20:17:12 --> Output Class Initialized
INFO - 2023-08-16 20:17:12 --> Security Class Initialized
DEBUG - 2023-08-16 20:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:12 --> Input Class Initialized
INFO - 2023-08-16 20:17:12 --> Language Class Initialized
ERROR - 2023-08-16 20:17:13 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:17:13 --> Config Class Initialized
INFO - 2023-08-16 20:17:14 --> Config Class Initialized
INFO - 2023-08-16 20:17:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:17:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:14 --> Hooks Class Initialized
INFO - 2023-08-16 20:17:14 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:17:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:14 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:14 --> URI Class Initialized
INFO - 2023-08-16 20:17:14 --> URI Class Initialized
INFO - 2023-08-16 20:17:14 --> Router Class Initialized
INFO - 2023-08-16 20:17:14 --> Router Class Initialized
INFO - 2023-08-16 20:17:14 --> Output Class Initialized
INFO - 2023-08-16 20:17:14 --> Output Class Initialized
INFO - 2023-08-16 20:17:14 --> Security Class Initialized
INFO - 2023-08-16 20:17:14 --> Security Class Initialized
DEBUG - 2023-08-16 20:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 20:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:14 --> Input Class Initialized
INFO - 2023-08-16 20:17:14 --> Input Class Initialized
INFO - 2023-08-16 20:17:14 --> Language Class Initialized
INFO - 2023-08-16 20:17:14 --> Language Class Initialized
ERROR - 2023-08-16 20:17:14 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-16 20:17:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:17:14 --> Config Class Initialized
INFO - 2023-08-16 20:17:14 --> Hooks Class Initialized
INFO - 2023-08-16 20:17:14 --> Config Class Initialized
INFO - 2023-08-16 20:17:14 --> Config Class Initialized
DEBUG - 2023-08-16 20:17:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:14 --> Config Class Initialized
INFO - 2023-08-16 20:17:14 --> Config Class Initialized
INFO - 2023-08-16 20:17:14 --> Hooks Class Initialized
INFO - 2023-08-16 20:17:14 --> Hooks Class Initialized
INFO - 2023-08-16 20:17:14 --> Hooks Class Initialized
INFO - 2023-08-16 20:17:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:17:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:14 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:14 --> URI Class Initialized
INFO - 2023-08-16 20:17:14 --> Router Class Initialized
INFO - 2023-08-16 20:17:14 --> Output Class Initialized
INFO - 2023-08-16 20:17:14 --> Security Class Initialized
DEBUG - 2023-08-16 20:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 20:17:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:14 --> Input Class Initialized
INFO - 2023-08-16 20:17:14 --> Config Class Initialized
INFO - 2023-08-16 20:17:14 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:17:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:14 --> URI Class Initialized
DEBUG - 2023-08-16 20:17:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:14 --> Language Class Initialized
INFO - 2023-08-16 20:17:14 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:14 --> Hooks Class Initialized
INFO - 2023-08-16 20:17:14 --> Router Class Initialized
INFO - 2023-08-16 20:17:14 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:14 --> URI Class Initialized
INFO - 2023-08-16 20:17:14 --> Output Class Initialized
INFO - 2023-08-16 20:17:14 --> Security Class Initialized
DEBUG - 2023-08-16 20:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:14 --> Input Class Initialized
INFO - 2023-08-16 20:17:14 --> Language Class Initialized
ERROR - 2023-08-16 20:17:14 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-16 20:17:14 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:17:14 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:17:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:14 --> Router Class Initialized
INFO - 2023-08-16 20:17:14 --> URI Class Initialized
INFO - 2023-08-16 20:17:14 --> Router Class Initialized
INFO - 2023-08-16 20:17:14 --> URI Class Initialized
INFO - 2023-08-16 20:17:14 --> Config Class Initialized
INFO - 2023-08-16 20:17:14 --> Config Class Initialized
INFO - 2023-08-16 20:17:14 --> Router Class Initialized
INFO - 2023-08-16 20:17:14 --> Output Class Initialized
INFO - 2023-08-16 20:17:14 --> Hooks Class Initialized
INFO - 2023-08-16 20:17:14 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:14 --> Output Class Initialized
INFO - 2023-08-16 20:17:14 --> Security Class Initialized
INFO - 2023-08-16 20:17:14 --> Output Class Initialized
INFO - 2023-08-16 20:17:14 --> Security Class Initialized
INFO - 2023-08-16 20:17:15 --> Security Class Initialized
INFO - 2023-08-16 20:17:15 --> URI Class Initialized
DEBUG - 2023-08-16 20:17:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:15 --> Hooks Class Initialized
INFO - 2023-08-16 20:17:15 --> Utf8 Class Initialized
DEBUG - 2023-08-16 20:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:15 --> Router Class Initialized
INFO - 2023-08-16 20:17:15 --> Input Class Initialized
DEBUG - 2023-08-16 20:17:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:15 --> Input Class Initialized
INFO - 2023-08-16 20:17:15 --> Language Class Initialized
INFO - 2023-08-16 20:17:15 --> Input Class Initialized
INFO - 2023-08-16 20:17:15 --> Output Class Initialized
ERROR - 2023-08-16 20:17:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:17:15 --> Language Class Initialized
INFO - 2023-08-16 20:17:15 --> URI Class Initialized
INFO - 2023-08-16 20:17:15 --> Security Class Initialized
INFO - 2023-08-16 20:17:15 --> Language Class Initialized
INFO - 2023-08-16 20:17:15 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:15 --> URI Class Initialized
INFO - 2023-08-16 20:17:15 --> Config Class Initialized
INFO - 2023-08-16 20:17:15 --> Hooks Class Initialized
ERROR - 2023-08-16 20:17:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:17:15 --> Router Class Initialized
DEBUG - 2023-08-16 20:17:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-16 20:17:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:17:15 --> Router Class Initialized
DEBUG - 2023-08-16 20:17:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:15 --> Output Class Initialized
INFO - 2023-08-16 20:17:15 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:15 --> Output Class Initialized
INFO - 2023-08-16 20:17:15 --> Input Class Initialized
INFO - 2023-08-16 20:17:15 --> Security Class Initialized
INFO - 2023-08-16 20:17:15 --> Config Class Initialized
INFO - 2023-08-16 20:17:15 --> URI Class Initialized
INFO - 2023-08-16 20:17:15 --> Language Class Initialized
DEBUG - 2023-08-16 20:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:15 --> Hooks Class Initialized
INFO - 2023-08-16 20:17:15 --> Input Class Initialized
INFO - 2023-08-16 20:17:15 --> Language Class Initialized
ERROR - 2023-08-16 20:17:15 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-16 20:17:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:17:15 --> Security Class Initialized
INFO - 2023-08-16 20:17:15 --> Router Class Initialized
DEBUG - 2023-08-16 20:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 20:17:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:15 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:15 --> Output Class Initialized
INFO - 2023-08-16 20:17:16 --> Security Class Initialized
INFO - 2023-08-16 20:17:16 --> Input Class Initialized
DEBUG - 2023-08-16 20:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:16 --> URI Class Initialized
INFO - 2023-08-16 20:17:16 --> Input Class Initialized
INFO - 2023-08-16 20:17:16 --> Router Class Initialized
INFO - 2023-08-16 20:17:16 --> Language Class Initialized
INFO - 2023-08-16 20:17:16 --> Output Class Initialized
ERROR - 2023-08-16 20:17:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:17:16 --> Language Class Initialized
INFO - 2023-08-16 20:17:16 --> Security Class Initialized
ERROR - 2023-08-16 20:17:16 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-16 20:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:16 --> Input Class Initialized
INFO - 2023-08-16 20:17:16 --> Language Class Initialized
ERROR - 2023-08-16 20:17:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-16 20:17:51 --> Config Class Initialized
INFO - 2023-08-16 20:17:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:17:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:51 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:51 --> URI Class Initialized
INFO - 2023-08-16 20:17:51 --> Router Class Initialized
INFO - 2023-08-16 20:17:51 --> Output Class Initialized
INFO - 2023-08-16 20:17:51 --> Security Class Initialized
DEBUG - 2023-08-16 20:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:52 --> Input Class Initialized
INFO - 2023-08-16 20:17:52 --> Language Class Initialized
INFO - 2023-08-16 20:17:52 --> Loader Class Initialized
INFO - 2023-08-16 20:17:52 --> Helper loaded: url_helper
INFO - 2023-08-16 20:17:52 --> Helper loaded: file_helper
INFO - 2023-08-16 20:17:52 --> Database Driver Class Initialized
INFO - 2023-08-16 20:17:52 --> Email Class Initialized
DEBUG - 2023-08-16 20:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:17:52 --> Controller Class Initialized
INFO - 2023-08-16 20:17:52 --> Model "Home_model" initialized
INFO - 2023-08-16 20:17:52 --> Helper loaded: form_helper
INFO - 2023-08-16 20:17:52 --> Form Validation Class Initialized
INFO - 2023-08-16 20:17:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:17:52 --> Final output sent to browser
DEBUG - 2023-08-16 20:17:52 --> Total execution time: 0.5424
INFO - 2023-08-16 20:17:53 --> Config Class Initialized
INFO - 2023-08-16 20:17:53 --> Config Class Initialized
INFO - 2023-08-16 20:17:53 --> Hooks Class Initialized
INFO - 2023-08-16 20:17:53 --> Config Class Initialized
INFO - 2023-08-16 20:17:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:17:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-16 20:17:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:53 --> Config Class Initialized
INFO - 2023-08-16 20:17:53 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:53 --> URI Class Initialized
INFO - 2023-08-16 20:17:53 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:53 --> Hooks Class Initialized
INFO - 2023-08-16 20:17:53 --> URI Class Initialized
DEBUG - 2023-08-16 20:17:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:17:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:53 --> Router Class Initialized
INFO - 2023-08-16 20:17:53 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:53 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:53 --> Router Class Initialized
INFO - 2023-08-16 20:17:53 --> URI Class Initialized
INFO - 2023-08-16 20:17:53 --> Output Class Initialized
INFO - 2023-08-16 20:17:53 --> URI Class Initialized
INFO - 2023-08-16 20:17:53 --> Router Class Initialized
INFO - 2023-08-16 20:17:53 --> Router Class Initialized
INFO - 2023-08-16 20:17:53 --> Output Class Initialized
INFO - 2023-08-16 20:17:53 --> Security Class Initialized
INFO - 2023-08-16 20:17:53 --> Security Class Initialized
INFO - 2023-08-16 20:17:53 --> Output Class Initialized
INFO - 2023-08-16 20:17:53 --> Output Class Initialized
INFO - 2023-08-16 20:17:53 --> Security Class Initialized
DEBUG - 2023-08-16 20:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-16 20:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:53 --> Input Class Initialized
DEBUG - 2023-08-16 20:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:54 --> Input Class Initialized
INFO - 2023-08-16 20:17:54 --> Language Class Initialized
INFO - 2023-08-16 20:17:54 --> Security Class Initialized
ERROR - 2023-08-16 20:17:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:17:54 --> Config Class Initialized
INFO - 2023-08-16 20:17:54 --> Config Class Initialized
INFO - 2023-08-16 20:17:54 --> Hooks Class Initialized
INFO - 2023-08-16 20:17:54 --> Language Class Initialized
DEBUG - 2023-08-16 20:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:54 --> Input Class Initialized
INFO - 2023-08-16 20:17:54 --> Input Class Initialized
INFO - 2023-08-16 20:17:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:17:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:54 --> Language Class Initialized
INFO - 2023-08-16 20:17:54 --> Language Class Initialized
ERROR - 2023-08-16 20:17:54 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-16 20:17:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:17:54 --> Utf8 Class Initialized
ERROR - 2023-08-16 20:17:54 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-16 20:17:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:17:54 --> URI Class Initialized
INFO - 2023-08-16 20:17:54 --> Utf8 Class Initialized
INFO - 2023-08-16 20:17:54 --> Router Class Initialized
INFO - 2023-08-16 20:17:54 --> URI Class Initialized
INFO - 2023-08-16 20:17:54 --> Output Class Initialized
INFO - 2023-08-16 20:17:54 --> Router Class Initialized
INFO - 2023-08-16 20:17:54 --> Output Class Initialized
INFO - 2023-08-16 20:17:54 --> Security Class Initialized
INFO - 2023-08-16 20:17:54 --> Security Class Initialized
DEBUG - 2023-08-16 20:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:54 --> Input Class Initialized
DEBUG - 2023-08-16 20:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:17:54 --> Language Class Initialized
INFO - 2023-08-16 20:17:54 --> Input Class Initialized
ERROR - 2023-08-16 20:17:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:17:54 --> Language Class Initialized
ERROR - 2023-08-16 20:17:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:18:05 --> Config Class Initialized
INFO - 2023-08-16 20:18:05 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:18:05 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:18:05 --> Utf8 Class Initialized
INFO - 2023-08-16 20:18:05 --> URI Class Initialized
INFO - 2023-08-16 20:18:05 --> Router Class Initialized
INFO - 2023-08-16 20:18:05 --> Output Class Initialized
INFO - 2023-08-16 20:18:05 --> Security Class Initialized
DEBUG - 2023-08-16 20:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:18:05 --> Input Class Initialized
INFO - 2023-08-16 20:18:05 --> Language Class Initialized
INFO - 2023-08-16 20:18:05 --> Loader Class Initialized
INFO - 2023-08-16 20:18:05 --> Helper loaded: url_helper
INFO - 2023-08-16 20:18:05 --> Helper loaded: file_helper
INFO - 2023-08-16 20:18:05 --> Database Driver Class Initialized
INFO - 2023-08-16 20:18:06 --> Email Class Initialized
DEBUG - 2023-08-16 20:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 20:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 20:18:06 --> Controller Class Initialized
INFO - 2023-08-16 20:18:06 --> Model "Home_model" initialized
INFO - 2023-08-16 20:18:06 --> Helper loaded: form_helper
INFO - 2023-08-16 20:18:06 --> Form Validation Class Initialized
INFO - 2023-08-16 20:18:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-16 20:18:06 --> Final output sent to browser
DEBUG - 2023-08-16 20:18:06 --> Total execution time: 0.5232
INFO - 2023-08-16 20:18:06 --> Config Class Initialized
INFO - 2023-08-16 20:18:06 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:18:06 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:18:06 --> Utf8 Class Initialized
INFO - 2023-08-16 20:18:06 --> URI Class Initialized
INFO - 2023-08-16 20:18:06 --> Router Class Initialized
INFO - 2023-08-16 20:18:06 --> Output Class Initialized
INFO - 2023-08-16 20:18:06 --> Security Class Initialized
DEBUG - 2023-08-16 20:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:18:06 --> Input Class Initialized
INFO - 2023-08-16 20:18:06 --> Language Class Initialized
ERROR - 2023-08-16 20:18:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:18:06 --> Config Class Initialized
INFO - 2023-08-16 20:18:06 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:18:06 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:18:06 --> Utf8 Class Initialized
INFO - 2023-08-16 20:18:06 --> URI Class Initialized
INFO - 2023-08-16 20:18:06 --> Router Class Initialized
INFO - 2023-08-16 20:18:06 --> Output Class Initialized
INFO - 2023-08-16 20:18:06 --> Security Class Initialized
DEBUG - 2023-08-16 20:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:18:06 --> Input Class Initialized
INFO - 2023-08-16 20:18:06 --> Language Class Initialized
ERROR - 2023-08-16 20:18:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:18:06 --> Config Class Initialized
INFO - 2023-08-16 20:18:06 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:18:06 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:18:06 --> Utf8 Class Initialized
INFO - 2023-08-16 20:18:06 --> URI Class Initialized
INFO - 2023-08-16 20:18:06 --> Router Class Initialized
INFO - 2023-08-16 20:18:06 --> Output Class Initialized
INFO - 2023-08-16 20:18:06 --> Security Class Initialized
DEBUG - 2023-08-16 20:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:18:06 --> Input Class Initialized
INFO - 2023-08-16 20:18:06 --> Language Class Initialized
ERROR - 2023-08-16 20:18:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:18:07 --> Config Class Initialized
INFO - 2023-08-16 20:18:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:18:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:18:07 --> Utf8 Class Initialized
INFO - 2023-08-16 20:18:07 --> URI Class Initialized
INFO - 2023-08-16 20:18:07 --> Router Class Initialized
INFO - 2023-08-16 20:18:07 --> Output Class Initialized
INFO - 2023-08-16 20:18:07 --> Security Class Initialized
DEBUG - 2023-08-16 20:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:18:07 --> Input Class Initialized
INFO - 2023-08-16 20:18:07 --> Language Class Initialized
ERROR - 2023-08-16 20:18:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:18:07 --> Config Class Initialized
INFO - 2023-08-16 20:18:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:18:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:18:07 --> Utf8 Class Initialized
INFO - 2023-08-16 20:18:07 --> URI Class Initialized
INFO - 2023-08-16 20:18:07 --> Router Class Initialized
INFO - 2023-08-16 20:18:07 --> Output Class Initialized
INFO - 2023-08-16 20:18:07 --> Security Class Initialized
DEBUG - 2023-08-16 20:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:18:07 --> Input Class Initialized
INFO - 2023-08-16 20:18:07 --> Language Class Initialized
ERROR - 2023-08-16 20:18:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-16 20:18:07 --> Config Class Initialized
INFO - 2023-08-16 20:18:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 20:18:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 20:18:07 --> Utf8 Class Initialized
INFO - 2023-08-16 20:18:07 --> URI Class Initialized
INFO - 2023-08-16 20:18:07 --> Router Class Initialized
INFO - 2023-08-16 20:18:07 --> Output Class Initialized
INFO - 2023-08-16 20:18:07 --> Security Class Initialized
DEBUG - 2023-08-16 20:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 20:18:07 --> Input Class Initialized
INFO - 2023-08-16 20:18:07 --> Language Class Initialized
ERROR - 2023-08-16 20:18:07 --> 404 Page Not Found: Assets/images
