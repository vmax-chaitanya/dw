<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-18 17:13:38 --> Config Class Initialized
INFO - 2023-08-18 17:13:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:13:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:13:38 --> Utf8 Class Initialized
INFO - 2023-08-18 17:13:38 --> URI Class Initialized
INFO - 2023-08-18 17:13:38 --> Router Class Initialized
INFO - 2023-08-18 17:13:38 --> Output Class Initialized
INFO - 2023-08-18 17:13:38 --> Security Class Initialized
DEBUG - 2023-08-18 17:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:13:38 --> Input Class Initialized
INFO - 2023-08-18 17:13:38 --> Language Class Initialized
INFO - 2023-08-18 17:13:38 --> Loader Class Initialized
INFO - 2023-08-18 17:13:38 --> Helper loaded: url_helper
INFO - 2023-08-18 17:13:38 --> Helper loaded: file_helper
INFO - 2023-08-18 17:13:38 --> Database Driver Class Initialized
INFO - 2023-08-18 17:13:38 --> Email Class Initialized
DEBUG - 2023-08-18 17:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:13:38 --> Controller Class Initialized
INFO - 2023-08-18 17:13:38 --> Model "Home_model" initialized
INFO - 2023-08-18 17:13:38 --> Helper loaded: form_helper
INFO - 2023-08-18 17:13:38 --> Form Validation Class Initialized
INFO - 2023-08-18 17:13:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-18 17:13:38 --> Final output sent to browser
DEBUG - 2023-08-18 17:13:38 --> Total execution time: 0.1379
INFO - 2023-08-18 17:13:39 --> Config Class Initialized
INFO - 2023-08-18 17:13:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:13:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:13:39 --> Utf8 Class Initialized
INFO - 2023-08-18 17:13:39 --> URI Class Initialized
INFO - 2023-08-18 17:13:39 --> Router Class Initialized
INFO - 2023-08-18 17:13:39 --> Output Class Initialized
INFO - 2023-08-18 17:13:39 --> Security Class Initialized
DEBUG - 2023-08-18 17:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:13:39 --> Input Class Initialized
INFO - 2023-08-18 17:13:39 --> Language Class Initialized
ERROR - 2023-08-18 17:13:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:13:39 --> Config Class Initialized
INFO - 2023-08-18 17:13:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:13:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:13:39 --> Utf8 Class Initialized
INFO - 2023-08-18 17:13:39 --> URI Class Initialized
INFO - 2023-08-18 17:13:39 --> Router Class Initialized
INFO - 2023-08-18 17:13:39 --> Output Class Initialized
INFO - 2023-08-18 17:13:39 --> Security Class Initialized
DEBUG - 2023-08-18 17:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:13:39 --> Input Class Initialized
INFO - 2023-08-18 17:13:39 --> Language Class Initialized
ERROR - 2023-08-18 17:13:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:13:39 --> Config Class Initialized
INFO - 2023-08-18 17:13:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:13:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:13:39 --> Utf8 Class Initialized
INFO - 2023-08-18 17:13:39 --> URI Class Initialized
INFO - 2023-08-18 17:13:39 --> Router Class Initialized
INFO - 2023-08-18 17:13:39 --> Output Class Initialized
INFO - 2023-08-18 17:13:39 --> Security Class Initialized
DEBUG - 2023-08-18 17:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:13:39 --> Input Class Initialized
INFO - 2023-08-18 17:13:39 --> Language Class Initialized
ERROR - 2023-08-18 17:13:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:13:41 --> Config Class Initialized
INFO - 2023-08-18 17:13:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:13:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:13:41 --> Utf8 Class Initialized
INFO - 2023-08-18 17:13:41 --> URI Class Initialized
INFO - 2023-08-18 17:13:41 --> Router Class Initialized
INFO - 2023-08-18 17:13:41 --> Output Class Initialized
INFO - 2023-08-18 17:13:41 --> Security Class Initialized
DEBUG - 2023-08-18 17:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:13:41 --> Input Class Initialized
INFO - 2023-08-18 17:13:41 --> Language Class Initialized
ERROR - 2023-08-18 17:13:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:13:41 --> Config Class Initialized
INFO - 2023-08-18 17:13:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:13:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:13:41 --> Utf8 Class Initialized
INFO - 2023-08-18 17:13:41 --> URI Class Initialized
INFO - 2023-08-18 17:13:41 --> Router Class Initialized
INFO - 2023-08-18 17:13:41 --> Output Class Initialized
INFO - 2023-08-18 17:13:41 --> Security Class Initialized
DEBUG - 2023-08-18 17:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:13:41 --> Input Class Initialized
INFO - 2023-08-18 17:13:41 --> Language Class Initialized
ERROR - 2023-08-18 17:13:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:13:41 --> Config Class Initialized
INFO - 2023-08-18 17:13:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:13:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:13:41 --> Utf8 Class Initialized
INFO - 2023-08-18 17:13:41 --> URI Class Initialized
INFO - 2023-08-18 17:13:41 --> Router Class Initialized
INFO - 2023-08-18 17:13:41 --> Output Class Initialized
INFO - 2023-08-18 17:13:41 --> Security Class Initialized
DEBUG - 2023-08-18 17:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:13:41 --> Input Class Initialized
INFO - 2023-08-18 17:13:41 --> Language Class Initialized
ERROR - 2023-08-18 17:13:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:13:41 --> Config Class Initialized
INFO - 2023-08-18 17:13:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:13:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:13:41 --> Utf8 Class Initialized
INFO - 2023-08-18 17:13:41 --> URI Class Initialized
INFO - 2023-08-18 17:13:41 --> Router Class Initialized
INFO - 2023-08-18 17:13:41 --> Output Class Initialized
INFO - 2023-08-18 17:13:41 --> Security Class Initialized
DEBUG - 2023-08-18 17:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:13:41 --> Input Class Initialized
INFO - 2023-08-18 17:13:41 --> Language Class Initialized
ERROR - 2023-08-18 17:13:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:13:41 --> Config Class Initialized
INFO - 2023-08-18 17:13:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:13:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:13:41 --> Utf8 Class Initialized
INFO - 2023-08-18 17:13:41 --> URI Class Initialized
INFO - 2023-08-18 17:13:41 --> Router Class Initialized
INFO - 2023-08-18 17:13:41 --> Output Class Initialized
INFO - 2023-08-18 17:13:41 --> Security Class Initialized
DEBUG - 2023-08-18 17:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:13:41 --> Input Class Initialized
INFO - 2023-08-18 17:13:41 --> Language Class Initialized
ERROR - 2023-08-18 17:13:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:13:41 --> Config Class Initialized
INFO - 2023-08-18 17:13:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:13:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:13:41 --> Utf8 Class Initialized
INFO - 2023-08-18 17:13:41 --> URI Class Initialized
INFO - 2023-08-18 17:13:41 --> Router Class Initialized
INFO - 2023-08-18 17:13:41 --> Output Class Initialized
INFO - 2023-08-18 17:13:41 --> Security Class Initialized
DEBUG - 2023-08-18 17:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:13:41 --> Input Class Initialized
INFO - 2023-08-18 17:13:41 --> Language Class Initialized
ERROR - 2023-08-18 17:13:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:15:04 --> Config Class Initialized
INFO - 2023-08-18 17:15:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:15:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:15:04 --> Utf8 Class Initialized
INFO - 2023-08-18 17:15:04 --> URI Class Initialized
INFO - 2023-08-18 17:15:04 --> Router Class Initialized
INFO - 2023-08-18 17:15:04 --> Output Class Initialized
INFO - 2023-08-18 17:15:04 --> Security Class Initialized
DEBUG - 2023-08-18 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:15:04 --> Input Class Initialized
INFO - 2023-08-18 17:15:04 --> Language Class Initialized
INFO - 2023-08-18 17:15:04 --> Loader Class Initialized
INFO - 2023-08-18 17:15:04 --> Helper loaded: url_helper
INFO - 2023-08-18 17:15:04 --> Helper loaded: file_helper
INFO - 2023-08-18 17:15:04 --> Database Driver Class Initialized
INFO - 2023-08-18 17:15:04 --> Email Class Initialized
DEBUG - 2023-08-18 17:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:15:04 --> Controller Class Initialized
INFO - 2023-08-18 17:15:04 --> Model "Home_model" initialized
INFO - 2023-08-18 17:15:04 --> Helper loaded: form_helper
INFO - 2023-08-18 17:15:04 --> Form Validation Class Initialized
INFO - 2023-08-18 17:15:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 17:15:04 --> Final output sent to browser
DEBUG - 2023-08-18 17:15:04 --> Total execution time: 0.1519
INFO - 2023-08-18 17:15:04 --> Config Class Initialized
INFO - 2023-08-18 17:15:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:15:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:15:04 --> Utf8 Class Initialized
INFO - 2023-08-18 17:15:04 --> URI Class Initialized
INFO - 2023-08-18 17:15:04 --> Router Class Initialized
INFO - 2023-08-18 17:15:04 --> Output Class Initialized
INFO - 2023-08-18 17:15:04 --> Security Class Initialized
DEBUG - 2023-08-18 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:15:04 --> Input Class Initialized
INFO - 2023-08-18 17:15:04 --> Language Class Initialized
ERROR - 2023-08-18 17:15:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:15:04 --> Config Class Initialized
INFO - 2023-08-18 17:15:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:15:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:15:04 --> Utf8 Class Initialized
INFO - 2023-08-18 17:15:04 --> URI Class Initialized
INFO - 2023-08-18 17:15:04 --> Router Class Initialized
INFO - 2023-08-18 17:15:04 --> Output Class Initialized
INFO - 2023-08-18 17:15:04 --> Security Class Initialized
DEBUG - 2023-08-18 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:15:04 --> Input Class Initialized
INFO - 2023-08-18 17:15:04 --> Language Class Initialized
ERROR - 2023-08-18 17:15:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:15:05 --> Config Class Initialized
INFO - 2023-08-18 17:15:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:15:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:15:05 --> Utf8 Class Initialized
INFO - 2023-08-18 17:15:05 --> URI Class Initialized
INFO - 2023-08-18 17:15:05 --> Router Class Initialized
INFO - 2023-08-18 17:15:05 --> Output Class Initialized
INFO - 2023-08-18 17:15:05 --> Security Class Initialized
DEBUG - 2023-08-18 17:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:15:05 --> Input Class Initialized
INFO - 2023-08-18 17:15:05 --> Language Class Initialized
ERROR - 2023-08-18 17:15:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:15:05 --> Config Class Initialized
INFO - 2023-08-18 17:15:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:15:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:15:05 --> Utf8 Class Initialized
INFO - 2023-08-18 17:15:05 --> URI Class Initialized
INFO - 2023-08-18 17:15:05 --> Router Class Initialized
INFO - 2023-08-18 17:15:05 --> Output Class Initialized
INFO - 2023-08-18 17:15:05 --> Security Class Initialized
DEBUG - 2023-08-18 17:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:15:05 --> Input Class Initialized
INFO - 2023-08-18 17:15:05 --> Language Class Initialized
ERROR - 2023-08-18 17:15:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:15:10 --> Config Class Initialized
INFO - 2023-08-18 17:15:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:15:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:15:10 --> Utf8 Class Initialized
INFO - 2023-08-18 17:15:10 --> URI Class Initialized
INFO - 2023-08-18 17:15:10 --> Router Class Initialized
INFO - 2023-08-18 17:15:10 --> Output Class Initialized
INFO - 2023-08-18 17:15:10 --> Security Class Initialized
DEBUG - 2023-08-18 17:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:15:10 --> Input Class Initialized
INFO - 2023-08-18 17:15:10 --> Language Class Initialized
ERROR - 2023-08-18 17:15:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:15:10 --> Config Class Initialized
INFO - 2023-08-18 17:15:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:15:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:15:10 --> Utf8 Class Initialized
INFO - 2023-08-18 17:15:10 --> URI Class Initialized
INFO - 2023-08-18 17:15:10 --> Router Class Initialized
INFO - 2023-08-18 17:15:10 --> Output Class Initialized
INFO - 2023-08-18 17:15:10 --> Security Class Initialized
DEBUG - 2023-08-18 17:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:15:10 --> Input Class Initialized
INFO - 2023-08-18 17:15:10 --> Language Class Initialized
ERROR - 2023-08-18 17:15:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:15:10 --> Config Class Initialized
INFO - 2023-08-18 17:15:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:15:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:15:10 --> Utf8 Class Initialized
INFO - 2023-08-18 17:15:10 --> URI Class Initialized
INFO - 2023-08-18 17:15:10 --> Router Class Initialized
INFO - 2023-08-18 17:15:10 --> Output Class Initialized
INFO - 2023-08-18 17:15:10 --> Security Class Initialized
DEBUG - 2023-08-18 17:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:15:10 --> Input Class Initialized
INFO - 2023-08-18 17:15:10 --> Language Class Initialized
ERROR - 2023-08-18 17:15:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:15:10 --> Config Class Initialized
INFO - 2023-08-18 17:15:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:15:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:15:10 --> Utf8 Class Initialized
INFO - 2023-08-18 17:15:10 --> URI Class Initialized
INFO - 2023-08-18 17:15:10 --> Router Class Initialized
INFO - 2023-08-18 17:15:10 --> Output Class Initialized
INFO - 2023-08-18 17:15:10 --> Security Class Initialized
DEBUG - 2023-08-18 17:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:15:10 --> Input Class Initialized
INFO - 2023-08-18 17:15:10 --> Language Class Initialized
ERROR - 2023-08-18 17:15:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:16:07 --> Config Class Initialized
INFO - 2023-08-18 17:16:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:16:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:16:07 --> Utf8 Class Initialized
INFO - 2023-08-18 17:16:07 --> URI Class Initialized
INFO - 2023-08-18 17:16:07 --> Router Class Initialized
INFO - 2023-08-18 17:16:07 --> Output Class Initialized
INFO - 2023-08-18 17:16:07 --> Security Class Initialized
DEBUG - 2023-08-18 17:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:16:07 --> Input Class Initialized
INFO - 2023-08-18 17:16:07 --> Language Class Initialized
ERROR - 2023-08-18 17:16:07 --> 404 Page Not Found: Training-detail/index.html
INFO - 2023-08-18 17:16:09 --> Config Class Initialized
INFO - 2023-08-18 17:16:09 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:16:09 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:16:09 --> Utf8 Class Initialized
INFO - 2023-08-18 17:16:09 --> URI Class Initialized
INFO - 2023-08-18 17:16:09 --> Router Class Initialized
INFO - 2023-08-18 17:16:09 --> Output Class Initialized
INFO - 2023-08-18 17:16:09 --> Security Class Initialized
DEBUG - 2023-08-18 17:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:16:09 --> Input Class Initialized
INFO - 2023-08-18 17:16:09 --> Language Class Initialized
INFO - 2023-08-18 17:16:09 --> Loader Class Initialized
INFO - 2023-08-18 17:16:09 --> Helper loaded: url_helper
INFO - 2023-08-18 17:16:09 --> Helper loaded: file_helper
INFO - 2023-08-18 17:16:09 --> Database Driver Class Initialized
INFO - 2023-08-18 17:16:09 --> Email Class Initialized
DEBUG - 2023-08-18 17:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:16:09 --> Controller Class Initialized
INFO - 2023-08-18 17:16:09 --> Model "Home_model" initialized
INFO - 2023-08-18 17:16:09 --> Helper loaded: form_helper
INFO - 2023-08-18 17:16:09 --> Form Validation Class Initialized
INFO - 2023-08-18 17:16:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 17:16:09 --> Final output sent to browser
DEBUG - 2023-08-18 17:16:09 --> Total execution time: 0.0503
INFO - 2023-08-18 17:17:08 --> Config Class Initialized
INFO - 2023-08-18 17:17:08 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:17:08 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:17:08 --> Utf8 Class Initialized
INFO - 2023-08-18 17:17:08 --> URI Class Initialized
INFO - 2023-08-18 17:17:08 --> Router Class Initialized
INFO - 2023-08-18 17:17:08 --> Output Class Initialized
INFO - 2023-08-18 17:17:08 --> Security Class Initialized
DEBUG - 2023-08-18 17:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:17:08 --> Input Class Initialized
INFO - 2023-08-18 17:17:08 --> Language Class Initialized
INFO - 2023-08-18 17:17:08 --> Loader Class Initialized
INFO - 2023-08-18 17:17:08 --> Helper loaded: url_helper
INFO - 2023-08-18 17:17:08 --> Helper loaded: file_helper
INFO - 2023-08-18 17:17:08 --> Database Driver Class Initialized
INFO - 2023-08-18 17:17:08 --> Email Class Initialized
DEBUG - 2023-08-18 17:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:17:08 --> Controller Class Initialized
INFO - 2023-08-18 17:17:08 --> Model "User_model" initialized
INFO - 2023-08-18 17:17:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-18 17:17:08 --> Final output sent to browser
DEBUG - 2023-08-18 17:17:08 --> Total execution time: 0.4595
INFO - 2023-08-18 17:17:10 --> Config Class Initialized
INFO - 2023-08-18 17:17:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:17:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:17:10 --> Utf8 Class Initialized
INFO - 2023-08-18 17:17:10 --> URI Class Initialized
INFO - 2023-08-18 17:17:10 --> Router Class Initialized
INFO - 2023-08-18 17:17:10 --> Output Class Initialized
INFO - 2023-08-18 17:17:10 --> Security Class Initialized
DEBUG - 2023-08-18 17:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:17:10 --> Input Class Initialized
INFO - 2023-08-18 17:17:10 --> Language Class Initialized
ERROR - 2023-08-18 17:17:10 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-18 17:17:18 --> Config Class Initialized
INFO - 2023-08-18 17:17:18 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:17:18 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:17:18 --> Utf8 Class Initialized
INFO - 2023-08-18 17:17:18 --> URI Class Initialized
INFO - 2023-08-18 17:17:18 --> Router Class Initialized
INFO - 2023-08-18 17:17:18 --> Output Class Initialized
INFO - 2023-08-18 17:17:18 --> Security Class Initialized
DEBUG - 2023-08-18 17:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:17:18 --> Input Class Initialized
INFO - 2023-08-18 17:17:18 --> Language Class Initialized
INFO - 2023-08-18 17:17:18 --> Loader Class Initialized
INFO - 2023-08-18 17:17:18 --> Helper loaded: url_helper
INFO - 2023-08-18 17:17:18 --> Helper loaded: file_helper
INFO - 2023-08-18 17:17:18 --> Database Driver Class Initialized
INFO - 2023-08-18 17:17:18 --> Email Class Initialized
DEBUG - 2023-08-18 17:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:17:18 --> Controller Class Initialized
INFO - 2023-08-18 17:17:18 --> Model "User_model" initialized
INFO - 2023-08-18 17:17:18 --> Config Class Initialized
INFO - 2023-08-18 17:17:18 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:17:18 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:17:18 --> Utf8 Class Initialized
INFO - 2023-08-18 17:17:18 --> URI Class Initialized
INFO - 2023-08-18 17:17:18 --> Router Class Initialized
INFO - 2023-08-18 17:17:18 --> Output Class Initialized
INFO - 2023-08-18 17:17:18 --> Security Class Initialized
DEBUG - 2023-08-18 17:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:17:18 --> Input Class Initialized
INFO - 2023-08-18 17:17:18 --> Language Class Initialized
INFO - 2023-08-18 17:17:18 --> Loader Class Initialized
INFO - 2023-08-18 17:17:18 --> Helper loaded: url_helper
INFO - 2023-08-18 17:17:18 --> Helper loaded: file_helper
INFO - 2023-08-18 17:17:18 --> Database Driver Class Initialized
INFO - 2023-08-18 17:17:18 --> Email Class Initialized
DEBUG - 2023-08-18 17:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:17:18 --> Controller Class Initialized
INFO - 2023-08-18 17:17:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-18 17:17:18 --> Final output sent to browser
DEBUG - 2023-08-18 17:17:18 --> Total execution time: 0.0334
INFO - 2023-08-18 17:17:36 --> Config Class Initialized
INFO - 2023-08-18 17:17:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:17:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:17:36 --> Utf8 Class Initialized
INFO - 2023-08-18 17:17:36 --> URI Class Initialized
INFO - 2023-08-18 17:17:36 --> Router Class Initialized
INFO - 2023-08-18 17:17:36 --> Output Class Initialized
INFO - 2023-08-18 17:17:36 --> Security Class Initialized
DEBUG - 2023-08-18 17:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:17:36 --> Input Class Initialized
INFO - 2023-08-18 17:17:36 --> Language Class Initialized
INFO - 2023-08-18 17:17:36 --> Loader Class Initialized
INFO - 2023-08-18 17:17:36 --> Helper loaded: url_helper
INFO - 2023-08-18 17:17:36 --> Helper loaded: file_helper
INFO - 2023-08-18 17:17:36 --> Database Driver Class Initialized
INFO - 2023-08-18 17:17:36 --> Email Class Initialized
DEBUG - 2023-08-18 17:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:17:36 --> Controller Class Initialized
INFO - 2023-08-18 17:17:36 --> Model "Blog_model" initialized
INFO - 2023-08-18 17:17:36 --> Helper loaded: form_helper
INFO - 2023-08-18 17:17:36 --> Form Validation Class Initialized
INFO - 2023-08-18 17:17:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-18 17:17:36 --> Final output sent to browser
DEBUG - 2023-08-18 17:17:36 --> Total execution time: 0.1016
INFO - 2023-08-18 17:17:36 --> Config Class Initialized
INFO - 2023-08-18 17:17:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:17:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:17:36 --> Utf8 Class Initialized
INFO - 2023-08-18 17:17:36 --> URI Class Initialized
INFO - 2023-08-18 17:17:36 --> Router Class Initialized
INFO - 2023-08-18 17:17:36 --> Output Class Initialized
INFO - 2023-08-18 17:17:36 --> Security Class Initialized
DEBUG - 2023-08-18 17:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:17:36 --> Input Class Initialized
INFO - 2023-08-18 17:17:36 --> Language Class Initialized
ERROR - 2023-08-18 17:17:36 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-18 17:17:42 --> Config Class Initialized
INFO - 2023-08-18 17:17:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:17:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:17:42 --> Utf8 Class Initialized
INFO - 2023-08-18 17:17:42 --> URI Class Initialized
INFO - 2023-08-18 17:17:42 --> Router Class Initialized
INFO - 2023-08-18 17:17:42 --> Output Class Initialized
INFO - 2023-08-18 17:17:42 --> Security Class Initialized
DEBUG - 2023-08-18 17:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:17:42 --> Input Class Initialized
INFO - 2023-08-18 17:17:42 --> Language Class Initialized
INFO - 2023-08-18 17:17:42 --> Loader Class Initialized
INFO - 2023-08-18 17:17:42 --> Helper loaded: url_helper
INFO - 2023-08-18 17:17:42 --> Helper loaded: file_helper
INFO - 2023-08-18 17:17:42 --> Database Driver Class Initialized
INFO - 2023-08-18 17:17:42 --> Email Class Initialized
DEBUG - 2023-08-18 17:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:17:42 --> Controller Class Initialized
INFO - 2023-08-18 17:17:42 --> Model "Blog_model" initialized
INFO - 2023-08-18 17:17:42 --> Helper loaded: form_helper
INFO - 2023-08-18 17:17:42 --> Form Validation Class Initialized
INFO - 2023-08-18 17:17:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-08-18 17:17:42 --> Final output sent to browser
DEBUG - 2023-08-18 17:17:42 --> Total execution time: 0.0483
INFO - 2023-08-18 17:17:43 --> Config Class Initialized
INFO - 2023-08-18 17:17:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:17:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:17:43 --> Utf8 Class Initialized
INFO - 2023-08-18 17:17:43 --> URI Class Initialized
INFO - 2023-08-18 17:17:43 --> Router Class Initialized
INFO - 2023-08-18 17:17:43 --> Output Class Initialized
INFO - 2023-08-18 17:17:43 --> Security Class Initialized
DEBUG - 2023-08-18 17:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:17:43 --> Input Class Initialized
INFO - 2023-08-18 17:17:43 --> Language Class Initialized
ERROR - 2023-08-18 17:17:43 --> 404 Page Not Found: admin/Blog/images
INFO - 2023-08-18 17:17:47 --> Config Class Initialized
INFO - 2023-08-18 17:17:47 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:17:47 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:17:47 --> Utf8 Class Initialized
INFO - 2023-08-18 17:17:47 --> URI Class Initialized
INFO - 2023-08-18 17:17:47 --> Router Class Initialized
INFO - 2023-08-18 17:17:47 --> Output Class Initialized
INFO - 2023-08-18 17:17:47 --> Security Class Initialized
DEBUG - 2023-08-18 17:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:17:47 --> Input Class Initialized
INFO - 2023-08-18 17:17:47 --> Language Class Initialized
INFO - 2023-08-18 17:17:47 --> Loader Class Initialized
INFO - 2023-08-18 17:17:47 --> Helper loaded: url_helper
INFO - 2023-08-18 17:17:47 --> Helper loaded: file_helper
INFO - 2023-08-18 17:17:47 --> Database Driver Class Initialized
INFO - 2023-08-18 17:17:47 --> Email Class Initialized
DEBUG - 2023-08-18 17:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:17:47 --> Controller Class Initialized
INFO - 2023-08-18 17:17:47 --> Model "Gallery_model" initialized
INFO - 2023-08-18 17:17:47 --> Helper loaded: form_helper
INFO - 2023-08-18 17:17:47 --> Form Validation Class Initialized
INFO - 2023-08-18 17:17:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/gallery_list.php
INFO - 2023-08-18 17:17:47 --> Final output sent to browser
DEBUG - 2023-08-18 17:17:47 --> Total execution time: 0.1225
INFO - 2023-08-18 17:17:52 --> Config Class Initialized
INFO - 2023-08-18 17:17:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:17:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:17:52 --> Utf8 Class Initialized
INFO - 2023-08-18 17:17:52 --> URI Class Initialized
INFO - 2023-08-18 17:17:52 --> Router Class Initialized
INFO - 2023-08-18 17:17:52 --> Output Class Initialized
INFO - 2023-08-18 17:17:52 --> Security Class Initialized
DEBUG - 2023-08-18 17:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:17:52 --> Input Class Initialized
INFO - 2023-08-18 17:17:52 --> Language Class Initialized
INFO - 2023-08-18 17:17:52 --> Loader Class Initialized
INFO - 2023-08-18 17:17:52 --> Helper loaded: url_helper
INFO - 2023-08-18 17:17:52 --> Helper loaded: file_helper
INFO - 2023-08-18 17:17:52 --> Database Driver Class Initialized
INFO - 2023-08-18 17:17:52 --> Email Class Initialized
DEBUG - 2023-08-18 17:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:17:52 --> Controller Class Initialized
INFO - 2023-08-18 17:17:52 --> Model "Services_model" initialized
INFO - 2023-08-18 17:17:52 --> Helper loaded: form_helper
INFO - 2023-08-18 17:17:52 --> Form Validation Class Initialized
INFO - 2023-08-18 17:17:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-18 17:17:52 --> Final output sent to browser
DEBUG - 2023-08-18 17:17:52 --> Total execution time: 0.1350
INFO - 2023-08-18 17:17:52 --> Config Class Initialized
INFO - 2023-08-18 17:17:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:17:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:17:52 --> Utf8 Class Initialized
INFO - 2023-08-18 17:17:52 --> URI Class Initialized
INFO - 2023-08-18 17:17:52 --> Router Class Initialized
INFO - 2023-08-18 17:17:52 --> Output Class Initialized
INFO - 2023-08-18 17:17:52 --> Security Class Initialized
DEBUG - 2023-08-18 17:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:17:52 --> Input Class Initialized
INFO - 2023-08-18 17:17:52 --> Language Class Initialized
ERROR - 2023-08-18 17:17:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:17:55 --> Config Class Initialized
INFO - 2023-08-18 17:17:55 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:17:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:17:55 --> Utf8 Class Initialized
INFO - 2023-08-18 17:17:55 --> URI Class Initialized
INFO - 2023-08-18 17:17:55 --> Router Class Initialized
INFO - 2023-08-18 17:17:55 --> Output Class Initialized
INFO - 2023-08-18 17:17:55 --> Security Class Initialized
DEBUG - 2023-08-18 17:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:17:55 --> Input Class Initialized
INFO - 2023-08-18 17:17:55 --> Language Class Initialized
INFO - 2023-08-18 17:17:55 --> Loader Class Initialized
INFO - 2023-08-18 17:17:55 --> Helper loaded: url_helper
INFO - 2023-08-18 17:17:55 --> Helper loaded: file_helper
INFO - 2023-08-18 17:17:55 --> Database Driver Class Initialized
INFO - 2023-08-18 17:17:55 --> Email Class Initialized
DEBUG - 2023-08-18 17:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:17:55 --> Controller Class Initialized
INFO - 2023-08-18 17:17:55 --> Model "Training_model" initialized
INFO - 2023-08-18 17:17:55 --> Helper loaded: form_helper
INFO - 2023-08-18 17:17:55 --> Form Validation Class Initialized
INFO - 2023-08-18 17:17:55 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-18 17:17:55 --> Final output sent to browser
DEBUG - 2023-08-18 17:17:55 --> Total execution time: 0.0516
INFO - 2023-08-18 17:17:59 --> Config Class Initialized
INFO - 2023-08-18 17:17:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:17:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:17:59 --> Utf8 Class Initialized
INFO - 2023-08-18 17:17:59 --> URI Class Initialized
INFO - 2023-08-18 17:17:59 --> Router Class Initialized
INFO - 2023-08-18 17:17:59 --> Output Class Initialized
INFO - 2023-08-18 17:17:59 --> Security Class Initialized
DEBUG - 2023-08-18 17:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:17:59 --> Input Class Initialized
INFO - 2023-08-18 17:17:59 --> Language Class Initialized
INFO - 2023-08-18 17:17:59 --> Loader Class Initialized
INFO - 2023-08-18 17:17:59 --> Helper loaded: url_helper
INFO - 2023-08-18 17:17:59 --> Helper loaded: file_helper
INFO - 2023-08-18 17:17:59 --> Database Driver Class Initialized
INFO - 2023-08-18 17:17:59 --> Email Class Initialized
DEBUG - 2023-08-18 17:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:17:59 --> Controller Class Initialized
INFO - 2023-08-18 17:17:59 --> Model "Training_model" initialized
INFO - 2023-08-18 17:17:59 --> Helper loaded: form_helper
INFO - 2023-08-18 17:17:59 --> Form Validation Class Initialized
INFO - 2023-08-18 17:17:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-18 17:17:59 --> Final output sent to browser
DEBUG - 2023-08-18 17:17:59 --> Total execution time: 0.0616
INFO - 2023-08-18 17:18:03 --> Config Class Initialized
INFO - 2023-08-18 17:18:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:18:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:18:03 --> Utf8 Class Initialized
INFO - 2023-08-18 17:18:03 --> URI Class Initialized
INFO - 2023-08-18 17:18:03 --> Router Class Initialized
INFO - 2023-08-18 17:18:03 --> Output Class Initialized
INFO - 2023-08-18 17:18:03 --> Security Class Initialized
DEBUG - 2023-08-18 17:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:18:03 --> Input Class Initialized
INFO - 2023-08-18 17:18:03 --> Language Class Initialized
INFO - 2023-08-18 17:18:03 --> Loader Class Initialized
INFO - 2023-08-18 17:18:03 --> Helper loaded: url_helper
INFO - 2023-08-18 17:18:03 --> Helper loaded: file_helper
INFO - 2023-08-18 17:18:03 --> Database Driver Class Initialized
INFO - 2023-08-18 17:18:03 --> Email Class Initialized
DEBUG - 2023-08-18 17:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:18:03 --> Controller Class Initialized
INFO - 2023-08-18 17:18:03 --> Model "Key_highlights_model" initialized
INFO - 2023-08-18 17:18:03 --> Helper loaded: form_helper
INFO - 2023-08-18 17:18:03 --> Form Validation Class Initialized
INFO - 2023-08-18 17:18:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/key_highlights_list.php
INFO - 2023-08-18 17:18:03 --> Final output sent to browser
DEBUG - 2023-08-18 17:18:03 --> Total execution time: 0.1323
INFO - 2023-08-18 17:18:03 --> Config Class Initialized
INFO - 2023-08-18 17:18:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:18:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:18:03 --> Utf8 Class Initialized
INFO - 2023-08-18 17:18:03 --> URI Class Initialized
INFO - 2023-08-18 17:18:03 --> Router Class Initialized
INFO - 2023-08-18 17:18:03 --> Output Class Initialized
INFO - 2023-08-18 17:18:03 --> Security Class Initialized
DEBUG - 2023-08-18 17:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:18:03 --> Input Class Initialized
INFO - 2023-08-18 17:18:03 --> Language Class Initialized
ERROR - 2023-08-18 17:18:03 --> 404 Page Not Found: admin/Key_highlights/images
INFO - 2023-08-18 17:18:05 --> Config Class Initialized
INFO - 2023-08-18 17:18:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:18:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:18:05 --> Utf8 Class Initialized
INFO - 2023-08-18 17:18:05 --> URI Class Initialized
INFO - 2023-08-18 17:18:05 --> Router Class Initialized
INFO - 2023-08-18 17:18:05 --> Output Class Initialized
INFO - 2023-08-18 17:18:05 --> Security Class Initialized
DEBUG - 2023-08-18 17:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:18:05 --> Input Class Initialized
INFO - 2023-08-18 17:18:05 --> Language Class Initialized
INFO - 2023-08-18 17:18:05 --> Loader Class Initialized
INFO - 2023-08-18 17:18:05 --> Helper loaded: url_helper
INFO - 2023-08-18 17:18:05 --> Helper loaded: file_helper
INFO - 2023-08-18 17:18:05 --> Database Driver Class Initialized
INFO - 2023-08-18 17:18:05 --> Email Class Initialized
DEBUG - 2023-08-18 17:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:18:05 --> Controller Class Initialized
INFO - 2023-08-18 17:18:05 --> Model "Key_highlights_model" initialized
INFO - 2023-08-18 17:18:05 --> Helper loaded: form_helper
INFO - 2023-08-18 17:18:05 --> Form Validation Class Initialized
INFO - 2023-08-18 17:18:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/key_highlights_create.php
INFO - 2023-08-18 17:18:05 --> Final output sent to browser
DEBUG - 2023-08-18 17:18:05 --> Total execution time: 0.0477
INFO - 2023-08-18 17:18:06 --> Config Class Initialized
INFO - 2023-08-18 17:18:06 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:18:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:18:06 --> Utf8 Class Initialized
INFO - 2023-08-18 17:18:06 --> URI Class Initialized
INFO - 2023-08-18 17:18:06 --> Router Class Initialized
INFO - 2023-08-18 17:18:06 --> Output Class Initialized
INFO - 2023-08-18 17:18:06 --> Security Class Initialized
DEBUG - 2023-08-18 17:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:18:06 --> Input Class Initialized
INFO - 2023-08-18 17:18:06 --> Language Class Initialized
ERROR - 2023-08-18 17:18:06 --> 404 Page Not Found: admin/Key_highlights/add
INFO - 2023-08-18 17:18:20 --> Config Class Initialized
INFO - 2023-08-18 17:18:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:18:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:18:20 --> Utf8 Class Initialized
INFO - 2023-08-18 17:18:20 --> URI Class Initialized
INFO - 2023-08-18 17:18:20 --> Router Class Initialized
INFO - 2023-08-18 17:18:20 --> Output Class Initialized
INFO - 2023-08-18 17:18:20 --> Security Class Initialized
DEBUG - 2023-08-18 17:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:18:20 --> Input Class Initialized
INFO - 2023-08-18 17:18:20 --> Language Class Initialized
INFO - 2023-08-18 17:18:20 --> Loader Class Initialized
INFO - 2023-08-18 17:18:20 --> Helper loaded: url_helper
INFO - 2023-08-18 17:18:20 --> Helper loaded: file_helper
INFO - 2023-08-18 17:18:20 --> Database Driver Class Initialized
INFO - 2023-08-18 17:18:20 --> Email Class Initialized
DEBUG - 2023-08-18 17:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:18:20 --> Controller Class Initialized
INFO - 2023-08-18 17:18:20 --> Model "Key_highlights_model" initialized
INFO - 2023-08-18 17:18:20 --> Helper loaded: form_helper
INFO - 2023-08-18 17:18:20 --> Form Validation Class Initialized
INFO - 2023-08-18 17:18:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:18:20 --> Config Class Initialized
INFO - 2023-08-18 17:18:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:18:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:18:20 --> Utf8 Class Initialized
INFO - 2023-08-18 17:18:20 --> URI Class Initialized
INFO - 2023-08-18 17:18:20 --> Router Class Initialized
INFO - 2023-08-18 17:18:20 --> Output Class Initialized
INFO - 2023-08-18 17:18:20 --> Security Class Initialized
DEBUG - 2023-08-18 17:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:18:20 --> Input Class Initialized
INFO - 2023-08-18 17:18:20 --> Language Class Initialized
INFO - 2023-08-18 17:18:20 --> Loader Class Initialized
INFO - 2023-08-18 17:18:20 --> Helper loaded: url_helper
INFO - 2023-08-18 17:18:20 --> Helper loaded: file_helper
INFO - 2023-08-18 17:18:20 --> Database Driver Class Initialized
INFO - 2023-08-18 17:18:20 --> Email Class Initialized
DEBUG - 2023-08-18 17:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:18:20 --> Controller Class Initialized
INFO - 2023-08-18 17:18:20 --> Model "Key_highlights_model" initialized
INFO - 2023-08-18 17:18:20 --> Helper loaded: form_helper
INFO - 2023-08-18 17:18:20 --> Form Validation Class Initialized
INFO - 2023-08-18 17:18:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/key_highlights_list.php
INFO - 2023-08-18 17:18:20 --> Final output sent to browser
DEBUG - 2023-08-18 17:18:20 --> Total execution time: 0.0845
INFO - 2023-08-18 17:18:22 --> Config Class Initialized
INFO - 2023-08-18 17:18:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:18:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:18:22 --> Utf8 Class Initialized
INFO - 2023-08-18 17:18:22 --> URI Class Initialized
INFO - 2023-08-18 17:18:22 --> Router Class Initialized
INFO - 2023-08-18 17:18:22 --> Output Class Initialized
INFO - 2023-08-18 17:18:22 --> Security Class Initialized
DEBUG - 2023-08-18 17:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:18:22 --> Input Class Initialized
INFO - 2023-08-18 17:18:22 --> Language Class Initialized
INFO - 2023-08-18 17:18:22 --> Loader Class Initialized
INFO - 2023-08-18 17:18:22 --> Helper loaded: url_helper
INFO - 2023-08-18 17:18:22 --> Helper loaded: file_helper
INFO - 2023-08-18 17:18:22 --> Database Driver Class Initialized
INFO - 2023-08-18 17:18:22 --> Email Class Initialized
DEBUG - 2023-08-18 17:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:18:22 --> Controller Class Initialized
INFO - 2023-08-18 17:18:22 --> Model "Key_highlights_model" initialized
INFO - 2023-08-18 17:18:22 --> Helper loaded: form_helper
INFO - 2023-08-18 17:18:22 --> Form Validation Class Initialized
INFO - 2023-08-18 17:18:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/key_highlights_create.php
INFO - 2023-08-18 17:18:22 --> Final output sent to browser
DEBUG - 2023-08-18 17:18:22 --> Total execution time: 0.0512
INFO - 2023-08-18 17:18:31 --> Config Class Initialized
INFO - 2023-08-18 17:18:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:18:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:18:31 --> Utf8 Class Initialized
INFO - 2023-08-18 17:18:31 --> URI Class Initialized
INFO - 2023-08-18 17:18:31 --> Router Class Initialized
INFO - 2023-08-18 17:18:31 --> Output Class Initialized
INFO - 2023-08-18 17:18:31 --> Security Class Initialized
DEBUG - 2023-08-18 17:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:18:31 --> Input Class Initialized
INFO - 2023-08-18 17:18:31 --> Language Class Initialized
INFO - 2023-08-18 17:18:31 --> Loader Class Initialized
INFO - 2023-08-18 17:18:31 --> Helper loaded: url_helper
INFO - 2023-08-18 17:18:31 --> Helper loaded: file_helper
INFO - 2023-08-18 17:18:31 --> Database Driver Class Initialized
INFO - 2023-08-18 17:18:32 --> Email Class Initialized
DEBUG - 2023-08-18 17:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:18:32 --> Controller Class Initialized
INFO - 2023-08-18 17:18:32 --> Model "Key_highlights_model" initialized
INFO - 2023-08-18 17:18:32 --> Helper loaded: form_helper
INFO - 2023-08-18 17:18:32 --> Form Validation Class Initialized
INFO - 2023-08-18 17:18:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:18:32 --> Config Class Initialized
INFO - 2023-08-18 17:18:32 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:18:32 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:18:32 --> Utf8 Class Initialized
INFO - 2023-08-18 17:18:32 --> URI Class Initialized
INFO - 2023-08-18 17:18:32 --> Router Class Initialized
INFO - 2023-08-18 17:18:32 --> Output Class Initialized
INFO - 2023-08-18 17:18:32 --> Security Class Initialized
DEBUG - 2023-08-18 17:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:18:32 --> Input Class Initialized
INFO - 2023-08-18 17:18:32 --> Language Class Initialized
INFO - 2023-08-18 17:18:32 --> Loader Class Initialized
INFO - 2023-08-18 17:18:32 --> Helper loaded: url_helper
INFO - 2023-08-18 17:18:32 --> Helper loaded: file_helper
INFO - 2023-08-18 17:18:32 --> Database Driver Class Initialized
INFO - 2023-08-18 17:18:32 --> Email Class Initialized
DEBUG - 2023-08-18 17:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:18:32 --> Controller Class Initialized
INFO - 2023-08-18 17:18:32 --> Model "Key_highlights_model" initialized
INFO - 2023-08-18 17:18:32 --> Helper loaded: form_helper
INFO - 2023-08-18 17:18:32 --> Form Validation Class Initialized
INFO - 2023-08-18 17:18:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/key_highlights_list.php
INFO - 2023-08-18 17:18:32 --> Final output sent to browser
DEBUG - 2023-08-18 17:18:32 --> Total execution time: 0.0747
INFO - 2023-08-18 17:18:35 --> Config Class Initialized
INFO - 2023-08-18 17:18:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:18:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:18:35 --> Utf8 Class Initialized
INFO - 2023-08-18 17:18:35 --> URI Class Initialized
INFO - 2023-08-18 17:18:35 --> Router Class Initialized
INFO - 2023-08-18 17:18:35 --> Output Class Initialized
INFO - 2023-08-18 17:18:35 --> Security Class Initialized
DEBUG - 2023-08-18 17:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:18:35 --> Input Class Initialized
INFO - 2023-08-18 17:18:35 --> Language Class Initialized
INFO - 2023-08-18 17:18:35 --> Loader Class Initialized
INFO - 2023-08-18 17:18:35 --> Helper loaded: url_helper
INFO - 2023-08-18 17:18:35 --> Helper loaded: file_helper
INFO - 2023-08-18 17:18:35 --> Database Driver Class Initialized
INFO - 2023-08-18 17:18:35 --> Email Class Initialized
DEBUG - 2023-08-18 17:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:18:35 --> Controller Class Initialized
INFO - 2023-08-18 17:18:35 --> Model "Key_highlights_model" initialized
INFO - 2023-08-18 17:18:35 --> Helper loaded: form_helper
INFO - 2023-08-18 17:18:35 --> Form Validation Class Initialized
INFO - 2023-08-18 17:18:35 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/key_highlights_create.php
INFO - 2023-08-18 17:18:35 --> Final output sent to browser
DEBUG - 2023-08-18 17:18:35 --> Total execution time: 0.0508
INFO - 2023-08-18 17:18:48 --> Config Class Initialized
INFO - 2023-08-18 17:18:48 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:18:48 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:18:48 --> Utf8 Class Initialized
INFO - 2023-08-18 17:18:48 --> URI Class Initialized
INFO - 2023-08-18 17:18:48 --> Router Class Initialized
INFO - 2023-08-18 17:18:48 --> Output Class Initialized
INFO - 2023-08-18 17:18:48 --> Security Class Initialized
DEBUG - 2023-08-18 17:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:18:48 --> Input Class Initialized
INFO - 2023-08-18 17:18:48 --> Language Class Initialized
INFO - 2023-08-18 17:18:48 --> Loader Class Initialized
INFO - 2023-08-18 17:18:48 --> Helper loaded: url_helper
INFO - 2023-08-18 17:18:48 --> Helper loaded: file_helper
INFO - 2023-08-18 17:18:48 --> Database Driver Class Initialized
INFO - 2023-08-18 17:18:48 --> Email Class Initialized
DEBUG - 2023-08-18 17:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:18:48 --> Controller Class Initialized
INFO - 2023-08-18 17:18:48 --> Model "Key_highlights_model" initialized
INFO - 2023-08-18 17:18:48 --> Helper loaded: form_helper
INFO - 2023-08-18 17:18:48 --> Form Validation Class Initialized
INFO - 2023-08-18 17:18:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:18:48 --> Config Class Initialized
INFO - 2023-08-18 17:18:48 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:18:48 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:18:48 --> Utf8 Class Initialized
INFO - 2023-08-18 17:18:48 --> URI Class Initialized
INFO - 2023-08-18 17:18:48 --> Router Class Initialized
INFO - 2023-08-18 17:18:48 --> Output Class Initialized
INFO - 2023-08-18 17:18:48 --> Security Class Initialized
DEBUG - 2023-08-18 17:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:18:48 --> Input Class Initialized
INFO - 2023-08-18 17:18:48 --> Language Class Initialized
INFO - 2023-08-18 17:18:48 --> Loader Class Initialized
INFO - 2023-08-18 17:18:48 --> Helper loaded: url_helper
INFO - 2023-08-18 17:18:48 --> Helper loaded: file_helper
INFO - 2023-08-18 17:18:48 --> Database Driver Class Initialized
INFO - 2023-08-18 17:18:48 --> Email Class Initialized
DEBUG - 2023-08-18 17:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:18:48 --> Controller Class Initialized
INFO - 2023-08-18 17:18:48 --> Model "Key_highlights_model" initialized
INFO - 2023-08-18 17:18:48 --> Helper loaded: form_helper
INFO - 2023-08-18 17:18:48 --> Form Validation Class Initialized
INFO - 2023-08-18 17:18:48 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/key_highlights_list.php
INFO - 2023-08-18 17:18:48 --> Final output sent to browser
DEBUG - 2023-08-18 17:18:48 --> Total execution time: 0.2683
INFO - 2023-08-18 17:19:02 --> Config Class Initialized
INFO - 2023-08-18 17:19:02 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:19:02 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:19:02 --> Utf8 Class Initialized
INFO - 2023-08-18 17:19:02 --> URI Class Initialized
INFO - 2023-08-18 17:19:02 --> Router Class Initialized
INFO - 2023-08-18 17:19:02 --> Output Class Initialized
INFO - 2023-08-18 17:19:02 --> Security Class Initialized
DEBUG - 2023-08-18 17:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:19:02 --> Input Class Initialized
INFO - 2023-08-18 17:19:02 --> Language Class Initialized
INFO - 2023-08-18 17:19:02 --> Loader Class Initialized
INFO - 2023-08-18 17:19:02 --> Helper loaded: url_helper
INFO - 2023-08-18 17:19:02 --> Helper loaded: file_helper
INFO - 2023-08-18 17:19:02 --> Database Driver Class Initialized
INFO - 2023-08-18 17:19:02 --> Email Class Initialized
DEBUG - 2023-08-18 17:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:19:02 --> Controller Class Initialized
INFO - 2023-08-18 17:19:02 --> Model "Key_highlights_model" initialized
INFO - 2023-08-18 17:19:02 --> Helper loaded: form_helper
INFO - 2023-08-18 17:19:03 --> Form Validation Class Initialized
INFO - 2023-08-18 17:19:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/key_highlights_list.php
INFO - 2023-08-18 17:19:03 --> Final output sent to browser
DEBUG - 2023-08-18 17:19:03 --> Total execution time: 1.1794
INFO - 2023-08-18 17:19:45 --> Config Class Initialized
INFO - 2023-08-18 17:19:45 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:19:45 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:19:45 --> Utf8 Class Initialized
INFO - 2023-08-18 17:19:45 --> URI Class Initialized
INFO - 2023-08-18 17:19:45 --> Router Class Initialized
INFO - 2023-08-18 17:19:45 --> Output Class Initialized
INFO - 2023-08-18 17:19:45 --> Security Class Initialized
DEBUG - 2023-08-18 17:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:19:45 --> Input Class Initialized
INFO - 2023-08-18 17:19:45 --> Language Class Initialized
INFO - 2023-08-18 17:19:45 --> Loader Class Initialized
INFO - 2023-08-18 17:19:45 --> Helper loaded: url_helper
INFO - 2023-08-18 17:19:45 --> Helper loaded: file_helper
INFO - 2023-08-18 17:19:45 --> Database Driver Class Initialized
INFO - 2023-08-18 17:19:45 --> Email Class Initialized
DEBUG - 2023-08-18 17:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:19:45 --> Controller Class Initialized
INFO - 2023-08-18 17:19:45 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:19:45 --> Helper loaded: form_helper
INFO - 2023-08-18 17:19:45 --> Form Validation Class Initialized
INFO - 2023-08-18 17:19:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 17:19:45 --> Final output sent to browser
DEBUG - 2023-08-18 17:19:45 --> Total execution time: 0.0997
INFO - 2023-08-18 17:19:53 --> Config Class Initialized
INFO - 2023-08-18 17:19:53 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:19:53 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:19:53 --> Utf8 Class Initialized
INFO - 2023-08-18 17:19:53 --> URI Class Initialized
INFO - 2023-08-18 17:19:53 --> Router Class Initialized
INFO - 2023-08-18 17:19:53 --> Output Class Initialized
INFO - 2023-08-18 17:19:53 --> Security Class Initialized
DEBUG - 2023-08-18 17:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:19:53 --> Input Class Initialized
INFO - 2023-08-18 17:19:53 --> Language Class Initialized
INFO - 2023-08-18 17:19:53 --> Loader Class Initialized
INFO - 2023-08-18 17:19:53 --> Helper loaded: url_helper
INFO - 2023-08-18 17:19:53 --> Helper loaded: file_helper
INFO - 2023-08-18 17:19:53 --> Database Driver Class Initialized
INFO - 2023-08-18 17:19:53 --> Email Class Initialized
DEBUG - 2023-08-18 17:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:19:53 --> Controller Class Initialized
INFO - 2023-08-18 17:19:53 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:19:53 --> Helper loaded: form_helper
INFO - 2023-08-18 17:19:53 --> Form Validation Class Initialized
INFO - 2023-08-18 17:19:53 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_create.php
INFO - 2023-08-18 17:19:53 --> Final output sent to browser
DEBUG - 2023-08-18 17:19:53 --> Total execution time: 0.0573
INFO - 2023-08-18 17:19:54 --> Config Class Initialized
INFO - 2023-08-18 17:19:54 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:19:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:19:54 --> Utf8 Class Initialized
INFO - 2023-08-18 17:19:54 --> URI Class Initialized
INFO - 2023-08-18 17:19:54 --> Router Class Initialized
INFO - 2023-08-18 17:19:54 --> Output Class Initialized
INFO - 2023-08-18 17:19:54 --> Security Class Initialized
DEBUG - 2023-08-18 17:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:19:54 --> Input Class Initialized
INFO - 2023-08-18 17:19:54 --> Language Class Initialized
ERROR - 2023-08-18 17:19:54 --> 404 Page Not Found: admin/Certification_courses/images
INFO - 2023-08-18 17:20:49 --> Config Class Initialized
INFO - 2023-08-18 17:20:49 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:20:49 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:20:49 --> Utf8 Class Initialized
INFO - 2023-08-18 17:20:49 --> URI Class Initialized
INFO - 2023-08-18 17:20:49 --> Router Class Initialized
INFO - 2023-08-18 17:20:49 --> Output Class Initialized
INFO - 2023-08-18 17:20:49 --> Security Class Initialized
DEBUG - 2023-08-18 17:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:20:49 --> Input Class Initialized
INFO - 2023-08-18 17:20:49 --> Language Class Initialized
INFO - 2023-08-18 17:20:49 --> Loader Class Initialized
INFO - 2023-08-18 17:20:49 --> Helper loaded: url_helper
INFO - 2023-08-18 17:20:49 --> Helper loaded: file_helper
INFO - 2023-08-18 17:20:49 --> Database Driver Class Initialized
INFO - 2023-08-18 17:20:49 --> Email Class Initialized
DEBUG - 2023-08-18 17:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:20:49 --> Controller Class Initialized
INFO - 2023-08-18 17:20:49 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:20:49 --> Helper loaded: form_helper
INFO - 2023-08-18 17:20:49 --> Form Validation Class Initialized
INFO - 2023-08-18 17:20:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:20:49 --> Config Class Initialized
INFO - 2023-08-18 17:20:49 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:20:49 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:20:49 --> Utf8 Class Initialized
INFO - 2023-08-18 17:20:49 --> URI Class Initialized
INFO - 2023-08-18 17:20:49 --> Router Class Initialized
INFO - 2023-08-18 17:20:49 --> Output Class Initialized
INFO - 2023-08-18 17:20:49 --> Security Class Initialized
DEBUG - 2023-08-18 17:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:20:49 --> Input Class Initialized
INFO - 2023-08-18 17:20:49 --> Language Class Initialized
INFO - 2023-08-18 17:20:49 --> Loader Class Initialized
INFO - 2023-08-18 17:20:49 --> Helper loaded: url_helper
INFO - 2023-08-18 17:20:49 --> Helper loaded: file_helper
INFO - 2023-08-18 17:20:49 --> Database Driver Class Initialized
INFO - 2023-08-18 17:20:49 --> Email Class Initialized
DEBUG - 2023-08-18 17:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:20:49 --> Controller Class Initialized
INFO - 2023-08-18 17:20:49 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:20:49 --> Helper loaded: form_helper
INFO - 2023-08-18 17:20:49 --> Form Validation Class Initialized
ERROR - 2023-08-18 17:20:49 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\dw\application\views\admin\certification_courses_list.php 76
ERROR - 2023-08-18 17:20:49 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\dw\application\views\admin\certification_courses_list.php 78
INFO - 2023-08-18 17:20:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 17:20:49 --> Final output sent to browser
DEBUG - 2023-08-18 17:20:49 --> Total execution time: 0.1223
INFO - 2023-08-18 17:22:59 --> Config Class Initialized
INFO - 2023-08-18 17:22:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:22:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:22:59 --> Utf8 Class Initialized
INFO - 2023-08-18 17:22:59 --> URI Class Initialized
INFO - 2023-08-18 17:22:59 --> Router Class Initialized
INFO - 2023-08-18 17:22:59 --> Output Class Initialized
INFO - 2023-08-18 17:22:59 --> Security Class Initialized
DEBUG - 2023-08-18 17:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:22:59 --> Input Class Initialized
INFO - 2023-08-18 17:22:59 --> Language Class Initialized
INFO - 2023-08-18 17:22:59 --> Loader Class Initialized
INFO - 2023-08-18 17:22:59 --> Helper loaded: url_helper
INFO - 2023-08-18 17:22:59 --> Helper loaded: file_helper
INFO - 2023-08-18 17:22:59 --> Database Driver Class Initialized
INFO - 2023-08-18 17:22:59 --> Email Class Initialized
DEBUG - 2023-08-18 17:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:22:59 --> Controller Class Initialized
INFO - 2023-08-18 17:22:59 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:22:59 --> Helper loaded: form_helper
INFO - 2023-08-18 17:22:59 --> Form Validation Class Initialized
INFO - 2023-08-18 17:22:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 17:22:59 --> Final output sent to browser
DEBUG - 2023-08-18 17:22:59 --> Total execution time: 0.0782
INFO - 2023-08-18 17:23:03 --> Config Class Initialized
INFO - 2023-08-18 17:23:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:23:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:23:03 --> Utf8 Class Initialized
INFO - 2023-08-18 17:23:03 --> URI Class Initialized
INFO - 2023-08-18 17:23:03 --> Router Class Initialized
INFO - 2023-08-18 17:23:03 --> Output Class Initialized
INFO - 2023-08-18 17:23:03 --> Security Class Initialized
DEBUG - 2023-08-18 17:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:23:03 --> Input Class Initialized
INFO - 2023-08-18 17:23:03 --> Language Class Initialized
INFO - 2023-08-18 17:23:03 --> Loader Class Initialized
INFO - 2023-08-18 17:23:03 --> Helper loaded: url_helper
INFO - 2023-08-18 17:23:03 --> Helper loaded: file_helper
INFO - 2023-08-18 17:23:03 --> Database Driver Class Initialized
INFO - 2023-08-18 17:23:03 --> Email Class Initialized
DEBUG - 2023-08-18 17:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:23:03 --> Controller Class Initialized
INFO - 2023-08-18 17:23:03 --> Model "Services_model" initialized
INFO - 2023-08-18 17:23:03 --> Helper loaded: form_helper
INFO - 2023-08-18 17:23:03 --> Form Validation Class Initialized
INFO - 2023-08-18 17:23:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-18 17:23:03 --> Final output sent to browser
DEBUG - 2023-08-18 17:23:03 --> Total execution time: 0.0532
INFO - 2023-08-18 17:23:04 --> Config Class Initialized
INFO - 2023-08-18 17:23:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:23:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:23:04 --> Utf8 Class Initialized
INFO - 2023-08-18 17:23:04 --> URI Class Initialized
INFO - 2023-08-18 17:23:04 --> Router Class Initialized
INFO - 2023-08-18 17:23:04 --> Output Class Initialized
INFO - 2023-08-18 17:23:04 --> Security Class Initialized
DEBUG - 2023-08-18 17:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:23:04 --> Input Class Initialized
INFO - 2023-08-18 17:23:04 --> Language Class Initialized
ERROR - 2023-08-18 17:23:04 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-18 17:23:16 --> Config Class Initialized
INFO - 2023-08-18 17:23:16 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:23:16 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:23:16 --> Utf8 Class Initialized
INFO - 2023-08-18 17:23:16 --> URI Class Initialized
INFO - 2023-08-18 17:23:16 --> Router Class Initialized
INFO - 2023-08-18 17:23:16 --> Output Class Initialized
INFO - 2023-08-18 17:23:16 --> Security Class Initialized
DEBUG - 2023-08-18 17:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:23:16 --> Input Class Initialized
INFO - 2023-08-18 17:23:16 --> Language Class Initialized
INFO - 2023-08-18 17:23:16 --> Loader Class Initialized
INFO - 2023-08-18 17:23:16 --> Helper loaded: url_helper
INFO - 2023-08-18 17:23:16 --> Helper loaded: file_helper
INFO - 2023-08-18 17:23:16 --> Database Driver Class Initialized
INFO - 2023-08-18 17:23:16 --> Email Class Initialized
DEBUG - 2023-08-18 17:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:23:16 --> Controller Class Initialized
INFO - 2023-08-18 17:23:16 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:23:16 --> Helper loaded: form_helper
INFO - 2023-08-18 17:23:16 --> Form Validation Class Initialized
INFO - 2023-08-18 17:23:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 17:23:16 --> Final output sent to browser
DEBUG - 2023-08-18 17:23:16 --> Total execution time: 0.0861
INFO - 2023-08-18 17:23:21 --> Config Class Initialized
INFO - 2023-08-18 17:23:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:23:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:23:21 --> Utf8 Class Initialized
INFO - 2023-08-18 17:23:21 --> URI Class Initialized
INFO - 2023-08-18 17:23:21 --> Router Class Initialized
INFO - 2023-08-18 17:23:21 --> Output Class Initialized
INFO - 2023-08-18 17:23:21 --> Security Class Initialized
DEBUG - 2023-08-18 17:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:23:21 --> Input Class Initialized
INFO - 2023-08-18 17:23:21 --> Language Class Initialized
INFO - 2023-08-18 17:23:21 --> Loader Class Initialized
INFO - 2023-08-18 17:23:21 --> Helper loaded: url_helper
INFO - 2023-08-18 17:23:21 --> Helper loaded: file_helper
INFO - 2023-08-18 17:23:21 --> Database Driver Class Initialized
INFO - 2023-08-18 17:23:21 --> Email Class Initialized
DEBUG - 2023-08-18 17:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:23:21 --> Controller Class Initialized
INFO - 2023-08-18 17:23:21 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:23:21 --> Helper loaded: form_helper
INFO - 2023-08-18 17:23:21 --> Form Validation Class Initialized
INFO - 2023-08-18 17:23:21 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_create.php
INFO - 2023-08-18 17:23:21 --> Final output sent to browser
DEBUG - 2023-08-18 17:23:21 --> Total execution time: 0.0907
INFO - 2023-08-18 17:23:38 --> Config Class Initialized
INFO - 2023-08-18 17:23:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:23:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:23:38 --> Utf8 Class Initialized
INFO - 2023-08-18 17:23:38 --> URI Class Initialized
INFO - 2023-08-18 17:23:38 --> Router Class Initialized
INFO - 2023-08-18 17:23:38 --> Output Class Initialized
INFO - 2023-08-18 17:23:38 --> Security Class Initialized
DEBUG - 2023-08-18 17:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:23:38 --> Input Class Initialized
INFO - 2023-08-18 17:23:38 --> Language Class Initialized
INFO - 2023-08-18 17:23:38 --> Loader Class Initialized
INFO - 2023-08-18 17:23:38 --> Helper loaded: url_helper
INFO - 2023-08-18 17:23:38 --> Helper loaded: file_helper
INFO - 2023-08-18 17:23:38 --> Database Driver Class Initialized
INFO - 2023-08-18 17:23:38 --> Email Class Initialized
DEBUG - 2023-08-18 17:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:23:38 --> Controller Class Initialized
INFO - 2023-08-18 17:23:38 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:23:38 --> Helper loaded: form_helper
INFO - 2023-08-18 17:23:38 --> Form Validation Class Initialized
INFO - 2023-08-18 17:23:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:23:38 --> Config Class Initialized
INFO - 2023-08-18 17:23:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:23:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:23:38 --> Utf8 Class Initialized
INFO - 2023-08-18 17:23:38 --> URI Class Initialized
INFO - 2023-08-18 17:23:38 --> Router Class Initialized
INFO - 2023-08-18 17:23:38 --> Output Class Initialized
INFO - 2023-08-18 17:23:38 --> Security Class Initialized
DEBUG - 2023-08-18 17:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:23:38 --> Input Class Initialized
INFO - 2023-08-18 17:23:38 --> Language Class Initialized
INFO - 2023-08-18 17:23:38 --> Loader Class Initialized
INFO - 2023-08-18 17:23:38 --> Helper loaded: url_helper
INFO - 2023-08-18 17:23:38 --> Helper loaded: file_helper
INFO - 2023-08-18 17:23:38 --> Database Driver Class Initialized
INFO - 2023-08-18 17:23:38 --> Email Class Initialized
DEBUG - 2023-08-18 17:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:23:38 --> Controller Class Initialized
INFO - 2023-08-18 17:23:38 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:23:38 --> Helper loaded: form_helper
INFO - 2023-08-18 17:23:38 --> Form Validation Class Initialized
INFO - 2023-08-18 17:23:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 17:23:38 --> Final output sent to browser
DEBUG - 2023-08-18 17:23:38 --> Total execution time: 0.0461
INFO - 2023-08-18 17:23:41 --> Config Class Initialized
INFO - 2023-08-18 17:23:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:23:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:23:41 --> Utf8 Class Initialized
INFO - 2023-08-18 17:23:41 --> URI Class Initialized
INFO - 2023-08-18 17:23:41 --> Router Class Initialized
INFO - 2023-08-18 17:23:41 --> Output Class Initialized
INFO - 2023-08-18 17:23:41 --> Security Class Initialized
DEBUG - 2023-08-18 17:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:23:41 --> Input Class Initialized
INFO - 2023-08-18 17:23:41 --> Language Class Initialized
INFO - 2023-08-18 17:23:41 --> Loader Class Initialized
INFO - 2023-08-18 17:23:41 --> Helper loaded: url_helper
INFO - 2023-08-18 17:23:41 --> Helper loaded: file_helper
INFO - 2023-08-18 17:23:41 --> Database Driver Class Initialized
INFO - 2023-08-18 17:23:41 --> Email Class Initialized
DEBUG - 2023-08-18 17:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:23:41 --> Controller Class Initialized
INFO - 2023-08-18 17:23:41 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:23:41 --> Helper loaded: form_helper
INFO - 2023-08-18 17:23:41 --> Form Validation Class Initialized
ERROR - 2023-08-18 17:23:41 --> Severity: Warning --> Undefined array key "image" C:\xampp\htdocs\dw\application\views\admin\certification_courses_edit.php 101
ERROR - 2023-08-18 17:23:41 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\certification_courses_edit.php 115
INFO - 2023-08-18 17:23:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_edit.php
INFO - 2023-08-18 17:23:41 --> Final output sent to browser
DEBUG - 2023-08-18 17:23:41 --> Total execution time: 0.0502
INFO - 2023-08-18 17:23:42 --> Config Class Initialized
INFO - 2023-08-18 17:23:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:23:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:23:42 --> Utf8 Class Initialized
INFO - 2023-08-18 17:23:42 --> URI Class Initialized
INFO - 2023-08-18 17:23:42 --> Router Class Initialized
INFO - 2023-08-18 17:23:42 --> Output Class Initialized
INFO - 2023-08-18 17:23:42 --> Security Class Initialized
DEBUG - 2023-08-18 17:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:23:42 --> Input Class Initialized
INFO - 2023-08-18 17:23:42 --> Language Class Initialized
ERROR - 2023-08-18 17:23:42 --> 404 Page Not Found: admin/Certification_courses/edit
INFO - 2023-08-18 17:25:29 --> Config Class Initialized
INFO - 2023-08-18 17:25:29 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:25:29 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:25:29 --> Utf8 Class Initialized
INFO - 2023-08-18 17:25:29 --> URI Class Initialized
INFO - 2023-08-18 17:25:29 --> Router Class Initialized
INFO - 2023-08-18 17:25:29 --> Output Class Initialized
INFO - 2023-08-18 17:25:29 --> Security Class Initialized
DEBUG - 2023-08-18 17:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:25:29 --> Input Class Initialized
INFO - 2023-08-18 17:25:29 --> Language Class Initialized
INFO - 2023-08-18 17:25:29 --> Loader Class Initialized
INFO - 2023-08-18 17:25:29 --> Helper loaded: url_helper
INFO - 2023-08-18 17:25:29 --> Helper loaded: file_helper
INFO - 2023-08-18 17:25:29 --> Database Driver Class Initialized
INFO - 2023-08-18 17:25:29 --> Email Class Initialized
DEBUG - 2023-08-18 17:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:25:30 --> Controller Class Initialized
INFO - 2023-08-18 17:25:30 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:25:30 --> Helper loaded: form_helper
INFO - 2023-08-18 17:25:30 --> Form Validation Class Initialized
ERROR - 2023-08-18 17:25:30 --> Severity: Warning --> Undefined array key "image" C:\xampp\htdocs\dw\application\views\admin\certification_courses_edit.php 101
ERROR - 2023-08-18 17:25:30 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\certification_courses_edit.php 115
INFO - 2023-08-18 17:25:30 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_edit.php
INFO - 2023-08-18 17:25:30 --> Final output sent to browser
DEBUG - 2023-08-18 17:25:30 --> Total execution time: 1.8349
INFO - 2023-08-18 17:25:36 --> Config Class Initialized
INFO - 2023-08-18 17:25:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:25:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:25:36 --> Utf8 Class Initialized
INFO - 2023-08-18 17:25:36 --> URI Class Initialized
INFO - 2023-08-18 17:25:36 --> Router Class Initialized
INFO - 2023-08-18 17:25:36 --> Output Class Initialized
INFO - 2023-08-18 17:25:36 --> Security Class Initialized
DEBUG - 2023-08-18 17:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:25:36 --> Input Class Initialized
INFO - 2023-08-18 17:25:36 --> Language Class Initialized
INFO - 2023-08-18 17:25:36 --> Loader Class Initialized
INFO - 2023-08-18 17:25:36 --> Helper loaded: url_helper
INFO - 2023-08-18 17:25:36 --> Helper loaded: file_helper
INFO - 2023-08-18 17:25:36 --> Database Driver Class Initialized
INFO - 2023-08-18 17:25:36 --> Email Class Initialized
DEBUG - 2023-08-18 17:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:25:36 --> Controller Class Initialized
INFO - 2023-08-18 17:25:36 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:25:36 --> Helper loaded: form_helper
INFO - 2023-08-18 17:25:36 --> Form Validation Class Initialized
INFO - 2023-08-18 17:25:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_create.php
INFO - 2023-08-18 17:25:36 --> Final output sent to browser
DEBUG - 2023-08-18 17:25:37 --> Total execution time: 0.2004
INFO - 2023-08-18 17:26:12 --> Config Class Initialized
INFO - 2023-08-18 17:26:12 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:26:12 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:26:12 --> Utf8 Class Initialized
INFO - 2023-08-18 17:26:12 --> URI Class Initialized
INFO - 2023-08-18 17:26:12 --> Router Class Initialized
INFO - 2023-08-18 17:26:12 --> Output Class Initialized
INFO - 2023-08-18 17:26:12 --> Security Class Initialized
DEBUG - 2023-08-18 17:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:26:12 --> Input Class Initialized
INFO - 2023-08-18 17:26:12 --> Language Class Initialized
INFO - 2023-08-18 17:26:12 --> Loader Class Initialized
INFO - 2023-08-18 17:26:12 --> Helper loaded: url_helper
INFO - 2023-08-18 17:26:12 --> Helper loaded: file_helper
INFO - 2023-08-18 17:26:12 --> Database Driver Class Initialized
INFO - 2023-08-18 17:26:12 --> Email Class Initialized
DEBUG - 2023-08-18 17:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:26:12 --> Controller Class Initialized
INFO - 2023-08-18 17:26:12 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:26:12 --> Helper loaded: form_helper
INFO - 2023-08-18 17:26:12 --> Form Validation Class Initialized
INFO - 2023-08-18 17:26:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:26:13 --> Config Class Initialized
INFO - 2023-08-18 17:26:13 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:26:13 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:26:13 --> Utf8 Class Initialized
INFO - 2023-08-18 17:26:13 --> URI Class Initialized
INFO - 2023-08-18 17:26:13 --> Router Class Initialized
INFO - 2023-08-18 17:26:13 --> Output Class Initialized
INFO - 2023-08-18 17:26:13 --> Security Class Initialized
DEBUG - 2023-08-18 17:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:26:13 --> Input Class Initialized
INFO - 2023-08-18 17:26:13 --> Language Class Initialized
INFO - 2023-08-18 17:26:13 --> Loader Class Initialized
INFO - 2023-08-18 17:26:13 --> Helper loaded: url_helper
INFO - 2023-08-18 17:26:13 --> Helper loaded: file_helper
INFO - 2023-08-18 17:26:13 --> Database Driver Class Initialized
INFO - 2023-08-18 17:26:13 --> Email Class Initialized
DEBUG - 2023-08-18 17:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:26:13 --> Controller Class Initialized
INFO - 2023-08-18 17:26:13 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:26:13 --> Helper loaded: form_helper
INFO - 2023-08-18 17:26:13 --> Form Validation Class Initialized
INFO - 2023-08-18 17:26:14 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 17:26:14 --> Final output sent to browser
DEBUG - 2023-08-18 17:26:14 --> Total execution time: 0.7518
INFO - 2023-08-18 17:26:19 --> Config Class Initialized
INFO - 2023-08-18 17:26:19 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:26:19 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:26:19 --> Utf8 Class Initialized
INFO - 2023-08-18 17:26:19 --> URI Class Initialized
INFO - 2023-08-18 17:26:19 --> Router Class Initialized
INFO - 2023-08-18 17:26:19 --> Output Class Initialized
INFO - 2023-08-18 17:26:19 --> Security Class Initialized
DEBUG - 2023-08-18 17:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:26:19 --> Input Class Initialized
INFO - 2023-08-18 17:26:19 --> Language Class Initialized
INFO - 2023-08-18 17:26:19 --> Loader Class Initialized
INFO - 2023-08-18 17:26:19 --> Helper loaded: url_helper
INFO - 2023-08-18 17:26:19 --> Helper loaded: file_helper
INFO - 2023-08-18 17:26:19 --> Database Driver Class Initialized
INFO - 2023-08-18 17:26:19 --> Email Class Initialized
DEBUG - 2023-08-18 17:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:26:19 --> Controller Class Initialized
INFO - 2023-08-18 17:26:19 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:26:19 --> Helper loaded: form_helper
INFO - 2023-08-18 17:26:19 --> Form Validation Class Initialized
ERROR - 2023-08-18 17:26:19 --> Severity: Warning --> Undefined array key "image" C:\xampp\htdocs\dw\application\views\admin\certification_courses_edit.php 101
ERROR - 2023-08-18 17:26:19 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\certification_courses_edit.php 115
INFO - 2023-08-18 17:26:19 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_edit.php
INFO - 2023-08-18 17:26:19 --> Final output sent to browser
DEBUG - 2023-08-18 17:26:19 --> Total execution time: 0.0503
INFO - 2023-08-18 17:26:33 --> Config Class Initialized
INFO - 2023-08-18 17:26:33 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:26:33 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:26:33 --> Utf8 Class Initialized
INFO - 2023-08-18 17:26:33 --> URI Class Initialized
INFO - 2023-08-18 17:26:33 --> Router Class Initialized
INFO - 2023-08-18 17:26:33 --> Output Class Initialized
INFO - 2023-08-18 17:26:33 --> Security Class Initialized
DEBUG - 2023-08-18 17:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:26:33 --> Input Class Initialized
INFO - 2023-08-18 17:26:33 --> Language Class Initialized
INFO - 2023-08-18 17:26:33 --> Loader Class Initialized
INFO - 2023-08-18 17:26:33 --> Helper loaded: url_helper
INFO - 2023-08-18 17:26:33 --> Helper loaded: file_helper
INFO - 2023-08-18 17:26:33 --> Database Driver Class Initialized
INFO - 2023-08-18 17:26:33 --> Email Class Initialized
DEBUG - 2023-08-18 17:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:26:33 --> Controller Class Initialized
INFO - 2023-08-18 17:26:33 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:26:33 --> Helper loaded: form_helper
INFO - 2023-08-18 17:26:33 --> Form Validation Class Initialized
INFO - 2023-08-18 17:26:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:26:33 --> Config Class Initialized
INFO - 2023-08-18 17:26:33 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:26:33 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:26:33 --> Utf8 Class Initialized
INFO - 2023-08-18 17:26:33 --> URI Class Initialized
INFO - 2023-08-18 17:26:33 --> Router Class Initialized
INFO - 2023-08-18 17:26:33 --> Output Class Initialized
INFO - 2023-08-18 17:26:33 --> Security Class Initialized
DEBUG - 2023-08-18 17:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:26:33 --> Input Class Initialized
INFO - 2023-08-18 17:26:33 --> Language Class Initialized
INFO - 2023-08-18 17:26:33 --> Loader Class Initialized
INFO - 2023-08-18 17:26:33 --> Helper loaded: url_helper
INFO - 2023-08-18 17:26:33 --> Helper loaded: file_helper
INFO - 2023-08-18 17:26:33 --> Database Driver Class Initialized
INFO - 2023-08-18 17:26:33 --> Email Class Initialized
DEBUG - 2023-08-18 17:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:26:33 --> Controller Class Initialized
INFO - 2023-08-18 17:26:33 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:26:33 --> Helper loaded: form_helper
INFO - 2023-08-18 17:26:33 --> Form Validation Class Initialized
INFO - 2023-08-18 17:26:33 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 17:26:33 --> Final output sent to browser
DEBUG - 2023-08-18 17:26:33 --> Total execution time: 0.0528
INFO - 2023-08-18 17:26:39 --> Config Class Initialized
INFO - 2023-08-18 17:26:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:26:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:26:39 --> Utf8 Class Initialized
INFO - 2023-08-18 17:26:39 --> URI Class Initialized
INFO - 2023-08-18 17:26:39 --> Router Class Initialized
INFO - 2023-08-18 17:26:39 --> Output Class Initialized
INFO - 2023-08-18 17:26:39 --> Security Class Initialized
DEBUG - 2023-08-18 17:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:26:39 --> Input Class Initialized
INFO - 2023-08-18 17:26:39 --> Language Class Initialized
INFO - 2023-08-18 17:26:39 --> Loader Class Initialized
INFO - 2023-08-18 17:26:39 --> Helper loaded: url_helper
INFO - 2023-08-18 17:26:39 --> Helper loaded: file_helper
INFO - 2023-08-18 17:26:39 --> Database Driver Class Initialized
INFO - 2023-08-18 17:26:39 --> Email Class Initialized
DEBUG - 2023-08-18 17:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:26:39 --> Controller Class Initialized
INFO - 2023-08-18 17:26:39 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:26:39 --> Helper loaded: form_helper
INFO - 2023-08-18 17:26:39 --> Form Validation Class Initialized
ERROR - 2023-08-18 17:26:39 --> Severity: Warning --> Undefined array key "image" C:\xampp\htdocs\dw\application\views\admin\certification_courses_edit.php 101
ERROR - 2023-08-18 17:26:39 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\certification_courses_edit.php 115
INFO - 2023-08-18 17:26:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_edit.php
INFO - 2023-08-18 17:26:39 --> Final output sent to browser
DEBUG - 2023-08-18 17:26:39 --> Total execution time: 0.0486
INFO - 2023-08-18 17:26:48 --> Config Class Initialized
INFO - 2023-08-18 17:26:48 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:26:48 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:26:48 --> Utf8 Class Initialized
INFO - 2023-08-18 17:26:48 --> URI Class Initialized
INFO - 2023-08-18 17:26:48 --> Router Class Initialized
INFO - 2023-08-18 17:26:48 --> Output Class Initialized
INFO - 2023-08-18 17:26:48 --> Security Class Initialized
DEBUG - 2023-08-18 17:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:26:48 --> Input Class Initialized
INFO - 2023-08-18 17:26:48 --> Language Class Initialized
INFO - 2023-08-18 17:26:48 --> Loader Class Initialized
INFO - 2023-08-18 17:26:48 --> Helper loaded: url_helper
INFO - 2023-08-18 17:26:48 --> Helper loaded: file_helper
INFO - 2023-08-18 17:26:48 --> Database Driver Class Initialized
INFO - 2023-08-18 17:26:48 --> Email Class Initialized
DEBUG - 2023-08-18 17:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:26:48 --> Controller Class Initialized
INFO - 2023-08-18 17:26:48 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:26:48 --> Helper loaded: form_helper
INFO - 2023-08-18 17:26:48 --> Form Validation Class Initialized
INFO - 2023-08-18 17:26:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:26:48 --> Config Class Initialized
INFO - 2023-08-18 17:26:48 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:26:48 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:26:48 --> Utf8 Class Initialized
INFO - 2023-08-18 17:26:48 --> URI Class Initialized
INFO - 2023-08-18 17:26:48 --> Router Class Initialized
INFO - 2023-08-18 17:26:48 --> Output Class Initialized
INFO - 2023-08-18 17:26:48 --> Security Class Initialized
DEBUG - 2023-08-18 17:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:26:48 --> Input Class Initialized
INFO - 2023-08-18 17:26:48 --> Language Class Initialized
INFO - 2023-08-18 17:26:48 --> Loader Class Initialized
INFO - 2023-08-18 17:26:48 --> Helper loaded: url_helper
INFO - 2023-08-18 17:26:48 --> Helper loaded: file_helper
INFO - 2023-08-18 17:26:48 --> Database Driver Class Initialized
INFO - 2023-08-18 17:26:48 --> Email Class Initialized
DEBUG - 2023-08-18 17:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:26:48 --> Controller Class Initialized
INFO - 2023-08-18 17:26:48 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:26:48 --> Helper loaded: form_helper
INFO - 2023-08-18 17:26:48 --> Form Validation Class Initialized
INFO - 2023-08-18 17:26:48 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 17:26:48 --> Final output sent to browser
DEBUG - 2023-08-18 17:26:48 --> Total execution time: 0.0469
INFO - 2023-08-18 17:27:25 --> Config Class Initialized
INFO - 2023-08-18 17:27:25 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:27:25 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:27:25 --> Utf8 Class Initialized
INFO - 2023-08-18 17:27:25 --> URI Class Initialized
INFO - 2023-08-18 17:27:25 --> Router Class Initialized
INFO - 2023-08-18 17:27:25 --> Output Class Initialized
INFO - 2023-08-18 17:27:25 --> Security Class Initialized
DEBUG - 2023-08-18 17:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:27:25 --> Input Class Initialized
INFO - 2023-08-18 17:27:25 --> Language Class Initialized
INFO - 2023-08-18 17:27:25 --> Loader Class Initialized
INFO - 2023-08-18 17:27:25 --> Helper loaded: url_helper
INFO - 2023-08-18 17:27:25 --> Helper loaded: file_helper
INFO - 2023-08-18 17:27:25 --> Database Driver Class Initialized
INFO - 2023-08-18 17:27:25 --> Email Class Initialized
DEBUG - 2023-08-18 17:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:27:25 --> Controller Class Initialized
INFO - 2023-08-18 17:27:25 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:27:25 --> Helper loaded: form_helper
INFO - 2023-08-18 17:27:25 --> Form Validation Class Initialized
INFO - 2023-08-18 17:27:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 17:27:25 --> Final output sent to browser
DEBUG - 2023-08-18 17:27:25 --> Total execution time: 0.7028
INFO - 2023-08-18 17:27:27 --> Config Class Initialized
INFO - 2023-08-18 17:27:27 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:27:27 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:27:27 --> Utf8 Class Initialized
INFO - 2023-08-18 17:27:27 --> URI Class Initialized
INFO - 2023-08-18 17:27:27 --> Router Class Initialized
INFO - 2023-08-18 17:27:27 --> Output Class Initialized
INFO - 2023-08-18 17:27:27 --> Security Class Initialized
DEBUG - 2023-08-18 17:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:27:27 --> Input Class Initialized
INFO - 2023-08-18 17:27:27 --> Language Class Initialized
INFO - 2023-08-18 17:27:27 --> Loader Class Initialized
INFO - 2023-08-18 17:27:27 --> Helper loaded: url_helper
INFO - 2023-08-18 17:27:27 --> Helper loaded: file_helper
INFO - 2023-08-18 17:27:27 --> Database Driver Class Initialized
INFO - 2023-08-18 17:27:27 --> Email Class Initialized
DEBUG - 2023-08-18 17:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:27:27 --> Controller Class Initialized
INFO - 2023-08-18 17:27:27 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:27:27 --> Helper loaded: form_helper
INFO - 2023-08-18 17:27:27 --> Form Validation Class Initialized
ERROR - 2023-08-18 17:27:27 --> Severity: Warning --> Undefined array key "image" C:\xampp\htdocs\dw\application\views\admin\certification_courses_edit.php 101
ERROR - 2023-08-18 17:27:27 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\certification_courses_edit.php 115
INFO - 2023-08-18 17:27:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_edit.php
INFO - 2023-08-18 17:27:27 --> Final output sent to browser
DEBUG - 2023-08-18 17:27:27 --> Total execution time: 0.0505
INFO - 2023-08-18 17:27:31 --> Config Class Initialized
INFO - 2023-08-18 17:27:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:27:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:27:31 --> Utf8 Class Initialized
INFO - 2023-08-18 17:27:31 --> URI Class Initialized
INFO - 2023-08-18 17:27:31 --> Router Class Initialized
INFO - 2023-08-18 17:27:31 --> Output Class Initialized
INFO - 2023-08-18 17:27:31 --> Security Class Initialized
DEBUG - 2023-08-18 17:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:27:31 --> Input Class Initialized
INFO - 2023-08-18 17:27:31 --> Language Class Initialized
INFO - 2023-08-18 17:27:31 --> Loader Class Initialized
INFO - 2023-08-18 17:27:31 --> Helper loaded: url_helper
INFO - 2023-08-18 17:27:31 --> Helper loaded: file_helper
INFO - 2023-08-18 17:27:31 --> Database Driver Class Initialized
INFO - 2023-08-18 17:27:31 --> Email Class Initialized
DEBUG - 2023-08-18 17:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:27:31 --> Controller Class Initialized
INFO - 2023-08-18 17:27:31 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:27:31 --> Helper loaded: form_helper
INFO - 2023-08-18 17:27:31 --> Form Validation Class Initialized
INFO - 2023-08-18 17:27:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:27:31 --> Config Class Initialized
INFO - 2023-08-18 17:27:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:27:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:27:31 --> Utf8 Class Initialized
INFO - 2023-08-18 17:27:31 --> URI Class Initialized
INFO - 2023-08-18 17:27:31 --> Router Class Initialized
INFO - 2023-08-18 17:27:31 --> Output Class Initialized
INFO - 2023-08-18 17:27:31 --> Security Class Initialized
DEBUG - 2023-08-18 17:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:27:31 --> Input Class Initialized
INFO - 2023-08-18 17:27:31 --> Language Class Initialized
INFO - 2023-08-18 17:27:31 --> Loader Class Initialized
INFO - 2023-08-18 17:27:31 --> Helper loaded: url_helper
INFO - 2023-08-18 17:27:31 --> Helper loaded: file_helper
INFO - 2023-08-18 17:27:31 --> Database Driver Class Initialized
INFO - 2023-08-18 17:27:31 --> Email Class Initialized
DEBUG - 2023-08-18 17:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:27:31 --> Controller Class Initialized
INFO - 2023-08-18 17:27:31 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:27:31 --> Helper loaded: form_helper
INFO - 2023-08-18 17:27:31 --> Form Validation Class Initialized
INFO - 2023-08-18 17:27:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 17:27:31 --> Final output sent to browser
DEBUG - 2023-08-18 17:27:31 --> Total execution time: 0.0961
INFO - 2023-08-18 17:27:35 --> Config Class Initialized
INFO - 2023-08-18 17:27:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:27:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:27:35 --> Utf8 Class Initialized
INFO - 2023-08-18 17:27:35 --> URI Class Initialized
INFO - 2023-08-18 17:27:35 --> Router Class Initialized
INFO - 2023-08-18 17:27:35 --> Output Class Initialized
INFO - 2023-08-18 17:27:35 --> Security Class Initialized
DEBUG - 2023-08-18 17:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:27:35 --> Input Class Initialized
INFO - 2023-08-18 17:27:35 --> Language Class Initialized
INFO - 2023-08-18 17:27:35 --> Loader Class Initialized
INFO - 2023-08-18 17:27:35 --> Helper loaded: url_helper
INFO - 2023-08-18 17:27:35 --> Helper loaded: file_helper
INFO - 2023-08-18 17:27:35 --> Database Driver Class Initialized
INFO - 2023-08-18 17:27:35 --> Email Class Initialized
DEBUG - 2023-08-18 17:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:27:35 --> Controller Class Initialized
INFO - 2023-08-18 17:27:35 --> Model "Services_model" initialized
INFO - 2023-08-18 17:27:35 --> Helper loaded: form_helper
INFO - 2023-08-18 17:27:35 --> Form Validation Class Initialized
INFO - 2023-08-18 17:27:35 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-18 17:27:35 --> Final output sent to browser
DEBUG - 2023-08-18 17:27:35 --> Total execution time: 0.3029
INFO - 2023-08-18 17:27:39 --> Config Class Initialized
INFO - 2023-08-18 17:27:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:27:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:27:39 --> Utf8 Class Initialized
INFO - 2023-08-18 17:27:39 --> URI Class Initialized
INFO - 2023-08-18 17:27:39 --> Router Class Initialized
INFO - 2023-08-18 17:27:39 --> Output Class Initialized
INFO - 2023-08-18 17:27:39 --> Security Class Initialized
DEBUG - 2023-08-18 17:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:27:39 --> Input Class Initialized
INFO - 2023-08-18 17:27:39 --> Language Class Initialized
INFO - 2023-08-18 17:27:39 --> Loader Class Initialized
INFO - 2023-08-18 17:27:39 --> Helper loaded: url_helper
INFO - 2023-08-18 17:27:39 --> Helper loaded: file_helper
INFO - 2023-08-18 17:27:39 --> Database Driver Class Initialized
INFO - 2023-08-18 17:27:39 --> Email Class Initialized
DEBUG - 2023-08-18 17:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:27:39 --> Controller Class Initialized
INFO - 2023-08-18 17:27:39 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:27:39 --> Helper loaded: form_helper
INFO - 2023-08-18 17:27:39 --> Form Validation Class Initialized
INFO - 2023-08-18 17:27:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 17:27:39 --> Final output sent to browser
DEBUG - 2023-08-18 17:27:39 --> Total execution time: 0.0596
INFO - 2023-08-18 17:27:43 --> Config Class Initialized
INFO - 2023-08-18 17:27:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:27:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:27:43 --> Utf8 Class Initialized
INFO - 2023-08-18 17:27:43 --> URI Class Initialized
INFO - 2023-08-18 17:27:43 --> Router Class Initialized
INFO - 2023-08-18 17:27:43 --> Output Class Initialized
INFO - 2023-08-18 17:27:43 --> Security Class Initialized
DEBUG - 2023-08-18 17:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:27:43 --> Input Class Initialized
INFO - 2023-08-18 17:27:43 --> Language Class Initialized
INFO - 2023-08-18 17:27:43 --> Loader Class Initialized
INFO - 2023-08-18 17:27:43 --> Helper loaded: url_helper
INFO - 2023-08-18 17:27:43 --> Helper loaded: file_helper
INFO - 2023-08-18 17:27:43 --> Database Driver Class Initialized
INFO - 2023-08-18 17:27:43 --> Email Class Initialized
DEBUG - 2023-08-18 17:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:27:43 --> Controller Class Initialized
INFO - 2023-08-18 17:27:43 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:27:43 --> Helper loaded: form_helper
INFO - 2023-08-18 17:27:43 --> Form Validation Class Initialized
INFO - 2023-08-18 17:27:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_create.php
INFO - 2023-08-18 17:27:43 --> Final output sent to browser
DEBUG - 2023-08-18 17:27:43 --> Total execution time: 0.0503
INFO - 2023-08-18 17:28:03 --> Config Class Initialized
INFO - 2023-08-18 17:28:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:28:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:28:03 --> Utf8 Class Initialized
INFO - 2023-08-18 17:28:03 --> URI Class Initialized
INFO - 2023-08-18 17:28:03 --> Router Class Initialized
INFO - 2023-08-18 17:28:03 --> Output Class Initialized
INFO - 2023-08-18 17:28:03 --> Security Class Initialized
DEBUG - 2023-08-18 17:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:28:03 --> Input Class Initialized
INFO - 2023-08-18 17:28:03 --> Language Class Initialized
INFO - 2023-08-18 17:28:03 --> Loader Class Initialized
INFO - 2023-08-18 17:28:03 --> Helper loaded: url_helper
INFO - 2023-08-18 17:28:03 --> Helper loaded: file_helper
INFO - 2023-08-18 17:28:03 --> Database Driver Class Initialized
INFO - 2023-08-18 17:28:03 --> Email Class Initialized
DEBUG - 2023-08-18 17:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:28:03 --> Controller Class Initialized
INFO - 2023-08-18 17:28:03 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:28:03 --> Helper loaded: form_helper
INFO - 2023-08-18 17:28:03 --> Form Validation Class Initialized
INFO - 2023-08-18 17:28:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:28:04 --> Config Class Initialized
INFO - 2023-08-18 17:28:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:28:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:28:04 --> Utf8 Class Initialized
INFO - 2023-08-18 17:28:04 --> URI Class Initialized
INFO - 2023-08-18 17:28:04 --> Router Class Initialized
INFO - 2023-08-18 17:28:04 --> Output Class Initialized
INFO - 2023-08-18 17:28:04 --> Security Class Initialized
DEBUG - 2023-08-18 17:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:28:04 --> Input Class Initialized
INFO - 2023-08-18 17:28:04 --> Language Class Initialized
INFO - 2023-08-18 17:28:04 --> Loader Class Initialized
INFO - 2023-08-18 17:28:04 --> Helper loaded: url_helper
INFO - 2023-08-18 17:28:04 --> Helper loaded: file_helper
INFO - 2023-08-18 17:28:04 --> Database Driver Class Initialized
INFO - 2023-08-18 17:28:04 --> Email Class Initialized
DEBUG - 2023-08-18 17:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:28:04 --> Controller Class Initialized
INFO - 2023-08-18 17:28:04 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:28:04 --> Helper loaded: form_helper
INFO - 2023-08-18 17:28:04 --> Form Validation Class Initialized
INFO - 2023-08-18 17:28:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 17:28:04 --> Final output sent to browser
DEBUG - 2023-08-18 17:28:04 --> Total execution time: 0.2302
INFO - 2023-08-18 17:28:10 --> Config Class Initialized
INFO - 2023-08-18 17:28:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:28:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:28:10 --> Utf8 Class Initialized
INFO - 2023-08-18 17:28:10 --> URI Class Initialized
INFO - 2023-08-18 17:28:10 --> Router Class Initialized
INFO - 2023-08-18 17:28:10 --> Output Class Initialized
INFO - 2023-08-18 17:28:10 --> Security Class Initialized
DEBUG - 2023-08-18 17:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:28:10 --> Input Class Initialized
INFO - 2023-08-18 17:28:10 --> Language Class Initialized
INFO - 2023-08-18 17:28:10 --> Loader Class Initialized
INFO - 2023-08-18 17:28:10 --> Helper loaded: url_helper
INFO - 2023-08-18 17:28:10 --> Helper loaded: file_helper
INFO - 2023-08-18 17:28:10 --> Database Driver Class Initialized
INFO - 2023-08-18 17:28:10 --> Email Class Initialized
DEBUG - 2023-08-18 17:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:28:10 --> Controller Class Initialized
INFO - 2023-08-18 17:28:10 --> Model "Training_model" initialized
INFO - 2023-08-18 17:28:10 --> Helper loaded: form_helper
INFO - 2023-08-18 17:28:10 --> Form Validation Class Initialized
INFO - 2023-08-18 17:28:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-18 17:28:10 --> Final output sent to browser
DEBUG - 2023-08-18 17:28:10 --> Total execution time: 0.2387
INFO - 2023-08-18 17:28:41 --> Config Class Initialized
INFO - 2023-08-18 17:28:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:28:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:28:41 --> Utf8 Class Initialized
INFO - 2023-08-18 17:28:41 --> URI Class Initialized
INFO - 2023-08-18 17:28:41 --> Router Class Initialized
INFO - 2023-08-18 17:28:41 --> Output Class Initialized
INFO - 2023-08-18 17:28:41 --> Security Class Initialized
DEBUG - 2023-08-18 17:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:28:41 --> Input Class Initialized
INFO - 2023-08-18 17:28:41 --> Language Class Initialized
INFO - 2023-08-18 17:28:41 --> Loader Class Initialized
INFO - 2023-08-18 17:28:41 --> Helper loaded: url_helper
INFO - 2023-08-18 17:28:41 --> Helper loaded: file_helper
INFO - 2023-08-18 17:28:41 --> Database Driver Class Initialized
INFO - 2023-08-18 17:28:41 --> Email Class Initialized
DEBUG - 2023-08-18 17:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:28:41 --> Controller Class Initialized
INFO - 2023-08-18 17:28:41 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:28:41 --> Helper loaded: form_helper
INFO - 2023-08-18 17:28:41 --> Form Validation Class Initialized
ERROR - 2023-08-18 17:28:41 --> Severity: Warning --> Undefined variable $curriculums C:\xampp\htdocs\dw\application\views\admin\training_curriculum_list.php 66
ERROR - 2023-08-18 17:28:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\admin\training_curriculum_list.php 66
INFO - 2023-08-18 17:28:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:28:41 --> Final output sent to browser
DEBUG - 2023-08-18 17:28:41 --> Total execution time: 0.7615
INFO - 2023-08-18 17:28:42 --> Config Class Initialized
INFO - 2023-08-18 17:28:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:28:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:28:42 --> Utf8 Class Initialized
INFO - 2023-08-18 17:28:42 --> URI Class Initialized
INFO - 2023-08-18 17:28:42 --> Router Class Initialized
INFO - 2023-08-18 17:28:42 --> Output Class Initialized
INFO - 2023-08-18 17:28:42 --> Security Class Initialized
DEBUG - 2023-08-18 17:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:28:42 --> Input Class Initialized
INFO - 2023-08-18 17:28:42 --> Language Class Initialized
ERROR - 2023-08-18 17:28:42 --> 404 Page Not Found: admin/Training_curriculum/images
INFO - 2023-08-18 17:29:01 --> Config Class Initialized
INFO - 2023-08-18 17:29:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:29:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:29:01 --> Utf8 Class Initialized
INFO - 2023-08-18 17:29:01 --> URI Class Initialized
INFO - 2023-08-18 17:29:01 --> Router Class Initialized
INFO - 2023-08-18 17:29:01 --> Output Class Initialized
INFO - 2023-08-18 17:29:01 --> Security Class Initialized
DEBUG - 2023-08-18 17:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:29:01 --> Input Class Initialized
INFO - 2023-08-18 17:29:01 --> Language Class Initialized
ERROR - 2023-08-18 17:29:01 --> 404 Page Not Found: admin/Training_curriculum/index
INFO - 2023-08-18 17:29:04 --> Config Class Initialized
INFO - 2023-08-18 17:29:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:29:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:29:04 --> Utf8 Class Initialized
INFO - 2023-08-18 17:29:04 --> URI Class Initialized
INFO - 2023-08-18 17:29:04 --> Router Class Initialized
INFO - 2023-08-18 17:29:04 --> Output Class Initialized
INFO - 2023-08-18 17:29:04 --> Security Class Initialized
DEBUG - 2023-08-18 17:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:29:04 --> Input Class Initialized
INFO - 2023-08-18 17:29:04 --> Language Class Initialized
INFO - 2023-08-18 17:29:04 --> Loader Class Initialized
INFO - 2023-08-18 17:29:04 --> Helper loaded: url_helper
INFO - 2023-08-18 17:29:04 --> Helper loaded: file_helper
INFO - 2023-08-18 17:29:04 --> Database Driver Class Initialized
INFO - 2023-08-18 17:29:04 --> Email Class Initialized
DEBUG - 2023-08-18 17:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:29:04 --> Controller Class Initialized
INFO - 2023-08-18 17:29:04 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:29:04 --> Helper loaded: form_helper
INFO - 2023-08-18 17:29:04 --> Form Validation Class Initialized
ERROR - 2023-08-18 17:29:04 --> Severity: Warning --> Undefined variable $curriculums C:\xampp\htdocs\dw\application\views\admin\training_curriculum_list.php 66
ERROR - 2023-08-18 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\admin\training_curriculum_list.php 66
INFO - 2023-08-18 17:29:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:29:04 --> Final output sent to browser
DEBUG - 2023-08-18 17:29:04 --> Total execution time: 0.0560
INFO - 2023-08-18 17:29:18 --> Config Class Initialized
INFO - 2023-08-18 17:29:18 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:29:18 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:29:18 --> Utf8 Class Initialized
INFO - 2023-08-18 17:29:18 --> URI Class Initialized
INFO - 2023-08-18 17:29:18 --> Router Class Initialized
INFO - 2023-08-18 17:29:18 --> Output Class Initialized
INFO - 2023-08-18 17:29:18 --> Security Class Initialized
DEBUG - 2023-08-18 17:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:29:18 --> Input Class Initialized
INFO - 2023-08-18 17:29:18 --> Language Class Initialized
INFO - 2023-08-18 17:29:18 --> Loader Class Initialized
INFO - 2023-08-18 17:29:19 --> Helper loaded: url_helper
INFO - 2023-08-18 17:29:19 --> Helper loaded: file_helper
INFO - 2023-08-18 17:29:19 --> Database Driver Class Initialized
INFO - 2023-08-18 17:29:19 --> Email Class Initialized
DEBUG - 2023-08-18 17:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:29:19 --> Controller Class Initialized
INFO - 2023-08-18 17:29:19 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:29:19 --> Helper loaded: form_helper
INFO - 2023-08-18 17:29:19 --> Form Validation Class Initialized
INFO - 2023-08-18 17:29:19 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-08-18 17:29:19 --> Final output sent to browser
DEBUG - 2023-08-18 17:29:19 --> Total execution time: 0.7504
INFO - 2023-08-18 17:29:20 --> Config Class Initialized
INFO - 2023-08-18 17:29:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:29:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:29:20 --> Utf8 Class Initialized
INFO - 2023-08-18 17:29:20 --> URI Class Initialized
INFO - 2023-08-18 17:29:20 --> Router Class Initialized
INFO - 2023-08-18 17:29:20 --> Output Class Initialized
INFO - 2023-08-18 17:29:20 --> Security Class Initialized
DEBUG - 2023-08-18 17:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:29:20 --> Input Class Initialized
INFO - 2023-08-18 17:29:20 --> Language Class Initialized
ERROR - 2023-08-18 17:29:20 --> 404 Page Not Found: admin/Training_curriculum/add
INFO - 2023-08-18 17:29:40 --> Config Class Initialized
INFO - 2023-08-18 17:29:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:29:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:29:40 --> Utf8 Class Initialized
INFO - 2023-08-18 17:29:40 --> URI Class Initialized
INFO - 2023-08-18 17:29:40 --> Router Class Initialized
INFO - 2023-08-18 17:29:40 --> Output Class Initialized
INFO - 2023-08-18 17:29:40 --> Security Class Initialized
DEBUG - 2023-08-18 17:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:29:40 --> Input Class Initialized
INFO - 2023-08-18 17:29:40 --> Language Class Initialized
INFO - 2023-08-18 17:29:40 --> Loader Class Initialized
INFO - 2023-08-18 17:29:40 --> Helper loaded: url_helper
INFO - 2023-08-18 17:29:40 --> Helper loaded: file_helper
INFO - 2023-08-18 17:29:40 --> Database Driver Class Initialized
INFO - 2023-08-18 17:29:40 --> Email Class Initialized
DEBUG - 2023-08-18 17:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:29:40 --> Controller Class Initialized
INFO - 2023-08-18 17:29:40 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:29:40 --> Helper loaded: form_helper
INFO - 2023-08-18 17:29:40 --> Form Validation Class Initialized
INFO - 2023-08-18 17:29:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:29:40 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-08-18 17:29:40 --> Final output sent to browser
DEBUG - 2023-08-18 17:29:40 --> Total execution time: 0.2149
INFO - 2023-08-18 17:29:44 --> Config Class Initialized
INFO - 2023-08-18 17:29:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:29:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:29:44 --> Utf8 Class Initialized
INFO - 2023-08-18 17:29:44 --> URI Class Initialized
INFO - 2023-08-18 17:29:44 --> Router Class Initialized
INFO - 2023-08-18 17:29:44 --> Output Class Initialized
INFO - 2023-08-18 17:29:44 --> Security Class Initialized
DEBUG - 2023-08-18 17:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:29:44 --> Input Class Initialized
INFO - 2023-08-18 17:29:44 --> Language Class Initialized
ERROR - 2023-08-18 17:29:44 --> 404 Page Not Found: admin/Training_curriculum/create
INFO - 2023-08-18 17:30:03 --> Config Class Initialized
INFO - 2023-08-18 17:30:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:30:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:30:03 --> Utf8 Class Initialized
INFO - 2023-08-18 17:30:03 --> URI Class Initialized
INFO - 2023-08-18 17:30:03 --> Router Class Initialized
INFO - 2023-08-18 17:30:03 --> Output Class Initialized
INFO - 2023-08-18 17:30:03 --> Security Class Initialized
DEBUG - 2023-08-18 17:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:30:03 --> Input Class Initialized
INFO - 2023-08-18 17:30:03 --> Language Class Initialized
INFO - 2023-08-18 17:30:03 --> Loader Class Initialized
INFO - 2023-08-18 17:30:03 --> Helper loaded: url_helper
INFO - 2023-08-18 17:30:03 --> Helper loaded: file_helper
INFO - 2023-08-18 17:30:03 --> Database Driver Class Initialized
INFO - 2023-08-18 17:30:03 --> Email Class Initialized
DEBUG - 2023-08-18 17:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:30:03 --> Controller Class Initialized
INFO - 2023-08-18 17:30:03 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:30:04 --> Helper loaded: form_helper
INFO - 2023-08-18 17:30:04 --> Form Validation Class Initialized
INFO - 2023-08-18 17:30:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:30:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-08-18 17:30:04 --> Final output sent to browser
DEBUG - 2023-08-18 17:30:04 --> Total execution time: 0.8030
INFO - 2023-08-18 17:32:32 --> Config Class Initialized
INFO - 2023-08-18 17:32:32 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:32:32 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:32:32 --> Utf8 Class Initialized
INFO - 2023-08-18 17:32:32 --> URI Class Initialized
INFO - 2023-08-18 17:32:32 --> Router Class Initialized
INFO - 2023-08-18 17:32:32 --> Output Class Initialized
INFO - 2023-08-18 17:32:32 --> Security Class Initialized
DEBUG - 2023-08-18 17:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:32:32 --> Input Class Initialized
INFO - 2023-08-18 17:32:32 --> Language Class Initialized
INFO - 2023-08-18 17:32:32 --> Loader Class Initialized
INFO - 2023-08-18 17:32:32 --> Helper loaded: url_helper
INFO - 2023-08-18 17:32:32 --> Helper loaded: file_helper
INFO - 2023-08-18 17:32:32 --> Database Driver Class Initialized
INFO - 2023-08-18 17:32:32 --> Email Class Initialized
DEBUG - 2023-08-18 17:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:32:32 --> Controller Class Initialized
INFO - 2023-08-18 17:32:32 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:32:32 --> Helper loaded: form_helper
INFO - 2023-08-18 17:32:32 --> Form Validation Class Initialized
INFO - 2023-08-18 17:32:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:32:32 --> Config Class Initialized
INFO - 2023-08-18 17:32:32 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:32:32 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:32:32 --> Utf8 Class Initialized
INFO - 2023-08-18 17:32:32 --> URI Class Initialized
INFO - 2023-08-18 17:32:32 --> Router Class Initialized
INFO - 2023-08-18 17:32:32 --> Output Class Initialized
INFO - 2023-08-18 17:32:32 --> Security Class Initialized
DEBUG - 2023-08-18 17:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:32:32 --> Input Class Initialized
INFO - 2023-08-18 17:32:32 --> Language Class Initialized
ERROR - 2023-08-18 17:32:32 --> 404 Page Not Found: admin/Training_curriculum/index
INFO - 2023-08-18 17:33:23 --> Config Class Initialized
INFO - 2023-08-18 17:33:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:33:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:33:23 --> Utf8 Class Initialized
INFO - 2023-08-18 17:33:23 --> URI Class Initialized
INFO - 2023-08-18 17:33:23 --> Router Class Initialized
INFO - 2023-08-18 17:33:23 --> Output Class Initialized
INFO - 2023-08-18 17:33:23 --> Security Class Initialized
DEBUG - 2023-08-18 17:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:33:23 --> Input Class Initialized
INFO - 2023-08-18 17:33:23 --> Language Class Initialized
INFO - 2023-08-18 17:33:23 --> Loader Class Initialized
INFO - 2023-08-18 17:33:23 --> Helper loaded: url_helper
INFO - 2023-08-18 17:33:23 --> Helper loaded: file_helper
INFO - 2023-08-18 17:33:23 --> Database Driver Class Initialized
INFO - 2023-08-18 17:33:23 --> Email Class Initialized
DEBUG - 2023-08-18 17:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:33:23 --> Controller Class Initialized
INFO - 2023-08-18 17:33:23 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:33:23 --> Helper loaded: form_helper
INFO - 2023-08-18 17:33:23 --> Form Validation Class Initialized
INFO - 2023-08-18 17:33:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-08-18 17:33:23 --> Final output sent to browser
DEBUG - 2023-08-18 17:33:23 --> Total execution time: 0.6944
INFO - 2023-08-18 17:33:27 --> Config Class Initialized
INFO - 2023-08-18 17:33:27 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:33:27 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:33:27 --> Utf8 Class Initialized
INFO - 2023-08-18 17:33:27 --> URI Class Initialized
INFO - 2023-08-18 17:33:27 --> Router Class Initialized
INFO - 2023-08-18 17:33:27 --> Output Class Initialized
INFO - 2023-08-18 17:33:27 --> Security Class Initialized
DEBUG - 2023-08-18 17:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:33:27 --> Input Class Initialized
INFO - 2023-08-18 17:33:27 --> Language Class Initialized
INFO - 2023-08-18 17:33:27 --> Loader Class Initialized
INFO - 2023-08-18 17:33:27 --> Helper loaded: url_helper
INFO - 2023-08-18 17:33:27 --> Helper loaded: file_helper
INFO - 2023-08-18 17:33:27 --> Database Driver Class Initialized
INFO - 2023-08-18 17:33:27 --> Email Class Initialized
DEBUG - 2023-08-18 17:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:33:27 --> Controller Class Initialized
INFO - 2023-08-18 17:33:27 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:33:27 --> Helper loaded: form_helper
INFO - 2023-08-18 17:33:27 --> Form Validation Class Initialized
INFO - 2023-08-18 17:33:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:33:27 --> Config Class Initialized
INFO - 2023-08-18 17:33:27 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:33:27 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:33:27 --> Utf8 Class Initialized
INFO - 2023-08-18 17:33:27 --> URI Class Initialized
INFO - 2023-08-18 17:33:27 --> Router Class Initialized
INFO - 2023-08-18 17:33:27 --> Output Class Initialized
INFO - 2023-08-18 17:33:27 --> Security Class Initialized
DEBUG - 2023-08-18 17:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:33:27 --> Input Class Initialized
INFO - 2023-08-18 17:33:27 --> Language Class Initialized
INFO - 2023-08-18 17:33:27 --> Loader Class Initialized
INFO - 2023-08-18 17:33:27 --> Helper loaded: url_helper
INFO - 2023-08-18 17:33:27 --> Helper loaded: file_helper
INFO - 2023-08-18 17:33:27 --> Database Driver Class Initialized
INFO - 2023-08-18 17:33:27 --> Email Class Initialized
DEBUG - 2023-08-18 17:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:33:27 --> Controller Class Initialized
INFO - 2023-08-18 17:33:27 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:33:27 --> Helper loaded: form_helper
INFO - 2023-08-18 17:33:27 --> Form Validation Class Initialized
ERROR - 2023-08-18 17:33:27 --> Severity: Warning --> Undefined variable $curriculums C:\xampp\htdocs\dw\application\views\admin\training_curriculum_list.php 66
ERROR - 2023-08-18 17:33:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\admin\training_curriculum_list.php 66
INFO - 2023-08-18 17:33:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:33:27 --> Final output sent to browser
DEBUG - 2023-08-18 17:33:27 --> Total execution time: 0.0835
INFO - 2023-08-18 17:34:49 --> Config Class Initialized
INFO - 2023-08-18 17:34:49 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:34:49 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:34:49 --> Utf8 Class Initialized
INFO - 2023-08-18 17:34:49 --> URI Class Initialized
INFO - 2023-08-18 17:34:49 --> Router Class Initialized
INFO - 2023-08-18 17:34:49 --> Output Class Initialized
INFO - 2023-08-18 17:34:49 --> Security Class Initialized
DEBUG - 2023-08-18 17:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:34:49 --> Input Class Initialized
INFO - 2023-08-18 17:34:49 --> Language Class Initialized
INFO - 2023-08-18 17:34:49 --> Loader Class Initialized
INFO - 2023-08-18 17:34:49 --> Helper loaded: url_helper
INFO - 2023-08-18 17:34:49 --> Helper loaded: file_helper
INFO - 2023-08-18 17:34:49 --> Database Driver Class Initialized
INFO - 2023-08-18 17:34:49 --> Email Class Initialized
DEBUG - 2023-08-18 17:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:34:49 --> Controller Class Initialized
INFO - 2023-08-18 17:34:49 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:34:49 --> Helper loaded: form_helper
INFO - 2023-08-18 17:34:49 --> Form Validation Class Initialized
INFO - 2023-08-18 17:34:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:34:49 --> Final output sent to browser
DEBUG - 2023-08-18 17:34:49 --> Total execution time: 0.4106
INFO - 2023-08-18 17:35:00 --> Config Class Initialized
INFO - 2023-08-18 17:35:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:35:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:35:00 --> Utf8 Class Initialized
INFO - 2023-08-18 17:35:00 --> URI Class Initialized
INFO - 2023-08-18 17:35:00 --> Router Class Initialized
INFO - 2023-08-18 17:35:00 --> Output Class Initialized
INFO - 2023-08-18 17:35:00 --> Security Class Initialized
DEBUG - 2023-08-18 17:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:35:00 --> Input Class Initialized
INFO - 2023-08-18 17:35:00 --> Language Class Initialized
INFO - 2023-08-18 17:35:00 --> Loader Class Initialized
INFO - 2023-08-18 17:35:00 --> Helper loaded: url_helper
INFO - 2023-08-18 17:35:00 --> Helper loaded: file_helper
INFO - 2023-08-18 17:35:00 --> Database Driver Class Initialized
INFO - 2023-08-18 17:35:00 --> Email Class Initialized
DEBUG - 2023-08-18 17:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:35:00 --> Controller Class Initialized
INFO - 2023-08-18 17:35:00 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:35:00 --> Helper loaded: form_helper
INFO - 2023-08-18 17:35:00 --> Form Validation Class Initialized
INFO - 2023-08-18 17:35:00 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-08-18 17:35:00 --> Final output sent to browser
DEBUG - 2023-08-18 17:35:00 --> Total execution time: 0.4089
INFO - 2023-08-18 17:35:17 --> Config Class Initialized
INFO - 2023-08-18 17:35:17 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:35:17 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:35:17 --> Utf8 Class Initialized
INFO - 2023-08-18 17:35:17 --> URI Class Initialized
INFO - 2023-08-18 17:35:17 --> Router Class Initialized
INFO - 2023-08-18 17:35:17 --> Output Class Initialized
INFO - 2023-08-18 17:35:17 --> Security Class Initialized
DEBUG - 2023-08-18 17:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:35:17 --> Input Class Initialized
INFO - 2023-08-18 17:35:17 --> Language Class Initialized
INFO - 2023-08-18 17:35:18 --> Loader Class Initialized
INFO - 2023-08-18 17:35:18 --> Helper loaded: url_helper
INFO - 2023-08-18 17:35:18 --> Helper loaded: file_helper
INFO - 2023-08-18 17:35:18 --> Database Driver Class Initialized
INFO - 2023-08-18 17:35:18 --> Email Class Initialized
DEBUG - 2023-08-18 17:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:35:18 --> Controller Class Initialized
INFO - 2023-08-18 17:35:18 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:35:18 --> Helper loaded: form_helper
INFO - 2023-08-18 17:35:18 --> Form Validation Class Initialized
INFO - 2023-08-18 17:35:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:35:18 --> Config Class Initialized
INFO - 2023-08-18 17:35:18 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:35:18 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:35:18 --> Utf8 Class Initialized
INFO - 2023-08-18 17:35:18 --> URI Class Initialized
INFO - 2023-08-18 17:35:18 --> Router Class Initialized
INFO - 2023-08-18 17:35:18 --> Output Class Initialized
INFO - 2023-08-18 17:35:18 --> Security Class Initialized
DEBUG - 2023-08-18 17:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:35:18 --> Input Class Initialized
INFO - 2023-08-18 17:35:18 --> Language Class Initialized
INFO - 2023-08-18 17:35:18 --> Loader Class Initialized
INFO - 2023-08-18 17:35:18 --> Helper loaded: url_helper
INFO - 2023-08-18 17:35:18 --> Helper loaded: file_helper
INFO - 2023-08-18 17:35:18 --> Database Driver Class Initialized
INFO - 2023-08-18 17:35:18 --> Email Class Initialized
DEBUG - 2023-08-18 17:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:35:18 --> Controller Class Initialized
INFO - 2023-08-18 17:35:18 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:35:18 --> Helper loaded: form_helper
INFO - 2023-08-18 17:35:18 --> Form Validation Class Initialized
INFO - 2023-08-18 17:35:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:35:18 --> Final output sent to browser
DEBUG - 2023-08-18 17:35:18 --> Total execution time: 0.5436
INFO - 2023-08-18 17:36:08 --> Config Class Initialized
INFO - 2023-08-18 17:36:08 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:36:08 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:36:08 --> Utf8 Class Initialized
INFO - 2023-08-18 17:36:08 --> URI Class Initialized
INFO - 2023-08-18 17:36:08 --> Router Class Initialized
INFO - 2023-08-18 17:36:08 --> Output Class Initialized
INFO - 2023-08-18 17:36:08 --> Security Class Initialized
DEBUG - 2023-08-18 17:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:36:08 --> Input Class Initialized
INFO - 2023-08-18 17:36:08 --> Language Class Initialized
INFO - 2023-08-18 17:36:08 --> Loader Class Initialized
INFO - 2023-08-18 17:36:08 --> Helper loaded: url_helper
INFO - 2023-08-18 17:36:08 --> Helper loaded: file_helper
INFO - 2023-08-18 17:36:08 --> Database Driver Class Initialized
INFO - 2023-08-18 17:36:08 --> Email Class Initialized
DEBUG - 2023-08-18 17:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:36:08 --> Controller Class Initialized
INFO - 2023-08-18 17:36:09 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:36:09 --> Helper loaded: form_helper
INFO - 2023-08-18 17:36:09 --> Form Validation Class Initialized
INFO - 2023-08-18 17:36:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:36:09 --> Final output sent to browser
DEBUG - 2023-08-18 17:36:09 --> Total execution time: 0.3842
INFO - 2023-08-18 17:36:11 --> Config Class Initialized
INFO - 2023-08-18 17:36:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:36:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:36:11 --> Utf8 Class Initialized
INFO - 2023-08-18 17:36:11 --> URI Class Initialized
INFO - 2023-08-18 17:36:11 --> Router Class Initialized
INFO - 2023-08-18 17:36:11 --> Output Class Initialized
INFO - 2023-08-18 17:36:11 --> Security Class Initialized
DEBUG - 2023-08-18 17:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:36:11 --> Input Class Initialized
INFO - 2023-08-18 17:36:11 --> Language Class Initialized
INFO - 2023-08-18 17:36:11 --> Loader Class Initialized
INFO - 2023-08-18 17:36:11 --> Helper loaded: url_helper
INFO - 2023-08-18 17:36:11 --> Helper loaded: file_helper
INFO - 2023-08-18 17:36:11 --> Database Driver Class Initialized
INFO - 2023-08-18 17:36:11 --> Email Class Initialized
DEBUG - 2023-08-18 17:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:36:11 --> Controller Class Initialized
INFO - 2023-08-18 17:36:11 --> Model "Services_model" initialized
INFO - 2023-08-18 17:36:11 --> Helper loaded: form_helper
INFO - 2023-08-18 17:36:11 --> Form Validation Class Initialized
INFO - 2023-08-18 17:36:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-18 17:36:11 --> Final output sent to browser
DEBUG - 2023-08-18 17:36:11 --> Total execution time: 0.4253
INFO - 2023-08-18 17:36:32 --> Config Class Initialized
INFO - 2023-08-18 17:36:32 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:36:32 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:36:32 --> Utf8 Class Initialized
INFO - 2023-08-18 17:36:32 --> URI Class Initialized
INFO - 2023-08-18 17:36:32 --> Router Class Initialized
INFO - 2023-08-18 17:36:32 --> Output Class Initialized
INFO - 2023-08-18 17:36:32 --> Security Class Initialized
DEBUG - 2023-08-18 17:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:36:32 --> Input Class Initialized
INFO - 2023-08-18 17:36:32 --> Language Class Initialized
INFO - 2023-08-18 17:36:32 --> Loader Class Initialized
INFO - 2023-08-18 17:36:32 --> Helper loaded: url_helper
INFO - 2023-08-18 17:36:32 --> Helper loaded: file_helper
INFO - 2023-08-18 17:36:32 --> Database Driver Class Initialized
INFO - 2023-08-18 17:36:32 --> Email Class Initialized
DEBUG - 2023-08-18 17:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:36:32 --> Controller Class Initialized
INFO - 2023-08-18 17:36:32 --> Model "Services_model" initialized
INFO - 2023-08-18 17:36:32 --> Helper loaded: form_helper
INFO - 2023-08-18 17:36:32 --> Form Validation Class Initialized
INFO - 2023-08-18 17:36:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:36:32 --> Config Class Initialized
INFO - 2023-08-18 17:36:32 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:36:32 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:36:32 --> Utf8 Class Initialized
INFO - 2023-08-18 17:36:32 --> URI Class Initialized
INFO - 2023-08-18 17:36:32 --> Router Class Initialized
INFO - 2023-08-18 17:36:32 --> Output Class Initialized
INFO - 2023-08-18 17:36:32 --> Security Class Initialized
DEBUG - 2023-08-18 17:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:36:33 --> Input Class Initialized
INFO - 2023-08-18 17:36:33 --> Language Class Initialized
INFO - 2023-08-18 17:36:33 --> Loader Class Initialized
INFO - 2023-08-18 17:36:33 --> Helper loaded: url_helper
INFO - 2023-08-18 17:36:33 --> Helper loaded: file_helper
INFO - 2023-08-18 17:36:33 --> Database Driver Class Initialized
INFO - 2023-08-18 17:36:33 --> Email Class Initialized
DEBUG - 2023-08-18 17:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:36:33 --> Controller Class Initialized
INFO - 2023-08-18 17:36:33 --> Model "Services_model" initialized
INFO - 2023-08-18 17:36:33 --> Helper loaded: form_helper
INFO - 2023-08-18 17:36:33 --> Form Validation Class Initialized
INFO - 2023-08-18 17:36:33 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-18 17:36:33 --> Final output sent to browser
DEBUG - 2023-08-18 17:36:33 --> Total execution time: 0.5425
INFO - 2023-08-18 17:36:33 --> Config Class Initialized
INFO - 2023-08-18 17:36:33 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:36:33 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:36:33 --> Utf8 Class Initialized
INFO - 2023-08-18 17:36:33 --> URI Class Initialized
INFO - 2023-08-18 17:36:33 --> Router Class Initialized
INFO - 2023-08-18 17:36:33 --> Output Class Initialized
INFO - 2023-08-18 17:36:33 --> Security Class Initialized
DEBUG - 2023-08-18 17:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:36:34 --> Input Class Initialized
INFO - 2023-08-18 17:36:34 --> Language Class Initialized
ERROR - 2023-08-18 17:36:34 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:36:36 --> Config Class Initialized
INFO - 2023-08-18 17:36:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:36:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:36:36 --> Utf8 Class Initialized
INFO - 2023-08-18 17:36:36 --> URI Class Initialized
INFO - 2023-08-18 17:36:36 --> Router Class Initialized
INFO - 2023-08-18 17:36:36 --> Output Class Initialized
INFO - 2023-08-18 17:36:36 --> Security Class Initialized
DEBUG - 2023-08-18 17:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:36:36 --> Input Class Initialized
INFO - 2023-08-18 17:36:36 --> Language Class Initialized
INFO - 2023-08-18 17:36:36 --> Loader Class Initialized
INFO - 2023-08-18 17:36:36 --> Helper loaded: url_helper
INFO - 2023-08-18 17:36:37 --> Helper loaded: file_helper
INFO - 2023-08-18 17:36:37 --> Database Driver Class Initialized
INFO - 2023-08-18 17:36:37 --> Email Class Initialized
DEBUG - 2023-08-18 17:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:36:37 --> Controller Class Initialized
INFO - 2023-08-18 17:36:37 --> Model "Services_model" initialized
INFO - 2023-08-18 17:36:37 --> Helper loaded: form_helper
INFO - 2023-08-18 17:36:37 --> Form Validation Class Initialized
INFO - 2023-08-18 17:36:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-18 17:36:38 --> Final output sent to browser
DEBUG - 2023-08-18 17:36:38 --> Total execution time: 1.4365
INFO - 2023-08-18 17:36:38 --> Config Class Initialized
INFO - 2023-08-18 17:36:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:36:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:36:38 --> Utf8 Class Initialized
INFO - 2023-08-18 17:36:38 --> URI Class Initialized
INFO - 2023-08-18 17:36:38 --> Router Class Initialized
INFO - 2023-08-18 17:36:38 --> Output Class Initialized
INFO - 2023-08-18 17:36:38 --> Security Class Initialized
DEBUG - 2023-08-18 17:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:36:38 --> Input Class Initialized
INFO - 2023-08-18 17:36:38 --> Language Class Initialized
INFO - 2023-08-18 17:36:38 --> Loader Class Initialized
INFO - 2023-08-18 17:36:38 --> Helper loaded: url_helper
INFO - 2023-08-18 17:36:38 --> Helper loaded: file_helper
INFO - 2023-08-18 17:36:38 --> Database Driver Class Initialized
INFO - 2023-08-18 17:36:38 --> Email Class Initialized
DEBUG - 2023-08-18 17:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:36:38 --> Controller Class Initialized
INFO - 2023-08-18 17:36:38 --> Model "Services_model" initialized
INFO - 2023-08-18 17:36:38 --> Helper loaded: form_helper
INFO - 2023-08-18 17:36:38 --> Form Validation Class Initialized
ERROR - 2023-08-18 17:36:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-18 17:36:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-18 17:36:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-18 17:36:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 75
ERROR - 2023-08-18 17:36:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 76
ERROR - 2023-08-18 17:36:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 77
ERROR - 2023-08-18 17:36:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-08-18 17:36:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 100
INFO - 2023-08-18 17:36:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-18 17:36:39 --> Final output sent to browser
DEBUG - 2023-08-18 17:36:39 --> Total execution time: 0.5174
INFO - 2023-08-18 17:36:57 --> Config Class Initialized
INFO - 2023-08-18 17:36:57 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:36:57 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:36:57 --> Utf8 Class Initialized
INFO - 2023-08-18 17:36:57 --> URI Class Initialized
INFO - 2023-08-18 17:36:57 --> Router Class Initialized
INFO - 2023-08-18 17:36:57 --> Output Class Initialized
INFO - 2023-08-18 17:36:57 --> Security Class Initialized
DEBUG - 2023-08-18 17:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:36:57 --> Input Class Initialized
INFO - 2023-08-18 17:36:57 --> Language Class Initialized
INFO - 2023-08-18 17:36:57 --> Loader Class Initialized
INFO - 2023-08-18 17:36:57 --> Helper loaded: url_helper
INFO - 2023-08-18 17:36:57 --> Helper loaded: file_helper
INFO - 2023-08-18 17:36:57 --> Database Driver Class Initialized
INFO - 2023-08-18 17:36:57 --> Email Class Initialized
DEBUG - 2023-08-18 17:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:36:57 --> Controller Class Initialized
INFO - 2023-08-18 17:36:57 --> Model "Services_model" initialized
INFO - 2023-08-18 17:36:57 --> Helper loaded: form_helper
INFO - 2023-08-18 17:36:57 --> Form Validation Class Initialized
INFO - 2023-08-18 17:36:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:36:57 --> Config Class Initialized
INFO - 2023-08-18 17:36:57 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:36:57 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:36:58 --> Utf8 Class Initialized
INFO - 2023-08-18 17:36:58 --> URI Class Initialized
INFO - 2023-08-18 17:36:58 --> Router Class Initialized
INFO - 2023-08-18 17:36:58 --> Output Class Initialized
INFO - 2023-08-18 17:36:58 --> Security Class Initialized
DEBUG - 2023-08-18 17:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:36:58 --> Input Class Initialized
INFO - 2023-08-18 17:36:58 --> Language Class Initialized
INFO - 2023-08-18 17:36:58 --> Loader Class Initialized
INFO - 2023-08-18 17:36:58 --> Helper loaded: url_helper
INFO - 2023-08-18 17:36:58 --> Helper loaded: file_helper
INFO - 2023-08-18 17:36:58 --> Database Driver Class Initialized
INFO - 2023-08-18 17:36:58 --> Email Class Initialized
DEBUG - 2023-08-18 17:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:36:58 --> Controller Class Initialized
INFO - 2023-08-18 17:36:58 --> Model "Services_model" initialized
INFO - 2023-08-18 17:36:58 --> Helper loaded: form_helper
INFO - 2023-08-18 17:36:58 --> Form Validation Class Initialized
INFO - 2023-08-18 17:36:58 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-18 17:36:58 --> Final output sent to browser
DEBUG - 2023-08-18 17:36:58 --> Total execution time: 0.4841
INFO - 2023-08-18 17:36:58 --> Config Class Initialized
INFO - 2023-08-18 17:36:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:36:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:36:58 --> Utf8 Class Initialized
INFO - 2023-08-18 17:36:58 --> URI Class Initialized
INFO - 2023-08-18 17:36:58 --> Router Class Initialized
INFO - 2023-08-18 17:36:58 --> Output Class Initialized
INFO - 2023-08-18 17:36:58 --> Security Class Initialized
DEBUG - 2023-08-18 17:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:36:59 --> Input Class Initialized
INFO - 2023-08-18 17:36:59 --> Language Class Initialized
ERROR - 2023-08-18 17:36:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:37:10 --> Config Class Initialized
INFO - 2023-08-18 17:37:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:37:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:37:10 --> Utf8 Class Initialized
INFO - 2023-08-18 17:37:10 --> URI Class Initialized
INFO - 2023-08-18 17:37:10 --> Router Class Initialized
INFO - 2023-08-18 17:37:10 --> Output Class Initialized
INFO - 2023-08-18 17:37:10 --> Security Class Initialized
DEBUG - 2023-08-18 17:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:37:10 --> Input Class Initialized
INFO - 2023-08-18 17:37:10 --> Language Class Initialized
INFO - 2023-08-18 17:37:10 --> Loader Class Initialized
INFO - 2023-08-18 17:37:10 --> Helper loaded: url_helper
INFO - 2023-08-18 17:37:10 --> Helper loaded: file_helper
INFO - 2023-08-18 17:37:10 --> Database Driver Class Initialized
INFO - 2023-08-18 17:37:10 --> Email Class Initialized
DEBUG - 2023-08-18 17:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:37:10 --> Controller Class Initialized
INFO - 2023-08-18 17:37:10 --> Model "Services_model" initialized
INFO - 2023-08-18 17:37:10 --> Helper loaded: form_helper
INFO - 2023-08-18 17:37:10 --> Form Validation Class Initialized
INFO - 2023-08-18 17:37:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-18 17:37:10 --> Final output sent to browser
DEBUG - 2023-08-18 17:37:10 --> Total execution time: 0.3729
INFO - 2023-08-18 17:37:11 --> Config Class Initialized
INFO - 2023-08-18 17:37:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:37:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:37:11 --> Utf8 Class Initialized
INFO - 2023-08-18 17:37:11 --> URI Class Initialized
INFO - 2023-08-18 17:37:11 --> Router Class Initialized
INFO - 2023-08-18 17:37:11 --> Output Class Initialized
INFO - 2023-08-18 17:37:11 --> Security Class Initialized
DEBUG - 2023-08-18 17:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:37:11 --> Input Class Initialized
INFO - 2023-08-18 17:37:11 --> Language Class Initialized
INFO - 2023-08-18 17:37:11 --> Loader Class Initialized
INFO - 2023-08-18 17:37:11 --> Helper loaded: url_helper
INFO - 2023-08-18 17:37:11 --> Helper loaded: file_helper
INFO - 2023-08-18 17:37:11 --> Database Driver Class Initialized
INFO - 2023-08-18 17:37:11 --> Email Class Initialized
DEBUG - 2023-08-18 17:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:37:11 --> Controller Class Initialized
INFO - 2023-08-18 17:37:11 --> Model "Services_model" initialized
INFO - 2023-08-18 17:37:11 --> Helper loaded: form_helper
INFO - 2023-08-18 17:37:11 --> Form Validation Class Initialized
ERROR - 2023-08-18 17:37:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
INFO - 2023-08-18 17:37:11 --> Config Class Initialized
INFO - 2023-08-18 17:37:11 --> Hooks Class Initialized
ERROR - 2023-08-18 17:37:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-18 17:37:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
DEBUG - 2023-08-18 17:37:11 --> UTF-8 Support Enabled
ERROR - 2023-08-18 17:37:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 75
INFO - 2023-08-18 17:37:11 --> Utf8 Class Initialized
ERROR - 2023-08-18 17:37:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 76
INFO - 2023-08-18 17:37:11 --> URI Class Initialized
ERROR - 2023-08-18 17:37:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 77
INFO - 2023-08-18 17:37:11 --> Router Class Initialized
ERROR - 2023-08-18 17:37:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
INFO - 2023-08-18 17:37:11 --> Output Class Initialized
ERROR - 2023-08-18 17:37:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 100
INFO - 2023-08-18 17:37:11 --> Security Class Initialized
INFO - 2023-08-18 17:37:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
DEBUG - 2023-08-18 17:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:37:12 --> Final output sent to browser
INFO - 2023-08-18 17:37:12 --> Input Class Initialized
INFO - 2023-08-18 17:37:12 --> Language Class Initialized
DEBUG - 2023-08-18 17:37:12 --> Total execution time: 0.7100
INFO - 2023-08-18 17:37:12 --> Loader Class Initialized
INFO - 2023-08-18 17:37:12 --> Helper loaded: url_helper
INFO - 2023-08-18 17:37:12 --> Helper loaded: file_helper
INFO - 2023-08-18 17:37:12 --> Database Driver Class Initialized
INFO - 2023-08-18 17:37:12 --> Email Class Initialized
DEBUG - 2023-08-18 17:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:37:12 --> Controller Class Initialized
INFO - 2023-08-18 17:37:12 --> Model "Services_model" initialized
INFO - 2023-08-18 17:37:12 --> Helper loaded: form_helper
INFO - 2023-08-18 17:37:12 --> Form Validation Class Initialized
INFO - 2023-08-18 17:37:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-18 17:37:12 --> Final output sent to browser
DEBUG - 2023-08-18 17:37:12 --> Total execution time: 0.7402
INFO - 2023-08-18 17:37:13 --> Config Class Initialized
INFO - 2023-08-18 17:37:13 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:37:13 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:37:13 --> Utf8 Class Initialized
INFO - 2023-08-18 17:37:13 --> URI Class Initialized
INFO - 2023-08-18 17:37:13 --> Router Class Initialized
INFO - 2023-08-18 17:37:13 --> Output Class Initialized
INFO - 2023-08-18 17:37:13 --> Security Class Initialized
DEBUG - 2023-08-18 17:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:37:13 --> Input Class Initialized
INFO - 2023-08-18 17:37:13 --> Language Class Initialized
INFO - 2023-08-18 17:37:13 --> Loader Class Initialized
INFO - 2023-08-18 17:37:13 --> Helper loaded: url_helper
INFO - 2023-08-18 17:37:13 --> Helper loaded: file_helper
INFO - 2023-08-18 17:37:13 --> Database Driver Class Initialized
INFO - 2023-08-18 17:37:13 --> Email Class Initialized
DEBUG - 2023-08-18 17:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:37:13 --> Controller Class Initialized
INFO - 2023-08-18 17:37:13 --> Model "Services_model" initialized
INFO - 2023-08-18 17:37:13 --> Helper loaded: form_helper
INFO - 2023-08-18 17:37:13 --> Form Validation Class Initialized
INFO - 2023-08-18 17:37:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-18 17:37:13 --> Final output sent to browser
DEBUG - 2023-08-18 17:37:13 --> Total execution time: 0.4243
INFO - 2023-08-18 17:37:15 --> Config Class Initialized
INFO - 2023-08-18 17:37:15 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:37:15 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:37:15 --> Utf8 Class Initialized
INFO - 2023-08-18 17:37:15 --> URI Class Initialized
INFO - 2023-08-18 17:37:15 --> Router Class Initialized
INFO - 2023-08-18 17:37:15 --> Output Class Initialized
INFO - 2023-08-18 17:37:15 --> Security Class Initialized
DEBUG - 2023-08-18 17:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:37:15 --> Input Class Initialized
INFO - 2023-08-18 17:37:15 --> Language Class Initialized
INFO - 2023-08-18 17:37:15 --> Loader Class Initialized
INFO - 2023-08-18 17:37:15 --> Helper loaded: url_helper
INFO - 2023-08-18 17:37:15 --> Helper loaded: file_helper
INFO - 2023-08-18 17:37:15 --> Database Driver Class Initialized
INFO - 2023-08-18 17:37:15 --> Email Class Initialized
DEBUG - 2023-08-18 17:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:37:15 --> Controller Class Initialized
INFO - 2023-08-18 17:37:15 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:37:15 --> Helper loaded: form_helper
INFO - 2023-08-18 17:37:15 --> Form Validation Class Initialized
INFO - 2023-08-18 17:37:15 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:37:15 --> Final output sent to browser
DEBUG - 2023-08-18 17:37:15 --> Total execution time: 0.3999
INFO - 2023-08-18 17:37:22 --> Config Class Initialized
INFO - 2023-08-18 17:37:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:37:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:37:22 --> Utf8 Class Initialized
INFO - 2023-08-18 17:37:22 --> URI Class Initialized
INFO - 2023-08-18 17:37:22 --> Router Class Initialized
INFO - 2023-08-18 17:37:22 --> Output Class Initialized
INFO - 2023-08-18 17:37:22 --> Security Class Initialized
DEBUG - 2023-08-18 17:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:37:22 --> Input Class Initialized
INFO - 2023-08-18 17:37:22 --> Language Class Initialized
INFO - 2023-08-18 17:37:22 --> Loader Class Initialized
INFO - 2023-08-18 17:37:22 --> Helper loaded: url_helper
INFO - 2023-08-18 17:37:22 --> Helper loaded: file_helper
INFO - 2023-08-18 17:37:22 --> Database Driver Class Initialized
INFO - 2023-08-18 17:37:22 --> Email Class Initialized
DEBUG - 2023-08-18 17:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:37:22 --> Controller Class Initialized
INFO - 2023-08-18 17:37:22 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:37:22 --> Helper loaded: form_helper
INFO - 2023-08-18 17:37:22 --> Form Validation Class Initialized
INFO - 2023-08-18 17:37:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-08-18 17:37:22 --> Final output sent to browser
DEBUG - 2023-08-18 17:37:22 --> Total execution time: 0.3879
INFO - 2023-08-18 17:37:38 --> Config Class Initialized
INFO - 2023-08-18 17:37:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:37:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:37:38 --> Utf8 Class Initialized
INFO - 2023-08-18 17:37:38 --> URI Class Initialized
INFO - 2023-08-18 17:37:38 --> Router Class Initialized
INFO - 2023-08-18 17:37:38 --> Output Class Initialized
INFO - 2023-08-18 17:37:38 --> Security Class Initialized
DEBUG - 2023-08-18 17:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:37:38 --> Input Class Initialized
INFO - 2023-08-18 17:37:38 --> Language Class Initialized
INFO - 2023-08-18 17:37:38 --> Loader Class Initialized
INFO - 2023-08-18 17:37:38 --> Helper loaded: url_helper
INFO - 2023-08-18 17:37:38 --> Helper loaded: file_helper
INFO - 2023-08-18 17:37:38 --> Database Driver Class Initialized
INFO - 2023-08-18 17:37:38 --> Email Class Initialized
DEBUG - 2023-08-18 17:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:37:38 --> Controller Class Initialized
INFO - 2023-08-18 17:37:38 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:37:38 --> Helper loaded: form_helper
INFO - 2023-08-18 17:37:38 --> Form Validation Class Initialized
INFO - 2023-08-18 17:37:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:37:38 --> Config Class Initialized
INFO - 2023-08-18 17:37:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:37:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:37:38 --> Utf8 Class Initialized
INFO - 2023-08-18 17:37:38 --> URI Class Initialized
INFO - 2023-08-18 17:37:38 --> Router Class Initialized
INFO - 2023-08-18 17:37:38 --> Output Class Initialized
INFO - 2023-08-18 17:37:38 --> Security Class Initialized
DEBUG - 2023-08-18 17:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:37:38 --> Input Class Initialized
INFO - 2023-08-18 17:37:38 --> Language Class Initialized
INFO - 2023-08-18 17:37:38 --> Loader Class Initialized
INFO - 2023-08-18 17:37:38 --> Helper loaded: url_helper
INFO - 2023-08-18 17:37:38 --> Helper loaded: file_helper
INFO - 2023-08-18 17:37:38 --> Database Driver Class Initialized
INFO - 2023-08-18 17:37:39 --> Email Class Initialized
DEBUG - 2023-08-18 17:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:37:39 --> Controller Class Initialized
INFO - 2023-08-18 17:37:39 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:37:39 --> Helper loaded: form_helper
INFO - 2023-08-18 17:37:39 --> Form Validation Class Initialized
INFO - 2023-08-18 17:37:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:37:39 --> Final output sent to browser
DEBUG - 2023-08-18 17:37:39 --> Total execution time: 0.5046
INFO - 2023-08-18 17:37:39 --> Config Class Initialized
INFO - 2023-08-18 17:37:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:37:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:37:39 --> Utf8 Class Initialized
INFO - 2023-08-18 17:37:39 --> URI Class Initialized
INFO - 2023-08-18 17:37:39 --> Router Class Initialized
INFO - 2023-08-18 17:37:39 --> Output Class Initialized
INFO - 2023-08-18 17:37:39 --> Security Class Initialized
DEBUG - 2023-08-18 17:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:37:39 --> Input Class Initialized
INFO - 2023-08-18 17:37:39 --> Language Class Initialized
ERROR - 2023-08-18 17:37:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:38:30 --> Config Class Initialized
INFO - 2023-08-18 17:38:30 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:38:30 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:38:30 --> Utf8 Class Initialized
INFO - 2023-08-18 17:38:30 --> URI Class Initialized
INFO - 2023-08-18 17:38:30 --> Router Class Initialized
INFO - 2023-08-18 17:38:30 --> Output Class Initialized
INFO - 2023-08-18 17:38:30 --> Security Class Initialized
DEBUG - 2023-08-18 17:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:38:30 --> Input Class Initialized
INFO - 2023-08-18 17:38:30 --> Language Class Initialized
ERROR - 2023-08-18 17:38:30 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-18 17:38:30 --> Config Class Initialized
INFO - 2023-08-18 17:38:30 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:38:30 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:38:30 --> Utf8 Class Initialized
INFO - 2023-08-18 17:38:31 --> URI Class Initialized
INFO - 2023-08-18 17:38:31 --> Router Class Initialized
INFO - 2023-08-18 17:38:31 --> Output Class Initialized
INFO - 2023-08-18 17:38:31 --> Security Class Initialized
DEBUG - 2023-08-18 17:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:38:31 --> Input Class Initialized
INFO - 2023-08-18 17:38:32 --> Language Class Initialized
ERROR - 2023-08-18 17:38:32 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-18 17:39:12 --> Config Class Initialized
INFO - 2023-08-18 17:39:12 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:39:12 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:39:12 --> Utf8 Class Initialized
INFO - 2023-08-18 17:39:12 --> URI Class Initialized
INFO - 2023-08-18 17:39:12 --> Router Class Initialized
INFO - 2023-08-18 17:39:12 --> Output Class Initialized
INFO - 2023-08-18 17:39:12 --> Security Class Initialized
DEBUG - 2023-08-18 17:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:39:12 --> Input Class Initialized
INFO - 2023-08-18 17:39:12 --> Language Class Initialized
INFO - 2023-08-18 17:39:12 --> Loader Class Initialized
INFO - 2023-08-18 17:39:12 --> Helper loaded: url_helper
INFO - 2023-08-18 17:39:12 --> Helper loaded: file_helper
INFO - 2023-08-18 17:39:12 --> Database Driver Class Initialized
INFO - 2023-08-18 17:39:12 --> Email Class Initialized
DEBUG - 2023-08-18 17:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:39:12 --> Controller Class Initialized
INFO - 2023-08-18 17:39:12 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:39:12 --> Helper loaded: form_helper
INFO - 2023-08-18 17:39:12 --> Form Validation Class Initialized
INFO - 2023-08-18 17:39:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-08-18 17:39:12 --> Final output sent to browser
DEBUG - 2023-08-18 17:39:12 --> Total execution time: 0.4357
INFO - 2023-08-18 17:39:14 --> Config Class Initialized
INFO - 2023-08-18 17:39:14 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:39:14 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:39:15 --> Utf8 Class Initialized
INFO - 2023-08-18 17:39:15 --> URI Class Initialized
INFO - 2023-08-18 17:39:15 --> Router Class Initialized
INFO - 2023-08-18 17:39:15 --> Output Class Initialized
INFO - 2023-08-18 17:39:15 --> Security Class Initialized
DEBUG - 2023-08-18 17:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:39:15 --> Input Class Initialized
INFO - 2023-08-18 17:39:15 --> Language Class Initialized
ERROR - 2023-08-18 17:39:15 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-18 17:39:15 --> Config Class Initialized
INFO - 2023-08-18 17:39:15 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:39:15 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:39:15 --> Utf8 Class Initialized
INFO - 2023-08-18 17:39:15 --> URI Class Initialized
INFO - 2023-08-18 17:39:15 --> Router Class Initialized
INFO - 2023-08-18 17:39:15 --> Output Class Initialized
INFO - 2023-08-18 17:39:15 --> Security Class Initialized
DEBUG - 2023-08-18 17:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:39:15 --> Input Class Initialized
INFO - 2023-08-18 17:39:15 --> Language Class Initialized
ERROR - 2023-08-18 17:39:15 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-18 17:39:31 --> Config Class Initialized
INFO - 2023-08-18 17:39:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:39:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:39:31 --> Utf8 Class Initialized
INFO - 2023-08-18 17:39:31 --> URI Class Initialized
INFO - 2023-08-18 17:39:31 --> Router Class Initialized
INFO - 2023-08-18 17:39:31 --> Output Class Initialized
INFO - 2023-08-18 17:39:31 --> Security Class Initialized
DEBUG - 2023-08-18 17:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:39:31 --> Input Class Initialized
INFO - 2023-08-18 17:39:31 --> Language Class Initialized
INFO - 2023-08-18 17:39:31 --> Loader Class Initialized
INFO - 2023-08-18 17:39:32 --> Helper loaded: url_helper
INFO - 2023-08-18 17:39:32 --> Helper loaded: file_helper
INFO - 2023-08-18 17:39:32 --> Database Driver Class Initialized
INFO - 2023-08-18 17:39:32 --> Email Class Initialized
DEBUG - 2023-08-18 17:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:39:32 --> Controller Class Initialized
INFO - 2023-08-18 17:39:32 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:39:32 --> Helper loaded: form_helper
INFO - 2023-08-18 17:39:32 --> Form Validation Class Initialized
INFO - 2023-08-18 17:39:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:39:32 --> Config Class Initialized
INFO - 2023-08-18 17:39:32 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:39:32 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:39:32 --> Utf8 Class Initialized
INFO - 2023-08-18 17:39:32 --> URI Class Initialized
INFO - 2023-08-18 17:39:32 --> Router Class Initialized
INFO - 2023-08-18 17:39:32 --> Output Class Initialized
INFO - 2023-08-18 17:39:32 --> Security Class Initialized
DEBUG - 2023-08-18 17:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:39:32 --> Input Class Initialized
INFO - 2023-08-18 17:39:33 --> Language Class Initialized
INFO - 2023-08-18 17:39:33 --> Loader Class Initialized
INFO - 2023-08-18 17:39:33 --> Helper loaded: url_helper
INFO - 2023-08-18 17:39:33 --> Helper loaded: file_helper
INFO - 2023-08-18 17:39:33 --> Database Driver Class Initialized
INFO - 2023-08-18 17:39:33 --> Email Class Initialized
DEBUG - 2023-08-18 17:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:39:33 --> Controller Class Initialized
INFO - 2023-08-18 17:39:33 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:39:33 --> Helper loaded: form_helper
INFO - 2023-08-18 17:39:33 --> Form Validation Class Initialized
INFO - 2023-08-18 17:39:33 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:39:33 --> Final output sent to browser
DEBUG - 2023-08-18 17:39:33 --> Total execution time: 0.6874
INFO - 2023-08-18 17:39:34 --> Config Class Initialized
INFO - 2023-08-18 17:39:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:39:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:39:34 --> Utf8 Class Initialized
INFO - 2023-08-18 17:39:34 --> URI Class Initialized
INFO - 2023-08-18 17:39:34 --> Router Class Initialized
INFO - 2023-08-18 17:39:34 --> Output Class Initialized
INFO - 2023-08-18 17:39:34 --> Security Class Initialized
DEBUG - 2023-08-18 17:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:39:34 --> Input Class Initialized
INFO - 2023-08-18 17:39:34 --> Language Class Initialized
ERROR - 2023-08-18 17:39:34 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:39:36 --> Config Class Initialized
INFO - 2023-08-18 17:39:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:39:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:39:36 --> Utf8 Class Initialized
INFO - 2023-08-18 17:39:36 --> URI Class Initialized
INFO - 2023-08-18 17:39:36 --> Router Class Initialized
INFO - 2023-08-18 17:39:36 --> Output Class Initialized
INFO - 2023-08-18 17:39:36 --> Security Class Initialized
DEBUG - 2023-08-18 17:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:39:36 --> Input Class Initialized
INFO - 2023-08-18 17:39:36 --> Language Class Initialized
INFO - 2023-08-18 17:39:36 --> Loader Class Initialized
INFO - 2023-08-18 17:39:36 --> Helper loaded: url_helper
INFO - 2023-08-18 17:39:36 --> Helper loaded: file_helper
INFO - 2023-08-18 17:39:36 --> Database Driver Class Initialized
INFO - 2023-08-18 17:39:37 --> Email Class Initialized
DEBUG - 2023-08-18 17:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:39:37 --> Controller Class Initialized
INFO - 2023-08-18 17:39:37 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:39:37 --> Helper loaded: form_helper
INFO - 2023-08-18 17:39:37 --> Form Validation Class Initialized
INFO - 2023-08-18 17:39:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_edit.php
INFO - 2023-08-18 17:39:37 --> Final output sent to browser
DEBUG - 2023-08-18 17:39:37 --> Total execution time: 0.5928
INFO - 2023-08-18 17:39:37 --> Config Class Initialized
INFO - 2023-08-18 17:39:37 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:39:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:39:37 --> Utf8 Class Initialized
INFO - 2023-08-18 17:39:37 --> URI Class Initialized
INFO - 2023-08-18 17:39:37 --> Router Class Initialized
INFO - 2023-08-18 17:39:37 --> Output Class Initialized
INFO - 2023-08-18 17:39:37 --> Security Class Initialized
DEBUG - 2023-08-18 17:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:39:37 --> Input Class Initialized
INFO - 2023-08-18 17:39:37 --> Language Class Initialized
ERROR - 2023-08-18 17:39:38 --> 404 Page Not Found: admin/Training_curriculum/edit
INFO - 2023-08-18 17:39:49 --> Config Class Initialized
INFO - 2023-08-18 17:39:49 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:39:49 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:39:49 --> Utf8 Class Initialized
INFO - 2023-08-18 17:39:49 --> URI Class Initialized
INFO - 2023-08-18 17:39:49 --> Router Class Initialized
INFO - 2023-08-18 17:39:49 --> Output Class Initialized
INFO - 2023-08-18 17:39:49 --> Security Class Initialized
DEBUG - 2023-08-18 17:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:39:49 --> Input Class Initialized
INFO - 2023-08-18 17:39:49 --> Language Class Initialized
INFO - 2023-08-18 17:39:49 --> Loader Class Initialized
INFO - 2023-08-18 17:39:49 --> Helper loaded: url_helper
INFO - 2023-08-18 17:39:49 --> Helper loaded: file_helper
INFO - 2023-08-18 17:39:49 --> Database Driver Class Initialized
INFO - 2023-08-18 17:39:49 --> Email Class Initialized
DEBUG - 2023-08-18 17:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:39:49 --> Controller Class Initialized
INFO - 2023-08-18 17:39:49 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:39:49 --> Helper loaded: form_helper
INFO - 2023-08-18 17:39:49 --> Form Validation Class Initialized
INFO - 2023-08-18 17:39:49 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-18 17:39:49 --> Severity: Warning --> Undefined variable $curriculum C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 39
ERROR - 2023-08-18 17:39:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 39
ERROR - 2023-08-18 17:39:50 --> Severity: Warning --> Undefined variable $curriculum C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 46
ERROR - 2023-08-18 17:39:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 46
ERROR - 2023-08-18 17:39:50 --> Severity: Warning --> Undefined variable $curriculum C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 56
ERROR - 2023-08-18 17:39:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 56
ERROR - 2023-08-18 17:39:50 --> Severity: Warning --> Undefined variable $curriculum C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 71
ERROR - 2023-08-18 17:39:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 71
ERROR - 2023-08-18 17:39:50 --> Severity: Warning --> Undefined variable $curriculum C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 85
ERROR - 2023-08-18 17:39:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 85
ERROR - 2023-08-18 17:39:50 --> Severity: Warning --> Undefined variable $curriculum C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 86
ERROR - 2023-08-18 17:39:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 86
ERROR - 2023-08-18 17:39:50 --> Severity: Warning --> Undefined variable $curriculum C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 87
ERROR - 2023-08-18 17:39:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 87
ERROR - 2023-08-18 17:39:50 --> Severity: Warning --> Undefined variable $curriculum C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 99
ERROR - 2023-08-18 17:39:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_curriculum_edit.php 99
INFO - 2023-08-18 17:39:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_edit.php
INFO - 2023-08-18 17:39:50 --> Final output sent to browser
DEBUG - 2023-08-18 17:39:50 --> Total execution time: 0.7916
INFO - 2023-08-18 17:39:50 --> Config Class Initialized
INFO - 2023-08-18 17:39:50 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:39:50 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:39:50 --> Utf8 Class Initialized
INFO - 2023-08-18 17:39:50 --> URI Class Initialized
INFO - 2023-08-18 17:39:50 --> Router Class Initialized
INFO - 2023-08-18 17:39:50 --> Output Class Initialized
INFO - 2023-08-18 17:39:50 --> Security Class Initialized
DEBUG - 2023-08-18 17:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:39:50 --> Input Class Initialized
INFO - 2023-08-18 17:39:50 --> Language Class Initialized
ERROR - 2023-08-18 17:39:50 --> 404 Page Not Found: admin/Training_curriculum/update
INFO - 2023-08-18 17:42:15 --> Config Class Initialized
INFO - 2023-08-18 17:42:15 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:42:15 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:42:15 --> Utf8 Class Initialized
INFO - 2023-08-18 17:42:15 --> URI Class Initialized
INFO - 2023-08-18 17:42:15 --> Router Class Initialized
INFO - 2023-08-18 17:42:15 --> Output Class Initialized
INFO - 2023-08-18 17:42:15 --> Security Class Initialized
DEBUG - 2023-08-18 17:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:42:15 --> Input Class Initialized
INFO - 2023-08-18 17:42:15 --> Language Class Initialized
INFO - 2023-08-18 17:42:15 --> Loader Class Initialized
INFO - 2023-08-18 17:42:15 --> Helper loaded: url_helper
INFO - 2023-08-18 17:42:15 --> Helper loaded: file_helper
INFO - 2023-08-18 17:42:15 --> Database Driver Class Initialized
INFO - 2023-08-18 17:42:15 --> Email Class Initialized
DEBUG - 2023-08-18 17:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:42:15 --> Controller Class Initialized
INFO - 2023-08-18 17:42:15 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:42:15 --> Helper loaded: form_helper
INFO - 2023-08-18 17:42:15 --> Form Validation Class Initialized
INFO - 2023-08-18 17:42:15 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_edit.php
INFO - 2023-08-18 17:42:15 --> Final output sent to browser
DEBUG - 2023-08-18 17:42:15 --> Total execution time: 0.8159
INFO - 2023-08-18 17:43:09 --> Config Class Initialized
INFO - 2023-08-18 17:43:09 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:43:09 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:43:09 --> Utf8 Class Initialized
INFO - 2023-08-18 17:43:09 --> URI Class Initialized
INFO - 2023-08-18 17:43:09 --> Router Class Initialized
INFO - 2023-08-18 17:43:09 --> Output Class Initialized
INFO - 2023-08-18 17:43:09 --> Security Class Initialized
DEBUG - 2023-08-18 17:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:43:09 --> Input Class Initialized
INFO - 2023-08-18 17:43:09 --> Language Class Initialized
INFO - 2023-08-18 17:43:09 --> Loader Class Initialized
INFO - 2023-08-18 17:43:09 --> Helper loaded: url_helper
INFO - 2023-08-18 17:43:09 --> Helper loaded: file_helper
INFO - 2023-08-18 17:43:09 --> Database Driver Class Initialized
INFO - 2023-08-18 17:43:09 --> Email Class Initialized
DEBUG - 2023-08-18 17:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:43:09 --> Controller Class Initialized
INFO - 2023-08-18 17:43:09 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:43:09 --> Helper loaded: form_helper
INFO - 2023-08-18 17:43:09 --> Form Validation Class Initialized
INFO - 2023-08-18 17:43:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_edit.php
INFO - 2023-08-18 17:43:10 --> Final output sent to browser
DEBUG - 2023-08-18 17:43:10 --> Total execution time: 0.4680
INFO - 2023-08-18 17:44:46 --> Config Class Initialized
INFO - 2023-08-18 17:44:46 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:44:46 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:44:46 --> Utf8 Class Initialized
INFO - 2023-08-18 17:44:46 --> URI Class Initialized
INFO - 2023-08-18 17:44:46 --> Router Class Initialized
INFO - 2023-08-18 17:44:46 --> Output Class Initialized
INFO - 2023-08-18 17:44:46 --> Security Class Initialized
DEBUG - 2023-08-18 17:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:44:46 --> Input Class Initialized
INFO - 2023-08-18 17:44:46 --> Language Class Initialized
INFO - 2023-08-18 17:44:46 --> Loader Class Initialized
INFO - 2023-08-18 17:44:46 --> Helper loaded: url_helper
INFO - 2023-08-18 17:44:46 --> Helper loaded: file_helper
INFO - 2023-08-18 17:44:46 --> Database Driver Class Initialized
INFO - 2023-08-18 17:44:46 --> Email Class Initialized
DEBUG - 2023-08-18 17:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:44:46 --> Controller Class Initialized
INFO - 2023-08-18 17:44:46 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:44:46 --> Helper loaded: form_helper
INFO - 2023-08-18 17:44:46 --> Form Validation Class Initialized
INFO - 2023-08-18 17:44:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_edit.php
INFO - 2023-08-18 17:44:47 --> Final output sent to browser
DEBUG - 2023-08-18 17:44:47 --> Total execution time: 0.9112
INFO - 2023-08-18 17:44:51 --> Config Class Initialized
INFO - 2023-08-18 17:44:51 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:44:51 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:44:51 --> Utf8 Class Initialized
INFO - 2023-08-18 17:44:51 --> URI Class Initialized
INFO - 2023-08-18 17:44:51 --> Router Class Initialized
INFO - 2023-08-18 17:44:51 --> Output Class Initialized
INFO - 2023-08-18 17:44:51 --> Security Class Initialized
DEBUG - 2023-08-18 17:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:44:51 --> Input Class Initialized
INFO - 2023-08-18 17:44:51 --> Language Class Initialized
ERROR - 2023-08-18 17:44:51 --> 404 Page Not Found: admin/Training_curriculum/edit
INFO - 2023-08-18 17:44:58 --> Config Class Initialized
INFO - 2023-08-18 17:44:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:44:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:44:58 --> Utf8 Class Initialized
INFO - 2023-08-18 17:44:58 --> URI Class Initialized
INFO - 2023-08-18 17:44:58 --> Router Class Initialized
INFO - 2023-08-18 17:44:58 --> Output Class Initialized
INFO - 2023-08-18 17:44:58 --> Security Class Initialized
DEBUG - 2023-08-18 17:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:44:58 --> Input Class Initialized
INFO - 2023-08-18 17:44:58 --> Language Class Initialized
INFO - 2023-08-18 17:44:58 --> Loader Class Initialized
INFO - 2023-08-18 17:44:58 --> Helper loaded: url_helper
INFO - 2023-08-18 17:44:58 --> Helper loaded: file_helper
INFO - 2023-08-18 17:44:58 --> Database Driver Class Initialized
INFO - 2023-08-18 17:44:58 --> Email Class Initialized
DEBUG - 2023-08-18 17:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:44:58 --> Controller Class Initialized
INFO - 2023-08-18 17:44:58 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:44:58 --> Helper loaded: form_helper
INFO - 2023-08-18 17:44:58 --> Form Validation Class Initialized
INFO - 2023-08-18 17:44:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:44:58 --> Config Class Initialized
INFO - 2023-08-18 17:44:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:44:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:44:58 --> Utf8 Class Initialized
INFO - 2023-08-18 17:44:58 --> URI Class Initialized
INFO - 2023-08-18 17:44:58 --> Router Class Initialized
INFO - 2023-08-18 17:44:58 --> Output Class Initialized
INFO - 2023-08-18 17:44:58 --> Security Class Initialized
DEBUG - 2023-08-18 17:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:44:58 --> Input Class Initialized
INFO - 2023-08-18 17:44:58 --> Language Class Initialized
INFO - 2023-08-18 17:44:58 --> Loader Class Initialized
INFO - 2023-08-18 17:44:58 --> Helper loaded: url_helper
INFO - 2023-08-18 17:44:58 --> Helper loaded: file_helper
INFO - 2023-08-18 17:44:59 --> Database Driver Class Initialized
INFO - 2023-08-18 17:44:59 --> Email Class Initialized
DEBUG - 2023-08-18 17:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:44:59 --> Controller Class Initialized
INFO - 2023-08-18 17:44:59 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:44:59 --> Helper loaded: form_helper
INFO - 2023-08-18 17:44:59 --> Form Validation Class Initialized
INFO - 2023-08-18 17:44:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:44:59 --> Final output sent to browser
DEBUG - 2023-08-18 17:44:59 --> Total execution time: 0.4912
INFO - 2023-08-18 17:44:59 --> Config Class Initialized
INFO - 2023-08-18 17:44:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:44:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:44:59 --> Utf8 Class Initialized
INFO - 2023-08-18 17:44:59 --> URI Class Initialized
INFO - 2023-08-18 17:45:00 --> Router Class Initialized
INFO - 2023-08-18 17:45:00 --> Output Class Initialized
INFO - 2023-08-18 17:45:00 --> Security Class Initialized
DEBUG - 2023-08-18 17:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:45:00 --> Input Class Initialized
INFO - 2023-08-18 17:45:00 --> Language Class Initialized
ERROR - 2023-08-18 17:45:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:45:00 --> Config Class Initialized
INFO - 2023-08-18 17:45:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:45:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:45:00 --> Utf8 Class Initialized
INFO - 2023-08-18 17:45:00 --> URI Class Initialized
INFO - 2023-08-18 17:45:00 --> Router Class Initialized
INFO - 2023-08-18 17:45:00 --> Output Class Initialized
INFO - 2023-08-18 17:45:00 --> Security Class Initialized
DEBUG - 2023-08-18 17:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:45:00 --> Input Class Initialized
INFO - 2023-08-18 17:45:00 --> Language Class Initialized
ERROR - 2023-08-18 17:45:00 --> 404 Page Not Found: admin/Training_curriculum/images
INFO - 2023-08-18 17:45:03 --> Config Class Initialized
INFO - 2023-08-18 17:45:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:45:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:45:03 --> Utf8 Class Initialized
INFO - 2023-08-18 17:45:03 --> URI Class Initialized
INFO - 2023-08-18 17:45:03 --> Router Class Initialized
INFO - 2023-08-18 17:45:03 --> Output Class Initialized
INFO - 2023-08-18 17:45:03 --> Security Class Initialized
DEBUG - 2023-08-18 17:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:45:03 --> Input Class Initialized
INFO - 2023-08-18 17:45:03 --> Language Class Initialized
INFO - 2023-08-18 17:45:03 --> Loader Class Initialized
INFO - 2023-08-18 17:45:03 --> Helper loaded: url_helper
INFO - 2023-08-18 17:45:03 --> Helper loaded: file_helper
INFO - 2023-08-18 17:45:03 --> Database Driver Class Initialized
INFO - 2023-08-18 17:45:03 --> Email Class Initialized
DEBUG - 2023-08-18 17:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:45:03 --> Controller Class Initialized
INFO - 2023-08-18 17:45:03 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:45:03 --> Helper loaded: form_helper
INFO - 2023-08-18 17:45:03 --> Form Validation Class Initialized
INFO - 2023-08-18 17:45:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_edit.php
INFO - 2023-08-18 17:45:03 --> Final output sent to browser
DEBUG - 2023-08-18 17:45:03 --> Total execution time: 0.3914
INFO - 2023-08-18 17:45:13 --> Config Class Initialized
INFO - 2023-08-18 17:45:13 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:45:13 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:45:13 --> Utf8 Class Initialized
INFO - 2023-08-18 17:45:13 --> URI Class Initialized
INFO - 2023-08-18 17:45:13 --> Router Class Initialized
INFO - 2023-08-18 17:45:13 --> Output Class Initialized
INFO - 2023-08-18 17:45:14 --> Security Class Initialized
DEBUG - 2023-08-18 17:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:45:14 --> Input Class Initialized
INFO - 2023-08-18 17:45:14 --> Language Class Initialized
INFO - 2023-08-18 17:45:14 --> Loader Class Initialized
INFO - 2023-08-18 17:45:14 --> Helper loaded: url_helper
INFO - 2023-08-18 17:45:14 --> Helper loaded: file_helper
INFO - 2023-08-18 17:45:14 --> Database Driver Class Initialized
INFO - 2023-08-18 17:45:14 --> Email Class Initialized
DEBUG - 2023-08-18 17:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:45:14 --> Controller Class Initialized
INFO - 2023-08-18 17:45:14 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:45:14 --> Helper loaded: form_helper
INFO - 2023-08-18 17:45:15 --> Form Validation Class Initialized
INFO - 2023-08-18 17:45:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:45:15 --> Config Class Initialized
INFO - 2023-08-18 17:45:15 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:45:15 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:45:15 --> Utf8 Class Initialized
INFO - 2023-08-18 17:45:15 --> URI Class Initialized
INFO - 2023-08-18 17:45:15 --> Router Class Initialized
INFO - 2023-08-18 17:45:15 --> Output Class Initialized
INFO - 2023-08-18 17:45:15 --> Security Class Initialized
DEBUG - 2023-08-18 17:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:45:15 --> Input Class Initialized
INFO - 2023-08-18 17:45:15 --> Language Class Initialized
INFO - 2023-08-18 17:45:15 --> Loader Class Initialized
INFO - 2023-08-18 17:45:15 --> Helper loaded: url_helper
INFO - 2023-08-18 17:45:15 --> Helper loaded: file_helper
INFO - 2023-08-18 17:45:15 --> Database Driver Class Initialized
INFO - 2023-08-18 17:45:15 --> Email Class Initialized
DEBUG - 2023-08-18 17:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:45:16 --> Controller Class Initialized
INFO - 2023-08-18 17:45:16 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:45:16 --> Helper loaded: form_helper
INFO - 2023-08-18 17:45:16 --> Form Validation Class Initialized
INFO - 2023-08-18 17:45:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:45:16 --> Final output sent to browser
DEBUG - 2023-08-18 17:45:16 --> Total execution time: 0.8833
INFO - 2023-08-18 17:45:16 --> Config Class Initialized
INFO - 2023-08-18 17:45:16 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:45:16 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:45:16 --> Utf8 Class Initialized
INFO - 2023-08-18 17:45:16 --> URI Class Initialized
INFO - 2023-08-18 17:45:16 --> Router Class Initialized
INFO - 2023-08-18 17:45:16 --> Output Class Initialized
INFO - 2023-08-18 17:45:16 --> Security Class Initialized
DEBUG - 2023-08-18 17:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:45:17 --> Input Class Initialized
INFO - 2023-08-18 17:45:17 --> Language Class Initialized
ERROR - 2023-08-18 17:45:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:45:37 --> Config Class Initialized
INFO - 2023-08-18 17:45:37 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:45:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:45:38 --> Utf8 Class Initialized
INFO - 2023-08-18 17:45:38 --> URI Class Initialized
INFO - 2023-08-18 17:45:38 --> Router Class Initialized
INFO - 2023-08-18 17:45:38 --> Output Class Initialized
INFO - 2023-08-18 17:45:38 --> Security Class Initialized
DEBUG - 2023-08-18 17:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:45:38 --> Input Class Initialized
INFO - 2023-08-18 17:45:38 --> Language Class Initialized
INFO - 2023-08-18 17:45:38 --> Loader Class Initialized
INFO - 2023-08-18 17:45:38 --> Helper loaded: url_helper
INFO - 2023-08-18 17:45:38 --> Helper loaded: file_helper
INFO - 2023-08-18 17:45:38 --> Database Driver Class Initialized
INFO - 2023-08-18 17:45:38 --> Email Class Initialized
DEBUG - 2023-08-18 17:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:45:38 --> Controller Class Initialized
INFO - 2023-08-18 17:45:38 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:45:38 --> Helper loaded: form_helper
INFO - 2023-08-18 17:45:38 --> Form Validation Class Initialized
INFO - 2023-08-18 17:45:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:45:38 --> Final output sent to browser
DEBUG - 2023-08-18 17:45:38 --> Total execution time: 0.8529
INFO - 2023-08-18 17:45:38 --> Config Class Initialized
INFO - 2023-08-18 17:45:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:45:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:45:38 --> Utf8 Class Initialized
INFO - 2023-08-18 17:45:38 --> URI Class Initialized
INFO - 2023-08-18 17:45:38 --> Router Class Initialized
INFO - 2023-08-18 17:45:38 --> Output Class Initialized
INFO - 2023-08-18 17:45:38 --> Security Class Initialized
DEBUG - 2023-08-18 17:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:45:38 --> Input Class Initialized
INFO - 2023-08-18 17:45:38 --> Language Class Initialized
ERROR - 2023-08-18 17:45:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 17:47:49 --> Config Class Initialized
INFO - 2023-08-18 17:47:49 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:47:49 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:47:50 --> Utf8 Class Initialized
INFO - 2023-08-18 17:47:50 --> URI Class Initialized
INFO - 2023-08-18 17:47:50 --> Router Class Initialized
INFO - 2023-08-18 17:47:50 --> Output Class Initialized
INFO - 2023-08-18 17:47:50 --> Security Class Initialized
DEBUG - 2023-08-18 17:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:47:50 --> Input Class Initialized
INFO - 2023-08-18 17:47:50 --> Language Class Initialized
INFO - 2023-08-18 17:47:50 --> Loader Class Initialized
INFO - 2023-08-18 17:47:50 --> Helper loaded: url_helper
INFO - 2023-08-18 17:47:50 --> Helper loaded: file_helper
INFO - 2023-08-18 17:47:50 --> Database Driver Class Initialized
INFO - 2023-08-18 17:47:50 --> Email Class Initialized
DEBUG - 2023-08-18 17:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:47:50 --> Controller Class Initialized
INFO - 2023-08-18 17:47:50 --> Model "Training_model" initialized
INFO - 2023-08-18 17:47:50 --> Helper loaded: form_helper
INFO - 2023-08-18 17:47:50 --> Form Validation Class Initialized
INFO - 2023-08-18 17:47:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-18 17:47:50 --> Final output sent to browser
DEBUG - 2023-08-18 17:47:50 --> Total execution time: 0.5965
INFO - 2023-08-18 17:47:56 --> Config Class Initialized
INFO - 2023-08-18 17:47:56 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:47:56 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:47:56 --> Utf8 Class Initialized
INFO - 2023-08-18 17:47:56 --> URI Class Initialized
INFO - 2023-08-18 17:47:56 --> Router Class Initialized
INFO - 2023-08-18 17:47:56 --> Output Class Initialized
INFO - 2023-08-18 17:47:56 --> Security Class Initialized
DEBUG - 2023-08-18 17:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:47:56 --> Input Class Initialized
INFO - 2023-08-18 17:47:56 --> Language Class Initialized
ERROR - 2023-08-18 17:47:56 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-18 17:48:01 --> Config Class Initialized
INFO - 2023-08-18 17:48:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:48:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:48:01 --> Utf8 Class Initialized
INFO - 2023-08-18 17:48:01 --> URI Class Initialized
INFO - 2023-08-18 17:48:01 --> Router Class Initialized
INFO - 2023-08-18 17:48:01 --> Output Class Initialized
INFO - 2023-08-18 17:48:01 --> Security Class Initialized
DEBUG - 2023-08-18 17:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:48:01 --> Input Class Initialized
INFO - 2023-08-18 17:48:01 --> Language Class Initialized
INFO - 2023-08-18 17:48:01 --> Loader Class Initialized
INFO - 2023-08-18 17:48:01 --> Helper loaded: url_helper
INFO - 2023-08-18 17:48:01 --> Helper loaded: file_helper
INFO - 2023-08-18 17:48:01 --> Database Driver Class Initialized
INFO - 2023-08-18 17:48:01 --> Email Class Initialized
DEBUG - 2023-08-18 17:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:48:01 --> Controller Class Initialized
INFO - 2023-08-18 17:48:01 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:48:01 --> Helper loaded: form_helper
INFO - 2023-08-18 17:48:01 --> Form Validation Class Initialized
INFO - 2023-08-18 17:48:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:48:01 --> Final output sent to browser
DEBUG - 2023-08-18 17:48:01 --> Total execution time: 0.0519
INFO - 2023-08-18 17:48:04 --> Config Class Initialized
INFO - 2023-08-18 17:48:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:48:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:48:04 --> Utf8 Class Initialized
INFO - 2023-08-18 17:48:04 --> URI Class Initialized
INFO - 2023-08-18 17:48:04 --> Router Class Initialized
INFO - 2023-08-18 17:48:04 --> Output Class Initialized
INFO - 2023-08-18 17:48:04 --> Security Class Initialized
DEBUG - 2023-08-18 17:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:48:04 --> Input Class Initialized
INFO - 2023-08-18 17:48:04 --> Language Class Initialized
INFO - 2023-08-18 17:48:04 --> Loader Class Initialized
INFO - 2023-08-18 17:48:04 --> Helper loaded: url_helper
INFO - 2023-08-18 17:48:04 --> Helper loaded: file_helper
INFO - 2023-08-18 17:48:04 --> Database Driver Class Initialized
INFO - 2023-08-18 17:48:04 --> Email Class Initialized
DEBUG - 2023-08-18 17:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:48:04 --> Controller Class Initialized
INFO - 2023-08-18 17:48:04 --> Model "Services_model" initialized
INFO - 2023-08-18 17:48:04 --> Helper loaded: form_helper
INFO - 2023-08-18 17:48:04 --> Form Validation Class Initialized
INFO - 2023-08-18 17:48:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-18 17:48:04 --> Final output sent to browser
DEBUG - 2023-08-18 17:48:04 --> Total execution time: 0.0499
INFO - 2023-08-18 17:48:05 --> Config Class Initialized
INFO - 2023-08-18 17:48:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:48:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:48:05 --> Utf8 Class Initialized
INFO - 2023-08-18 17:48:05 --> URI Class Initialized
INFO - 2023-08-18 17:48:05 --> Router Class Initialized
INFO - 2023-08-18 17:48:05 --> Output Class Initialized
INFO - 2023-08-18 17:48:05 --> Security Class Initialized
DEBUG - 2023-08-18 17:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:48:05 --> Input Class Initialized
INFO - 2023-08-18 17:48:05 --> Language Class Initialized
ERROR - 2023-08-18 17:48:05 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-18 17:48:07 --> Config Class Initialized
INFO - 2023-08-18 17:48:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:48:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:48:08 --> Utf8 Class Initialized
INFO - 2023-08-18 17:48:08 --> URI Class Initialized
INFO - 2023-08-18 17:48:08 --> Router Class Initialized
INFO - 2023-08-18 17:48:08 --> Output Class Initialized
INFO - 2023-08-18 17:48:08 --> Security Class Initialized
DEBUG - 2023-08-18 17:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:48:08 --> Input Class Initialized
INFO - 2023-08-18 17:48:08 --> Language Class Initialized
INFO - 2023-08-18 17:48:08 --> Loader Class Initialized
INFO - 2023-08-18 17:48:08 --> Helper loaded: url_helper
INFO - 2023-08-18 17:48:08 --> Helper loaded: file_helper
INFO - 2023-08-18 17:48:08 --> Database Driver Class Initialized
INFO - 2023-08-18 17:48:08 --> Email Class Initialized
DEBUG - 2023-08-18 17:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:48:08 --> Controller Class Initialized
INFO - 2023-08-18 17:48:08 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:48:08 --> Helper loaded: form_helper
INFO - 2023-08-18 17:48:08 --> Form Validation Class Initialized
INFO - 2023-08-18 17:48:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:48:08 --> Final output sent to browser
DEBUG - 2023-08-18 17:48:08 --> Total execution time: 0.8507
INFO - 2023-08-18 17:49:37 --> Config Class Initialized
INFO - 2023-08-18 17:49:37 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:49:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:49:37 --> Utf8 Class Initialized
INFO - 2023-08-18 17:49:37 --> URI Class Initialized
INFO - 2023-08-18 17:49:37 --> Router Class Initialized
INFO - 2023-08-18 17:49:37 --> Output Class Initialized
INFO - 2023-08-18 17:49:37 --> Security Class Initialized
DEBUG - 2023-08-18 17:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:49:37 --> Input Class Initialized
INFO - 2023-08-18 17:49:37 --> Language Class Initialized
INFO - 2023-08-18 17:49:37 --> Loader Class Initialized
INFO - 2023-08-18 17:49:37 --> Helper loaded: url_helper
INFO - 2023-08-18 17:49:37 --> Helper loaded: file_helper
INFO - 2023-08-18 17:49:37 --> Database Driver Class Initialized
INFO - 2023-08-18 17:49:37 --> Email Class Initialized
DEBUG - 2023-08-18 17:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:49:37 --> Controller Class Initialized
INFO - 2023-08-18 17:49:37 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:49:38 --> Helper loaded: form_helper
INFO - 2023-08-18 17:49:38 --> Form Validation Class Initialized
INFO - 2023-08-18 17:49:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:49:38 --> Final output sent to browser
DEBUG - 2023-08-18 17:49:38 --> Total execution time: 0.9389
INFO - 2023-08-18 17:49:40 --> Config Class Initialized
INFO - 2023-08-18 17:49:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:49:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:49:40 --> Utf8 Class Initialized
INFO - 2023-08-18 17:49:40 --> URI Class Initialized
INFO - 2023-08-18 17:49:40 --> Router Class Initialized
INFO - 2023-08-18 17:49:40 --> Output Class Initialized
INFO - 2023-08-18 17:49:40 --> Security Class Initialized
DEBUG - 2023-08-18 17:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:49:40 --> Input Class Initialized
INFO - 2023-08-18 17:49:40 --> Language Class Initialized
INFO - 2023-08-18 17:49:40 --> Loader Class Initialized
INFO - 2023-08-18 17:49:40 --> Helper loaded: url_helper
INFO - 2023-08-18 17:49:40 --> Helper loaded: file_helper
INFO - 2023-08-18 17:49:40 --> Database Driver Class Initialized
INFO - 2023-08-18 17:49:41 --> Email Class Initialized
DEBUG - 2023-08-18 17:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:49:41 --> Controller Class Initialized
INFO - 2023-08-18 17:49:41 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:49:41 --> Helper loaded: form_helper
INFO - 2023-08-18 17:49:41 --> Form Validation Class Initialized
INFO - 2023-08-18 17:49:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-08-18 17:49:41 --> Final output sent to browser
DEBUG - 2023-08-18 17:49:41 --> Total execution time: 0.8983
INFO - 2023-08-18 17:49:42 --> Config Class Initialized
INFO - 2023-08-18 17:49:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:49:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:49:42 --> Utf8 Class Initialized
INFO - 2023-08-18 17:49:42 --> URI Class Initialized
INFO - 2023-08-18 17:49:42 --> Router Class Initialized
INFO - 2023-08-18 17:49:42 --> Output Class Initialized
INFO - 2023-08-18 17:49:42 --> Security Class Initialized
DEBUG - 2023-08-18 17:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:49:42 --> Input Class Initialized
INFO - 2023-08-18 17:49:42 --> Language Class Initialized
ERROR - 2023-08-18 17:49:42 --> 404 Page Not Found: admin/Training_curriculum/add
INFO - 2023-08-18 17:49:59 --> Config Class Initialized
INFO - 2023-08-18 17:49:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:49:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:49:59 --> Utf8 Class Initialized
INFO - 2023-08-18 17:49:59 --> URI Class Initialized
INFO - 2023-08-18 17:49:59 --> Router Class Initialized
INFO - 2023-08-18 17:49:59 --> Output Class Initialized
INFO - 2023-08-18 17:49:59 --> Security Class Initialized
DEBUG - 2023-08-18 17:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:49:59 --> Input Class Initialized
INFO - 2023-08-18 17:49:59 --> Language Class Initialized
INFO - 2023-08-18 17:49:59 --> Loader Class Initialized
INFO - 2023-08-18 17:49:59 --> Helper loaded: url_helper
INFO - 2023-08-18 17:49:59 --> Helper loaded: file_helper
INFO - 2023-08-18 17:50:00 --> Database Driver Class Initialized
INFO - 2023-08-18 17:50:00 --> Email Class Initialized
DEBUG - 2023-08-18 17:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:50:00 --> Controller Class Initialized
INFO - 2023-08-18 17:50:00 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:50:00 --> Helper loaded: form_helper
INFO - 2023-08-18 17:50:00 --> Form Validation Class Initialized
INFO - 2023-08-18 17:50:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:50:00 --> Config Class Initialized
INFO - 2023-08-18 17:50:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:50:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:50:00 --> Utf8 Class Initialized
INFO - 2023-08-18 17:50:00 --> URI Class Initialized
INFO - 2023-08-18 17:50:00 --> Router Class Initialized
INFO - 2023-08-18 17:50:00 --> Output Class Initialized
INFO - 2023-08-18 17:50:00 --> Security Class Initialized
DEBUG - 2023-08-18 17:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:50:00 --> Input Class Initialized
INFO - 2023-08-18 17:50:00 --> Language Class Initialized
INFO - 2023-08-18 17:50:00 --> Loader Class Initialized
INFO - 2023-08-18 17:50:00 --> Helper loaded: url_helper
INFO - 2023-08-18 17:50:00 --> Helper loaded: file_helper
INFO - 2023-08-18 17:50:00 --> Database Driver Class Initialized
INFO - 2023-08-18 17:50:00 --> Email Class Initialized
DEBUG - 2023-08-18 17:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:50:01 --> Controller Class Initialized
INFO - 2023-08-18 17:50:01 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:50:01 --> Helper loaded: form_helper
INFO - 2023-08-18 17:50:01 --> Form Validation Class Initialized
INFO - 2023-08-18 17:50:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:50:01 --> Final output sent to browser
DEBUG - 2023-08-18 17:50:01 --> Total execution time: 0.8406
INFO - 2023-08-18 17:50:25 --> Config Class Initialized
INFO - 2023-08-18 17:50:25 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:50:25 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:50:25 --> Utf8 Class Initialized
INFO - 2023-08-18 17:50:25 --> URI Class Initialized
INFO - 2023-08-18 17:50:25 --> Router Class Initialized
INFO - 2023-08-18 17:50:25 --> Output Class Initialized
INFO - 2023-08-18 17:50:25 --> Security Class Initialized
DEBUG - 2023-08-18 17:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:50:25 --> Input Class Initialized
INFO - 2023-08-18 17:50:25 --> Language Class Initialized
INFO - 2023-08-18 17:50:25 --> Loader Class Initialized
INFO - 2023-08-18 17:50:25 --> Helper loaded: url_helper
INFO - 2023-08-18 17:50:25 --> Helper loaded: file_helper
INFO - 2023-08-18 17:50:25 --> Database Driver Class Initialized
INFO - 2023-08-18 17:50:25 --> Email Class Initialized
DEBUG - 2023-08-18 17:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:50:25 --> Controller Class Initialized
INFO - 2023-08-18 17:50:25 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:50:25 --> Helper loaded: form_helper
INFO - 2023-08-18 17:50:26 --> Form Validation Class Initialized
INFO - 2023-08-18 17:50:26 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_edit.php
INFO - 2023-08-18 17:50:26 --> Final output sent to browser
DEBUG - 2023-08-18 17:50:26 --> Total execution time: 0.8624
INFO - 2023-08-18 17:50:37 --> Config Class Initialized
INFO - 2023-08-18 17:50:37 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:50:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:50:37 --> Utf8 Class Initialized
INFO - 2023-08-18 17:50:37 --> URI Class Initialized
INFO - 2023-08-18 17:50:37 --> Router Class Initialized
INFO - 2023-08-18 17:50:37 --> Output Class Initialized
INFO - 2023-08-18 17:50:37 --> Security Class Initialized
DEBUG - 2023-08-18 17:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:50:38 --> Input Class Initialized
INFO - 2023-08-18 17:50:38 --> Language Class Initialized
INFO - 2023-08-18 17:50:38 --> Loader Class Initialized
INFO - 2023-08-18 17:50:38 --> Helper loaded: url_helper
INFO - 2023-08-18 17:50:38 --> Helper loaded: file_helper
INFO - 2023-08-18 17:50:38 --> Database Driver Class Initialized
INFO - 2023-08-18 17:50:38 --> Email Class Initialized
DEBUG - 2023-08-18 17:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:50:38 --> Controller Class Initialized
INFO - 2023-08-18 17:50:38 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:50:38 --> Helper loaded: form_helper
INFO - 2023-08-18 17:50:38 --> Form Validation Class Initialized
INFO - 2023-08-18 17:50:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:50:38 --> Config Class Initialized
INFO - 2023-08-18 17:50:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:50:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:50:38 --> Utf8 Class Initialized
INFO - 2023-08-18 17:50:38 --> URI Class Initialized
INFO - 2023-08-18 17:50:38 --> Router Class Initialized
INFO - 2023-08-18 17:50:38 --> Output Class Initialized
INFO - 2023-08-18 17:50:38 --> Security Class Initialized
DEBUG - 2023-08-18 17:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:50:38 --> Input Class Initialized
INFO - 2023-08-18 17:50:38 --> Language Class Initialized
INFO - 2023-08-18 17:50:38 --> Loader Class Initialized
INFO - 2023-08-18 17:50:39 --> Helper loaded: url_helper
INFO - 2023-08-18 17:50:39 --> Helper loaded: file_helper
INFO - 2023-08-18 17:50:39 --> Database Driver Class Initialized
INFO - 2023-08-18 17:50:39 --> Email Class Initialized
DEBUG - 2023-08-18 17:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:50:39 --> Controller Class Initialized
INFO - 2023-08-18 17:50:39 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:50:39 --> Helper loaded: form_helper
INFO - 2023-08-18 17:50:39 --> Form Validation Class Initialized
INFO - 2023-08-18 17:50:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:50:39 --> Final output sent to browser
DEBUG - 2023-08-18 17:50:39 --> Total execution time: 0.8307
INFO - 2023-08-18 17:50:42 --> Config Class Initialized
INFO - 2023-08-18 17:50:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:50:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:50:42 --> Utf8 Class Initialized
INFO - 2023-08-18 17:50:42 --> URI Class Initialized
INFO - 2023-08-18 17:50:42 --> Router Class Initialized
INFO - 2023-08-18 17:50:42 --> Output Class Initialized
INFO - 2023-08-18 17:50:42 --> Security Class Initialized
DEBUG - 2023-08-18 17:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:50:42 --> Input Class Initialized
INFO - 2023-08-18 17:50:42 --> Language Class Initialized
INFO - 2023-08-18 17:50:42 --> Loader Class Initialized
INFO - 2023-08-18 17:50:42 --> Helper loaded: url_helper
INFO - 2023-08-18 17:50:42 --> Helper loaded: file_helper
INFO - 2023-08-18 17:50:43 --> Database Driver Class Initialized
INFO - 2023-08-18 17:50:43 --> Email Class Initialized
DEBUG - 2023-08-18 17:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:50:43 --> Controller Class Initialized
INFO - 2023-08-18 17:50:43 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:50:43 --> Helper loaded: form_helper
INFO - 2023-08-18 17:50:43 --> Form Validation Class Initialized
INFO - 2023-08-18 17:50:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_edit.php
INFO - 2023-08-18 17:50:43 --> Final output sent to browser
DEBUG - 2023-08-18 17:50:43 --> Total execution time: 0.7522
INFO - 2023-08-18 17:50:54 --> Config Class Initialized
INFO - 2023-08-18 17:50:54 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:50:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:50:54 --> Utf8 Class Initialized
INFO - 2023-08-18 17:50:54 --> URI Class Initialized
INFO - 2023-08-18 17:50:54 --> Router Class Initialized
INFO - 2023-08-18 17:50:54 --> Output Class Initialized
INFO - 2023-08-18 17:50:54 --> Security Class Initialized
DEBUG - 2023-08-18 17:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:50:54 --> Input Class Initialized
INFO - 2023-08-18 17:50:54 --> Language Class Initialized
INFO - 2023-08-18 17:50:54 --> Loader Class Initialized
INFO - 2023-08-18 17:50:54 --> Helper loaded: url_helper
INFO - 2023-08-18 17:50:54 --> Helper loaded: file_helper
INFO - 2023-08-18 17:50:54 --> Database Driver Class Initialized
INFO - 2023-08-18 17:50:54 --> Email Class Initialized
DEBUG - 2023-08-18 17:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:50:54 --> Controller Class Initialized
INFO - 2023-08-18 17:50:55 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:50:55 --> Helper loaded: form_helper
INFO - 2023-08-18 17:50:55 --> Form Validation Class Initialized
INFO - 2023-08-18 17:50:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 17:50:55 --> Config Class Initialized
INFO - 2023-08-18 17:50:55 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:50:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:50:55 --> Utf8 Class Initialized
INFO - 2023-08-18 17:50:55 --> URI Class Initialized
INFO - 2023-08-18 17:50:55 --> Router Class Initialized
INFO - 2023-08-18 17:50:55 --> Output Class Initialized
INFO - 2023-08-18 17:50:55 --> Security Class Initialized
DEBUG - 2023-08-18 17:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:50:55 --> Input Class Initialized
INFO - 2023-08-18 17:50:55 --> Language Class Initialized
INFO - 2023-08-18 17:50:55 --> Loader Class Initialized
INFO - 2023-08-18 17:50:55 --> Helper loaded: url_helper
INFO - 2023-08-18 17:50:55 --> Helper loaded: file_helper
INFO - 2023-08-18 17:50:55 --> Database Driver Class Initialized
INFO - 2023-08-18 17:50:55 --> Email Class Initialized
DEBUG - 2023-08-18 17:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:50:55 --> Controller Class Initialized
INFO - 2023-08-18 17:50:55 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-18 17:50:55 --> Helper loaded: form_helper
INFO - 2023-08-18 17:50:55 --> Form Validation Class Initialized
INFO - 2023-08-18 17:50:55 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-18 17:50:55 --> Final output sent to browser
DEBUG - 2023-08-18 17:50:55 --> Total execution time: 0.5919
INFO - 2023-08-18 17:50:59 --> Config Class Initialized
INFO - 2023-08-18 17:50:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:50:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:50:59 --> Utf8 Class Initialized
INFO - 2023-08-18 17:50:59 --> URI Class Initialized
INFO - 2023-08-18 17:50:59 --> Router Class Initialized
INFO - 2023-08-18 17:50:59 --> Output Class Initialized
INFO - 2023-08-18 17:50:59 --> Security Class Initialized
DEBUG - 2023-08-18 17:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:50:59 --> Input Class Initialized
INFO - 2023-08-18 17:50:59 --> Language Class Initialized
INFO - 2023-08-18 17:50:59 --> Loader Class Initialized
INFO - 2023-08-18 17:50:59 --> Helper loaded: url_helper
INFO - 2023-08-18 17:50:59 --> Helper loaded: file_helper
INFO - 2023-08-18 17:50:59 --> Database Driver Class Initialized
INFO - 2023-08-18 17:50:59 --> Email Class Initialized
DEBUG - 2023-08-18 17:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:50:59 --> Controller Class Initialized
INFO - 2023-08-18 17:50:59 --> Model "Training_model" initialized
INFO - 2023-08-18 17:50:59 --> Helper loaded: form_helper
INFO - 2023-08-18 17:50:59 --> Form Validation Class Initialized
INFO - 2023-08-18 17:50:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-18 17:50:59 --> Final output sent to browser
DEBUG - 2023-08-18 17:50:59 --> Total execution time: 0.3932
INFO - 2023-08-18 17:51:13 --> Config Class Initialized
INFO - 2023-08-18 17:51:13 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:51:13 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:51:13 --> Utf8 Class Initialized
INFO - 2023-08-18 17:51:13 --> URI Class Initialized
INFO - 2023-08-18 17:51:13 --> Router Class Initialized
INFO - 2023-08-18 17:51:13 --> Output Class Initialized
INFO - 2023-08-18 17:51:13 --> Security Class Initialized
DEBUG - 2023-08-18 17:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:51:13 --> Input Class Initialized
INFO - 2023-08-18 17:51:13 --> Language Class Initialized
INFO - 2023-08-18 17:51:13 --> Loader Class Initialized
INFO - 2023-08-18 17:51:13 --> Helper loaded: url_helper
INFO - 2023-08-18 17:51:13 --> Helper loaded: file_helper
INFO - 2023-08-18 17:51:13 --> Database Driver Class Initialized
INFO - 2023-08-18 17:51:13 --> Email Class Initialized
DEBUG - 2023-08-18 17:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:51:13 --> Controller Class Initialized
INFO - 2023-08-18 17:51:13 --> Model "Training_model" initialized
INFO - 2023-08-18 17:51:13 --> Helper loaded: form_helper
INFO - 2023-08-18 17:51:13 --> Form Validation Class Initialized
INFO - 2023-08-18 17:51:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-18 17:51:13 --> Final output sent to browser
DEBUG - 2023-08-18 17:51:14 --> Total execution time: 0.5384
INFO - 2023-08-18 17:51:14 --> Config Class Initialized
INFO - 2023-08-18 17:51:14 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:51:14 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:51:14 --> Utf8 Class Initialized
INFO - 2023-08-18 17:51:14 --> URI Class Initialized
INFO - 2023-08-18 17:51:14 --> Router Class Initialized
INFO - 2023-08-18 17:51:14 --> Output Class Initialized
INFO - 2023-08-18 17:51:14 --> Security Class Initialized
DEBUG - 2023-08-18 17:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:51:14 --> Input Class Initialized
INFO - 2023-08-18 17:51:14 --> Language Class Initialized
INFO - 2023-08-18 17:51:15 --> Loader Class Initialized
INFO - 2023-08-18 17:51:15 --> Helper loaded: url_helper
INFO - 2023-08-18 17:51:15 --> Helper loaded: file_helper
INFO - 2023-08-18 17:51:15 --> Database Driver Class Initialized
INFO - 2023-08-18 17:51:15 --> Email Class Initialized
DEBUG - 2023-08-18 17:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:51:15 --> Controller Class Initialized
INFO - 2023-08-18 17:51:15 --> Model "Training_model" initialized
INFO - 2023-08-18 17:51:15 --> Helper loaded: form_helper
INFO - 2023-08-18 17:51:15 --> Form Validation Class Initialized
ERROR - 2023-08-18 17:51:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 39
ERROR - 2023-08-18 17:51:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 46
ERROR - 2023-08-18 17:51:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 55
ERROR - 2023-08-18 17:51:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 69
ERROR - 2023-08-18 17:51:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 81
ERROR - 2023-08-18 17:51:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 98
ERROR - 2023-08-18 17:51:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 99
ERROR - 2023-08-18 17:51:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 100
ERROR - 2023-08-18 17:51:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 116
ERROR - 2023-08-18 17:51:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 126
ERROR - 2023-08-18 17:51:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 127
INFO - 2023-08-18 17:51:15 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-18 17:51:15 --> Final output sent to browser
DEBUG - 2023-08-18 17:51:15 --> Total execution time: 1.2420
INFO - 2023-08-18 17:59:29 --> Config Class Initialized
INFO - 2023-08-18 17:59:29 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:59:29 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:59:29 --> Utf8 Class Initialized
INFO - 2023-08-18 17:59:29 --> URI Class Initialized
INFO - 2023-08-18 17:59:29 --> Router Class Initialized
INFO - 2023-08-18 17:59:29 --> Output Class Initialized
INFO - 2023-08-18 17:59:29 --> Security Class Initialized
DEBUG - 2023-08-18 17:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:59:29 --> Input Class Initialized
INFO - 2023-08-18 17:59:29 --> Language Class Initialized
INFO - 2023-08-18 17:59:29 --> Loader Class Initialized
INFO - 2023-08-18 17:59:29 --> Helper loaded: url_helper
INFO - 2023-08-18 17:59:29 --> Helper loaded: file_helper
INFO - 2023-08-18 17:59:29 --> Database Driver Class Initialized
INFO - 2023-08-18 17:59:29 --> Email Class Initialized
DEBUG - 2023-08-18 17:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:59:29 --> Controller Class Initialized
INFO - 2023-08-18 17:59:29 --> Model "Home_model" initialized
INFO - 2023-08-18 17:59:29 --> Helper loaded: form_helper
INFO - 2023-08-18 17:59:29 --> Form Validation Class Initialized
INFO - 2023-08-18 17:59:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 17:59:30 --> Final output sent to browser
DEBUG - 2023-08-18 17:59:30 --> Total execution time: 0.9428
INFO - 2023-08-18 17:59:31 --> Config Class Initialized
INFO - 2023-08-18 17:59:31 --> Config Class Initialized
INFO - 2023-08-18 17:59:31 --> Hooks Class Initialized
INFO - 2023-08-18 17:59:31 --> Config Class Initialized
INFO - 2023-08-18 17:59:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:59:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 17:59:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:59:31 --> Utf8 Class Initialized
INFO - 2023-08-18 17:59:31 --> Hooks Class Initialized
INFO - 2023-08-18 17:59:31 --> Config Class Initialized
INFO - 2023-08-18 17:59:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:59:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 17:59:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:59:31 --> Utf8 Class Initialized
INFO - 2023-08-18 17:59:31 --> URI Class Initialized
INFO - 2023-08-18 17:59:31 --> Utf8 Class Initialized
INFO - 2023-08-18 17:59:31 --> Router Class Initialized
INFO - 2023-08-18 17:59:31 --> Utf8 Class Initialized
INFO - 2023-08-18 17:59:31 --> URI Class Initialized
INFO - 2023-08-18 17:59:31 --> Router Class Initialized
INFO - 2023-08-18 17:59:31 --> Output Class Initialized
INFO - 2023-08-18 17:59:31 --> Security Class Initialized
DEBUG - 2023-08-18 17:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:59:31 --> Input Class Initialized
INFO - 2023-08-18 17:59:31 --> Language Class Initialized
ERROR - 2023-08-18 17:59:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:59:31 --> URI Class Initialized
INFO - 2023-08-18 17:59:31 --> Router Class Initialized
INFO - 2023-08-18 17:59:31 --> Output Class Initialized
INFO - 2023-08-18 17:59:31 --> Output Class Initialized
INFO - 2023-08-18 17:59:31 --> URI Class Initialized
INFO - 2023-08-18 17:59:31 --> Security Class Initialized
INFO - 2023-08-18 17:59:31 --> Router Class Initialized
INFO - 2023-08-18 17:59:31 --> Security Class Initialized
DEBUG - 2023-08-18 17:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:59:31 --> Output Class Initialized
INFO - 2023-08-18 17:59:31 --> Input Class Initialized
INFO - 2023-08-18 17:59:31 --> Language Class Initialized
INFO - 2023-08-18 17:59:31 --> Security Class Initialized
DEBUG - 2023-08-18 17:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 17:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:59:31 --> Config Class Initialized
ERROR - 2023-08-18 17:59:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:59:31 --> Input Class Initialized
INFO - 2023-08-18 17:59:31 --> Hooks Class Initialized
INFO - 2023-08-18 17:59:31 --> Input Class Initialized
INFO - 2023-08-18 17:59:31 --> Language Class Initialized
INFO - 2023-08-18 17:59:31 --> Language Class Initialized
ERROR - 2023-08-18 17:59:31 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-18 17:59:31 --> UTF-8 Support Enabled
ERROR - 2023-08-18 17:59:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:59:31 --> Utf8 Class Initialized
INFO - 2023-08-18 17:59:31 --> URI Class Initialized
INFO - 2023-08-18 17:59:31 --> Router Class Initialized
INFO - 2023-08-18 17:59:31 --> Output Class Initialized
INFO - 2023-08-18 17:59:31 --> Security Class Initialized
DEBUG - 2023-08-18 17:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:59:31 --> Input Class Initialized
INFO - 2023-08-18 17:59:31 --> Language Class Initialized
INFO - 2023-08-18 17:59:31 --> Loader Class Initialized
INFO - 2023-08-18 17:59:31 --> Helper loaded: url_helper
INFO - 2023-08-18 17:59:31 --> Helper loaded: file_helper
INFO - 2023-08-18 17:59:31 --> Database Driver Class Initialized
INFO - 2023-08-18 17:59:31 --> Email Class Initialized
DEBUG - 2023-08-18 17:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:59:32 --> Controller Class Initialized
INFO - 2023-08-18 17:59:32 --> Model "Training_model" initialized
INFO - 2023-08-18 17:59:32 --> Helper loaded: form_helper
INFO - 2023-08-18 17:59:32 --> Form Validation Class Initialized
INFO - 2023-08-18 17:59:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-18 17:59:32 --> Final output sent to browser
DEBUG - 2023-08-18 17:59:32 --> Total execution time: 0.5544
INFO - 2023-08-18 17:59:32 --> Config Class Initialized
INFO - 2023-08-18 17:59:32 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:59:32 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:59:32 --> Utf8 Class Initialized
INFO - 2023-08-18 17:59:32 --> URI Class Initialized
INFO - 2023-08-18 17:59:32 --> Router Class Initialized
INFO - 2023-08-18 17:59:32 --> Output Class Initialized
INFO - 2023-08-18 17:59:32 --> Security Class Initialized
DEBUG - 2023-08-18 17:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:59:32 --> Input Class Initialized
INFO - 2023-08-18 17:59:32 --> Language Class Initialized
ERROR - 2023-08-18 17:59:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:59:33 --> Config Class Initialized
INFO - 2023-08-18 17:59:33 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:59:33 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:59:33 --> Utf8 Class Initialized
INFO - 2023-08-18 17:59:33 --> URI Class Initialized
INFO - 2023-08-18 17:59:33 --> Router Class Initialized
INFO - 2023-08-18 17:59:33 --> Output Class Initialized
INFO - 2023-08-18 17:59:33 --> Security Class Initialized
DEBUG - 2023-08-18 17:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:59:33 --> Input Class Initialized
INFO - 2023-08-18 17:59:33 --> Language Class Initialized
INFO - 2023-08-18 17:59:33 --> Loader Class Initialized
INFO - 2023-08-18 17:59:33 --> Helper loaded: url_helper
INFO - 2023-08-18 17:59:33 --> Helper loaded: file_helper
INFO - 2023-08-18 17:59:33 --> Database Driver Class Initialized
INFO - 2023-08-18 17:59:33 --> Email Class Initialized
DEBUG - 2023-08-18 17:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:59:33 --> Controller Class Initialized
INFO - 2023-08-18 17:59:33 --> Model "Training_model" initialized
INFO - 2023-08-18 17:59:33 --> Helper loaded: form_helper
INFO - 2023-08-18 17:59:33 --> Form Validation Class Initialized
ERROR - 2023-08-18 17:59:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 39
ERROR - 2023-08-18 17:59:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 46
ERROR - 2023-08-18 17:59:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 55
ERROR - 2023-08-18 17:59:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 69
ERROR - 2023-08-18 17:59:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 81
ERROR - 2023-08-18 17:59:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 98
ERROR - 2023-08-18 17:59:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 99
ERROR - 2023-08-18 17:59:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 100
ERROR - 2023-08-18 17:59:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 116
ERROR - 2023-08-18 17:59:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 126
ERROR - 2023-08-18 17:59:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 127
INFO - 2023-08-18 17:59:33 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-18 17:59:33 --> Final output sent to browser
DEBUG - 2023-08-18 17:59:33 --> Total execution time: 0.6855
INFO - 2023-08-18 17:59:34 --> Config Class Initialized
INFO - 2023-08-18 17:59:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:59:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:59:34 --> Utf8 Class Initialized
INFO - 2023-08-18 17:59:34 --> URI Class Initialized
INFO - 2023-08-18 17:59:34 --> Router Class Initialized
INFO - 2023-08-18 17:59:34 --> Output Class Initialized
INFO - 2023-08-18 17:59:34 --> Security Class Initialized
DEBUG - 2023-08-18 17:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:59:34 --> Input Class Initialized
INFO - 2023-08-18 17:59:34 --> Language Class Initialized
ERROR - 2023-08-18 17:59:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:59:34 --> Config Class Initialized
INFO - 2023-08-18 17:59:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:59:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:59:34 --> Utf8 Class Initialized
INFO - 2023-08-18 17:59:34 --> URI Class Initialized
INFO - 2023-08-18 17:59:34 --> Router Class Initialized
INFO - 2023-08-18 17:59:34 --> Output Class Initialized
INFO - 2023-08-18 17:59:34 --> Security Class Initialized
DEBUG - 2023-08-18 17:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:59:34 --> Input Class Initialized
INFO - 2023-08-18 17:59:34 --> Language Class Initialized
ERROR - 2023-08-18 17:59:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:59:34 --> Config Class Initialized
INFO - 2023-08-18 17:59:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:59:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:59:34 --> Utf8 Class Initialized
INFO - 2023-08-18 17:59:34 --> URI Class Initialized
INFO - 2023-08-18 17:59:34 --> Router Class Initialized
INFO - 2023-08-18 17:59:34 --> Output Class Initialized
INFO - 2023-08-18 17:59:34 --> Security Class Initialized
DEBUG - 2023-08-18 17:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:59:34 --> Input Class Initialized
INFO - 2023-08-18 17:59:34 --> Language Class Initialized
ERROR - 2023-08-18 17:59:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 17:59:41 --> Config Class Initialized
INFO - 2023-08-18 17:59:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:59:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:59:41 --> Utf8 Class Initialized
INFO - 2023-08-18 17:59:41 --> URI Class Initialized
INFO - 2023-08-18 17:59:41 --> Router Class Initialized
INFO - 2023-08-18 17:59:41 --> Output Class Initialized
INFO - 2023-08-18 17:59:41 --> Security Class Initialized
DEBUG - 2023-08-18 17:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:59:42 --> Input Class Initialized
INFO - 2023-08-18 17:59:42 --> Language Class Initialized
INFO - 2023-08-18 17:59:42 --> Loader Class Initialized
INFO - 2023-08-18 17:59:42 --> Helper loaded: url_helper
INFO - 2023-08-18 17:59:42 --> Helper loaded: file_helper
INFO - 2023-08-18 17:59:42 --> Database Driver Class Initialized
INFO - 2023-08-18 17:59:42 --> Email Class Initialized
DEBUG - 2023-08-18 17:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 17:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:59:42 --> Controller Class Initialized
INFO - 2023-08-18 17:59:42 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 17:59:42 --> Helper loaded: form_helper
INFO - 2023-08-18 17:59:42 --> Form Validation Class Initialized
INFO - 2023-08-18 17:59:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 17:59:42 --> Final output sent to browser
DEBUG - 2023-08-18 17:59:42 --> Total execution time: 0.3453
INFO - 2023-08-18 18:00:04 --> Config Class Initialized
INFO - 2023-08-18 18:00:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:00:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:00:04 --> Utf8 Class Initialized
INFO - 2023-08-18 18:00:04 --> URI Class Initialized
INFO - 2023-08-18 18:00:04 --> Router Class Initialized
INFO - 2023-08-18 18:00:04 --> Output Class Initialized
INFO - 2023-08-18 18:00:04 --> Security Class Initialized
DEBUG - 2023-08-18 18:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:00:04 --> Input Class Initialized
INFO - 2023-08-18 18:00:04 --> Language Class Initialized
INFO - 2023-08-18 18:00:04 --> Loader Class Initialized
INFO - 2023-08-18 18:00:04 --> Helper loaded: url_helper
INFO - 2023-08-18 18:00:04 --> Helper loaded: file_helper
INFO - 2023-08-18 18:00:04 --> Database Driver Class Initialized
INFO - 2023-08-18 18:00:04 --> Email Class Initialized
DEBUG - 2023-08-18 18:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 18:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 18:00:04 --> Controller Class Initialized
INFO - 2023-08-18 18:00:04 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 18:00:04 --> Helper loaded: form_helper
INFO - 2023-08-18 18:00:04 --> Form Validation Class Initialized
INFO - 2023-08-18 18:00:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 18:00:04 --> Final output sent to browser
DEBUG - 2023-08-18 18:00:05 --> Total execution time: 0.4514
INFO - 2023-08-18 18:16:22 --> Config Class Initialized
INFO - 2023-08-18 18:16:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:16:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:16:22 --> Utf8 Class Initialized
INFO - 2023-08-18 18:16:22 --> URI Class Initialized
INFO - 2023-08-18 18:16:22 --> Router Class Initialized
INFO - 2023-08-18 18:16:22 --> Output Class Initialized
INFO - 2023-08-18 18:16:22 --> Security Class Initialized
DEBUG - 2023-08-18 18:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:16:22 --> Input Class Initialized
INFO - 2023-08-18 18:16:22 --> Language Class Initialized
INFO - 2023-08-18 18:16:22 --> Loader Class Initialized
INFO - 2023-08-18 18:16:22 --> Helper loaded: url_helper
INFO - 2023-08-18 18:16:22 --> Helper loaded: file_helper
INFO - 2023-08-18 18:16:22 --> Database Driver Class Initialized
INFO - 2023-08-18 18:16:22 --> Email Class Initialized
DEBUG - 2023-08-18 18:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 18:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 18:16:22 --> Controller Class Initialized
INFO - 2023-08-18 18:16:22 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 18:16:22 --> Helper loaded: form_helper
INFO - 2023-08-18 18:16:22 --> Form Validation Class Initialized
INFO - 2023-08-18 18:16:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 18:16:22 --> Final output sent to browser
DEBUG - 2023-08-18 18:16:23 --> Total execution time: 0.8550
INFO - 2023-08-18 18:16:33 --> Config Class Initialized
INFO - 2023-08-18 18:16:33 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:16:33 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:16:33 --> Utf8 Class Initialized
INFO - 2023-08-18 18:16:33 --> URI Class Initialized
INFO - 2023-08-18 18:16:33 --> Router Class Initialized
INFO - 2023-08-18 18:16:33 --> Output Class Initialized
INFO - 2023-08-18 18:16:33 --> Security Class Initialized
DEBUG - 2023-08-18 18:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:16:33 --> Input Class Initialized
INFO - 2023-08-18 18:16:33 --> Language Class Initialized
INFO - 2023-08-18 18:16:34 --> Loader Class Initialized
INFO - 2023-08-18 18:16:34 --> Helper loaded: url_helper
INFO - 2023-08-18 18:16:34 --> Helper loaded: file_helper
INFO - 2023-08-18 18:16:34 --> Database Driver Class Initialized
INFO - 2023-08-18 18:16:34 --> Email Class Initialized
DEBUG - 2023-08-18 18:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 18:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 18:16:34 --> Controller Class Initialized
INFO - 2023-08-18 18:16:34 --> Model "Certification_courses_model" initialized
INFO - 2023-08-18 18:16:34 --> Helper loaded: form_helper
INFO - 2023-08-18 18:16:34 --> Form Validation Class Initialized
INFO - 2023-08-18 18:16:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-18 18:16:34 --> Final output sent to browser
DEBUG - 2023-08-18 18:16:34 --> Total execution time: 0.9305
INFO - 2023-08-18 18:17:05 --> Config Class Initialized
INFO - 2023-08-18 18:17:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:17:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:17:05 --> Utf8 Class Initialized
INFO - 2023-08-18 18:17:05 --> URI Class Initialized
INFO - 2023-08-18 18:17:05 --> Router Class Initialized
INFO - 2023-08-18 18:17:05 --> Output Class Initialized
INFO - 2023-08-18 18:17:05 --> Security Class Initialized
DEBUG - 2023-08-18 18:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:17:05 --> Input Class Initialized
INFO - 2023-08-18 18:17:05 --> Language Class Initialized
INFO - 2023-08-18 18:17:05 --> Loader Class Initialized
INFO - 2023-08-18 18:17:05 --> Helper loaded: url_helper
INFO - 2023-08-18 18:17:05 --> Helper loaded: file_helper
INFO - 2023-08-18 18:17:05 --> Database Driver Class Initialized
INFO - 2023-08-18 18:17:05 --> Email Class Initialized
DEBUG - 2023-08-18 18:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 18:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 18:17:05 --> Controller Class Initialized
INFO - 2023-08-18 18:17:05 --> Model "Home_model" initialized
INFO - 2023-08-18 18:17:05 --> Helper loaded: form_helper
INFO - 2023-08-18 18:17:05 --> Form Validation Class Initialized
INFO - 2023-08-18 18:17:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 18:17:05 --> Final output sent to browser
DEBUG - 2023-08-18 18:17:05 --> Total execution time: 0.4028
INFO - 2023-08-18 18:17:05 --> Config Class Initialized
INFO - 2023-08-18 18:17:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:17:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:17:05 --> Utf8 Class Initialized
INFO - 2023-08-18 18:17:05 --> URI Class Initialized
INFO - 2023-08-18 18:17:05 --> Router Class Initialized
INFO - 2023-08-18 18:17:05 --> Output Class Initialized
INFO - 2023-08-18 18:17:05 --> Security Class Initialized
DEBUG - 2023-08-18 18:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:17:05 --> Input Class Initialized
INFO - 2023-08-18 18:17:05 --> Language Class Initialized
ERROR - 2023-08-18 18:17:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:17:06 --> Config Class Initialized
INFO - 2023-08-18 18:17:06 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:17:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:17:06 --> Utf8 Class Initialized
INFO - 2023-08-18 18:17:06 --> URI Class Initialized
INFO - 2023-08-18 18:17:06 --> Router Class Initialized
INFO - 2023-08-18 18:17:06 --> Output Class Initialized
INFO - 2023-08-18 18:17:06 --> Security Class Initialized
DEBUG - 2023-08-18 18:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:17:06 --> Input Class Initialized
INFO - 2023-08-18 18:17:06 --> Language Class Initialized
ERROR - 2023-08-18 18:17:06 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:17:06 --> Config Class Initialized
INFO - 2023-08-18 18:17:06 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:17:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:17:06 --> Utf8 Class Initialized
INFO - 2023-08-18 18:17:06 --> URI Class Initialized
INFO - 2023-08-18 18:17:06 --> Router Class Initialized
INFO - 2023-08-18 18:17:06 --> Output Class Initialized
INFO - 2023-08-18 18:17:06 --> Security Class Initialized
DEBUG - 2023-08-18 18:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:17:06 --> Input Class Initialized
INFO - 2023-08-18 18:17:06 --> Language Class Initialized
ERROR - 2023-08-18 18:17:07 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:17:07 --> Config Class Initialized
INFO - 2023-08-18 18:17:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:17:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:17:07 --> Utf8 Class Initialized
INFO - 2023-08-18 18:17:07 --> URI Class Initialized
INFO - 2023-08-18 18:17:07 --> Router Class Initialized
INFO - 2023-08-18 18:17:07 --> Output Class Initialized
INFO - 2023-08-18 18:17:07 --> Security Class Initialized
DEBUG - 2023-08-18 18:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:17:07 --> Input Class Initialized
INFO - 2023-08-18 18:17:07 --> Language Class Initialized
ERROR - 2023-08-18 18:17:07 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:17:07 --> Config Class Initialized
INFO - 2023-08-18 18:17:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:17:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:17:07 --> Utf8 Class Initialized
INFO - 2023-08-18 18:17:07 --> URI Class Initialized
INFO - 2023-08-18 18:17:07 --> Router Class Initialized
INFO - 2023-08-18 18:17:07 --> Output Class Initialized
INFO - 2023-08-18 18:17:07 --> Security Class Initialized
DEBUG - 2023-08-18 18:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:17:07 --> Input Class Initialized
INFO - 2023-08-18 18:17:07 --> Language Class Initialized
ERROR - 2023-08-18 18:17:07 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:20:36 --> Config Class Initialized
INFO - 2023-08-18 18:20:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:20:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:20:36 --> Utf8 Class Initialized
INFO - 2023-08-18 18:20:36 --> URI Class Initialized
INFO - 2023-08-18 18:20:36 --> Router Class Initialized
INFO - 2023-08-18 18:20:36 --> Output Class Initialized
INFO - 2023-08-18 18:20:36 --> Security Class Initialized
DEBUG - 2023-08-18 18:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:20:36 --> Input Class Initialized
INFO - 2023-08-18 18:20:36 --> Language Class Initialized
INFO - 2023-08-18 18:20:36 --> Loader Class Initialized
INFO - 2023-08-18 18:20:36 --> Helper loaded: url_helper
INFO - 2023-08-18 18:20:36 --> Helper loaded: file_helper
INFO - 2023-08-18 18:20:36 --> Database Driver Class Initialized
INFO - 2023-08-18 18:20:36 --> Email Class Initialized
DEBUG - 2023-08-18 18:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 18:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 18:20:36 --> Controller Class Initialized
INFO - 2023-08-18 18:20:36 --> Model "Home_model" initialized
INFO - 2023-08-18 18:20:36 --> Helper loaded: form_helper
INFO - 2023-08-18 18:20:36 --> Form Validation Class Initialized
INFO - 2023-08-18 18:20:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 18:20:36 --> Final output sent to browser
DEBUG - 2023-08-18 18:20:37 --> Total execution time: 0.5523
INFO - 2023-08-18 18:20:38 --> Config Class Initialized
INFO - 2023-08-18 18:20:38 --> Config Class Initialized
INFO - 2023-08-18 18:20:38 --> Hooks Class Initialized
INFO - 2023-08-18 18:20:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:20:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 18:20:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:20:38 --> Utf8 Class Initialized
INFO - 2023-08-18 18:20:38 --> Utf8 Class Initialized
INFO - 2023-08-18 18:20:38 --> URI Class Initialized
INFO - 2023-08-18 18:20:38 --> URI Class Initialized
INFO - 2023-08-18 18:20:38 --> Router Class Initialized
INFO - 2023-08-18 18:20:38 --> Output Class Initialized
INFO - 2023-08-18 18:20:38 --> Security Class Initialized
INFO - 2023-08-18 18:20:38 --> Router Class Initialized
DEBUG - 2023-08-18 18:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:20:38 --> Output Class Initialized
INFO - 2023-08-18 18:20:38 --> Input Class Initialized
INFO - 2023-08-18 18:20:38 --> Security Class Initialized
DEBUG - 2023-08-18 18:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:20:38 --> Language Class Initialized
INFO - 2023-08-18 18:20:38 --> Input Class Initialized
ERROR - 2023-08-18 18:20:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:20:38 --> Language Class Initialized
ERROR - 2023-08-18 18:20:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:20:38 --> Config Class Initialized
INFO - 2023-08-18 18:20:38 --> Config Class Initialized
INFO - 2023-08-18 18:20:38 --> Hooks Class Initialized
INFO - 2023-08-18 18:20:38 --> Config Class Initialized
INFO - 2023-08-18 18:20:38 --> Hooks Class Initialized
INFO - 2023-08-18 18:20:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:20:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:20:38 --> Utf8 Class Initialized
DEBUG - 2023-08-18 18:20:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:20:38 --> Utf8 Class Initialized
DEBUG - 2023-08-18 18:20:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:20:38 --> URI Class Initialized
INFO - 2023-08-18 18:20:38 --> URI Class Initialized
INFO - 2023-08-18 18:20:38 --> Router Class Initialized
INFO - 2023-08-18 18:20:38 --> Router Class Initialized
INFO - 2023-08-18 18:20:38 --> Output Class Initialized
INFO - 2023-08-18 18:20:38 --> Utf8 Class Initialized
INFO - 2023-08-18 18:20:38 --> Output Class Initialized
INFO - 2023-08-18 18:20:38 --> Security Class Initialized
INFO - 2023-08-18 18:20:38 --> Security Class Initialized
DEBUG - 2023-08-18 18:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:20:38 --> URI Class Initialized
INFO - 2023-08-18 18:20:38 --> Input Class Initialized
INFO - 2023-08-18 18:20:38 --> Router Class Initialized
DEBUG - 2023-08-18 18:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:20:38 --> Input Class Initialized
INFO - 2023-08-18 18:20:38 --> Language Class Initialized
INFO - 2023-08-18 18:20:38 --> Output Class Initialized
INFO - 2023-08-18 18:20:38 --> Language Class Initialized
ERROR - 2023-08-18 18:20:38 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-18 18:20:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:20:38 --> Security Class Initialized
DEBUG - 2023-08-18 18:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:20:38 --> Input Class Initialized
INFO - 2023-08-18 18:20:38 --> Language Class Initialized
ERROR - 2023-08-18 18:20:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:21:59 --> Config Class Initialized
INFO - 2023-08-18 18:21:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:21:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:21:59 --> Utf8 Class Initialized
INFO - 2023-08-18 18:21:59 --> URI Class Initialized
INFO - 2023-08-18 18:21:59 --> Router Class Initialized
INFO - 2023-08-18 18:21:59 --> Output Class Initialized
INFO - 2023-08-18 18:21:59 --> Security Class Initialized
DEBUG - 2023-08-18 18:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:21:59 --> Input Class Initialized
INFO - 2023-08-18 18:21:59 --> Language Class Initialized
INFO - 2023-08-18 18:21:59 --> Loader Class Initialized
INFO - 2023-08-18 18:21:59 --> Helper loaded: url_helper
INFO - 2023-08-18 18:21:59 --> Helper loaded: file_helper
INFO - 2023-08-18 18:21:59 --> Database Driver Class Initialized
INFO - 2023-08-18 18:21:59 --> Email Class Initialized
DEBUG - 2023-08-18 18:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 18:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 18:21:59 --> Controller Class Initialized
INFO - 2023-08-18 18:21:59 --> Model "Home_model" initialized
INFO - 2023-08-18 18:21:59 --> Helper loaded: form_helper
INFO - 2023-08-18 18:21:59 --> Form Validation Class Initialized
INFO - 2023-08-18 18:21:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 18:21:59 --> Final output sent to browser
DEBUG - 2023-08-18 18:21:59 --> Total execution time: 0.5649
INFO - 2023-08-18 18:22:00 --> Config Class Initialized
INFO - 2023-08-18 18:22:00 --> Config Class Initialized
INFO - 2023-08-18 18:22:00 --> Config Class Initialized
INFO - 2023-08-18 18:22:00 --> Config Class Initialized
INFO - 2023-08-18 18:22:00 --> Hooks Class Initialized
INFO - 2023-08-18 18:22:00 --> Config Class Initialized
INFO - 2023-08-18 18:22:00 --> Hooks Class Initialized
INFO - 2023-08-18 18:22:00 --> Hooks Class Initialized
INFO - 2023-08-18 18:22:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:22:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:22:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:22:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 18:22:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 18:22:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:22:00 --> Utf8 Class Initialized
DEBUG - 2023-08-18 18:22:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:22:00 --> URI Class Initialized
INFO - 2023-08-18 18:22:00 --> Utf8 Class Initialized
INFO - 2023-08-18 18:22:00 --> Utf8 Class Initialized
INFO - 2023-08-18 18:22:00 --> Router Class Initialized
INFO - 2023-08-18 18:22:00 --> Utf8 Class Initialized
INFO - 2023-08-18 18:22:00 --> Utf8 Class Initialized
INFO - 2023-08-18 18:22:00 --> URI Class Initialized
INFO - 2023-08-18 18:22:00 --> URI Class Initialized
INFO - 2023-08-18 18:22:00 --> URI Class Initialized
INFO - 2023-08-18 18:22:01 --> Router Class Initialized
INFO - 2023-08-18 18:22:01 --> Output Class Initialized
INFO - 2023-08-18 18:22:01 --> Security Class Initialized
DEBUG - 2023-08-18 18:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:22:01 --> Input Class Initialized
INFO - 2023-08-18 18:22:01 --> Language Class Initialized
ERROR - 2023-08-18 18:22:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:22:01 --> Router Class Initialized
INFO - 2023-08-18 18:22:01 --> URI Class Initialized
INFO - 2023-08-18 18:22:01 --> Output Class Initialized
INFO - 2023-08-18 18:22:01 --> Router Class Initialized
INFO - 2023-08-18 18:22:01 --> Security Class Initialized
INFO - 2023-08-18 18:22:01 --> Router Class Initialized
INFO - 2023-08-18 18:22:01 --> Output Class Initialized
DEBUG - 2023-08-18 18:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:22:01 --> Output Class Initialized
INFO - 2023-08-18 18:22:01 --> Output Class Initialized
INFO - 2023-08-18 18:22:01 --> Input Class Initialized
INFO - 2023-08-18 18:22:01 --> Security Class Initialized
INFO - 2023-08-18 18:22:01 --> Security Class Initialized
INFO - 2023-08-18 18:22:01 --> Security Class Initialized
DEBUG - 2023-08-18 18:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:22:01 --> Language Class Initialized
DEBUG - 2023-08-18 18:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 18:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:22:01 --> Input Class Initialized
INFO - 2023-08-18 18:22:01 --> Input Class Initialized
INFO - 2023-08-18 18:22:01 --> Language Class Initialized
ERROR - 2023-08-18 18:22:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:22:01 --> Language Class Initialized
INFO - 2023-08-18 18:22:01 --> Input Class Initialized
ERROR - 2023-08-18 18:22:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:22:01 --> Language Class Initialized
ERROR - 2023-08-18 18:22:01 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-18 18:22:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:22:52 --> Config Class Initialized
INFO - 2023-08-18 18:22:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:22:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:22:52 --> Utf8 Class Initialized
INFO - 2023-08-18 18:22:52 --> URI Class Initialized
INFO - 2023-08-18 18:22:52 --> Router Class Initialized
INFO - 2023-08-18 18:22:52 --> Output Class Initialized
INFO - 2023-08-18 18:22:52 --> Security Class Initialized
DEBUG - 2023-08-18 18:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:22:52 --> Input Class Initialized
INFO - 2023-08-18 18:22:52 --> Language Class Initialized
INFO - 2023-08-18 18:22:52 --> Loader Class Initialized
INFO - 2023-08-18 18:22:52 --> Helper loaded: url_helper
INFO - 2023-08-18 18:22:52 --> Helper loaded: file_helper
INFO - 2023-08-18 18:22:52 --> Database Driver Class Initialized
INFO - 2023-08-18 18:22:52 --> Email Class Initialized
DEBUG - 2023-08-18 18:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 18:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 18:22:52 --> Controller Class Initialized
INFO - 2023-08-18 18:22:52 --> Model "Home_model" initialized
INFO - 2023-08-18 18:22:52 --> Helper loaded: form_helper
INFO - 2023-08-18 18:22:52 --> Form Validation Class Initialized
INFO - 2023-08-18 18:22:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 18:22:52 --> Final output sent to browser
DEBUG - 2023-08-18 18:22:52 --> Total execution time: 0.4049
INFO - 2023-08-18 18:22:53 --> Config Class Initialized
INFO - 2023-08-18 18:22:53 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:22:53 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:22:53 --> Utf8 Class Initialized
INFO - 2023-08-18 18:22:53 --> URI Class Initialized
INFO - 2023-08-18 18:22:53 --> Router Class Initialized
INFO - 2023-08-18 18:22:53 --> Output Class Initialized
INFO - 2023-08-18 18:22:53 --> Security Class Initialized
DEBUG - 2023-08-18 18:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:22:53 --> Input Class Initialized
INFO - 2023-08-18 18:22:53 --> Language Class Initialized
ERROR - 2023-08-18 18:22:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:22:53 --> Config Class Initialized
INFO - 2023-08-18 18:22:53 --> Hooks Class Initialized
INFO - 2023-08-18 18:22:53 --> Config Class Initialized
DEBUG - 2023-08-18 18:22:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:22:54 --> Utf8 Class Initialized
INFO - 2023-08-18 18:22:54 --> Config Class Initialized
INFO - 2023-08-18 18:22:54 --> Hooks Class Initialized
INFO - 2023-08-18 18:22:54 --> Config Class Initialized
DEBUG - 2023-08-18 18:22:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:22:54 --> URI Class Initialized
INFO - 2023-08-18 18:22:54 --> Hooks Class Initialized
INFO - 2023-08-18 18:22:54 --> Hooks Class Initialized
INFO - 2023-08-18 18:22:54 --> Utf8 Class Initialized
DEBUG - 2023-08-18 18:22:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:22:54 --> Router Class Initialized
INFO - 2023-08-18 18:22:54 --> Utf8 Class Initialized
INFO - 2023-08-18 18:22:54 --> URI Class Initialized
INFO - 2023-08-18 18:22:54 --> URI Class Initialized
DEBUG - 2023-08-18 18:22:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:22:54 --> Output Class Initialized
INFO - 2023-08-18 18:22:54 --> Router Class Initialized
INFO - 2023-08-18 18:22:54 --> Security Class Initialized
INFO - 2023-08-18 18:22:54 --> Output Class Initialized
INFO - 2023-08-18 18:22:54 --> Utf8 Class Initialized
INFO - 2023-08-18 18:22:54 --> URI Class Initialized
INFO - 2023-08-18 18:22:54 --> Router Class Initialized
INFO - 2023-08-18 18:22:54 --> Output Class Initialized
INFO - 2023-08-18 18:22:54 --> Router Class Initialized
DEBUG - 2023-08-18 18:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:22:54 --> Security Class Initialized
INFO - 2023-08-18 18:22:54 --> Output Class Initialized
INFO - 2023-08-18 18:22:54 --> Input Class Initialized
DEBUG - 2023-08-18 18:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:22:54 --> Security Class Initialized
INFO - 2023-08-18 18:22:54 --> Input Class Initialized
INFO - 2023-08-18 18:22:54 --> Security Class Initialized
INFO - 2023-08-18 18:22:54 --> Language Class Initialized
ERROR - 2023-08-18 18:22:54 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-18 18:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:22:54 --> Language Class Initialized
DEBUG - 2023-08-18 18:22:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-18 18:22:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:22:54 --> Input Class Initialized
INFO - 2023-08-18 18:22:54 --> Language Class Initialized
INFO - 2023-08-18 18:22:54 --> Input Class Initialized
ERROR - 2023-08-18 18:22:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:22:54 --> Language Class Initialized
ERROR - 2023-08-18 18:22:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:23:48 --> Config Class Initialized
INFO - 2023-08-18 18:23:49 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:23:49 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:23:49 --> Utf8 Class Initialized
INFO - 2023-08-18 18:23:49 --> URI Class Initialized
INFO - 2023-08-18 18:23:49 --> Router Class Initialized
INFO - 2023-08-18 18:23:49 --> Output Class Initialized
INFO - 2023-08-18 18:23:49 --> Security Class Initialized
DEBUG - 2023-08-18 18:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:23:49 --> Input Class Initialized
INFO - 2023-08-18 18:23:49 --> Language Class Initialized
INFO - 2023-08-18 18:23:49 --> Loader Class Initialized
INFO - 2023-08-18 18:23:49 --> Helper loaded: url_helper
INFO - 2023-08-18 18:23:49 --> Helper loaded: file_helper
INFO - 2023-08-18 18:23:49 --> Database Driver Class Initialized
INFO - 2023-08-18 18:23:49 --> Email Class Initialized
DEBUG - 2023-08-18 18:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 18:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 18:23:49 --> Controller Class Initialized
INFO - 2023-08-18 18:23:49 --> Model "Home_model" initialized
INFO - 2023-08-18 18:23:49 --> Helper loaded: form_helper
INFO - 2023-08-18 18:23:49 --> Form Validation Class Initialized
INFO - 2023-08-18 18:23:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-18 18:23:49 --> Final output sent to browser
DEBUG - 2023-08-18 18:23:49 --> Total execution time: 0.5133
INFO - 2023-08-18 18:23:53 --> Config Class Initialized
INFO - 2023-08-18 18:23:53 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:23:53 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:23:53 --> Utf8 Class Initialized
INFO - 2023-08-18 18:23:53 --> URI Class Initialized
INFO - 2023-08-18 18:23:53 --> Router Class Initialized
INFO - 2023-08-18 18:23:53 --> Output Class Initialized
INFO - 2023-08-18 18:23:53 --> Security Class Initialized
DEBUG - 2023-08-18 18:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:23:53 --> Input Class Initialized
INFO - 2023-08-18 18:23:53 --> Language Class Initialized
INFO - 2023-08-18 18:23:53 --> Loader Class Initialized
INFO - 2023-08-18 18:23:53 --> Helper loaded: url_helper
INFO - 2023-08-18 18:23:53 --> Helper loaded: file_helper
INFO - 2023-08-18 18:23:53 --> Database Driver Class Initialized
INFO - 2023-08-18 18:23:53 --> Email Class Initialized
DEBUG - 2023-08-18 18:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 18:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 18:23:53 --> Controller Class Initialized
INFO - 2023-08-18 18:23:53 --> Model "Home_model" initialized
INFO - 2023-08-18 18:23:53 --> Helper loaded: form_helper
INFO - 2023-08-18 18:23:53 --> Form Validation Class Initialized
INFO - 2023-08-18 18:23:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 18:23:54 --> Final output sent to browser
DEBUG - 2023-08-18 18:23:54 --> Total execution time: 0.3960
INFO - 2023-08-18 18:23:54 --> Config Class Initialized
INFO - 2023-08-18 18:23:54 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:23:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:23:54 --> Utf8 Class Initialized
INFO - 2023-08-18 18:23:54 --> URI Class Initialized
INFO - 2023-08-18 18:23:54 --> Router Class Initialized
INFO - 2023-08-18 18:23:54 --> Output Class Initialized
INFO - 2023-08-18 18:23:54 --> Security Class Initialized
DEBUG - 2023-08-18 18:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:23:54 --> Input Class Initialized
INFO - 2023-08-18 18:23:54 --> Language Class Initialized
ERROR - 2023-08-18 18:23:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:23:54 --> Config Class Initialized
INFO - 2023-08-18 18:23:54 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:23:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:23:54 --> Utf8 Class Initialized
INFO - 2023-08-18 18:23:54 --> URI Class Initialized
INFO - 2023-08-18 18:23:54 --> Router Class Initialized
INFO - 2023-08-18 18:23:54 --> Output Class Initialized
INFO - 2023-08-18 18:23:54 --> Security Class Initialized
DEBUG - 2023-08-18 18:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:23:54 --> Input Class Initialized
INFO - 2023-08-18 18:23:54 --> Language Class Initialized
ERROR - 2023-08-18 18:23:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:23:54 --> Config Class Initialized
INFO - 2023-08-18 18:23:55 --> Config Class Initialized
INFO - 2023-08-18 18:23:55 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:23:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:23:55 --> Utf8 Class Initialized
INFO - 2023-08-18 18:23:55 --> URI Class Initialized
INFO - 2023-08-18 18:23:55 --> Router Class Initialized
INFO - 2023-08-18 18:23:55 --> Output Class Initialized
INFO - 2023-08-18 18:23:55 --> Security Class Initialized
DEBUG - 2023-08-18 18:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:23:55 --> Input Class Initialized
INFO - 2023-08-18 18:23:55 --> Language Class Initialized
ERROR - 2023-08-18 18:23:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:23:55 --> Config Class Initialized
INFO - 2023-08-18 18:23:55 --> Hooks Class Initialized
INFO - 2023-08-18 18:23:55 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:23:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:23:55 --> Utf8 Class Initialized
INFO - 2023-08-18 18:23:55 --> URI Class Initialized
INFO - 2023-08-18 18:23:55 --> Router Class Initialized
INFO - 2023-08-18 18:23:55 --> Output Class Initialized
INFO - 2023-08-18 18:23:55 --> Security Class Initialized
DEBUG - 2023-08-18 18:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:23:55 --> Input Class Initialized
INFO - 2023-08-18 18:23:55 --> Language Class Initialized
ERROR - 2023-08-18 18:23:55 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-18 18:23:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:23:55 --> Utf8 Class Initialized
INFO - 2023-08-18 18:23:55 --> URI Class Initialized
INFO - 2023-08-18 18:23:55 --> Router Class Initialized
INFO - 2023-08-18 18:23:55 --> Output Class Initialized
INFO - 2023-08-18 18:23:55 --> Security Class Initialized
DEBUG - 2023-08-18 18:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:23:55 --> Input Class Initialized
INFO - 2023-08-18 18:23:55 --> Language Class Initialized
ERROR - 2023-08-18 18:23:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:23:55 --> Config Class Initialized
INFO - 2023-08-18 18:23:55 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:23:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:23:55 --> Utf8 Class Initialized
INFO - 2023-08-18 18:23:55 --> URI Class Initialized
INFO - 2023-08-18 18:23:55 --> Router Class Initialized
INFO - 2023-08-18 18:23:55 --> Output Class Initialized
INFO - 2023-08-18 18:23:55 --> Security Class Initialized
DEBUG - 2023-08-18 18:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:23:55 --> Input Class Initialized
INFO - 2023-08-18 18:23:55 --> Language Class Initialized
ERROR - 2023-08-18 18:23:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:24:11 --> Config Class Initialized
INFO - 2023-08-18 18:24:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:24:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:24:11 --> Utf8 Class Initialized
INFO - 2023-08-18 18:24:11 --> URI Class Initialized
INFO - 2023-08-18 18:24:11 --> Router Class Initialized
INFO - 2023-08-18 18:24:11 --> Output Class Initialized
INFO - 2023-08-18 18:24:11 --> Security Class Initialized
DEBUG - 2023-08-18 18:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:24:12 --> Input Class Initialized
INFO - 2023-08-18 18:24:12 --> Language Class Initialized
INFO - 2023-08-18 18:24:12 --> Loader Class Initialized
INFO - 2023-08-18 18:24:12 --> Helper loaded: url_helper
INFO - 2023-08-18 18:24:12 --> Helper loaded: file_helper
INFO - 2023-08-18 18:24:12 --> Database Driver Class Initialized
INFO - 2023-08-18 18:24:12 --> Email Class Initialized
DEBUG - 2023-08-18 18:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 18:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 18:24:12 --> Controller Class Initialized
INFO - 2023-08-18 18:24:12 --> Model "Home_model" initialized
INFO - 2023-08-18 18:24:12 --> Helper loaded: form_helper
INFO - 2023-08-18 18:24:12 --> Form Validation Class Initialized
INFO - 2023-08-18 18:24:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 18:24:12 --> Final output sent to browser
DEBUG - 2023-08-18 18:24:12 --> Total execution time: 0.4405
INFO - 2023-08-18 18:24:12 --> Config Class Initialized
INFO - 2023-08-18 18:24:12 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:24:12 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:24:12 --> Utf8 Class Initialized
INFO - 2023-08-18 18:24:12 --> URI Class Initialized
INFO - 2023-08-18 18:24:12 --> Router Class Initialized
INFO - 2023-08-18 18:24:12 --> Output Class Initialized
INFO - 2023-08-18 18:24:12 --> Security Class Initialized
DEBUG - 2023-08-18 18:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:24:12 --> Input Class Initialized
INFO - 2023-08-18 18:24:12 --> Language Class Initialized
ERROR - 2023-08-18 18:24:12 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:24:12 --> Config Class Initialized
INFO - 2023-08-18 18:24:12 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:24:12 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:24:12 --> Utf8 Class Initialized
INFO - 2023-08-18 18:24:12 --> URI Class Initialized
INFO - 2023-08-18 18:24:12 --> Router Class Initialized
INFO - 2023-08-18 18:24:12 --> Output Class Initialized
INFO - 2023-08-18 18:24:13 --> Security Class Initialized
DEBUG - 2023-08-18 18:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:24:13 --> Input Class Initialized
INFO - 2023-08-18 18:24:13 --> Language Class Initialized
ERROR - 2023-08-18 18:24:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:24:13 --> Config Class Initialized
INFO - 2023-08-18 18:24:13 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:24:13 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:24:13 --> Utf8 Class Initialized
INFO - 2023-08-18 18:24:13 --> URI Class Initialized
INFO - 2023-08-18 18:24:13 --> Router Class Initialized
INFO - 2023-08-18 18:24:13 --> Output Class Initialized
INFO - 2023-08-18 18:24:13 --> Security Class Initialized
DEBUG - 2023-08-18 18:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:24:13 --> Input Class Initialized
INFO - 2023-08-18 18:24:13 --> Language Class Initialized
ERROR - 2023-08-18 18:24:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:24:13 --> Config Class Initialized
INFO - 2023-08-18 18:24:13 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:24:13 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:24:13 --> Utf8 Class Initialized
INFO - 2023-08-18 18:24:13 --> URI Class Initialized
INFO - 2023-08-18 18:24:13 --> Router Class Initialized
INFO - 2023-08-18 18:24:13 --> Output Class Initialized
INFO - 2023-08-18 18:24:13 --> Security Class Initialized
DEBUG - 2023-08-18 18:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:24:13 --> Input Class Initialized
INFO - 2023-08-18 18:24:13 --> Language Class Initialized
ERROR - 2023-08-18 18:24:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:24:13 --> Config Class Initialized
INFO - 2023-08-18 18:24:13 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:24:13 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:24:13 --> Utf8 Class Initialized
INFO - 2023-08-18 18:24:13 --> URI Class Initialized
INFO - 2023-08-18 18:24:13 --> Router Class Initialized
INFO - 2023-08-18 18:24:13 --> Output Class Initialized
INFO - 2023-08-18 18:24:13 --> Security Class Initialized
DEBUG - 2023-08-18 18:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:24:13 --> Input Class Initialized
INFO - 2023-08-18 18:24:13 --> Language Class Initialized
ERROR - 2023-08-18 18:24:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:25:17 --> Config Class Initialized
INFO - 2023-08-18 18:25:17 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:25:17 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:25:17 --> Utf8 Class Initialized
INFO - 2023-08-18 18:25:17 --> URI Class Initialized
INFO - 2023-08-18 18:25:17 --> Router Class Initialized
INFO - 2023-08-18 18:25:17 --> Output Class Initialized
INFO - 2023-08-18 18:25:17 --> Security Class Initialized
DEBUG - 2023-08-18 18:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:25:17 --> Input Class Initialized
INFO - 2023-08-18 18:25:17 --> Language Class Initialized
INFO - 2023-08-18 18:25:17 --> Loader Class Initialized
INFO - 2023-08-18 18:25:17 --> Helper loaded: url_helper
INFO - 2023-08-18 18:25:17 --> Helper loaded: file_helper
INFO - 2023-08-18 18:25:17 --> Database Driver Class Initialized
INFO - 2023-08-18 18:25:17 --> Email Class Initialized
DEBUG - 2023-08-18 18:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 18:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 18:25:17 --> Controller Class Initialized
INFO - 2023-08-18 18:25:17 --> Model "Home_model" initialized
INFO - 2023-08-18 18:25:17 --> Helper loaded: form_helper
INFO - 2023-08-18 18:25:17 --> Form Validation Class Initialized
INFO - 2023-08-18 18:25:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 18:25:17 --> Final output sent to browser
DEBUG - 2023-08-18 18:25:17 --> Total execution time: 0.4184
INFO - 2023-08-18 18:25:17 --> Config Class Initialized
INFO - 2023-08-18 18:25:17 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:25:17 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:25:17 --> Utf8 Class Initialized
INFO - 2023-08-18 18:25:17 --> URI Class Initialized
INFO - 2023-08-18 18:25:17 --> Router Class Initialized
INFO - 2023-08-18 18:25:17 --> Output Class Initialized
INFO - 2023-08-18 18:25:17 --> Security Class Initialized
DEBUG - 2023-08-18 18:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:25:17 --> Input Class Initialized
INFO - 2023-08-18 18:25:17 --> Language Class Initialized
ERROR - 2023-08-18 18:25:17 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:25:17 --> Config Class Initialized
INFO - 2023-08-18 18:25:17 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:25:17 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:25:17 --> Utf8 Class Initialized
INFO - 2023-08-18 18:25:17 --> URI Class Initialized
INFO - 2023-08-18 18:25:17 --> Router Class Initialized
INFO - 2023-08-18 18:25:17 --> Output Class Initialized
INFO - 2023-08-18 18:25:17 --> Security Class Initialized
DEBUG - 2023-08-18 18:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:25:17 --> Input Class Initialized
INFO - 2023-08-18 18:25:17 --> Language Class Initialized
ERROR - 2023-08-18 18:25:17 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:25:18 --> Config Class Initialized
INFO - 2023-08-18 18:25:18 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:25:18 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:25:18 --> Utf8 Class Initialized
INFO - 2023-08-18 18:25:18 --> URI Class Initialized
INFO - 2023-08-18 18:25:18 --> Router Class Initialized
INFO - 2023-08-18 18:25:18 --> Output Class Initialized
INFO - 2023-08-18 18:25:18 --> Security Class Initialized
DEBUG - 2023-08-18 18:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:25:18 --> Input Class Initialized
INFO - 2023-08-18 18:25:18 --> Language Class Initialized
ERROR - 2023-08-18 18:25:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:25:18 --> Config Class Initialized
INFO - 2023-08-18 18:25:18 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:25:18 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:25:18 --> Utf8 Class Initialized
INFO - 2023-08-18 18:25:18 --> URI Class Initialized
INFO - 2023-08-18 18:25:18 --> Router Class Initialized
INFO - 2023-08-18 18:25:18 --> Output Class Initialized
INFO - 2023-08-18 18:25:18 --> Security Class Initialized
DEBUG - 2023-08-18 18:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:25:18 --> Input Class Initialized
INFO - 2023-08-18 18:25:18 --> Language Class Initialized
ERROR - 2023-08-18 18:25:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:25:18 --> Config Class Initialized
INFO - 2023-08-18 18:25:18 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:25:18 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:25:18 --> Utf8 Class Initialized
INFO - 2023-08-18 18:25:18 --> URI Class Initialized
INFO - 2023-08-18 18:25:19 --> Router Class Initialized
INFO - 2023-08-18 18:25:19 --> Output Class Initialized
INFO - 2023-08-18 18:25:19 --> Security Class Initialized
DEBUG - 2023-08-18 18:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:25:19 --> Input Class Initialized
INFO - 2023-08-18 18:25:19 --> Language Class Initialized
ERROR - 2023-08-18 18:25:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:25:19 --> Config Class Initialized
INFO - 2023-08-18 18:25:19 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:25:19 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:25:19 --> Utf8 Class Initialized
INFO - 2023-08-18 18:25:19 --> URI Class Initialized
INFO - 2023-08-18 18:25:19 --> Router Class Initialized
INFO - 2023-08-18 18:25:19 --> Output Class Initialized
INFO - 2023-08-18 18:25:19 --> Security Class Initialized
DEBUG - 2023-08-18 18:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:25:19 --> Input Class Initialized
INFO - 2023-08-18 18:25:19 --> Language Class Initialized
ERROR - 2023-08-18 18:25:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:25:28 --> Config Class Initialized
INFO - 2023-08-18 18:25:29 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:25:29 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:25:29 --> Utf8 Class Initialized
INFO - 2023-08-18 18:25:29 --> URI Class Initialized
INFO - 2023-08-18 18:25:29 --> Router Class Initialized
INFO - 2023-08-18 18:25:29 --> Output Class Initialized
INFO - 2023-08-18 18:25:29 --> Security Class Initialized
DEBUG - 2023-08-18 18:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:25:29 --> Input Class Initialized
INFO - 2023-08-18 18:25:29 --> Language Class Initialized
INFO - 2023-08-18 18:25:29 --> Loader Class Initialized
INFO - 2023-08-18 18:25:29 --> Helper loaded: url_helper
INFO - 2023-08-18 18:25:29 --> Helper loaded: file_helper
INFO - 2023-08-18 18:25:29 --> Database Driver Class Initialized
INFO - 2023-08-18 18:25:29 --> Email Class Initialized
DEBUG - 2023-08-18 18:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 18:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 18:25:29 --> Controller Class Initialized
INFO - 2023-08-18 18:25:29 --> Model "Home_model" initialized
INFO - 2023-08-18 18:25:29 --> Helper loaded: form_helper
INFO - 2023-08-18 18:25:29 --> Form Validation Class Initialized
INFO - 2023-08-18 18:25:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 18:25:29 --> Final output sent to browser
DEBUG - 2023-08-18 18:25:29 --> Total execution time: 0.3741
INFO - 2023-08-18 18:25:29 --> Config Class Initialized
INFO - 2023-08-18 18:25:29 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:25:29 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:25:29 --> Utf8 Class Initialized
INFO - 2023-08-18 18:25:29 --> URI Class Initialized
INFO - 2023-08-18 18:25:29 --> Router Class Initialized
INFO - 2023-08-18 18:25:29 --> Output Class Initialized
INFO - 2023-08-18 18:25:29 --> Security Class Initialized
DEBUG - 2023-08-18 18:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:25:29 --> Input Class Initialized
INFO - 2023-08-18 18:25:29 --> Language Class Initialized
ERROR - 2023-08-18 18:25:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:25:29 --> Config Class Initialized
INFO - 2023-08-18 18:25:29 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:25:29 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:25:29 --> Utf8 Class Initialized
INFO - 2023-08-18 18:25:29 --> URI Class Initialized
INFO - 2023-08-18 18:25:29 --> Router Class Initialized
INFO - 2023-08-18 18:25:29 --> Output Class Initialized
INFO - 2023-08-18 18:25:29 --> Security Class Initialized
DEBUG - 2023-08-18 18:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:25:29 --> Input Class Initialized
INFO - 2023-08-18 18:25:29 --> Language Class Initialized
ERROR - 2023-08-18 18:25:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:25:30 --> Config Class Initialized
INFO - 2023-08-18 18:25:30 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:25:30 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:25:30 --> Utf8 Class Initialized
INFO - 2023-08-18 18:25:30 --> URI Class Initialized
INFO - 2023-08-18 18:25:30 --> Router Class Initialized
INFO - 2023-08-18 18:25:30 --> Output Class Initialized
INFO - 2023-08-18 18:25:30 --> Security Class Initialized
DEBUG - 2023-08-18 18:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:25:30 --> Input Class Initialized
INFO - 2023-08-18 18:25:30 --> Language Class Initialized
ERROR - 2023-08-18 18:25:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:25:30 --> Config Class Initialized
INFO - 2023-08-18 18:25:30 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:25:30 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:25:30 --> Utf8 Class Initialized
INFO - 2023-08-18 18:25:30 --> URI Class Initialized
INFO - 2023-08-18 18:25:30 --> Router Class Initialized
INFO - 2023-08-18 18:25:30 --> Output Class Initialized
INFO - 2023-08-18 18:25:30 --> Security Class Initialized
DEBUG - 2023-08-18 18:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:25:30 --> Input Class Initialized
INFO - 2023-08-18 18:25:30 --> Language Class Initialized
ERROR - 2023-08-18 18:25:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:25:30 --> Config Class Initialized
INFO - 2023-08-18 18:25:30 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:25:30 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:25:30 --> Utf8 Class Initialized
INFO - 2023-08-18 18:25:30 --> URI Class Initialized
INFO - 2023-08-18 18:25:30 --> Router Class Initialized
INFO - 2023-08-18 18:25:30 --> Output Class Initialized
INFO - 2023-08-18 18:25:30 --> Security Class Initialized
DEBUG - 2023-08-18 18:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:25:30 --> Input Class Initialized
INFO - 2023-08-18 18:25:30 --> Language Class Initialized
ERROR - 2023-08-18 18:25:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 18:25:30 --> Config Class Initialized
INFO - 2023-08-18 18:25:30 --> Hooks Class Initialized
DEBUG - 2023-08-18 18:25:30 --> UTF-8 Support Enabled
INFO - 2023-08-18 18:25:30 --> Utf8 Class Initialized
INFO - 2023-08-18 18:25:30 --> URI Class Initialized
INFO - 2023-08-18 18:25:30 --> Router Class Initialized
INFO - 2023-08-18 18:25:30 --> Output Class Initialized
INFO - 2023-08-18 18:25:31 --> Security Class Initialized
DEBUG - 2023-08-18 18:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 18:25:31 --> Input Class Initialized
INFO - 2023-08-18 18:25:31 --> Language Class Initialized
ERROR - 2023-08-18 18:25:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:24:40 --> Config Class Initialized
INFO - 2023-08-18 19:24:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:24:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:24:40 --> Utf8 Class Initialized
INFO - 2023-08-18 19:24:40 --> URI Class Initialized
INFO - 2023-08-18 19:24:40 --> Router Class Initialized
INFO - 2023-08-18 19:24:40 --> Output Class Initialized
INFO - 2023-08-18 19:24:40 --> Security Class Initialized
DEBUG - 2023-08-18 19:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:24:40 --> Input Class Initialized
INFO - 2023-08-18 19:24:40 --> Language Class Initialized
ERROR - 2023-08-18 19:24:40 --> 404 Page Not Found: Training-detail/contact.html
INFO - 2023-08-18 19:24:42 --> Config Class Initialized
INFO - 2023-08-18 19:24:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:24:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:24:42 --> Utf8 Class Initialized
INFO - 2023-08-18 19:24:42 --> URI Class Initialized
INFO - 2023-08-18 19:24:42 --> Router Class Initialized
INFO - 2023-08-18 19:24:42 --> Output Class Initialized
INFO - 2023-08-18 19:24:42 --> Security Class Initialized
DEBUG - 2023-08-18 19:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:24:42 --> Input Class Initialized
INFO - 2023-08-18 19:24:42 --> Language Class Initialized
INFO - 2023-08-18 19:24:42 --> Loader Class Initialized
INFO - 2023-08-18 19:24:42 --> Helper loaded: url_helper
INFO - 2023-08-18 19:24:42 --> Helper loaded: file_helper
INFO - 2023-08-18 19:24:42 --> Database Driver Class Initialized
INFO - 2023-08-18 19:24:42 --> Email Class Initialized
DEBUG - 2023-08-18 19:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:24:42 --> Controller Class Initialized
INFO - 2023-08-18 19:24:42 --> Model "Home_model" initialized
INFO - 2023-08-18 19:24:42 --> Helper loaded: form_helper
INFO - 2023-08-18 19:24:42 --> Form Validation Class Initialized
INFO - 2023-08-18 19:24:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 19:24:42 --> Final output sent to browser
DEBUG - 2023-08-18 19:24:42 --> Total execution time: 0.1140
INFO - 2023-08-18 19:26:19 --> Config Class Initialized
INFO - 2023-08-18 19:26:19 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:26:19 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:26:19 --> Utf8 Class Initialized
INFO - 2023-08-18 19:26:19 --> URI Class Initialized
INFO - 2023-08-18 19:26:19 --> Router Class Initialized
INFO - 2023-08-18 19:26:19 --> Output Class Initialized
INFO - 2023-08-18 19:26:19 --> Security Class Initialized
DEBUG - 2023-08-18 19:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:26:19 --> Input Class Initialized
INFO - 2023-08-18 19:26:19 --> Language Class Initialized
INFO - 2023-08-18 19:26:19 --> Loader Class Initialized
INFO - 2023-08-18 19:26:19 --> Helper loaded: url_helper
INFO - 2023-08-18 19:26:19 --> Helper loaded: file_helper
INFO - 2023-08-18 19:26:19 --> Database Driver Class Initialized
INFO - 2023-08-18 19:26:20 --> Email Class Initialized
DEBUG - 2023-08-18 19:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:26:20 --> Controller Class Initialized
INFO - 2023-08-18 19:26:20 --> Model "Home_model" initialized
INFO - 2023-08-18 19:26:20 --> Helper loaded: form_helper
INFO - 2023-08-18 19:26:20 --> Form Validation Class Initialized
INFO - 2023-08-18 19:26:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 19:26:20 --> Final output sent to browser
DEBUG - 2023-08-18 19:26:20 --> Total execution time: 0.4494
INFO - 2023-08-18 19:26:20 --> Config Class Initialized
INFO - 2023-08-18 19:26:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:26:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:26:20 --> Utf8 Class Initialized
INFO - 2023-08-18 19:26:20 --> URI Class Initialized
INFO - 2023-08-18 19:26:20 --> Router Class Initialized
INFO - 2023-08-18 19:26:20 --> Output Class Initialized
INFO - 2023-08-18 19:26:20 --> Security Class Initialized
DEBUG - 2023-08-18 19:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:26:20 --> Input Class Initialized
INFO - 2023-08-18 19:26:20 --> Language Class Initialized
ERROR - 2023-08-18 19:26:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:26:20 --> Config Class Initialized
INFO - 2023-08-18 19:26:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:26:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:26:20 --> Utf8 Class Initialized
INFO - 2023-08-18 19:26:20 --> URI Class Initialized
INFO - 2023-08-18 19:26:20 --> Router Class Initialized
INFO - 2023-08-18 19:26:20 --> Output Class Initialized
INFO - 2023-08-18 19:26:20 --> Security Class Initialized
DEBUG - 2023-08-18 19:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:26:20 --> Input Class Initialized
INFO - 2023-08-18 19:26:20 --> Language Class Initialized
ERROR - 2023-08-18 19:26:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:26:21 --> Config Class Initialized
INFO - 2023-08-18 19:26:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:26:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:26:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:26:21 --> URI Class Initialized
INFO - 2023-08-18 19:26:21 --> Router Class Initialized
INFO - 2023-08-18 19:26:21 --> Output Class Initialized
INFO - 2023-08-18 19:26:21 --> Security Class Initialized
DEBUG - 2023-08-18 19:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:26:21 --> Input Class Initialized
INFO - 2023-08-18 19:26:21 --> Language Class Initialized
ERROR - 2023-08-18 19:26:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:26:21 --> Config Class Initialized
INFO - 2023-08-18 19:26:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:26:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:26:21 --> Config Class Initialized
INFO - 2023-08-18 19:26:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:26:21 --> Config Class Initialized
INFO - 2023-08-18 19:26:21 --> URI Class Initialized
INFO - 2023-08-18 19:26:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:26:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:26:21 --> Hooks Class Initialized
INFO - 2023-08-18 19:26:21 --> Router Class Initialized
DEBUG - 2023-08-18 19:26:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:26:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:26:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:26:21 --> Output Class Initialized
INFO - 2023-08-18 19:26:21 --> URI Class Initialized
INFO - 2023-08-18 19:26:21 --> Security Class Initialized
INFO - 2023-08-18 19:26:21 --> Router Class Initialized
INFO - 2023-08-18 19:26:21 --> URI Class Initialized
INFO - 2023-08-18 19:26:21 --> Router Class Initialized
DEBUG - 2023-08-18 19:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:26:21 --> Output Class Initialized
INFO - 2023-08-18 19:26:21 --> Output Class Initialized
INFO - 2023-08-18 19:26:21 --> Security Class Initialized
INFO - 2023-08-18 19:26:21 --> Input Class Initialized
INFO - 2023-08-18 19:26:21 --> Language Class Initialized
DEBUG - 2023-08-18 19:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:26:21 --> Security Class Initialized
INFO - 2023-08-18 19:26:21 --> Input Class Initialized
DEBUG - 2023-08-18 19:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:26:21 --> Input Class Initialized
INFO - 2023-08-18 19:26:21 --> Language Class Initialized
ERROR - 2023-08-18 19:26:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:26:21 --> Language Class Initialized
ERROR - 2023-08-18 19:26:21 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-18 19:26:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:26:53 --> Config Class Initialized
INFO - 2023-08-18 19:26:53 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:26:53 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:26:53 --> Utf8 Class Initialized
INFO - 2023-08-18 19:26:53 --> URI Class Initialized
INFO - 2023-08-18 19:26:53 --> Router Class Initialized
INFO - 2023-08-18 19:26:53 --> Output Class Initialized
INFO - 2023-08-18 19:26:53 --> Security Class Initialized
DEBUG - 2023-08-18 19:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:26:53 --> Input Class Initialized
INFO - 2023-08-18 19:26:53 --> Language Class Initialized
INFO - 2023-08-18 19:26:53 --> Loader Class Initialized
INFO - 2023-08-18 19:26:53 --> Helper loaded: url_helper
INFO - 2023-08-18 19:26:53 --> Helper loaded: file_helper
INFO - 2023-08-18 19:26:53 --> Database Driver Class Initialized
INFO - 2023-08-18 19:26:53 --> Email Class Initialized
DEBUG - 2023-08-18 19:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:26:53 --> Controller Class Initialized
INFO - 2023-08-18 19:26:54 --> Model "Home_model" initialized
INFO - 2023-08-18 19:26:54 --> Helper loaded: form_helper
INFO - 2023-08-18 19:26:54 --> Form Validation Class Initialized
INFO - 2023-08-18 19:26:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 19:26:54 --> Final output sent to browser
DEBUG - 2023-08-18 19:26:54 --> Total execution time: 0.4371
INFO - 2023-08-18 19:26:55 --> Config Class Initialized
INFO - 2023-08-18 19:26:55 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:26:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:26:55 --> Utf8 Class Initialized
INFO - 2023-08-18 19:26:55 --> URI Class Initialized
INFO - 2023-08-18 19:26:55 --> Router Class Initialized
INFO - 2023-08-18 19:26:55 --> Output Class Initialized
INFO - 2023-08-18 19:26:55 --> Security Class Initialized
DEBUG - 2023-08-18 19:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:26:55 --> Input Class Initialized
INFO - 2023-08-18 19:26:55 --> Language Class Initialized
ERROR - 2023-08-18 19:26:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:26:55 --> Config Class Initialized
INFO - 2023-08-18 19:26:55 --> Config Class Initialized
INFO - 2023-08-18 19:26:55 --> Hooks Class Initialized
INFO - 2023-08-18 19:26:55 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:26:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:26:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:26:55 --> Utf8 Class Initialized
INFO - 2023-08-18 19:26:55 --> Config Class Initialized
INFO - 2023-08-18 19:26:55 --> Utf8 Class Initialized
INFO - 2023-08-18 19:26:55 --> Config Class Initialized
INFO - 2023-08-18 19:26:55 --> URI Class Initialized
INFO - 2023-08-18 19:26:55 --> Hooks Class Initialized
INFO - 2023-08-18 19:26:55 --> URI Class Initialized
DEBUG - 2023-08-18 19:26:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:26:55 --> Utf8 Class Initialized
INFO - 2023-08-18 19:26:55 --> Router Class Initialized
INFO - 2023-08-18 19:26:55 --> URI Class Initialized
INFO - 2023-08-18 19:26:55 --> Router Class Initialized
INFO - 2023-08-18 19:26:55 --> Hooks Class Initialized
INFO - 2023-08-18 19:26:55 --> Output Class Initialized
INFO - 2023-08-18 19:26:55 --> Router Class Initialized
DEBUG - 2023-08-18 19:26:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:26:55 --> Output Class Initialized
INFO - 2023-08-18 19:26:55 --> Security Class Initialized
INFO - 2023-08-18 19:26:55 --> Security Class Initialized
INFO - 2023-08-18 19:26:55 --> Output Class Initialized
INFO - 2023-08-18 19:26:55 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:26:55 --> Input Class Initialized
INFO - 2023-08-18 19:26:55 --> Language Class Initialized
ERROR - 2023-08-18 19:26:55 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-18 19:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:26:55 --> Security Class Initialized
INFO - 2023-08-18 19:26:55 --> Input Class Initialized
INFO - 2023-08-18 19:26:55 --> URI Class Initialized
INFO - 2023-08-18 19:26:55 --> Router Class Initialized
INFO - 2023-08-18 19:26:55 --> Output Class Initialized
INFO - 2023-08-18 19:26:55 --> Security Class Initialized
DEBUG - 2023-08-18 19:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:26:55 --> Input Class Initialized
INFO - 2023-08-18 19:26:55 --> Language Class Initialized
ERROR - 2023-08-18 19:26:55 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-18 19:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:28:05 --> Config Class Initialized
INFO - 2023-08-18 19:28:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:28:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:28:05 --> Utf8 Class Initialized
INFO - 2023-08-18 19:28:05 --> URI Class Initialized
INFO - 2023-08-18 19:28:05 --> Router Class Initialized
INFO - 2023-08-18 19:28:05 --> Output Class Initialized
INFO - 2023-08-18 19:28:05 --> Security Class Initialized
DEBUG - 2023-08-18 19:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:28:05 --> Input Class Initialized
INFO - 2023-08-18 19:28:05 --> Language Class Initialized
INFO - 2023-08-18 19:28:05 --> Loader Class Initialized
INFO - 2023-08-18 19:28:05 --> Helper loaded: url_helper
INFO - 2023-08-18 19:28:05 --> Helper loaded: file_helper
INFO - 2023-08-18 19:28:05 --> Database Driver Class Initialized
INFO - 2023-08-18 19:28:05 --> Email Class Initialized
DEBUG - 2023-08-18 19:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:28:06 --> Controller Class Initialized
INFO - 2023-08-18 19:28:06 --> Model "Home_model" initialized
INFO - 2023-08-18 19:28:06 --> Helper loaded: form_helper
INFO - 2023-08-18 19:28:06 --> Form Validation Class Initialized
INFO - 2023-08-18 19:28:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 19:28:06 --> Final output sent to browser
DEBUG - 2023-08-18 19:28:06 --> Total execution time: 0.4386
INFO - 2023-08-18 19:28:07 --> Config Class Initialized
INFO - 2023-08-18 19:28:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:28:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:28:07 --> Utf8 Class Initialized
INFO - 2023-08-18 19:28:07 --> URI Class Initialized
INFO - 2023-08-18 19:28:07 --> Router Class Initialized
INFO - 2023-08-18 19:28:07 --> Output Class Initialized
INFO - 2023-08-18 19:28:07 --> Security Class Initialized
DEBUG - 2023-08-18 19:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:28:07 --> Input Class Initialized
INFO - 2023-08-18 19:28:07 --> Language Class Initialized
ERROR - 2023-08-18 19:28:07 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:28:07 --> Config Class Initialized
INFO - 2023-08-18 19:28:07 --> Hooks Class Initialized
INFO - 2023-08-18 19:28:07 --> Config Class Initialized
INFO - 2023-08-18 19:28:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:28:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:28:07 --> Utf8 Class Initialized
INFO - 2023-08-18 19:28:07 --> URI Class Initialized
DEBUG - 2023-08-18 19:28:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:28:07 --> Router Class Initialized
INFO - 2023-08-18 19:28:07 --> Config Class Initialized
INFO - 2023-08-18 19:28:07 --> Config Class Initialized
INFO - 2023-08-18 19:28:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:28:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:28:07 --> Utf8 Class Initialized
INFO - 2023-08-18 19:28:07 --> URI Class Initialized
INFO - 2023-08-18 19:28:07 --> Router Class Initialized
INFO - 2023-08-18 19:28:07 --> Output Class Initialized
INFO - 2023-08-18 19:28:07 --> Security Class Initialized
DEBUG - 2023-08-18 19:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:28:07 --> Input Class Initialized
INFO - 2023-08-18 19:28:07 --> Language Class Initialized
ERROR - 2023-08-18 19:28:07 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:28:07 --> Output Class Initialized
INFO - 2023-08-18 19:28:07 --> Hooks Class Initialized
INFO - 2023-08-18 19:28:07 --> Security Class Initialized
DEBUG - 2023-08-18 19:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:28:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:28:08 --> Utf8 Class Initialized
INFO - 2023-08-18 19:28:08 --> Utf8 Class Initialized
INFO - 2023-08-18 19:28:08 --> Input Class Initialized
INFO - 2023-08-18 19:28:08 --> URI Class Initialized
INFO - 2023-08-18 19:28:08 --> Language Class Initialized
INFO - 2023-08-18 19:28:08 --> Router Class Initialized
INFO - 2023-08-18 19:28:08 --> URI Class Initialized
ERROR - 2023-08-18 19:28:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:28:08 --> Output Class Initialized
INFO - 2023-08-18 19:28:08 --> Router Class Initialized
INFO - 2023-08-18 19:28:08 --> Security Class Initialized
INFO - 2023-08-18 19:28:08 --> Output Class Initialized
DEBUG - 2023-08-18 19:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:28:08 --> Input Class Initialized
INFO - 2023-08-18 19:28:08 --> Security Class Initialized
INFO - 2023-08-18 19:28:08 --> Language Class Initialized
ERROR - 2023-08-18 19:28:08 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-18 19:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:28:08 --> Input Class Initialized
INFO - 2023-08-18 19:28:08 --> Language Class Initialized
ERROR - 2023-08-18 19:28:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:29:59 --> Config Class Initialized
INFO - 2023-08-18 19:29:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:29:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:29:59 --> Utf8 Class Initialized
INFO - 2023-08-18 19:29:59 --> URI Class Initialized
INFO - 2023-08-18 19:29:59 --> Router Class Initialized
INFO - 2023-08-18 19:29:59 --> Output Class Initialized
INFO - 2023-08-18 19:29:59 --> Security Class Initialized
DEBUG - 2023-08-18 19:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:29:59 --> Input Class Initialized
INFO - 2023-08-18 19:29:59 --> Language Class Initialized
INFO - 2023-08-18 19:29:59 --> Loader Class Initialized
INFO - 2023-08-18 19:29:59 --> Helper loaded: url_helper
INFO - 2023-08-18 19:29:59 --> Helper loaded: file_helper
INFO - 2023-08-18 19:29:59 --> Database Driver Class Initialized
INFO - 2023-08-18 19:29:59 --> Email Class Initialized
DEBUG - 2023-08-18 19:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:29:59 --> Controller Class Initialized
INFO - 2023-08-18 19:29:59 --> Model "Home_model" initialized
INFO - 2023-08-18 19:29:59 --> Helper loaded: form_helper
INFO - 2023-08-18 19:29:59 --> Form Validation Class Initialized
INFO - 2023-08-18 19:29:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 19:29:59 --> Final output sent to browser
DEBUG - 2023-08-18 19:30:00 --> Total execution time: 0.5613
INFO - 2023-08-18 19:30:01 --> Config Class Initialized
INFO - 2023-08-18 19:30:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:30:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:30:01 --> Utf8 Class Initialized
INFO - 2023-08-18 19:30:01 --> URI Class Initialized
INFO - 2023-08-18 19:30:01 --> Router Class Initialized
INFO - 2023-08-18 19:30:01 --> Output Class Initialized
INFO - 2023-08-18 19:30:01 --> Security Class Initialized
DEBUG - 2023-08-18 19:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:30:01 --> Input Class Initialized
INFO - 2023-08-18 19:30:01 --> Language Class Initialized
ERROR - 2023-08-18 19:30:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:30:01 --> Config Class Initialized
INFO - 2023-08-18 19:30:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:30:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:30:01 --> Utf8 Class Initialized
INFO - 2023-08-18 19:30:01 --> URI Class Initialized
INFO - 2023-08-18 19:30:01 --> Router Class Initialized
INFO - 2023-08-18 19:30:01 --> Output Class Initialized
INFO - 2023-08-18 19:30:01 --> Security Class Initialized
DEBUG - 2023-08-18 19:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:30:01 --> Input Class Initialized
INFO - 2023-08-18 19:30:01 --> Language Class Initialized
ERROR - 2023-08-18 19:30:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:30:02 --> Config Class Initialized
INFO - 2023-08-18 19:30:02 --> Config Class Initialized
INFO - 2023-08-18 19:30:02 --> Hooks Class Initialized
INFO - 2023-08-18 19:30:02 --> Hooks Class Initialized
INFO - 2023-08-18 19:30:02 --> Config Class Initialized
DEBUG - 2023-08-18 19:30:02 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:30:02 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:30:02 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:30:02 --> Utf8 Class Initialized
INFO - 2023-08-18 19:30:02 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:30:02 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:30:02 --> URI Class Initialized
INFO - 2023-08-18 19:30:02 --> Utf8 Class Initialized
INFO - 2023-08-18 19:30:02 --> URI Class Initialized
INFO - 2023-08-18 19:30:02 --> Router Class Initialized
INFO - 2023-08-18 19:30:02 --> Router Class Initialized
INFO - 2023-08-18 19:30:02 --> Output Class Initialized
INFO - 2023-08-18 19:30:02 --> URI Class Initialized
INFO - 2023-08-18 19:30:02 --> Security Class Initialized
DEBUG - 2023-08-18 19:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:30:02 --> Output Class Initialized
INFO - 2023-08-18 19:30:02 --> Router Class Initialized
INFO - 2023-08-18 19:30:02 --> Security Class Initialized
INFO - 2023-08-18 19:30:02 --> Input Class Initialized
DEBUG - 2023-08-18 19:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:30:02 --> Language Class Initialized
INFO - 2023-08-18 19:30:02 --> Output Class Initialized
INFO - 2023-08-18 19:30:02 --> Input Class Initialized
INFO - 2023-08-18 19:30:02 --> Security Class Initialized
INFO - 2023-08-18 19:30:02 --> Language Class Initialized
ERROR - 2023-08-18 19:30:02 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-18 19:30:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-18 19:30:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:30:02 --> Input Class Initialized
INFO - 2023-08-18 19:30:02 --> Language Class Initialized
ERROR - 2023-08-18 19:30:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:30:04 --> Config Class Initialized
INFO - 2023-08-18 19:30:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:30:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:30:04 --> Utf8 Class Initialized
INFO - 2023-08-18 19:30:04 --> URI Class Initialized
INFO - 2023-08-18 19:30:04 --> Router Class Initialized
INFO - 2023-08-18 19:30:04 --> Output Class Initialized
INFO - 2023-08-18 19:30:04 --> Security Class Initialized
DEBUG - 2023-08-18 19:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:30:05 --> Input Class Initialized
INFO - 2023-08-18 19:30:05 --> Language Class Initialized
INFO - 2023-08-18 19:30:05 --> Loader Class Initialized
INFO - 2023-08-18 19:30:05 --> Helper loaded: url_helper
INFO - 2023-08-18 19:30:05 --> Helper loaded: file_helper
INFO - 2023-08-18 19:30:05 --> Database Driver Class Initialized
INFO - 2023-08-18 19:30:05 --> Email Class Initialized
DEBUG - 2023-08-18 19:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:30:05 --> Controller Class Initialized
INFO - 2023-08-18 19:30:05 --> Model "Home_model" initialized
INFO - 2023-08-18 19:30:05 --> Helper loaded: form_helper
INFO - 2023-08-18 19:30:05 --> Form Validation Class Initialized
INFO - 2023-08-18 19:30:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-18 19:30:05 --> Final output sent to browser
DEBUG - 2023-08-18 19:30:05 --> Total execution time: 0.5647
INFO - 2023-08-18 19:30:06 --> Config Class Initialized
INFO - 2023-08-18 19:30:06 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:30:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:30:06 --> Utf8 Class Initialized
INFO - 2023-08-18 19:30:06 --> URI Class Initialized
INFO - 2023-08-18 19:30:06 --> Router Class Initialized
INFO - 2023-08-18 19:30:06 --> Config Class Initialized
INFO - 2023-08-18 19:30:06 --> Config Class Initialized
INFO - 2023-08-18 19:30:06 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:30:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:30:06 --> Hooks Class Initialized
INFO - 2023-08-18 19:30:06 --> Config Class Initialized
INFO - 2023-08-18 19:30:06 --> Hooks Class Initialized
INFO - 2023-08-18 19:30:06 --> Output Class Initialized
INFO - 2023-08-18 19:30:06 --> Utf8 Class Initialized
INFO - 2023-08-18 19:30:06 --> Security Class Initialized
INFO - 2023-08-18 19:30:06 --> URI Class Initialized
INFO - 2023-08-18 19:30:06 --> Router Class Initialized
INFO - 2023-08-18 19:30:06 --> Config Class Initialized
DEBUG - 2023-08-18 19:30:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:30:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:30:06 --> Output Class Initialized
INFO - 2023-08-18 19:30:06 --> Utf8 Class Initialized
INFO - 2023-08-18 19:30:06 --> Utf8 Class Initialized
INFO - 2023-08-18 19:30:06 --> URI Class Initialized
INFO - 2023-08-18 19:30:06 --> Router Class Initialized
INFO - 2023-08-18 19:30:06 --> URI Class Initialized
INFO - 2023-08-18 19:30:06 --> Hooks Class Initialized
INFO - 2023-08-18 19:30:06 --> Security Class Initialized
INFO - 2023-08-18 19:30:06 --> Input Class Initialized
INFO - 2023-08-18 19:30:06 --> Router Class Initialized
INFO - 2023-08-18 19:30:06 --> Config Class Initialized
INFO - 2023-08-18 19:30:06 --> Output Class Initialized
INFO - 2023-08-18 19:30:06 --> Hooks Class Initialized
INFO - 2023-08-18 19:30:06 --> Language Class Initialized
DEBUG - 2023-08-18 19:30:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:30:06 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:30:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:30:06 --> Output Class Initialized
INFO - 2023-08-18 19:30:06 --> Security Class Initialized
ERROR - 2023-08-18 19:30:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:30:06 --> URI Class Initialized
INFO - 2023-08-18 19:30:06 --> Utf8 Class Initialized
INFO - 2023-08-18 19:30:06 --> Router Class Initialized
DEBUG - 2023-08-18 19:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:30:06 --> URI Class Initialized
INFO - 2023-08-18 19:30:06 --> Security Class Initialized
INFO - 2023-08-18 19:30:06 --> Output Class Initialized
INFO - 2023-08-18 19:30:06 --> Input Class Initialized
INFO - 2023-08-18 19:30:06 --> Security Class Initialized
INFO - 2023-08-18 19:30:07 --> Router Class Initialized
DEBUG - 2023-08-18 19:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:30:07 --> Output Class Initialized
INFO - 2023-08-18 19:30:07 --> Input Class Initialized
INFO - 2023-08-18 19:30:07 --> Language Class Initialized
INFO - 2023-08-18 19:30:07 --> Language Class Initialized
INFO - 2023-08-18 19:30:07 --> Security Class Initialized
DEBUG - 2023-08-18 19:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:30:07 --> Input Class Initialized
DEBUG - 2023-08-18 19:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:30:07 --> Input Class Initialized
INFO - 2023-08-18 19:30:07 --> Language Class Initialized
INFO - 2023-08-18 19:30:07 --> Input Class Initialized
ERROR - 2023-08-18 19:30:07 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 19:30:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:30:07 --> Language Class Initialized
INFO - 2023-08-18 19:30:07 --> Language Class Initialized
ERROR - 2023-08-18 19:30:07 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 19:30:07 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 19:30:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:32:34 --> Config Class Initialized
INFO - 2023-08-18 19:32:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:32:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:32:34 --> Utf8 Class Initialized
INFO - 2023-08-18 19:32:34 --> URI Class Initialized
INFO - 2023-08-18 19:32:34 --> Router Class Initialized
INFO - 2023-08-18 19:32:34 --> Output Class Initialized
INFO - 2023-08-18 19:32:34 --> Security Class Initialized
DEBUG - 2023-08-18 19:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:32:34 --> Input Class Initialized
INFO - 2023-08-18 19:32:34 --> Language Class Initialized
INFO - 2023-08-18 19:32:34 --> Loader Class Initialized
INFO - 2023-08-18 19:32:34 --> Helper loaded: url_helper
INFO - 2023-08-18 19:32:34 --> Helper loaded: file_helper
INFO - 2023-08-18 19:32:34 --> Database Driver Class Initialized
INFO - 2023-08-18 19:32:34 --> Email Class Initialized
DEBUG - 2023-08-18 19:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:32:34 --> Controller Class Initialized
INFO - 2023-08-18 19:32:34 --> Model "Home_model" initialized
INFO - 2023-08-18 19:32:34 --> Helper loaded: form_helper
INFO - 2023-08-18 19:32:34 --> Form Validation Class Initialized
INFO - 2023-08-18 19:32:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-18 19:32:34 --> Final output sent to browser
DEBUG - 2023-08-18 19:32:34 --> Total execution time: 0.4512
INFO - 2023-08-18 19:32:35 --> Config Class Initialized
INFO - 2023-08-18 19:32:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:32:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:32:35 --> Utf8 Class Initialized
INFO - 2023-08-18 19:32:35 --> URI Class Initialized
INFO - 2023-08-18 19:32:35 --> Router Class Initialized
INFO - 2023-08-18 19:32:36 --> Output Class Initialized
INFO - 2023-08-18 19:32:36 --> Security Class Initialized
DEBUG - 2023-08-18 19:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:32:36 --> Input Class Initialized
INFO - 2023-08-18 19:32:36 --> Language Class Initialized
ERROR - 2023-08-18 19:32:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:32:36 --> Config Class Initialized
INFO - 2023-08-18 19:32:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:32:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:32:36 --> Utf8 Class Initialized
INFO - 2023-08-18 19:32:36 --> URI Class Initialized
INFO - 2023-08-18 19:32:36 --> Router Class Initialized
INFO - 2023-08-18 19:32:36 --> Output Class Initialized
INFO - 2023-08-18 19:32:36 --> Security Class Initialized
DEBUG - 2023-08-18 19:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:32:36 --> Input Class Initialized
INFO - 2023-08-18 19:32:36 --> Language Class Initialized
ERROR - 2023-08-18 19:32:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:32:36 --> Config Class Initialized
INFO - 2023-08-18 19:32:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:32:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:32:36 --> Utf8 Class Initialized
INFO - 2023-08-18 19:32:36 --> URI Class Initialized
INFO - 2023-08-18 19:32:36 --> Router Class Initialized
INFO - 2023-08-18 19:32:36 --> Output Class Initialized
INFO - 2023-08-18 19:32:36 --> Security Class Initialized
DEBUG - 2023-08-18 19:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:32:36 --> Input Class Initialized
INFO - 2023-08-18 19:32:36 --> Language Class Initialized
ERROR - 2023-08-18 19:32:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:32:38 --> Config Class Initialized
INFO - 2023-08-18 19:32:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:32:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:32:38 --> Utf8 Class Initialized
INFO - 2023-08-18 19:32:38 --> URI Class Initialized
INFO - 2023-08-18 19:32:38 --> Router Class Initialized
INFO - 2023-08-18 19:32:38 --> Output Class Initialized
INFO - 2023-08-18 19:32:38 --> Security Class Initialized
DEBUG - 2023-08-18 19:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:32:38 --> Input Class Initialized
INFO - 2023-08-18 19:32:38 --> Language Class Initialized
ERROR - 2023-08-18 19:32:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:32:38 --> Config Class Initialized
INFO - 2023-08-18 19:32:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:32:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:32:38 --> Utf8 Class Initialized
INFO - 2023-08-18 19:32:38 --> URI Class Initialized
INFO - 2023-08-18 19:32:38 --> Router Class Initialized
INFO - 2023-08-18 19:32:38 --> Output Class Initialized
INFO - 2023-08-18 19:32:38 --> Security Class Initialized
DEBUG - 2023-08-18 19:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:32:38 --> Input Class Initialized
INFO - 2023-08-18 19:32:38 --> Language Class Initialized
ERROR - 2023-08-18 19:32:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:32:38 --> Config Class Initialized
INFO - 2023-08-18 19:32:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:32:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:32:38 --> Utf8 Class Initialized
INFO - 2023-08-18 19:32:38 --> URI Class Initialized
INFO - 2023-08-18 19:32:38 --> Router Class Initialized
INFO - 2023-08-18 19:32:38 --> Output Class Initialized
INFO - 2023-08-18 19:32:38 --> Security Class Initialized
DEBUG - 2023-08-18 19:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:32:38 --> Input Class Initialized
INFO - 2023-08-18 19:32:38 --> Language Class Initialized
ERROR - 2023-08-18 19:32:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:32:39 --> Config Class Initialized
INFO - 2023-08-18 19:32:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:32:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:32:39 --> Utf8 Class Initialized
INFO - 2023-08-18 19:32:39 --> URI Class Initialized
INFO - 2023-08-18 19:32:39 --> Router Class Initialized
INFO - 2023-08-18 19:32:39 --> Output Class Initialized
INFO - 2023-08-18 19:32:39 --> Security Class Initialized
DEBUG - 2023-08-18 19:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:32:39 --> Input Class Initialized
INFO - 2023-08-18 19:32:39 --> Language Class Initialized
ERROR - 2023-08-18 19:32:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:32:39 --> Config Class Initialized
INFO - 2023-08-18 19:32:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:32:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:32:39 --> Utf8 Class Initialized
INFO - 2023-08-18 19:32:39 --> URI Class Initialized
INFO - 2023-08-18 19:32:39 --> Router Class Initialized
INFO - 2023-08-18 19:32:39 --> Output Class Initialized
INFO - 2023-08-18 19:32:39 --> Security Class Initialized
DEBUG - 2023-08-18 19:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:32:39 --> Input Class Initialized
INFO - 2023-08-18 19:32:39 --> Language Class Initialized
ERROR - 2023-08-18 19:32:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:32:39 --> Config Class Initialized
INFO - 2023-08-18 19:32:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:32:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:32:39 --> Utf8 Class Initialized
INFO - 2023-08-18 19:32:39 --> URI Class Initialized
INFO - 2023-08-18 19:32:39 --> Router Class Initialized
INFO - 2023-08-18 19:32:39 --> Output Class Initialized
INFO - 2023-08-18 19:32:39 --> Security Class Initialized
DEBUG - 2023-08-18 19:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:32:39 --> Input Class Initialized
INFO - 2023-08-18 19:32:39 --> Language Class Initialized
ERROR - 2023-08-18 19:32:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:32:39 --> Config Class Initialized
INFO - 2023-08-18 19:32:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:32:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:32:39 --> Utf8 Class Initialized
INFO - 2023-08-18 19:32:39 --> URI Class Initialized
INFO - 2023-08-18 19:32:39 --> Router Class Initialized
INFO - 2023-08-18 19:32:39 --> Output Class Initialized
INFO - 2023-08-18 19:32:39 --> Security Class Initialized
DEBUG - 2023-08-18 19:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:32:39 --> Input Class Initialized
INFO - 2023-08-18 19:32:39 --> Language Class Initialized
ERROR - 2023-08-18 19:32:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:32:40 --> Config Class Initialized
INFO - 2023-08-18 19:32:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:32:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:32:40 --> Utf8 Class Initialized
INFO - 2023-08-18 19:32:40 --> URI Class Initialized
INFO - 2023-08-18 19:32:40 --> Router Class Initialized
INFO - 2023-08-18 19:32:40 --> Output Class Initialized
INFO - 2023-08-18 19:32:40 --> Security Class Initialized
DEBUG - 2023-08-18 19:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:32:40 --> Input Class Initialized
INFO - 2023-08-18 19:32:40 --> Language Class Initialized
ERROR - 2023-08-18 19:32:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:32:40 --> Config Class Initialized
INFO - 2023-08-18 19:32:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:32:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:32:40 --> Utf8 Class Initialized
INFO - 2023-08-18 19:32:40 --> URI Class Initialized
INFO - 2023-08-18 19:32:40 --> Router Class Initialized
INFO - 2023-08-18 19:32:40 --> Output Class Initialized
INFO - 2023-08-18 19:32:40 --> Security Class Initialized
DEBUG - 2023-08-18 19:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:32:40 --> Input Class Initialized
INFO - 2023-08-18 19:32:40 --> Language Class Initialized
ERROR - 2023-08-18 19:32:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:34:40 --> Config Class Initialized
INFO - 2023-08-18 19:34:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:34:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:34:40 --> Utf8 Class Initialized
INFO - 2023-08-18 19:34:40 --> URI Class Initialized
INFO - 2023-08-18 19:34:40 --> Router Class Initialized
INFO - 2023-08-18 19:34:40 --> Output Class Initialized
INFO - 2023-08-18 19:34:40 --> Security Class Initialized
DEBUG - 2023-08-18 19:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:34:40 --> Input Class Initialized
INFO - 2023-08-18 19:34:40 --> Language Class Initialized
INFO - 2023-08-18 19:34:40 --> Loader Class Initialized
INFO - 2023-08-18 19:34:40 --> Helper loaded: url_helper
INFO - 2023-08-18 19:34:40 --> Helper loaded: file_helper
INFO - 2023-08-18 19:34:40 --> Database Driver Class Initialized
INFO - 2023-08-18 19:34:40 --> Email Class Initialized
DEBUG - 2023-08-18 19:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:34:40 --> Controller Class Initialized
INFO - 2023-08-18 19:34:40 --> Model "Home_model" initialized
INFO - 2023-08-18 19:34:40 --> Helper loaded: form_helper
INFO - 2023-08-18 19:34:40 --> Form Validation Class Initialized
INFO - 2023-08-18 19:34:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-18 19:34:40 --> Final output sent to browser
DEBUG - 2023-08-18 19:34:40 --> Total execution time: 0.4608
INFO - 2023-08-18 19:34:40 --> Config Class Initialized
INFO - 2023-08-18 19:34:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:34:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:34:40 --> Utf8 Class Initialized
INFO - 2023-08-18 19:34:40 --> URI Class Initialized
INFO - 2023-08-18 19:34:40 --> Router Class Initialized
INFO - 2023-08-18 19:34:40 --> Output Class Initialized
INFO - 2023-08-18 19:34:40 --> Security Class Initialized
DEBUG - 2023-08-18 19:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:34:40 --> Input Class Initialized
INFO - 2023-08-18 19:34:40 --> Language Class Initialized
ERROR - 2023-08-18 19:34:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:34:41 --> Config Class Initialized
INFO - 2023-08-18 19:34:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:34:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:34:41 --> Config Class Initialized
INFO - 2023-08-18 19:34:41 --> Config Class Initialized
INFO - 2023-08-18 19:34:41 --> Hooks Class Initialized
INFO - 2023-08-18 19:34:41 --> Hooks Class Initialized
INFO - 2023-08-18 19:34:41 --> Utf8 Class Initialized
INFO - 2023-08-18 19:34:41 --> Config Class Initialized
DEBUG - 2023-08-18 19:34:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:34:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:34:42 --> Utf8 Class Initialized
INFO - 2023-08-18 19:34:42 --> URI Class Initialized
INFO - 2023-08-18 19:34:42 --> Router Class Initialized
INFO - 2023-08-18 19:34:42 --> Output Class Initialized
INFO - 2023-08-18 19:34:42 --> Security Class Initialized
DEBUG - 2023-08-18 19:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:34:42 --> Input Class Initialized
INFO - 2023-08-18 19:34:42 --> Language Class Initialized
ERROR - 2023-08-18 19:34:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:34:42 --> Utf8 Class Initialized
INFO - 2023-08-18 19:34:42 --> URI Class Initialized
INFO - 2023-08-18 19:34:42 --> URI Class Initialized
INFO - 2023-08-18 19:34:42 --> Router Class Initialized
INFO - 2023-08-18 19:34:42 --> Config Class Initialized
INFO - 2023-08-18 19:34:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:34:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:34:42 --> Utf8 Class Initialized
INFO - 2023-08-18 19:34:42 --> URI Class Initialized
INFO - 2023-08-18 19:34:42 --> Router Class Initialized
INFO - 2023-08-18 19:34:42 --> Output Class Initialized
INFO - 2023-08-18 19:34:42 --> Security Class Initialized
DEBUG - 2023-08-18 19:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:34:42 --> Input Class Initialized
INFO - 2023-08-18 19:34:42 --> Language Class Initialized
ERROR - 2023-08-18 19:34:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:34:42 --> Output Class Initialized
INFO - 2023-08-18 19:34:42 --> Config Class Initialized
INFO - 2023-08-18 19:34:42 --> Hooks Class Initialized
INFO - 2023-08-18 19:34:42 --> Security Class Initialized
INFO - 2023-08-18 19:34:42 --> Router Class Initialized
DEBUG - 2023-08-18 19:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:34:42 --> Hooks Class Initialized
INFO - 2023-08-18 19:34:42 --> Output Class Initialized
DEBUG - 2023-08-18 19:34:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:34:42 --> Input Class Initialized
INFO - 2023-08-18 19:34:42 --> Utf8 Class Initialized
INFO - 2023-08-18 19:34:42 --> Security Class Initialized
DEBUG - 2023-08-18 19:34:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:34:42 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:34:42 --> URI Class Initialized
INFO - 2023-08-18 19:34:42 --> Language Class Initialized
INFO - 2023-08-18 19:34:42 --> URI Class Initialized
ERROR - 2023-08-18 19:34:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:34:42 --> Input Class Initialized
INFO - 2023-08-18 19:34:42 --> Router Class Initialized
INFO - 2023-08-18 19:34:42 --> Router Class Initialized
INFO - 2023-08-18 19:34:42 --> Language Class Initialized
INFO - 2023-08-18 19:34:42 --> Output Class Initialized
ERROR - 2023-08-18 19:34:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:34:42 --> Output Class Initialized
INFO - 2023-08-18 19:34:42 --> Security Class Initialized
DEBUG - 2023-08-18 19:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:34:42 --> Security Class Initialized
INFO - 2023-08-18 19:34:42 --> Input Class Initialized
DEBUG - 2023-08-18 19:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:34:42 --> Language Class Initialized
INFO - 2023-08-18 19:34:42 --> Input Class Initialized
ERROR - 2023-08-18 19:34:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:34:42 --> Language Class Initialized
ERROR - 2023-08-18 19:34:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:01 --> Config Class Initialized
INFO - 2023-08-18 19:35:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:01 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:01 --> URI Class Initialized
INFO - 2023-08-18 19:35:01 --> Router Class Initialized
INFO - 2023-08-18 19:35:01 --> Output Class Initialized
INFO - 2023-08-18 19:35:01 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:01 --> Input Class Initialized
INFO - 2023-08-18 19:35:01 --> Language Class Initialized
INFO - 2023-08-18 19:35:01 --> Loader Class Initialized
INFO - 2023-08-18 19:35:01 --> Helper loaded: url_helper
INFO - 2023-08-18 19:35:01 --> Helper loaded: file_helper
INFO - 2023-08-18 19:35:01 --> Database Driver Class Initialized
INFO - 2023-08-18 19:35:01 --> Email Class Initialized
DEBUG - 2023-08-18 19:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:35:01 --> Controller Class Initialized
INFO - 2023-08-18 19:35:01 --> Model "Home_model" initialized
INFO - 2023-08-18 19:35:01 --> Helper loaded: form_helper
INFO - 2023-08-18 19:35:02 --> Form Validation Class Initialized
INFO - 2023-08-18 19:35:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-18 19:35:02 --> Final output sent to browser
DEBUG - 2023-08-18 19:35:02 --> Total execution time: 0.4678
INFO - 2023-08-18 19:35:02 --> Config Class Initialized
INFO - 2023-08-18 19:35:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:03 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:03 --> URI Class Initialized
INFO - 2023-08-18 19:35:03 --> Router Class Initialized
INFO - 2023-08-18 19:35:03 --> Output Class Initialized
INFO - 2023-08-18 19:35:03 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:03 --> Input Class Initialized
INFO - 2023-08-18 19:35:03 --> Language Class Initialized
ERROR - 2023-08-18 19:35:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:03 --> Config Class Initialized
INFO - 2023-08-18 19:35:03 --> Config Class Initialized
INFO - 2023-08-18 19:35:03 --> Hooks Class Initialized
INFO - 2023-08-18 19:35:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:03 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:35:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:03 --> URI Class Initialized
INFO - 2023-08-18 19:35:03 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:03 --> Router Class Initialized
INFO - 2023-08-18 19:35:03 --> URI Class Initialized
INFO - 2023-08-18 19:35:03 --> Output Class Initialized
INFO - 2023-08-18 19:35:03 --> Router Class Initialized
INFO - 2023-08-18 19:35:03 --> Security Class Initialized
INFO - 2023-08-18 19:35:03 --> Output Class Initialized
INFO - 2023-08-18 19:35:03 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:03 --> Input Class Initialized
INFO - 2023-08-18 19:35:03 --> Input Class Initialized
INFO - 2023-08-18 19:35:03 --> Language Class Initialized
INFO - 2023-08-18 19:35:03 --> Language Class Initialized
ERROR - 2023-08-18 19:35:03 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 19:35:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:04 --> Config Class Initialized
INFO - 2023-08-18 19:35:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:04 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:04 --> URI Class Initialized
INFO - 2023-08-18 19:35:04 --> Router Class Initialized
INFO - 2023-08-18 19:35:04 --> Output Class Initialized
INFO - 2023-08-18 19:35:04 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:04 --> Input Class Initialized
INFO - 2023-08-18 19:35:04 --> Language Class Initialized
ERROR - 2023-08-18 19:35:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:04 --> Config Class Initialized
INFO - 2023-08-18 19:35:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:04 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:04 --> URI Class Initialized
INFO - 2023-08-18 19:35:04 --> Router Class Initialized
INFO - 2023-08-18 19:35:04 --> Output Class Initialized
INFO - 2023-08-18 19:35:04 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:04 --> Input Class Initialized
INFO - 2023-08-18 19:35:04 --> Language Class Initialized
ERROR - 2023-08-18 19:35:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:05 --> Config Class Initialized
INFO - 2023-08-18 19:35:05 --> Hooks Class Initialized
INFO - 2023-08-18 19:35:05 --> Config Class Initialized
DEBUG - 2023-08-18 19:35:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:05 --> Config Class Initialized
INFO - 2023-08-18 19:35:05 --> Hooks Class Initialized
INFO - 2023-08-18 19:35:05 --> Config Class Initialized
INFO - 2023-08-18 19:35:05 --> Hooks Class Initialized
INFO - 2023-08-18 19:35:05 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:35:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:05 --> URI Class Initialized
INFO - 2023-08-18 19:35:05 --> Hooks Class Initialized
INFO - 2023-08-18 19:35:05 --> Router Class Initialized
DEBUG - 2023-08-18 19:35:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:35:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:05 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:05 --> Output Class Initialized
INFO - 2023-08-18 19:35:05 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:05 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:05 --> URI Class Initialized
INFO - 2023-08-18 19:35:06 --> URI Class Initialized
INFO - 2023-08-18 19:35:06 --> Router Class Initialized
INFO - 2023-08-18 19:35:06 --> Security Class Initialized
INFO - 2023-08-18 19:35:06 --> URI Class Initialized
INFO - 2023-08-18 19:35:06 --> Router Class Initialized
INFO - 2023-08-18 19:35:06 --> Router Class Initialized
DEBUG - 2023-08-18 19:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:06 --> Output Class Initialized
INFO - 2023-08-18 19:35:06 --> Output Class Initialized
INFO - 2023-08-18 19:35:06 --> Output Class Initialized
INFO - 2023-08-18 19:35:06 --> Security Class Initialized
INFO - 2023-08-18 19:35:06 --> Security Class Initialized
INFO - 2023-08-18 19:35:06 --> Input Class Initialized
INFO - 2023-08-18 19:35:06 --> Language Class Initialized
INFO - 2023-08-18 19:35:06 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:06 --> Input Class Initialized
INFO - 2023-08-18 19:35:06 --> Language Class Initialized
DEBUG - 2023-08-18 19:35:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-18 19:35:06 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 19:35:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:06 --> Input Class Initialized
INFO - 2023-08-18 19:35:06 --> Input Class Initialized
INFO - 2023-08-18 19:35:06 --> Language Class Initialized
INFO - 2023-08-18 19:35:06 --> Language Class Initialized
ERROR - 2023-08-18 19:35:06 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 19:35:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:18 --> Config Class Initialized
INFO - 2023-08-18 19:35:18 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:18 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:18 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:18 --> URI Class Initialized
INFO - 2023-08-18 19:35:18 --> Router Class Initialized
INFO - 2023-08-18 19:35:18 --> Output Class Initialized
INFO - 2023-08-18 19:35:18 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:18 --> Input Class Initialized
INFO - 2023-08-18 19:35:18 --> Language Class Initialized
INFO - 2023-08-18 19:35:18 --> Loader Class Initialized
INFO - 2023-08-18 19:35:18 --> Helper loaded: url_helper
INFO - 2023-08-18 19:35:18 --> Helper loaded: file_helper
INFO - 2023-08-18 19:35:18 --> Database Driver Class Initialized
INFO - 2023-08-18 19:35:18 --> Email Class Initialized
DEBUG - 2023-08-18 19:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:35:18 --> Controller Class Initialized
INFO - 2023-08-18 19:35:18 --> Model "Home_model" initialized
INFO - 2023-08-18 19:35:18 --> Helper loaded: form_helper
INFO - 2023-08-18 19:35:18 --> Form Validation Class Initialized
INFO - 2023-08-18 19:35:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-18 19:35:19 --> Final output sent to browser
DEBUG - 2023-08-18 19:35:19 --> Total execution time: 0.4069
INFO - 2023-08-18 19:35:20 --> Config Class Initialized
INFO - 2023-08-18 19:35:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:20 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:20 --> URI Class Initialized
INFO - 2023-08-18 19:35:20 --> Router Class Initialized
INFO - 2023-08-18 19:35:20 --> Output Class Initialized
INFO - 2023-08-18 19:35:20 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:20 --> Input Class Initialized
INFO - 2023-08-18 19:35:20 --> Language Class Initialized
ERROR - 2023-08-18 19:35:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:21 --> Config Class Initialized
INFO - 2023-08-18 19:35:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:21 --> URI Class Initialized
INFO - 2023-08-18 19:35:21 --> Router Class Initialized
INFO - 2023-08-18 19:35:21 --> Output Class Initialized
INFO - 2023-08-18 19:35:21 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:21 --> Input Class Initialized
INFO - 2023-08-18 19:35:21 --> Language Class Initialized
ERROR - 2023-08-18 19:35:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:21 --> Config Class Initialized
INFO - 2023-08-18 19:35:21 --> Config Class Initialized
INFO - 2023-08-18 19:35:21 --> Hooks Class Initialized
INFO - 2023-08-18 19:35:21 --> Config Class Initialized
INFO - 2023-08-18 19:35:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:21 --> Hooks Class Initialized
INFO - 2023-08-18 19:35:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:21 --> Config Class Initialized
DEBUG - 2023-08-18 19:35:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:35:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:21 --> URI Class Initialized
INFO - 2023-08-18 19:35:21 --> Router Class Initialized
INFO - 2023-08-18 19:35:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:21 --> Output Class Initialized
INFO - 2023-08-18 19:35:21 --> Hooks Class Initialized
INFO - 2023-08-18 19:35:21 --> URI Class Initialized
INFO - 2023-08-18 19:35:21 --> Router Class Initialized
INFO - 2023-08-18 19:35:21 --> URI Class Initialized
DEBUG - 2023-08-18 19:35:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:21 --> Security Class Initialized
INFO - 2023-08-18 19:35:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:21 --> Output Class Initialized
INFO - 2023-08-18 19:35:21 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:21 --> Router Class Initialized
DEBUG - 2023-08-18 19:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:21 --> URI Class Initialized
INFO - 2023-08-18 19:35:21 --> Input Class Initialized
INFO - 2023-08-18 19:35:21 --> Input Class Initialized
INFO - 2023-08-18 19:35:21 --> Language Class Initialized
INFO - 2023-08-18 19:35:21 --> Output Class Initialized
INFO - 2023-08-18 19:35:21 --> Security Class Initialized
INFO - 2023-08-18 19:35:21 --> Router Class Initialized
ERROR - 2023-08-18 19:35:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:21 --> Output Class Initialized
INFO - 2023-08-18 19:35:21 --> Language Class Initialized
DEBUG - 2023-08-18 19:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:21 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:21 --> Input Class Initialized
ERROR - 2023-08-18 19:35:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:21 --> Input Class Initialized
INFO - 2023-08-18 19:35:21 --> Language Class Initialized
INFO - 2023-08-18 19:35:21 --> Language Class Initialized
ERROR - 2023-08-18 19:35:21 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 19:35:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:30 --> Config Class Initialized
INFO - 2023-08-18 19:35:30 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:30 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:30 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:30 --> URI Class Initialized
INFO - 2023-08-18 19:35:34 --> Config Class Initialized
INFO - 2023-08-18 19:35:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:35 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:35 --> URI Class Initialized
INFO - 2023-08-18 19:35:35 --> Router Class Initialized
INFO - 2023-08-18 19:35:35 --> Output Class Initialized
INFO - 2023-08-18 19:35:35 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:35 --> Input Class Initialized
INFO - 2023-08-18 19:35:35 --> Language Class Initialized
INFO - 2023-08-18 19:35:35 --> Loader Class Initialized
INFO - 2023-08-18 19:35:35 --> Helper loaded: url_helper
INFO - 2023-08-18 19:35:35 --> Helper loaded: file_helper
INFO - 2023-08-18 19:35:35 --> Database Driver Class Initialized
INFO - 2023-08-18 19:35:35 --> Email Class Initialized
DEBUG - 2023-08-18 19:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:35:35 --> Controller Class Initialized
INFO - 2023-08-18 19:35:35 --> Model "Home_model" initialized
INFO - 2023-08-18 19:35:35 --> Helper loaded: form_helper
INFO - 2023-08-18 19:35:35 --> Form Validation Class Initialized
INFO - 2023-08-18 19:35:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-18 19:35:35 --> Final output sent to browser
DEBUG - 2023-08-18 19:35:35 --> Total execution time: 0.3855
INFO - 2023-08-18 19:35:35 --> Config Class Initialized
INFO - 2023-08-18 19:35:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:35 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:35 --> URI Class Initialized
INFO - 2023-08-18 19:35:35 --> Router Class Initialized
INFO - 2023-08-18 19:35:35 --> Output Class Initialized
INFO - 2023-08-18 19:35:35 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:35 --> Input Class Initialized
INFO - 2023-08-18 19:35:35 --> Language Class Initialized
ERROR - 2023-08-18 19:35:35 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:36 --> Config Class Initialized
INFO - 2023-08-18 19:35:36 --> Config Class Initialized
INFO - 2023-08-18 19:35:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:36 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:36 --> URI Class Initialized
INFO - 2023-08-18 19:35:36 --> Router Class Initialized
INFO - 2023-08-18 19:35:36 --> Output Class Initialized
INFO - 2023-08-18 19:35:36 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:36 --> Input Class Initialized
INFO - 2023-08-18 19:35:36 --> Language Class Initialized
ERROR - 2023-08-18 19:35:36 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:35:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:36 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:36 --> URI Class Initialized
INFO - 2023-08-18 19:35:36 --> Router Class Initialized
INFO - 2023-08-18 19:35:36 --> Config Class Initialized
INFO - 2023-08-18 19:35:37 --> Config Class Initialized
INFO - 2023-08-18 19:35:37 --> Hooks Class Initialized
INFO - 2023-08-18 19:35:37 --> Config Class Initialized
INFO - 2023-08-18 19:35:37 --> Config Class Initialized
INFO - 2023-08-18 19:35:37 --> Output Class Initialized
INFO - 2023-08-18 19:35:37 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:35:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:37 --> Hooks Class Initialized
INFO - 2023-08-18 19:35:37 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:35:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:35:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:37 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:37 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:37 --> Hooks Class Initialized
INFO - 2023-08-18 19:35:37 --> URI Class Initialized
INFO - 2023-08-18 19:35:37 --> Input Class Initialized
INFO - 2023-08-18 19:35:37 --> URI Class Initialized
INFO - 2023-08-18 19:35:37 --> Utf8 Class Initialized
INFO - 2023-08-18 19:35:37 --> Language Class Initialized
INFO - 2023-08-18 19:35:37 --> Router Class Initialized
ERROR - 2023-08-18 19:35:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:37 --> Router Class Initialized
DEBUG - 2023-08-18 19:35:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:35:37 --> Output Class Initialized
INFO - 2023-08-18 19:35:37 --> Output Class Initialized
INFO - 2023-08-18 19:35:37 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:37 --> Input Class Initialized
INFO - 2023-08-18 19:35:37 --> Language Class Initialized
ERROR - 2023-08-18 19:35:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:37 --> URI Class Initialized
INFO - 2023-08-18 19:35:37 --> Security Class Initialized
INFO - 2023-08-18 19:35:37 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:37 --> URI Class Initialized
INFO - 2023-08-18 19:35:37 --> Router Class Initialized
INFO - 2023-08-18 19:35:37 --> Router Class Initialized
INFO - 2023-08-18 19:35:37 --> Output Class Initialized
INFO - 2023-08-18 19:35:37 --> Input Class Initialized
INFO - 2023-08-18 19:35:37 --> Output Class Initialized
INFO - 2023-08-18 19:35:37 --> Language Class Initialized
INFO - 2023-08-18 19:35:37 --> Security Class Initialized
ERROR - 2023-08-18 19:35:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:35:37 --> Security Class Initialized
DEBUG - 2023-08-18 19:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:35:37 --> Input Class Initialized
INFO - 2023-08-18 19:35:37 --> Input Class Initialized
INFO - 2023-08-18 19:35:37 --> Language Class Initialized
INFO - 2023-08-18 19:35:37 --> Language Class Initialized
ERROR - 2023-08-18 19:35:37 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 19:35:37 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:36:52 --> Config Class Initialized
INFO - 2023-08-18 19:36:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:36:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:36:52 --> Utf8 Class Initialized
INFO - 2023-08-18 19:36:52 --> URI Class Initialized
INFO - 2023-08-18 19:36:52 --> Router Class Initialized
INFO - 2023-08-18 19:36:52 --> Output Class Initialized
INFO - 2023-08-18 19:36:52 --> Security Class Initialized
DEBUG - 2023-08-18 19:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:36:52 --> Input Class Initialized
INFO - 2023-08-18 19:36:52 --> Language Class Initialized
INFO - 2023-08-18 19:36:52 --> Loader Class Initialized
INFO - 2023-08-18 19:36:52 --> Helper loaded: url_helper
INFO - 2023-08-18 19:36:52 --> Helper loaded: file_helper
INFO - 2023-08-18 19:36:52 --> Database Driver Class Initialized
INFO - 2023-08-18 19:36:52 --> Email Class Initialized
DEBUG - 2023-08-18 19:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:36:52 --> Controller Class Initialized
INFO - 2023-08-18 19:36:52 --> Model "Home_model" initialized
INFO - 2023-08-18 19:36:52 --> Helper loaded: form_helper
INFO - 2023-08-18 19:36:52 --> Form Validation Class Initialized
INFO - 2023-08-18 19:36:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-18 19:36:52 --> Final output sent to browser
DEBUG - 2023-08-18 19:36:53 --> Total execution time: 0.4730
INFO - 2023-08-18 19:36:53 --> Config Class Initialized
INFO - 2023-08-18 19:36:53 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:36:53 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:36:53 --> Utf8 Class Initialized
INFO - 2023-08-18 19:36:53 --> URI Class Initialized
INFO - 2023-08-18 19:36:53 --> Router Class Initialized
INFO - 2023-08-18 19:36:53 --> Output Class Initialized
INFO - 2023-08-18 19:36:54 --> Security Class Initialized
DEBUG - 2023-08-18 19:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:36:54 --> Input Class Initialized
INFO - 2023-08-18 19:36:54 --> Language Class Initialized
ERROR - 2023-08-18 19:36:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:36:54 --> Config Class Initialized
INFO - 2023-08-18 19:36:54 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:36:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:36:54 --> Utf8 Class Initialized
INFO - 2023-08-18 19:36:54 --> URI Class Initialized
INFO - 2023-08-18 19:36:54 --> Router Class Initialized
INFO - 2023-08-18 19:36:54 --> Output Class Initialized
INFO - 2023-08-18 19:36:54 --> Security Class Initialized
DEBUG - 2023-08-18 19:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:36:54 --> Input Class Initialized
INFO - 2023-08-18 19:36:54 --> Language Class Initialized
ERROR - 2023-08-18 19:36:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:36:54 --> Config Class Initialized
INFO - 2023-08-18 19:36:54 --> Config Class Initialized
INFO - 2023-08-18 19:36:54 --> Hooks Class Initialized
INFO - 2023-08-18 19:36:54 --> Config Class Initialized
INFO - 2023-08-18 19:36:54 --> Config Class Initialized
DEBUG - 2023-08-18 19:36:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:36:54 --> Hooks Class Initialized
INFO - 2023-08-18 19:36:54 --> Utf8 Class Initialized
INFO - 2023-08-18 19:36:54 --> Hooks Class Initialized
INFO - 2023-08-18 19:36:54 --> URI Class Initialized
DEBUG - 2023-08-18 19:36:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:36:54 --> Router Class Initialized
INFO - 2023-08-18 19:36:54 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:36:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:36:54 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:36:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:36:54 --> URI Class Initialized
INFO - 2023-08-18 19:36:54 --> Router Class Initialized
INFO - 2023-08-18 19:36:54 --> Output Class Initialized
INFO - 2023-08-18 19:36:54 --> Security Class Initialized
DEBUG - 2023-08-18 19:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:36:54 --> Input Class Initialized
INFO - 2023-08-18 19:36:54 --> Language Class Initialized
ERROR - 2023-08-18 19:36:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:36:54 --> Utf8 Class Initialized
INFO - 2023-08-18 19:36:55 --> Utf8 Class Initialized
INFO - 2023-08-18 19:36:55 --> Output Class Initialized
INFO - 2023-08-18 19:36:55 --> URI Class Initialized
INFO - 2023-08-18 19:36:55 --> URI Class Initialized
INFO - 2023-08-18 19:36:55 --> Router Class Initialized
INFO - 2023-08-18 19:36:55 --> Security Class Initialized
INFO - 2023-08-18 19:36:55 --> Router Class Initialized
DEBUG - 2023-08-18 19:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:36:56 --> Input Class Initialized
INFO - 2023-08-18 19:36:56 --> Output Class Initialized
INFO - 2023-08-18 19:36:56 --> Language Class Initialized
INFO - 2023-08-18 19:36:56 --> Output Class Initialized
INFO - 2023-08-18 19:36:56 --> Security Class Initialized
INFO - 2023-08-18 19:36:56 --> Security Class Initialized
DEBUG - 2023-08-18 19:36:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-18 19:36:56 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 19:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:36:56 --> Input Class Initialized
INFO - 2023-08-18 19:36:56 --> Input Class Initialized
INFO - 2023-08-18 19:36:56 --> Language Class Initialized
ERROR - 2023-08-18 19:36:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:36:56 --> Language Class Initialized
ERROR - 2023-08-18 19:36:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:36:58 --> Config Class Initialized
INFO - 2023-08-18 19:36:59 --> Hooks Class Initialized
INFO - 2023-08-18 19:36:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-18 19:36:59 --> Final output sent to browser
DEBUG - 2023-08-18 19:36:59 --> Total execution time: 0.1909
INFO - 2023-08-18 19:36:59 --> Config Class Initialized
INFO - 2023-08-18 19:36:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:36:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:36:59 --> Utf8 Class Initialized
INFO - 2023-08-18 19:36:59 --> URI Class Initialized
INFO - 2023-08-18 19:36:59 --> Router Class Initialized
INFO - 2023-08-18 19:36:59 --> Output Class Initialized
INFO - 2023-08-18 19:36:59 --> Security Class Initialized
DEBUG - 2023-08-18 19:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:36:59 --> Input Class Initialized
INFO - 2023-08-18 19:36:59 --> Language Class Initialized
ERROR - 2023-08-18 19:36:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:36:59 --> Config Class Initialized
INFO - 2023-08-18 19:36:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:36:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:36:59 --> Utf8 Class Initialized
INFO - 2023-08-18 19:36:59 --> URI Class Initialized
INFO - 2023-08-18 19:36:59 --> Router Class Initialized
INFO - 2023-08-18 19:37:00 --> Config Class Initialized
INFO - 2023-08-18 19:37:00 --> Output Class Initialized
INFO - 2023-08-18 19:37:00 --> Hooks Class Initialized
INFO - 2023-08-18 19:37:00 --> Security Class Initialized
INFO - 2023-08-18 19:37:00 --> Config Class Initialized
INFO - 2023-08-18 19:37:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:37:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:37:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:37:00 --> Utf8 Class Initialized
INFO - 2023-08-18 19:37:00 --> Utf8 Class Initialized
INFO - 2023-08-18 19:37:00 --> Input Class Initialized
INFO - 2023-08-18 19:37:00 --> URI Class Initialized
INFO - 2023-08-18 19:37:00 --> Language Class Initialized
INFO - 2023-08-18 19:37:00 --> Router Class Initialized
INFO - 2023-08-18 19:37:00 --> URI Class Initialized
INFO - 2023-08-18 19:37:00 --> Output Class Initialized
INFO - 2023-08-18 19:37:00 --> Security Class Initialized
INFO - 2023-08-18 19:37:00 --> Router Class Initialized
ERROR - 2023-08-18 19:37:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:37:00 --> Output Class Initialized
INFO - 2023-08-18 19:37:01 --> Config Class Initialized
INFO - 2023-08-18 19:37:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:37:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:37:01 --> Utf8 Class Initialized
INFO - 2023-08-18 19:37:01 --> URI Class Initialized
INFO - 2023-08-18 19:37:01 --> Router Class Initialized
INFO - 2023-08-18 19:37:01 --> Output Class Initialized
INFO - 2023-08-18 19:37:01 --> Security Class Initialized
DEBUG - 2023-08-18 19:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:37:01 --> Input Class Initialized
INFO - 2023-08-18 19:37:01 --> Language Class Initialized
DEBUG - 2023-08-18 19:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:37:01 --> Security Class Initialized
INFO - 2023-08-18 19:37:01 --> Input Class Initialized
INFO - 2023-08-18 19:37:01 --> Config Class Initialized
ERROR - 2023-08-18 19:37:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:37:01 --> Language Class Initialized
DEBUG - 2023-08-18 19:37:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-18 19:37:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:37:01 --> Input Class Initialized
INFO - 2023-08-18 19:37:01 --> Config Class Initialized
INFO - 2023-08-18 19:37:01 --> Language Class Initialized
ERROR - 2023-08-18 19:37:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:37:01 --> Hooks Class Initialized
INFO - 2023-08-18 19:37:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:37:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:37:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:37:01 --> Utf8 Class Initialized
INFO - 2023-08-18 19:37:01 --> Utf8 Class Initialized
INFO - 2023-08-18 19:37:01 --> URI Class Initialized
INFO - 2023-08-18 19:37:01 --> URI Class Initialized
INFO - 2023-08-18 19:37:01 --> Router Class Initialized
INFO - 2023-08-18 19:37:01 --> Router Class Initialized
INFO - 2023-08-18 19:37:01 --> Output Class Initialized
INFO - 2023-08-18 19:37:01 --> Security Class Initialized
DEBUG - 2023-08-18 19:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:37:01 --> Input Class Initialized
INFO - 2023-08-18 19:37:01 --> Language Class Initialized
ERROR - 2023-08-18 19:37:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:37:01 --> Output Class Initialized
INFO - 2023-08-18 19:37:01 --> Security Class Initialized
DEBUG - 2023-08-18 19:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:37:01 --> Input Class Initialized
INFO - 2023-08-18 19:37:01 --> Language Class Initialized
ERROR - 2023-08-18 19:37:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:37:01 --> Config Class Initialized
INFO - 2023-08-18 19:37:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:37:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:37:01 --> Utf8 Class Initialized
INFO - 2023-08-18 19:37:01 --> URI Class Initialized
INFO - 2023-08-18 19:37:01 --> Router Class Initialized
INFO - 2023-08-18 19:37:01 --> Output Class Initialized
INFO - 2023-08-18 19:37:01 --> Security Class Initialized
DEBUG - 2023-08-18 19:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:37:01 --> Input Class Initialized
INFO - 2023-08-18 19:37:01 --> Language Class Initialized
ERROR - 2023-08-18 19:37:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:39:30 --> Config Class Initialized
INFO - 2023-08-18 19:39:30 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:39:30 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:39:30 --> Utf8 Class Initialized
INFO - 2023-08-18 19:39:30 --> URI Class Initialized
INFO - 2023-08-18 19:39:30 --> Router Class Initialized
INFO - 2023-08-18 19:39:30 --> Output Class Initialized
INFO - 2023-08-18 19:39:30 --> Security Class Initialized
DEBUG - 2023-08-18 19:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:39:30 --> Input Class Initialized
INFO - 2023-08-18 19:39:30 --> Language Class Initialized
ERROR - 2023-08-18 19:39:30 --> 404 Page Not Found: Indexhtml/index
INFO - 2023-08-18 19:39:32 --> Config Class Initialized
INFO - 2023-08-18 19:39:32 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:39:32 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:39:32 --> Utf8 Class Initialized
INFO - 2023-08-18 19:39:32 --> URI Class Initialized
INFO - 2023-08-18 19:39:32 --> Router Class Initialized
INFO - 2023-08-18 19:39:32 --> Output Class Initialized
INFO - 2023-08-18 19:39:32 --> Security Class Initialized
DEBUG - 2023-08-18 19:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:39:32 --> Input Class Initialized
INFO - 2023-08-18 19:39:32 --> Language Class Initialized
INFO - 2023-08-18 19:39:32 --> Loader Class Initialized
INFO - 2023-08-18 19:39:32 --> Helper loaded: url_helper
INFO - 2023-08-18 19:39:32 --> Helper loaded: file_helper
INFO - 2023-08-18 19:39:32 --> Database Driver Class Initialized
INFO - 2023-08-18 19:39:32 --> Email Class Initialized
DEBUG - 2023-08-18 19:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:39:32 --> Controller Class Initialized
INFO - 2023-08-18 19:39:32 --> Model "Home_model" initialized
INFO - 2023-08-18 19:39:32 --> Helper loaded: form_helper
INFO - 2023-08-18 19:39:32 --> Form Validation Class Initialized
INFO - 2023-08-18 19:39:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-18 19:39:32 --> Final output sent to browser
DEBUG - 2023-08-18 19:39:32 --> Total execution time: 0.0562
INFO - 2023-08-18 19:41:33 --> Config Class Initialized
INFO - 2023-08-18 19:41:33 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:41:33 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:41:33 --> Utf8 Class Initialized
INFO - 2023-08-18 19:41:33 --> URI Class Initialized
INFO - 2023-08-18 19:41:33 --> Router Class Initialized
INFO - 2023-08-18 19:41:33 --> Output Class Initialized
INFO - 2023-08-18 19:41:33 --> Security Class Initialized
DEBUG - 2023-08-18 19:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:41:33 --> Input Class Initialized
INFO - 2023-08-18 19:41:33 --> Language Class Initialized
INFO - 2023-08-18 19:41:33 --> Loader Class Initialized
INFO - 2023-08-18 19:41:33 --> Helper loaded: url_helper
INFO - 2023-08-18 19:41:33 --> Helper loaded: file_helper
INFO - 2023-08-18 19:41:33 --> Database Driver Class Initialized
INFO - 2023-08-18 19:41:33 --> Email Class Initialized
DEBUG - 2023-08-18 19:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:41:34 --> Controller Class Initialized
INFO - 2023-08-18 19:41:34 --> Model "Home_model" initialized
INFO - 2023-08-18 19:41:34 --> Helper loaded: form_helper
INFO - 2023-08-18 19:41:34 --> Form Validation Class Initialized
INFO - 2023-08-18 19:41:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-18 19:41:34 --> Final output sent to browser
DEBUG - 2023-08-18 19:41:34 --> Total execution time: 0.4864
INFO - 2023-08-18 19:41:35 --> Config Class Initialized
INFO - 2023-08-18 19:41:35 --> Hooks Class Initialized
INFO - 2023-08-18 19:41:35 --> Config Class Initialized
INFO - 2023-08-18 19:41:35 --> Config Class Initialized
INFO - 2023-08-18 19:41:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:41:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:41:35 --> Hooks Class Initialized
INFO - 2023-08-18 19:41:35 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:41:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:41:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:41:35 --> URI Class Initialized
INFO - 2023-08-18 19:41:35 --> Utf8 Class Initialized
INFO - 2023-08-18 19:41:35 --> URI Class Initialized
INFO - 2023-08-18 19:41:35 --> Router Class Initialized
INFO - 2023-08-18 19:41:35 --> Router Class Initialized
INFO - 2023-08-18 19:41:35 --> Utf8 Class Initialized
INFO - 2023-08-18 19:41:35 --> URI Class Initialized
INFO - 2023-08-18 19:41:35 --> Output Class Initialized
INFO - 2023-08-18 19:41:35 --> Output Class Initialized
INFO - 2023-08-18 19:41:35 --> Router Class Initialized
INFO - 2023-08-18 19:41:35 --> Security Class Initialized
INFO - 2023-08-18 19:41:35 --> Output Class Initialized
INFO - 2023-08-18 19:41:35 --> Security Class Initialized
INFO - 2023-08-18 19:41:35 --> Security Class Initialized
DEBUG - 2023-08-18 19:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:41:35 --> Input Class Initialized
INFO - 2023-08-18 19:41:35 --> Language Class Initialized
DEBUG - 2023-08-18 19:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:41:35 --> Input Class Initialized
INFO - 2023-08-18 19:41:35 --> Input Class Initialized
INFO - 2023-08-18 19:41:35 --> Language Class Initialized
INFO - 2023-08-18 19:41:35 --> Language Class Initialized
ERROR - 2023-08-18 19:41:35 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-18 19:41:35 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-18 19:41:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:41:35 --> Config Class Initialized
INFO - 2023-08-18 19:41:35 --> Hooks Class Initialized
INFO - 2023-08-18 19:41:36 --> Config Class Initialized
DEBUG - 2023-08-18 19:41:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:41:36 --> Hooks Class Initialized
INFO - 2023-08-18 19:41:36 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:41:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:41:36 --> URI Class Initialized
INFO - 2023-08-18 19:41:36 --> Utf8 Class Initialized
INFO - 2023-08-18 19:41:36 --> Router Class Initialized
INFO - 2023-08-18 19:41:36 --> URI Class Initialized
INFO - 2023-08-18 19:41:36 --> Output Class Initialized
INFO - 2023-08-18 19:41:36 --> Router Class Initialized
INFO - 2023-08-18 19:41:36 --> Security Class Initialized
INFO - 2023-08-18 19:41:36 --> Output Class Initialized
INFO - 2023-08-18 19:41:36 --> Security Class Initialized
DEBUG - 2023-08-18 19:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:41:36 --> Input Class Initialized
INFO - 2023-08-18 19:41:36 --> Input Class Initialized
INFO - 2023-08-18 19:41:36 --> Language Class Initialized
INFO - 2023-08-18 19:41:36 --> Language Class Initialized
ERROR - 2023-08-18 19:41:36 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-18 19:41:36 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-18 19:41:38 --> Config Class Initialized
INFO - 2023-08-18 19:41:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:41:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:41:38 --> Utf8 Class Initialized
INFO - 2023-08-18 19:41:38 --> URI Class Initialized
INFO - 2023-08-18 19:41:38 --> Router Class Initialized
INFO - 2023-08-18 19:41:38 --> Output Class Initialized
INFO - 2023-08-18 19:41:38 --> Security Class Initialized
DEBUG - 2023-08-18 19:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:41:38 --> Input Class Initialized
INFO - 2023-08-18 19:41:38 --> Language Class Initialized
INFO - 2023-08-18 19:41:38 --> Loader Class Initialized
INFO - 2023-08-18 19:41:38 --> Helper loaded: url_helper
INFO - 2023-08-18 19:41:38 --> Helper loaded: file_helper
INFO - 2023-08-18 19:41:38 --> Database Driver Class Initialized
INFO - 2023-08-18 19:41:38 --> Email Class Initialized
DEBUG - 2023-08-18 19:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:41:39 --> Controller Class Initialized
INFO - 2023-08-18 19:41:39 --> Model "Home_model" initialized
INFO - 2023-08-18 19:41:39 --> Helper loaded: form_helper
INFO - 2023-08-18 19:41:39 --> Form Validation Class Initialized
INFO - 2023-08-18 19:41:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-18 19:41:39 --> Final output sent to browser
DEBUG - 2023-08-18 19:41:39 --> Total execution time: 1.2718
INFO - 2023-08-18 19:54:02 --> Config Class Initialized
INFO - 2023-08-18 19:54:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:54:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:54:03 --> Utf8 Class Initialized
INFO - 2023-08-18 19:54:03 --> URI Class Initialized
INFO - 2023-08-18 19:54:03 --> Router Class Initialized
INFO - 2023-08-18 19:54:03 --> Output Class Initialized
INFO - 2023-08-18 19:54:03 --> Security Class Initialized
DEBUG - 2023-08-18 19:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:54:03 --> Input Class Initialized
INFO - 2023-08-18 19:54:03 --> Language Class Initialized
INFO - 2023-08-18 19:54:03 --> Loader Class Initialized
INFO - 2023-08-18 19:54:03 --> Helper loaded: url_helper
INFO - 2023-08-18 19:54:03 --> Helper loaded: file_helper
INFO - 2023-08-18 19:54:03 --> Database Driver Class Initialized
INFO - 2023-08-18 19:54:03 --> Email Class Initialized
DEBUG - 2023-08-18 19:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:54:04 --> Controller Class Initialized
ERROR - 2023-08-18 19:54:04 --> Severity: Compile Error --> Cannot redeclare Home_model::get_blog_by_id() C:\xampp\htdocs\dw\application\models\Home_model.php 53
INFO - 2023-08-18 19:55:34 --> Config Class Initialized
INFO - 2023-08-18 19:55:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:34 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:34 --> URI Class Initialized
INFO - 2023-08-18 19:55:34 --> Router Class Initialized
INFO - 2023-08-18 19:55:34 --> Output Class Initialized
INFO - 2023-08-18 19:55:34 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:34 --> Input Class Initialized
INFO - 2023-08-18 19:55:34 --> Language Class Initialized
INFO - 2023-08-18 19:55:34 --> Loader Class Initialized
INFO - 2023-08-18 19:55:34 --> Helper loaded: url_helper
INFO - 2023-08-18 19:55:34 --> Helper loaded: file_helper
INFO - 2023-08-18 19:55:34 --> Database Driver Class Initialized
INFO - 2023-08-18 19:55:34 --> Email Class Initialized
DEBUG - 2023-08-18 19:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:55:34 --> Controller Class Initialized
INFO - 2023-08-18 19:55:34 --> Model "Home_model" initialized
INFO - 2023-08-18 19:55:34 --> Helper loaded: form_helper
INFO - 2023-08-18 19:55:34 --> Form Validation Class Initialized
INFO - 2023-08-18 19:55:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-18 19:55:34 --> Final output sent to browser
DEBUG - 2023-08-18 19:55:34 --> Total execution time: 0.3194
INFO - 2023-08-18 19:55:35 --> Config Class Initialized
INFO - 2023-08-18 19:55:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:35 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:35 --> URI Class Initialized
INFO - 2023-08-18 19:55:35 --> Router Class Initialized
INFO - 2023-08-18 19:55:35 --> Output Class Initialized
INFO - 2023-08-18 19:55:35 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:35 --> Input Class Initialized
INFO - 2023-08-18 19:55:35 --> Language Class Initialized
ERROR - 2023-08-18 19:55:35 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:55:35 --> Config Class Initialized
INFO - 2023-08-18 19:55:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:35 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:35 --> URI Class Initialized
INFO - 2023-08-18 19:55:35 --> Router Class Initialized
INFO - 2023-08-18 19:55:35 --> Output Class Initialized
INFO - 2023-08-18 19:55:35 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:35 --> Input Class Initialized
INFO - 2023-08-18 19:55:35 --> Language Class Initialized
ERROR - 2023-08-18 19:55:35 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:55:36 --> Config Class Initialized
INFO - 2023-08-18 19:55:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:36 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:36 --> URI Class Initialized
INFO - 2023-08-18 19:55:36 --> Router Class Initialized
INFO - 2023-08-18 19:55:36 --> Output Class Initialized
INFO - 2023-08-18 19:55:36 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:36 --> Input Class Initialized
INFO - 2023-08-18 19:55:36 --> Language Class Initialized
ERROR - 2023-08-18 19:55:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:55:36 --> Config Class Initialized
INFO - 2023-08-18 19:55:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:36 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:36 --> URI Class Initialized
INFO - 2023-08-18 19:55:36 --> Router Class Initialized
INFO - 2023-08-18 19:55:36 --> Output Class Initialized
INFO - 2023-08-18 19:55:36 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:36 --> Input Class Initialized
INFO - 2023-08-18 19:55:36 --> Language Class Initialized
ERROR - 2023-08-18 19:55:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:55:36 --> Config Class Initialized
INFO - 2023-08-18 19:55:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:36 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:36 --> URI Class Initialized
INFO - 2023-08-18 19:55:36 --> Router Class Initialized
INFO - 2023-08-18 19:55:36 --> Output Class Initialized
INFO - 2023-08-18 19:55:36 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:36 --> Input Class Initialized
INFO - 2023-08-18 19:55:36 --> Language Class Initialized
ERROR - 2023-08-18 19:55:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:55:36 --> Config Class Initialized
INFO - 2023-08-18 19:55:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:36 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:36 --> URI Class Initialized
INFO - 2023-08-18 19:55:36 --> Router Class Initialized
INFO - 2023-08-18 19:55:36 --> Output Class Initialized
INFO - 2023-08-18 19:55:36 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:36 --> Input Class Initialized
INFO - 2023-08-18 19:55:36 --> Language Class Initialized
ERROR - 2023-08-18 19:55:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:55:40 --> Config Class Initialized
INFO - 2023-08-18 19:55:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:40 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:40 --> URI Class Initialized
INFO - 2023-08-18 19:55:40 --> Router Class Initialized
INFO - 2023-08-18 19:55:40 --> Output Class Initialized
INFO - 2023-08-18 19:55:40 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:40 --> Input Class Initialized
INFO - 2023-08-18 19:55:40 --> Language Class Initialized
INFO - 2023-08-18 19:55:40 --> Loader Class Initialized
INFO - 2023-08-18 19:55:40 --> Helper loaded: url_helper
INFO - 2023-08-18 19:55:40 --> Helper loaded: file_helper
INFO - 2023-08-18 19:55:40 --> Database Driver Class Initialized
INFO - 2023-08-18 19:55:40 --> Email Class Initialized
DEBUG - 2023-08-18 19:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:55:40 --> Controller Class Initialized
INFO - 2023-08-18 19:55:40 --> Model "Home_model" initialized
INFO - 2023-08-18 19:55:40 --> Helper loaded: form_helper
INFO - 2023-08-18 19:55:40 --> Form Validation Class Initialized
ERROR - 2023-08-18 19:55:40 --> Severity: Warning --> Undefined variable $trainings C:\xampp\htdocs\dw\application\views\home\blog.php 52
ERROR - 2023-08-18 19:55:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\blog.php 52
INFO - 2023-08-18 19:55:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 19:55:41 --> Final output sent to browser
INFO - 2023-08-18 19:55:41 --> Config Class Initialized
INFO - 2023-08-18 19:55:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:41 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:41 --> URI Class Initialized
INFO - 2023-08-18 19:55:41 --> Router Class Initialized
INFO - 2023-08-18 19:55:41 --> Output Class Initialized
INFO - 2023-08-18 19:55:41 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:41 --> Input Class Initialized
INFO - 2023-08-18 19:55:41 --> Language Class Initialized
ERROR - 2023-08-18 19:55:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:55:41 --> Config Class Initialized
INFO - 2023-08-18 19:55:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:41 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:41 --> URI Class Initialized
INFO - 2023-08-18 19:55:41 --> Router Class Initialized
INFO - 2023-08-18 19:55:41 --> Output Class Initialized
INFO - 2023-08-18 19:55:41 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:41 --> Input Class Initialized
INFO - 2023-08-18 19:55:41 --> Language Class Initialized
ERROR - 2023-08-18 19:55:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:55:41 --> Config Class Initialized
INFO - 2023-08-18 19:55:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:41 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:41 --> URI Class Initialized
INFO - 2023-08-18 19:55:41 --> Router Class Initialized
INFO - 2023-08-18 19:55:41 --> Output Class Initialized
INFO - 2023-08-18 19:55:41 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:41 --> Input Class Initialized
INFO - 2023-08-18 19:55:41 --> Language Class Initialized
ERROR - 2023-08-18 19:55:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:55:41 --> Config Class Initialized
INFO - 2023-08-18 19:55:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:41 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:41 --> URI Class Initialized
INFO - 2023-08-18 19:55:41 --> Router Class Initialized
INFO - 2023-08-18 19:55:41 --> Output Class Initialized
INFO - 2023-08-18 19:55:41 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:41 --> Input Class Initialized
INFO - 2023-08-18 19:55:41 --> Language Class Initialized
ERROR - 2023-08-18 19:55:41 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:41 --> Config Class Initialized
INFO - 2023-08-18 19:55:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:41 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:41 --> URI Class Initialized
INFO - 2023-08-18 19:55:41 --> Router Class Initialized
INFO - 2023-08-18 19:55:41 --> Output Class Initialized
INFO - 2023-08-18 19:55:41 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:41 --> Input Class Initialized
INFO - 2023-08-18 19:55:41 --> Language Class Initialized
ERROR - 2023-08-18 19:55:41 --> 404 Page Not Found: Assets/vendors
DEBUG - 2023-08-18 19:55:41 --> Total execution time: 0.1992
INFO - 2023-08-18 19:55:41 --> Config Class Initialized
INFO - 2023-08-18 19:55:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:41 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:41 --> URI Class Initialized
INFO - 2023-08-18 19:55:41 --> Router Class Initialized
INFO - 2023-08-18 19:55:41 --> Output Class Initialized
INFO - 2023-08-18 19:55:41 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:41 --> Input Class Initialized
INFO - 2023-08-18 19:55:41 --> Language Class Initialized
ERROR - 2023-08-18 19:55:41 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:41 --> Config Class Initialized
INFO - 2023-08-18 19:55:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:41 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:41 --> URI Class Initialized
INFO - 2023-08-18 19:55:41 --> Router Class Initialized
INFO - 2023-08-18 19:55:41 --> Output Class Initialized
INFO - 2023-08-18 19:55:41 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:41 --> Input Class Initialized
INFO - 2023-08-18 19:55:41 --> Language Class Initialized
ERROR - 2023-08-18 19:55:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:55:42 --> Config Class Initialized
INFO - 2023-08-18 19:55:42 --> Config Class Initialized
INFO - 2023-08-18 19:55:42 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:42 --> Config Class Initialized
DEBUG - 2023-08-18 19:55:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:42 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:42 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:42 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:42 --> Config Class Initialized
INFO - 2023-08-18 19:55:42 --> URI Class Initialized
INFO - 2023-08-18 19:55:42 --> Config Class Initialized
DEBUG - 2023-08-18 19:55:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:42 --> Config Class Initialized
INFO - 2023-08-18 19:55:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:42 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:42 --> Router Class Initialized
INFO - 2023-08-18 19:55:42 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:42 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:55:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:42 --> URI Class Initialized
DEBUG - 2023-08-18 19:55:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:55:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:42 --> Router Class Initialized
INFO - 2023-08-18 19:55:42 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:42 --> Output Class Initialized
INFO - 2023-08-18 19:55:42 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:42 --> URI Class Initialized
INFO - 2023-08-18 19:55:42 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:42 --> URI Class Initialized
INFO - 2023-08-18 19:55:42 --> Router Class Initialized
INFO - 2023-08-18 19:55:42 --> Output Class Initialized
INFO - 2023-08-18 19:55:42 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:42 --> Input Class Initialized
INFO - 2023-08-18 19:55:42 --> Language Class Initialized
ERROR - 2023-08-18 19:55:42 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:42 --> Output Class Initialized
INFO - 2023-08-18 19:55:42 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:42 --> Router Class Initialized
INFO - 2023-08-18 19:55:42 --> URI Class Initialized
INFO - 2023-08-18 19:55:42 --> Security Class Initialized
INFO - 2023-08-18 19:55:42 --> Security Class Initialized
INFO - 2023-08-18 19:55:42 --> URI Class Initialized
INFO - 2023-08-18 19:55:42 --> Output Class Initialized
INFO - 2023-08-18 19:55:42 --> Router Class Initialized
DEBUG - 2023-08-18 19:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:42 --> Router Class Initialized
INFO - 2023-08-18 19:55:42 --> Config Class Initialized
INFO - 2023-08-18 19:55:42 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:42 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:42 --> Output Class Initialized
INFO - 2023-08-18 19:55:42 --> Input Class Initialized
INFO - 2023-08-18 19:55:42 --> Language Class Initialized
ERROR - 2023-08-18 19:55:42 --> 404 Page Not Found: Assets/vendors
DEBUG - 2023-08-18 19:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:42 --> Security Class Initialized
INFO - 2023-08-18 19:55:42 --> Output Class Initialized
DEBUG - 2023-08-18 19:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:42 --> Input Class Initialized
INFO - 2023-08-18 19:55:42 --> Language Class Initialized
ERROR - 2023-08-18 19:55:42 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 19:55:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:42 --> Input Class Initialized
INFO - 2023-08-18 19:55:42 --> Input Class Initialized
INFO - 2023-08-18 19:55:42 --> Config Class Initialized
INFO - 2023-08-18 19:55:42 --> Security Class Initialized
INFO - 2023-08-18 19:55:43 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:43 --> Language Class Initialized
DEBUG - 2023-08-18 19:55:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-18 19:55:43 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:43 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:43 --> Language Class Initialized
INFO - 2023-08-18 19:55:43 --> URI Class Initialized
INFO - 2023-08-18 19:55:43 --> Router Class Initialized
ERROR - 2023-08-18 19:55:43 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:43 --> Config Class Initialized
INFO - 2023-08-18 19:55:43 --> Input Class Initialized
INFO - 2023-08-18 19:55:43 --> Language Class Initialized
DEBUG - 2023-08-18 19:55:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:43 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:43 --> Output Class Initialized
INFO - 2023-08-18 19:55:43 --> Security Class Initialized
ERROR - 2023-08-18 19:55:43 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:43 --> Config Class Initialized
DEBUG - 2023-08-18 19:55:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:43 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:43 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:43 --> Config Class Initialized
INFO - 2023-08-18 19:55:43 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:43 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:55:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:43 --> URI Class Initialized
INFO - 2023-08-18 19:55:43 --> Input Class Initialized
INFO - 2023-08-18 19:55:43 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:55:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:43 --> Router Class Initialized
INFO - 2023-08-18 19:55:43 --> URI Class Initialized
INFO - 2023-08-18 19:55:43 --> Config Class Initialized
INFO - 2023-08-18 19:55:43 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:43 --> Language Class Initialized
ERROR - 2023-08-18 19:55:43 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:43 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:43 --> Router Class Initialized
INFO - 2023-08-18 19:55:43 --> URI Class Initialized
INFO - 2023-08-18 19:55:43 --> Output Class Initialized
INFO - 2023-08-18 19:55:43 --> Output Class Initialized
INFO - 2023-08-18 19:55:43 --> URI Class Initialized
INFO - 2023-08-18 19:55:43 --> Router Class Initialized
INFO - 2023-08-18 19:55:43 --> Router Class Initialized
INFO - 2023-08-18 19:55:43 --> Security Class Initialized
INFO - 2023-08-18 19:55:43 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:43 --> Output Class Initialized
DEBUG - 2023-08-18 19:55:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:43 --> Output Class Initialized
INFO - 2023-08-18 19:55:43 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:43 --> Input Class Initialized
INFO - 2023-08-18 19:55:43 --> Language Class Initialized
ERROR - 2023-08-18 19:55:43 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:43 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:43 --> Security Class Initialized
INFO - 2023-08-18 19:55:43 --> Input Class Initialized
INFO - 2023-08-18 19:55:43 --> Config Class Initialized
DEBUG - 2023-08-18 19:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:43 --> URI Class Initialized
INFO - 2023-08-18 19:55:43 --> Language Class Initialized
INFO - 2023-08-18 19:55:43 --> Config Class Initialized
INFO - 2023-08-18 19:55:43 --> Input Class Initialized
INFO - 2023-08-18 19:55:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:43 --> Input Class Initialized
INFO - 2023-08-18 19:55:43 --> Language Class Initialized
ERROR - 2023-08-18 19:55:43 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:43 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:43 --> Language Class Initialized
ERROR - 2023-08-18 19:55:43 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:43 --> Router Class Initialized
ERROR - 2023-08-18 19:55:43 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:43 --> Output Class Initialized
DEBUG - 2023-08-18 19:55:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:55:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:43 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:43 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:43 --> Security Class Initialized
INFO - 2023-08-18 19:55:43 --> Config Class Initialized
INFO - 2023-08-18 19:55:43 --> Config Class Initialized
INFO - 2023-08-18 19:55:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:44 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:44 --> URI Class Initialized
INFO - 2023-08-18 19:55:44 --> URI Class Initialized
INFO - 2023-08-18 19:55:44 --> Router Class Initialized
INFO - 2023-08-18 19:55:44 --> Config Class Initialized
INFO - 2023-08-18 19:55:44 --> Router Class Initialized
INFO - 2023-08-18 19:55:44 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:55:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:44 --> URI Class Initialized
INFO - 2023-08-18 19:55:44 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:44 --> Output Class Initialized
INFO - 2023-08-18 19:55:44 --> Output Class Initialized
INFO - 2023-08-18 19:55:44 --> Router Class Initialized
INFO - 2023-08-18 19:55:44 --> Security Class Initialized
INFO - 2023-08-18 19:55:44 --> Input Class Initialized
DEBUG - 2023-08-18 19:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:44 --> Input Class Initialized
INFO - 2023-08-18 19:55:44 --> Language Class Initialized
ERROR - 2023-08-18 19:55:44 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:44 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:44 --> Language Class Initialized
DEBUG - 2023-08-18 19:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:44 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:44 --> Output Class Initialized
INFO - 2023-08-18 19:55:44 --> Utf8 Class Initialized
ERROR - 2023-08-18 19:55:44 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:44 --> URI Class Initialized
INFO - 2023-08-18 19:55:44 --> Router Class Initialized
INFO - 2023-08-18 19:55:44 --> Input Class Initialized
INFO - 2023-08-18 19:55:44 --> Security Class Initialized
INFO - 2023-08-18 19:55:44 --> Config Class Initialized
INFO - 2023-08-18 19:55:44 --> URI Class Initialized
DEBUG - 2023-08-18 19:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:44 --> Input Class Initialized
INFO - 2023-08-18 19:55:44 --> Language Class Initialized
ERROR - 2023-08-18 19:55:44 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:44 --> Router Class Initialized
INFO - 2023-08-18 19:55:44 --> Output Class Initialized
INFO - 2023-08-18 19:55:44 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:44 --> Output Class Initialized
DEBUG - 2023-08-18 19:55:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:44 --> Config Class Initialized
INFO - 2023-08-18 19:55:44 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:44 --> Input Class Initialized
INFO - 2023-08-18 19:55:44 --> Language Class Initialized
ERROR - 2023-08-18 19:55:44 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:55:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:44 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:44 --> Security Class Initialized
INFO - 2023-08-18 19:55:44 --> Config Class Initialized
INFO - 2023-08-18 19:55:44 --> Language Class Initialized
INFO - 2023-08-18 19:55:44 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:44 --> URI Class Initialized
INFO - 2023-08-18 19:55:44 --> Router Class Initialized
INFO - 2023-08-18 19:55:44 --> URI Class Initialized
INFO - 2023-08-18 19:55:44 --> Router Class Initialized
INFO - 2023-08-18 19:55:44 --> Output Class Initialized
INFO - 2023-08-18 19:55:44 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:44 --> Input Class Initialized
INFO - 2023-08-18 19:55:44 --> Language Class Initialized
ERROR - 2023-08-18 19:55:44 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:44 --> Input Class Initialized
INFO - 2023-08-18 19:55:44 --> Config Class Initialized
INFO - 2023-08-18 19:55:44 --> Hooks Class Initialized
ERROR - 2023-08-18 19:55:44 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:44 --> Language Class Initialized
INFO - 2023-08-18 19:55:44 --> Output Class Initialized
ERROR - 2023-08-18 19:55:44 --> 404 Page Not Found: Assets/vendors
DEBUG - 2023-08-18 19:55:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:44 --> Config Class Initialized
INFO - 2023-08-18 19:55:44 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:44 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:55:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:44 --> Security Class Initialized
INFO - 2023-08-18 19:55:44 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:44 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:44 --> URI Class Initialized
INFO - 2023-08-18 19:55:44 --> URI Class Initialized
INFO - 2023-08-18 19:55:44 --> Config Class Initialized
DEBUG - 2023-08-18 19:55:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:44 --> Hooks Class Initialized
INFO - 2023-08-18 19:55:44 --> Router Class Initialized
INFO - 2023-08-18 19:55:44 --> Input Class Initialized
DEBUG - 2023-08-18 19:55:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:55:44 --> Router Class Initialized
INFO - 2023-08-18 19:55:44 --> Output Class Initialized
INFO - 2023-08-18 19:55:44 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:44 --> Security Class Initialized
INFO - 2023-08-18 19:55:44 --> Output Class Initialized
INFO - 2023-08-18 19:55:45 --> Language Class Initialized
INFO - 2023-08-18 19:55:45 --> Utf8 Class Initialized
INFO - 2023-08-18 19:55:45 --> URI Class Initialized
DEBUG - 2023-08-18 19:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-18 19:55:45 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:55:45 --> URI Class Initialized
INFO - 2023-08-18 19:55:45 --> Input Class Initialized
INFO - 2023-08-18 19:55:45 --> Router Class Initialized
INFO - 2023-08-18 19:55:45 --> Security Class Initialized
INFO - 2023-08-18 19:55:45 --> Output Class Initialized
INFO - 2023-08-18 19:55:45 --> Router Class Initialized
INFO - 2023-08-18 19:55:45 --> Language Class Initialized
INFO - 2023-08-18 19:55:45 --> Output Class Initialized
DEBUG - 2023-08-18 19:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:45 --> Security Class Initialized
INFO - 2023-08-18 19:55:45 --> Security Class Initialized
DEBUG - 2023-08-18 19:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-18 19:55:45 --> 404 Page Not Found: Assets/vendors
DEBUG - 2023-08-18 19:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:55:45 --> Input Class Initialized
INFO - 2023-08-18 19:55:45 --> Input Class Initialized
INFO - 2023-08-18 19:55:45 --> Input Class Initialized
INFO - 2023-08-18 19:55:45 --> Language Class Initialized
ERROR - 2023-08-18 19:55:45 --> 404 Page Not Found: Assets/js
INFO - 2023-08-18 19:55:45 --> Language Class Initialized
INFO - 2023-08-18 19:55:45 --> Language Class Initialized
ERROR - 2023-08-18 19:55:45 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 19:55:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:56:00 --> Config Class Initialized
INFO - 2023-08-18 19:56:00 --> Config Class Initialized
INFO - 2023-08-18 19:56:00 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:56:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:01 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:01 --> URI Class Initialized
INFO - 2023-08-18 19:56:01 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:01 --> Router Class Initialized
INFO - 2023-08-18 19:56:01 --> Output Class Initialized
INFO - 2023-08-18 19:56:01 --> URI Class Initialized
INFO - 2023-08-18 19:56:01 --> Security Class Initialized
INFO - 2023-08-18 19:56:01 --> Router Class Initialized
DEBUG - 2023-08-18 19:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:01 --> Output Class Initialized
INFO - 2023-08-18 19:56:01 --> Input Class Initialized
INFO - 2023-08-18 19:56:01 --> Language Class Initialized
INFO - 2023-08-18 19:56:01 --> Security Class Initialized
ERROR - 2023-08-18 19:56:01 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-18 19:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:01 --> Input Class Initialized
INFO - 2023-08-18 19:56:01 --> Language Class Initialized
ERROR - 2023-08-18 19:56:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:56:04 --> Config Class Initialized
INFO - 2023-08-18 19:56:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:04 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:04 --> URI Class Initialized
INFO - 2023-08-18 19:56:04 --> Router Class Initialized
INFO - 2023-08-18 19:56:04 --> Output Class Initialized
INFO - 2023-08-18 19:56:04 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:04 --> Input Class Initialized
INFO - 2023-08-18 19:56:04 --> Language Class Initialized
INFO - 2023-08-18 19:56:04 --> Loader Class Initialized
INFO - 2023-08-18 19:56:04 --> Helper loaded: url_helper
INFO - 2023-08-18 19:56:04 --> Helper loaded: file_helper
INFO - 2023-08-18 19:56:04 --> Database Driver Class Initialized
INFO - 2023-08-18 19:56:04 --> Email Class Initialized
DEBUG - 2023-08-18 19:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:56:04 --> Controller Class Initialized
INFO - 2023-08-18 19:56:04 --> Model "Home_model" initialized
INFO - 2023-08-18 19:56:04 --> Helper loaded: form_helper
INFO - 2023-08-18 19:56:04 --> Form Validation Class Initialized
ERROR - 2023-08-18 19:56:04 --> Severity: Warning --> Undefined variable $trainings C:\xampp\htdocs\dw\application\views\home\blog.php 52
ERROR - 2023-08-18 19:56:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\blog.php 52
INFO - 2023-08-18 19:56:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 19:56:05 --> Final output sent to browser
DEBUG - 2023-08-18 19:56:05 --> Total execution time: 0.6885
INFO - 2023-08-18 19:56:05 --> Config Class Initialized
INFO - 2023-08-18 19:56:05 --> Config Class Initialized
INFO - 2023-08-18 19:56:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:05 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:05 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:56:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:05 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:05 --> URI Class Initialized
INFO - 2023-08-18 19:56:05 --> URI Class Initialized
INFO - 2023-08-18 19:56:05 --> Router Class Initialized
INFO - 2023-08-18 19:56:05 --> Router Class Initialized
INFO - 2023-08-18 19:56:05 --> Output Class Initialized
INFO - 2023-08-18 19:56:05 --> Output Class Initialized
INFO - 2023-08-18 19:56:05 --> Security Class Initialized
INFO - 2023-08-18 19:56:05 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:05 --> Input Class Initialized
INFO - 2023-08-18 19:56:05 --> Input Class Initialized
INFO - 2023-08-18 19:56:05 --> Language Class Initialized
INFO - 2023-08-18 19:56:06 --> Language Class Initialized
ERROR - 2023-08-18 19:56:06 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-18 19:56:06 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:06 --> Config Class Initialized
INFO - 2023-08-18 19:56:06 --> Config Class Initialized
INFO - 2023-08-18 19:56:06 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:06 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:06 --> Config Class Initialized
INFO - 2023-08-18 19:56:06 --> URI Class Initialized
INFO - 2023-08-18 19:56:06 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:06 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:06 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:56:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:06 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:06 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:06 --> Router Class Initialized
INFO - 2023-08-18 19:56:06 --> URI Class Initialized
INFO - 2023-08-18 19:56:06 --> Output Class Initialized
INFO - 2023-08-18 19:56:06 --> Router Class Initialized
INFO - 2023-08-18 19:56:06 --> URI Class Initialized
INFO - 2023-08-18 19:56:06 --> Security Class Initialized
INFO - 2023-08-18 19:56:06 --> Output Class Initialized
INFO - 2023-08-18 19:56:06 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:06 --> Config Class Initialized
INFO - 2023-08-18 19:56:06 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:06 --> Config Class Initialized
INFO - 2023-08-18 19:56:06 --> Router Class Initialized
INFO - 2023-08-18 19:56:06 --> Config Class Initialized
INFO - 2023-08-18 19:56:06 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:06 --> Output Class Initialized
DEBUG - 2023-08-18 19:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:06 --> Input Class Initialized
INFO - 2023-08-18 19:56:06 --> Language Class Initialized
ERROR - 2023-08-18 19:56:06 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:56:06 --> Input Class Initialized
INFO - 2023-08-18 19:56:06 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:06 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:06 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:06 --> Config Class Initialized
INFO - 2023-08-18 19:56:06 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:06 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:06 --> URI Class Initialized
INFO - 2023-08-18 19:56:06 --> Router Class Initialized
INFO - 2023-08-18 19:56:06 --> Output Class Initialized
INFO - 2023-08-18 19:56:06 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:06 --> Input Class Initialized
INFO - 2023-08-18 19:56:06 --> Language Class Initialized
ERROR - 2023-08-18 19:56:06 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:06 --> Language Class Initialized
DEBUG - 2023-08-18 19:56:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-18 19:56:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:56:06 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:06 --> URI Class Initialized
INFO - 2023-08-18 19:56:06 --> Router Class Initialized
INFO - 2023-08-18 19:56:06 --> Output Class Initialized
INFO - 2023-08-18 19:56:06 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:06 --> Input Class Initialized
INFO - 2023-08-18 19:56:06 --> Language Class Initialized
ERROR - 2023-08-18 19:56:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:56:06 --> Config Class Initialized
INFO - 2023-08-18 19:56:06 --> URI Class Initialized
DEBUG - 2023-08-18 19:56:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:06 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:06 --> Input Class Initialized
INFO - 2023-08-18 19:56:06 --> Language Class Initialized
INFO - 2023-08-18 19:56:06 --> Router Class Initialized
INFO - 2023-08-18 19:56:06 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:06 --> Output Class Initialized
INFO - 2023-08-18 19:56:06 --> URI Class Initialized
DEBUG - 2023-08-18 19:56:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:07 --> Security Class Initialized
ERROR - 2023-08-18 19:56:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:56:07 --> Config Class Initialized
INFO - 2023-08-18 19:56:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:07 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:07 --> URI Class Initialized
INFO - 2023-08-18 19:56:07 --> Router Class Initialized
INFO - 2023-08-18 19:56:07 --> Output Class Initialized
INFO - 2023-08-18 19:56:07 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:07 --> Input Class Initialized
INFO - 2023-08-18 19:56:07 --> Language Class Initialized
ERROR - 2023-08-18 19:56:07 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:07 --> Router Class Initialized
DEBUG - 2023-08-18 19:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:07 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:07 --> Input Class Initialized
INFO - 2023-08-18 19:56:07 --> Config Class Initialized
INFO - 2023-08-18 19:56:07 --> URI Class Initialized
INFO - 2023-08-18 19:56:07 --> Output Class Initialized
INFO - 2023-08-18 19:56:07 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:07 --> Language Class Initialized
INFO - 2023-08-18 19:56:07 --> Router Class Initialized
INFO - 2023-08-18 19:56:07 --> Output Class Initialized
INFO - 2023-08-18 19:56:07 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:07 --> Input Class Initialized
INFO - 2023-08-18 19:56:07 --> Language Class Initialized
ERROR - 2023-08-18 19:56:07 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 19:56:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:56:07 --> Config Class Initialized
INFO - 2023-08-18 19:56:07 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:07 --> Config Class Initialized
INFO - 2023-08-18 19:56:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:07 --> Config Class Initialized
INFO - 2023-08-18 19:56:07 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:56:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:07 --> Config Class Initialized
INFO - 2023-08-18 19:56:07 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:07 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:07 --> URI Class Initialized
INFO - 2023-08-18 19:56:07 --> Input Class Initialized
DEBUG - 2023-08-18 19:56:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:07 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:07 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:07 --> Router Class Initialized
INFO - 2023-08-18 19:56:07 --> URI Class Initialized
INFO - 2023-08-18 19:56:07 --> Language Class Initialized
INFO - 2023-08-18 19:56:07 --> Output Class Initialized
INFO - 2023-08-18 19:56:07 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:07 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:07 --> Router Class Initialized
INFO - 2023-08-18 19:56:07 --> URI Class Initialized
INFO - 2023-08-18 19:56:07 --> URI Class Initialized
ERROR - 2023-08-18 19:56:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:56:07 --> Router Class Initialized
DEBUG - 2023-08-18 19:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:07 --> Router Class Initialized
INFO - 2023-08-18 19:56:08 --> Output Class Initialized
INFO - 2023-08-18 19:56:08 --> Output Class Initialized
INFO - 2023-08-18 19:56:08 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:08 --> Input Class Initialized
INFO - 2023-08-18 19:56:08 --> Language Class Initialized
ERROR - 2023-08-18 19:56:08 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:08 --> Output Class Initialized
INFO - 2023-08-18 19:56:08 --> Input Class Initialized
INFO - 2023-08-18 19:56:08 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:08 --> Security Class Initialized
INFO - 2023-08-18 19:56:08 --> Config Class Initialized
INFO - 2023-08-18 19:56:08 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:08 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:08 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:08 --> URI Class Initialized
INFO - 2023-08-18 19:56:08 --> Router Class Initialized
INFO - 2023-08-18 19:56:08 --> Output Class Initialized
INFO - 2023-08-18 19:56:08 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:08 --> Input Class Initialized
INFO - 2023-08-18 19:56:08 --> Language Class Initialized
ERROR - 2023-08-18 19:56:08 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:08 --> Security Class Initialized
INFO - 2023-08-18 19:56:08 --> Language Class Initialized
INFO - 2023-08-18 19:56:08 --> URI Class Initialized
DEBUG - 2023-08-18 19:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:08 --> Input Class Initialized
ERROR - 2023-08-18 19:56:08 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:08 --> Config Class Initialized
INFO - 2023-08-18 19:56:08 --> Input Class Initialized
INFO - 2023-08-18 19:56:08 --> Config Class Initialized
INFO - 2023-08-18 19:56:08 --> Router Class Initialized
INFO - 2023-08-18 19:56:08 --> Language Class Initialized
INFO - 2023-08-18 19:56:08 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:08 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:08 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:08 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:08 --> URI Class Initialized
INFO - 2023-08-18 19:56:08 --> Router Class Initialized
INFO - 2023-08-18 19:56:08 --> Output Class Initialized
INFO - 2023-08-18 19:56:08 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:08 --> Input Class Initialized
INFO - 2023-08-18 19:56:08 --> Language Class Initialized
ERROR - 2023-08-18 19:56:08 --> 404 Page Not Found: Assets/vendors
ERROR - 2023-08-18 19:56:08 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:08 --> Language Class Initialized
INFO - 2023-08-18 19:56:09 --> Output Class Initialized
DEBUG - 2023-08-18 19:56:09 --> UTF-8 Support Enabled
ERROR - 2023-08-18 19:56:09 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:09 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:09 --> URI Class Initialized
INFO - 2023-08-18 19:56:09 --> Config Class Initialized
INFO - 2023-08-18 19:56:09 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:09 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:09 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:09 --> URI Class Initialized
INFO - 2023-08-18 19:56:09 --> Router Class Initialized
INFO - 2023-08-18 19:56:09 --> Output Class Initialized
INFO - 2023-08-18 19:56:09 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:09 --> Input Class Initialized
INFO - 2023-08-18 19:56:09 --> Language Class Initialized
ERROR - 2023-08-18 19:56:09 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:09 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:09 --> Router Class Initialized
INFO - 2023-08-18 19:56:09 --> Output Class Initialized
INFO - 2023-08-18 19:56:09 --> Input Class Initialized
INFO - 2023-08-18 19:56:09 --> Config Class Initialized
INFO - 2023-08-18 19:56:09 --> Config Class Initialized
INFO - 2023-08-18 19:56:09 --> Config Class Initialized
INFO - 2023-08-18 19:56:09 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:09 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:09 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:09 --> URI Class Initialized
INFO - 2023-08-18 19:56:09 --> Router Class Initialized
INFO - 2023-08-18 19:56:09 --> Output Class Initialized
INFO - 2023-08-18 19:56:09 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:09 --> Input Class Initialized
INFO - 2023-08-18 19:56:09 --> Language Class Initialized
ERROR - 2023-08-18 19:56:09 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:09 --> Config Class Initialized
INFO - 2023-08-18 19:56:09 --> Security Class Initialized
INFO - 2023-08-18 19:56:09 --> Language Class Initialized
INFO - 2023-08-18 19:56:09 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:09 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:09 --> Hooks Class Initialized
ERROR - 2023-08-18 19:56:09 --> 404 Page Not Found: Assets/vendors
DEBUG - 2023-08-18 19:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:56:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:56:09 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:10 --> Config Class Initialized
DEBUG - 2023-08-18 19:56:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:10 --> Input Class Initialized
INFO - 2023-08-18 19:56:10 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:10 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:10 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:10 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:10 --> URI Class Initialized
INFO - 2023-08-18 19:56:10 --> Language Class Initialized
INFO - 2023-08-18 19:56:10 --> Config Class Initialized
INFO - 2023-08-18 19:56:10 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:10 --> URI Class Initialized
INFO - 2023-08-18 19:56:10 --> Router Class Initialized
INFO - 2023-08-18 19:56:10 --> Output Class Initialized
INFO - 2023-08-18 19:56:10 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:10 --> Input Class Initialized
INFO - 2023-08-18 19:56:10 --> Language Class Initialized
ERROR - 2023-08-18 19:56:10 --> 404 Page Not Found: Assets/vendors
DEBUG - 2023-08-18 19:56:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:10 --> URI Class Initialized
DEBUG - 2023-08-18 19:56:10 --> UTF-8 Support Enabled
ERROR - 2023-08-18 19:56:10 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:10 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:10 --> Router Class Initialized
INFO - 2023-08-18 19:56:10 --> Router Class Initialized
INFO - 2023-08-18 19:56:10 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:10 --> Config Class Initialized
INFO - 2023-08-18 19:56:10 --> Output Class Initialized
INFO - 2023-08-18 19:56:10 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:10 --> Input Class Initialized
INFO - 2023-08-18 19:56:10 --> Language Class Initialized
ERROR - 2023-08-18 19:56:10 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:10 --> URI Class Initialized
INFO - 2023-08-18 19:56:10 --> Output Class Initialized
INFO - 2023-08-18 19:56:10 --> URI Class Initialized
INFO - 2023-08-18 19:56:10 --> Router Class Initialized
INFO - 2023-08-18 19:56:10 --> Output Class Initialized
INFO - 2023-08-18 19:56:10 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:10 --> Input Class Initialized
INFO - 2023-08-18 19:56:10 --> Language Class Initialized
ERROR - 2023-08-18 19:56:10 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:10 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:10 --> Config Class Initialized
INFO - 2023-08-18 19:56:10 --> Router Class Initialized
INFO - 2023-08-18 19:56:10 --> Security Class Initialized
INFO - 2023-08-18 19:56:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:10 --> Output Class Initialized
INFO - 2023-08-18 19:56:10 --> Input Class Initialized
DEBUG - 2023-08-18 19:56:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:56:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:10 --> Config Class Initialized
INFO - 2023-08-18 19:56:10 --> Security Class Initialized
INFO - 2023-08-18 19:56:10 --> Language Class Initialized
ERROR - 2023-08-18 19:56:10 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:10 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:10 --> Config Class Initialized
DEBUG - 2023-08-18 19:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:11 --> URI Class Initialized
INFO - 2023-08-18 19:56:11 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:11 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:11 --> URI Class Initialized
INFO - 2023-08-18 19:56:11 --> Router Class Initialized
INFO - 2023-08-18 19:56:11 --> Output Class Initialized
INFO - 2023-08-18 19:56:11 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:11 --> Input Class Initialized
INFO - 2023-08-18 19:56:11 --> Language Class Initialized
ERROR - 2023-08-18 19:56:11 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:11 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:11 --> Input Class Initialized
INFO - 2023-08-18 19:56:11 --> Language Class Initialized
INFO - 2023-08-18 19:56:11 --> Router Class Initialized
INFO - 2023-08-18 19:56:11 --> Output Class Initialized
INFO - 2023-08-18 19:56:11 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:11 --> Input Class Initialized
INFO - 2023-08-18 19:56:11 --> Language Class Initialized
ERROR - 2023-08-18 19:56:11 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:11 --> Config Class Initialized
DEBUG - 2023-08-18 19:56:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:11 --> Config Class Initialized
ERROR - 2023-08-18 19:56:11 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:11 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:11 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:11 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:11 --> URI Class Initialized
DEBUG - 2023-08-18 19:56:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:11 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:56:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:11 --> Router Class Initialized
INFO - 2023-08-18 19:56:11 --> URI Class Initialized
INFO - 2023-08-18 19:56:11 --> Output Class Initialized
INFO - 2023-08-18 19:56:11 --> URI Class Initialized
INFO - 2023-08-18 19:56:11 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:11 --> Security Class Initialized
INFO - 2023-08-18 19:56:11 --> Router Class Initialized
INFO - 2023-08-18 19:56:11 --> Router Class Initialized
DEBUG - 2023-08-18 19:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:11 --> Input Class Initialized
INFO - 2023-08-18 19:56:11 --> Language Class Initialized
ERROR - 2023-08-18 19:56:11 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:11 --> URI Class Initialized
INFO - 2023-08-18 19:56:11 --> Output Class Initialized
INFO - 2023-08-18 19:56:11 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:11 --> Input Class Initialized
INFO - 2023-08-18 19:56:11 --> Language Class Initialized
ERROR - 2023-08-18 19:56:11 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:11 --> Router Class Initialized
INFO - 2023-08-18 19:56:12 --> Output Class Initialized
INFO - 2023-08-18 19:56:12 --> Output Class Initialized
INFO - 2023-08-18 19:56:12 --> Security Class Initialized
INFO - 2023-08-18 19:56:12 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:12 --> Input Class Initialized
DEBUG - 2023-08-18 19:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:12 --> Language Class Initialized
INFO - 2023-08-18 19:56:12 --> Input Class Initialized
ERROR - 2023-08-18 19:56:12 --> 404 Page Not Found: Assets/js
INFO - 2023-08-18 19:56:12 --> Language Class Initialized
ERROR - 2023-08-18 19:56:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:56:19 --> Config Class Initialized
INFO - 2023-08-18 19:56:19 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:20 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:20 --> URI Class Initialized
INFO - 2023-08-18 19:56:20 --> Router Class Initialized
INFO - 2023-08-18 19:56:20 --> Output Class Initialized
INFO - 2023-08-18 19:56:20 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:20 --> Input Class Initialized
INFO - 2023-08-18 19:56:20 --> Language Class Initialized
INFO - 2023-08-18 19:56:20 --> Loader Class Initialized
INFO - 2023-08-18 19:56:20 --> Helper loaded: url_helper
INFO - 2023-08-18 19:56:20 --> Helper loaded: file_helper
INFO - 2023-08-18 19:56:20 --> Database Driver Class Initialized
INFO - 2023-08-18 19:56:20 --> Email Class Initialized
DEBUG - 2023-08-18 19:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:56:20 --> Controller Class Initialized
INFO - 2023-08-18 19:56:20 --> Model "Home_model" initialized
INFO - 2023-08-18 19:56:20 --> Helper loaded: form_helper
INFO - 2023-08-18 19:56:20 --> Form Validation Class Initialized
ERROR - 2023-08-18 19:56:20 --> Severity: Warning --> Undefined variable $trainings C:\xampp\htdocs\dw\application\views\home\blog.php 52
ERROR - 2023-08-18 19:56:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\blog.php 52
INFO - 2023-08-18 19:56:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 19:56:20 --> Final output sent to browser
DEBUG - 2023-08-18 19:56:20 --> Total execution time: 0.5415
INFO - 2023-08-18 19:56:21 --> Config Class Initialized
INFO - 2023-08-18 19:56:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:21 --> URI Class Initialized
INFO - 2023-08-18 19:56:21 --> Router Class Initialized
INFO - 2023-08-18 19:56:21 --> Output Class Initialized
INFO - 2023-08-18 19:56:21 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:21 --> Input Class Initialized
INFO - 2023-08-18 19:56:21 --> Language Class Initialized
ERROR - 2023-08-18 19:56:21 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:21 --> Config Class Initialized
INFO - 2023-08-18 19:56:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:21 --> URI Class Initialized
INFO - 2023-08-18 19:56:21 --> Router Class Initialized
INFO - 2023-08-18 19:56:21 --> Output Class Initialized
INFO - 2023-08-18 19:56:21 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:21 --> Input Class Initialized
INFO - 2023-08-18 19:56:21 --> Language Class Initialized
ERROR - 2023-08-18 19:56:21 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:21 --> Config Class Initialized
INFO - 2023-08-18 19:56:21 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:21 --> Config Class Initialized
INFO - 2023-08-18 19:56:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:21 --> URI Class Initialized
INFO - 2023-08-18 19:56:21 --> Router Class Initialized
INFO - 2023-08-18 19:56:21 --> Output Class Initialized
INFO - 2023-08-18 19:56:21 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:21 --> Input Class Initialized
INFO - 2023-08-18 19:56:21 --> Language Class Initialized
ERROR - 2023-08-18 19:56:21 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:21 --> Config Class Initialized
INFO - 2023-08-18 19:56:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:21 --> URI Class Initialized
INFO - 2023-08-18 19:56:21 --> Router Class Initialized
INFO - 2023-08-18 19:56:21 --> Output Class Initialized
INFO - 2023-08-18 19:56:21 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:21 --> Input Class Initialized
INFO - 2023-08-18 19:56:21 --> Language Class Initialized
ERROR - 2023-08-18 19:56:21 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:21 --> Config Class Initialized
INFO - 2023-08-18 19:56:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:21 --> URI Class Initialized
INFO - 2023-08-18 19:56:21 --> Router Class Initialized
INFO - 2023-08-18 19:56:21 --> Output Class Initialized
INFO - 2023-08-18 19:56:21 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:21 --> Input Class Initialized
INFO - 2023-08-18 19:56:21 --> Language Class Initialized
ERROR - 2023-08-18 19:56:21 --> 404 Page Not Found: Assets/vendors
DEBUG - 2023-08-18 19:56:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:21 --> URI Class Initialized
INFO - 2023-08-18 19:56:21 --> Router Class Initialized
INFO - 2023-08-18 19:56:21 --> Output Class Initialized
INFO - 2023-08-18 19:56:21 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:21 --> Input Class Initialized
INFO - 2023-08-18 19:56:21 --> Language Class Initialized
ERROR - 2023-08-18 19:56:21 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:21 --> Config Class Initialized
INFO - 2023-08-18 19:56:21 --> Config Class Initialized
INFO - 2023-08-18 19:56:21 --> Config Class Initialized
INFO - 2023-08-18 19:56:21 --> Config Class Initialized
INFO - 2023-08-18 19:56:21 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:21 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:21 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:56:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:56:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:56:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:21 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:21 --> URI Class Initialized
INFO - 2023-08-18 19:56:21 --> URI Class Initialized
INFO - 2023-08-18 19:56:21 --> URI Class Initialized
INFO - 2023-08-18 19:56:21 --> URI Class Initialized
INFO - 2023-08-18 19:56:21 --> Router Class Initialized
INFO - 2023-08-18 19:56:21 --> Router Class Initialized
INFO - 2023-08-18 19:56:21 --> Router Class Initialized
INFO - 2023-08-18 19:56:21 --> Router Class Initialized
INFO - 2023-08-18 19:56:21 --> Output Class Initialized
INFO - 2023-08-18 19:56:21 --> Output Class Initialized
INFO - 2023-08-18 19:56:21 --> Output Class Initialized
INFO - 2023-08-18 19:56:21 --> Output Class Initialized
INFO - 2023-08-18 19:56:21 --> Security Class Initialized
INFO - 2023-08-18 19:56:21 --> Security Class Initialized
INFO - 2023-08-18 19:56:21 --> Security Class Initialized
INFO - 2023-08-18 19:56:21 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:21 --> Input Class Initialized
INFO - 2023-08-18 19:56:21 --> Input Class Initialized
INFO - 2023-08-18 19:56:21 --> Input Class Initialized
INFO - 2023-08-18 19:56:21 --> Input Class Initialized
INFO - 2023-08-18 19:56:21 --> Language Class Initialized
INFO - 2023-08-18 19:56:21 --> Language Class Initialized
INFO - 2023-08-18 19:56:21 --> Language Class Initialized
INFO - 2023-08-18 19:56:21 --> Language Class Initialized
ERROR - 2023-08-18 19:56:21 --> 404 Page Not Found: Assets/vendors
ERROR - 2023-08-18 19:56:21 --> 404 Page Not Found: Assets/vendors
ERROR - 2023-08-18 19:56:21 --> 404 Page Not Found: Assets/vendors
ERROR - 2023-08-18 19:56:21 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:21 --> Config Class Initialized
INFO - 2023-08-18 19:56:22 --> Config Class Initialized
INFO - 2023-08-18 19:56:22 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:22 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:22 --> URI Class Initialized
INFO - 2023-08-18 19:56:22 --> Router Class Initialized
INFO - 2023-08-18 19:56:22 --> Output Class Initialized
INFO - 2023-08-18 19:56:22 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:22 --> Input Class Initialized
INFO - 2023-08-18 19:56:22 --> Language Class Initialized
ERROR - 2023-08-18 19:56:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2023-08-18 19:56:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:22 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:22 --> URI Class Initialized
INFO - 2023-08-18 19:56:22 --> Router Class Initialized
INFO - 2023-08-18 19:56:22 --> Output Class Initialized
INFO - 2023-08-18 19:56:22 --> Config Class Initialized
INFO - 2023-08-18 19:56:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:22 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:22 --> URI Class Initialized
INFO - 2023-08-18 19:56:22 --> Router Class Initialized
INFO - 2023-08-18 19:56:22 --> Output Class Initialized
INFO - 2023-08-18 19:56:22 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:22 --> Input Class Initialized
INFO - 2023-08-18 19:56:22 --> Language Class Initialized
ERROR - 2023-08-18 19:56:22 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:56:22 --> Security Class Initialized
INFO - 2023-08-18 19:56:22 --> Config Class Initialized
INFO - 2023-08-18 19:56:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:22 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:22 --> URI Class Initialized
INFO - 2023-08-18 19:56:22 --> Router Class Initialized
INFO - 2023-08-18 19:56:22 --> Output Class Initialized
INFO - 2023-08-18 19:56:22 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:22 --> Input Class Initialized
INFO - 2023-08-18 19:56:22 --> Language Class Initialized
ERROR - 2023-08-18 19:56:22 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:56:22 --> Config Class Initialized
INFO - 2023-08-18 19:56:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:22 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:22 --> URI Class Initialized
INFO - 2023-08-18 19:56:22 --> Router Class Initialized
INFO - 2023-08-18 19:56:22 --> Output Class Initialized
INFO - 2023-08-18 19:56:22 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:22 --> Input Class Initialized
INFO - 2023-08-18 19:56:22 --> Language Class Initialized
ERROR - 2023-08-18 19:56:22 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 19:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:22 --> Config Class Initialized
INFO - 2023-08-18 19:56:22 --> Config Class Initialized
INFO - 2023-08-18 19:56:22 --> Config Class Initialized
INFO - 2023-08-18 19:56:22 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:22 --> Hooks Class Initialized
INFO - 2023-08-18 19:56:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:56:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:56:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:22 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:22 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:22 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:22 --> Input Class Initialized
INFO - 2023-08-18 19:56:22 --> URI Class Initialized
INFO - 2023-08-18 19:56:22 --> URI Class Initialized
INFO - 2023-08-18 19:56:22 --> URI Class Initialized
INFO - 2023-08-18 19:56:22 --> Language Class Initialized
INFO - 2023-08-18 19:56:22 --> Router Class Initialized
INFO - 2023-08-18 19:56:22 --> Router Class Initialized
INFO - 2023-08-18 19:56:22 --> Router Class Initialized
ERROR - 2023-08-18 19:56:22 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:22 --> Output Class Initialized
INFO - 2023-08-18 19:56:22 --> Output Class Initialized
INFO - 2023-08-18 19:56:22 --> Output Class Initialized
INFO - 2023-08-18 19:56:22 --> Security Class Initialized
INFO - 2023-08-18 19:56:22 --> Security Class Initialized
INFO - 2023-08-18 19:56:22 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:22 --> Input Class Initialized
INFO - 2023-08-18 19:56:22 --> Input Class Initialized
INFO - 2023-08-18 19:56:22 --> Input Class Initialized
INFO - 2023-08-18 19:56:22 --> Language Class Initialized
INFO - 2023-08-18 19:56:22 --> Language Class Initialized
INFO - 2023-08-18 19:56:22 --> Language Class Initialized
ERROR - 2023-08-18 19:56:22 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 19:56:22 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-18 19:56:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:56:23 --> Config Class Initialized
INFO - 2023-08-18 19:56:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:23 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:23 --> URI Class Initialized
INFO - 2023-08-18 19:56:23 --> Router Class Initialized
INFO - 2023-08-18 19:56:23 --> Output Class Initialized
INFO - 2023-08-18 19:56:23 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:23 --> Input Class Initialized
INFO - 2023-08-18 19:56:23 --> Language Class Initialized
ERROR - 2023-08-18 19:56:23 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:23 --> Config Class Initialized
INFO - 2023-08-18 19:56:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:23 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:23 --> URI Class Initialized
INFO - 2023-08-18 19:56:23 --> Router Class Initialized
INFO - 2023-08-18 19:56:23 --> Output Class Initialized
INFO - 2023-08-18 19:56:23 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:23 --> Input Class Initialized
INFO - 2023-08-18 19:56:23 --> Language Class Initialized
ERROR - 2023-08-18 19:56:23 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:23 --> Config Class Initialized
INFO - 2023-08-18 19:56:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:23 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:23 --> URI Class Initialized
INFO - 2023-08-18 19:56:23 --> Router Class Initialized
INFO - 2023-08-18 19:56:23 --> Output Class Initialized
INFO - 2023-08-18 19:56:23 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:23 --> Input Class Initialized
INFO - 2023-08-18 19:56:23 --> Language Class Initialized
ERROR - 2023-08-18 19:56:23 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:23 --> Config Class Initialized
INFO - 2023-08-18 19:56:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:23 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:23 --> URI Class Initialized
INFO - 2023-08-18 19:56:23 --> Router Class Initialized
INFO - 2023-08-18 19:56:23 --> Output Class Initialized
INFO - 2023-08-18 19:56:23 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:23 --> Input Class Initialized
INFO - 2023-08-18 19:56:23 --> Language Class Initialized
ERROR - 2023-08-18 19:56:23 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:23 --> Config Class Initialized
INFO - 2023-08-18 19:56:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:23 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:23 --> URI Class Initialized
INFO - 2023-08-18 19:56:23 --> Router Class Initialized
INFO - 2023-08-18 19:56:23 --> Output Class Initialized
INFO - 2023-08-18 19:56:23 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:23 --> Input Class Initialized
INFO - 2023-08-18 19:56:23 --> Language Class Initialized
ERROR - 2023-08-18 19:56:23 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:24 --> Config Class Initialized
INFO - 2023-08-18 19:56:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:24 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:24 --> URI Class Initialized
INFO - 2023-08-18 19:56:24 --> Router Class Initialized
INFO - 2023-08-18 19:56:24 --> Output Class Initialized
INFO - 2023-08-18 19:56:24 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:24 --> Input Class Initialized
INFO - 2023-08-18 19:56:24 --> Language Class Initialized
ERROR - 2023-08-18 19:56:24 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:24 --> Config Class Initialized
INFO - 2023-08-18 19:56:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:24 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:24 --> URI Class Initialized
INFO - 2023-08-18 19:56:24 --> Router Class Initialized
INFO - 2023-08-18 19:56:24 --> Output Class Initialized
INFO - 2023-08-18 19:56:24 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:24 --> Input Class Initialized
INFO - 2023-08-18 19:56:24 --> Language Class Initialized
ERROR - 2023-08-18 19:56:24 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:24 --> Config Class Initialized
INFO - 2023-08-18 19:56:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:24 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:24 --> URI Class Initialized
INFO - 2023-08-18 19:56:24 --> Router Class Initialized
INFO - 2023-08-18 19:56:24 --> Output Class Initialized
INFO - 2023-08-18 19:56:24 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:24 --> Input Class Initialized
INFO - 2023-08-18 19:56:24 --> Language Class Initialized
ERROR - 2023-08-18 19:56:24 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:24 --> Config Class Initialized
INFO - 2023-08-18 19:56:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:24 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:24 --> URI Class Initialized
INFO - 2023-08-18 19:56:24 --> Router Class Initialized
INFO - 2023-08-18 19:56:24 --> Output Class Initialized
INFO - 2023-08-18 19:56:24 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:24 --> Input Class Initialized
INFO - 2023-08-18 19:56:24 --> Language Class Initialized
ERROR - 2023-08-18 19:56:24 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:24 --> Config Class Initialized
INFO - 2023-08-18 19:56:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:24 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:24 --> URI Class Initialized
INFO - 2023-08-18 19:56:24 --> Router Class Initialized
INFO - 2023-08-18 19:56:24 --> Output Class Initialized
INFO - 2023-08-18 19:56:24 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:24 --> Input Class Initialized
INFO - 2023-08-18 19:56:24 --> Language Class Initialized
ERROR - 2023-08-18 19:56:24 --> 404 Page Not Found: Assets/vendors
INFO - 2023-08-18 19:56:24 --> Config Class Initialized
INFO - 2023-08-18 19:56:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:24 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:24 --> URI Class Initialized
INFO - 2023-08-18 19:56:24 --> Router Class Initialized
INFO - 2023-08-18 19:56:24 --> Output Class Initialized
INFO - 2023-08-18 19:56:24 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:24 --> Input Class Initialized
INFO - 2023-08-18 19:56:24 --> Language Class Initialized
ERROR - 2023-08-18 19:56:24 --> 404 Page Not Found: Assets/js
INFO - 2023-08-18 19:56:24 --> Config Class Initialized
INFO - 2023-08-18 19:56:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:24 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:24 --> URI Class Initialized
INFO - 2023-08-18 19:56:24 --> Router Class Initialized
INFO - 2023-08-18 19:56:24 --> Output Class Initialized
INFO - 2023-08-18 19:56:24 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:24 --> Input Class Initialized
INFO - 2023-08-18 19:56:24 --> Language Class Initialized
ERROR - 2023-08-18 19:56:24 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:56:24 --> Config Class Initialized
INFO - 2023-08-18 19:56:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:24 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:24 --> URI Class Initialized
INFO - 2023-08-18 19:56:24 --> Router Class Initialized
INFO - 2023-08-18 19:56:24 --> Output Class Initialized
INFO - 2023-08-18 19:56:24 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:24 --> Input Class Initialized
INFO - 2023-08-18 19:56:24 --> Language Class Initialized
ERROR - 2023-08-18 19:56:24 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:56:24 --> Config Class Initialized
INFO - 2023-08-18 19:56:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:56:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:56:24 --> Utf8 Class Initialized
INFO - 2023-08-18 19:56:24 --> URI Class Initialized
INFO - 2023-08-18 19:56:24 --> Router Class Initialized
INFO - 2023-08-18 19:56:24 --> Output Class Initialized
INFO - 2023-08-18 19:56:24 --> Security Class Initialized
DEBUG - 2023-08-18 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:56:24 --> Input Class Initialized
INFO - 2023-08-18 19:56:24 --> Language Class Initialized
ERROR - 2023-08-18 19:56:24 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:57:57 --> Config Class Initialized
INFO - 2023-08-18 19:57:57 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:57:57 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:57:57 --> Utf8 Class Initialized
INFO - 2023-08-18 19:57:57 --> URI Class Initialized
INFO - 2023-08-18 19:57:57 --> Router Class Initialized
INFO - 2023-08-18 19:57:57 --> Output Class Initialized
INFO - 2023-08-18 19:57:57 --> Security Class Initialized
DEBUG - 2023-08-18 19:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:57:57 --> Input Class Initialized
INFO - 2023-08-18 19:57:57 --> Language Class Initialized
INFO - 2023-08-18 19:57:57 --> Loader Class Initialized
INFO - 2023-08-18 19:57:57 --> Helper loaded: url_helper
INFO - 2023-08-18 19:57:57 --> Helper loaded: file_helper
INFO - 2023-08-18 19:57:57 --> Database Driver Class Initialized
INFO - 2023-08-18 19:57:57 --> Email Class Initialized
DEBUG - 2023-08-18 19:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:57:57 --> Controller Class Initialized
INFO - 2023-08-18 19:57:57 --> Model "Home_model" initialized
INFO - 2023-08-18 19:57:57 --> Helper loaded: form_helper
INFO - 2023-08-18 19:57:57 --> Form Validation Class Initialized
ERROR - 2023-08-18 19:57:57 --> Severity: Warning --> Undefined variable $trainings C:\xampp\htdocs\dw\application\views\home\blog.php 55
ERROR - 2023-08-18 19:57:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\blog.php 55
INFO - 2023-08-18 19:57:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 19:57:57 --> Final output sent to browser
DEBUG - 2023-08-18 19:57:58 --> Total execution time: 0.5371
INFO - 2023-08-18 19:57:58 --> Config Class Initialized
INFO - 2023-08-18 19:57:58 --> Config Class Initialized
INFO - 2023-08-18 19:57:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:57:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:57:58 --> Hooks Class Initialized
INFO - 2023-08-18 19:57:58 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:57:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:57:58 --> Utf8 Class Initialized
INFO - 2023-08-18 19:57:58 --> URI Class Initialized
INFO - 2023-08-18 19:57:58 --> URI Class Initialized
INFO - 2023-08-18 19:57:58 --> Router Class Initialized
INFO - 2023-08-18 19:57:58 --> Router Class Initialized
INFO - 2023-08-18 19:57:58 --> Output Class Initialized
INFO - 2023-08-18 19:57:58 --> Output Class Initialized
INFO - 2023-08-18 19:57:58 --> Security Class Initialized
INFO - 2023-08-18 19:57:58 --> Security Class Initialized
DEBUG - 2023-08-18 19:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:57:58 --> Input Class Initialized
INFO - 2023-08-18 19:57:58 --> Input Class Initialized
INFO - 2023-08-18 19:57:58 --> Language Class Initialized
INFO - 2023-08-18 19:57:58 --> Language Class Initialized
ERROR - 2023-08-18 19:57:58 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 19:57:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:57:59 --> Config Class Initialized
INFO - 2023-08-18 19:57:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:57:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:57:59 --> Utf8 Class Initialized
INFO - 2023-08-18 19:57:59 --> URI Class Initialized
INFO - 2023-08-18 19:57:59 --> Router Class Initialized
INFO - 2023-08-18 19:57:59 --> Output Class Initialized
INFO - 2023-08-18 19:57:59 --> Security Class Initialized
DEBUG - 2023-08-18 19:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:57:59 --> Input Class Initialized
INFO - 2023-08-18 19:57:59 --> Language Class Initialized
ERROR - 2023-08-18 19:57:59 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:57:59 --> Config Class Initialized
INFO - 2023-08-18 19:57:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:57:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:57:59 --> Utf8 Class Initialized
INFO - 2023-08-18 19:57:59 --> URI Class Initialized
INFO - 2023-08-18 19:57:59 --> Router Class Initialized
INFO - 2023-08-18 19:57:59 --> Output Class Initialized
INFO - 2023-08-18 19:57:59 --> Security Class Initialized
DEBUG - 2023-08-18 19:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:57:59 --> Input Class Initialized
INFO - 2023-08-18 19:57:59 --> Language Class Initialized
ERROR - 2023-08-18 19:57:59 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:57:59 --> Config Class Initialized
INFO - 2023-08-18 19:57:59 --> Config Class Initialized
INFO - 2023-08-18 19:57:59 --> Hooks Class Initialized
INFO - 2023-08-18 19:57:59 --> Config Class Initialized
DEBUG - 2023-08-18 19:57:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:57:59 --> Utf8 Class Initialized
INFO - 2023-08-18 19:57:59 --> URI Class Initialized
INFO - 2023-08-18 19:57:59 --> Router Class Initialized
INFO - 2023-08-18 19:57:59 --> Output Class Initialized
INFO - 2023-08-18 19:57:59 --> Security Class Initialized
DEBUG - 2023-08-18 19:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:57:59 --> Input Class Initialized
INFO - 2023-08-18 19:57:59 --> Language Class Initialized
ERROR - 2023-08-18 19:57:59 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:57:59 --> Config Class Initialized
INFO - 2023-08-18 19:57:59 --> Config Class Initialized
INFO - 2023-08-18 19:58:00 --> Hooks Class Initialized
INFO - 2023-08-18 19:58:00 --> Hooks Class Initialized
INFO - 2023-08-18 19:58:00 --> Config Class Initialized
INFO - 2023-08-18 19:58:00 --> Hooks Class Initialized
INFO - 2023-08-18 19:58:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:58:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:58:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:00 --> Hooks Class Initialized
INFO - 2023-08-18 19:58:00 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:58:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:58:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:00 --> Config Class Initialized
INFO - 2023-08-18 19:58:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:58:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:00 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:00 --> URI Class Initialized
INFO - 2023-08-18 19:58:00 --> Router Class Initialized
INFO - 2023-08-18 19:58:00 --> Output Class Initialized
INFO - 2023-08-18 19:58:00 --> Security Class Initialized
DEBUG - 2023-08-18 19:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:00 --> Input Class Initialized
INFO - 2023-08-18 19:58:00 --> Language Class Initialized
ERROR - 2023-08-18 19:58:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:58:00 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:58:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:00 --> URI Class Initialized
INFO - 2023-08-18 19:58:00 --> Router Class Initialized
INFO - 2023-08-18 19:58:00 --> Config Class Initialized
INFO - 2023-08-18 19:58:00 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:00 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:00 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:00 --> URI Class Initialized
INFO - 2023-08-18 19:58:00 --> Output Class Initialized
INFO - 2023-08-18 19:58:00 --> URI Class Initialized
INFO - 2023-08-18 19:58:00 --> Security Class Initialized
INFO - 2023-08-18 19:58:00 --> URI Class Initialized
INFO - 2023-08-18 19:58:00 --> Router Class Initialized
INFO - 2023-08-18 19:58:00 --> URI Class Initialized
INFO - 2023-08-18 19:58:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:58:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:00 --> Router Class Initialized
DEBUG - 2023-08-18 19:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:00 --> Output Class Initialized
INFO - 2023-08-18 19:58:00 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:00 --> Output Class Initialized
INFO - 2023-08-18 19:58:00 --> Router Class Initialized
INFO - 2023-08-18 19:58:00 --> Input Class Initialized
INFO - 2023-08-18 19:58:00 --> Router Class Initialized
INFO - 2023-08-18 19:58:00 --> Security Class Initialized
INFO - 2023-08-18 19:58:00 --> Security Class Initialized
INFO - 2023-08-18 19:58:00 --> Language Class Initialized
INFO - 2023-08-18 19:58:00 --> Output Class Initialized
INFO - 2023-08-18 19:58:00 --> Output Class Initialized
DEBUG - 2023-08-18 19:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:00 --> URI Class Initialized
INFO - 2023-08-18 19:58:00 --> Router Class Initialized
ERROR - 2023-08-18 19:58:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:58:00 --> Output Class Initialized
INFO - 2023-08-18 19:58:00 --> Security Class Initialized
INFO - 2023-08-18 19:58:00 --> Input Class Initialized
INFO - 2023-08-18 19:58:00 --> Security Class Initialized
INFO - 2023-08-18 19:58:00 --> Security Class Initialized
DEBUG - 2023-08-18 19:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:00 --> Language Class Initialized
ERROR - 2023-08-18 19:58:00 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 19:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:00 --> Config Class Initialized
INFO - 2023-08-18 19:58:00 --> Input Class Initialized
INFO - 2023-08-18 19:58:00 --> Language Class Initialized
ERROR - 2023-08-18 19:58:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:58:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:00 --> Config Class Initialized
DEBUG - 2023-08-18 19:58:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:00 --> Input Class Initialized
DEBUG - 2023-08-18 19:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:00 --> Input Class Initialized
INFO - 2023-08-18 19:58:00 --> Input Class Initialized
INFO - 2023-08-18 19:58:00 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:00 --> Language Class Initialized
INFO - 2023-08-18 19:58:01 --> Language Class Initialized
ERROR - 2023-08-18 19:58:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:58:01 --> Hooks Class Initialized
INFO - 2023-08-18 19:58:01 --> URI Class Initialized
INFO - 2023-08-18 19:58:01 --> Language Class Initialized
ERROR - 2023-08-18 19:58:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:58:01 --> Router Class Initialized
DEBUG - 2023-08-18 19:58:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:01 --> Output Class Initialized
INFO - 2023-08-18 19:58:01 --> Security Class Initialized
DEBUG - 2023-08-18 19:58:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-18 19:58:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:58:01 --> Input Class Initialized
INFO - 2023-08-18 19:58:01 --> Language Class Initialized
INFO - 2023-08-18 19:58:01 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:01 --> URI Class Initialized
ERROR - 2023-08-18 19:58:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:58:01 --> Router Class Initialized
INFO - 2023-08-18 19:58:01 --> Output Class Initialized
INFO - 2023-08-18 19:58:01 --> Security Class Initialized
DEBUG - 2023-08-18 19:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:01 --> Input Class Initialized
INFO - 2023-08-18 19:58:01 --> Language Class Initialized
ERROR - 2023-08-18 19:58:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:58:52 --> Config Class Initialized
INFO - 2023-08-18 19:58:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:58:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:52 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:52 --> URI Class Initialized
INFO - 2023-08-18 19:58:52 --> Router Class Initialized
INFO - 2023-08-18 19:58:52 --> Output Class Initialized
INFO - 2023-08-18 19:58:52 --> Security Class Initialized
DEBUG - 2023-08-18 19:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:52 --> Input Class Initialized
INFO - 2023-08-18 19:58:52 --> Language Class Initialized
INFO - 2023-08-18 19:58:52 --> Loader Class Initialized
INFO - 2023-08-18 19:58:52 --> Helper loaded: url_helper
INFO - 2023-08-18 19:58:52 --> Helper loaded: file_helper
INFO - 2023-08-18 19:58:52 --> Database Driver Class Initialized
INFO - 2023-08-18 19:58:52 --> Email Class Initialized
DEBUG - 2023-08-18 19:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:58:52 --> Controller Class Initialized
INFO - 2023-08-18 19:58:52 --> Model "Home_model" initialized
INFO - 2023-08-18 19:58:52 --> Helper loaded: form_helper
INFO - 2023-08-18 19:58:52 --> Form Validation Class Initialized
ERROR - 2023-08-18 19:58:52 --> Severity: Warning --> Undefined variable $blogs C:\xampp\htdocs\dw\application\views\home\blog.php 55
ERROR - 2023-08-18 19:58:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\blog.php 55
INFO - 2023-08-18 19:58:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 19:58:52 --> Final output sent to browser
DEBUG - 2023-08-18 19:58:53 --> Total execution time: 0.5059
INFO - 2023-08-18 19:58:53 --> Config Class Initialized
INFO - 2023-08-18 19:58:53 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:58:53 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:54 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:54 --> URI Class Initialized
INFO - 2023-08-18 19:58:54 --> Router Class Initialized
INFO - 2023-08-18 19:58:54 --> Output Class Initialized
INFO - 2023-08-18 19:58:54 --> Security Class Initialized
DEBUG - 2023-08-18 19:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:54 --> Input Class Initialized
INFO - 2023-08-18 19:58:54 --> Language Class Initialized
ERROR - 2023-08-18 19:58:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:58:54 --> Config Class Initialized
INFO - 2023-08-18 19:58:54 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:58:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:54 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:54 --> URI Class Initialized
INFO - 2023-08-18 19:58:54 --> Router Class Initialized
INFO - 2023-08-18 19:58:54 --> Output Class Initialized
INFO - 2023-08-18 19:58:54 --> Security Class Initialized
DEBUG - 2023-08-18 19:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:54 --> Input Class Initialized
INFO - 2023-08-18 19:58:54 --> Language Class Initialized
ERROR - 2023-08-18 19:58:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:58:54 --> Config Class Initialized
INFO - 2023-08-18 19:58:54 --> Hooks Class Initialized
INFO - 2023-08-18 19:58:54 --> Config Class Initialized
INFO - 2023-08-18 19:58:54 --> Config Class Initialized
INFO - 2023-08-18 19:58:54 --> Config Class Initialized
INFO - 2023-08-18 19:58:54 --> Config Class Initialized
INFO - 2023-08-18 19:58:54 --> Hooks Class Initialized
INFO - 2023-08-18 19:58:54 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:58:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:54 --> Hooks Class Initialized
INFO - 2023-08-18 19:58:54 --> Config Class Initialized
DEBUG - 2023-08-18 19:58:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:54 --> Hooks Class Initialized
INFO - 2023-08-18 19:58:54 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:58:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:54 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:54 --> URI Class Initialized
INFO - 2023-08-18 19:58:54 --> Router Class Initialized
INFO - 2023-08-18 19:58:54 --> Output Class Initialized
INFO - 2023-08-18 19:58:54 --> Security Class Initialized
DEBUG - 2023-08-18 19:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:54 --> Input Class Initialized
INFO - 2023-08-18 19:58:54 --> Language Class Initialized
ERROR - 2023-08-18 19:58:54 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 19:58:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:58:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:55 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:55 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:58:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:55 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:55 --> URI Class Initialized
INFO - 2023-08-18 19:58:55 --> URI Class Initialized
INFO - 2023-08-18 19:58:55 --> Router Class Initialized
INFO - 2023-08-18 19:58:55 --> Output Class Initialized
INFO - 2023-08-18 19:58:55 --> Security Class Initialized
DEBUG - 2023-08-18 19:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:55 --> Input Class Initialized
INFO - 2023-08-18 19:58:55 --> Language Class Initialized
ERROR - 2023-08-18 19:58:55 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:58:55 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:55 --> Config Class Initialized
INFO - 2023-08-18 19:58:55 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:55 --> URI Class Initialized
INFO - 2023-08-18 19:58:55 --> Router Class Initialized
INFO - 2023-08-18 19:58:55 --> URI Class Initialized
INFO - 2023-08-18 19:58:55 --> Hooks Class Initialized
INFO - 2023-08-18 19:58:55 --> URI Class Initialized
INFO - 2023-08-18 19:58:55 --> Router Class Initialized
DEBUG - 2023-08-18 19:58:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:55 --> Output Class Initialized
INFO - 2023-08-18 19:58:55 --> Router Class Initialized
INFO - 2023-08-18 19:58:55 --> Output Class Initialized
INFO - 2023-08-18 19:58:55 --> Router Class Initialized
INFO - 2023-08-18 19:58:55 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:55 --> Security Class Initialized
INFO - 2023-08-18 19:58:55 --> Security Class Initialized
INFO - 2023-08-18 19:58:55 --> Output Class Initialized
DEBUG - 2023-08-18 19:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:55 --> URI Class Initialized
INFO - 2023-08-18 19:58:55 --> Config Class Initialized
DEBUG - 2023-08-18 19:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:55 --> Router Class Initialized
INFO - 2023-08-18 19:58:55 --> Input Class Initialized
INFO - 2023-08-18 19:58:55 --> Hooks Class Initialized
INFO - 2023-08-18 19:58:55 --> Input Class Initialized
INFO - 2023-08-18 19:58:55 --> Security Class Initialized
INFO - 2023-08-18 19:58:55 --> Output Class Initialized
INFO - 2023-08-18 19:58:55 --> Output Class Initialized
INFO - 2023-08-18 19:58:55 --> Language Class Initialized
INFO - 2023-08-18 19:58:55 --> Language Class Initialized
INFO - 2023-08-18 19:58:55 --> Security Class Initialized
DEBUG - 2023-08-18 19:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:55 --> Security Class Initialized
ERROR - 2023-08-18 19:58:55 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 19:58:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:55 --> Input Class Initialized
ERROR - 2023-08-18 19:58:55 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 19:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:55 --> Language Class Initialized
INFO - 2023-08-18 19:58:55 --> Input Class Initialized
ERROR - 2023-08-18 19:58:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:58:55 --> Language Class Initialized
INFO - 2023-08-18 19:58:55 --> Input Class Initialized
INFO - 2023-08-18 19:58:55 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:55 --> URI Class Initialized
INFO - 2023-08-18 19:58:56 --> Language Class Initialized
ERROR - 2023-08-18 19:58:56 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 19:58:56 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:58:56 --> Config Class Initialized
INFO - 2023-08-18 19:58:56 --> Config Class Initialized
INFO - 2023-08-18 19:58:56 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:58:56 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:56 --> Hooks Class Initialized
INFO - 2023-08-18 19:58:56 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:56 --> Config Class Initialized
INFO - 2023-08-18 19:58:56 --> URI Class Initialized
INFO - 2023-08-18 19:58:56 --> Router Class Initialized
INFO - 2023-08-18 19:58:56 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:58:56 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:56 --> Router Class Initialized
INFO - 2023-08-18 19:58:56 --> Output Class Initialized
INFO - 2023-08-18 19:58:56 --> Security Class Initialized
DEBUG - 2023-08-18 19:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:56 --> Input Class Initialized
INFO - 2023-08-18 19:58:56 --> Language Class Initialized
ERROR - 2023-08-18 19:58:56 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:58:56 --> Output Class Initialized
DEBUG - 2023-08-18 19:58:56 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:58:57 --> Security Class Initialized
INFO - 2023-08-18 19:58:57 --> Utf8 Class Initialized
DEBUG - 2023-08-18 19:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:57 --> URI Class Initialized
INFO - 2023-08-18 19:58:57 --> Input Class Initialized
INFO - 2023-08-18 19:58:57 --> Utf8 Class Initialized
INFO - 2023-08-18 19:58:57 --> Language Class Initialized
INFO - 2023-08-18 19:58:57 --> URI Class Initialized
INFO - 2023-08-18 19:58:57 --> Router Class Initialized
INFO - 2023-08-18 19:58:57 --> Router Class Initialized
ERROR - 2023-08-18 19:58:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:58:57 --> Output Class Initialized
INFO - 2023-08-18 19:58:57 --> Output Class Initialized
INFO - 2023-08-18 19:58:57 --> Security Class Initialized
INFO - 2023-08-18 19:58:57 --> Security Class Initialized
DEBUG - 2023-08-18 19:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:58:57 --> Input Class Initialized
INFO - 2023-08-18 19:58:57 --> Input Class Initialized
INFO - 2023-08-18 19:58:57 --> Language Class Initialized
INFO - 2023-08-18 19:58:57 --> Language Class Initialized
ERROR - 2023-08-18 19:58:57 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-18 19:58:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:01 --> Config Class Initialized
INFO - 2023-08-18 19:59:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:01 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:01 --> URI Class Initialized
INFO - 2023-08-18 19:59:01 --> Router Class Initialized
INFO - 2023-08-18 19:59:01 --> Output Class Initialized
INFO - 2023-08-18 19:59:01 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:01 --> Input Class Initialized
INFO - 2023-08-18 19:59:01 --> Language Class Initialized
INFO - 2023-08-18 19:59:01 --> Loader Class Initialized
INFO - 2023-08-18 19:59:01 --> Helper loaded: url_helper
INFO - 2023-08-18 19:59:01 --> Helper loaded: file_helper
INFO - 2023-08-18 19:59:01 --> Database Driver Class Initialized
INFO - 2023-08-18 19:59:01 --> Email Class Initialized
DEBUG - 2023-08-18 19:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:59:01 --> Controller Class Initialized
INFO - 2023-08-18 19:59:01 --> Model "Home_model" initialized
INFO - 2023-08-18 19:59:01 --> Helper loaded: form_helper
INFO - 2023-08-18 19:59:01 --> Form Validation Class Initialized
ERROR - 2023-08-18 19:59:01 --> Severity: Warning --> Undefined variable $blogs C:\xampp\htdocs\dw\application\views\home\blog.php 55
ERROR - 2023-08-18 19:59:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\blog.php 55
INFO - 2023-08-18 19:59:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 19:59:02 --> Final output sent to browser
DEBUG - 2023-08-18 19:59:02 --> Total execution time: 0.5916
INFO - 2023-08-18 19:59:02 --> Config Class Initialized
INFO - 2023-08-18 19:59:02 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:02 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:02 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:02 --> URI Class Initialized
INFO - 2023-08-18 19:59:02 --> Router Class Initialized
INFO - 2023-08-18 19:59:02 --> Output Class Initialized
INFO - 2023-08-18 19:59:02 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:02 --> Input Class Initialized
INFO - 2023-08-18 19:59:02 --> Language Class Initialized
ERROR - 2023-08-18 19:59:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:02 --> Config Class Initialized
INFO - 2023-08-18 19:59:02 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:02 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:02 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:02 --> URI Class Initialized
INFO - 2023-08-18 19:59:02 --> Router Class Initialized
INFO - 2023-08-18 19:59:02 --> Output Class Initialized
INFO - 2023-08-18 19:59:02 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:02 --> Input Class Initialized
INFO - 2023-08-18 19:59:02 --> Language Class Initialized
ERROR - 2023-08-18 19:59:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:02 --> Config Class Initialized
INFO - 2023-08-18 19:59:02 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:02 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:02 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:02 --> URI Class Initialized
INFO - 2023-08-18 19:59:02 --> Router Class Initialized
INFO - 2023-08-18 19:59:02 --> Output Class Initialized
INFO - 2023-08-18 19:59:02 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:02 --> Input Class Initialized
INFO - 2023-08-18 19:59:02 --> Language Class Initialized
ERROR - 2023-08-18 19:59:02 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:02 --> Config Class Initialized
INFO - 2023-08-18 19:59:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:03 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:03 --> URI Class Initialized
INFO - 2023-08-18 19:59:03 --> Router Class Initialized
INFO - 2023-08-18 19:59:03 --> Output Class Initialized
INFO - 2023-08-18 19:59:03 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:03 --> Input Class Initialized
INFO - 2023-08-18 19:59:03 --> Language Class Initialized
ERROR - 2023-08-18 19:59:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:03 --> Config Class Initialized
INFO - 2023-08-18 19:59:03 --> Config Class Initialized
INFO - 2023-08-18 19:59:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:03 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:03 --> URI Class Initialized
INFO - 2023-08-18 19:59:03 --> Router Class Initialized
INFO - 2023-08-18 19:59:03 --> Output Class Initialized
INFO - 2023-08-18 19:59:03 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:03 --> Input Class Initialized
INFO - 2023-08-18 19:59:03 --> Language Class Initialized
ERROR - 2023-08-18 19:59:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:04 --> Config Class Initialized
INFO - 2023-08-18 19:59:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:04 --> Config Class Initialized
INFO - 2023-08-18 19:59:04 --> Config Class Initialized
INFO - 2023-08-18 19:59:04 --> Config Class Initialized
INFO - 2023-08-18 19:59:04 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:04 --> Config Class Initialized
INFO - 2023-08-18 19:59:04 --> Hooks Class Initialized
INFO - 2023-08-18 19:59:04 --> URI Class Initialized
INFO - 2023-08-18 19:59:04 --> Hooks Class Initialized
INFO - 2023-08-18 19:59:04 --> Hooks Class Initialized
INFO - 2023-08-18 19:59:04 --> Hooks Class Initialized
INFO - 2023-08-18 19:59:04 --> Hooks Class Initialized
INFO - 2023-08-18 19:59:04 --> Router Class Initialized
DEBUG - 2023-08-18 19:59:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:59:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:59:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:04 --> Output Class Initialized
DEBUG - 2023-08-18 19:59:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:04 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:04 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:04 --> URI Class Initialized
DEBUG - 2023-08-18 19:59:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:04 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:04 --> Security Class Initialized
INFO - 2023-08-18 19:59:04 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:04 --> URI Class Initialized
INFO - 2023-08-18 19:59:04 --> Router Class Initialized
INFO - 2023-08-18 19:59:04 --> Output Class Initialized
INFO - 2023-08-18 19:59:04 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:04 --> Input Class Initialized
INFO - 2023-08-18 19:59:04 --> Language Class Initialized
ERROR - 2023-08-18 19:59:04 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 19:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:04 --> Router Class Initialized
INFO - 2023-08-18 19:59:04 --> URI Class Initialized
INFO - 2023-08-18 19:59:04 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:04 --> Input Class Initialized
INFO - 2023-08-18 19:59:04 --> URI Class Initialized
INFO - 2023-08-18 19:59:04 --> Output Class Initialized
INFO - 2023-08-18 19:59:04 --> Security Class Initialized
INFO - 2023-08-18 19:59:04 --> Language Class Initialized
ERROR - 2023-08-18 19:59:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:04 --> Config Class Initialized
INFO - 2023-08-18 19:59:04 --> URI Class Initialized
INFO - 2023-08-18 19:59:04 --> Router Class Initialized
INFO - 2023-08-18 19:59:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:04 --> Router Class Initialized
INFO - 2023-08-18 19:59:04 --> Config Class Initialized
DEBUG - 2023-08-18 19:59:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:04 --> Output Class Initialized
INFO - 2023-08-18 19:59:04 --> Router Class Initialized
INFO - 2023-08-18 19:59:04 --> Input Class Initialized
INFO - 2023-08-18 19:59:04 --> Output Class Initialized
INFO - 2023-08-18 19:59:04 --> Hooks Class Initialized
INFO - 2023-08-18 19:59:04 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:04 --> Output Class Initialized
INFO - 2023-08-18 19:59:04 --> Language Class Initialized
INFO - 2023-08-18 19:59:04 --> Security Class Initialized
INFO - 2023-08-18 19:59:04 --> Security Class Initialized
INFO - 2023-08-18 19:59:04 --> Security Class Initialized
ERROR - 2023-08-18 19:59:04 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:04 --> URI Class Initialized
DEBUG - 2023-08-18 19:59:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 19:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 19:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:05 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:05 --> Config Class Initialized
INFO - 2023-08-18 19:59:05 --> Router Class Initialized
INFO - 2023-08-18 19:59:05 --> Input Class Initialized
INFO - 2023-08-18 19:59:05 --> Input Class Initialized
INFO - 2023-08-18 19:59:05 --> Output Class Initialized
INFO - 2023-08-18 19:59:05 --> Language Class Initialized
INFO - 2023-08-18 19:59:05 --> URI Class Initialized
INFO - 2023-08-18 19:59:05 --> Input Class Initialized
INFO - 2023-08-18 19:59:05 --> Security Class Initialized
INFO - 2023-08-18 19:59:05 --> Hooks Class Initialized
ERROR - 2023-08-18 19:59:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:05 --> Language Class Initialized
INFO - 2023-08-18 19:59:05 --> Router Class Initialized
DEBUG - 2023-08-18 19:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:05 --> Language Class Initialized
DEBUG - 2023-08-18 19:59:05 --> UTF-8 Support Enabled
ERROR - 2023-08-18 19:59:05 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:05 --> Output Class Initialized
INFO - 2023-08-18 19:59:05 --> Config Class Initialized
INFO - 2023-08-18 19:59:05 --> Input Class Initialized
INFO - 2023-08-18 19:59:05 --> Utf8 Class Initialized
ERROR - 2023-08-18 19:59:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:05 --> Language Class Initialized
ERROR - 2023-08-18 19:59:05 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:05 --> URI Class Initialized
INFO - 2023-08-18 19:59:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:06 --> Security Class Initialized
INFO - 2023-08-18 19:59:06 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:06 --> Router Class Initialized
INFO - 2023-08-18 19:59:06 --> Output Class Initialized
DEBUG - 2023-08-18 19:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:07 --> URI Class Initialized
INFO - 2023-08-18 19:59:07 --> Security Class Initialized
INFO - 2023-08-18 19:59:07 --> Router Class Initialized
DEBUG - 2023-08-18 19:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:07 --> Input Class Initialized
INFO - 2023-08-18 19:59:07 --> Input Class Initialized
INFO - 2023-08-18 19:59:07 --> Output Class Initialized
INFO - 2023-08-18 19:59:07 --> Language Class Initialized
INFO - 2023-08-18 19:59:07 --> Security Class Initialized
ERROR - 2023-08-18 19:59:07 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:07 --> Language Class Initialized
DEBUG - 2023-08-18 19:59:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-18 19:59:07 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:07 --> Input Class Initialized
INFO - 2023-08-18 19:59:07 --> Language Class Initialized
ERROR - 2023-08-18 19:59:07 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:39 --> Config Class Initialized
INFO - 2023-08-18 19:59:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:39 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:39 --> URI Class Initialized
INFO - 2023-08-18 19:59:39 --> Router Class Initialized
INFO - 2023-08-18 19:59:39 --> Output Class Initialized
INFO - 2023-08-18 19:59:39 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:39 --> Input Class Initialized
INFO - 2023-08-18 19:59:39 --> Language Class Initialized
INFO - 2023-08-18 19:59:39 --> Loader Class Initialized
INFO - 2023-08-18 19:59:39 --> Helper loaded: url_helper
INFO - 2023-08-18 19:59:40 --> Helper loaded: file_helper
INFO - 2023-08-18 19:59:40 --> Database Driver Class Initialized
INFO - 2023-08-18 19:59:40 --> Email Class Initialized
DEBUG - 2023-08-18 19:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:59:40 --> Controller Class Initialized
INFO - 2023-08-18 19:59:40 --> Model "Home_model" initialized
INFO - 2023-08-18 19:59:40 --> Helper loaded: form_helper
INFO - 2023-08-18 19:59:40 --> Form Validation Class Initialized
ERROR - 2023-08-18 19:59:40 --> Severity: Warning --> Undefined variable $blogs C:\xampp\htdocs\dw\application\views\home\blog.php 55
ERROR - 2023-08-18 19:59:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\blog.php 55
INFO - 2023-08-18 19:59:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 19:59:40 --> Final output sent to browser
DEBUG - 2023-08-18 19:59:40 --> Total execution time: 0.8169
INFO - 2023-08-18 19:59:40 --> Config Class Initialized
INFO - 2023-08-18 19:59:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:40 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:40 --> URI Class Initialized
INFO - 2023-08-18 19:59:40 --> Router Class Initialized
INFO - 2023-08-18 19:59:40 --> Output Class Initialized
INFO - 2023-08-18 19:59:40 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:41 --> Input Class Initialized
INFO - 2023-08-18 19:59:41 --> Language Class Initialized
ERROR - 2023-08-18 19:59:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:41 --> Config Class Initialized
INFO - 2023-08-18 19:59:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:41 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:41 --> URI Class Initialized
INFO - 2023-08-18 19:59:41 --> Router Class Initialized
INFO - 2023-08-18 19:59:41 --> Output Class Initialized
INFO - 2023-08-18 19:59:41 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:41 --> Input Class Initialized
INFO - 2023-08-18 19:59:41 --> Language Class Initialized
ERROR - 2023-08-18 19:59:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:41 --> Config Class Initialized
INFO - 2023-08-18 19:59:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:41 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:41 --> URI Class Initialized
INFO - 2023-08-18 19:59:41 --> Router Class Initialized
INFO - 2023-08-18 19:59:41 --> Output Class Initialized
INFO - 2023-08-18 19:59:41 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:41 --> Config Class Initialized
INFO - 2023-08-18 19:59:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:41 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:41 --> URI Class Initialized
INFO - 2023-08-18 19:59:41 --> Router Class Initialized
INFO - 2023-08-18 19:59:41 --> Output Class Initialized
INFO - 2023-08-18 19:59:41 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:41 --> Input Class Initialized
INFO - 2023-08-18 19:59:41 --> Language Class Initialized
ERROR - 2023-08-18 19:59:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:42 --> Config Class Initialized
INFO - 2023-08-18 19:59:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:42 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:42 --> URI Class Initialized
INFO - 2023-08-18 19:59:42 --> Router Class Initialized
INFO - 2023-08-18 19:59:42 --> Output Class Initialized
INFO - 2023-08-18 19:59:42 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:42 --> Input Class Initialized
INFO - 2023-08-18 19:59:42 --> Language Class Initialized
ERROR - 2023-08-18 19:59:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:42 --> Input Class Initialized
INFO - 2023-08-18 19:59:42 --> Config Class Initialized
INFO - 2023-08-18 19:59:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:42 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:42 --> URI Class Initialized
INFO - 2023-08-18 19:59:42 --> Router Class Initialized
INFO - 2023-08-18 19:59:42 --> Output Class Initialized
INFO - 2023-08-18 19:59:42 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:42 --> Input Class Initialized
INFO - 2023-08-18 19:59:42 --> Language Class Initialized
ERROR - 2023-08-18 19:59:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:42 --> Language Class Initialized
ERROR - 2023-08-18 19:59:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:42 --> Config Class Initialized
INFO - 2023-08-18 19:59:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:42 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:42 --> URI Class Initialized
INFO - 2023-08-18 19:59:43 --> Router Class Initialized
INFO - 2023-08-18 19:59:43 --> Output Class Initialized
INFO - 2023-08-18 19:59:43 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:43 --> Input Class Initialized
INFO - 2023-08-18 19:59:43 --> Language Class Initialized
ERROR - 2023-08-18 19:59:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:43 --> Config Class Initialized
INFO - 2023-08-18 19:59:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:43 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:43 --> URI Class Initialized
INFO - 2023-08-18 19:59:43 --> Router Class Initialized
INFO - 2023-08-18 19:59:43 --> Output Class Initialized
INFO - 2023-08-18 19:59:43 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:43 --> Input Class Initialized
INFO - 2023-08-18 19:59:43 --> Language Class Initialized
ERROR - 2023-08-18 19:59:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:43 --> Config Class Initialized
INFO - 2023-08-18 19:59:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:43 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:43 --> URI Class Initialized
INFO - 2023-08-18 19:59:43 --> Router Class Initialized
INFO - 2023-08-18 19:59:43 --> Output Class Initialized
INFO - 2023-08-18 19:59:43 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:43 --> Input Class Initialized
INFO - 2023-08-18 19:59:43 --> Language Class Initialized
ERROR - 2023-08-18 19:59:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:43 --> Config Class Initialized
INFO - 2023-08-18 19:59:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:43 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:43 --> URI Class Initialized
INFO - 2023-08-18 19:59:43 --> Router Class Initialized
INFO - 2023-08-18 19:59:43 --> Output Class Initialized
INFO - 2023-08-18 19:59:43 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:43 --> Config Class Initialized
INFO - 2023-08-18 19:59:44 --> Config Class Initialized
INFO - 2023-08-18 19:59:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:44 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:44 --> URI Class Initialized
INFO - 2023-08-18 19:59:44 --> Router Class Initialized
INFO - 2023-08-18 19:59:44 --> Output Class Initialized
INFO - 2023-08-18 19:59:44 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:44 --> Input Class Initialized
INFO - 2023-08-18 19:59:44 --> Language Class Initialized
ERROR - 2023-08-18 19:59:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:44 --> Input Class Initialized
INFO - 2023-08-18 19:59:44 --> Language Class Initialized
ERROR - 2023-08-18 19:59:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:44 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:44 --> URI Class Initialized
INFO - 2023-08-18 19:59:44 --> Router Class Initialized
INFO - 2023-08-18 19:59:44 --> Output Class Initialized
INFO - 2023-08-18 19:59:44 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:44 --> Input Class Initialized
INFO - 2023-08-18 19:59:44 --> Language Class Initialized
ERROR - 2023-08-18 19:59:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:44 --> Config Class Initialized
INFO - 2023-08-18 19:59:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:44 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:44 --> URI Class Initialized
INFO - 2023-08-18 19:59:44 --> Router Class Initialized
INFO - 2023-08-18 19:59:44 --> Output Class Initialized
INFO - 2023-08-18 19:59:44 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:44 --> Input Class Initialized
INFO - 2023-08-18 19:59:44 --> Language Class Initialized
ERROR - 2023-08-18 19:59:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:44 --> Config Class Initialized
INFO - 2023-08-18 19:59:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:44 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:44 --> URI Class Initialized
INFO - 2023-08-18 19:59:44 --> Router Class Initialized
INFO - 2023-08-18 19:59:44 --> Output Class Initialized
INFO - 2023-08-18 19:59:44 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:44 --> Input Class Initialized
INFO - 2023-08-18 19:59:44 --> Language Class Initialized
ERROR - 2023-08-18 19:59:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:44 --> Config Class Initialized
INFO - 2023-08-18 19:59:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:44 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:44 --> URI Class Initialized
INFO - 2023-08-18 19:59:44 --> Router Class Initialized
INFO - 2023-08-18 19:59:44 --> Output Class Initialized
INFO - 2023-08-18 19:59:44 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:44 --> Input Class Initialized
INFO - 2023-08-18 19:59:44 --> Language Class Initialized
ERROR - 2023-08-18 19:59:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:44 --> Config Class Initialized
INFO - 2023-08-18 19:59:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:44 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:44 --> URI Class Initialized
INFO - 2023-08-18 19:59:44 --> Router Class Initialized
INFO - 2023-08-18 19:59:44 --> Output Class Initialized
INFO - 2023-08-18 19:59:44 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:44 --> Input Class Initialized
INFO - 2023-08-18 19:59:44 --> Language Class Initialized
ERROR - 2023-08-18 19:59:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:51 --> Config Class Initialized
INFO - 2023-08-18 19:59:51 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:51 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:51 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:51 --> URI Class Initialized
INFO - 2023-08-18 19:59:51 --> Router Class Initialized
INFO - 2023-08-18 19:59:51 --> Output Class Initialized
INFO - 2023-08-18 19:59:51 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:51 --> Input Class Initialized
INFO - 2023-08-18 19:59:51 --> Language Class Initialized
INFO - 2023-08-18 19:59:51 --> Loader Class Initialized
INFO - 2023-08-18 19:59:51 --> Helper loaded: url_helper
INFO - 2023-08-18 19:59:51 --> Helper loaded: file_helper
INFO - 2023-08-18 19:59:51 --> Database Driver Class Initialized
INFO - 2023-08-18 19:59:51 --> Email Class Initialized
DEBUG - 2023-08-18 19:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 19:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 19:59:51 --> Controller Class Initialized
INFO - 2023-08-18 19:59:51 --> Model "Home_model" initialized
INFO - 2023-08-18 19:59:51 --> Helper loaded: form_helper
INFO - 2023-08-18 19:59:51 --> Form Validation Class Initialized
ERROR - 2023-08-18 19:59:51 --> Severity: Warning --> Undefined variable $blogs C:\xampp\htdocs\dw\application\views\home\blog.php 55
ERROR - 2023-08-18 19:59:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\blog.php 55
INFO - 2023-08-18 19:59:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 19:59:51 --> Final output sent to browser
DEBUG - 2023-08-18 19:59:51 --> Total execution time: 0.0639
INFO - 2023-08-18 19:59:52 --> Config Class Initialized
INFO - 2023-08-18 19:59:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:52 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:52 --> URI Class Initialized
INFO - 2023-08-18 19:59:52 --> Router Class Initialized
INFO - 2023-08-18 19:59:52 --> Output Class Initialized
INFO - 2023-08-18 19:59:52 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:52 --> Input Class Initialized
INFO - 2023-08-18 19:59:52 --> Language Class Initialized
ERROR - 2023-08-18 19:59:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:52 --> Config Class Initialized
INFO - 2023-08-18 19:59:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:52 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:52 --> URI Class Initialized
INFO - 2023-08-18 19:59:52 --> Router Class Initialized
INFO - 2023-08-18 19:59:52 --> Output Class Initialized
INFO - 2023-08-18 19:59:52 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:52 --> Input Class Initialized
INFO - 2023-08-18 19:59:52 --> Language Class Initialized
ERROR - 2023-08-18 19:59:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:52 --> Config Class Initialized
INFO - 2023-08-18 19:59:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:52 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:52 --> URI Class Initialized
INFO - 2023-08-18 19:59:52 --> Router Class Initialized
INFO - 2023-08-18 19:59:52 --> Output Class Initialized
INFO - 2023-08-18 19:59:52 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:52 --> Input Class Initialized
INFO - 2023-08-18 19:59:52 --> Language Class Initialized
ERROR - 2023-08-18 19:59:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:52 --> Config Class Initialized
INFO - 2023-08-18 19:59:52 --> Config Class Initialized
INFO - 2023-08-18 19:59:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:52 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:52 --> URI Class Initialized
INFO - 2023-08-18 19:59:52 --> Router Class Initialized
INFO - 2023-08-18 19:59:52 --> Output Class Initialized
INFO - 2023-08-18 19:59:52 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:52 --> Input Class Initialized
INFO - 2023-08-18 19:59:52 --> Language Class Initialized
ERROR - 2023-08-18 19:59:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:52 --> Config Class Initialized
INFO - 2023-08-18 19:59:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:52 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:52 --> URI Class Initialized
INFO - 2023-08-18 19:59:52 --> Router Class Initialized
INFO - 2023-08-18 19:59:52 --> Output Class Initialized
INFO - 2023-08-18 19:59:52 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:52 --> Input Class Initialized
INFO - 2023-08-18 19:59:52 --> Language Class Initialized
ERROR - 2023-08-18 19:59:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:52 --> Config Class Initialized
INFO - 2023-08-18 19:59:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:52 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:52 --> URI Class Initialized
INFO - 2023-08-18 19:59:52 --> Router Class Initialized
INFO - 2023-08-18 19:59:52 --> Output Class Initialized
INFO - 2023-08-18 19:59:52 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:52 --> Input Class Initialized
INFO - 2023-08-18 19:59:52 --> Language Class Initialized
ERROR - 2023-08-18 19:59:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:52 --> Config Class Initialized
INFO - 2023-08-18 19:59:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:52 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:52 --> URI Class Initialized
INFO - 2023-08-18 19:59:52 --> Router Class Initialized
INFO - 2023-08-18 19:59:52 --> Output Class Initialized
INFO - 2023-08-18 19:59:52 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:52 --> Input Class Initialized
INFO - 2023-08-18 19:59:52 --> Language Class Initialized
ERROR - 2023-08-18 19:59:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:52 --> Config Class Initialized
INFO - 2023-08-18 19:59:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:52 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:52 --> URI Class Initialized
INFO - 2023-08-18 19:59:52 --> Router Class Initialized
INFO - 2023-08-18 19:59:52 --> Output Class Initialized
INFO - 2023-08-18 19:59:52 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:52 --> Input Class Initialized
INFO - 2023-08-18 19:59:52 --> Language Class Initialized
ERROR - 2023-08-18 19:59:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:52 --> Config Class Initialized
INFO - 2023-08-18 19:59:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:52 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:52 --> URI Class Initialized
INFO - 2023-08-18 19:59:52 --> Router Class Initialized
INFO - 2023-08-18 19:59:52 --> Output Class Initialized
INFO - 2023-08-18 19:59:52 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:52 --> Input Class Initialized
INFO - 2023-08-18 19:59:52 --> Language Class Initialized
ERROR - 2023-08-18 19:59:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:53 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:53 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:53 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:53 --> URI Class Initialized
INFO - 2023-08-18 19:59:53 --> Router Class Initialized
INFO - 2023-08-18 19:59:53 --> Output Class Initialized
INFO - 2023-08-18 19:59:53 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:53 --> Input Class Initialized
INFO - 2023-08-18 19:59:53 --> Language Class Initialized
ERROR - 2023-08-18 19:59:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:53 --> Config Class Initialized
INFO - 2023-08-18 19:59:53 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:53 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:53 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:53 --> URI Class Initialized
INFO - 2023-08-18 19:59:53 --> Router Class Initialized
INFO - 2023-08-18 19:59:53 --> Output Class Initialized
INFO - 2023-08-18 19:59:53 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:53 --> Input Class Initialized
INFO - 2023-08-18 19:59:53 --> Language Class Initialized
ERROR - 2023-08-18 19:59:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 19:59:54 --> Config Class Initialized
INFO - 2023-08-18 19:59:54 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:54 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:54 --> URI Class Initialized
INFO - 2023-08-18 19:59:54 --> Router Class Initialized
INFO - 2023-08-18 19:59:54 --> Output Class Initialized
INFO - 2023-08-18 19:59:54 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:54 --> Input Class Initialized
INFO - 2023-08-18 19:59:54 --> Language Class Initialized
ERROR - 2023-08-18 19:59:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 19:59:55 --> Config Class Initialized
INFO - 2023-08-18 19:59:55 --> Hooks Class Initialized
DEBUG - 2023-08-18 19:59:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 19:59:55 --> Utf8 Class Initialized
INFO - 2023-08-18 19:59:55 --> URI Class Initialized
INFO - 2023-08-18 19:59:55 --> Router Class Initialized
INFO - 2023-08-18 19:59:55 --> Output Class Initialized
INFO - 2023-08-18 19:59:55 --> Security Class Initialized
DEBUG - 2023-08-18 19:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 19:59:55 --> Input Class Initialized
INFO - 2023-08-18 19:59:56 --> Language Class Initialized
ERROR - 2023-08-18 19:59:56 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 20:00:40 --> Config Class Initialized
INFO - 2023-08-18 20:00:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:40 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:40 --> URI Class Initialized
INFO - 2023-08-18 20:00:40 --> Router Class Initialized
INFO - 2023-08-18 20:00:40 --> Output Class Initialized
INFO - 2023-08-18 20:00:40 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:40 --> Input Class Initialized
INFO - 2023-08-18 20:00:40 --> Language Class Initialized
INFO - 2023-08-18 20:00:40 --> Loader Class Initialized
INFO - 2023-08-18 20:00:40 --> Helper loaded: url_helper
INFO - 2023-08-18 20:00:40 --> Helper loaded: file_helper
INFO - 2023-08-18 20:00:41 --> Database Driver Class Initialized
INFO - 2023-08-18 20:00:41 --> Email Class Initialized
DEBUG - 2023-08-18 20:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:00:41 --> Controller Class Initialized
INFO - 2023-08-18 20:00:41 --> Model "Home_model" initialized
INFO - 2023-08-18 20:00:41 --> Helper loaded: form_helper
INFO - 2023-08-18 20:00:41 --> Form Validation Class Initialized
ERROR - 2023-08-18 20:00:41 --> Severity: Warning --> Undefined variable $blogs C:\xampp\htdocs\dw\application\views\home\blog.php 55
ERROR - 2023-08-18 20:00:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\blog.php 55
INFO - 2023-08-18 20:00:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:00:41 --> Final output sent to browser
DEBUG - 2023-08-18 20:00:42 --> Total execution time: 1.5860
INFO - 2023-08-18 20:00:42 --> Config Class Initialized
INFO - 2023-08-18 20:00:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:42 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:42 --> URI Class Initialized
INFO - 2023-08-18 20:00:42 --> Router Class Initialized
INFO - 2023-08-18 20:00:42 --> Output Class Initialized
INFO - 2023-08-18 20:00:42 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:42 --> Input Class Initialized
INFO - 2023-08-18 20:00:42 --> Language Class Initialized
ERROR - 2023-08-18 20:00:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:00:42 --> Config Class Initialized
INFO - 2023-08-18 20:00:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:42 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:42 --> URI Class Initialized
INFO - 2023-08-18 20:00:42 --> Router Class Initialized
INFO - 2023-08-18 20:00:42 --> Output Class Initialized
INFO - 2023-08-18 20:00:42 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:42 --> Input Class Initialized
INFO - 2023-08-18 20:00:42 --> Language Class Initialized
ERROR - 2023-08-18 20:00:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:00:42 --> Config Class Initialized
INFO - 2023-08-18 20:00:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:42 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:42 --> URI Class Initialized
INFO - 2023-08-18 20:00:42 --> Router Class Initialized
INFO - 2023-08-18 20:00:42 --> Output Class Initialized
INFO - 2023-08-18 20:00:42 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:42 --> Input Class Initialized
INFO - 2023-08-18 20:00:42 --> Language Class Initialized
ERROR - 2023-08-18 20:00:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:00:42 --> Config Class Initialized
INFO - 2023-08-18 20:00:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:42 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:42 --> URI Class Initialized
INFO - 2023-08-18 20:00:42 --> Router Class Initialized
INFO - 2023-08-18 20:00:42 --> Output Class Initialized
INFO - 2023-08-18 20:00:42 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:42 --> Input Class Initialized
INFO - 2023-08-18 20:00:42 --> Language Class Initialized
ERROR - 2023-08-18 20:00:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 20:00:43 --> Config Class Initialized
INFO - 2023-08-18 20:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:43 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:43 --> URI Class Initialized
INFO - 2023-08-18 20:00:43 --> Router Class Initialized
INFO - 2023-08-18 20:00:43 --> Output Class Initialized
INFO - 2023-08-18 20:00:43 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:43 --> Input Class Initialized
INFO - 2023-08-18 20:00:43 --> Language Class Initialized
ERROR - 2023-08-18 20:00:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 20:00:43 --> Config Class Initialized
INFO - 2023-08-18 20:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:43 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:43 --> URI Class Initialized
INFO - 2023-08-18 20:00:43 --> Router Class Initialized
INFO - 2023-08-18 20:00:43 --> Output Class Initialized
INFO - 2023-08-18 20:00:43 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:43 --> Input Class Initialized
INFO - 2023-08-18 20:00:43 --> Language Class Initialized
ERROR - 2023-08-18 20:00:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 20:00:43 --> Config Class Initialized
INFO - 2023-08-18 20:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:43 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:43 --> URI Class Initialized
INFO - 2023-08-18 20:00:43 --> Router Class Initialized
INFO - 2023-08-18 20:00:43 --> Output Class Initialized
INFO - 2023-08-18 20:00:43 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:43 --> Input Class Initialized
INFO - 2023-08-18 20:00:43 --> Language Class Initialized
ERROR - 2023-08-18 20:00:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 20:00:43 --> Config Class Initialized
INFO - 2023-08-18 20:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:43 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:43 --> URI Class Initialized
INFO - 2023-08-18 20:00:43 --> Router Class Initialized
INFO - 2023-08-18 20:00:43 --> Output Class Initialized
INFO - 2023-08-18 20:00:43 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:43 --> Input Class Initialized
INFO - 2023-08-18 20:00:43 --> Language Class Initialized
ERROR - 2023-08-18 20:00:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 20:00:43 --> Config Class Initialized
INFO - 2023-08-18 20:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:43 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:43 --> URI Class Initialized
INFO - 2023-08-18 20:00:43 --> Router Class Initialized
INFO - 2023-08-18 20:00:43 --> Output Class Initialized
INFO - 2023-08-18 20:00:43 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:43 --> Input Class Initialized
INFO - 2023-08-18 20:00:43 --> Language Class Initialized
ERROR - 2023-08-18 20:00:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 20:00:43 --> Config Class Initialized
INFO - 2023-08-18 20:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:43 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:43 --> URI Class Initialized
INFO - 2023-08-18 20:00:43 --> Router Class Initialized
INFO - 2023-08-18 20:00:43 --> Output Class Initialized
INFO - 2023-08-18 20:00:43 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:43 --> Input Class Initialized
INFO - 2023-08-18 20:00:43 --> Language Class Initialized
ERROR - 2023-08-18 20:00:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-18 20:00:43 --> Config Class Initialized
INFO - 2023-08-18 20:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:43 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:43 --> URI Class Initialized
INFO - 2023-08-18 20:00:43 --> Router Class Initialized
INFO - 2023-08-18 20:00:43 --> Output Class Initialized
INFO - 2023-08-18 20:00:43 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:43 --> Input Class Initialized
INFO - 2023-08-18 20:00:43 --> Language Class Initialized
ERROR - 2023-08-18 20:00:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:00:43 --> Config Class Initialized
INFO - 2023-08-18 20:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:43 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:43 --> URI Class Initialized
INFO - 2023-08-18 20:00:43 --> Router Class Initialized
INFO - 2023-08-18 20:00:43 --> Output Class Initialized
INFO - 2023-08-18 20:00:43 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:43 --> Input Class Initialized
INFO - 2023-08-18 20:00:43 --> Language Class Initialized
ERROR - 2023-08-18 20:00:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:00:44 --> Config Class Initialized
INFO - 2023-08-18 20:00:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:44 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:44 --> URI Class Initialized
INFO - 2023-08-18 20:00:44 --> Router Class Initialized
INFO - 2023-08-18 20:00:44 --> Output Class Initialized
INFO - 2023-08-18 20:00:44 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:44 --> Input Class Initialized
INFO - 2023-08-18 20:00:44 --> Language Class Initialized
ERROR - 2023-08-18 20:00:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:00:45 --> Config Class Initialized
INFO - 2023-08-18 20:00:45 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:45 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:45 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:45 --> URI Class Initialized
INFO - 2023-08-18 20:00:45 --> Router Class Initialized
INFO - 2023-08-18 20:00:45 --> Output Class Initialized
INFO - 2023-08-18 20:00:45 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:45 --> Input Class Initialized
INFO - 2023-08-18 20:00:45 --> Language Class Initialized
ERROR - 2023-08-18 20:00:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:00:57 --> Config Class Initialized
INFO - 2023-08-18 20:00:57 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:57 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:57 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:57 --> URI Class Initialized
INFO - 2023-08-18 20:00:58 --> Router Class Initialized
INFO - 2023-08-18 20:00:58 --> Output Class Initialized
INFO - 2023-08-18 20:00:58 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:58 --> Input Class Initialized
INFO - 2023-08-18 20:00:58 --> Language Class Initialized
INFO - 2023-08-18 20:00:58 --> Loader Class Initialized
INFO - 2023-08-18 20:00:58 --> Helper loaded: url_helper
INFO - 2023-08-18 20:00:58 --> Helper loaded: file_helper
INFO - 2023-08-18 20:00:58 --> Database Driver Class Initialized
INFO - 2023-08-18 20:00:58 --> Email Class Initialized
DEBUG - 2023-08-18 20:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:00:58 --> Controller Class Initialized
INFO - 2023-08-18 20:00:58 --> Model "Home_model" initialized
INFO - 2023-08-18 20:00:58 --> Helper loaded: form_helper
INFO - 2023-08-18 20:00:58 --> Form Validation Class Initialized
ERROR - 2023-08-18 20:00:58 --> Severity: Warning --> Undefined variable $blogs C:\xampp\htdocs\dw\application\views\home\blog.php 55
ERROR - 2023-08-18 20:00:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\blog.php 55
INFO - 2023-08-18 20:00:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:00:58 --> Final output sent to browser
DEBUG - 2023-08-18 20:00:59 --> Total execution time: 1.0515
INFO - 2023-08-18 20:00:59 --> Config Class Initialized
INFO - 2023-08-18 20:00:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:59 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:59 --> URI Class Initialized
INFO - 2023-08-18 20:00:59 --> Router Class Initialized
INFO - 2023-08-18 20:00:59 --> Output Class Initialized
INFO - 2023-08-18 20:00:59 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:59 --> Input Class Initialized
INFO - 2023-08-18 20:00:59 --> Language Class Initialized
ERROR - 2023-08-18 20:00:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:00:59 --> Config Class Initialized
INFO - 2023-08-18 20:00:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:00:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:00:59 --> Utf8 Class Initialized
INFO - 2023-08-18 20:00:59 --> URI Class Initialized
INFO - 2023-08-18 20:00:59 --> Router Class Initialized
INFO - 2023-08-18 20:00:59 --> Output Class Initialized
INFO - 2023-08-18 20:00:59 --> Security Class Initialized
DEBUG - 2023-08-18 20:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:00:59 --> Input Class Initialized
INFO - 2023-08-18 20:00:59 --> Language Class Initialized
ERROR - 2023-08-18 20:00:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:00:59 --> Config Class Initialized
INFO - 2023-08-18 20:01:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:01:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:01:00 --> Utf8 Class Initialized
INFO - 2023-08-18 20:01:00 --> URI Class Initialized
INFO - 2023-08-18 20:01:00 --> Router Class Initialized
INFO - 2023-08-18 20:01:00 --> Output Class Initialized
INFO - 2023-08-18 20:01:00 --> Security Class Initialized
DEBUG - 2023-08-18 20:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:01:00 --> Input Class Initialized
INFO - 2023-08-18 20:01:00 --> Language Class Initialized
ERROR - 2023-08-18 20:01:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:01:00 --> Config Class Initialized
INFO - 2023-08-18 20:01:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:01:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:01:00 --> Utf8 Class Initialized
INFO - 2023-08-18 20:01:00 --> URI Class Initialized
INFO - 2023-08-18 20:01:00 --> Router Class Initialized
INFO - 2023-08-18 20:01:01 --> Output Class Initialized
INFO - 2023-08-18 20:01:01 --> Security Class Initialized
DEBUG - 2023-08-18 20:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:01:01 --> Input Class Initialized
INFO - 2023-08-18 20:01:01 --> Language Class Initialized
ERROR - 2023-08-18 20:01:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:01:01 --> Config Class Initialized
INFO - 2023-08-18 20:01:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:01:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:01:01 --> Utf8 Class Initialized
INFO - 2023-08-18 20:01:01 --> URI Class Initialized
INFO - 2023-08-18 20:01:01 --> Router Class Initialized
INFO - 2023-08-18 20:01:01 --> Output Class Initialized
INFO - 2023-08-18 20:01:01 --> Security Class Initialized
DEBUG - 2023-08-18 20:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:01:01 --> Input Class Initialized
INFO - 2023-08-18 20:01:01 --> Language Class Initialized
ERROR - 2023-08-18 20:01:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:01:01 --> Config Class Initialized
INFO - 2023-08-18 20:01:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:01:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:01:01 --> Utf8 Class Initialized
INFO - 2023-08-18 20:01:01 --> URI Class Initialized
INFO - 2023-08-18 20:01:01 --> Router Class Initialized
INFO - 2023-08-18 20:01:01 --> Output Class Initialized
INFO - 2023-08-18 20:01:01 --> Security Class Initialized
DEBUG - 2023-08-18 20:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:01:01 --> Input Class Initialized
INFO - 2023-08-18 20:01:02 --> Language Class Initialized
ERROR - 2023-08-18 20:01:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:02:27 --> Config Class Initialized
INFO - 2023-08-18 20:02:27 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:02:28 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:02:28 --> Utf8 Class Initialized
INFO - 2023-08-18 20:02:28 --> URI Class Initialized
INFO - 2023-08-18 20:02:28 --> Router Class Initialized
INFO - 2023-08-18 20:02:28 --> Output Class Initialized
INFO - 2023-08-18 20:02:28 --> Security Class Initialized
DEBUG - 2023-08-18 20:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:02:28 --> Input Class Initialized
INFO - 2023-08-18 20:02:28 --> Language Class Initialized
INFO - 2023-08-18 20:02:28 --> Loader Class Initialized
INFO - 2023-08-18 20:02:28 --> Helper loaded: url_helper
INFO - 2023-08-18 20:02:28 --> Helper loaded: file_helper
INFO - 2023-08-18 20:02:28 --> Database Driver Class Initialized
INFO - 2023-08-18 20:02:28 --> Email Class Initialized
DEBUG - 2023-08-18 20:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:02:28 --> Controller Class Initialized
INFO - 2023-08-18 20:02:29 --> Model "Home_model" initialized
INFO - 2023-08-18 20:02:29 --> Helper loaded: form_helper
INFO - 2023-08-18 20:02:29 --> Form Validation Class Initialized
INFO - 2023-08-18 20:02:38 --> Config Class Initialized
INFO - 2023-08-18 20:02:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:02:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:02:38 --> Utf8 Class Initialized
INFO - 2023-08-18 20:02:38 --> URI Class Initialized
INFO - 2023-08-18 20:02:38 --> Router Class Initialized
INFO - 2023-08-18 20:02:39 --> Output Class Initialized
INFO - 2023-08-18 20:02:39 --> Security Class Initialized
DEBUG - 2023-08-18 20:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:02:39 --> Input Class Initialized
INFO - 2023-08-18 20:02:39 --> Language Class Initialized
INFO - 2023-08-18 20:02:39 --> Loader Class Initialized
INFO - 2023-08-18 20:02:39 --> Helper loaded: url_helper
INFO - 2023-08-18 20:02:39 --> Helper loaded: file_helper
INFO - 2023-08-18 20:02:39 --> Database Driver Class Initialized
INFO - 2023-08-18 20:02:39 --> Email Class Initialized
DEBUG - 2023-08-18 20:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:02:39 --> Controller Class Initialized
INFO - 2023-08-18 20:02:39 --> Model "Home_model" initialized
INFO - 2023-08-18 20:02:39 --> Helper loaded: form_helper
INFO - 2023-08-18 20:02:39 --> Form Validation Class Initialized
INFO - 2023-08-18 20:02:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:02:39 --> Final output sent to browser
DEBUG - 2023-08-18 20:02:40 --> Total execution time: 1.1070
INFO - 2023-08-18 20:02:40 --> Config Class Initialized
INFO - 2023-08-18 20:02:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:02:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:02:40 --> Utf8 Class Initialized
INFO - 2023-08-18 20:02:40 --> URI Class Initialized
INFO - 2023-08-18 20:02:40 --> Router Class Initialized
INFO - 2023-08-18 20:02:40 --> Output Class Initialized
INFO - 2023-08-18 20:02:40 --> Security Class Initialized
DEBUG - 2023-08-18 20:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:02:40 --> Input Class Initialized
INFO - 2023-08-18 20:02:40 --> Language Class Initialized
ERROR - 2023-08-18 20:02:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:02:40 --> Config Class Initialized
INFO - 2023-08-18 20:02:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:02:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:02:40 --> Utf8 Class Initialized
INFO - 2023-08-18 20:02:40 --> URI Class Initialized
INFO - 2023-08-18 20:02:40 --> Router Class Initialized
INFO - 2023-08-18 20:02:40 --> Output Class Initialized
INFO - 2023-08-18 20:02:40 --> Security Class Initialized
DEBUG - 2023-08-18 20:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:02:40 --> Input Class Initialized
INFO - 2023-08-18 20:02:40 --> Language Class Initialized
ERROR - 2023-08-18 20:02:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:02:40 --> Config Class Initialized
INFO - 2023-08-18 20:02:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:02:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:02:40 --> Utf8 Class Initialized
INFO - 2023-08-18 20:02:40 --> URI Class Initialized
INFO - 2023-08-18 20:02:40 --> Router Class Initialized
INFO - 2023-08-18 20:02:40 --> Output Class Initialized
INFO - 2023-08-18 20:02:40 --> Security Class Initialized
DEBUG - 2023-08-18 20:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:02:40 --> Input Class Initialized
INFO - 2023-08-18 20:02:40 --> Language Class Initialized
ERROR - 2023-08-18 20:02:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:02:41 --> Config Class Initialized
INFO - 2023-08-18 20:02:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:02:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:02:41 --> Utf8 Class Initialized
INFO - 2023-08-18 20:02:41 --> URI Class Initialized
INFO - 2023-08-18 20:02:41 --> Router Class Initialized
INFO - 2023-08-18 20:02:41 --> Output Class Initialized
INFO - 2023-08-18 20:02:41 --> Security Class Initialized
DEBUG - 2023-08-18 20:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:02:41 --> Input Class Initialized
INFO - 2023-08-18 20:02:41 --> Language Class Initialized
ERROR - 2023-08-18 20:02:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:02:41 --> Config Class Initialized
INFO - 2023-08-18 20:02:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:02:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:02:41 --> Utf8 Class Initialized
INFO - 2023-08-18 20:02:41 --> URI Class Initialized
INFO - 2023-08-18 20:02:41 --> Router Class Initialized
INFO - 2023-08-18 20:02:41 --> Output Class Initialized
INFO - 2023-08-18 20:02:41 --> Security Class Initialized
DEBUG - 2023-08-18 20:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:02:42 --> Input Class Initialized
INFO - 2023-08-18 20:02:42 --> Language Class Initialized
ERROR - 2023-08-18 20:02:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:02:42 --> Config Class Initialized
INFO - 2023-08-18 20:02:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:02:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:02:42 --> Utf8 Class Initialized
INFO - 2023-08-18 20:02:42 --> URI Class Initialized
INFO - 2023-08-18 20:02:42 --> Router Class Initialized
INFO - 2023-08-18 20:02:42 --> Output Class Initialized
INFO - 2023-08-18 20:02:42 --> Security Class Initialized
DEBUG - 2023-08-18 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:02:42 --> Input Class Initialized
INFO - 2023-08-18 20:02:42 --> Language Class Initialized
ERROR - 2023-08-18 20:02:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:02:42 --> Config Class Initialized
INFO - 2023-08-18 20:02:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:02:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:02:42 --> Utf8 Class Initialized
INFO - 2023-08-18 20:02:42 --> URI Class Initialized
INFO - 2023-08-18 20:02:42 --> Router Class Initialized
INFO - 2023-08-18 20:02:42 --> Output Class Initialized
INFO - 2023-08-18 20:02:42 --> Security Class Initialized
DEBUG - 2023-08-18 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:02:42 --> Input Class Initialized
INFO - 2023-08-18 20:02:42 --> Language Class Initialized
ERROR - 2023-08-18 20:02:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:02:42 --> Config Class Initialized
INFO - 2023-08-18 20:02:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:02:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:02:42 --> Utf8 Class Initialized
INFO - 2023-08-18 20:02:42 --> URI Class Initialized
INFO - 2023-08-18 20:02:42 --> Router Class Initialized
INFO - 2023-08-18 20:02:42 --> Output Class Initialized
INFO - 2023-08-18 20:02:42 --> Security Class Initialized
DEBUG - 2023-08-18 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:02:42 --> Input Class Initialized
INFO - 2023-08-18 20:02:42 --> Language Class Initialized
ERROR - 2023-08-18 20:02:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:03:38 --> Config Class Initialized
INFO - 2023-08-18 20:03:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:03:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:03:38 --> Utf8 Class Initialized
INFO - 2023-08-18 20:03:38 --> URI Class Initialized
INFO - 2023-08-18 20:03:38 --> Router Class Initialized
INFO - 2023-08-18 20:03:38 --> Output Class Initialized
INFO - 2023-08-18 20:03:38 --> Security Class Initialized
DEBUG - 2023-08-18 20:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:03:38 --> Input Class Initialized
INFO - 2023-08-18 20:03:38 --> Language Class Initialized
INFO - 2023-08-18 20:03:38 --> Loader Class Initialized
INFO - 2023-08-18 20:03:38 --> Helper loaded: url_helper
INFO - 2023-08-18 20:03:39 --> Helper loaded: file_helper
INFO - 2023-08-18 20:03:39 --> Database Driver Class Initialized
INFO - 2023-08-18 20:03:39 --> Email Class Initialized
DEBUG - 2023-08-18 20:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:03:39 --> Controller Class Initialized
INFO - 2023-08-18 20:03:39 --> Model "Home_model" initialized
INFO - 2023-08-18 20:03:39 --> Helper loaded: form_helper
INFO - 2023-08-18 20:03:39 --> Form Validation Class Initialized
INFO - 2023-08-18 20:03:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:03:39 --> Final output sent to browser
DEBUG - 2023-08-18 20:03:39 --> Total execution time: 0.7129
INFO - 2023-08-18 20:03:39 --> Config Class Initialized
INFO - 2023-08-18 20:03:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:03:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:03:39 --> Utf8 Class Initialized
INFO - 2023-08-18 20:03:39 --> URI Class Initialized
INFO - 2023-08-18 20:03:39 --> Router Class Initialized
INFO - 2023-08-18 20:03:39 --> Output Class Initialized
INFO - 2023-08-18 20:03:39 --> Security Class Initialized
DEBUG - 2023-08-18 20:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:03:39 --> Input Class Initialized
INFO - 2023-08-18 20:03:39 --> Language Class Initialized
ERROR - 2023-08-18 20:03:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:03:40 --> Config Class Initialized
INFO - 2023-08-18 20:03:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:03:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:03:40 --> Utf8 Class Initialized
INFO - 2023-08-18 20:03:40 --> URI Class Initialized
INFO - 2023-08-18 20:03:40 --> Router Class Initialized
INFO - 2023-08-18 20:03:40 --> Output Class Initialized
INFO - 2023-08-18 20:03:40 --> Security Class Initialized
DEBUG - 2023-08-18 20:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:03:40 --> Input Class Initialized
INFO - 2023-08-18 20:03:40 --> Language Class Initialized
ERROR - 2023-08-18 20:03:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:03:40 --> Config Class Initialized
INFO - 2023-08-18 20:03:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:03:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:03:40 --> Utf8 Class Initialized
INFO - 2023-08-18 20:03:40 --> URI Class Initialized
INFO - 2023-08-18 20:03:40 --> Router Class Initialized
INFO - 2023-08-18 20:03:40 --> Output Class Initialized
INFO - 2023-08-18 20:03:40 --> Security Class Initialized
DEBUG - 2023-08-18 20:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:03:40 --> Input Class Initialized
INFO - 2023-08-18 20:03:40 --> Language Class Initialized
ERROR - 2023-08-18 20:03:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:03:40 --> Config Class Initialized
INFO - 2023-08-18 20:03:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:03:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:03:40 --> Utf8 Class Initialized
INFO - 2023-08-18 20:03:40 --> URI Class Initialized
INFO - 2023-08-18 20:03:40 --> Router Class Initialized
INFO - 2023-08-18 20:03:40 --> Output Class Initialized
INFO - 2023-08-18 20:03:40 --> Security Class Initialized
DEBUG - 2023-08-18 20:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:03:40 --> Input Class Initialized
INFO - 2023-08-18 20:03:40 --> Language Class Initialized
ERROR - 2023-08-18 20:03:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:03:40 --> Config Class Initialized
INFO - 2023-08-18 20:03:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:03:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:03:40 --> Utf8 Class Initialized
INFO - 2023-08-18 20:03:40 --> URI Class Initialized
INFO - 2023-08-18 20:03:40 --> Router Class Initialized
INFO - 2023-08-18 20:03:40 --> Output Class Initialized
INFO - 2023-08-18 20:03:40 --> Security Class Initialized
DEBUG - 2023-08-18 20:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:03:40 --> Input Class Initialized
INFO - 2023-08-18 20:03:40 --> Language Class Initialized
ERROR - 2023-08-18 20:03:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:03:40 --> Config Class Initialized
INFO - 2023-08-18 20:03:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:03:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:03:40 --> Utf8 Class Initialized
INFO - 2023-08-18 20:03:40 --> URI Class Initialized
INFO - 2023-08-18 20:03:40 --> Router Class Initialized
INFO - 2023-08-18 20:03:40 --> Output Class Initialized
INFO - 2023-08-18 20:03:40 --> Security Class Initialized
DEBUG - 2023-08-18 20:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:03:40 --> Input Class Initialized
INFO - 2023-08-18 20:03:40 --> Language Class Initialized
ERROR - 2023-08-18 20:03:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:03:40 --> Config Class Initialized
INFO - 2023-08-18 20:03:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:03:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:03:40 --> Utf8 Class Initialized
INFO - 2023-08-18 20:03:40 --> URI Class Initialized
INFO - 2023-08-18 20:03:40 --> Router Class Initialized
INFO - 2023-08-18 20:03:40 --> Output Class Initialized
INFO - 2023-08-18 20:03:40 --> Security Class Initialized
DEBUG - 2023-08-18 20:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:03:40 --> Input Class Initialized
INFO - 2023-08-18 20:03:40 --> Language Class Initialized
ERROR - 2023-08-18 20:03:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:03:40 --> Config Class Initialized
INFO - 2023-08-18 20:03:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:03:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:03:40 --> Utf8 Class Initialized
INFO - 2023-08-18 20:03:40 --> URI Class Initialized
INFO - 2023-08-18 20:03:40 --> Router Class Initialized
INFO - 2023-08-18 20:03:40 --> Output Class Initialized
INFO - 2023-08-18 20:03:41 --> Security Class Initialized
DEBUG - 2023-08-18 20:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:03:41 --> Input Class Initialized
INFO - 2023-08-18 20:03:41 --> Language Class Initialized
ERROR - 2023-08-18 20:03:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:09:03 --> Config Class Initialized
INFO - 2023-08-18 20:09:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:03 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:03 --> URI Class Initialized
INFO - 2023-08-18 20:09:03 --> Router Class Initialized
INFO - 2023-08-18 20:09:03 --> Output Class Initialized
INFO - 2023-08-18 20:09:03 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:03 --> Input Class Initialized
INFO - 2023-08-18 20:09:03 --> Language Class Initialized
INFO - 2023-08-18 20:09:03 --> Loader Class Initialized
INFO - 2023-08-18 20:09:03 --> Helper loaded: url_helper
INFO - 2023-08-18 20:09:03 --> Helper loaded: file_helper
INFO - 2023-08-18 20:09:03 --> Database Driver Class Initialized
INFO - 2023-08-18 20:09:03 --> Email Class Initialized
DEBUG - 2023-08-18 20:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:09:03 --> Controller Class Initialized
INFO - 2023-08-18 20:09:03 --> Model "Home_model" initialized
INFO - 2023-08-18 20:09:03 --> Helper loaded: form_helper
INFO - 2023-08-18 20:09:04 --> Form Validation Class Initialized
INFO - 2023-08-18 20:09:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:09:04 --> Final output sent to browser
DEBUG - 2023-08-18 20:09:04 --> Total execution time: 0.9782
INFO - 2023-08-18 20:09:04 --> Config Class Initialized
INFO - 2023-08-18 20:09:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:04 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:04 --> URI Class Initialized
INFO - 2023-08-18 20:09:04 --> Router Class Initialized
INFO - 2023-08-18 20:09:04 --> Output Class Initialized
INFO - 2023-08-18 20:09:04 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:04 --> Input Class Initialized
INFO - 2023-08-18 20:09:04 --> Language Class Initialized
ERROR - 2023-08-18 20:09:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:09:04 --> Config Class Initialized
INFO - 2023-08-18 20:09:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:04 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:04 --> URI Class Initialized
INFO - 2023-08-18 20:09:04 --> Router Class Initialized
INFO - 2023-08-18 20:09:04 --> Output Class Initialized
INFO - 2023-08-18 20:09:04 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:04 --> Input Class Initialized
INFO - 2023-08-18 20:09:04 --> Language Class Initialized
ERROR - 2023-08-18 20:09:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:09:04 --> Config Class Initialized
INFO - 2023-08-18 20:09:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:05 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:05 --> URI Class Initialized
INFO - 2023-08-18 20:09:05 --> Router Class Initialized
INFO - 2023-08-18 20:09:05 --> Output Class Initialized
INFO - 2023-08-18 20:09:05 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:05 --> Input Class Initialized
INFO - 2023-08-18 20:09:05 --> Language Class Initialized
ERROR - 2023-08-18 20:09:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:09:05 --> Config Class Initialized
INFO - 2023-08-18 20:09:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:05 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:05 --> URI Class Initialized
INFO - 2023-08-18 20:09:05 --> Router Class Initialized
INFO - 2023-08-18 20:09:05 --> Output Class Initialized
INFO - 2023-08-18 20:09:05 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:05 --> Input Class Initialized
INFO - 2023-08-18 20:09:05 --> Language Class Initialized
ERROR - 2023-08-18 20:09:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:09:05 --> Config Class Initialized
INFO - 2023-08-18 20:09:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:05 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:05 --> URI Class Initialized
INFO - 2023-08-18 20:09:05 --> Router Class Initialized
INFO - 2023-08-18 20:09:05 --> Output Class Initialized
INFO - 2023-08-18 20:09:05 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:05 --> Input Class Initialized
INFO - 2023-08-18 20:09:05 --> Language Class Initialized
ERROR - 2023-08-18 20:09:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:09:05 --> Config Class Initialized
INFO - 2023-08-18 20:09:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:05 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:05 --> URI Class Initialized
INFO - 2023-08-18 20:09:05 --> Router Class Initialized
INFO - 2023-08-18 20:09:05 --> Output Class Initialized
INFO - 2023-08-18 20:09:05 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:05 --> Input Class Initialized
INFO - 2023-08-18 20:09:05 --> Language Class Initialized
ERROR - 2023-08-18 20:09:05 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-18 20:09:05 --> Config Class Initialized
INFO - 2023-08-18 20:09:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:05 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:05 --> URI Class Initialized
INFO - 2023-08-18 20:09:05 --> Router Class Initialized
INFO - 2023-08-18 20:09:05 --> Output Class Initialized
INFO - 2023-08-18 20:09:05 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:05 --> Input Class Initialized
INFO - 2023-08-18 20:09:05 --> Language Class Initialized
ERROR - 2023-08-18 20:09:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:09:05 --> Config Class Initialized
INFO - 2023-08-18 20:09:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:05 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:05 --> URI Class Initialized
INFO - 2023-08-18 20:09:05 --> Router Class Initialized
INFO - 2023-08-18 20:09:05 --> Output Class Initialized
INFO - 2023-08-18 20:09:05 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:05 --> Input Class Initialized
INFO - 2023-08-18 20:09:05 --> Language Class Initialized
ERROR - 2023-08-18 20:09:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:09:05 --> Config Class Initialized
INFO - 2023-08-18 20:09:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:05 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:05 --> URI Class Initialized
INFO - 2023-08-18 20:09:05 --> Router Class Initialized
INFO - 2023-08-18 20:09:05 --> Output Class Initialized
INFO - 2023-08-18 20:09:05 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:05 --> Input Class Initialized
INFO - 2023-08-18 20:09:05 --> Language Class Initialized
ERROR - 2023-08-18 20:09:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:09:35 --> Config Class Initialized
INFO - 2023-08-18 20:09:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:35 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:35 --> URI Class Initialized
INFO - 2023-08-18 20:09:35 --> Router Class Initialized
INFO - 2023-08-18 20:09:35 --> Output Class Initialized
INFO - 2023-08-18 20:09:35 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:35 --> Input Class Initialized
INFO - 2023-08-18 20:09:35 --> Language Class Initialized
INFO - 2023-08-18 20:09:35 --> Loader Class Initialized
INFO - 2023-08-18 20:09:35 --> Helper loaded: url_helper
INFO - 2023-08-18 20:09:35 --> Helper loaded: file_helper
INFO - 2023-08-18 20:09:35 --> Database Driver Class Initialized
INFO - 2023-08-18 20:09:35 --> Email Class Initialized
DEBUG - 2023-08-18 20:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:09:35 --> Controller Class Initialized
INFO - 2023-08-18 20:09:35 --> Model "User_model" initialized
INFO - 2023-08-18 20:09:35 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-18 20:09:35 --> Final output sent to browser
DEBUG - 2023-08-18 20:09:35 --> Total execution time: 0.4489
INFO - 2023-08-18 20:09:37 --> Config Class Initialized
INFO - 2023-08-18 20:09:37 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:37 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:37 --> URI Class Initialized
INFO - 2023-08-18 20:09:37 --> Router Class Initialized
INFO - 2023-08-18 20:09:37 --> Output Class Initialized
INFO - 2023-08-18 20:09:37 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:37 --> Input Class Initialized
INFO - 2023-08-18 20:09:37 --> Language Class Initialized
ERROR - 2023-08-18 20:09:37 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-18 20:09:44 --> Config Class Initialized
INFO - 2023-08-18 20:09:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:44 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:44 --> URI Class Initialized
INFO - 2023-08-18 20:09:44 --> Router Class Initialized
INFO - 2023-08-18 20:09:44 --> Output Class Initialized
INFO - 2023-08-18 20:09:44 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:44 --> Input Class Initialized
INFO - 2023-08-18 20:09:44 --> Language Class Initialized
INFO - 2023-08-18 20:09:44 --> Loader Class Initialized
INFO - 2023-08-18 20:09:44 --> Helper loaded: url_helper
INFO - 2023-08-18 20:09:44 --> Helper loaded: file_helper
INFO - 2023-08-18 20:09:44 --> Database Driver Class Initialized
INFO - 2023-08-18 20:09:44 --> Email Class Initialized
DEBUG - 2023-08-18 20:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:09:44 --> Controller Class Initialized
INFO - 2023-08-18 20:09:44 --> Model "User_model" initialized
INFO - 2023-08-18 20:09:44 --> Config Class Initialized
INFO - 2023-08-18 20:09:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:44 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:44 --> URI Class Initialized
INFO - 2023-08-18 20:09:44 --> Router Class Initialized
INFO - 2023-08-18 20:09:44 --> Output Class Initialized
INFO - 2023-08-18 20:09:44 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:44 --> Input Class Initialized
INFO - 2023-08-18 20:09:44 --> Language Class Initialized
INFO - 2023-08-18 20:09:44 --> Loader Class Initialized
INFO - 2023-08-18 20:09:44 --> Helper loaded: url_helper
INFO - 2023-08-18 20:09:44 --> Helper loaded: file_helper
INFO - 2023-08-18 20:09:44 --> Database Driver Class Initialized
INFO - 2023-08-18 20:09:44 --> Email Class Initialized
DEBUG - 2023-08-18 20:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:09:44 --> Controller Class Initialized
INFO - 2023-08-18 20:09:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-18 20:09:44 --> Final output sent to browser
DEBUG - 2023-08-18 20:09:44 --> Total execution time: 0.0394
INFO - 2023-08-18 20:09:50 --> Config Class Initialized
INFO - 2023-08-18 20:09:50 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:50 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:50 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:50 --> URI Class Initialized
INFO - 2023-08-18 20:09:50 --> Router Class Initialized
INFO - 2023-08-18 20:09:50 --> Output Class Initialized
INFO - 2023-08-18 20:09:50 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:50 --> Input Class Initialized
INFO - 2023-08-18 20:09:50 --> Language Class Initialized
INFO - 2023-08-18 20:09:50 --> Loader Class Initialized
INFO - 2023-08-18 20:09:50 --> Helper loaded: url_helper
INFO - 2023-08-18 20:09:50 --> Helper loaded: file_helper
INFO - 2023-08-18 20:09:50 --> Database Driver Class Initialized
INFO - 2023-08-18 20:09:50 --> Email Class Initialized
DEBUG - 2023-08-18 20:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:09:50 --> Controller Class Initialized
INFO - 2023-08-18 20:09:50 --> Model "Blog_model" initialized
INFO - 2023-08-18 20:09:50 --> Helper loaded: form_helper
INFO - 2023-08-18 20:09:50 --> Form Validation Class Initialized
INFO - 2023-08-18 20:09:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-18 20:09:50 --> Final output sent to browser
DEBUG - 2023-08-18 20:09:50 --> Total execution time: 0.0548
INFO - 2023-08-18 20:09:50 --> Config Class Initialized
INFO - 2023-08-18 20:09:50 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:09:50 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:09:50 --> Utf8 Class Initialized
INFO - 2023-08-18 20:09:50 --> URI Class Initialized
INFO - 2023-08-18 20:09:50 --> Router Class Initialized
INFO - 2023-08-18 20:09:50 --> Output Class Initialized
INFO - 2023-08-18 20:09:50 --> Security Class Initialized
DEBUG - 2023-08-18 20:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:09:50 --> Input Class Initialized
INFO - 2023-08-18 20:09:50 --> Language Class Initialized
ERROR - 2023-08-18 20:09:50 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-18 20:10:08 --> Config Class Initialized
INFO - 2023-08-18 20:10:08 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:10:08 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:10:08 --> Utf8 Class Initialized
INFO - 2023-08-18 20:10:08 --> URI Class Initialized
INFO - 2023-08-18 20:10:08 --> Router Class Initialized
INFO - 2023-08-18 20:10:08 --> Output Class Initialized
INFO - 2023-08-18 20:10:08 --> Security Class Initialized
DEBUG - 2023-08-18 20:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:10:08 --> Input Class Initialized
INFO - 2023-08-18 20:10:08 --> Language Class Initialized
INFO - 2023-08-18 20:10:08 --> Loader Class Initialized
INFO - 2023-08-18 20:10:08 --> Helper loaded: url_helper
INFO - 2023-08-18 20:10:08 --> Helper loaded: file_helper
INFO - 2023-08-18 20:10:08 --> Database Driver Class Initialized
INFO - 2023-08-18 20:10:08 --> Email Class Initialized
DEBUG - 2023-08-18 20:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:10:08 --> Controller Class Initialized
INFO - 2023-08-18 20:10:08 --> Model "Blog_model" initialized
INFO - 2023-08-18 20:10:08 --> Helper loaded: form_helper
INFO - 2023-08-18 20:10:08 --> Form Validation Class Initialized
INFO - 2023-08-18 20:10:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-18 20:10:08 --> Final output sent to browser
DEBUG - 2023-08-18 20:10:08 --> Total execution time: 0.4690
INFO - 2023-08-18 20:10:11 --> Config Class Initialized
INFO - 2023-08-18 20:10:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:10:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:10:11 --> Utf8 Class Initialized
INFO - 2023-08-18 20:10:11 --> URI Class Initialized
INFO - 2023-08-18 20:10:11 --> Router Class Initialized
INFO - 2023-08-18 20:10:11 --> Output Class Initialized
INFO - 2023-08-18 20:10:11 --> Security Class Initialized
DEBUG - 2023-08-18 20:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:10:11 --> Input Class Initialized
INFO - 2023-08-18 20:10:11 --> Language Class Initialized
INFO - 2023-08-18 20:10:11 --> Loader Class Initialized
INFO - 2023-08-18 20:10:11 --> Helper loaded: url_helper
INFO - 2023-08-18 20:10:11 --> Helper loaded: file_helper
INFO - 2023-08-18 20:10:11 --> Database Driver Class Initialized
INFO - 2023-08-18 20:10:11 --> Email Class Initialized
DEBUG - 2023-08-18 20:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:10:11 --> Controller Class Initialized
INFO - 2023-08-18 20:10:11 --> Model "Blog_model" initialized
INFO - 2023-08-18 20:10:11 --> Helper loaded: form_helper
INFO - 2023-08-18 20:10:11 --> Form Validation Class Initialized
INFO - 2023-08-18 20:10:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-08-18 20:10:11 --> Final output sent to browser
DEBUG - 2023-08-18 20:10:11 --> Total execution time: 0.0537
INFO - 2023-08-18 20:10:11 --> Config Class Initialized
INFO - 2023-08-18 20:10:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:10:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:10:11 --> Utf8 Class Initialized
INFO - 2023-08-18 20:10:11 --> URI Class Initialized
INFO - 2023-08-18 20:10:11 --> Router Class Initialized
INFO - 2023-08-18 20:10:11 --> Output Class Initialized
INFO - 2023-08-18 20:10:11 --> Security Class Initialized
DEBUG - 2023-08-18 20:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:10:11 --> Input Class Initialized
INFO - 2023-08-18 20:10:11 --> Language Class Initialized
ERROR - 2023-08-18 20:10:11 --> 404 Page Not Found: admin/Blog/images
INFO - 2023-08-18 20:11:37 --> Config Class Initialized
INFO - 2023-08-18 20:11:37 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:11:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:11:37 --> Utf8 Class Initialized
INFO - 2023-08-18 20:11:37 --> URI Class Initialized
INFO - 2023-08-18 20:11:37 --> Router Class Initialized
INFO - 2023-08-18 20:11:37 --> Output Class Initialized
INFO - 2023-08-18 20:11:37 --> Security Class Initialized
DEBUG - 2023-08-18 20:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:11:38 --> Input Class Initialized
INFO - 2023-08-18 20:11:38 --> Language Class Initialized
INFO - 2023-08-18 20:11:38 --> Loader Class Initialized
INFO - 2023-08-18 20:11:38 --> Helper loaded: url_helper
INFO - 2023-08-18 20:11:38 --> Helper loaded: file_helper
INFO - 2023-08-18 20:11:38 --> Database Driver Class Initialized
INFO - 2023-08-18 20:11:38 --> Email Class Initialized
DEBUG - 2023-08-18 20:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:11:38 --> Controller Class Initialized
INFO - 2023-08-18 20:11:38 --> Model "Blog_model" initialized
INFO - 2023-08-18 20:11:38 --> Helper loaded: form_helper
INFO - 2023-08-18 20:11:38 --> Form Validation Class Initialized
INFO - 2023-08-18 20:11:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 20:11:38 --> Config Class Initialized
INFO - 2023-08-18 20:11:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:11:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:11:38 --> Utf8 Class Initialized
INFO - 2023-08-18 20:11:38 --> URI Class Initialized
INFO - 2023-08-18 20:11:38 --> Router Class Initialized
INFO - 2023-08-18 20:11:39 --> Output Class Initialized
INFO - 2023-08-18 20:11:39 --> Security Class Initialized
DEBUG - 2023-08-18 20:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:11:39 --> Input Class Initialized
INFO - 2023-08-18 20:11:39 --> Language Class Initialized
INFO - 2023-08-18 20:11:39 --> Loader Class Initialized
INFO - 2023-08-18 20:11:39 --> Helper loaded: url_helper
INFO - 2023-08-18 20:11:39 --> Helper loaded: file_helper
INFO - 2023-08-18 20:11:39 --> Database Driver Class Initialized
INFO - 2023-08-18 20:11:39 --> Email Class Initialized
DEBUG - 2023-08-18 20:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:11:39 --> Controller Class Initialized
INFO - 2023-08-18 20:11:39 --> Model "Blog_model" initialized
INFO - 2023-08-18 20:11:39 --> Helper loaded: form_helper
INFO - 2023-08-18 20:11:39 --> Form Validation Class Initialized
INFO - 2023-08-18 20:11:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-18 20:11:39 --> Final output sent to browser
DEBUG - 2023-08-18 20:11:39 --> Total execution time: 0.9592
INFO - 2023-08-18 20:12:01 --> Config Class Initialized
INFO - 2023-08-18 20:12:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:12:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:12:01 --> Utf8 Class Initialized
INFO - 2023-08-18 20:12:01 --> URI Class Initialized
INFO - 2023-08-18 20:12:01 --> Router Class Initialized
INFO - 2023-08-18 20:12:01 --> Output Class Initialized
INFO - 2023-08-18 20:12:01 --> Security Class Initialized
DEBUG - 2023-08-18 20:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:12:01 --> Input Class Initialized
INFO - 2023-08-18 20:12:01 --> Language Class Initialized
INFO - 2023-08-18 20:12:01 --> Loader Class Initialized
INFO - 2023-08-18 20:12:02 --> Helper loaded: url_helper
INFO - 2023-08-18 20:12:02 --> Helper loaded: file_helper
INFO - 2023-08-18 20:12:02 --> Database Driver Class Initialized
INFO - 2023-08-18 20:12:02 --> Email Class Initialized
DEBUG - 2023-08-18 20:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:12:02 --> Controller Class Initialized
INFO - 2023-08-18 20:12:02 --> Model "Blog_model" initialized
INFO - 2023-08-18 20:12:02 --> Helper loaded: form_helper
INFO - 2023-08-18 20:12:02 --> Form Validation Class Initialized
INFO - 2023-08-18 20:12:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-18 20:12:02 --> Final output sent to browser
DEBUG - 2023-08-18 20:12:02 --> Total execution time: 1.0563
INFO - 2023-08-18 20:12:04 --> Config Class Initialized
INFO - 2023-08-18 20:12:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:12:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:12:04 --> Utf8 Class Initialized
INFO - 2023-08-18 20:12:04 --> URI Class Initialized
INFO - 2023-08-18 20:12:04 --> Router Class Initialized
INFO - 2023-08-18 20:12:04 --> Output Class Initialized
INFO - 2023-08-18 20:12:05 --> Security Class Initialized
DEBUG - 2023-08-18 20:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:12:05 --> Input Class Initialized
INFO - 2023-08-18 20:12:05 --> Language Class Initialized
INFO - 2023-08-18 20:12:05 --> Loader Class Initialized
INFO - 2023-08-18 20:12:05 --> Helper loaded: url_helper
INFO - 2023-08-18 20:12:05 --> Helper loaded: file_helper
INFO - 2023-08-18 20:12:05 --> Database Driver Class Initialized
INFO - 2023-08-18 20:12:05 --> Email Class Initialized
DEBUG - 2023-08-18 20:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:12:05 --> Controller Class Initialized
INFO - 2023-08-18 20:12:05 --> Model "Blog_model" initialized
INFO - 2023-08-18 20:12:05 --> Helper loaded: form_helper
INFO - 2023-08-18 20:12:05 --> Form Validation Class Initialized
INFO - 2023-08-18 20:12:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-08-18 20:12:05 --> Final output sent to browser
DEBUG - 2023-08-18 20:12:05 --> Total execution time: 1.0388
INFO - 2023-08-18 20:12:34 --> Config Class Initialized
INFO - 2023-08-18 20:12:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:12:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:12:34 --> Utf8 Class Initialized
INFO - 2023-08-18 20:12:34 --> URI Class Initialized
INFO - 2023-08-18 20:12:34 --> Router Class Initialized
INFO - 2023-08-18 20:12:34 --> Output Class Initialized
INFO - 2023-08-18 20:12:34 --> Security Class Initialized
DEBUG - 2023-08-18 20:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:12:34 --> Input Class Initialized
INFO - 2023-08-18 20:12:34 --> Language Class Initialized
INFO - 2023-08-18 20:12:34 --> Loader Class Initialized
INFO - 2023-08-18 20:12:34 --> Helper loaded: url_helper
INFO - 2023-08-18 20:12:34 --> Helper loaded: file_helper
INFO - 2023-08-18 20:12:34 --> Database Driver Class Initialized
INFO - 2023-08-18 20:12:35 --> Email Class Initialized
DEBUG - 2023-08-18 20:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:12:35 --> Controller Class Initialized
INFO - 2023-08-18 20:12:35 --> Model "Blog_model" initialized
INFO - 2023-08-18 20:12:35 --> Helper loaded: form_helper
INFO - 2023-08-18 20:12:35 --> Form Validation Class Initialized
INFO - 2023-08-18 20:12:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 20:12:35 --> Config Class Initialized
INFO - 2023-08-18 20:12:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:12:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:12:35 --> Utf8 Class Initialized
INFO - 2023-08-18 20:12:35 --> URI Class Initialized
INFO - 2023-08-18 20:12:35 --> Router Class Initialized
INFO - 2023-08-18 20:12:36 --> Output Class Initialized
INFO - 2023-08-18 20:12:36 --> Security Class Initialized
DEBUG - 2023-08-18 20:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:12:36 --> Input Class Initialized
INFO - 2023-08-18 20:12:36 --> Language Class Initialized
INFO - 2023-08-18 20:12:36 --> Loader Class Initialized
INFO - 2023-08-18 20:12:36 --> Helper loaded: url_helper
INFO - 2023-08-18 20:12:36 --> Helper loaded: file_helper
INFO - 2023-08-18 20:12:36 --> Database Driver Class Initialized
INFO - 2023-08-18 20:12:36 --> Email Class Initialized
DEBUG - 2023-08-18 20:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:12:36 --> Controller Class Initialized
INFO - 2023-08-18 20:12:36 --> Model "Blog_model" initialized
INFO - 2023-08-18 20:12:36 --> Helper loaded: form_helper
INFO - 2023-08-18 20:12:36 --> Form Validation Class Initialized
INFO - 2023-08-18 20:12:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-18 20:12:36 --> Final output sent to browser
DEBUG - 2023-08-18 20:12:36 --> Total execution time: 1.1623
INFO - 2023-08-18 20:12:37 --> Config Class Initialized
INFO - 2023-08-18 20:12:37 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:12:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:12:37 --> Utf8 Class Initialized
INFO - 2023-08-18 20:12:37 --> URI Class Initialized
INFO - 2023-08-18 20:12:37 --> Router Class Initialized
INFO - 2023-08-18 20:12:37 --> Output Class Initialized
INFO - 2023-08-18 20:12:37 --> Security Class Initialized
DEBUG - 2023-08-18 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:12:37 --> Input Class Initialized
INFO - 2023-08-18 20:12:37 --> Language Class Initialized
INFO - 2023-08-18 20:12:37 --> Loader Class Initialized
INFO - 2023-08-18 20:12:37 --> Helper loaded: url_helper
INFO - 2023-08-18 20:12:37 --> Helper loaded: file_helper
INFO - 2023-08-18 20:12:37 --> Database Driver Class Initialized
INFO - 2023-08-18 20:12:37 --> Email Class Initialized
DEBUG - 2023-08-18 20:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:12:38 --> Controller Class Initialized
INFO - 2023-08-18 20:12:38 --> Model "Home_model" initialized
INFO - 2023-08-18 20:12:38 --> Helper loaded: form_helper
INFO - 2023-08-18 20:12:38 --> Form Validation Class Initialized
INFO - 2023-08-18 20:12:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:12:38 --> Final output sent to browser
DEBUG - 2023-08-18 20:12:38 --> Total execution time: 0.9576
INFO - 2023-08-18 20:12:39 --> Config Class Initialized
INFO - 2023-08-18 20:12:39 --> Config Class Initialized
INFO - 2023-08-18 20:12:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:12:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:12:39 --> Utf8 Class Initialized
INFO - 2023-08-18 20:12:39 --> URI Class Initialized
INFO - 2023-08-18 20:12:39 --> Hooks Class Initialized
INFO - 2023-08-18 20:12:39 --> Router Class Initialized
DEBUG - 2023-08-18 20:12:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:12:39 --> Utf8 Class Initialized
INFO - 2023-08-18 20:12:39 --> Output Class Initialized
INFO - 2023-08-18 20:12:39 --> URI Class Initialized
INFO - 2023-08-18 20:12:39 --> Router Class Initialized
INFO - 2023-08-18 20:12:39 --> Security Class Initialized
INFO - 2023-08-18 20:12:39 --> Output Class Initialized
DEBUG - 2023-08-18 20:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:12:39 --> Security Class Initialized
INFO - 2023-08-18 20:12:40 --> Input Class Initialized
INFO - 2023-08-18 20:12:40 --> Config Class Initialized
INFO - 2023-08-18 20:12:40 --> Language Class Initialized
ERROR - 2023-08-18 20:12:40 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 20:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:12:40 --> Hooks Class Initialized
INFO - 2023-08-18 20:12:40 --> Config Class Initialized
DEBUG - 2023-08-18 20:12:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:12:40 --> Utf8 Class Initialized
INFO - 2023-08-18 20:12:40 --> Hooks Class Initialized
INFO - 2023-08-18 20:12:40 --> Config Class Initialized
INFO - 2023-08-18 20:12:40 --> Hooks Class Initialized
INFO - 2023-08-18 20:12:40 --> Input Class Initialized
DEBUG - 2023-08-18 20:12:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:12:40 --> Language Class Initialized
ERROR - 2023-08-18 20:12:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:12:40 --> Utf8 Class Initialized
INFO - 2023-08-18 20:12:40 --> URI Class Initialized
DEBUG - 2023-08-18 20:12:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:12:40 --> Utf8 Class Initialized
INFO - 2023-08-18 20:12:40 --> Router Class Initialized
INFO - 2023-08-18 20:12:40 --> URI Class Initialized
INFO - 2023-08-18 20:12:40 --> Router Class Initialized
INFO - 2023-08-18 20:12:40 --> Output Class Initialized
INFO - 2023-08-18 20:12:40 --> Output Class Initialized
INFO - 2023-08-18 20:12:40 --> Security Class Initialized
INFO - 2023-08-18 20:12:40 --> URI Class Initialized
DEBUG - 2023-08-18 20:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:12:40 --> Input Class Initialized
INFO - 2023-08-18 20:12:40 --> Security Class Initialized
INFO - 2023-08-18 20:12:40 --> Language Class Initialized
ERROR - 2023-08-18 20:12:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:12:40 --> Router Class Initialized
DEBUG - 2023-08-18 20:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:12:40 --> Output Class Initialized
INFO - 2023-08-18 20:12:40 --> Input Class Initialized
INFO - 2023-08-18 20:12:40 --> Security Class Initialized
INFO - 2023-08-18 20:12:40 --> Language Class Initialized
DEBUG - 2023-08-18 20:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:12:40 --> Input Class Initialized
ERROR - 2023-08-18 20:12:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:12:40 --> Language Class Initialized
ERROR - 2023-08-18 20:12:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:12:40 --> Config Class Initialized
INFO - 2023-08-18 20:12:41 --> Config Class Initialized
INFO - 2023-08-18 20:12:41 --> Hooks Class Initialized
INFO - 2023-08-18 20:12:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:12:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 20:12:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:12:41 --> Utf8 Class Initialized
INFO - 2023-08-18 20:12:41 --> Utf8 Class Initialized
INFO - 2023-08-18 20:12:41 --> URI Class Initialized
INFO - 2023-08-18 20:12:41 --> URI Class Initialized
INFO - 2023-08-18 20:12:41 --> Router Class Initialized
INFO - 2023-08-18 20:12:41 --> Router Class Initialized
INFO - 2023-08-18 20:12:41 --> Output Class Initialized
INFO - 2023-08-18 20:12:41 --> Security Class Initialized
INFO - 2023-08-18 20:12:41 --> Output Class Initialized
DEBUG - 2023-08-18 20:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:12:41 --> Security Class Initialized
DEBUG - 2023-08-18 20:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:12:41 --> Input Class Initialized
INFO - 2023-08-18 20:12:41 --> Input Class Initialized
INFO - 2023-08-18 20:12:41 --> Language Class Initialized
ERROR - 2023-08-18 20:12:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:12:41 --> Language Class Initialized
ERROR - 2023-08-18 20:12:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:13:20 --> Config Class Initialized
INFO - 2023-08-18 20:13:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:13:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:13:20 --> Utf8 Class Initialized
INFO - 2023-08-18 20:13:20 --> URI Class Initialized
INFO - 2023-08-18 20:13:20 --> Router Class Initialized
INFO - 2023-08-18 20:13:20 --> Output Class Initialized
INFO - 2023-08-18 20:13:20 --> Security Class Initialized
DEBUG - 2023-08-18 20:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:13:20 --> Input Class Initialized
INFO - 2023-08-18 20:13:20 --> Language Class Initialized
INFO - 2023-08-18 20:13:20 --> Loader Class Initialized
INFO - 2023-08-18 20:13:20 --> Helper loaded: url_helper
INFO - 2023-08-18 20:13:20 --> Helper loaded: file_helper
INFO - 2023-08-18 20:13:20 --> Database Driver Class Initialized
INFO - 2023-08-18 20:13:20 --> Email Class Initialized
DEBUG - 2023-08-18 20:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:13:20 --> Controller Class Initialized
INFO - 2023-08-18 20:13:20 --> Model "Blog_model" initialized
INFO - 2023-08-18 20:13:21 --> Helper loaded: form_helper
INFO - 2023-08-18 20:13:21 --> Form Validation Class Initialized
INFO - 2023-08-18 20:13:21 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-18 20:13:21 --> Final output sent to browser
DEBUG - 2023-08-18 20:13:21 --> Total execution time: 0.9690
INFO - 2023-08-18 20:13:22 --> Config Class Initialized
INFO - 2023-08-18 20:13:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:13:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:13:22 --> Utf8 Class Initialized
INFO - 2023-08-18 20:13:22 --> URI Class Initialized
INFO - 2023-08-18 20:13:22 --> Router Class Initialized
INFO - 2023-08-18 20:13:22 --> Output Class Initialized
INFO - 2023-08-18 20:13:22 --> Security Class Initialized
DEBUG - 2023-08-18 20:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:13:22 --> Input Class Initialized
INFO - 2023-08-18 20:13:22 --> Language Class Initialized
INFO - 2023-08-18 20:13:22 --> Loader Class Initialized
INFO - 2023-08-18 20:13:22 --> Helper loaded: url_helper
INFO - 2023-08-18 20:13:22 --> Helper loaded: file_helper
INFO - 2023-08-18 20:13:22 --> Database Driver Class Initialized
INFO - 2023-08-18 20:13:22 --> Email Class Initialized
DEBUG - 2023-08-18 20:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:13:23 --> Controller Class Initialized
INFO - 2023-08-18 20:13:23 --> Model "Blog_model" initialized
INFO - 2023-08-18 20:13:23 --> Helper loaded: form_helper
INFO - 2023-08-18 20:13:23 --> Form Validation Class Initialized
ERROR - 2023-08-18 20:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-08-18 20:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-08-18 20:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-08-18 20:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-08-18 20:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-08-18 20:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-08-18 20:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-08-18 20:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-08-18 20:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 106
INFO - 2023-08-18 20:13:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-18 20:13:24 --> Final output sent to browser
DEBUG - 2023-08-18 20:13:24 --> Total execution time: 1.8638
INFO - 2023-08-18 20:13:28 --> Config Class Initialized
INFO - 2023-08-18 20:13:28 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:13:28 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:13:28 --> Utf8 Class Initialized
INFO - 2023-08-18 20:13:28 --> URI Class Initialized
INFO - 2023-08-18 20:13:28 --> Router Class Initialized
INFO - 2023-08-18 20:13:28 --> Output Class Initialized
INFO - 2023-08-18 20:13:28 --> Security Class Initialized
DEBUG - 2023-08-18 20:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:13:28 --> Input Class Initialized
INFO - 2023-08-18 20:13:29 --> Language Class Initialized
INFO - 2023-08-18 20:13:29 --> Loader Class Initialized
INFO - 2023-08-18 20:13:29 --> Helper loaded: url_helper
INFO - 2023-08-18 20:13:29 --> Helper loaded: file_helper
INFO - 2023-08-18 20:13:29 --> Database Driver Class Initialized
INFO - 2023-08-18 20:13:29 --> Email Class Initialized
DEBUG - 2023-08-18 20:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:13:29 --> Controller Class Initialized
INFO - 2023-08-18 20:13:29 --> Model "Blog_model" initialized
INFO - 2023-08-18 20:13:29 --> Helper loaded: form_helper
INFO - 2023-08-18 20:13:29 --> Form Validation Class Initialized
INFO - 2023-08-18 20:13:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-18 20:13:29 --> Config Class Initialized
INFO - 2023-08-18 20:13:29 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:13:29 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:13:29 --> Utf8 Class Initialized
INFO - 2023-08-18 20:13:29 --> URI Class Initialized
INFO - 2023-08-18 20:13:29 --> Router Class Initialized
INFO - 2023-08-18 20:13:30 --> Output Class Initialized
INFO - 2023-08-18 20:13:30 --> Security Class Initialized
DEBUG - 2023-08-18 20:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:13:30 --> Input Class Initialized
INFO - 2023-08-18 20:13:30 --> Language Class Initialized
INFO - 2023-08-18 20:13:30 --> Loader Class Initialized
INFO - 2023-08-18 20:13:30 --> Helper loaded: url_helper
INFO - 2023-08-18 20:13:30 --> Helper loaded: file_helper
INFO - 2023-08-18 20:13:30 --> Database Driver Class Initialized
INFO - 2023-08-18 20:13:30 --> Email Class Initialized
DEBUG - 2023-08-18 20:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:13:30 --> Controller Class Initialized
INFO - 2023-08-18 20:13:30 --> Model "Blog_model" initialized
INFO - 2023-08-18 20:13:30 --> Helper loaded: form_helper
INFO - 2023-08-18 20:13:30 --> Form Validation Class Initialized
INFO - 2023-08-18 20:13:30 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-18 20:13:30 --> Final output sent to browser
DEBUG - 2023-08-18 20:13:30 --> Total execution time: 0.9501
INFO - 2023-08-18 20:13:34 --> Config Class Initialized
INFO - 2023-08-18 20:13:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:13:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:13:34 --> Utf8 Class Initialized
INFO - 2023-08-18 20:13:34 --> URI Class Initialized
INFO - 2023-08-18 20:13:34 --> Router Class Initialized
INFO - 2023-08-18 20:13:34 --> Output Class Initialized
INFO - 2023-08-18 20:13:34 --> Security Class Initialized
DEBUG - 2023-08-18 20:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:13:34 --> Input Class Initialized
INFO - 2023-08-18 20:13:34 --> Language Class Initialized
INFO - 2023-08-18 20:13:34 --> Loader Class Initialized
INFO - 2023-08-18 20:13:34 --> Helper loaded: url_helper
INFO - 2023-08-18 20:13:34 --> Helper loaded: file_helper
INFO - 2023-08-18 20:13:34 --> Database Driver Class Initialized
INFO - 2023-08-18 20:13:35 --> Email Class Initialized
DEBUG - 2023-08-18 20:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:13:35 --> Controller Class Initialized
INFO - 2023-08-18 20:13:35 --> Model "Home_model" initialized
INFO - 2023-08-18 20:13:35 --> Helper loaded: form_helper
INFO - 2023-08-18 20:13:35 --> Form Validation Class Initialized
INFO - 2023-08-18 20:13:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:13:35 --> Final output sent to browser
DEBUG - 2023-08-18 20:13:35 --> Total execution time: 1.1314
INFO - 2023-08-18 20:13:36 --> Config Class Initialized
INFO - 2023-08-18 20:13:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:13:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:13:36 --> Utf8 Class Initialized
INFO - 2023-08-18 20:13:36 --> URI Class Initialized
INFO - 2023-08-18 20:13:36 --> Router Class Initialized
INFO - 2023-08-18 20:13:36 --> Output Class Initialized
INFO - 2023-08-18 20:13:36 --> Security Class Initialized
DEBUG - 2023-08-18 20:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:13:36 --> Input Class Initialized
INFO - 2023-08-18 20:13:36 --> Language Class Initialized
ERROR - 2023-08-18 20:13:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:13:36 --> Config Class Initialized
INFO - 2023-08-18 20:13:36 --> Config Class Initialized
INFO - 2023-08-18 20:13:36 --> Hooks Class Initialized
INFO - 2023-08-18 20:13:36 --> Config Class Initialized
DEBUG - 2023-08-18 20:13:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:13:36 --> Config Class Initialized
INFO - 2023-08-18 20:13:36 --> Hooks Class Initialized
INFO - 2023-08-18 20:13:36 --> Hooks Class Initialized
INFO - 2023-08-18 20:13:36 --> Config Class Initialized
DEBUG - 2023-08-18 20:13:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:13:36 --> Hooks Class Initialized
INFO - 2023-08-18 20:13:36 --> Utf8 Class Initialized
DEBUG - 2023-08-18 20:13:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:13:37 --> Hooks Class Initialized
INFO - 2023-08-18 20:13:37 --> URI Class Initialized
INFO - 2023-08-18 20:13:37 --> Router Class Initialized
INFO - 2023-08-18 20:13:37 --> Output Class Initialized
INFO - 2023-08-18 20:13:37 --> Security Class Initialized
DEBUG - 2023-08-18 20:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:13:37 --> Input Class Initialized
INFO - 2023-08-18 20:13:37 --> Language Class Initialized
ERROR - 2023-08-18 20:13:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:13:37 --> Utf8 Class Initialized
DEBUG - 2023-08-18 20:13:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:13:37 --> Config Class Initialized
INFO - 2023-08-18 20:13:37 --> Utf8 Class Initialized
DEBUG - 2023-08-18 20:13:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:13:37 --> Utf8 Class Initialized
INFO - 2023-08-18 20:13:37 --> Hooks Class Initialized
INFO - 2023-08-18 20:13:37 --> URI Class Initialized
INFO - 2023-08-18 20:13:37 --> URI Class Initialized
INFO - 2023-08-18 20:13:37 --> Router Class Initialized
INFO - 2023-08-18 20:13:37 --> Utf8 Class Initialized
INFO - 2023-08-18 20:13:37 --> URI Class Initialized
INFO - 2023-08-18 20:13:37 --> Router Class Initialized
DEBUG - 2023-08-18 20:13:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:13:37 --> URI Class Initialized
INFO - 2023-08-18 20:13:37 --> Output Class Initialized
INFO - 2023-08-18 20:13:37 --> Output Class Initialized
INFO - 2023-08-18 20:13:37 --> Router Class Initialized
INFO - 2023-08-18 20:13:37 --> Utf8 Class Initialized
INFO - 2023-08-18 20:13:37 --> Security Class Initialized
INFO - 2023-08-18 20:13:37 --> Router Class Initialized
INFO - 2023-08-18 20:13:37 --> Security Class Initialized
INFO - 2023-08-18 20:13:37 --> Output Class Initialized
INFO - 2023-08-18 20:13:37 --> URI Class Initialized
DEBUG - 2023-08-18 20:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:13:37 --> Router Class Initialized
INFO - 2023-08-18 20:13:37 --> Output Class Initialized
INFO - 2023-08-18 20:13:37 --> Security Class Initialized
INFO - 2023-08-18 20:13:37 --> Security Class Initialized
DEBUG - 2023-08-18 20:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 20:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:13:37 --> Input Class Initialized
INFO - 2023-08-18 20:13:37 --> Input Class Initialized
INFO - 2023-08-18 20:13:37 --> Output Class Initialized
DEBUG - 2023-08-18 20:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:13:37 --> Language Class Initialized
INFO - 2023-08-18 20:13:37 --> Input Class Initialized
ERROR - 2023-08-18 20:13:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:13:37 --> Language Class Initialized
INFO - 2023-08-18 20:13:37 --> Language Class Initialized
INFO - 2023-08-18 20:13:37 --> Security Class Initialized
INFO - 2023-08-18 20:13:37 --> Input Class Initialized
INFO - 2023-08-18 20:13:37 --> Language Class Initialized
DEBUG - 2023-08-18 20:13:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-18 20:13:37 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 20:13:37 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 20:13:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:13:37 --> Input Class Initialized
INFO - 2023-08-18 20:13:37 --> Language Class Initialized
ERROR - 2023-08-18 20:13:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:15:13 --> Config Class Initialized
INFO - 2023-08-18 20:15:13 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:15:13 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:15:13 --> Utf8 Class Initialized
INFO - 2023-08-18 20:15:13 --> URI Class Initialized
INFO - 2023-08-18 20:15:13 --> Router Class Initialized
INFO - 2023-08-18 20:15:13 --> Output Class Initialized
INFO - 2023-08-18 20:15:13 --> Security Class Initialized
DEBUG - 2023-08-18 20:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:15:13 --> Input Class Initialized
INFO - 2023-08-18 20:15:13 --> Language Class Initialized
INFO - 2023-08-18 20:15:13 --> Loader Class Initialized
INFO - 2023-08-18 20:15:13 --> Helper loaded: url_helper
INFO - 2023-08-18 20:15:14 --> Helper loaded: file_helper
INFO - 2023-08-18 20:15:14 --> Database Driver Class Initialized
INFO - 2023-08-18 20:15:14 --> Email Class Initialized
DEBUG - 2023-08-18 20:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:15:14 --> Controller Class Initialized
INFO - 2023-08-18 20:15:14 --> Model "Home_model" initialized
INFO - 2023-08-18 20:15:14 --> Helper loaded: form_helper
INFO - 2023-08-18 20:15:14 --> Form Validation Class Initialized
INFO - 2023-08-18 20:15:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:15:14 --> Final output sent to browser
DEBUG - 2023-08-18 20:15:14 --> Total execution time: 0.5706
INFO - 2023-08-18 20:15:15 --> Config Class Initialized
INFO - 2023-08-18 20:15:15 --> Hooks Class Initialized
INFO - 2023-08-18 20:15:15 --> Config Class Initialized
INFO - 2023-08-18 20:15:15 --> Config Class Initialized
INFO - 2023-08-18 20:15:15 --> Hooks Class Initialized
INFO - 2023-08-18 20:15:15 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:15:15 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:15:15 --> Utf8 Class Initialized
DEBUG - 2023-08-18 20:15:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 20:15:15 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:15:15 --> URI Class Initialized
INFO - 2023-08-18 20:15:15 --> Utf8 Class Initialized
INFO - 2023-08-18 20:15:15 --> URI Class Initialized
INFO - 2023-08-18 20:15:15 --> Router Class Initialized
INFO - 2023-08-18 20:15:15 --> Output Class Initialized
INFO - 2023-08-18 20:15:15 --> Security Class Initialized
INFO - 2023-08-18 20:15:15 --> Utf8 Class Initialized
INFO - 2023-08-18 20:15:15 --> URI Class Initialized
DEBUG - 2023-08-18 20:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:15:15 --> Router Class Initialized
INFO - 2023-08-18 20:15:15 --> Output Class Initialized
INFO - 2023-08-18 20:15:15 --> Router Class Initialized
INFO - 2023-08-18 20:15:15 --> Input Class Initialized
INFO - 2023-08-18 20:15:15 --> Output Class Initialized
INFO - 2023-08-18 20:15:15 --> Language Class Initialized
INFO - 2023-08-18 20:15:15 --> Security Class Initialized
DEBUG - 2023-08-18 20:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:15:15 --> Security Class Initialized
ERROR - 2023-08-18 20:15:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:15:15 --> Input Class Initialized
DEBUG - 2023-08-18 20:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:15:15 --> Language Class Initialized
INFO - 2023-08-18 20:15:15 --> Input Class Initialized
INFO - 2023-08-18 20:15:15 --> Language Class Initialized
ERROR - 2023-08-18 20:15:15 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 20:15:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:15:15 --> Config Class Initialized
INFO - 2023-08-18 20:15:15 --> Config Class Initialized
INFO - 2023-08-18 20:15:15 --> Config Class Initialized
INFO - 2023-08-18 20:15:15 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:15:16 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:15:16 --> Config Class Initialized
INFO - 2023-08-18 20:15:16 --> Hooks Class Initialized
INFO - 2023-08-18 20:15:16 --> Hooks Class Initialized
INFO - 2023-08-18 20:15:16 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:15:16 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:15:16 --> Utf8 Class Initialized
DEBUG - 2023-08-18 20:15:16 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:15:16 --> Utf8 Class Initialized
DEBUG - 2023-08-18 20:15:16 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:15:16 --> URI Class Initialized
INFO - 2023-08-18 20:15:16 --> Router Class Initialized
INFO - 2023-08-18 20:15:16 --> Utf8 Class Initialized
INFO - 2023-08-18 20:15:16 --> Utf8 Class Initialized
INFO - 2023-08-18 20:15:16 --> URI Class Initialized
INFO - 2023-08-18 20:15:16 --> Router Class Initialized
INFO - 2023-08-18 20:15:16 --> Output Class Initialized
INFO - 2023-08-18 20:15:16 --> Security Class Initialized
DEBUG - 2023-08-18 20:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:15:16 --> Input Class Initialized
INFO - 2023-08-18 20:15:16 --> Language Class Initialized
ERROR - 2023-08-18 20:15:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:15:16 --> Output Class Initialized
INFO - 2023-08-18 20:15:16 --> URI Class Initialized
INFO - 2023-08-18 20:15:16 --> Router Class Initialized
INFO - 2023-08-18 20:15:16 --> Output Class Initialized
INFO - 2023-08-18 20:15:16 --> Security Class Initialized
DEBUG - 2023-08-18 20:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:15:16 --> Input Class Initialized
INFO - 2023-08-18 20:15:16 --> Language Class Initialized
ERROR - 2023-08-18 20:15:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:15:16 --> URI Class Initialized
INFO - 2023-08-18 20:15:16 --> Router Class Initialized
INFO - 2023-08-18 20:15:16 --> Output Class Initialized
INFO - 2023-08-18 20:15:16 --> Security Class Initialized
DEBUG - 2023-08-18 20:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:15:16 --> Input Class Initialized
INFO - 2023-08-18 20:15:16 --> Language Class Initialized
ERROR - 2023-08-18 20:15:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:15:16 --> Security Class Initialized
DEBUG - 2023-08-18 20:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:15:16 --> Input Class Initialized
INFO - 2023-08-18 20:15:16 --> Language Class Initialized
ERROR - 2023-08-18 20:15:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:16:09 --> Config Class Initialized
INFO - 2023-08-18 20:16:09 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:16:09 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:16:09 --> Utf8 Class Initialized
INFO - 2023-08-18 20:16:09 --> URI Class Initialized
INFO - 2023-08-18 20:16:09 --> Router Class Initialized
INFO - 2023-08-18 20:16:09 --> Output Class Initialized
INFO - 2023-08-18 20:16:09 --> Security Class Initialized
DEBUG - 2023-08-18 20:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:16:09 --> Input Class Initialized
INFO - 2023-08-18 20:16:09 --> Language Class Initialized
INFO - 2023-08-18 20:16:09 --> Loader Class Initialized
INFO - 2023-08-18 20:16:09 --> Helper loaded: url_helper
INFO - 2023-08-18 20:16:09 --> Helper loaded: file_helper
INFO - 2023-08-18 20:16:09 --> Database Driver Class Initialized
INFO - 2023-08-18 20:16:09 --> Email Class Initialized
DEBUG - 2023-08-18 20:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:16:09 --> Controller Class Initialized
INFO - 2023-08-18 20:16:09 --> Model "Home_model" initialized
INFO - 2023-08-18 20:16:09 --> Helper loaded: form_helper
INFO - 2023-08-18 20:16:09 --> Form Validation Class Initialized
INFO - 2023-08-18 20:16:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:16:09 --> Final output sent to browser
DEBUG - 2023-08-18 20:16:09 --> Total execution time: 0.4328
INFO - 2023-08-18 20:16:10 --> Config Class Initialized
INFO - 2023-08-18 20:16:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:16:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:16:10 --> Utf8 Class Initialized
INFO - 2023-08-18 20:16:10 --> URI Class Initialized
INFO - 2023-08-18 20:16:10 --> Router Class Initialized
INFO - 2023-08-18 20:16:10 --> Output Class Initialized
INFO - 2023-08-18 20:16:10 --> Security Class Initialized
DEBUG - 2023-08-18 20:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:16:10 --> Input Class Initialized
INFO - 2023-08-18 20:16:10 --> Language Class Initialized
ERROR - 2023-08-18 20:16:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:16:10 --> Config Class Initialized
INFO - 2023-08-18 20:16:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:16:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:16:10 --> Utf8 Class Initialized
INFO - 2023-08-18 20:16:10 --> URI Class Initialized
INFO - 2023-08-18 20:16:10 --> Router Class Initialized
INFO - 2023-08-18 20:16:10 --> Output Class Initialized
INFO - 2023-08-18 20:16:10 --> Security Class Initialized
DEBUG - 2023-08-18 20:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:16:10 --> Input Class Initialized
INFO - 2023-08-18 20:16:10 --> Language Class Initialized
ERROR - 2023-08-18 20:16:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:16:10 --> Config Class Initialized
INFO - 2023-08-18 20:16:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:16:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:16:11 --> Config Class Initialized
INFO - 2023-08-18 20:16:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:16:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:16:11 --> Utf8 Class Initialized
INFO - 2023-08-18 20:16:11 --> URI Class Initialized
INFO - 2023-08-18 20:16:11 --> Router Class Initialized
INFO - 2023-08-18 20:16:11 --> Output Class Initialized
INFO - 2023-08-18 20:16:11 --> Security Class Initialized
DEBUG - 2023-08-18 20:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:16:11 --> Input Class Initialized
INFO - 2023-08-18 20:16:11 --> Language Class Initialized
ERROR - 2023-08-18 20:16:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:16:11 --> Utf8 Class Initialized
INFO - 2023-08-18 20:16:11 --> URI Class Initialized
INFO - 2023-08-18 20:16:11 --> Router Class Initialized
INFO - 2023-08-18 20:16:11 --> Output Class Initialized
INFO - 2023-08-18 20:16:11 --> Security Class Initialized
DEBUG - 2023-08-18 20:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:16:11 --> Input Class Initialized
INFO - 2023-08-18 20:16:11 --> Language Class Initialized
ERROR - 2023-08-18 20:16:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:16:11 --> Config Class Initialized
INFO - 2023-08-18 20:16:11 --> Hooks Class Initialized
INFO - 2023-08-18 20:16:11 --> Config Class Initialized
DEBUG - 2023-08-18 20:16:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:16:11 --> Utf8 Class Initialized
INFO - 2023-08-18 20:16:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:16:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:16:11 --> URI Class Initialized
INFO - 2023-08-18 20:16:11 --> Router Class Initialized
INFO - 2023-08-18 20:16:11 --> Utf8 Class Initialized
INFO - 2023-08-18 20:16:11 --> Output Class Initialized
INFO - 2023-08-18 20:16:11 --> URI Class Initialized
INFO - 2023-08-18 20:16:11 --> Security Class Initialized
INFO - 2023-08-18 20:16:11 --> Router Class Initialized
DEBUG - 2023-08-18 20:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:16:11 --> Input Class Initialized
INFO - 2023-08-18 20:16:11 --> Output Class Initialized
INFO - 2023-08-18 20:16:11 --> Language Class Initialized
INFO - 2023-08-18 20:16:11 --> Security Class Initialized
ERROR - 2023-08-18 20:16:11 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 20:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:16:11 --> Input Class Initialized
INFO - 2023-08-18 20:16:11 --> Language Class Initialized
ERROR - 2023-08-18 20:16:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:16:25 --> Config Class Initialized
INFO - 2023-08-18 20:16:25 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:16:25 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:16:25 --> Utf8 Class Initialized
INFO - 2023-08-18 20:16:25 --> URI Class Initialized
INFO - 2023-08-18 20:16:25 --> Router Class Initialized
INFO - 2023-08-18 20:16:25 --> Output Class Initialized
INFO - 2023-08-18 20:16:25 --> Security Class Initialized
DEBUG - 2023-08-18 20:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:16:25 --> Input Class Initialized
INFO - 2023-08-18 20:16:25 --> Language Class Initialized
INFO - 2023-08-18 20:16:25 --> Loader Class Initialized
INFO - 2023-08-18 20:16:25 --> Helper loaded: url_helper
INFO - 2023-08-18 20:16:25 --> Helper loaded: file_helper
INFO - 2023-08-18 20:16:25 --> Database Driver Class Initialized
INFO - 2023-08-18 20:16:25 --> Email Class Initialized
DEBUG - 2023-08-18 20:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:16:25 --> Controller Class Initialized
INFO - 2023-08-18 20:16:25 --> Model "Home_model" initialized
INFO - 2023-08-18 20:16:25 --> Helper loaded: form_helper
INFO - 2023-08-18 20:16:25 --> Form Validation Class Initialized
INFO - 2023-08-18 20:16:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:16:25 --> Final output sent to browser
DEBUG - 2023-08-18 20:16:25 --> Total execution time: 0.1835
INFO - 2023-08-18 20:16:26 --> Config Class Initialized
INFO - 2023-08-18 20:16:26 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:16:26 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:16:26 --> Config Class Initialized
INFO - 2023-08-18 20:16:26 --> Config Class Initialized
INFO - 2023-08-18 20:16:26 --> Utf8 Class Initialized
INFO - 2023-08-18 20:16:26 --> URI Class Initialized
INFO - 2023-08-18 20:16:26 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:16:26 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:16:26 --> Utf8 Class Initialized
INFO - 2023-08-18 20:16:26 --> Hooks Class Initialized
INFO - 2023-08-18 20:16:26 --> Router Class Initialized
DEBUG - 2023-08-18 20:16:26 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:16:26 --> URI Class Initialized
INFO - 2023-08-18 20:16:26 --> Output Class Initialized
INFO - 2023-08-18 20:16:26 --> Router Class Initialized
INFO - 2023-08-18 20:16:26 --> Security Class Initialized
DEBUG - 2023-08-18 20:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:16:26 --> Config Class Initialized
INFO - 2023-08-18 20:16:26 --> Output Class Initialized
INFO - 2023-08-18 20:16:26 --> Security Class Initialized
DEBUG - 2023-08-18 20:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:16:26 --> Input Class Initialized
INFO - 2023-08-18 20:16:26 --> Language Class Initialized
ERROR - 2023-08-18 20:16:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:16:26 --> Hooks Class Initialized
INFO - 2023-08-18 20:16:26 --> Input Class Initialized
INFO - 2023-08-18 20:16:26 --> Utf8 Class Initialized
INFO - 2023-08-18 20:16:26 --> Language Class Initialized
DEBUG - 2023-08-18 20:16:26 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:16:26 --> Config Class Initialized
INFO - 2023-08-18 20:16:26 --> Hooks Class Initialized
INFO - 2023-08-18 20:16:26 --> URI Class Initialized
ERROR - 2023-08-18 20:16:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:16:26 --> Utf8 Class Initialized
INFO - 2023-08-18 20:16:26 --> Router Class Initialized
DEBUG - 2023-08-18 20:16:26 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:16:26 --> Output Class Initialized
INFO - 2023-08-18 20:16:26 --> Utf8 Class Initialized
INFO - 2023-08-18 20:16:26 --> Security Class Initialized
INFO - 2023-08-18 20:16:26 --> URI Class Initialized
DEBUG - 2023-08-18 20:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:16:26 --> URI Class Initialized
INFO - 2023-08-18 20:16:26 --> Router Class Initialized
INFO - 2023-08-18 20:16:26 --> Router Class Initialized
INFO - 2023-08-18 20:16:26 --> Output Class Initialized
INFO - 2023-08-18 20:16:26 --> Security Class Initialized
INFO - 2023-08-18 20:16:27 --> Input Class Initialized
DEBUG - 2023-08-18 20:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:16:27 --> Language Class Initialized
INFO - 2023-08-18 20:16:27 --> Output Class Initialized
ERROR - 2023-08-18 20:16:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:16:27 --> Input Class Initialized
INFO - 2023-08-18 20:16:27 --> Security Class Initialized
INFO - 2023-08-18 20:16:27 --> Language Class Initialized
ERROR - 2023-08-18 20:16:27 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 20:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:16:27 --> Input Class Initialized
INFO - 2023-08-18 20:16:27 --> Language Class Initialized
ERROR - 2023-08-18 20:16:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:17:05 --> Config Class Initialized
INFO - 2023-08-18 20:17:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:17:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:17:05 --> Utf8 Class Initialized
INFO - 2023-08-18 20:17:05 --> URI Class Initialized
INFO - 2023-08-18 20:17:05 --> Router Class Initialized
INFO - 2023-08-18 20:17:05 --> Output Class Initialized
INFO - 2023-08-18 20:17:05 --> Security Class Initialized
DEBUG - 2023-08-18 20:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:17:05 --> Input Class Initialized
INFO - 2023-08-18 20:17:05 --> Language Class Initialized
INFO - 2023-08-18 20:17:05 --> Loader Class Initialized
INFO - 2023-08-18 20:17:05 --> Helper loaded: url_helper
INFO - 2023-08-18 20:17:05 --> Helper loaded: file_helper
INFO - 2023-08-18 20:17:05 --> Database Driver Class Initialized
INFO - 2023-08-18 20:17:05 --> Email Class Initialized
DEBUG - 2023-08-18 20:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:17:05 --> Controller Class Initialized
INFO - 2023-08-18 20:17:05 --> Model "Home_model" initialized
INFO - 2023-08-18 20:17:05 --> Helper loaded: form_helper
INFO - 2023-08-18 20:17:06 --> Form Validation Class Initialized
INFO - 2023-08-18 20:17:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:17:06 --> Final output sent to browser
DEBUG - 2023-08-18 20:17:06 --> Total execution time: 0.4668
INFO - 2023-08-18 20:17:06 --> Config Class Initialized
INFO - 2023-08-18 20:17:06 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:17:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:17:07 --> Config Class Initialized
INFO - 2023-08-18 20:17:07 --> Hooks Class Initialized
INFO - 2023-08-18 20:17:07 --> Utf8 Class Initialized
DEBUG - 2023-08-18 20:17:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:17:07 --> Config Class Initialized
INFO - 2023-08-18 20:17:07 --> URI Class Initialized
INFO - 2023-08-18 20:17:07 --> Hooks Class Initialized
INFO - 2023-08-18 20:17:07 --> Utf8 Class Initialized
INFO - 2023-08-18 20:17:07 --> Config Class Initialized
INFO - 2023-08-18 20:17:07 --> Router Class Initialized
DEBUG - 2023-08-18 20:17:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:17:07 --> Output Class Initialized
INFO - 2023-08-18 20:17:07 --> Hooks Class Initialized
INFO - 2023-08-18 20:17:07 --> URI Class Initialized
DEBUG - 2023-08-18 20:17:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:17:07 --> Router Class Initialized
INFO - 2023-08-18 20:17:07 --> Utf8 Class Initialized
INFO - 2023-08-18 20:17:07 --> Security Class Initialized
INFO - 2023-08-18 20:17:07 --> Utf8 Class Initialized
DEBUG - 2023-08-18 20:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:17:07 --> Output Class Initialized
INFO - 2023-08-18 20:17:07 --> URI Class Initialized
INFO - 2023-08-18 20:17:07 --> Config Class Initialized
INFO - 2023-08-18 20:17:07 --> URI Class Initialized
INFO - 2023-08-18 20:17:07 --> Security Class Initialized
INFO - 2023-08-18 20:17:07 --> Input Class Initialized
INFO - 2023-08-18 20:17:07 --> Language Class Initialized
INFO - 2023-08-18 20:17:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:17:07 --> Router Class Initialized
INFO - 2023-08-18 20:17:07 --> Router Class Initialized
ERROR - 2023-08-18 20:17:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:17:07 --> Input Class Initialized
DEBUG - 2023-08-18 20:17:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:17:07 --> Output Class Initialized
INFO - 2023-08-18 20:17:07 --> Utf8 Class Initialized
INFO - 2023-08-18 20:17:07 --> Language Class Initialized
INFO - 2023-08-18 20:17:07 --> Output Class Initialized
INFO - 2023-08-18 20:17:07 --> Security Class Initialized
INFO - 2023-08-18 20:17:07 --> Security Class Initialized
INFO - 2023-08-18 20:17:07 --> URI Class Initialized
ERROR - 2023-08-18 20:17:07 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 20:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:17:07 --> Input Class Initialized
DEBUG - 2023-08-18 20:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:17:07 --> Input Class Initialized
INFO - 2023-08-18 20:17:07 --> Router Class Initialized
INFO - 2023-08-18 20:17:07 --> Output Class Initialized
INFO - 2023-08-18 20:17:07 --> Language Class Initialized
INFO - 2023-08-18 20:17:07 --> Language Class Initialized
ERROR - 2023-08-18 20:17:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:17:07 --> Security Class Initialized
ERROR - 2023-08-18 20:17:07 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 20:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:17:07 --> Input Class Initialized
INFO - 2023-08-18 20:17:08 --> Language Class Initialized
ERROR - 2023-08-18 20:17:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:18:01 --> Config Class Initialized
INFO - 2023-08-18 20:18:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:18:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:18:01 --> Utf8 Class Initialized
INFO - 2023-08-18 20:18:01 --> URI Class Initialized
INFO - 2023-08-18 20:18:01 --> Router Class Initialized
INFO - 2023-08-18 20:18:02 --> Output Class Initialized
INFO - 2023-08-18 20:18:02 --> Security Class Initialized
DEBUG - 2023-08-18 20:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:18:02 --> Input Class Initialized
INFO - 2023-08-18 20:18:02 --> Language Class Initialized
INFO - 2023-08-18 20:18:02 --> Loader Class Initialized
INFO - 2023-08-18 20:18:02 --> Helper loaded: url_helper
INFO - 2023-08-18 20:18:02 --> Helper loaded: file_helper
INFO - 2023-08-18 20:18:02 --> Database Driver Class Initialized
INFO - 2023-08-18 20:18:02 --> Email Class Initialized
DEBUG - 2023-08-18 20:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:18:02 --> Controller Class Initialized
INFO - 2023-08-18 20:18:02 --> Model "Home_model" initialized
INFO - 2023-08-18 20:18:02 --> Helper loaded: form_helper
INFO - 2023-08-18 20:18:02 --> Form Validation Class Initialized
INFO - 2023-08-18 20:18:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:18:02 --> Final output sent to browser
DEBUG - 2023-08-18 20:18:02 --> Total execution time: 0.7373
INFO - 2023-08-18 20:18:02 --> Config Class Initialized
INFO - 2023-08-18 20:18:02 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:18:02 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:18:02 --> Utf8 Class Initialized
INFO - 2023-08-18 20:18:02 --> URI Class Initialized
INFO - 2023-08-18 20:18:02 --> Router Class Initialized
INFO - 2023-08-18 20:18:02 --> Output Class Initialized
INFO - 2023-08-18 20:18:02 --> Security Class Initialized
DEBUG - 2023-08-18 20:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:18:02 --> Input Class Initialized
INFO - 2023-08-18 20:18:02 --> Language Class Initialized
ERROR - 2023-08-18 20:18:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:18:03 --> Config Class Initialized
INFO - 2023-08-18 20:18:04 --> Config Class Initialized
INFO - 2023-08-18 20:18:04 --> Config Class Initialized
INFO - 2023-08-18 20:18:04 --> Hooks Class Initialized
INFO - 2023-08-18 20:18:04 --> Config Class Initialized
INFO - 2023-08-18 20:18:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:18:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:18:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:18:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:18:04 --> Hooks Class Initialized
INFO - 2023-08-18 20:18:04 --> Config Class Initialized
INFO - 2023-08-18 20:18:04 --> Utf8 Class Initialized
DEBUG - 2023-08-18 20:18:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:18:04 --> Utf8 Class Initialized
INFO - 2023-08-18 20:18:04 --> URI Class Initialized
INFO - 2023-08-18 20:18:04 --> Hooks Class Initialized
INFO - 2023-08-18 20:18:04 --> URI Class Initialized
INFO - 2023-08-18 20:18:04 --> Router Class Initialized
INFO - 2023-08-18 20:18:04 --> Output Class Initialized
INFO - 2023-08-18 20:18:04 --> Security Class Initialized
DEBUG - 2023-08-18 20:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:18:04 --> Input Class Initialized
INFO - 2023-08-18 20:18:04 --> Language Class Initialized
ERROR - 2023-08-18 20:18:04 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 20:18:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:18:04 --> Utf8 Class Initialized
INFO - 2023-08-18 20:18:04 --> Router Class Initialized
INFO - 2023-08-18 20:18:04 --> Output Class Initialized
INFO - 2023-08-18 20:18:04 --> Security Class Initialized
DEBUG - 2023-08-18 20:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:18:04 --> Input Class Initialized
INFO - 2023-08-18 20:18:04 --> Language Class Initialized
ERROR - 2023-08-18 20:18:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:18:04 --> Utf8 Class Initialized
DEBUG - 2023-08-18 20:18:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:18:04 --> URI Class Initialized
INFO - 2023-08-18 20:18:04 --> Utf8 Class Initialized
INFO - 2023-08-18 20:18:04 --> URI Class Initialized
INFO - 2023-08-18 20:18:05 --> Router Class Initialized
INFO - 2023-08-18 20:18:05 --> URI Class Initialized
INFO - 2023-08-18 20:18:05 --> Output Class Initialized
INFO - 2023-08-18 20:18:05 --> Router Class Initialized
INFO - 2023-08-18 20:18:05 --> Output Class Initialized
INFO - 2023-08-18 20:18:05 --> Router Class Initialized
INFO - 2023-08-18 20:18:05 --> Security Class Initialized
DEBUG - 2023-08-18 20:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:18:05 --> Security Class Initialized
INFO - 2023-08-18 20:18:05 --> Input Class Initialized
INFO - 2023-08-18 20:18:05 --> Output Class Initialized
INFO - 2023-08-18 20:18:05 --> Language Class Initialized
INFO - 2023-08-18 20:18:05 --> Security Class Initialized
ERROR - 2023-08-18 20:18:05 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-18 20:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-18 20:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:18:05 --> Input Class Initialized
INFO - 2023-08-18 20:18:05 --> Language Class Initialized
INFO - 2023-08-18 20:18:05 --> Input Class Initialized
ERROR - 2023-08-18 20:18:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:18:05 --> Language Class Initialized
ERROR - 2023-08-18 20:18:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:18:15 --> Config Class Initialized
INFO - 2023-08-18 20:18:15 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:18:15 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:18:15 --> Utf8 Class Initialized
INFO - 2023-08-18 20:18:15 --> URI Class Initialized
INFO - 2023-08-18 20:18:15 --> Router Class Initialized
INFO - 2023-08-18 20:18:15 --> Output Class Initialized
INFO - 2023-08-18 20:18:15 --> Security Class Initialized
DEBUG - 2023-08-18 20:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:18:15 --> Input Class Initialized
INFO - 2023-08-18 20:18:15 --> Language Class Initialized
INFO - 2023-08-18 20:18:15 --> Loader Class Initialized
INFO - 2023-08-18 20:18:15 --> Helper loaded: url_helper
INFO - 2023-08-18 20:18:15 --> Helper loaded: file_helper
INFO - 2023-08-18 20:18:15 --> Database Driver Class Initialized
INFO - 2023-08-18 20:18:15 --> Email Class Initialized
DEBUG - 2023-08-18 20:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:18:15 --> Controller Class Initialized
INFO - 2023-08-18 20:18:15 --> Model "Home_model" initialized
INFO - 2023-08-18 20:18:15 --> Helper loaded: form_helper
INFO - 2023-08-18 20:18:15 --> Form Validation Class Initialized
INFO - 2023-08-18 20:18:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:18:16 --> Final output sent to browser
DEBUG - 2023-08-18 20:18:16 --> Total execution time: 0.4849
INFO - 2023-08-18 20:18:16 --> Config Class Initialized
INFO - 2023-08-18 20:18:16 --> Config Class Initialized
INFO - 2023-08-18 20:18:16 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:18:16 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:18:16 --> Hooks Class Initialized
INFO - 2023-08-18 20:18:16 --> Utf8 Class Initialized
DEBUG - 2023-08-18 20:18:16 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:18:17 --> URI Class Initialized
INFO - 2023-08-18 20:18:17 --> Utf8 Class Initialized
INFO - 2023-08-18 20:18:17 --> Router Class Initialized
INFO - 2023-08-18 20:18:17 --> Output Class Initialized
INFO - 2023-08-18 20:18:17 --> URI Class Initialized
INFO - 2023-08-18 20:18:17 --> Security Class Initialized
INFO - 2023-08-18 20:18:17 --> Router Class Initialized
DEBUG - 2023-08-18 20:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:18:17 --> Output Class Initialized
INFO - 2023-08-18 20:18:17 --> Input Class Initialized
INFO - 2023-08-18 20:18:17 --> Security Class Initialized
INFO - 2023-08-18 20:18:17 --> Language Class Initialized
DEBUG - 2023-08-18 20:18:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-18 20:18:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:18:17 --> Input Class Initialized
INFO - 2023-08-18 20:18:17 --> Language Class Initialized
ERROR - 2023-08-18 20:18:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:18:17 --> Config Class Initialized
INFO - 2023-08-18 20:18:17 --> Config Class Initialized
INFO - 2023-08-18 20:18:17 --> Config Class Initialized
INFO - 2023-08-18 20:18:17 --> Hooks Class Initialized
INFO - 2023-08-18 20:18:17 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:18:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 20:18:17 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:18:17 --> Hooks Class Initialized
INFO - 2023-08-18 20:18:17 --> Utf8 Class Initialized
INFO - 2023-08-18 20:18:17 --> Utf8 Class Initialized
INFO - 2023-08-18 20:18:17 --> URI Class Initialized
INFO - 2023-08-18 20:18:17 --> URI Class Initialized
INFO - 2023-08-18 20:18:17 --> Router Class Initialized
INFO - 2023-08-18 20:18:17 --> Router Class Initialized
DEBUG - 2023-08-18 20:18:17 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:18:17 --> Output Class Initialized
INFO - 2023-08-18 20:18:17 --> Utf8 Class Initialized
INFO - 2023-08-18 20:18:17 --> Security Class Initialized
INFO - 2023-08-18 20:18:17 --> Output Class Initialized
INFO - 2023-08-18 20:18:17 --> URI Class Initialized
DEBUG - 2023-08-18 20:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:18:17 --> Router Class Initialized
INFO - 2023-08-18 20:18:17 --> Security Class Initialized
DEBUG - 2023-08-18 20:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:18:17 --> Output Class Initialized
INFO - 2023-08-18 20:18:17 --> Input Class Initialized
INFO - 2023-08-18 20:18:17 --> Input Class Initialized
INFO - 2023-08-18 20:18:17 --> Language Class Initialized
INFO - 2023-08-18 20:18:17 --> Security Class Initialized
DEBUG - 2023-08-18 20:18:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-18 20:18:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:18:17 --> Input Class Initialized
INFO - 2023-08-18 20:18:17 --> Language Class Initialized
ERROR - 2023-08-18 20:18:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:18:17 --> Language Class Initialized
ERROR - 2023-08-18 20:18:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:18:59 --> Config Class Initialized
INFO - 2023-08-18 20:18:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:18:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:18:59 --> Utf8 Class Initialized
INFO - 2023-08-18 20:18:59 --> URI Class Initialized
INFO - 2023-08-18 20:18:59 --> Router Class Initialized
INFO - 2023-08-18 20:18:59 --> Output Class Initialized
INFO - 2023-08-18 20:18:59 --> Security Class Initialized
DEBUG - 2023-08-18 20:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:18:59 --> Input Class Initialized
INFO - 2023-08-18 20:18:59 --> Language Class Initialized
INFO - 2023-08-18 20:18:59 --> Loader Class Initialized
INFO - 2023-08-18 20:18:59 --> Helper loaded: url_helper
INFO - 2023-08-18 20:18:59 --> Helper loaded: file_helper
INFO - 2023-08-18 20:18:59 --> Database Driver Class Initialized
INFO - 2023-08-18 20:18:59 --> Email Class Initialized
DEBUG - 2023-08-18 20:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:18:59 --> Controller Class Initialized
INFO - 2023-08-18 20:18:59 --> Model "Home_model" initialized
INFO - 2023-08-18 20:18:59 --> Helper loaded: form_helper
INFO - 2023-08-18 20:18:59 --> Form Validation Class Initialized
INFO - 2023-08-18 20:18:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:18:59 --> Final output sent to browser
DEBUG - 2023-08-18 20:18:59 --> Total execution time: 0.5009
INFO - 2023-08-18 20:19:00 --> Config Class Initialized
INFO - 2023-08-18 20:19:00 --> Config Class Initialized
INFO - 2023-08-18 20:19:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:19:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:00 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:00 --> URI Class Initialized
INFO - 2023-08-18 20:19:00 --> Router Class Initialized
INFO - 2023-08-18 20:19:00 --> Output Class Initialized
INFO - 2023-08-18 20:19:00 --> Security Class Initialized
DEBUG - 2023-08-18 20:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:00 --> Input Class Initialized
INFO - 2023-08-18 20:19:00 --> Language Class Initialized
ERROR - 2023-08-18 20:19:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:19:00 --> Config Class Initialized
INFO - 2023-08-18 20:19:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:19:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:00 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:00 --> URI Class Initialized
INFO - 2023-08-18 20:19:00 --> Router Class Initialized
INFO - 2023-08-18 20:19:00 --> Output Class Initialized
INFO - 2023-08-18 20:19:00 --> Security Class Initialized
DEBUG - 2023-08-18 20:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:00 --> Input Class Initialized
INFO - 2023-08-18 20:19:00 --> Language Class Initialized
ERROR - 2023-08-18 20:19:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:19:00 --> Hooks Class Initialized
INFO - 2023-08-18 20:19:00 --> Config Class Initialized
INFO - 2023-08-18 20:19:00 --> Hooks Class Initialized
INFO - 2023-08-18 20:19:00 --> Config Class Initialized
DEBUG - 2023-08-18 20:19:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-18 20:19:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:00 --> Hooks Class Initialized
INFO - 2023-08-18 20:19:00 --> Utf8 Class Initialized
DEBUG - 2023-08-18 20:19:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:00 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:00 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:00 --> URI Class Initialized
INFO - 2023-08-18 20:19:00 --> URI Class Initialized
INFO - 2023-08-18 20:19:01 --> URI Class Initialized
INFO - 2023-08-18 20:19:01 --> Router Class Initialized
INFO - 2023-08-18 20:19:01 --> Router Class Initialized
INFO - 2023-08-18 20:19:01 --> Output Class Initialized
INFO - 2023-08-18 20:19:01 --> Router Class Initialized
INFO - 2023-08-18 20:19:01 --> Security Class Initialized
INFO - 2023-08-18 20:19:01 --> Output Class Initialized
INFO - 2023-08-18 20:19:01 --> Output Class Initialized
INFO - 2023-08-18 20:19:01 --> Security Class Initialized
DEBUG - 2023-08-18 20:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:01 --> Security Class Initialized
INFO - 2023-08-18 20:19:01 --> Input Class Initialized
DEBUG - 2023-08-18 20:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:01 --> Input Class Initialized
DEBUG - 2023-08-18 20:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:01 --> Language Class Initialized
INFO - 2023-08-18 20:19:01 --> Input Class Initialized
INFO - 2023-08-18 20:19:01 --> Language Class Initialized
INFO - 2023-08-18 20:19:01 --> Language Class Initialized
ERROR - 2023-08-18 20:19:01 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 20:19:01 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-18 20:19:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:19:12 --> Config Class Initialized
INFO - 2023-08-18 20:19:12 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:19:12 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:12 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:12 --> URI Class Initialized
INFO - 2023-08-18 20:19:12 --> Router Class Initialized
INFO - 2023-08-18 20:19:12 --> Output Class Initialized
INFO - 2023-08-18 20:19:13 --> Security Class Initialized
DEBUG - 2023-08-18 20:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:13 --> Input Class Initialized
INFO - 2023-08-18 20:19:13 --> Language Class Initialized
INFO - 2023-08-18 20:19:13 --> Loader Class Initialized
INFO - 2023-08-18 20:19:13 --> Helper loaded: url_helper
INFO - 2023-08-18 20:19:13 --> Helper loaded: file_helper
INFO - 2023-08-18 20:19:13 --> Database Driver Class Initialized
INFO - 2023-08-18 20:19:13 --> Email Class Initialized
DEBUG - 2023-08-18 20:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:19:13 --> Controller Class Initialized
INFO - 2023-08-18 20:19:13 --> Model "Home_model" initialized
INFO - 2023-08-18 20:19:13 --> Helper loaded: form_helper
INFO - 2023-08-18 20:19:13 --> Form Validation Class Initialized
INFO - 2023-08-18 20:19:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:19:13 --> Final output sent to browser
DEBUG - 2023-08-18 20:19:13 --> Total execution time: 0.4731
INFO - 2023-08-18 20:19:13 --> Config Class Initialized
INFO - 2023-08-18 20:19:13 --> Hooks Class Initialized
INFO - 2023-08-18 20:19:14 --> Config Class Initialized
INFO - 2023-08-18 20:19:14 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:19:14 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:14 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:14 --> URI Class Initialized
INFO - 2023-08-18 20:19:14 --> Router Class Initialized
INFO - 2023-08-18 20:19:14 --> Output Class Initialized
INFO - 2023-08-18 20:19:14 --> Security Class Initialized
DEBUG - 2023-08-18 20:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:14 --> Input Class Initialized
INFO - 2023-08-18 20:19:14 --> Language Class Initialized
ERROR - 2023-08-18 20:19:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:19:14 --> Config Class Initialized
INFO - 2023-08-18 20:19:14 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:19:14 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:14 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:14 --> URI Class Initialized
INFO - 2023-08-18 20:19:14 --> Router Class Initialized
INFO - 2023-08-18 20:19:14 --> Output Class Initialized
INFO - 2023-08-18 20:19:14 --> Security Class Initialized
DEBUG - 2023-08-18 20:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:14 --> Input Class Initialized
INFO - 2023-08-18 20:19:14 --> Language Class Initialized
ERROR - 2023-08-18 20:19:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:19:14 --> Config Class Initialized
INFO - 2023-08-18 20:19:14 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:19:14 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:14 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:14 --> URI Class Initialized
INFO - 2023-08-18 20:19:14 --> Router Class Initialized
INFO - 2023-08-18 20:19:14 --> Output Class Initialized
INFO - 2023-08-18 20:19:14 --> Security Class Initialized
DEBUG - 2023-08-18 20:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:14 --> Input Class Initialized
INFO - 2023-08-18 20:19:14 --> Language Class Initialized
ERROR - 2023-08-18 20:19:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:19:14 --> Config Class Initialized
DEBUG - 2023-08-18 20:19:14 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:14 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:14 --> URI Class Initialized
INFO - 2023-08-18 20:19:14 --> Hooks Class Initialized
INFO - 2023-08-18 20:19:14 --> Router Class Initialized
DEBUG - 2023-08-18 20:19:14 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:14 --> Output Class Initialized
INFO - 2023-08-18 20:19:14 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:14 --> URI Class Initialized
INFO - 2023-08-18 20:19:14 --> Security Class Initialized
INFO - 2023-08-18 20:19:14 --> Router Class Initialized
INFO - 2023-08-18 20:19:14 --> Output Class Initialized
DEBUG - 2023-08-18 20:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:14 --> Security Class Initialized
INFO - 2023-08-18 20:19:14 --> Input Class Initialized
DEBUG - 2023-08-18 20:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:14 --> Language Class Initialized
INFO - 2023-08-18 20:19:14 --> Input Class Initialized
ERROR - 2023-08-18 20:19:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:19:15 --> Language Class Initialized
ERROR - 2023-08-18 20:19:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:19:22 --> Config Class Initialized
INFO - 2023-08-18 20:19:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:19:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:22 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:22 --> URI Class Initialized
INFO - 2023-08-18 20:19:22 --> Router Class Initialized
INFO - 2023-08-18 20:19:22 --> Output Class Initialized
INFO - 2023-08-18 20:19:22 --> Security Class Initialized
DEBUG - 2023-08-18 20:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:22 --> Input Class Initialized
INFO - 2023-08-18 20:19:22 --> Language Class Initialized
INFO - 2023-08-18 20:19:22 --> Loader Class Initialized
INFO - 2023-08-18 20:19:22 --> Helper loaded: url_helper
INFO - 2023-08-18 20:19:22 --> Helper loaded: file_helper
INFO - 2023-08-18 20:19:22 --> Database Driver Class Initialized
INFO - 2023-08-18 20:19:22 --> Email Class Initialized
DEBUG - 2023-08-18 20:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 20:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 20:19:23 --> Controller Class Initialized
INFO - 2023-08-18 20:19:23 --> Model "Home_model" initialized
INFO - 2023-08-18 20:19:23 --> Helper loaded: form_helper
INFO - 2023-08-18 20:19:23 --> Form Validation Class Initialized
INFO - 2023-08-18 20:19:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-08-18 20:19:23 --> Final output sent to browser
DEBUG - 2023-08-18 20:19:23 --> Total execution time: 0.8030
INFO - 2023-08-18 20:19:23 --> Config Class Initialized
INFO - 2023-08-18 20:19:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:19:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:23 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:23 --> URI Class Initialized
INFO - 2023-08-18 20:19:23 --> Router Class Initialized
INFO - 2023-08-18 20:19:23 --> Output Class Initialized
INFO - 2023-08-18 20:19:23 --> Security Class Initialized
DEBUG - 2023-08-18 20:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:23 --> Input Class Initialized
INFO - 2023-08-18 20:19:23 --> Language Class Initialized
ERROR - 2023-08-18 20:19:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:19:23 --> Config Class Initialized
INFO - 2023-08-18 20:19:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:19:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:23 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:23 --> URI Class Initialized
INFO - 2023-08-18 20:19:23 --> Router Class Initialized
INFO - 2023-08-18 20:19:23 --> Output Class Initialized
INFO - 2023-08-18 20:19:23 --> Security Class Initialized
DEBUG - 2023-08-18 20:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:23 --> Input Class Initialized
INFO - 2023-08-18 20:19:23 --> Language Class Initialized
ERROR - 2023-08-18 20:19:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:19:23 --> Config Class Initialized
INFO - 2023-08-18 20:19:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:19:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:23 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:23 --> URI Class Initialized
INFO - 2023-08-18 20:19:23 --> Router Class Initialized
INFO - 2023-08-18 20:19:23 --> Output Class Initialized
INFO - 2023-08-18 20:19:23 --> Security Class Initialized
DEBUG - 2023-08-18 20:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:23 --> Input Class Initialized
INFO - 2023-08-18 20:19:23 --> Language Class Initialized
ERROR - 2023-08-18 20:19:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:19:23 --> Config Class Initialized
INFO - 2023-08-18 20:19:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:19:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:24 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:24 --> Config Class Initialized
INFO - 2023-08-18 20:19:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:19:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:24 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:24 --> URI Class Initialized
INFO - 2023-08-18 20:19:24 --> Router Class Initialized
INFO - 2023-08-18 20:19:24 --> Output Class Initialized
INFO - 2023-08-18 20:19:24 --> Security Class Initialized
DEBUG - 2023-08-18 20:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:24 --> Input Class Initialized
INFO - 2023-08-18 20:19:24 --> Language Class Initialized
ERROR - 2023-08-18 20:19:24 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:19:24 --> URI Class Initialized
INFO - 2023-08-18 20:19:24 --> Router Class Initialized
INFO - 2023-08-18 20:19:24 --> Output Class Initialized
INFO - 2023-08-18 20:19:24 --> Security Class Initialized
DEBUG - 2023-08-18 20:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:24 --> Input Class Initialized
INFO - 2023-08-18 20:19:24 --> Language Class Initialized
ERROR - 2023-08-18 20:19:24 --> 404 Page Not Found: Assets/images
INFO - 2023-08-18 20:19:24 --> Config Class Initialized
INFO - 2023-08-18 20:19:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 20:19:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 20:19:24 --> Utf8 Class Initialized
INFO - 2023-08-18 20:19:24 --> URI Class Initialized
INFO - 2023-08-18 20:19:24 --> Router Class Initialized
INFO - 2023-08-18 20:19:24 --> Output Class Initialized
INFO - 2023-08-18 20:19:24 --> Security Class Initialized
DEBUG - 2023-08-18 20:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 20:19:24 --> Input Class Initialized
INFO - 2023-08-18 20:19:24 --> Language Class Initialized
ERROR - 2023-08-18 20:19:24 --> 404 Page Not Found: Assets/images
