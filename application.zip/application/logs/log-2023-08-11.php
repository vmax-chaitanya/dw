<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-11 16:18:42 --> Config Class Initialized
INFO - 2023-08-11 16:18:42 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:18:42 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:18:42 --> Utf8 Class Initialized
INFO - 2023-08-11 16:18:42 --> URI Class Initialized
DEBUG - 2023-08-11 16:18:42 --> No URI present. Default controller set.
INFO - 2023-08-11 16:18:42 --> Router Class Initialized
INFO - 2023-08-11 16:18:42 --> Output Class Initialized
INFO - 2023-08-11 16:18:42 --> Security Class Initialized
DEBUG - 2023-08-11 16:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:18:42 --> Input Class Initialized
INFO - 2023-08-11 16:18:42 --> Language Class Initialized
INFO - 2023-08-11 16:18:42 --> Loader Class Initialized
INFO - 2023-08-11 16:18:42 --> Helper loaded: url_helper
INFO - 2023-08-11 16:18:42 --> Helper loaded: file_helper
INFO - 2023-08-11 16:18:42 --> Database Driver Class Initialized
INFO - 2023-08-11 16:18:42 --> Email Class Initialized
DEBUG - 2023-08-11 16:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:18:43 --> Controller Class Initialized
INFO - 2023-08-11 16:18:43 --> File loaded: C:\xampp\htdocs\DW\application\views\welcome_message.php
INFO - 2023-08-11 16:18:43 --> Final output sent to browser
DEBUG - 2023-08-11 16:18:43 --> Total execution time: 1.0827
INFO - 2023-08-11 16:18:46 --> Config Class Initialized
INFO - 2023-08-11 16:18:46 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:18:46 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:18:46 --> Utf8 Class Initialized
INFO - 2023-08-11 16:18:46 --> URI Class Initialized
INFO - 2023-08-11 16:18:46 --> Router Class Initialized
INFO - 2023-08-11 16:18:46 --> Output Class Initialized
INFO - 2023-08-11 16:18:46 --> Security Class Initialized
DEBUG - 2023-08-11 16:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:18:46 --> Input Class Initialized
INFO - 2023-08-11 16:18:46 --> Language Class Initialized
INFO - 2023-08-11 16:18:46 --> Loader Class Initialized
INFO - 2023-08-11 16:18:46 --> Helper loaded: url_helper
INFO - 2023-08-11 16:18:46 --> Helper loaded: file_helper
INFO - 2023-08-11 16:18:46 --> Database Driver Class Initialized
INFO - 2023-08-11 16:18:46 --> Email Class Initialized
DEBUG - 2023-08-11 16:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:18:46 --> Controller Class Initialized
INFO - 2023-08-11 16:18:46 --> Model "Gallery_model" initialized
INFO - 2023-08-11 16:18:46 --> Helper loaded: form_helper
INFO - 2023-08-11 16:18:46 --> Form Validation Class Initialized
INFO - 2023-08-11 16:18:46 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-11 16:18:46 --> Final output sent to browser
DEBUG - 2023-08-11 16:18:46 --> Total execution time: 0.3147
INFO - 2023-08-11 16:18:48 --> Config Class Initialized
INFO - 2023-08-11 16:18:48 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:18:48 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:18:48 --> Utf8 Class Initialized
INFO - 2023-08-11 16:18:48 --> URI Class Initialized
INFO - 2023-08-11 16:18:48 --> Router Class Initialized
INFO - 2023-08-11 16:18:48 --> Output Class Initialized
INFO - 2023-08-11 16:18:48 --> Security Class Initialized
DEBUG - 2023-08-11 16:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:18:48 --> Input Class Initialized
INFO - 2023-08-11 16:18:48 --> Language Class Initialized
ERROR - 2023-08-11 16:18:48 --> 404 Page Not Found: admin/Gallery/images
INFO - 2023-08-11 16:27:07 --> Config Class Initialized
INFO - 2023-08-11 16:27:07 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:27:07 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:27:07 --> Utf8 Class Initialized
INFO - 2023-08-11 16:27:07 --> URI Class Initialized
INFO - 2023-08-11 16:27:08 --> Router Class Initialized
INFO - 2023-08-11 16:27:08 --> Output Class Initialized
INFO - 2023-08-11 16:27:08 --> Security Class Initialized
DEBUG - 2023-08-11 16:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:27:08 --> Input Class Initialized
INFO - 2023-08-11 16:27:08 --> Language Class Initialized
INFO - 2023-08-11 16:27:08 --> Loader Class Initialized
INFO - 2023-08-11 16:27:08 --> Helper loaded: url_helper
INFO - 2023-08-11 16:27:08 --> Helper loaded: file_helper
INFO - 2023-08-11 16:27:08 --> Database Driver Class Initialized
INFO - 2023-08-11 16:27:08 --> Email Class Initialized
DEBUG - 2023-08-11 16:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:27:08 --> Controller Class Initialized
INFO - 2023-08-11 16:27:08 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:27:08 --> Helper loaded: form_helper
INFO - 2023-08-11 16:27:08 --> Form Validation Class Initialized
ERROR - 2023-08-11 16:27:08 --> Query error: Table 'dw.contact' doesn't exist - Invalid query: SELECT *
FROM `contact`
INFO - 2023-08-11 16:27:08 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-11 16:30:28 --> Config Class Initialized
INFO - 2023-08-11 16:30:28 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:30:28 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:30:28 --> Utf8 Class Initialized
INFO - 2023-08-11 16:30:28 --> URI Class Initialized
INFO - 2023-08-11 16:30:28 --> Router Class Initialized
INFO - 2023-08-11 16:30:28 --> Output Class Initialized
INFO - 2023-08-11 16:30:28 --> Security Class Initialized
DEBUG - 2023-08-11 16:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:30:28 --> Input Class Initialized
INFO - 2023-08-11 16:30:28 --> Language Class Initialized
INFO - 2023-08-11 16:30:28 --> Loader Class Initialized
INFO - 2023-08-11 16:30:28 --> Helper loaded: url_helper
INFO - 2023-08-11 16:30:28 --> Helper loaded: file_helper
INFO - 2023-08-11 16:30:28 --> Database Driver Class Initialized
INFO - 2023-08-11 16:30:28 --> Email Class Initialized
DEBUG - 2023-08-11 16:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:30:28 --> Controller Class Initialized
INFO - 2023-08-11 16:30:28 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:30:28 --> Helper loaded: form_helper
INFO - 2023-08-11 16:30:28 --> Form Validation Class Initialized
INFO - 2023-08-11 16:30:28 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_list.php
INFO - 2023-08-11 16:30:28 --> Final output sent to browser
DEBUG - 2023-08-11 16:30:28 --> Total execution time: 0.0853
INFO - 2023-08-11 16:30:29 --> Config Class Initialized
INFO - 2023-08-11 16:30:29 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:30:29 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:30:29 --> Utf8 Class Initialized
INFO - 2023-08-11 16:30:29 --> URI Class Initialized
INFO - 2023-08-11 16:30:29 --> Router Class Initialized
INFO - 2023-08-11 16:30:29 --> Output Class Initialized
INFO - 2023-08-11 16:30:29 --> Security Class Initialized
DEBUG - 2023-08-11 16:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:30:29 --> Input Class Initialized
INFO - 2023-08-11 16:30:29 --> Language Class Initialized
ERROR - 2023-08-11 16:30:29 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-11 16:30:30 --> Config Class Initialized
INFO - 2023-08-11 16:30:30 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:30:30 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:30:30 --> Utf8 Class Initialized
INFO - 2023-08-11 16:30:30 --> URI Class Initialized
INFO - 2023-08-11 16:30:30 --> Router Class Initialized
INFO - 2023-08-11 16:30:30 --> Output Class Initialized
INFO - 2023-08-11 16:30:30 --> Security Class Initialized
DEBUG - 2023-08-11 16:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:30:30 --> Input Class Initialized
INFO - 2023-08-11 16:30:30 --> Language Class Initialized
INFO - 2023-08-11 16:30:30 --> Loader Class Initialized
INFO - 2023-08-11 16:30:30 --> Helper loaded: url_helper
INFO - 2023-08-11 16:30:30 --> Helper loaded: file_helper
INFO - 2023-08-11 16:30:30 --> Database Driver Class Initialized
INFO - 2023-08-11 16:30:30 --> Email Class Initialized
DEBUG - 2023-08-11 16:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:30:30 --> Controller Class Initialized
INFO - 2023-08-11 16:30:30 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:30:30 --> Helper loaded: form_helper
INFO - 2023-08-11 16:30:30 --> Form Validation Class Initialized
INFO - 2023-08-11 16:30:30 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_list.php
INFO - 2023-08-11 16:30:30 --> Final output sent to browser
DEBUG - 2023-08-11 16:30:30 --> Total execution time: 0.0467
INFO - 2023-08-11 16:32:07 --> Config Class Initialized
INFO - 2023-08-11 16:32:07 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:32:07 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:32:07 --> Utf8 Class Initialized
INFO - 2023-08-11 16:32:07 --> URI Class Initialized
INFO - 2023-08-11 16:32:07 --> Router Class Initialized
INFO - 2023-08-11 16:32:07 --> Output Class Initialized
INFO - 2023-08-11 16:32:07 --> Security Class Initialized
DEBUG - 2023-08-11 16:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:32:07 --> Input Class Initialized
INFO - 2023-08-11 16:32:07 --> Language Class Initialized
INFO - 2023-08-11 16:32:07 --> Loader Class Initialized
INFO - 2023-08-11 16:32:07 --> Helper loaded: url_helper
INFO - 2023-08-11 16:32:07 --> Helper loaded: file_helper
INFO - 2023-08-11 16:32:07 --> Database Driver Class Initialized
INFO - 2023-08-11 16:32:07 --> Email Class Initialized
DEBUG - 2023-08-11 16:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:32:07 --> Controller Class Initialized
INFO - 2023-08-11 16:32:07 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:32:07 --> Helper loaded: form_helper
INFO - 2023-08-11 16:32:07 --> Form Validation Class Initialized
INFO - 2023-08-11 16:32:07 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_list.php
INFO - 2023-08-11 16:32:07 --> Final output sent to browser
DEBUG - 2023-08-11 16:32:07 --> Total execution time: 0.1623
INFO - 2023-08-11 16:32:08 --> Config Class Initialized
INFO - 2023-08-11 16:32:08 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:32:08 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:32:08 --> Utf8 Class Initialized
INFO - 2023-08-11 16:32:08 --> URI Class Initialized
INFO - 2023-08-11 16:32:08 --> Router Class Initialized
INFO - 2023-08-11 16:32:08 --> Output Class Initialized
INFO - 2023-08-11 16:32:08 --> Security Class Initialized
DEBUG - 2023-08-11 16:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:32:08 --> Input Class Initialized
INFO - 2023-08-11 16:32:08 --> Language Class Initialized
INFO - 2023-08-11 16:32:08 --> Loader Class Initialized
INFO - 2023-08-11 16:32:08 --> Helper loaded: url_helper
INFO - 2023-08-11 16:32:08 --> Helper loaded: file_helper
INFO - 2023-08-11 16:32:08 --> Database Driver Class Initialized
INFO - 2023-08-11 16:32:08 --> Email Class Initialized
DEBUG - 2023-08-11 16:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:32:08 --> Controller Class Initialized
INFO - 2023-08-11 16:32:08 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:32:08 --> Helper loaded: form_helper
INFO - 2023-08-11 16:32:08 --> Form Validation Class Initialized
INFO - 2023-08-11 16:32:12 --> Config Class Initialized
INFO - 2023-08-11 16:32:12 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:32:12 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:32:12 --> Utf8 Class Initialized
INFO - 2023-08-11 16:32:12 --> URI Class Initialized
INFO - 2023-08-11 16:32:12 --> Router Class Initialized
INFO - 2023-08-11 16:32:12 --> Output Class Initialized
INFO - 2023-08-11 16:32:12 --> Security Class Initialized
DEBUG - 2023-08-11 16:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:32:12 --> Input Class Initialized
INFO - 2023-08-11 16:32:12 --> Language Class Initialized
INFO - 2023-08-11 16:32:12 --> Loader Class Initialized
INFO - 2023-08-11 16:32:12 --> Helper loaded: url_helper
INFO - 2023-08-11 16:32:12 --> Helper loaded: file_helper
INFO - 2023-08-11 16:32:12 --> Database Driver Class Initialized
INFO - 2023-08-11 16:32:12 --> Email Class Initialized
DEBUG - 2023-08-11 16:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:32:12 --> Controller Class Initialized
INFO - 2023-08-11 16:32:12 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:32:12 --> Helper loaded: form_helper
INFO - 2023-08-11 16:32:12 --> Form Validation Class Initialized
INFO - 2023-08-11 16:32:12 --> Config Class Initialized
INFO - 2023-08-11 16:32:12 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:32:12 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:32:12 --> Utf8 Class Initialized
INFO - 2023-08-11 16:32:12 --> URI Class Initialized
INFO - 2023-08-11 16:32:12 --> Router Class Initialized
INFO - 2023-08-11 16:32:12 --> Output Class Initialized
INFO - 2023-08-11 16:32:12 --> Security Class Initialized
DEBUG - 2023-08-11 16:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:32:12 --> Input Class Initialized
INFO - 2023-08-11 16:32:12 --> Language Class Initialized
INFO - 2023-08-11 16:32:12 --> Loader Class Initialized
INFO - 2023-08-11 16:32:12 --> Helper loaded: url_helper
INFO - 2023-08-11 16:32:12 --> Helper loaded: file_helper
INFO - 2023-08-11 16:32:12 --> Database Driver Class Initialized
INFO - 2023-08-11 16:32:12 --> Email Class Initialized
DEBUG - 2023-08-11 16:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:32:12 --> Controller Class Initialized
INFO - 2023-08-11 16:32:12 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:32:12 --> Helper loaded: form_helper
INFO - 2023-08-11 16:32:13 --> Form Validation Class Initialized
INFO - 2023-08-11 16:32:13 --> Config Class Initialized
INFO - 2023-08-11 16:32:13 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:32:13 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:32:13 --> Utf8 Class Initialized
INFO - 2023-08-11 16:32:13 --> URI Class Initialized
INFO - 2023-08-11 16:32:13 --> Router Class Initialized
INFO - 2023-08-11 16:32:13 --> Output Class Initialized
INFO - 2023-08-11 16:32:13 --> Security Class Initialized
DEBUG - 2023-08-11 16:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:32:13 --> Input Class Initialized
INFO - 2023-08-11 16:32:13 --> Language Class Initialized
INFO - 2023-08-11 16:32:13 --> Loader Class Initialized
INFO - 2023-08-11 16:32:13 --> Helper loaded: url_helper
INFO - 2023-08-11 16:32:13 --> Helper loaded: file_helper
INFO - 2023-08-11 16:32:13 --> Database Driver Class Initialized
INFO - 2023-08-11 16:32:13 --> Email Class Initialized
DEBUG - 2023-08-11 16:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:32:13 --> Controller Class Initialized
INFO - 2023-08-11 16:32:13 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:32:13 --> Helper loaded: form_helper
INFO - 2023-08-11 16:32:13 --> Form Validation Class Initialized
INFO - 2023-08-11 16:32:35 --> Config Class Initialized
INFO - 2023-08-11 16:32:35 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:32:35 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:32:35 --> Utf8 Class Initialized
INFO - 2023-08-11 16:32:35 --> URI Class Initialized
INFO - 2023-08-11 16:32:35 --> Router Class Initialized
INFO - 2023-08-11 16:32:35 --> Output Class Initialized
INFO - 2023-08-11 16:32:35 --> Security Class Initialized
DEBUG - 2023-08-11 16:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:32:35 --> Input Class Initialized
INFO - 2023-08-11 16:32:35 --> Language Class Initialized
INFO - 2023-08-11 16:32:35 --> Loader Class Initialized
INFO - 2023-08-11 16:32:35 --> Helper loaded: url_helper
INFO - 2023-08-11 16:32:35 --> Helper loaded: file_helper
INFO - 2023-08-11 16:32:35 --> Database Driver Class Initialized
INFO - 2023-08-11 16:32:35 --> Email Class Initialized
DEBUG - 2023-08-11 16:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:32:35 --> Controller Class Initialized
INFO - 2023-08-11 16:32:35 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:32:35 --> Helper loaded: form_helper
INFO - 2023-08-11 16:32:35 --> Form Validation Class Initialized
INFO - 2023-08-11 16:32:35 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_list.php
INFO - 2023-08-11 16:32:35 --> Final output sent to browser
DEBUG - 2023-08-11 16:32:35 --> Total execution time: 0.0654
INFO - 2023-08-11 16:32:38 --> Config Class Initialized
INFO - 2023-08-11 16:32:38 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:32:38 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:32:38 --> Utf8 Class Initialized
INFO - 2023-08-11 16:32:38 --> URI Class Initialized
INFO - 2023-08-11 16:32:38 --> Router Class Initialized
INFO - 2023-08-11 16:32:38 --> Output Class Initialized
INFO - 2023-08-11 16:32:38 --> Security Class Initialized
DEBUG - 2023-08-11 16:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:32:38 --> Input Class Initialized
INFO - 2023-08-11 16:32:38 --> Language Class Initialized
INFO - 2023-08-11 16:32:38 --> Loader Class Initialized
INFO - 2023-08-11 16:32:38 --> Helper loaded: url_helper
INFO - 2023-08-11 16:32:38 --> Helper loaded: file_helper
INFO - 2023-08-11 16:32:38 --> Database Driver Class Initialized
INFO - 2023-08-11 16:32:38 --> Email Class Initialized
DEBUG - 2023-08-11 16:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:32:38 --> Controller Class Initialized
INFO - 2023-08-11 16:32:38 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:32:38 --> Helper loaded: form_helper
INFO - 2023-08-11 16:32:38 --> Form Validation Class Initialized
INFO - 2023-08-11 16:32:38 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_list.php
INFO - 2023-08-11 16:32:38 --> Final output sent to browser
DEBUG - 2023-08-11 16:32:38 --> Total execution time: 0.0484
INFO - 2023-08-11 16:32:40 --> Config Class Initialized
INFO - 2023-08-11 16:32:40 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:32:40 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:32:40 --> Utf8 Class Initialized
INFO - 2023-08-11 16:32:40 --> URI Class Initialized
INFO - 2023-08-11 16:32:40 --> Router Class Initialized
INFO - 2023-08-11 16:32:40 --> Output Class Initialized
INFO - 2023-08-11 16:32:40 --> Security Class Initialized
DEBUG - 2023-08-11 16:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:32:40 --> Input Class Initialized
INFO - 2023-08-11 16:32:40 --> Language Class Initialized
INFO - 2023-08-11 16:32:40 --> Loader Class Initialized
INFO - 2023-08-11 16:32:40 --> Helper loaded: url_helper
INFO - 2023-08-11 16:32:40 --> Helper loaded: file_helper
INFO - 2023-08-11 16:32:40 --> Database Driver Class Initialized
INFO - 2023-08-11 16:32:40 --> Email Class Initialized
DEBUG - 2023-08-11 16:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:32:40 --> Controller Class Initialized
INFO - 2023-08-11 16:32:40 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:32:40 --> Helper loaded: form_helper
INFO - 2023-08-11 16:32:40 --> Form Validation Class Initialized
INFO - 2023-08-11 16:32:40 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_list.php
INFO - 2023-08-11 16:32:40 --> Final output sent to browser
DEBUG - 2023-08-11 16:32:40 --> Total execution time: 0.0483
INFO - 2023-08-11 16:32:41 --> Config Class Initialized
INFO - 2023-08-11 16:32:41 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:32:41 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:32:41 --> Utf8 Class Initialized
INFO - 2023-08-11 16:32:41 --> URI Class Initialized
INFO - 2023-08-11 16:32:41 --> Router Class Initialized
INFO - 2023-08-11 16:32:41 --> Output Class Initialized
INFO - 2023-08-11 16:32:41 --> Security Class Initialized
DEBUG - 2023-08-11 16:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:32:41 --> Input Class Initialized
INFO - 2023-08-11 16:32:41 --> Language Class Initialized
INFO - 2023-08-11 16:32:41 --> Loader Class Initialized
INFO - 2023-08-11 16:32:41 --> Helper loaded: url_helper
INFO - 2023-08-11 16:32:41 --> Helper loaded: file_helper
INFO - 2023-08-11 16:32:41 --> Database Driver Class Initialized
INFO - 2023-08-11 16:32:41 --> Email Class Initialized
DEBUG - 2023-08-11 16:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:32:41 --> Controller Class Initialized
INFO - 2023-08-11 16:32:41 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:32:41 --> Helper loaded: form_helper
INFO - 2023-08-11 16:32:41 --> Form Validation Class Initialized
INFO - 2023-08-11 16:32:41 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_list.php
INFO - 2023-08-11 16:32:41 --> Final output sent to browser
DEBUG - 2023-08-11 16:32:41 --> Total execution time: 0.0530
INFO - 2023-08-11 16:32:56 --> Config Class Initialized
INFO - 2023-08-11 16:32:56 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:32:56 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:32:56 --> Utf8 Class Initialized
INFO - 2023-08-11 16:32:56 --> URI Class Initialized
INFO - 2023-08-11 16:32:56 --> Router Class Initialized
INFO - 2023-08-11 16:32:56 --> Output Class Initialized
INFO - 2023-08-11 16:32:56 --> Security Class Initialized
DEBUG - 2023-08-11 16:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:32:56 --> Input Class Initialized
INFO - 2023-08-11 16:32:56 --> Language Class Initialized
INFO - 2023-08-11 16:32:56 --> Loader Class Initialized
INFO - 2023-08-11 16:32:56 --> Helper loaded: url_helper
INFO - 2023-08-11 16:32:56 --> Helper loaded: file_helper
INFO - 2023-08-11 16:32:56 --> Database Driver Class Initialized
INFO - 2023-08-11 16:32:56 --> Email Class Initialized
DEBUG - 2023-08-11 16:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:32:56 --> Controller Class Initialized
INFO - 2023-08-11 16:32:56 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:32:56 --> Helper loaded: form_helper
INFO - 2023-08-11 16:32:56 --> Form Validation Class Initialized
INFO - 2023-08-11 16:32:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_list.php
INFO - 2023-08-11 16:32:56 --> Final output sent to browser
DEBUG - 2023-08-11 16:32:56 --> Total execution time: 0.0725
INFO - 2023-08-11 16:32:58 --> Config Class Initialized
INFO - 2023-08-11 16:32:58 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:32:58 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:32:58 --> Utf8 Class Initialized
INFO - 2023-08-11 16:32:58 --> URI Class Initialized
INFO - 2023-08-11 16:32:58 --> Router Class Initialized
INFO - 2023-08-11 16:32:58 --> Output Class Initialized
INFO - 2023-08-11 16:32:58 --> Security Class Initialized
DEBUG - 2023-08-11 16:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:32:58 --> Input Class Initialized
INFO - 2023-08-11 16:32:58 --> Language Class Initialized
INFO - 2023-08-11 16:32:58 --> Loader Class Initialized
INFO - 2023-08-11 16:32:58 --> Helper loaded: url_helper
INFO - 2023-08-11 16:32:58 --> Helper loaded: file_helper
INFO - 2023-08-11 16:32:58 --> Database Driver Class Initialized
INFO - 2023-08-11 16:32:58 --> Email Class Initialized
DEBUG - 2023-08-11 16:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:32:58 --> Controller Class Initialized
INFO - 2023-08-11 16:32:58 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:32:58 --> Helper loaded: form_helper
INFO - 2023-08-11 16:32:58 --> Form Validation Class Initialized
INFO - 2023-08-11 16:32:58 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_list.php
INFO - 2023-08-11 16:32:58 --> Final output sent to browser
DEBUG - 2023-08-11 16:32:58 --> Total execution time: 0.0459
INFO - 2023-08-11 16:33:18 --> Config Class Initialized
INFO - 2023-08-11 16:33:18 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:33:18 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:33:18 --> Utf8 Class Initialized
INFO - 2023-08-11 16:33:18 --> URI Class Initialized
INFO - 2023-08-11 16:33:18 --> Router Class Initialized
INFO - 2023-08-11 16:33:18 --> Output Class Initialized
INFO - 2023-08-11 16:33:18 --> Security Class Initialized
DEBUG - 2023-08-11 16:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:33:18 --> Input Class Initialized
INFO - 2023-08-11 16:33:18 --> Language Class Initialized
INFO - 2023-08-11 16:33:18 --> Loader Class Initialized
INFO - 2023-08-11 16:33:18 --> Helper loaded: url_helper
INFO - 2023-08-11 16:33:18 --> Helper loaded: file_helper
INFO - 2023-08-11 16:33:18 --> Database Driver Class Initialized
INFO - 2023-08-11 16:33:18 --> Email Class Initialized
DEBUG - 2023-08-11 16:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:33:18 --> Controller Class Initialized
INFO - 2023-08-11 16:33:18 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:33:18 --> Helper loaded: form_helper
INFO - 2023-08-11 16:33:18 --> Form Validation Class Initialized
INFO - 2023-08-11 16:33:18 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_list.php
INFO - 2023-08-11 16:33:18 --> Final output sent to browser
DEBUG - 2023-08-11 16:33:18 --> Total execution time: 0.1160
INFO - 2023-08-11 16:35:34 --> Config Class Initialized
INFO - 2023-08-11 16:35:34 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:35:34 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:35:34 --> Utf8 Class Initialized
INFO - 2023-08-11 16:35:34 --> URI Class Initialized
INFO - 2023-08-11 16:35:34 --> Router Class Initialized
INFO - 2023-08-11 16:35:34 --> Output Class Initialized
INFO - 2023-08-11 16:35:34 --> Security Class Initialized
DEBUG - 2023-08-11 16:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:35:34 --> Input Class Initialized
INFO - 2023-08-11 16:35:34 --> Language Class Initialized
INFO - 2023-08-11 16:35:34 --> Loader Class Initialized
INFO - 2023-08-11 16:35:34 --> Helper loaded: url_helper
INFO - 2023-08-11 16:35:34 --> Helper loaded: file_helper
INFO - 2023-08-11 16:35:34 --> Database Driver Class Initialized
INFO - 2023-08-11 16:35:34 --> Email Class Initialized
DEBUG - 2023-08-11 16:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:35:34 --> Controller Class Initialized
INFO - 2023-08-11 16:35:34 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:35:34 --> Helper loaded: form_helper
INFO - 2023-08-11 16:35:34 --> Form Validation Class Initialized
INFO - 2023-08-11 16:35:34 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_list.php
INFO - 2023-08-11 16:35:34 --> Final output sent to browser
DEBUG - 2023-08-11 16:35:34 --> Total execution time: 0.0994
INFO - 2023-08-11 16:35:38 --> Config Class Initialized
INFO - 2023-08-11 16:35:38 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:35:38 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:35:38 --> Utf8 Class Initialized
INFO - 2023-08-11 16:35:38 --> URI Class Initialized
INFO - 2023-08-11 16:35:38 --> Router Class Initialized
INFO - 2023-08-11 16:35:38 --> Output Class Initialized
INFO - 2023-08-11 16:35:38 --> Security Class Initialized
DEBUG - 2023-08-11 16:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:35:38 --> Input Class Initialized
INFO - 2023-08-11 16:35:38 --> Language Class Initialized
INFO - 2023-08-11 16:35:38 --> Loader Class Initialized
INFO - 2023-08-11 16:35:38 --> Helper loaded: url_helper
INFO - 2023-08-11 16:35:38 --> Helper loaded: file_helper
INFO - 2023-08-11 16:35:38 --> Database Driver Class Initialized
INFO - 2023-08-11 16:35:38 --> Email Class Initialized
DEBUG - 2023-08-11 16:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:35:38 --> Controller Class Initialized
INFO - 2023-08-11 16:35:38 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:35:38 --> Helper loaded: form_helper
INFO - 2023-08-11 16:35:38 --> Form Validation Class Initialized
INFO - 2023-08-11 16:35:38 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_edit.php
INFO - 2023-08-11 16:35:38 --> Final output sent to browser
DEBUG - 2023-08-11 16:35:38 --> Total execution time: 0.0783
INFO - 2023-08-11 16:35:39 --> Config Class Initialized
INFO - 2023-08-11 16:35:39 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:35:39 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:35:39 --> Utf8 Class Initialized
INFO - 2023-08-11 16:35:39 --> URI Class Initialized
INFO - 2023-08-11 16:35:39 --> Router Class Initialized
INFO - 2023-08-11 16:35:39 --> Output Class Initialized
INFO - 2023-08-11 16:35:39 --> Security Class Initialized
DEBUG - 2023-08-11 16:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:35:39 --> Input Class Initialized
INFO - 2023-08-11 16:35:39 --> Language Class Initialized
INFO - 2023-08-11 16:35:39 --> Loader Class Initialized
INFO - 2023-08-11 16:35:39 --> Helper loaded: url_helper
INFO - 2023-08-11 16:35:39 --> Helper loaded: file_helper
INFO - 2023-08-11 16:35:39 --> Database Driver Class Initialized
INFO - 2023-08-11 16:35:39 --> Email Class Initialized
DEBUG - 2023-08-11 16:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:35:39 --> Controller Class Initialized
INFO - 2023-08-11 16:35:39 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:35:39 --> Helper loaded: form_helper
INFO - 2023-08-11 16:35:39 --> Form Validation Class Initialized
ERROR - 2023-08-11 16:35:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\contact_edit.php 39
ERROR - 2023-08-11 16:35:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\contact_edit.php 46
ERROR - 2023-08-11 16:35:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\contact_edit.php 54
ERROR - 2023-08-11 16:35:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\contact_edit.php 64
ERROR - 2023-08-11 16:35:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\contact_edit.php 72
ERROR - 2023-08-11 16:35:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\contact_edit.php 82
ERROR - 2023-08-11 16:35:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\contact_edit.php 93
ERROR - 2023-08-11 16:35:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\contact_edit.php 94
ERROR - 2023-08-11 16:35:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\contact_edit.php 95
ERROR - 2023-08-11 16:35:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\contact_edit.php 104
INFO - 2023-08-11 16:35:39 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_edit.php
INFO - 2023-08-11 16:35:39 --> Final output sent to browser
DEBUG - 2023-08-11 16:35:39 --> Total execution time: 0.0623
INFO - 2023-08-11 16:35:52 --> Config Class Initialized
INFO - 2023-08-11 16:35:52 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:35:52 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:35:52 --> Utf8 Class Initialized
INFO - 2023-08-11 16:35:52 --> URI Class Initialized
INFO - 2023-08-11 16:35:52 --> Router Class Initialized
INFO - 2023-08-11 16:35:52 --> Output Class Initialized
INFO - 2023-08-11 16:35:52 --> Security Class Initialized
DEBUG - 2023-08-11 16:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:35:52 --> Input Class Initialized
INFO - 2023-08-11 16:35:52 --> Language Class Initialized
INFO - 2023-08-11 16:35:52 --> Loader Class Initialized
INFO - 2023-08-11 16:35:52 --> Helper loaded: url_helper
INFO - 2023-08-11 16:35:52 --> Helper loaded: file_helper
INFO - 2023-08-11 16:35:52 --> Database Driver Class Initialized
INFO - 2023-08-11 16:35:52 --> Email Class Initialized
DEBUG - 2023-08-11 16:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:35:52 --> Controller Class Initialized
INFO - 2023-08-11 16:35:52 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:35:52 --> Helper loaded: form_helper
INFO - 2023-08-11 16:35:52 --> Form Validation Class Initialized
INFO - 2023-08-11 16:35:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-11 16:35:52 --> Config Class Initialized
INFO - 2023-08-11 16:35:52 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:35:52 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:35:52 --> Utf8 Class Initialized
INFO - 2023-08-11 16:35:52 --> URI Class Initialized
INFO - 2023-08-11 16:35:52 --> Router Class Initialized
INFO - 2023-08-11 16:35:52 --> Output Class Initialized
INFO - 2023-08-11 16:35:52 --> Security Class Initialized
DEBUG - 2023-08-11 16:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:35:52 --> Input Class Initialized
INFO - 2023-08-11 16:35:52 --> Language Class Initialized
INFO - 2023-08-11 16:35:52 --> Loader Class Initialized
INFO - 2023-08-11 16:35:52 --> Helper loaded: url_helper
INFO - 2023-08-11 16:35:52 --> Helper loaded: file_helper
INFO - 2023-08-11 16:35:52 --> Database Driver Class Initialized
INFO - 2023-08-11 16:35:52 --> Email Class Initialized
DEBUG - 2023-08-11 16:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:35:52 --> Controller Class Initialized
INFO - 2023-08-11 16:35:52 --> Model "Contact_model" initialized
INFO - 2023-08-11 16:35:52 --> Helper loaded: form_helper
INFO - 2023-08-11 16:35:52 --> Form Validation Class Initialized
INFO - 2023-08-11 16:35:52 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_list.php
INFO - 2023-08-11 16:35:52 --> Final output sent to browser
DEBUG - 2023-08-11 16:35:52 --> Total execution time: 0.0752
INFO - 2023-08-11 16:36:38 --> Config Class Initialized
INFO - 2023-08-11 16:36:38 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:36:38 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:36:38 --> Utf8 Class Initialized
INFO - 2023-08-11 16:36:38 --> URI Class Initialized
INFO - 2023-08-11 16:36:38 --> Router Class Initialized
INFO - 2023-08-11 16:36:38 --> Output Class Initialized
INFO - 2023-08-11 16:36:38 --> Security Class Initialized
DEBUG - 2023-08-11 16:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:36:38 --> Input Class Initialized
INFO - 2023-08-11 16:36:38 --> Language Class Initialized
INFO - 2023-08-11 16:36:38 --> Loader Class Initialized
INFO - 2023-08-11 16:36:38 --> Helper loaded: url_helper
INFO - 2023-08-11 16:36:38 --> Helper loaded: file_helper
INFO - 2023-08-11 16:36:38 --> Database Driver Class Initialized
INFO - 2023-08-11 16:36:38 --> Email Class Initialized
DEBUG - 2023-08-11 16:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:36:38 --> Controller Class Initialized
INFO - 2023-08-11 16:36:38 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:36:38 --> Helper loaded: form_helper
INFO - 2023-08-11 16:36:38 --> Form Validation Class Initialized
INFO - 2023-08-11 16:36:42 --> Config Class Initialized
INFO - 2023-08-11 16:36:42 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:36:42 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:36:42 --> Utf8 Class Initialized
INFO - 2023-08-11 16:36:42 --> URI Class Initialized
INFO - 2023-08-11 16:36:42 --> Router Class Initialized
INFO - 2023-08-11 16:36:42 --> Output Class Initialized
INFO - 2023-08-11 16:36:42 --> Security Class Initialized
DEBUG - 2023-08-11 16:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:36:42 --> Input Class Initialized
INFO - 2023-08-11 16:36:42 --> Language Class Initialized
INFO - 2023-08-11 16:36:42 --> Loader Class Initialized
INFO - 2023-08-11 16:36:42 --> Helper loaded: url_helper
INFO - 2023-08-11 16:36:42 --> Helper loaded: file_helper
INFO - 2023-08-11 16:36:42 --> Database Driver Class Initialized
INFO - 2023-08-11 16:36:42 --> Email Class Initialized
DEBUG - 2023-08-11 16:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:36:42 --> Controller Class Initialized
INFO - 2023-08-11 16:36:42 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:36:42 --> Helper loaded: form_helper
INFO - 2023-08-11 16:36:42 --> Form Validation Class Initialized
INFO - 2023-08-11 16:36:42 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/social_media_create.php
INFO - 2023-08-11 16:36:42 --> Final output sent to browser
DEBUG - 2023-08-11 16:36:42 --> Total execution time: 0.1403
INFO - 2023-08-11 16:36:43 --> Config Class Initialized
INFO - 2023-08-11 16:36:43 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:36:43 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:36:43 --> Utf8 Class Initialized
INFO - 2023-08-11 16:36:43 --> URI Class Initialized
INFO - 2023-08-11 16:36:43 --> Router Class Initialized
INFO - 2023-08-11 16:36:43 --> Output Class Initialized
INFO - 2023-08-11 16:36:43 --> Security Class Initialized
DEBUG - 2023-08-11 16:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:36:43 --> Input Class Initialized
INFO - 2023-08-11 16:36:43 --> Language Class Initialized
ERROR - 2023-08-11 16:36:43 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-08-11 16:37:18 --> Config Class Initialized
INFO - 2023-08-11 16:37:18 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:37:18 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:37:18 --> Utf8 Class Initialized
INFO - 2023-08-11 16:37:18 --> URI Class Initialized
INFO - 2023-08-11 16:37:18 --> Router Class Initialized
INFO - 2023-08-11 16:37:18 --> Output Class Initialized
INFO - 2023-08-11 16:37:18 --> Security Class Initialized
DEBUG - 2023-08-11 16:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:37:18 --> Input Class Initialized
INFO - 2023-08-11 16:37:18 --> Language Class Initialized
INFO - 2023-08-11 16:37:18 --> Loader Class Initialized
INFO - 2023-08-11 16:37:18 --> Helper loaded: url_helper
INFO - 2023-08-11 16:37:18 --> Helper loaded: file_helper
INFO - 2023-08-11 16:37:18 --> Database Driver Class Initialized
INFO - 2023-08-11 16:37:18 --> Email Class Initialized
DEBUG - 2023-08-11 16:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:37:18 --> Controller Class Initialized
INFO - 2023-08-11 16:37:18 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:37:18 --> Helper loaded: form_helper
INFO - 2023-08-11 16:37:18 --> Form Validation Class Initialized
INFO - 2023-08-11 16:37:18 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/social_media_create.php
INFO - 2023-08-11 16:37:19 --> Final output sent to browser
DEBUG - 2023-08-11 16:37:19 --> Total execution time: 0.1527
INFO - 2023-08-11 16:37:21 --> Config Class Initialized
INFO - 2023-08-11 16:37:21 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:37:21 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:37:21 --> Utf8 Class Initialized
INFO - 2023-08-11 16:37:21 --> URI Class Initialized
INFO - 2023-08-11 16:37:21 --> Router Class Initialized
INFO - 2023-08-11 16:37:21 --> Output Class Initialized
INFO - 2023-08-11 16:37:21 --> Security Class Initialized
DEBUG - 2023-08-11 16:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:37:21 --> Input Class Initialized
INFO - 2023-08-11 16:37:21 --> Language Class Initialized
INFO - 2023-08-11 16:37:21 --> Loader Class Initialized
INFO - 2023-08-11 16:37:21 --> Helper loaded: url_helper
INFO - 2023-08-11 16:37:21 --> Helper loaded: file_helper
INFO - 2023-08-11 16:37:21 --> Database Driver Class Initialized
INFO - 2023-08-11 16:37:21 --> Email Class Initialized
DEBUG - 2023-08-11 16:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:37:21 --> Controller Class Initialized
INFO - 2023-08-11 16:37:21 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:37:21 --> Helper loaded: form_helper
INFO - 2023-08-11 16:37:21 --> Form Validation Class Initialized
INFO - 2023-08-11 16:37:21 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/social_media_create.php
INFO - 2023-08-11 16:37:21 --> Final output sent to browser
DEBUG - 2023-08-11 16:37:21 --> Total execution time: 0.0470
INFO - 2023-08-11 16:37:26 --> Config Class Initialized
INFO - 2023-08-11 16:37:26 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:37:26 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:37:26 --> Utf8 Class Initialized
INFO - 2023-08-11 16:37:26 --> URI Class Initialized
INFO - 2023-08-11 16:37:26 --> Router Class Initialized
INFO - 2023-08-11 16:37:26 --> Output Class Initialized
INFO - 2023-08-11 16:37:26 --> Security Class Initialized
DEBUG - 2023-08-11 16:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:37:26 --> Input Class Initialized
INFO - 2023-08-11 16:37:26 --> Language Class Initialized
INFO - 2023-08-11 16:37:26 --> Loader Class Initialized
INFO - 2023-08-11 16:37:26 --> Helper loaded: url_helper
INFO - 2023-08-11 16:37:26 --> Helper loaded: file_helper
INFO - 2023-08-11 16:37:26 --> Database Driver Class Initialized
INFO - 2023-08-11 16:37:26 --> Email Class Initialized
DEBUG - 2023-08-11 16:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:37:26 --> Controller Class Initialized
INFO - 2023-08-11 16:37:26 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:37:26 --> Helper loaded: form_helper
INFO - 2023-08-11 16:37:26 --> Form Validation Class Initialized
INFO - 2023-08-11 16:37:26 --> Config Class Initialized
INFO - 2023-08-11 16:37:26 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:37:26 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:37:26 --> Utf8 Class Initialized
INFO - 2023-08-11 16:37:26 --> URI Class Initialized
INFO - 2023-08-11 16:37:26 --> Router Class Initialized
INFO - 2023-08-11 16:37:26 --> Output Class Initialized
INFO - 2023-08-11 16:37:26 --> Security Class Initialized
DEBUG - 2023-08-11 16:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:37:26 --> Input Class Initialized
INFO - 2023-08-11 16:37:26 --> Language Class Initialized
INFO - 2023-08-11 16:37:26 --> Loader Class Initialized
INFO - 2023-08-11 16:37:26 --> Helper loaded: url_helper
INFO - 2023-08-11 16:37:26 --> Helper loaded: file_helper
INFO - 2023-08-11 16:37:26 --> Database Driver Class Initialized
INFO - 2023-08-11 16:37:26 --> Email Class Initialized
DEBUG - 2023-08-11 16:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:37:26 --> Controller Class Initialized
INFO - 2023-08-11 16:37:26 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:37:26 --> Helper loaded: form_helper
INFO - 2023-08-11 16:37:26 --> Form Validation Class Initialized
INFO - 2023-08-11 16:37:26 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/social_media_create.php
INFO - 2023-08-11 16:37:26 --> Final output sent to browser
DEBUG - 2023-08-11 16:37:26 --> Total execution time: 0.0486
INFO - 2023-08-11 16:38:58 --> Config Class Initialized
INFO - 2023-08-11 16:38:58 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:38:58 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:38:58 --> Utf8 Class Initialized
INFO - 2023-08-11 16:38:58 --> URI Class Initialized
INFO - 2023-08-11 16:38:58 --> Router Class Initialized
INFO - 2023-08-11 16:38:58 --> Output Class Initialized
INFO - 2023-08-11 16:38:58 --> Security Class Initialized
DEBUG - 2023-08-11 16:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:38:58 --> Input Class Initialized
INFO - 2023-08-11 16:38:58 --> Language Class Initialized
INFO - 2023-08-11 16:38:58 --> Loader Class Initialized
INFO - 2023-08-11 16:38:58 --> Helper loaded: url_helper
INFO - 2023-08-11 16:38:58 --> Helper loaded: file_helper
INFO - 2023-08-11 16:38:58 --> Database Driver Class Initialized
INFO - 2023-08-11 16:38:58 --> Email Class Initialized
DEBUG - 2023-08-11 16:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:38:58 --> Controller Class Initialized
INFO - 2023-08-11 16:38:58 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:38:58 --> Helper loaded: form_helper
INFO - 2023-08-11 16:38:58 --> Form Validation Class Initialized
INFO - 2023-08-11 16:38:58 --> Config Class Initialized
INFO - 2023-08-11 16:38:58 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:38:58 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:38:58 --> Utf8 Class Initialized
INFO - 2023-08-11 16:38:58 --> URI Class Initialized
INFO - 2023-08-11 16:38:58 --> Router Class Initialized
INFO - 2023-08-11 16:38:58 --> Output Class Initialized
INFO - 2023-08-11 16:38:58 --> Security Class Initialized
DEBUG - 2023-08-11 16:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:38:58 --> Input Class Initialized
INFO - 2023-08-11 16:38:58 --> Language Class Initialized
INFO - 2023-08-11 16:38:58 --> Loader Class Initialized
INFO - 2023-08-11 16:38:58 --> Helper loaded: url_helper
INFO - 2023-08-11 16:38:58 --> Helper loaded: file_helper
INFO - 2023-08-11 16:38:58 --> Database Driver Class Initialized
INFO - 2023-08-11 16:38:58 --> Email Class Initialized
DEBUG - 2023-08-11 16:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:38:58 --> Controller Class Initialized
INFO - 2023-08-11 16:38:58 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:38:58 --> Helper loaded: form_helper
INFO - 2023-08-11 16:38:58 --> Form Validation Class Initialized
INFO - 2023-08-11 16:38:58 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/social_media_create.php
INFO - 2023-08-11 16:38:58 --> Final output sent to browser
DEBUG - 2023-08-11 16:38:58 --> Total execution time: 0.1671
INFO - 2023-08-11 16:39:02 --> Config Class Initialized
INFO - 2023-08-11 16:39:02 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:39:02 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:39:02 --> Utf8 Class Initialized
INFO - 2023-08-11 16:39:02 --> URI Class Initialized
INFO - 2023-08-11 16:39:02 --> Router Class Initialized
INFO - 2023-08-11 16:39:02 --> Output Class Initialized
INFO - 2023-08-11 16:39:02 --> Security Class Initialized
DEBUG - 2023-08-11 16:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:39:02 --> Input Class Initialized
INFO - 2023-08-11 16:39:02 --> Language Class Initialized
INFO - 2023-08-11 16:39:02 --> Loader Class Initialized
INFO - 2023-08-11 16:39:02 --> Helper loaded: url_helper
INFO - 2023-08-11 16:39:02 --> Helper loaded: file_helper
INFO - 2023-08-11 16:39:02 --> Database Driver Class Initialized
INFO - 2023-08-11 16:39:02 --> Email Class Initialized
DEBUG - 2023-08-11 16:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:39:02 --> Controller Class Initialized
INFO - 2023-08-11 16:39:02 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:39:02 --> Helper loaded: form_helper
INFO - 2023-08-11 16:39:02 --> Form Validation Class Initialized
INFO - 2023-08-11 16:39:02 --> Config Class Initialized
INFO - 2023-08-11 16:39:02 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:39:02 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:39:02 --> Utf8 Class Initialized
INFO - 2023-08-11 16:39:02 --> URI Class Initialized
INFO - 2023-08-11 16:39:02 --> Router Class Initialized
INFO - 2023-08-11 16:39:02 --> Output Class Initialized
INFO - 2023-08-11 16:39:02 --> Security Class Initialized
DEBUG - 2023-08-11 16:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:39:02 --> Input Class Initialized
INFO - 2023-08-11 16:39:02 --> Language Class Initialized
INFO - 2023-08-11 16:39:02 --> Loader Class Initialized
INFO - 2023-08-11 16:39:02 --> Helper loaded: url_helper
INFO - 2023-08-11 16:39:02 --> Helper loaded: file_helper
INFO - 2023-08-11 16:39:02 --> Database Driver Class Initialized
INFO - 2023-08-11 16:39:02 --> Email Class Initialized
DEBUG - 2023-08-11 16:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:39:02 --> Controller Class Initialized
INFO - 2023-08-11 16:39:02 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:39:02 --> Helper loaded: form_helper
INFO - 2023-08-11 16:39:02 --> Form Validation Class Initialized
INFO - 2023-08-11 16:39:02 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/social_media_create.php
INFO - 2023-08-11 16:39:02 --> Final output sent to browser
DEBUG - 2023-08-11 16:39:02 --> Total execution time: 0.0538
INFO - 2023-08-11 16:39:08 --> Config Class Initialized
INFO - 2023-08-11 16:39:08 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:39:08 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:39:08 --> Utf8 Class Initialized
INFO - 2023-08-11 16:39:08 --> URI Class Initialized
INFO - 2023-08-11 16:39:08 --> Router Class Initialized
INFO - 2023-08-11 16:39:08 --> Output Class Initialized
INFO - 2023-08-11 16:39:08 --> Security Class Initialized
DEBUG - 2023-08-11 16:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:39:08 --> Input Class Initialized
INFO - 2023-08-11 16:39:08 --> Language Class Initialized
INFO - 2023-08-11 16:39:08 --> Loader Class Initialized
INFO - 2023-08-11 16:39:08 --> Helper loaded: url_helper
INFO - 2023-08-11 16:39:08 --> Helper loaded: file_helper
INFO - 2023-08-11 16:39:08 --> Database Driver Class Initialized
INFO - 2023-08-11 16:39:08 --> Email Class Initialized
DEBUG - 2023-08-11 16:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:39:08 --> Controller Class Initialized
INFO - 2023-08-11 16:39:08 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:39:08 --> Helper loaded: form_helper
INFO - 2023-08-11 16:39:08 --> Form Validation Class Initialized
INFO - 2023-08-11 16:39:08 --> Config Class Initialized
INFO - 2023-08-11 16:39:08 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:39:08 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:39:08 --> Utf8 Class Initialized
INFO - 2023-08-11 16:39:08 --> URI Class Initialized
INFO - 2023-08-11 16:39:08 --> Router Class Initialized
INFO - 2023-08-11 16:39:08 --> Output Class Initialized
INFO - 2023-08-11 16:39:08 --> Security Class Initialized
DEBUG - 2023-08-11 16:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:39:08 --> Input Class Initialized
INFO - 2023-08-11 16:39:08 --> Language Class Initialized
INFO - 2023-08-11 16:39:08 --> Loader Class Initialized
INFO - 2023-08-11 16:39:08 --> Helper loaded: url_helper
INFO - 2023-08-11 16:39:08 --> Helper loaded: file_helper
INFO - 2023-08-11 16:39:08 --> Database Driver Class Initialized
INFO - 2023-08-11 16:39:08 --> Email Class Initialized
DEBUG - 2023-08-11 16:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:39:08 --> Controller Class Initialized
INFO - 2023-08-11 16:39:08 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:39:08 --> Helper loaded: form_helper
INFO - 2023-08-11 16:39:08 --> Form Validation Class Initialized
INFO - 2023-08-11 16:39:08 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/social_media_create.php
INFO - 2023-08-11 16:39:08 --> Final output sent to browser
DEBUG - 2023-08-11 16:39:08 --> Total execution time: 0.0435
INFO - 2023-08-11 16:39:13 --> Config Class Initialized
INFO - 2023-08-11 16:39:13 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:39:13 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:39:13 --> Utf8 Class Initialized
INFO - 2023-08-11 16:39:13 --> URI Class Initialized
INFO - 2023-08-11 16:39:13 --> Router Class Initialized
INFO - 2023-08-11 16:39:13 --> Output Class Initialized
INFO - 2023-08-11 16:39:13 --> Security Class Initialized
DEBUG - 2023-08-11 16:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:39:13 --> Input Class Initialized
INFO - 2023-08-11 16:39:13 --> Language Class Initialized
ERROR - 2023-08-11 16:39:13 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:39:14 --> Config Class Initialized
INFO - 2023-08-11 16:39:14 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:39:14 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:39:14 --> Utf8 Class Initialized
INFO - 2023-08-11 16:39:14 --> URI Class Initialized
INFO - 2023-08-11 16:39:14 --> Router Class Initialized
INFO - 2023-08-11 16:39:14 --> Output Class Initialized
INFO - 2023-08-11 16:39:14 --> Security Class Initialized
DEBUG - 2023-08-11 16:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:39:14 --> Input Class Initialized
INFO - 2023-08-11 16:39:14 --> Language Class Initialized
ERROR - 2023-08-11 16:39:14 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:40:06 --> Config Class Initialized
INFO - 2023-08-11 16:40:06 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:40:06 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:40:06 --> Utf8 Class Initialized
INFO - 2023-08-11 16:40:06 --> URI Class Initialized
INFO - 2023-08-11 16:40:06 --> Router Class Initialized
INFO - 2023-08-11 16:40:06 --> Output Class Initialized
INFO - 2023-08-11 16:40:06 --> Security Class Initialized
DEBUG - 2023-08-11 16:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:40:06 --> Input Class Initialized
INFO - 2023-08-11 16:40:06 --> Language Class Initialized
INFO - 2023-08-11 16:40:06 --> Loader Class Initialized
INFO - 2023-08-11 16:40:06 --> Helper loaded: url_helper
INFO - 2023-08-11 16:40:06 --> Helper loaded: file_helper
INFO - 2023-08-11 16:40:06 --> Database Driver Class Initialized
INFO - 2023-08-11 16:40:06 --> Email Class Initialized
DEBUG - 2023-08-11 16:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:40:06 --> Controller Class Initialized
INFO - 2023-08-11 16:40:06 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:40:06 --> Helper loaded: form_helper
INFO - 2023-08-11 16:40:06 --> Form Validation Class Initialized
INFO - 2023-08-11 16:40:06 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/social_media_create.php
INFO - 2023-08-11 16:40:06 --> Final output sent to browser
DEBUG - 2023-08-11 16:40:06 --> Total execution time: 0.3407
INFO - 2023-08-11 16:40:07 --> Config Class Initialized
INFO - 2023-08-11 16:40:07 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:40:07 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:40:07 --> Utf8 Class Initialized
INFO - 2023-08-11 16:40:07 --> URI Class Initialized
INFO - 2023-08-11 16:40:07 --> Router Class Initialized
INFO - 2023-08-11 16:40:07 --> Output Class Initialized
INFO - 2023-08-11 16:40:07 --> Security Class Initialized
DEBUG - 2023-08-11 16:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:40:07 --> Input Class Initialized
INFO - 2023-08-11 16:40:08 --> Language Class Initialized
ERROR - 2023-08-11 16:40:08 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:40:08 --> Config Class Initialized
INFO - 2023-08-11 16:40:08 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:40:08 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:40:08 --> Utf8 Class Initialized
INFO - 2023-08-11 16:40:08 --> URI Class Initialized
INFO - 2023-08-11 16:40:08 --> Router Class Initialized
INFO - 2023-08-11 16:40:08 --> Output Class Initialized
INFO - 2023-08-11 16:40:08 --> Security Class Initialized
DEBUG - 2023-08-11 16:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:40:08 --> Input Class Initialized
INFO - 2023-08-11 16:40:08 --> Language Class Initialized
INFO - 2023-08-11 16:40:08 --> Loader Class Initialized
INFO - 2023-08-11 16:40:08 --> Helper loaded: url_helper
INFO - 2023-08-11 16:40:08 --> Helper loaded: file_helper
INFO - 2023-08-11 16:40:08 --> Database Driver Class Initialized
INFO - 2023-08-11 16:40:08 --> Email Class Initialized
DEBUG - 2023-08-11 16:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:40:08 --> Controller Class Initialized
INFO - 2023-08-11 16:40:08 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:40:08 --> Helper loaded: form_helper
INFO - 2023-08-11 16:40:08 --> Form Validation Class Initialized
INFO - 2023-08-11 16:40:08 --> Config Class Initialized
INFO - 2023-08-11 16:40:08 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:40:08 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:40:08 --> Utf8 Class Initialized
INFO - 2023-08-11 16:40:08 --> URI Class Initialized
INFO - 2023-08-11 16:40:08 --> Router Class Initialized
INFO - 2023-08-11 16:40:08 --> Output Class Initialized
INFO - 2023-08-11 16:40:08 --> Security Class Initialized
DEBUG - 2023-08-11 16:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:40:08 --> Input Class Initialized
INFO - 2023-08-11 16:40:08 --> Language Class Initialized
INFO - 2023-08-11 16:40:08 --> Loader Class Initialized
INFO - 2023-08-11 16:40:08 --> Helper loaded: url_helper
INFO - 2023-08-11 16:40:08 --> Helper loaded: file_helper
INFO - 2023-08-11 16:40:08 --> Database Driver Class Initialized
INFO - 2023-08-11 16:40:08 --> Email Class Initialized
DEBUG - 2023-08-11 16:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:40:08 --> Controller Class Initialized
INFO - 2023-08-11 16:40:08 --> Model "Social_media_model" initialized
INFO - 2023-08-11 16:40:08 --> Helper loaded: form_helper
INFO - 2023-08-11 16:40:08 --> Form Validation Class Initialized
INFO - 2023-08-11 16:40:08 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/social_media_create.php
INFO - 2023-08-11 16:40:08 --> Final output sent to browser
DEBUG - 2023-08-11 16:40:08 --> Total execution time: 0.0418
INFO - 2023-08-11 16:40:16 --> Config Class Initialized
INFO - 2023-08-11 16:40:16 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:40:16 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:40:16 --> Utf8 Class Initialized
INFO - 2023-08-11 16:40:16 --> URI Class Initialized
INFO - 2023-08-11 16:40:16 --> Router Class Initialized
INFO - 2023-08-11 16:40:16 --> Output Class Initialized
INFO - 2023-08-11 16:40:16 --> Security Class Initialized
DEBUG - 2023-08-11 16:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:40:16 --> Input Class Initialized
INFO - 2023-08-11 16:40:16 --> Language Class Initialized
INFO - 2023-08-11 16:40:16 --> Loader Class Initialized
INFO - 2023-08-11 16:40:16 --> Helper loaded: url_helper
INFO - 2023-08-11 16:40:16 --> Helper loaded: file_helper
INFO - 2023-08-11 16:40:16 --> Database Driver Class Initialized
INFO - 2023-08-11 16:40:16 --> Email Class Initialized
DEBUG - 2023-08-11 16:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:40:16 --> Controller Class Initialized
INFO - 2023-08-11 16:40:16 --> Model "Banner_model" initialized
INFO - 2023-08-11 16:40:16 --> Helper loaded: form_helper
INFO - 2023-08-11 16:40:16 --> Form Validation Class Initialized
INFO - 2023-08-11 16:40:16 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-11 16:40:16 --> Final output sent to browser
DEBUG - 2023-08-11 16:40:16 --> Total execution time: 0.0993
INFO - 2023-08-11 16:40:30 --> Config Class Initialized
INFO - 2023-08-11 16:40:30 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:40:30 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:40:30 --> Utf8 Class Initialized
INFO - 2023-08-11 16:40:30 --> URI Class Initialized
INFO - 2023-08-11 16:40:30 --> Router Class Initialized
INFO - 2023-08-11 16:40:30 --> Output Class Initialized
INFO - 2023-08-11 16:40:30 --> Security Class Initialized
DEBUG - 2023-08-11 16:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:40:30 --> Input Class Initialized
INFO - 2023-08-11 16:40:30 --> Language Class Initialized
INFO - 2023-08-11 16:40:30 --> Loader Class Initialized
INFO - 2023-08-11 16:40:30 --> Helper loaded: url_helper
INFO - 2023-08-11 16:40:30 --> Helper loaded: file_helper
INFO - 2023-08-11 16:40:30 --> Database Driver Class Initialized
INFO - 2023-08-11 16:40:30 --> Email Class Initialized
DEBUG - 2023-08-11 16:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:40:30 --> Controller Class Initialized
INFO - 2023-08-11 16:40:30 --> Model "Gallery_model" initialized
INFO - 2023-08-11 16:40:30 --> Helper loaded: form_helper
INFO - 2023-08-11 16:40:30 --> Form Validation Class Initialized
INFO - 2023-08-11 16:40:30 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-11 16:40:30 --> Final output sent to browser
DEBUG - 2023-08-11 16:40:30 --> Total execution time: 0.0959
INFO - 2023-08-11 16:40:37 --> Config Class Initialized
INFO - 2023-08-11 16:40:37 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:40:37 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:40:37 --> Utf8 Class Initialized
INFO - 2023-08-11 16:40:37 --> URI Class Initialized
INFO - 2023-08-11 16:40:37 --> Router Class Initialized
INFO - 2023-08-11 16:40:37 --> Output Class Initialized
INFO - 2023-08-11 16:40:37 --> Security Class Initialized
DEBUG - 2023-08-11 16:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:40:37 --> Input Class Initialized
INFO - 2023-08-11 16:40:37 --> Language Class Initialized
INFO - 2023-08-11 16:40:37 --> Loader Class Initialized
INFO - 2023-08-11 16:40:37 --> Helper loaded: url_helper
INFO - 2023-08-11 16:40:37 --> Helper loaded: file_helper
INFO - 2023-08-11 16:40:37 --> Database Driver Class Initialized
INFO - 2023-08-11 16:40:38 --> Email Class Initialized
DEBUG - 2023-08-11 16:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:40:38 --> Controller Class Initialized
INFO - 2023-08-11 16:40:38 --> Model "Gallery_model" initialized
INFO - 2023-08-11 16:40:38 --> Helper loaded: form_helper
INFO - 2023-08-11 16:40:38 --> Form Validation Class Initialized
INFO - 2023-08-11 16:40:38 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-11 16:40:38 --> Final output sent to browser
DEBUG - 2023-08-11 16:40:38 --> Total execution time: 0.0511
INFO - 2023-08-11 16:40:48 --> Config Class Initialized
INFO - 2023-08-11 16:40:48 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:40:48 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:40:48 --> Utf8 Class Initialized
INFO - 2023-08-11 16:40:48 --> URI Class Initialized
INFO - 2023-08-11 16:40:48 --> Router Class Initialized
INFO - 2023-08-11 16:40:48 --> Output Class Initialized
INFO - 2023-08-11 16:40:48 --> Security Class Initialized
DEBUG - 2023-08-11 16:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:40:48 --> Input Class Initialized
INFO - 2023-08-11 16:40:48 --> Language Class Initialized
INFO - 2023-08-11 16:40:48 --> Loader Class Initialized
INFO - 2023-08-11 16:40:48 --> Helper loaded: url_helper
INFO - 2023-08-11 16:40:48 --> Helper loaded: file_helper
INFO - 2023-08-11 16:40:48 --> Database Driver Class Initialized
INFO - 2023-08-11 16:40:48 --> Email Class Initialized
DEBUG - 2023-08-11 16:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:40:48 --> Controller Class Initialized
INFO - 2023-08-11 16:40:48 --> Model "Gallery_model" initialized
INFO - 2023-08-11 16:40:48 --> Helper loaded: form_helper
INFO - 2023-08-11 16:40:48 --> Form Validation Class Initialized
INFO - 2023-08-11 16:40:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-11 16:40:48 --> Config Class Initialized
INFO - 2023-08-11 16:40:48 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:40:48 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:40:48 --> Utf8 Class Initialized
INFO - 2023-08-11 16:40:48 --> URI Class Initialized
INFO - 2023-08-11 16:40:48 --> Router Class Initialized
INFO - 2023-08-11 16:40:48 --> Output Class Initialized
INFO - 2023-08-11 16:40:48 --> Security Class Initialized
DEBUG - 2023-08-11 16:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:40:48 --> Input Class Initialized
INFO - 2023-08-11 16:40:48 --> Language Class Initialized
INFO - 2023-08-11 16:40:48 --> Loader Class Initialized
INFO - 2023-08-11 16:40:48 --> Helper loaded: url_helper
INFO - 2023-08-11 16:40:48 --> Helper loaded: file_helper
INFO - 2023-08-11 16:40:48 --> Database Driver Class Initialized
INFO - 2023-08-11 16:40:48 --> Email Class Initialized
DEBUG - 2023-08-11 16:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:40:49 --> Controller Class Initialized
INFO - 2023-08-11 16:40:49 --> Model "Gallery_model" initialized
INFO - 2023-08-11 16:40:49 --> Helper loaded: form_helper
INFO - 2023-08-11 16:40:49 --> Form Validation Class Initialized
INFO - 2023-08-11 16:40:49 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-11 16:40:49 --> Final output sent to browser
DEBUG - 2023-08-11 16:40:49 --> Total execution time: 0.0637
INFO - 2023-08-11 16:41:03 --> Config Class Initialized
INFO - 2023-08-11 16:41:03 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:41:03 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:41:03 --> Utf8 Class Initialized
INFO - 2023-08-11 16:41:03 --> URI Class Initialized
INFO - 2023-08-11 16:41:03 --> Router Class Initialized
INFO - 2023-08-11 16:41:03 --> Output Class Initialized
INFO - 2023-08-11 16:41:03 --> Security Class Initialized
DEBUG - 2023-08-11 16:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:41:03 --> Input Class Initialized
INFO - 2023-08-11 16:41:03 --> Language Class Initialized
INFO - 2023-08-11 16:41:03 --> Loader Class Initialized
INFO - 2023-08-11 16:41:03 --> Helper loaded: url_helper
INFO - 2023-08-11 16:41:03 --> Helper loaded: file_helper
INFO - 2023-08-11 16:41:03 --> Database Driver Class Initialized
INFO - 2023-08-11 16:41:03 --> Email Class Initialized
DEBUG - 2023-08-11 16:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:41:03 --> Controller Class Initialized
INFO - 2023-08-11 16:41:03 --> Model "Gallery_model" initialized
INFO - 2023-08-11 16:41:03 --> Helper loaded: form_helper
INFO - 2023-08-11 16:41:03 --> Form Validation Class Initialized
INFO - 2023-08-11 16:41:03 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-11 16:41:03 --> Final output sent to browser
DEBUG - 2023-08-11 16:41:03 --> Total execution time: 0.0624
INFO - 2023-08-11 16:41:37 --> Config Class Initialized
INFO - 2023-08-11 16:41:37 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:41:37 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:41:37 --> Utf8 Class Initialized
INFO - 2023-08-11 16:41:37 --> URI Class Initialized
INFO - 2023-08-11 16:41:37 --> Router Class Initialized
INFO - 2023-08-11 16:41:37 --> Output Class Initialized
INFO - 2023-08-11 16:41:37 --> Security Class Initialized
DEBUG - 2023-08-11 16:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:41:37 --> Input Class Initialized
INFO - 2023-08-11 16:41:37 --> Language Class Initialized
INFO - 2023-08-11 16:41:37 --> Loader Class Initialized
INFO - 2023-08-11 16:41:37 --> Helper loaded: url_helper
INFO - 2023-08-11 16:41:37 --> Helper loaded: file_helper
INFO - 2023-08-11 16:41:37 --> Database Driver Class Initialized
INFO - 2023-08-11 16:41:37 --> Email Class Initialized
DEBUG - 2023-08-11 16:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:41:37 --> Controller Class Initialized
INFO - 2023-08-11 16:41:37 --> Model "Gallery_model" initialized
INFO - 2023-08-11 16:41:37 --> Helper loaded: form_helper
INFO - 2023-08-11 16:41:37 --> Form Validation Class Initialized
INFO - 2023-08-11 16:41:37 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-11 16:41:37 --> Final output sent to browser
DEBUG - 2023-08-11 16:41:37 --> Total execution time: 0.0732
INFO - 2023-08-11 16:41:39 --> Config Class Initialized
INFO - 2023-08-11 16:41:39 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:41:39 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:41:39 --> Utf8 Class Initialized
INFO - 2023-08-11 16:41:39 --> URI Class Initialized
INFO - 2023-08-11 16:41:39 --> Router Class Initialized
INFO - 2023-08-11 16:41:39 --> Output Class Initialized
INFO - 2023-08-11 16:41:39 --> Security Class Initialized
DEBUG - 2023-08-11 16:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:41:39 --> Input Class Initialized
INFO - 2023-08-11 16:41:39 --> Language Class Initialized
INFO - 2023-08-11 16:41:39 --> Loader Class Initialized
INFO - 2023-08-11 16:41:39 --> Helper loaded: url_helper
INFO - 2023-08-11 16:41:39 --> Helper loaded: file_helper
INFO - 2023-08-11 16:41:39 --> Database Driver Class Initialized
INFO - 2023-08-11 16:41:39 --> Email Class Initialized
DEBUG - 2023-08-11 16:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:41:39 --> Controller Class Initialized
INFO - 2023-08-11 16:41:39 --> Model "Gallery_model" initialized
INFO - 2023-08-11 16:41:39 --> Helper loaded: form_helper
INFO - 2023-08-11 16:41:39 --> Form Validation Class Initialized
INFO - 2023-08-11 16:41:39 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-11 16:41:39 --> Final output sent to browser
DEBUG - 2023-08-11 16:41:39 --> Total execution time: 0.0496
INFO - 2023-08-11 16:41:40 --> Config Class Initialized
INFO - 2023-08-11 16:41:40 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:41:40 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:41:40 --> Utf8 Class Initialized
INFO - 2023-08-11 16:41:40 --> URI Class Initialized
INFO - 2023-08-11 16:41:40 --> Router Class Initialized
INFO - 2023-08-11 16:41:40 --> Output Class Initialized
INFO - 2023-08-11 16:41:40 --> Security Class Initialized
DEBUG - 2023-08-11 16:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:41:40 --> Input Class Initialized
INFO - 2023-08-11 16:41:40 --> Language Class Initialized
INFO - 2023-08-11 16:41:40 --> Loader Class Initialized
INFO - 2023-08-11 16:41:40 --> Helper loaded: url_helper
INFO - 2023-08-11 16:41:40 --> Helper loaded: file_helper
INFO - 2023-08-11 16:41:40 --> Database Driver Class Initialized
INFO - 2023-08-11 16:41:40 --> Email Class Initialized
DEBUG - 2023-08-11 16:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:41:40 --> Controller Class Initialized
INFO - 2023-08-11 16:41:40 --> Model "Gallery_model" initialized
INFO - 2023-08-11 16:41:40 --> Helper loaded: form_helper
INFO - 2023-08-11 16:41:40 --> Form Validation Class Initialized
ERROR - 2023-08-11 16:41:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-11 16:41:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-11 16:41:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 59
ERROR - 2023-08-11 16:41:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-11 16:41:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 61
ERROR - 2023-08-11 16:41:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 74
ERROR - 2023-08-11 16:41:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 75
ERROR - 2023-08-11 16:41:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 76
ERROR - 2023-08-11 16:41:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 87
ERROR - 2023-08-11 16:41:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 105
ERROR - 2023-08-11 16:41:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 116
INFO - 2023-08-11 16:41:40 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-11 16:41:40 --> Final output sent to browser
DEBUG - 2023-08-11 16:41:40 --> Total execution time: 0.0466
INFO - 2023-08-11 16:41:46 --> Config Class Initialized
INFO - 2023-08-11 16:41:46 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:41:46 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:41:46 --> Utf8 Class Initialized
INFO - 2023-08-11 16:41:46 --> URI Class Initialized
INFO - 2023-08-11 16:41:46 --> Router Class Initialized
INFO - 2023-08-11 16:41:46 --> Output Class Initialized
INFO - 2023-08-11 16:41:46 --> Security Class Initialized
DEBUG - 2023-08-11 16:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:41:46 --> Input Class Initialized
INFO - 2023-08-11 16:41:46 --> Language Class Initialized
INFO - 2023-08-11 16:41:46 --> Loader Class Initialized
INFO - 2023-08-11 16:41:46 --> Helper loaded: url_helper
INFO - 2023-08-11 16:41:46 --> Helper loaded: file_helper
INFO - 2023-08-11 16:41:46 --> Database Driver Class Initialized
INFO - 2023-08-11 16:41:46 --> Email Class Initialized
DEBUG - 2023-08-11 16:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:41:46 --> Controller Class Initialized
INFO - 2023-08-11 16:41:46 --> Model "Gallery_model" initialized
INFO - 2023-08-11 16:41:46 --> Helper loaded: form_helper
INFO - 2023-08-11 16:41:46 --> Form Validation Class Initialized
INFO - 2023-08-11 16:41:46 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-11 16:41:46 --> Final output sent to browser
DEBUG - 2023-08-11 16:41:46 --> Total execution time: 0.0510
INFO - 2023-08-11 16:41:49 --> Config Class Initialized
INFO - 2023-08-11 16:41:49 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:41:49 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:41:49 --> Utf8 Class Initialized
INFO - 2023-08-11 16:41:49 --> URI Class Initialized
INFO - 2023-08-11 16:41:49 --> Router Class Initialized
INFO - 2023-08-11 16:41:49 --> Output Class Initialized
INFO - 2023-08-11 16:41:49 --> Security Class Initialized
DEBUG - 2023-08-11 16:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:41:49 --> Input Class Initialized
INFO - 2023-08-11 16:41:49 --> Language Class Initialized
INFO - 2023-08-11 16:41:49 --> Loader Class Initialized
INFO - 2023-08-11 16:41:49 --> Helper loaded: url_helper
INFO - 2023-08-11 16:41:49 --> Helper loaded: file_helper
INFO - 2023-08-11 16:41:49 --> Database Driver Class Initialized
INFO - 2023-08-11 16:41:49 --> Email Class Initialized
DEBUG - 2023-08-11 16:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:41:49 --> Controller Class Initialized
INFO - 2023-08-11 16:41:49 --> Model "Gallery_model" initialized
INFO - 2023-08-11 16:41:49 --> Helper loaded: form_helper
INFO - 2023-08-11 16:41:49 --> Form Validation Class Initialized
INFO - 2023-08-11 16:41:49 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-11 16:41:49 --> Final output sent to browser
DEBUG - 2023-08-11 16:41:49 --> Total execution time: 0.0535
INFO - 2023-08-11 16:42:46 --> Config Class Initialized
INFO - 2023-08-11 16:42:46 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:42:46 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:42:46 --> Utf8 Class Initialized
INFO - 2023-08-11 16:42:46 --> URI Class Initialized
INFO - 2023-08-11 16:42:46 --> Router Class Initialized
INFO - 2023-08-11 16:42:46 --> Output Class Initialized
INFO - 2023-08-11 16:42:46 --> Security Class Initialized
DEBUG - 2023-08-11 16:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:42:46 --> Input Class Initialized
INFO - 2023-08-11 16:42:46 --> Language Class Initialized
INFO - 2023-08-11 16:42:46 --> Loader Class Initialized
INFO - 2023-08-11 16:42:46 --> Helper loaded: url_helper
INFO - 2023-08-11 16:42:46 --> Helper loaded: file_helper
INFO - 2023-08-11 16:42:46 --> Database Driver Class Initialized
INFO - 2023-08-11 16:42:46 --> Email Class Initialized
DEBUG - 2023-08-11 16:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:42:46 --> Controller Class Initialized
INFO - 2023-08-11 16:42:46 --> Model "User_model" initialized
INFO - 2023-08-11 16:42:46 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/login.php
INFO - 2023-08-11 16:42:46 --> Final output sent to browser
DEBUG - 2023-08-11 16:42:46 --> Total execution time: 0.0601
INFO - 2023-08-11 16:42:57 --> Config Class Initialized
INFO - 2023-08-11 16:42:57 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:42:57 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:42:57 --> Utf8 Class Initialized
INFO - 2023-08-11 16:42:57 --> URI Class Initialized
INFO - 2023-08-11 16:42:57 --> Router Class Initialized
INFO - 2023-08-11 16:42:57 --> Output Class Initialized
INFO - 2023-08-11 16:42:57 --> Security Class Initialized
DEBUG - 2023-08-11 16:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:42:57 --> Input Class Initialized
INFO - 2023-08-11 16:42:57 --> Language Class Initialized
INFO - 2023-08-11 16:42:57 --> Loader Class Initialized
INFO - 2023-08-11 16:42:57 --> Helper loaded: url_helper
INFO - 2023-08-11 16:42:57 --> Helper loaded: file_helper
INFO - 2023-08-11 16:42:57 --> Database Driver Class Initialized
INFO - 2023-08-11 16:42:57 --> Email Class Initialized
DEBUG - 2023-08-11 16:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:42:57 --> Controller Class Initialized
INFO - 2023-08-11 16:42:57 --> Model "User_model" initialized
INFO - 2023-08-11 16:42:57 --> Config Class Initialized
INFO - 2023-08-11 16:42:57 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:42:57 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:42:57 --> Utf8 Class Initialized
INFO - 2023-08-11 16:42:57 --> URI Class Initialized
INFO - 2023-08-11 16:42:57 --> Router Class Initialized
INFO - 2023-08-11 16:42:57 --> Output Class Initialized
INFO - 2023-08-11 16:42:57 --> Security Class Initialized
DEBUG - 2023-08-11 16:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:42:57 --> Input Class Initialized
INFO - 2023-08-11 16:42:57 --> Language Class Initialized
ERROR - 2023-08-11 16:42:57 --> 404 Page Not Found: admin/Dashboard/index
INFO - 2023-08-11 16:47:56 --> Config Class Initialized
INFO - 2023-08-11 16:47:56 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:47:56 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:47:56 --> Utf8 Class Initialized
INFO - 2023-08-11 16:47:56 --> URI Class Initialized
INFO - 2023-08-11 16:47:56 --> Router Class Initialized
INFO - 2023-08-11 16:47:56 --> Output Class Initialized
INFO - 2023-08-11 16:47:56 --> Security Class Initialized
DEBUG - 2023-08-11 16:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:47:56 --> Input Class Initialized
INFO - 2023-08-11 16:47:56 --> Language Class Initialized
ERROR - 2023-08-11 16:47:56 --> 404 Page Not Found: admin/Dashboard/index
INFO - 2023-08-11 16:47:57 --> Config Class Initialized
INFO - 2023-08-11 16:47:57 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:47:57 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:47:57 --> Utf8 Class Initialized
INFO - 2023-08-11 16:47:57 --> URI Class Initialized
INFO - 2023-08-11 16:47:57 --> Router Class Initialized
INFO - 2023-08-11 16:47:57 --> Output Class Initialized
INFO - 2023-08-11 16:47:57 --> Security Class Initialized
DEBUG - 2023-08-11 16:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:47:57 --> Input Class Initialized
INFO - 2023-08-11 16:47:57 --> Language Class Initialized
ERROR - 2023-08-11 16:47:57 --> 404 Page Not Found: admin/Dashboard/index
INFO - 2023-08-11 16:49:40 --> Config Class Initialized
INFO - 2023-08-11 16:49:40 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:49:40 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:49:40 --> Utf8 Class Initialized
INFO - 2023-08-11 16:49:40 --> URI Class Initialized
INFO - 2023-08-11 16:49:40 --> Router Class Initialized
INFO - 2023-08-11 16:49:40 --> Output Class Initialized
INFO - 2023-08-11 16:49:40 --> Security Class Initialized
DEBUG - 2023-08-11 16:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:49:40 --> Input Class Initialized
INFO - 2023-08-11 16:49:40 --> Language Class Initialized
INFO - 2023-08-11 16:49:40 --> Loader Class Initialized
INFO - 2023-08-11 16:49:40 --> Helper loaded: url_helper
INFO - 2023-08-11 16:49:40 --> Helper loaded: file_helper
INFO - 2023-08-11 16:49:40 --> Database Driver Class Initialized
INFO - 2023-08-11 16:49:40 --> Email Class Initialized
DEBUG - 2023-08-11 16:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:49:40 --> Controller Class Initialized
INFO - 2023-08-11 16:49:40 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/dashboard.php
INFO - 2023-08-11 16:49:40 --> Final output sent to browser
DEBUG - 2023-08-11 16:49:40 --> Total execution time: 0.3869
INFO - 2023-08-11 16:49:55 --> Config Class Initialized
INFO - 2023-08-11 16:49:55 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:49:55 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:49:55 --> Utf8 Class Initialized
INFO - 2023-08-11 16:49:55 --> URI Class Initialized
INFO - 2023-08-11 16:49:55 --> Router Class Initialized
INFO - 2023-08-11 16:49:55 --> Output Class Initialized
INFO - 2023-08-11 16:49:55 --> Security Class Initialized
DEBUG - 2023-08-11 16:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:49:55 --> Input Class Initialized
INFO - 2023-08-11 16:49:55 --> Language Class Initialized
INFO - 2023-08-11 16:49:55 --> Loader Class Initialized
INFO - 2023-08-11 16:49:55 --> Helper loaded: url_helper
INFO - 2023-08-11 16:49:55 --> Helper loaded: file_helper
INFO - 2023-08-11 16:49:55 --> Database Driver Class Initialized
INFO - 2023-08-11 16:49:55 --> Email Class Initialized
DEBUG - 2023-08-11 16:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:49:56 --> Controller Class Initialized
INFO - 2023-08-11 16:49:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/dashboard.php
INFO - 2023-08-11 16:49:56 --> Final output sent to browser
DEBUG - 2023-08-11 16:49:56 --> Total execution time: 0.0351
INFO - 2023-08-11 16:49:58 --> Config Class Initialized
INFO - 2023-08-11 16:49:58 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:49:58 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:49:58 --> Utf8 Class Initialized
INFO - 2023-08-11 16:49:58 --> URI Class Initialized
INFO - 2023-08-11 16:49:58 --> Router Class Initialized
INFO - 2023-08-11 16:49:58 --> Output Class Initialized
INFO - 2023-08-11 16:49:58 --> Security Class Initialized
DEBUG - 2023-08-11 16:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:49:58 --> Input Class Initialized
INFO - 2023-08-11 16:49:58 --> Language Class Initialized
INFO - 2023-08-11 16:49:58 --> Loader Class Initialized
INFO - 2023-08-11 16:49:58 --> Helper loaded: url_helper
INFO - 2023-08-11 16:49:58 --> Helper loaded: file_helper
INFO - 2023-08-11 16:49:58 --> Database Driver Class Initialized
INFO - 2023-08-11 16:49:58 --> Email Class Initialized
DEBUG - 2023-08-11 16:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:49:58 --> Controller Class Initialized
INFO - 2023-08-11 16:49:58 --> Model "Banner_model" initialized
INFO - 2023-08-11 16:49:58 --> Helper loaded: form_helper
INFO - 2023-08-11 16:49:58 --> Form Validation Class Initialized
INFO - 2023-08-11 16:49:58 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-11 16:49:58 --> Final output sent to browser
DEBUG - 2023-08-11 16:49:58 --> Total execution time: 0.0464
INFO - 2023-08-11 16:50:51 --> Config Class Initialized
INFO - 2023-08-11 16:50:51 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:50:51 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:50:51 --> Utf8 Class Initialized
INFO - 2023-08-11 16:50:51 --> URI Class Initialized
INFO - 2023-08-11 16:50:51 --> Router Class Initialized
INFO - 2023-08-11 16:50:51 --> Output Class Initialized
INFO - 2023-08-11 16:50:51 --> Security Class Initialized
DEBUG - 2023-08-11 16:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:50:51 --> Input Class Initialized
INFO - 2023-08-11 16:50:51 --> Language Class Initialized
INFO - 2023-08-11 16:50:51 --> Loader Class Initialized
INFO - 2023-08-11 16:50:51 --> Helper loaded: url_helper
INFO - 2023-08-11 16:50:51 --> Helper loaded: file_helper
INFO - 2023-08-11 16:50:51 --> Database Driver Class Initialized
INFO - 2023-08-11 16:50:51 --> Email Class Initialized
DEBUG - 2023-08-11 16:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:50:51 --> Controller Class Initialized
INFO - 2023-08-11 16:50:51 --> Model "Banner_model" initialized
INFO - 2023-08-11 16:50:51 --> Helper loaded: form_helper
INFO - 2023-08-11 16:50:51 --> Form Validation Class Initialized
INFO - 2023-08-11 16:50:52 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-11 16:50:52 --> Final output sent to browser
DEBUG - 2023-08-11 16:50:52 --> Total execution time: 0.0892
INFO - 2023-08-11 16:51:00 --> Config Class Initialized
INFO - 2023-08-11 16:51:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:51:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:51:00 --> Utf8 Class Initialized
INFO - 2023-08-11 16:51:00 --> URI Class Initialized
INFO - 2023-08-11 16:51:00 --> Router Class Initialized
INFO - 2023-08-11 16:51:00 --> Output Class Initialized
INFO - 2023-08-11 16:51:00 --> Security Class Initialized
DEBUG - 2023-08-11 16:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:51:00 --> Input Class Initialized
INFO - 2023-08-11 16:51:00 --> Language Class Initialized
ERROR - 2023-08-11 16:51:00 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:51:00 --> Config Class Initialized
INFO - 2023-08-11 16:51:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:51:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:51:00 --> Utf8 Class Initialized
INFO - 2023-08-11 16:51:00 --> URI Class Initialized
INFO - 2023-08-11 16:51:00 --> Router Class Initialized
INFO - 2023-08-11 16:51:00 --> Output Class Initialized
INFO - 2023-08-11 16:51:00 --> Security Class Initialized
DEBUG - 2023-08-11 16:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:51:00 --> Input Class Initialized
INFO - 2023-08-11 16:51:00 --> Language Class Initialized
ERROR - 2023-08-11 16:51:00 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:51:48 --> Config Class Initialized
INFO - 2023-08-11 16:51:48 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:51:48 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:51:48 --> Utf8 Class Initialized
INFO - 2023-08-11 16:51:48 --> URI Class Initialized
INFO - 2023-08-11 16:51:48 --> Router Class Initialized
INFO - 2023-08-11 16:51:48 --> Output Class Initialized
INFO - 2023-08-11 16:51:48 --> Security Class Initialized
DEBUG - 2023-08-11 16:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:51:48 --> Input Class Initialized
INFO - 2023-08-11 16:51:48 --> Language Class Initialized
INFO - 2023-08-11 16:51:48 --> Loader Class Initialized
INFO - 2023-08-11 16:51:48 --> Helper loaded: url_helper
INFO - 2023-08-11 16:51:48 --> Helper loaded: file_helper
INFO - 2023-08-11 16:51:48 --> Database Driver Class Initialized
INFO - 2023-08-11 16:51:48 --> Email Class Initialized
DEBUG - 2023-08-11 16:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:51:48 --> Controller Class Initialized
INFO - 2023-08-11 16:51:48 --> Model "Banner_model" initialized
INFO - 2023-08-11 16:51:48 --> Helper loaded: form_helper
INFO - 2023-08-11 16:51:48 --> Form Validation Class Initialized
INFO - 2023-08-11 16:51:48 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-11 16:51:48 --> Final output sent to browser
DEBUG - 2023-08-11 16:51:48 --> Total execution time: 0.1775
INFO - 2023-08-11 16:51:48 --> Config Class Initialized
INFO - 2023-08-11 16:51:48 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:51:48 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:51:48 --> Utf8 Class Initialized
INFO - 2023-08-11 16:51:48 --> URI Class Initialized
INFO - 2023-08-11 16:51:48 --> Router Class Initialized
INFO - 2023-08-11 16:51:48 --> Output Class Initialized
INFO - 2023-08-11 16:51:48 --> Security Class Initialized
DEBUG - 2023-08-11 16:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:51:48 --> Input Class Initialized
INFO - 2023-08-11 16:51:48 --> Language Class Initialized
ERROR - 2023-08-11 16:51:48 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:51:48 --> Config Class Initialized
INFO - 2023-08-11 16:51:48 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:51:48 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:51:48 --> Utf8 Class Initialized
INFO - 2023-08-11 16:51:48 --> URI Class Initialized
INFO - 2023-08-11 16:51:48 --> Router Class Initialized
INFO - 2023-08-11 16:51:48 --> Output Class Initialized
INFO - 2023-08-11 16:51:48 --> Security Class Initialized
DEBUG - 2023-08-11 16:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:51:49 --> Input Class Initialized
INFO - 2023-08-11 16:51:50 --> Language Class Initialized
ERROR - 2023-08-11 16:51:50 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:51:57 --> Config Class Initialized
INFO - 2023-08-11 16:51:57 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:51:57 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:51:57 --> Utf8 Class Initialized
INFO - 2023-08-11 16:51:57 --> URI Class Initialized
INFO - 2023-08-11 16:51:57 --> Router Class Initialized
INFO - 2023-08-11 16:51:57 --> Output Class Initialized
INFO - 2023-08-11 16:51:57 --> Security Class Initialized
DEBUG - 2023-08-11 16:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:51:57 --> Input Class Initialized
INFO - 2023-08-11 16:51:57 --> Language Class Initialized
INFO - 2023-08-11 16:51:57 --> Loader Class Initialized
INFO - 2023-08-11 16:51:57 --> Helper loaded: url_helper
INFO - 2023-08-11 16:51:57 --> Helper loaded: file_helper
INFO - 2023-08-11 16:51:58 --> Database Driver Class Initialized
INFO - 2023-08-11 16:51:58 --> Email Class Initialized
DEBUG - 2023-08-11 16:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:51:58 --> Controller Class Initialized
INFO - 2023-08-11 16:51:58 --> Model "Banner_model" initialized
INFO - 2023-08-11 16:51:58 --> Helper loaded: form_helper
INFO - 2023-08-11 16:51:58 --> Form Validation Class Initialized
INFO - 2023-08-11 16:51:58 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-11 16:51:58 --> Final output sent to browser
DEBUG - 2023-08-11 16:51:58 --> Total execution time: 0.1202
INFO - 2023-08-11 16:52:06 --> Config Class Initialized
INFO - 2023-08-11 16:52:06 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:52:06 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:52:06 --> Utf8 Class Initialized
INFO - 2023-08-11 16:52:06 --> URI Class Initialized
INFO - 2023-08-11 16:52:06 --> Router Class Initialized
INFO - 2023-08-11 16:52:06 --> Output Class Initialized
INFO - 2023-08-11 16:52:06 --> Security Class Initialized
DEBUG - 2023-08-11 16:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:52:06 --> Input Class Initialized
INFO - 2023-08-11 16:52:06 --> Language Class Initialized
INFO - 2023-08-11 16:52:06 --> Loader Class Initialized
INFO - 2023-08-11 16:52:06 --> Helper loaded: url_helper
INFO - 2023-08-11 16:52:06 --> Helper loaded: file_helper
INFO - 2023-08-11 16:52:06 --> Database Driver Class Initialized
INFO - 2023-08-11 16:52:06 --> Email Class Initialized
DEBUG - 2023-08-11 16:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:52:06 --> Controller Class Initialized
INFO - 2023-08-11 16:52:06 --> Model "Banner_model" initialized
INFO - 2023-08-11 16:52:06 --> Helper loaded: form_helper
INFO - 2023-08-11 16:52:06 --> Form Validation Class Initialized
INFO - 2023-08-11 16:52:06 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-11 16:52:06 --> Final output sent to browser
DEBUG - 2023-08-11 16:52:06 --> Total execution time: 0.0938
INFO - 2023-08-11 16:52:12 --> Config Class Initialized
INFO - 2023-08-11 16:52:12 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:52:12 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:52:12 --> Utf8 Class Initialized
INFO - 2023-08-11 16:52:12 --> URI Class Initialized
INFO - 2023-08-11 16:52:12 --> Router Class Initialized
INFO - 2023-08-11 16:52:12 --> Output Class Initialized
INFO - 2023-08-11 16:52:12 --> Security Class Initialized
DEBUG - 2023-08-11 16:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:52:12 --> Input Class Initialized
INFO - 2023-08-11 16:52:12 --> Language Class Initialized
INFO - 2023-08-11 16:52:12 --> Loader Class Initialized
INFO - 2023-08-11 16:52:12 --> Helper loaded: url_helper
INFO - 2023-08-11 16:52:12 --> Helper loaded: file_helper
INFO - 2023-08-11 16:52:12 --> Database Driver Class Initialized
INFO - 2023-08-11 16:52:12 --> Email Class Initialized
DEBUG - 2023-08-11 16:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:52:12 --> Controller Class Initialized
INFO - 2023-08-11 16:52:12 --> Model "Banner_model" initialized
INFO - 2023-08-11 16:52:12 --> Helper loaded: form_helper
INFO - 2023-08-11 16:52:12 --> Form Validation Class Initialized
INFO - 2023-08-11 16:52:12 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-11 16:52:12 --> Final output sent to browser
DEBUG - 2023-08-11 16:52:12 --> Total execution time: 0.0523
INFO - 2023-08-11 16:52:45 --> Config Class Initialized
INFO - 2023-08-11 16:52:45 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:52:45 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:52:45 --> Utf8 Class Initialized
INFO - 2023-08-11 16:52:45 --> URI Class Initialized
INFO - 2023-08-11 16:52:45 --> Router Class Initialized
INFO - 2023-08-11 16:52:45 --> Output Class Initialized
INFO - 2023-08-11 16:52:45 --> Security Class Initialized
DEBUG - 2023-08-11 16:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:52:45 --> Input Class Initialized
INFO - 2023-08-11 16:52:45 --> Language Class Initialized
INFO - 2023-08-11 16:52:45 --> Loader Class Initialized
INFO - 2023-08-11 16:52:45 --> Helper loaded: url_helper
INFO - 2023-08-11 16:52:45 --> Helper loaded: file_helper
INFO - 2023-08-11 16:52:45 --> Database Driver Class Initialized
INFO - 2023-08-11 16:52:45 --> Email Class Initialized
DEBUG - 2023-08-11 16:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:52:45 --> Controller Class Initialized
INFO - 2023-08-11 16:52:45 --> Model "Banner_model" initialized
INFO - 2023-08-11 16:52:45 --> Helper loaded: form_helper
INFO - 2023-08-11 16:52:45 --> Form Validation Class Initialized
INFO - 2023-08-11 16:52:45 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-11 16:52:45 --> Final output sent to browser
DEBUG - 2023-08-11 16:52:45 --> Total execution time: 0.0716
INFO - 2023-08-11 16:52:50 --> Config Class Initialized
INFO - 2023-08-11 16:52:50 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:52:50 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:52:50 --> Utf8 Class Initialized
INFO - 2023-08-11 16:52:50 --> URI Class Initialized
INFO - 2023-08-11 16:52:50 --> Router Class Initialized
INFO - 2023-08-11 16:52:50 --> Output Class Initialized
INFO - 2023-08-11 16:52:50 --> Security Class Initialized
DEBUG - 2023-08-11 16:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:52:50 --> Input Class Initialized
INFO - 2023-08-11 16:52:50 --> Language Class Initialized
ERROR - 2023-08-11 16:52:50 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-11 16:52:53 --> Config Class Initialized
INFO - 2023-08-11 16:52:53 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:52:53 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:52:53 --> Utf8 Class Initialized
INFO - 2023-08-11 16:52:53 --> URI Class Initialized
INFO - 2023-08-11 16:52:53 --> Router Class Initialized
INFO - 2023-08-11 16:52:53 --> Output Class Initialized
INFO - 2023-08-11 16:52:53 --> Security Class Initialized
DEBUG - 2023-08-11 16:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:52:53 --> Input Class Initialized
INFO - 2023-08-11 16:52:53 --> Language Class Initialized
ERROR - 2023-08-11 16:52:53 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:52:53 --> Config Class Initialized
INFO - 2023-08-11 16:52:53 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:52:53 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:52:53 --> Utf8 Class Initialized
INFO - 2023-08-11 16:52:53 --> URI Class Initialized
INFO - 2023-08-11 16:52:53 --> Router Class Initialized
INFO - 2023-08-11 16:52:53 --> Output Class Initialized
INFO - 2023-08-11 16:52:53 --> Security Class Initialized
DEBUG - 2023-08-11 16:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:52:53 --> Input Class Initialized
INFO - 2023-08-11 16:52:53 --> Language Class Initialized
ERROR - 2023-08-11 16:52:53 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:54:53 --> Config Class Initialized
INFO - 2023-08-11 16:54:53 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:54:53 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:54:53 --> Utf8 Class Initialized
INFO - 2023-08-11 16:54:53 --> URI Class Initialized
INFO - 2023-08-11 16:54:53 --> Router Class Initialized
INFO - 2023-08-11 16:54:53 --> Output Class Initialized
INFO - 2023-08-11 16:54:53 --> Security Class Initialized
DEBUG - 2023-08-11 16:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:54:53 --> Input Class Initialized
INFO - 2023-08-11 16:54:53 --> Language Class Initialized
INFO - 2023-08-11 16:54:53 --> Loader Class Initialized
INFO - 2023-08-11 16:54:53 --> Helper loaded: url_helper
INFO - 2023-08-11 16:54:53 --> Helper loaded: file_helper
INFO - 2023-08-11 16:54:53 --> Database Driver Class Initialized
INFO - 2023-08-11 16:54:53 --> Email Class Initialized
DEBUG - 2023-08-11 16:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:54:53 --> Controller Class Initialized
INFO - 2023-08-11 16:54:53 --> Model "Banner_model" initialized
INFO - 2023-08-11 16:54:53 --> Helper loaded: form_helper
INFO - 2023-08-11 16:54:53 --> Form Validation Class Initialized
INFO - 2023-08-11 16:54:54 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-11 16:54:54 --> Final output sent to browser
DEBUG - 2023-08-11 16:54:54 --> Total execution time: 0.1384
INFO - 2023-08-11 16:54:54 --> Config Class Initialized
INFO - 2023-08-11 16:54:54 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:54:54 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:54:54 --> Utf8 Class Initialized
INFO - 2023-08-11 16:54:54 --> URI Class Initialized
INFO - 2023-08-11 16:54:54 --> Router Class Initialized
INFO - 2023-08-11 16:54:54 --> Output Class Initialized
INFO - 2023-08-11 16:54:54 --> Security Class Initialized
DEBUG - 2023-08-11 16:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:54:54 --> Input Class Initialized
INFO - 2023-08-11 16:54:54 --> Language Class Initialized
ERROR - 2023-08-11 16:54:54 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:54:55 --> Config Class Initialized
INFO - 2023-08-11 16:54:55 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:54:55 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:54:55 --> Utf8 Class Initialized
INFO - 2023-08-11 16:54:55 --> URI Class Initialized
INFO - 2023-08-11 16:54:55 --> Router Class Initialized
INFO - 2023-08-11 16:54:55 --> Output Class Initialized
INFO - 2023-08-11 16:54:55 --> Security Class Initialized
DEBUG - 2023-08-11 16:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:54:55 --> Input Class Initialized
INFO - 2023-08-11 16:54:55 --> Language Class Initialized
ERROR - 2023-08-11 16:54:55 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:55:29 --> Config Class Initialized
INFO - 2023-08-11 16:55:29 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:55:29 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:55:29 --> Utf8 Class Initialized
INFO - 2023-08-11 16:55:29 --> URI Class Initialized
INFO - 2023-08-11 16:55:29 --> Router Class Initialized
INFO - 2023-08-11 16:55:29 --> Output Class Initialized
INFO - 2023-08-11 16:55:29 --> Security Class Initialized
DEBUG - 2023-08-11 16:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:55:29 --> Input Class Initialized
INFO - 2023-08-11 16:55:29 --> Language Class Initialized
INFO - 2023-08-11 16:55:29 --> Loader Class Initialized
INFO - 2023-08-11 16:55:29 --> Helper loaded: url_helper
INFO - 2023-08-11 16:55:29 --> Helper loaded: file_helper
INFO - 2023-08-11 16:55:29 --> Database Driver Class Initialized
INFO - 2023-08-11 16:55:29 --> Email Class Initialized
DEBUG - 2023-08-11 16:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:55:29 --> Controller Class Initialized
INFO - 2023-08-11 16:55:29 --> Model "Banner_model" initialized
INFO - 2023-08-11 16:55:30 --> Helper loaded: form_helper
INFO - 2023-08-11 16:55:30 --> Form Validation Class Initialized
INFO - 2023-08-11 16:55:30 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-11 16:55:30 --> Final output sent to browser
DEBUG - 2023-08-11 16:55:30 --> Total execution time: 0.1162
INFO - 2023-08-11 16:55:30 --> Config Class Initialized
INFO - 2023-08-11 16:55:30 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:55:30 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:55:30 --> Utf8 Class Initialized
INFO - 2023-08-11 16:55:30 --> URI Class Initialized
INFO - 2023-08-11 16:55:30 --> Router Class Initialized
INFO - 2023-08-11 16:55:30 --> Output Class Initialized
INFO - 2023-08-11 16:55:30 --> Security Class Initialized
DEBUG - 2023-08-11 16:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:55:30 --> Input Class Initialized
INFO - 2023-08-11 16:55:30 --> Language Class Initialized
ERROR - 2023-08-11 16:55:30 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:55:30 --> Config Class Initialized
INFO - 2023-08-11 16:55:30 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:55:30 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:55:30 --> Utf8 Class Initialized
INFO - 2023-08-11 16:55:30 --> URI Class Initialized
INFO - 2023-08-11 16:55:30 --> Router Class Initialized
INFO - 2023-08-11 16:55:30 --> Output Class Initialized
INFO - 2023-08-11 16:55:30 --> Security Class Initialized
DEBUG - 2023-08-11 16:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:55:30 --> Input Class Initialized
INFO - 2023-08-11 16:55:30 --> Language Class Initialized
ERROR - 2023-08-11 16:55:30 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:56:05 --> Config Class Initialized
INFO - 2023-08-11 16:56:05 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:56:05 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:56:05 --> Utf8 Class Initialized
INFO - 2023-08-11 16:56:05 --> URI Class Initialized
INFO - 2023-08-11 16:56:05 --> Router Class Initialized
INFO - 2023-08-11 16:56:05 --> Output Class Initialized
INFO - 2023-08-11 16:56:05 --> Security Class Initialized
DEBUG - 2023-08-11 16:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:56:05 --> Input Class Initialized
INFO - 2023-08-11 16:56:05 --> Language Class Initialized
INFO - 2023-08-11 16:56:05 --> Loader Class Initialized
INFO - 2023-08-11 16:56:05 --> Helper loaded: url_helper
INFO - 2023-08-11 16:56:05 --> Helper loaded: file_helper
INFO - 2023-08-11 16:56:05 --> Database Driver Class Initialized
INFO - 2023-08-11 16:56:05 --> Email Class Initialized
DEBUG - 2023-08-11 16:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:56:05 --> Controller Class Initialized
INFO - 2023-08-11 16:56:05 --> Model "Banner_model" initialized
INFO - 2023-08-11 16:56:05 --> Helper loaded: form_helper
INFO - 2023-08-11 16:56:05 --> Form Validation Class Initialized
INFO - 2023-08-11 16:56:05 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-11 16:56:05 --> Final output sent to browser
DEBUG - 2023-08-11 16:56:05 --> Total execution time: 0.1198
INFO - 2023-08-11 16:56:06 --> Config Class Initialized
INFO - 2023-08-11 16:56:06 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:56:06 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:56:06 --> Utf8 Class Initialized
INFO - 2023-08-11 16:56:06 --> URI Class Initialized
INFO - 2023-08-11 16:56:06 --> Router Class Initialized
INFO - 2023-08-11 16:56:06 --> Output Class Initialized
INFO - 2023-08-11 16:56:06 --> Security Class Initialized
DEBUG - 2023-08-11 16:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:56:06 --> Input Class Initialized
INFO - 2023-08-11 16:56:06 --> Language Class Initialized
ERROR - 2023-08-11 16:56:06 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:56:06 --> Config Class Initialized
INFO - 2023-08-11 16:56:06 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:56:06 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:56:06 --> Utf8 Class Initialized
INFO - 2023-08-11 16:56:07 --> URI Class Initialized
INFO - 2023-08-11 16:56:07 --> Router Class Initialized
INFO - 2023-08-11 16:56:07 --> Output Class Initialized
INFO - 2023-08-11 16:56:07 --> Security Class Initialized
DEBUG - 2023-08-11 16:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:56:07 --> Input Class Initialized
INFO - 2023-08-11 16:56:07 --> Language Class Initialized
ERROR - 2023-08-11 16:56:07 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:56:08 --> Config Class Initialized
INFO - 2023-08-11 16:56:08 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:56:08 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:56:08 --> Utf8 Class Initialized
INFO - 2023-08-11 16:56:08 --> URI Class Initialized
INFO - 2023-08-11 16:56:08 --> Router Class Initialized
INFO - 2023-08-11 16:56:08 --> Output Class Initialized
INFO - 2023-08-11 16:56:08 --> Security Class Initialized
DEBUG - 2023-08-11 16:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:56:08 --> Input Class Initialized
INFO - 2023-08-11 16:56:08 --> Language Class Initialized
INFO - 2023-08-11 16:56:08 --> Loader Class Initialized
INFO - 2023-08-11 16:56:08 --> Helper loaded: url_helper
INFO - 2023-08-11 16:56:08 --> Helper loaded: file_helper
INFO - 2023-08-11 16:56:08 --> Database Driver Class Initialized
INFO - 2023-08-11 16:56:08 --> Email Class Initialized
DEBUG - 2023-08-11 16:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:56:08 --> Controller Class Initialized
INFO - 2023-08-11 16:56:08 --> Model "User_model" initialized
INFO - 2023-08-11 16:56:08 --> Config Class Initialized
INFO - 2023-08-11 16:56:08 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:56:08 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:56:08 --> Utf8 Class Initialized
INFO - 2023-08-11 16:56:08 --> URI Class Initialized
INFO - 2023-08-11 16:56:08 --> Router Class Initialized
INFO - 2023-08-11 16:56:08 --> Output Class Initialized
INFO - 2023-08-11 16:56:08 --> Security Class Initialized
DEBUG - 2023-08-11 16:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:56:08 --> Input Class Initialized
INFO - 2023-08-11 16:56:08 --> Language Class Initialized
INFO - 2023-08-11 16:56:08 --> Loader Class Initialized
INFO - 2023-08-11 16:56:08 --> Helper loaded: url_helper
INFO - 2023-08-11 16:56:08 --> Helper loaded: file_helper
INFO - 2023-08-11 16:56:08 --> Database Driver Class Initialized
INFO - 2023-08-11 16:56:08 --> Email Class Initialized
DEBUG - 2023-08-11 16:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:56:08 --> Controller Class Initialized
INFO - 2023-08-11 16:56:08 --> Model "User_model" initialized
INFO - 2023-08-11 16:56:08 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/login.php
INFO - 2023-08-11 16:56:08 --> Final output sent to browser
DEBUG - 2023-08-11 16:56:08 --> Total execution time: 0.0874
INFO - 2023-08-11 16:56:08 --> Config Class Initialized
INFO - 2023-08-11 16:56:08 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:56:08 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:56:08 --> Utf8 Class Initialized
INFO - 2023-08-11 16:56:08 --> URI Class Initialized
INFO - 2023-08-11 16:56:08 --> Router Class Initialized
INFO - 2023-08-11 16:56:08 --> Output Class Initialized
INFO - 2023-08-11 16:56:08 --> Security Class Initialized
DEBUG - 2023-08-11 16:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:56:08 --> Input Class Initialized
INFO - 2023-08-11 16:56:08 --> Language Class Initialized
ERROR - 2023-08-11 16:56:08 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:56:08 --> Config Class Initialized
INFO - 2023-08-11 16:56:08 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:56:08 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:56:08 --> Utf8 Class Initialized
INFO - 2023-08-11 16:56:08 --> URI Class Initialized
INFO - 2023-08-11 16:56:08 --> Router Class Initialized
INFO - 2023-08-11 16:56:08 --> Output Class Initialized
INFO - 2023-08-11 16:56:08 --> Security Class Initialized
DEBUG - 2023-08-11 16:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:56:08 --> Input Class Initialized
INFO - 2023-08-11 16:56:08 --> Language Class Initialized
ERROR - 2023-08-11 16:56:08 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:56:08 --> Config Class Initialized
INFO - 2023-08-11 16:56:08 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:56:08 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:56:08 --> Utf8 Class Initialized
INFO - 2023-08-11 16:56:08 --> URI Class Initialized
INFO - 2023-08-11 16:56:08 --> Router Class Initialized
INFO - 2023-08-11 16:56:08 --> Output Class Initialized
INFO - 2023-08-11 16:56:08 --> Security Class Initialized
DEBUG - 2023-08-11 16:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:56:08 --> Input Class Initialized
INFO - 2023-08-11 16:56:08 --> Language Class Initialized
ERROR - 2023-08-11 16:56:08 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-11 16:56:16 --> Config Class Initialized
INFO - 2023-08-11 16:56:16 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:56:16 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:56:16 --> Utf8 Class Initialized
INFO - 2023-08-11 16:56:16 --> URI Class Initialized
INFO - 2023-08-11 16:56:16 --> Router Class Initialized
INFO - 2023-08-11 16:56:16 --> Output Class Initialized
INFO - 2023-08-11 16:56:16 --> Security Class Initialized
DEBUG - 2023-08-11 16:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:56:16 --> Input Class Initialized
INFO - 2023-08-11 16:56:16 --> Language Class Initialized
INFO - 2023-08-11 16:56:16 --> Loader Class Initialized
INFO - 2023-08-11 16:56:16 --> Helper loaded: url_helper
INFO - 2023-08-11 16:56:16 --> Helper loaded: file_helper
INFO - 2023-08-11 16:56:16 --> Database Driver Class Initialized
INFO - 2023-08-11 16:56:16 --> Email Class Initialized
DEBUG - 2023-08-11 16:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:56:17 --> Controller Class Initialized
INFO - 2023-08-11 16:56:17 --> Model "User_model" initialized
INFO - 2023-08-11 16:56:17 --> Config Class Initialized
INFO - 2023-08-11 16:56:17 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:56:17 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:56:17 --> Utf8 Class Initialized
INFO - 2023-08-11 16:56:17 --> URI Class Initialized
INFO - 2023-08-11 16:56:17 --> Router Class Initialized
INFO - 2023-08-11 16:56:17 --> Output Class Initialized
INFO - 2023-08-11 16:56:17 --> Security Class Initialized
DEBUG - 2023-08-11 16:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:56:17 --> Input Class Initialized
INFO - 2023-08-11 16:56:17 --> Language Class Initialized
INFO - 2023-08-11 16:56:17 --> Loader Class Initialized
INFO - 2023-08-11 16:56:17 --> Helper loaded: url_helper
INFO - 2023-08-11 16:56:17 --> Helper loaded: file_helper
INFO - 2023-08-11 16:56:17 --> Database Driver Class Initialized
INFO - 2023-08-11 16:56:17 --> Email Class Initialized
DEBUG - 2023-08-11 16:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:56:17 --> Controller Class Initialized
INFO - 2023-08-11 16:56:17 --> Model "User_model" initialized
INFO - 2023-08-11 16:56:17 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/login.php
INFO - 2023-08-11 16:56:17 --> Final output sent to browser
DEBUG - 2023-08-11 16:56:17 --> Total execution time: 0.1562
INFO - 2023-08-11 16:56:24 --> Config Class Initialized
INFO - 2023-08-11 16:56:24 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:56:24 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:56:24 --> Utf8 Class Initialized
INFO - 2023-08-11 16:56:24 --> URI Class Initialized
INFO - 2023-08-11 16:56:24 --> Router Class Initialized
INFO - 2023-08-11 16:56:24 --> Output Class Initialized
INFO - 2023-08-11 16:56:24 --> Security Class Initialized
DEBUG - 2023-08-11 16:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:56:24 --> Input Class Initialized
INFO - 2023-08-11 16:56:24 --> Language Class Initialized
INFO - 2023-08-11 16:56:24 --> Loader Class Initialized
INFO - 2023-08-11 16:56:24 --> Helper loaded: url_helper
INFO - 2023-08-11 16:56:24 --> Helper loaded: file_helper
INFO - 2023-08-11 16:56:24 --> Database Driver Class Initialized
INFO - 2023-08-11 16:56:24 --> Email Class Initialized
DEBUG - 2023-08-11 16:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:56:24 --> Controller Class Initialized
INFO - 2023-08-11 16:56:24 --> Model "User_model" initialized
INFO - 2023-08-11 16:56:24 --> Config Class Initialized
INFO - 2023-08-11 16:56:24 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:56:24 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:56:24 --> Utf8 Class Initialized
INFO - 2023-08-11 16:56:24 --> URI Class Initialized
INFO - 2023-08-11 16:56:24 --> Router Class Initialized
INFO - 2023-08-11 16:56:24 --> Output Class Initialized
INFO - 2023-08-11 16:56:24 --> Security Class Initialized
DEBUG - 2023-08-11 16:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:56:24 --> Input Class Initialized
INFO - 2023-08-11 16:56:24 --> Language Class Initialized
INFO - 2023-08-11 16:56:24 --> Loader Class Initialized
INFO - 2023-08-11 16:56:24 --> Helper loaded: url_helper
INFO - 2023-08-11 16:56:24 --> Helper loaded: file_helper
INFO - 2023-08-11 16:56:24 --> Database Driver Class Initialized
INFO - 2023-08-11 16:56:24 --> Email Class Initialized
DEBUG - 2023-08-11 16:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:56:24 --> Controller Class Initialized
INFO - 2023-08-11 16:56:24 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/dashboard.php
INFO - 2023-08-11 16:56:24 --> Final output sent to browser
DEBUG - 2023-08-11 16:56:24 --> Total execution time: 0.0324
INFO - 2023-08-11 16:59:09 --> Config Class Initialized
INFO - 2023-08-11 16:59:09 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:59:09 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:59:09 --> Utf8 Class Initialized
INFO - 2023-08-11 16:59:09 --> URI Class Initialized
INFO - 2023-08-11 16:59:09 --> Router Class Initialized
INFO - 2023-08-11 16:59:09 --> Output Class Initialized
INFO - 2023-08-11 16:59:09 --> Security Class Initialized
DEBUG - 2023-08-11 16:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:59:09 --> Input Class Initialized
INFO - 2023-08-11 16:59:09 --> Language Class Initialized
INFO - 2023-08-11 16:59:10 --> Loader Class Initialized
INFO - 2023-08-11 16:59:10 --> Helper loaded: url_helper
INFO - 2023-08-11 16:59:10 --> Helper loaded: file_helper
INFO - 2023-08-11 16:59:10 --> Database Driver Class Initialized
INFO - 2023-08-11 16:59:10 --> Email Class Initialized
DEBUG - 2023-08-11 16:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:59:10 --> Controller Class Initialized
INFO - 2023-08-11 16:59:10 --> Model "Banner_model" initialized
INFO - 2023-08-11 16:59:10 --> Helper loaded: form_helper
INFO - 2023-08-11 16:59:10 --> Form Validation Class Initialized
INFO - 2023-08-11 16:59:10 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-11 16:59:10 --> Final output sent to browser
DEBUG - 2023-08-11 16:59:10 --> Total execution time: 0.2814
INFO - 2023-08-11 16:59:11 --> Config Class Initialized
INFO - 2023-08-11 16:59:11 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:59:11 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:59:11 --> Utf8 Class Initialized
INFO - 2023-08-11 16:59:11 --> URI Class Initialized
INFO - 2023-08-11 16:59:11 --> Router Class Initialized
INFO - 2023-08-11 16:59:11 --> Output Class Initialized
INFO - 2023-08-11 16:59:11 --> Security Class Initialized
DEBUG - 2023-08-11 16:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:59:11 --> Input Class Initialized
INFO - 2023-08-11 16:59:11 --> Language Class Initialized
INFO - 2023-08-11 16:59:11 --> Loader Class Initialized
INFO - 2023-08-11 16:59:11 --> Helper loaded: url_helper
INFO - 2023-08-11 16:59:11 --> Helper loaded: file_helper
INFO - 2023-08-11 16:59:11 --> Database Driver Class Initialized
INFO - 2023-08-11 16:59:11 --> Email Class Initialized
DEBUG - 2023-08-11 16:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:59:11 --> Controller Class Initialized
INFO - 2023-08-11 16:59:11 --> Model "User_model" initialized
INFO - 2023-08-11 16:59:11 --> Config Class Initialized
INFO - 2023-08-11 16:59:11 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:59:11 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:59:11 --> Utf8 Class Initialized
INFO - 2023-08-11 16:59:11 --> URI Class Initialized
INFO - 2023-08-11 16:59:11 --> Router Class Initialized
INFO - 2023-08-11 16:59:11 --> Output Class Initialized
INFO - 2023-08-11 16:59:11 --> Security Class Initialized
DEBUG - 2023-08-11 16:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:59:11 --> Input Class Initialized
INFO - 2023-08-11 16:59:11 --> Language Class Initialized
INFO - 2023-08-11 16:59:11 --> Loader Class Initialized
INFO - 2023-08-11 16:59:11 --> Helper loaded: url_helper
INFO - 2023-08-11 16:59:11 --> Helper loaded: file_helper
INFO - 2023-08-11 16:59:11 --> Database Driver Class Initialized
INFO - 2023-08-11 16:59:11 --> Email Class Initialized
DEBUG - 2023-08-11 16:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:59:11 --> Controller Class Initialized
INFO - 2023-08-11 16:59:11 --> Model "User_model" initialized
INFO - 2023-08-11 16:59:11 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/login.php
INFO - 2023-08-11 16:59:11 --> Final output sent to browser
DEBUG - 2023-08-11 16:59:11 --> Total execution time: 0.1236
INFO - 2023-08-11 16:59:17 --> Config Class Initialized
INFO - 2023-08-11 16:59:17 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:59:17 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:59:17 --> Utf8 Class Initialized
INFO - 2023-08-11 16:59:17 --> URI Class Initialized
INFO - 2023-08-11 16:59:17 --> Router Class Initialized
INFO - 2023-08-11 16:59:17 --> Output Class Initialized
INFO - 2023-08-11 16:59:17 --> Security Class Initialized
DEBUG - 2023-08-11 16:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:59:17 --> Input Class Initialized
INFO - 2023-08-11 16:59:17 --> Language Class Initialized
INFO - 2023-08-11 16:59:17 --> Loader Class Initialized
INFO - 2023-08-11 16:59:17 --> Helper loaded: url_helper
INFO - 2023-08-11 16:59:17 --> Helper loaded: file_helper
INFO - 2023-08-11 16:59:17 --> Database Driver Class Initialized
INFO - 2023-08-11 16:59:17 --> Email Class Initialized
DEBUG - 2023-08-11 16:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:59:17 --> Controller Class Initialized
INFO - 2023-08-11 16:59:17 --> Config Class Initialized
INFO - 2023-08-11 16:59:17 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:59:17 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:59:17 --> Utf8 Class Initialized
INFO - 2023-08-11 16:59:17 --> URI Class Initialized
INFO - 2023-08-11 16:59:17 --> Router Class Initialized
INFO - 2023-08-11 16:59:17 --> Output Class Initialized
INFO - 2023-08-11 16:59:17 --> Security Class Initialized
DEBUG - 2023-08-11 16:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:59:17 --> Input Class Initialized
INFO - 2023-08-11 16:59:17 --> Language Class Initialized
INFO - 2023-08-11 16:59:17 --> Loader Class Initialized
INFO - 2023-08-11 16:59:17 --> Helper loaded: url_helper
INFO - 2023-08-11 16:59:17 --> Helper loaded: file_helper
INFO - 2023-08-11 16:59:17 --> Database Driver Class Initialized
INFO - 2023-08-11 16:59:17 --> Email Class Initialized
DEBUG - 2023-08-11 16:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:59:17 --> Controller Class Initialized
INFO - 2023-08-11 16:59:17 --> Model "User_model" initialized
INFO - 2023-08-11 16:59:17 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/login.php
INFO - 2023-08-11 16:59:17 --> Final output sent to browser
DEBUG - 2023-08-11 16:59:17 --> Total execution time: 0.0421
INFO - 2023-08-11 16:59:23 --> Config Class Initialized
INFO - 2023-08-11 16:59:23 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:59:23 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:59:23 --> Utf8 Class Initialized
INFO - 2023-08-11 16:59:23 --> URI Class Initialized
INFO - 2023-08-11 16:59:23 --> Router Class Initialized
INFO - 2023-08-11 16:59:23 --> Output Class Initialized
INFO - 2023-08-11 16:59:23 --> Security Class Initialized
DEBUG - 2023-08-11 16:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:59:23 --> Input Class Initialized
INFO - 2023-08-11 16:59:23 --> Language Class Initialized
INFO - 2023-08-11 16:59:23 --> Loader Class Initialized
INFO - 2023-08-11 16:59:23 --> Helper loaded: url_helper
INFO - 2023-08-11 16:59:23 --> Helper loaded: file_helper
INFO - 2023-08-11 16:59:23 --> Database Driver Class Initialized
INFO - 2023-08-11 16:59:23 --> Email Class Initialized
DEBUG - 2023-08-11 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:59:23 --> Controller Class Initialized
INFO - 2023-08-11 16:59:23 --> Config Class Initialized
INFO - 2023-08-11 16:59:23 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:59:23 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:59:23 --> Utf8 Class Initialized
INFO - 2023-08-11 16:59:23 --> URI Class Initialized
INFO - 2023-08-11 16:59:23 --> Router Class Initialized
INFO - 2023-08-11 16:59:23 --> Output Class Initialized
INFO - 2023-08-11 16:59:23 --> Security Class Initialized
DEBUG - 2023-08-11 16:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:59:23 --> Input Class Initialized
INFO - 2023-08-11 16:59:23 --> Language Class Initialized
INFO - 2023-08-11 16:59:23 --> Loader Class Initialized
INFO - 2023-08-11 16:59:23 --> Helper loaded: url_helper
INFO - 2023-08-11 16:59:23 --> Helper loaded: file_helper
INFO - 2023-08-11 16:59:23 --> Database Driver Class Initialized
INFO - 2023-08-11 16:59:23 --> Email Class Initialized
DEBUG - 2023-08-11 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:59:23 --> Controller Class Initialized
INFO - 2023-08-11 16:59:23 --> Model "User_model" initialized
INFO - 2023-08-11 16:59:23 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/login.php
INFO - 2023-08-11 16:59:23 --> Final output sent to browser
DEBUG - 2023-08-11 16:59:23 --> Total execution time: 0.0349
INFO - 2023-08-11 16:59:29 --> Config Class Initialized
INFO - 2023-08-11 16:59:29 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:59:29 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:59:29 --> Utf8 Class Initialized
INFO - 2023-08-11 16:59:29 --> URI Class Initialized
INFO - 2023-08-11 16:59:29 --> Router Class Initialized
INFO - 2023-08-11 16:59:29 --> Output Class Initialized
INFO - 2023-08-11 16:59:29 --> Security Class Initialized
DEBUG - 2023-08-11 16:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:59:29 --> Input Class Initialized
INFO - 2023-08-11 16:59:29 --> Language Class Initialized
INFO - 2023-08-11 16:59:29 --> Loader Class Initialized
INFO - 2023-08-11 16:59:29 --> Helper loaded: url_helper
INFO - 2023-08-11 16:59:29 --> Helper loaded: file_helper
INFO - 2023-08-11 16:59:29 --> Database Driver Class Initialized
INFO - 2023-08-11 16:59:29 --> Email Class Initialized
DEBUG - 2023-08-11 16:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:59:29 --> Controller Class Initialized
INFO - 2023-08-11 16:59:29 --> Model "User_model" initialized
INFO - 2023-08-11 16:59:29 --> Config Class Initialized
INFO - 2023-08-11 16:59:29 --> Hooks Class Initialized
DEBUG - 2023-08-11 16:59:29 --> UTF-8 Support Enabled
INFO - 2023-08-11 16:59:29 --> Utf8 Class Initialized
INFO - 2023-08-11 16:59:29 --> URI Class Initialized
INFO - 2023-08-11 16:59:29 --> Router Class Initialized
INFO - 2023-08-11 16:59:29 --> Output Class Initialized
INFO - 2023-08-11 16:59:29 --> Security Class Initialized
DEBUG - 2023-08-11 16:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 16:59:29 --> Input Class Initialized
INFO - 2023-08-11 16:59:29 --> Language Class Initialized
INFO - 2023-08-11 16:59:29 --> Loader Class Initialized
INFO - 2023-08-11 16:59:29 --> Helper loaded: url_helper
INFO - 2023-08-11 16:59:29 --> Helper loaded: file_helper
INFO - 2023-08-11 16:59:29 --> Database Driver Class Initialized
INFO - 2023-08-11 16:59:29 --> Email Class Initialized
DEBUG - 2023-08-11 16:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 16:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 16:59:29 --> Controller Class Initialized
INFO - 2023-08-11 16:59:29 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/dashboard.php
INFO - 2023-08-11 16:59:29 --> Final output sent to browser
DEBUG - 2023-08-11 16:59:29 --> Total execution time: 0.0457
INFO - 2023-08-11 17:01:11 --> Config Class Initialized
INFO - 2023-08-11 17:01:11 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:01:11 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:01:11 --> Utf8 Class Initialized
INFO - 2023-08-11 17:01:11 --> URI Class Initialized
INFO - 2023-08-11 17:01:11 --> Router Class Initialized
INFO - 2023-08-11 17:01:11 --> Output Class Initialized
INFO - 2023-08-11 17:01:11 --> Security Class Initialized
DEBUG - 2023-08-11 17:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:01:11 --> Input Class Initialized
INFO - 2023-08-11 17:01:11 --> Language Class Initialized
INFO - 2023-08-11 17:01:11 --> Loader Class Initialized
INFO - 2023-08-11 17:01:11 --> Helper loaded: url_helper
INFO - 2023-08-11 17:01:11 --> Helper loaded: file_helper
INFO - 2023-08-11 17:01:11 --> Database Driver Class Initialized
INFO - 2023-08-11 17:01:11 --> Email Class Initialized
DEBUG - 2023-08-11 17:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:01:11 --> Controller Class Initialized
INFO - 2023-08-11 17:01:11 --> Model "Training_model" initialized
INFO - 2023-08-11 17:01:11 --> Helper loaded: form_helper
INFO - 2023-08-11 17:01:11 --> Form Validation Class Initialized
INFO - 2023-08-11 17:01:11 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-11 17:01:11 --> Final output sent to browser
DEBUG - 2023-08-11 17:01:11 --> Total execution time: 0.0462
INFO - 2023-08-11 17:01:13 --> Config Class Initialized
INFO - 2023-08-11 17:01:13 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:01:13 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:01:13 --> Utf8 Class Initialized
INFO - 2023-08-11 17:01:13 --> URI Class Initialized
INFO - 2023-08-11 17:01:13 --> Router Class Initialized
INFO - 2023-08-11 17:01:13 --> Output Class Initialized
INFO - 2023-08-11 17:01:13 --> Security Class Initialized
DEBUG - 2023-08-11 17:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:01:13 --> Input Class Initialized
INFO - 2023-08-11 17:01:13 --> Language Class Initialized
INFO - 2023-08-11 17:01:13 --> Loader Class Initialized
INFO - 2023-08-11 17:01:13 --> Helper loaded: url_helper
INFO - 2023-08-11 17:01:13 --> Helper loaded: file_helper
INFO - 2023-08-11 17:01:13 --> Database Driver Class Initialized
INFO - 2023-08-11 17:01:13 --> Email Class Initialized
DEBUG - 2023-08-11 17:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:01:13 --> Controller Class Initialized
INFO - 2023-08-11 17:01:13 --> Model "Faq_model" initialized
INFO - 2023-08-11 17:01:13 --> Helper loaded: form_helper
INFO - 2023-08-11 17:01:13 --> Form Validation Class Initialized
INFO - 2023-08-11 17:01:13 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-11 17:01:13 --> Final output sent to browser
DEBUG - 2023-08-11 17:01:13 --> Total execution time: 0.0518
INFO - 2023-08-11 17:01:14 --> Config Class Initialized
INFO - 2023-08-11 17:01:14 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:01:14 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:01:14 --> Utf8 Class Initialized
INFO - 2023-08-11 17:01:14 --> URI Class Initialized
INFO - 2023-08-11 17:01:14 --> Router Class Initialized
INFO - 2023-08-11 17:01:14 --> Output Class Initialized
INFO - 2023-08-11 17:01:14 --> Security Class Initialized
DEBUG - 2023-08-11 17:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:01:14 --> Input Class Initialized
INFO - 2023-08-11 17:01:14 --> Language Class Initialized
ERROR - 2023-08-11 17:01:14 --> 404 Page Not Found: admin/Key_highlights/index
INFO - 2023-08-11 17:01:20 --> Config Class Initialized
INFO - 2023-08-11 17:01:20 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:01:20 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:01:20 --> Utf8 Class Initialized
INFO - 2023-08-11 17:01:20 --> URI Class Initialized
INFO - 2023-08-11 17:01:20 --> Router Class Initialized
INFO - 2023-08-11 17:01:20 --> Output Class Initialized
INFO - 2023-08-11 17:01:20 --> Security Class Initialized
DEBUG - 2023-08-11 17:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:01:20 --> Input Class Initialized
INFO - 2023-08-11 17:01:20 --> Language Class Initialized
INFO - 2023-08-11 17:01:20 --> Loader Class Initialized
INFO - 2023-08-11 17:01:20 --> Helper loaded: url_helper
INFO - 2023-08-11 17:01:20 --> Helper loaded: file_helper
INFO - 2023-08-11 17:01:20 --> Database Driver Class Initialized
INFO - 2023-08-11 17:01:20 --> Email Class Initialized
DEBUG - 2023-08-11 17:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:01:20 --> Controller Class Initialized
INFO - 2023-08-11 17:01:20 --> Model "Faq_model" initialized
INFO - 2023-08-11 17:01:20 --> Helper loaded: form_helper
INFO - 2023-08-11 17:01:20 --> Form Validation Class Initialized
INFO - 2023-08-11 17:01:20 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-11 17:01:20 --> Final output sent to browser
DEBUG - 2023-08-11 17:01:20 --> Total execution time: 0.0442
INFO - 2023-08-11 17:01:39 --> Config Class Initialized
INFO - 2023-08-11 17:01:39 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:01:39 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:01:39 --> Utf8 Class Initialized
INFO - 2023-08-11 17:01:39 --> URI Class Initialized
INFO - 2023-08-11 17:01:39 --> Router Class Initialized
INFO - 2023-08-11 17:01:39 --> Output Class Initialized
INFO - 2023-08-11 17:01:39 --> Security Class Initialized
DEBUG - 2023-08-11 17:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:01:39 --> Input Class Initialized
INFO - 2023-08-11 17:01:39 --> Language Class Initialized
INFO - 2023-08-11 17:01:39 --> Loader Class Initialized
INFO - 2023-08-11 17:01:39 --> Helper loaded: url_helper
INFO - 2023-08-11 17:01:39 --> Helper loaded: file_helper
INFO - 2023-08-11 17:01:39 --> Database Driver Class Initialized
INFO - 2023-08-11 17:01:39 --> Email Class Initialized
DEBUG - 2023-08-11 17:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:01:39 --> Controller Class Initialized
INFO - 2023-08-11 17:01:39 --> Model "Services_model" initialized
INFO - 2023-08-11 17:01:39 --> Helper loaded: form_helper
INFO - 2023-08-11 17:01:39 --> Form Validation Class Initialized
INFO - 2023-08-11 17:01:39 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-11 17:01:39 --> Final output sent to browser
DEBUG - 2023-08-11 17:01:39 --> Total execution time: 0.0843
INFO - 2023-08-11 17:01:39 --> Config Class Initialized
INFO - 2023-08-11 17:01:39 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:01:39 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:01:39 --> Utf8 Class Initialized
INFO - 2023-08-11 17:01:39 --> URI Class Initialized
INFO - 2023-08-11 17:01:39 --> Router Class Initialized
INFO - 2023-08-11 17:01:39 --> Output Class Initialized
INFO - 2023-08-11 17:01:39 --> Security Class Initialized
DEBUG - 2023-08-11 17:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:01:39 --> Input Class Initialized
INFO - 2023-08-11 17:01:39 --> Language Class Initialized
ERROR - 2023-08-11 17:01:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-11 17:01:43 --> Config Class Initialized
INFO - 2023-08-11 17:01:43 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:01:43 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:01:43 --> Utf8 Class Initialized
INFO - 2023-08-11 17:01:43 --> URI Class Initialized
INFO - 2023-08-11 17:01:43 --> Router Class Initialized
INFO - 2023-08-11 17:01:43 --> Output Class Initialized
INFO - 2023-08-11 17:01:43 --> Security Class Initialized
DEBUG - 2023-08-11 17:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:01:43 --> Input Class Initialized
INFO - 2023-08-11 17:01:43 --> Language Class Initialized
INFO - 2023-08-11 17:01:43 --> Loader Class Initialized
INFO - 2023-08-11 17:01:43 --> Helper loaded: url_helper
INFO - 2023-08-11 17:01:43 --> Helper loaded: file_helper
INFO - 2023-08-11 17:01:43 --> Database Driver Class Initialized
INFO - 2023-08-11 17:01:43 --> Email Class Initialized
DEBUG - 2023-08-11 17:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:01:43 --> Controller Class Initialized
INFO - 2023-08-11 17:01:43 --> Model "Faq_model" initialized
INFO - 2023-08-11 17:01:43 --> Helper loaded: form_helper
INFO - 2023-08-11 17:01:43 --> Form Validation Class Initialized
INFO - 2023-08-11 17:01:43 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-11 17:01:43 --> Final output sent to browser
DEBUG - 2023-08-11 17:01:43 --> Total execution time: 0.0503
INFO - 2023-08-11 17:02:09 --> Config Class Initialized
INFO - 2023-08-11 17:02:09 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:02:09 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:02:09 --> Utf8 Class Initialized
INFO - 2023-08-11 17:02:09 --> URI Class Initialized
INFO - 2023-08-11 17:02:09 --> Router Class Initialized
INFO - 2023-08-11 17:02:09 --> Output Class Initialized
INFO - 2023-08-11 17:02:09 --> Security Class Initialized
DEBUG - 2023-08-11 17:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:02:09 --> Input Class Initialized
INFO - 2023-08-11 17:02:09 --> Language Class Initialized
INFO - 2023-08-11 17:02:09 --> Loader Class Initialized
INFO - 2023-08-11 17:02:09 --> Helper loaded: url_helper
INFO - 2023-08-11 17:02:09 --> Helper loaded: file_helper
INFO - 2023-08-11 17:02:09 --> Database Driver Class Initialized
INFO - 2023-08-11 17:02:09 --> Email Class Initialized
DEBUG - 2023-08-11 17:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:02:09 --> Controller Class Initialized
INFO - 2023-08-11 17:02:09 --> Model "Faq_model" initialized
INFO - 2023-08-11 17:02:09 --> Helper loaded: form_helper
INFO - 2023-08-11 17:02:09 --> Form Validation Class Initialized
INFO - 2023-08-11 17:02:09 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-11 17:02:09 --> Final output sent to browser
DEBUG - 2023-08-11 17:02:09 --> Total execution time: 0.0605
INFO - 2023-08-11 17:02:14 --> Config Class Initialized
INFO - 2023-08-11 17:02:14 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:02:14 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:02:14 --> Utf8 Class Initialized
INFO - 2023-08-11 17:02:14 --> URI Class Initialized
INFO - 2023-08-11 17:02:14 --> Router Class Initialized
INFO - 2023-08-11 17:02:14 --> Output Class Initialized
INFO - 2023-08-11 17:02:14 --> Security Class Initialized
DEBUG - 2023-08-11 17:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:02:14 --> Input Class Initialized
INFO - 2023-08-11 17:02:14 --> Language Class Initialized
INFO - 2023-08-11 17:02:14 --> Loader Class Initialized
INFO - 2023-08-11 17:02:14 --> Helper loaded: url_helper
INFO - 2023-08-11 17:02:14 --> Helper loaded: file_helper
INFO - 2023-08-11 17:02:14 --> Database Driver Class Initialized
INFO - 2023-08-11 17:02:14 --> Email Class Initialized
DEBUG - 2023-08-11 17:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:02:14 --> Controller Class Initialized
INFO - 2023-08-11 17:02:14 --> Model "Address_model" initialized
INFO - 2023-08-11 17:02:14 --> Helper loaded: form_helper
INFO - 2023-08-11 17:02:14 --> Form Validation Class Initialized
INFO - 2023-08-11 17:02:14 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/address_list.php
INFO - 2023-08-11 17:02:14 --> Final output sent to browser
DEBUG - 2023-08-11 17:02:14 --> Total execution time: 0.0557
INFO - 2023-08-11 17:02:15 --> Config Class Initialized
INFO - 2023-08-11 17:02:15 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:02:15 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:02:15 --> Utf8 Class Initialized
INFO - 2023-08-11 17:02:15 --> URI Class Initialized
INFO - 2023-08-11 17:02:15 --> Router Class Initialized
INFO - 2023-08-11 17:02:15 --> Output Class Initialized
INFO - 2023-08-11 17:02:15 --> Security Class Initialized
DEBUG - 2023-08-11 17:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:02:15 --> Input Class Initialized
INFO - 2023-08-11 17:02:15 --> Language Class Initialized
INFO - 2023-08-11 17:02:15 --> Loader Class Initialized
INFO - 2023-08-11 17:02:15 --> Helper loaded: url_helper
INFO - 2023-08-11 17:02:15 --> Helper loaded: file_helper
INFO - 2023-08-11 17:02:15 --> Database Driver Class Initialized
INFO - 2023-08-11 17:02:15 --> Email Class Initialized
DEBUG - 2023-08-11 17:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:02:15 --> Controller Class Initialized
INFO - 2023-08-11 17:02:15 --> Model "Contact_model" initialized
INFO - 2023-08-11 17:02:15 --> Helper loaded: form_helper
INFO - 2023-08-11 17:02:16 --> Form Validation Class Initialized
INFO - 2023-08-11 17:02:16 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/contact_list.php
INFO - 2023-08-11 17:02:16 --> Final output sent to browser
DEBUG - 2023-08-11 17:02:16 --> Total execution time: 0.0489
INFO - 2023-08-11 17:02:18 --> Config Class Initialized
INFO - 2023-08-11 17:02:18 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:02:18 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:02:18 --> Utf8 Class Initialized
INFO - 2023-08-11 17:02:18 --> URI Class Initialized
INFO - 2023-08-11 17:02:18 --> Router Class Initialized
INFO - 2023-08-11 17:02:18 --> Output Class Initialized
INFO - 2023-08-11 17:02:18 --> Security Class Initialized
DEBUG - 2023-08-11 17:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:02:18 --> Input Class Initialized
INFO - 2023-08-11 17:02:18 --> Language Class Initialized
INFO - 2023-08-11 17:02:18 --> Loader Class Initialized
INFO - 2023-08-11 17:02:18 --> Helper loaded: url_helper
INFO - 2023-08-11 17:02:18 --> Helper loaded: file_helper
INFO - 2023-08-11 17:02:18 --> Database Driver Class Initialized
INFO - 2023-08-11 17:02:18 --> Email Class Initialized
DEBUG - 2023-08-11 17:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:02:18 --> Controller Class Initialized
INFO - 2023-08-11 17:02:18 --> Model "Address_model" initialized
INFO - 2023-08-11 17:02:18 --> Helper loaded: form_helper
INFO - 2023-08-11 17:02:18 --> Form Validation Class Initialized
INFO - 2023-08-11 17:02:18 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/address_list.php
INFO - 2023-08-11 17:02:18 --> Final output sent to browser
DEBUG - 2023-08-11 17:02:18 --> Total execution time: 0.0466
INFO - 2023-08-11 17:02:19 --> Config Class Initialized
INFO - 2023-08-11 17:02:19 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:02:19 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:02:19 --> Utf8 Class Initialized
INFO - 2023-08-11 17:02:19 --> URI Class Initialized
INFO - 2023-08-11 17:02:19 --> Router Class Initialized
INFO - 2023-08-11 17:02:19 --> Output Class Initialized
INFO - 2023-08-11 17:02:19 --> Security Class Initialized
DEBUG - 2023-08-11 17:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:02:19 --> Input Class Initialized
INFO - 2023-08-11 17:02:19 --> Language Class Initialized
INFO - 2023-08-11 17:02:19 --> Loader Class Initialized
INFO - 2023-08-11 17:02:19 --> Helper loaded: url_helper
INFO - 2023-08-11 17:02:19 --> Helper loaded: file_helper
INFO - 2023-08-11 17:02:19 --> Database Driver Class Initialized
INFO - 2023-08-11 17:02:19 --> Email Class Initialized
DEBUG - 2023-08-11 17:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:02:19 --> Controller Class Initialized
INFO - 2023-08-11 17:02:19 --> Model "Services_model" initialized
INFO - 2023-08-11 17:02:19 --> Helper loaded: form_helper
INFO - 2023-08-11 17:02:19 --> Form Validation Class Initialized
INFO - 2023-08-11 17:02:19 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-11 17:02:19 --> Final output sent to browser
DEBUG - 2023-08-11 17:02:19 --> Total execution time: 0.0583
INFO - 2023-08-11 17:02:19 --> Config Class Initialized
INFO - 2023-08-11 17:02:19 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:02:19 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:02:19 --> Utf8 Class Initialized
INFO - 2023-08-11 17:02:19 --> URI Class Initialized
INFO - 2023-08-11 17:02:19 --> Router Class Initialized
INFO - 2023-08-11 17:02:19 --> Output Class Initialized
INFO - 2023-08-11 17:02:19 --> Security Class Initialized
DEBUG - 2023-08-11 17:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:02:19 --> Input Class Initialized
INFO - 2023-08-11 17:02:19 --> Language Class Initialized
ERROR - 2023-08-11 17:02:19 --> 404 Page Not Found: Assets/images
INFO - 2023-08-11 17:02:24 --> Config Class Initialized
INFO - 2023-08-11 17:02:24 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:02:24 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:02:24 --> Utf8 Class Initialized
INFO - 2023-08-11 17:02:24 --> URI Class Initialized
INFO - 2023-08-11 17:02:24 --> Router Class Initialized
INFO - 2023-08-11 17:02:24 --> Output Class Initialized
INFO - 2023-08-11 17:02:24 --> Security Class Initialized
DEBUG - 2023-08-11 17:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:02:24 --> Input Class Initialized
INFO - 2023-08-11 17:02:24 --> Language Class Initialized
INFO - 2023-08-11 17:02:24 --> Loader Class Initialized
INFO - 2023-08-11 17:02:24 --> Helper loaded: url_helper
INFO - 2023-08-11 17:02:24 --> Helper loaded: file_helper
INFO - 2023-08-11 17:02:24 --> Database Driver Class Initialized
INFO - 2023-08-11 17:02:24 --> Email Class Initialized
DEBUG - 2023-08-11 17:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:02:24 --> Controller Class Initialized
INFO - 2023-08-11 17:02:24 --> Model "Banner_model" initialized
INFO - 2023-08-11 17:02:24 --> Helper loaded: form_helper
INFO - 2023-08-11 17:02:24 --> Form Validation Class Initialized
INFO - 2023-08-11 17:02:24 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-11 17:02:24 --> Final output sent to browser
DEBUG - 2023-08-11 17:02:24 --> Total execution time: 0.0439
INFO - 2023-08-11 17:39:33 --> Config Class Initialized
INFO - 2023-08-11 17:39:33 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:39:33 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:39:33 --> Utf8 Class Initialized
INFO - 2023-08-11 17:39:33 --> URI Class Initialized
INFO - 2023-08-11 17:39:33 --> Router Class Initialized
INFO - 2023-08-11 17:39:33 --> Output Class Initialized
INFO - 2023-08-11 17:39:33 --> Security Class Initialized
DEBUG - 2023-08-11 17:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:39:33 --> Input Class Initialized
INFO - 2023-08-11 17:39:33 --> Language Class Initialized
INFO - 2023-08-11 17:39:33 --> Loader Class Initialized
INFO - 2023-08-11 17:39:33 --> Helper loaded: url_helper
INFO - 2023-08-11 17:39:33 --> Helper loaded: file_helper
INFO - 2023-08-11 17:39:33 --> Database Driver Class Initialized
INFO - 2023-08-11 17:39:33 --> Email Class Initialized
DEBUG - 2023-08-11 17:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:39:33 --> Controller Class Initialized
INFO - 2023-08-11 17:39:33 --> Model "Banner_model" initialized
INFO - 2023-08-11 17:39:33 --> Helper loaded: form_helper
INFO - 2023-08-11 17:39:33 --> Form Validation Class Initialized
INFO - 2023-08-11 17:39:33 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-11 17:39:33 --> Final output sent to browser
DEBUG - 2023-08-11 17:39:33 --> Total execution time: 0.0518
INFO - 2023-08-11 17:39:35 --> Config Class Initialized
INFO - 2023-08-11 17:39:35 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:39:35 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:39:35 --> Utf8 Class Initialized
INFO - 2023-08-11 17:39:35 --> URI Class Initialized
INFO - 2023-08-11 17:39:35 --> Router Class Initialized
INFO - 2023-08-11 17:39:35 --> Output Class Initialized
INFO - 2023-08-11 17:39:35 --> Security Class Initialized
DEBUG - 2023-08-11 17:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:39:35 --> Input Class Initialized
INFO - 2023-08-11 17:39:35 --> Language Class Initialized
INFO - 2023-08-11 17:39:35 --> Loader Class Initialized
INFO - 2023-08-11 17:39:35 --> Helper loaded: url_helper
INFO - 2023-08-11 17:39:35 --> Helper loaded: file_helper
INFO - 2023-08-11 17:39:35 --> Database Driver Class Initialized
INFO - 2023-08-11 17:39:35 --> Email Class Initialized
DEBUG - 2023-08-11 17:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:39:35 --> Controller Class Initialized
INFO - 2023-08-11 17:39:35 --> Model "Banner_model" initialized
INFO - 2023-08-11 17:39:35 --> Helper loaded: form_helper
INFO - 2023-08-11 17:39:35 --> Form Validation Class Initialized
INFO - 2023-08-11 17:39:35 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_create.php
INFO - 2023-08-11 17:39:35 --> Final output sent to browser
DEBUG - 2023-08-11 17:39:35 --> Total execution time: 0.0441
INFO - 2023-08-11 17:39:35 --> Config Class Initialized
INFO - 2023-08-11 17:39:35 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:39:35 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:39:35 --> Utf8 Class Initialized
INFO - 2023-08-11 17:39:35 --> URI Class Initialized
INFO - 2023-08-11 17:39:35 --> Router Class Initialized
INFO - 2023-08-11 17:39:35 --> Output Class Initialized
INFO - 2023-08-11 17:39:35 --> Security Class Initialized
DEBUG - 2023-08-11 17:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:39:35 --> Input Class Initialized
INFO - 2023-08-11 17:39:35 --> Language Class Initialized
ERROR - 2023-08-11 17:39:35 --> 404 Page Not Found: admin/Banner/images
INFO - 2023-08-11 17:39:39 --> Config Class Initialized
INFO - 2023-08-11 17:39:39 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:39:39 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:39:39 --> Utf8 Class Initialized
INFO - 2023-08-11 17:39:39 --> URI Class Initialized
INFO - 2023-08-11 17:39:39 --> Router Class Initialized
INFO - 2023-08-11 17:39:39 --> Output Class Initialized
INFO - 2023-08-11 17:39:39 --> Security Class Initialized
DEBUG - 2023-08-11 17:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:39:39 --> Input Class Initialized
INFO - 2023-08-11 17:39:39 --> Language Class Initialized
INFO - 2023-08-11 17:39:39 --> Loader Class Initialized
INFO - 2023-08-11 17:39:39 --> Helper loaded: url_helper
INFO - 2023-08-11 17:39:39 --> Helper loaded: file_helper
INFO - 2023-08-11 17:39:39 --> Database Driver Class Initialized
INFO - 2023-08-11 17:39:39 --> Email Class Initialized
DEBUG - 2023-08-11 17:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:39:39 --> Controller Class Initialized
INFO - 2023-08-11 17:39:39 --> Model "Gallery_model" initialized
INFO - 2023-08-11 17:39:39 --> Helper loaded: form_helper
INFO - 2023-08-11 17:39:39 --> Form Validation Class Initialized
INFO - 2023-08-11 17:39:39 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-11 17:39:39 --> Final output sent to browser
DEBUG - 2023-08-11 17:39:39 --> Total execution time: 0.0519
INFO - 2023-08-11 17:39:41 --> Config Class Initialized
INFO - 2023-08-11 17:39:41 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:39:41 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:39:41 --> Utf8 Class Initialized
INFO - 2023-08-11 17:39:41 --> URI Class Initialized
INFO - 2023-08-11 17:39:41 --> Router Class Initialized
INFO - 2023-08-11 17:39:41 --> Output Class Initialized
INFO - 2023-08-11 17:39:41 --> Security Class Initialized
DEBUG - 2023-08-11 17:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:39:41 --> Input Class Initialized
INFO - 2023-08-11 17:39:41 --> Language Class Initialized
INFO - 2023-08-11 17:39:41 --> Loader Class Initialized
INFO - 2023-08-11 17:39:41 --> Helper loaded: url_helper
INFO - 2023-08-11 17:39:41 --> Helper loaded: file_helper
INFO - 2023-08-11 17:39:41 --> Database Driver Class Initialized
INFO - 2023-08-11 17:39:41 --> Email Class Initialized
DEBUG - 2023-08-11 17:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:39:41 --> Controller Class Initialized
INFO - 2023-08-11 17:39:41 --> Model "Gallery_model" initialized
INFO - 2023-08-11 17:39:41 --> Helper loaded: form_helper
INFO - 2023-08-11 17:39:41 --> Form Validation Class Initialized
INFO - 2023-08-11 17:39:41 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-11 17:39:41 --> Final output sent to browser
DEBUG - 2023-08-11 17:39:41 --> Total execution time: 0.0545
INFO - 2023-08-11 17:39:41 --> Config Class Initialized
INFO - 2023-08-11 17:39:41 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:39:41 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:39:41 --> Utf8 Class Initialized
INFO - 2023-08-11 17:39:41 --> URI Class Initialized
INFO - 2023-08-11 17:39:41 --> Router Class Initialized
INFO - 2023-08-11 17:39:41 --> Output Class Initialized
INFO - 2023-08-11 17:39:41 --> Security Class Initialized
DEBUG - 2023-08-11 17:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:39:41 --> Input Class Initialized
INFO - 2023-08-11 17:39:41 --> Language Class Initialized
ERROR - 2023-08-11 17:39:41 --> 404 Page Not Found: admin/Gallery/images
INFO - 2023-08-11 17:39:57 --> Config Class Initialized
INFO - 2023-08-11 17:39:57 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:39:57 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:39:57 --> Utf8 Class Initialized
INFO - 2023-08-11 17:39:57 --> URI Class Initialized
INFO - 2023-08-11 17:39:57 --> Router Class Initialized
INFO - 2023-08-11 17:39:57 --> Output Class Initialized
INFO - 2023-08-11 17:39:57 --> Security Class Initialized
DEBUG - 2023-08-11 17:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:39:57 --> Input Class Initialized
INFO - 2023-08-11 17:39:57 --> Language Class Initialized
INFO - 2023-08-11 17:39:57 --> Loader Class Initialized
INFO - 2023-08-11 17:39:57 --> Helper loaded: url_helper
INFO - 2023-08-11 17:39:57 --> Helper loaded: file_helper
INFO - 2023-08-11 17:39:57 --> Database Driver Class Initialized
INFO - 2023-08-11 17:39:57 --> Email Class Initialized
DEBUG - 2023-08-11 17:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:39:57 --> Controller Class Initialized
INFO - 2023-08-11 17:39:57 --> Model "Services_model" initialized
INFO - 2023-08-11 17:39:57 --> Helper loaded: form_helper
INFO - 2023-08-11 17:39:57 --> Form Validation Class Initialized
INFO - 2023-08-11 17:39:57 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-11 17:39:57 --> Final output sent to browser
DEBUG - 2023-08-11 17:39:57 --> Total execution time: 0.0914
INFO - 2023-08-11 17:39:57 --> Config Class Initialized
INFO - 2023-08-11 17:39:57 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:39:57 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:39:57 --> Utf8 Class Initialized
INFO - 2023-08-11 17:39:57 --> URI Class Initialized
INFO - 2023-08-11 17:39:57 --> Router Class Initialized
INFO - 2023-08-11 17:39:57 --> Output Class Initialized
INFO - 2023-08-11 17:39:57 --> Security Class Initialized
DEBUG - 2023-08-11 17:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:39:57 --> Input Class Initialized
INFO - 2023-08-11 17:39:57 --> Language Class Initialized
ERROR - 2023-08-11 17:39:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-11 17:39:58 --> Config Class Initialized
INFO - 2023-08-11 17:39:58 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:39:58 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:39:58 --> Utf8 Class Initialized
INFO - 2023-08-11 17:39:58 --> URI Class Initialized
INFO - 2023-08-11 17:39:58 --> Router Class Initialized
INFO - 2023-08-11 17:39:58 --> Output Class Initialized
INFO - 2023-08-11 17:39:58 --> Security Class Initialized
DEBUG - 2023-08-11 17:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:39:58 --> Input Class Initialized
INFO - 2023-08-11 17:39:58 --> Language Class Initialized
INFO - 2023-08-11 17:39:58 --> Loader Class Initialized
INFO - 2023-08-11 17:39:58 --> Helper loaded: url_helper
INFO - 2023-08-11 17:39:58 --> Helper loaded: file_helper
INFO - 2023-08-11 17:39:58 --> Database Driver Class Initialized
INFO - 2023-08-11 17:39:58 --> Email Class Initialized
DEBUG - 2023-08-11 17:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:39:58 --> Controller Class Initialized
INFO - 2023-08-11 17:39:58 --> Model "Services_model" initialized
INFO - 2023-08-11 17:39:58 --> Helper loaded: form_helper
INFO - 2023-08-11 17:39:58 --> Form Validation Class Initialized
INFO - 2023-08-11 17:39:58 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_create.php
INFO - 2023-08-11 17:39:58 --> Final output sent to browser
DEBUG - 2023-08-11 17:39:58 --> Total execution time: 0.0521
INFO - 2023-08-11 17:39:59 --> Config Class Initialized
INFO - 2023-08-11 17:39:59 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:39:59 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:39:59 --> Utf8 Class Initialized
INFO - 2023-08-11 17:39:59 --> URI Class Initialized
INFO - 2023-08-11 17:39:59 --> Router Class Initialized
INFO - 2023-08-11 17:39:59 --> Output Class Initialized
INFO - 2023-08-11 17:39:59 --> Security Class Initialized
DEBUG - 2023-08-11 17:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:39:59 --> Input Class Initialized
INFO - 2023-08-11 17:39:59 --> Language Class Initialized
ERROR - 2023-08-11 17:39:59 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-11 17:41:00 --> Config Class Initialized
INFO - 2023-08-11 17:41:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:41:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:41:00 --> Utf8 Class Initialized
INFO - 2023-08-11 17:41:00 --> URI Class Initialized
INFO - 2023-08-11 17:41:00 --> Router Class Initialized
INFO - 2023-08-11 17:41:00 --> Output Class Initialized
INFO - 2023-08-11 17:41:00 --> Security Class Initialized
DEBUG - 2023-08-11 17:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:41:00 --> Input Class Initialized
INFO - 2023-08-11 17:41:00 --> Language Class Initialized
INFO - 2023-08-11 17:41:00 --> Loader Class Initialized
INFO - 2023-08-11 17:41:00 --> Helper loaded: url_helper
INFO - 2023-08-11 17:41:00 --> Helper loaded: file_helper
INFO - 2023-08-11 17:41:00 --> Database Driver Class Initialized
INFO - 2023-08-11 17:41:00 --> Email Class Initialized
DEBUG - 2023-08-11 17:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:41:00 --> Controller Class Initialized
INFO - 2023-08-11 17:41:00 --> Model "Services_model" initialized
INFO - 2023-08-11 17:41:00 --> Helper loaded: form_helper
INFO - 2023-08-11 17:41:00 --> Form Validation Class Initialized
INFO - 2023-08-11 17:41:00 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_create.php
INFO - 2023-08-11 17:41:00 --> Final output sent to browser
DEBUG - 2023-08-11 17:41:00 --> Total execution time: 0.1759
INFO - 2023-08-11 17:41:06 --> Config Class Initialized
INFO - 2023-08-11 17:41:06 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:41:06 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:41:06 --> Utf8 Class Initialized
INFO - 2023-08-11 17:41:06 --> URI Class Initialized
INFO - 2023-08-11 17:41:06 --> Router Class Initialized
INFO - 2023-08-11 17:41:06 --> Output Class Initialized
INFO - 2023-08-11 17:41:06 --> Security Class Initialized
DEBUG - 2023-08-11 17:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:41:06 --> Input Class Initialized
INFO - 2023-08-11 17:41:06 --> Language Class Initialized
INFO - 2023-08-11 17:41:06 --> Loader Class Initialized
INFO - 2023-08-11 17:41:06 --> Helper loaded: url_helper
INFO - 2023-08-11 17:41:06 --> Helper loaded: file_helper
INFO - 2023-08-11 17:41:06 --> Database Driver Class Initialized
INFO - 2023-08-11 17:41:06 --> Email Class Initialized
DEBUG - 2023-08-11 17:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:41:06 --> Controller Class Initialized
INFO - 2023-08-11 17:41:06 --> Model "Services_model" initialized
INFO - 2023-08-11 17:41:06 --> Helper loaded: form_helper
INFO - 2023-08-11 17:41:06 --> Form Validation Class Initialized
INFO - 2023-08-11 17:41:06 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-11 17:41:06 --> Final output sent to browser
DEBUG - 2023-08-11 17:41:06 --> Total execution time: 0.0488
INFO - 2023-08-11 17:41:06 --> Config Class Initialized
INFO - 2023-08-11 17:41:06 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:41:06 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:41:06 --> Utf8 Class Initialized
INFO - 2023-08-11 17:41:06 --> URI Class Initialized
INFO - 2023-08-11 17:41:06 --> Router Class Initialized
INFO - 2023-08-11 17:41:06 --> Output Class Initialized
INFO - 2023-08-11 17:41:06 --> Security Class Initialized
DEBUG - 2023-08-11 17:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:41:06 --> Input Class Initialized
INFO - 2023-08-11 17:41:06 --> Language Class Initialized
ERROR - 2023-08-11 17:41:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-11 17:41:08 --> Config Class Initialized
INFO - 2023-08-11 17:41:08 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:41:08 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:41:08 --> Utf8 Class Initialized
INFO - 2023-08-11 17:41:08 --> URI Class Initialized
INFO - 2023-08-11 17:41:08 --> Router Class Initialized
INFO - 2023-08-11 17:41:08 --> Output Class Initialized
INFO - 2023-08-11 17:41:08 --> Security Class Initialized
DEBUG - 2023-08-11 17:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:41:08 --> Input Class Initialized
INFO - 2023-08-11 17:41:08 --> Language Class Initialized
INFO - 2023-08-11 17:41:08 --> Loader Class Initialized
INFO - 2023-08-11 17:41:08 --> Helper loaded: url_helper
INFO - 2023-08-11 17:41:08 --> Helper loaded: file_helper
INFO - 2023-08-11 17:41:08 --> Database Driver Class Initialized
INFO - 2023-08-11 17:41:08 --> Email Class Initialized
DEBUG - 2023-08-11 17:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:41:08 --> Controller Class Initialized
INFO - 2023-08-11 17:41:08 --> Model "Services_model" initialized
INFO - 2023-08-11 17:41:08 --> Helper loaded: form_helper
INFO - 2023-08-11 17:41:08 --> Form Validation Class Initialized
INFO - 2023-08-11 17:41:08 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_edit.php
INFO - 2023-08-11 17:41:08 --> Final output sent to browser
DEBUG - 2023-08-11 17:41:08 --> Total execution time: 0.0630
INFO - 2023-08-11 17:41:08 --> Config Class Initialized
INFO - 2023-08-11 17:41:08 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:41:08 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:41:08 --> Utf8 Class Initialized
INFO - 2023-08-11 17:41:08 --> URI Class Initialized
INFO - 2023-08-11 17:41:08 --> Router Class Initialized
INFO - 2023-08-11 17:41:08 --> Output Class Initialized
INFO - 2023-08-11 17:41:08 --> Security Class Initialized
DEBUG - 2023-08-11 17:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:41:08 --> Input Class Initialized
INFO - 2023-08-11 17:41:08 --> Language Class Initialized
ERROR - 2023-08-11 17:41:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-11 17:41:08 --> Config Class Initialized
INFO - 2023-08-11 17:41:08 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:41:08 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:41:08 --> Utf8 Class Initialized
INFO - 2023-08-11 17:41:08 --> URI Class Initialized
INFO - 2023-08-11 17:41:08 --> Router Class Initialized
INFO - 2023-08-11 17:41:08 --> Output Class Initialized
INFO - 2023-08-11 17:41:08 --> Security Class Initialized
DEBUG - 2023-08-11 17:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:41:08 --> Input Class Initialized
INFO - 2023-08-11 17:41:08 --> Language Class Initialized
INFO - 2023-08-11 17:41:08 --> Loader Class Initialized
INFO - 2023-08-11 17:41:08 --> Helper loaded: url_helper
INFO - 2023-08-11 17:41:08 --> Helper loaded: file_helper
INFO - 2023-08-11 17:41:08 --> Database Driver Class Initialized
INFO - 2023-08-11 17:41:08 --> Email Class Initialized
DEBUG - 2023-08-11 17:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:41:08 --> Controller Class Initialized
INFO - 2023-08-11 17:41:08 --> Model "Services_model" initialized
INFO - 2023-08-11 17:41:08 --> Helper loaded: form_helper
INFO - 2023-08-11 17:41:08 --> Form Validation Class Initialized
ERROR - 2023-08-11 17:41:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 39
ERROR - 2023-08-11 17:41:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 46
ERROR - 2023-08-11 17:41:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 56
ERROR - 2023-08-11 17:41:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 71
ERROR - 2023-08-11 17:41:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 85
ERROR - 2023-08-11 17:41:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 86
ERROR - 2023-08-11 17:41:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 87
ERROR - 2023-08-11 17:41:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 99
INFO - 2023-08-11 17:41:08 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_edit.php
INFO - 2023-08-11 17:41:08 --> Final output sent to browser
DEBUG - 2023-08-11 17:41:08 --> Total execution time: 0.0634
INFO - 2023-08-11 17:41:13 --> Config Class Initialized
INFO - 2023-08-11 17:41:13 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:41:13 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:41:13 --> Utf8 Class Initialized
INFO - 2023-08-11 17:41:13 --> URI Class Initialized
INFO - 2023-08-11 17:41:13 --> Router Class Initialized
INFO - 2023-08-11 17:41:13 --> Output Class Initialized
INFO - 2023-08-11 17:41:13 --> Security Class Initialized
DEBUG - 2023-08-11 17:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:41:13 --> Input Class Initialized
INFO - 2023-08-11 17:41:13 --> Language Class Initialized
INFO - 2023-08-11 17:41:13 --> Loader Class Initialized
INFO - 2023-08-11 17:41:13 --> Helper loaded: url_helper
INFO - 2023-08-11 17:41:13 --> Helper loaded: file_helper
INFO - 2023-08-11 17:41:13 --> Database Driver Class Initialized
INFO - 2023-08-11 17:41:13 --> Email Class Initialized
DEBUG - 2023-08-11 17:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:41:13 --> Controller Class Initialized
INFO - 2023-08-11 17:41:13 --> Model "Services_model" initialized
INFO - 2023-08-11 17:41:13 --> Helper loaded: form_helper
INFO - 2023-08-11 17:41:13 --> Form Validation Class Initialized
INFO - 2023-08-11 17:41:13 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-11 17:41:13 --> Final output sent to browser
DEBUG - 2023-08-11 17:41:13 --> Total execution time: 0.0662
INFO - 2023-08-11 17:41:15 --> Config Class Initialized
INFO - 2023-08-11 17:41:15 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:41:15 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:41:15 --> Utf8 Class Initialized
INFO - 2023-08-11 17:41:15 --> URI Class Initialized
INFO - 2023-08-11 17:41:15 --> Router Class Initialized
INFO - 2023-08-11 17:41:15 --> Output Class Initialized
INFO - 2023-08-11 17:41:15 --> Security Class Initialized
DEBUG - 2023-08-11 17:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:41:15 --> Input Class Initialized
INFO - 2023-08-11 17:41:15 --> Language Class Initialized
INFO - 2023-08-11 17:41:15 --> Loader Class Initialized
INFO - 2023-08-11 17:41:15 --> Helper loaded: url_helper
INFO - 2023-08-11 17:41:15 --> Helper loaded: file_helper
INFO - 2023-08-11 17:41:15 --> Database Driver Class Initialized
INFO - 2023-08-11 17:41:15 --> Email Class Initialized
DEBUG - 2023-08-11 17:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:41:15 --> Controller Class Initialized
INFO - 2023-08-11 17:41:15 --> Model "Services_model" initialized
INFO - 2023-08-11 17:41:15 --> Helper loaded: form_helper
INFO - 2023-08-11 17:41:15 --> Form Validation Class Initialized
INFO - 2023-08-11 17:41:15 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_edit.php
INFO - 2023-08-11 17:41:15 --> Final output sent to browser
DEBUG - 2023-08-11 17:41:15 --> Total execution time: 0.0557
INFO - 2023-08-11 17:41:15 --> Config Class Initialized
INFO - 2023-08-11 17:41:15 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:41:15 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:41:15 --> Utf8 Class Initialized
INFO - 2023-08-11 17:41:15 --> URI Class Initialized
INFO - 2023-08-11 17:41:15 --> Router Class Initialized
INFO - 2023-08-11 17:41:15 --> Output Class Initialized
INFO - 2023-08-11 17:41:15 --> Security Class Initialized
DEBUG - 2023-08-11 17:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:41:15 --> Input Class Initialized
INFO - 2023-08-11 17:41:15 --> Language Class Initialized
INFO - 2023-08-11 17:41:15 --> Loader Class Initialized
INFO - 2023-08-11 17:41:15 --> Helper loaded: url_helper
INFO - 2023-08-11 17:41:15 --> Helper loaded: file_helper
INFO - 2023-08-11 17:41:15 --> Database Driver Class Initialized
INFO - 2023-08-11 17:41:15 --> Email Class Initialized
DEBUG - 2023-08-11 17:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:41:15 --> Controller Class Initialized
INFO - 2023-08-11 17:41:15 --> Model "Services_model" initialized
INFO - 2023-08-11 17:41:15 --> Helper loaded: form_helper
INFO - 2023-08-11 17:41:15 --> Form Validation Class Initialized
ERROR - 2023-08-11 17:41:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 39
ERROR - 2023-08-11 17:41:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 46
ERROR - 2023-08-11 17:41:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 56
ERROR - 2023-08-11 17:41:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 71
ERROR - 2023-08-11 17:41:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 85
ERROR - 2023-08-11 17:41:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 86
ERROR - 2023-08-11 17:41:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 87
ERROR - 2023-08-11 17:41:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 99
INFO - 2023-08-11 17:41:15 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_edit.php
INFO - 2023-08-11 17:41:15 --> Final output sent to browser
DEBUG - 2023-08-11 17:41:15 --> Total execution time: 0.0490
INFO - 2023-08-11 17:42:00 --> Config Class Initialized
INFO - 2023-08-11 17:42:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:42:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:42:00 --> Utf8 Class Initialized
INFO - 2023-08-11 17:42:00 --> URI Class Initialized
INFO - 2023-08-11 17:42:00 --> Router Class Initialized
INFO - 2023-08-11 17:42:00 --> Output Class Initialized
INFO - 2023-08-11 17:42:00 --> Security Class Initialized
DEBUG - 2023-08-11 17:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:42:00 --> Input Class Initialized
INFO - 2023-08-11 17:42:00 --> Language Class Initialized
INFO - 2023-08-11 17:42:00 --> Loader Class Initialized
INFO - 2023-08-11 17:42:00 --> Helper loaded: url_helper
INFO - 2023-08-11 17:42:00 --> Helper loaded: file_helper
INFO - 2023-08-11 17:42:00 --> Database Driver Class Initialized
INFO - 2023-08-11 17:42:00 --> Email Class Initialized
DEBUG - 2023-08-11 17:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:42:00 --> Controller Class Initialized
INFO - 2023-08-11 17:42:00 --> Model "Services_model" initialized
INFO - 2023-08-11 17:42:00 --> Helper loaded: form_helper
INFO - 2023-08-11 17:42:00 --> Form Validation Class Initialized
INFO - 2023-08-11 17:42:00 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_edit.php
INFO - 2023-08-11 17:42:00 --> Final output sent to browser
DEBUG - 2023-08-11 17:42:00 --> Total execution time: 0.2169
INFO - 2023-08-11 17:42:00 --> Config Class Initialized
INFO - 2023-08-11 17:42:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:42:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:42:00 --> Utf8 Class Initialized
INFO - 2023-08-11 17:42:00 --> URI Class Initialized
INFO - 2023-08-11 17:42:00 --> Router Class Initialized
INFO - 2023-08-11 17:42:00 --> Output Class Initialized
INFO - 2023-08-11 17:42:00 --> Security Class Initialized
DEBUG - 2023-08-11 17:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:42:00 --> Input Class Initialized
INFO - 2023-08-11 17:42:00 --> Language Class Initialized
INFO - 2023-08-11 17:42:00 --> Loader Class Initialized
INFO - 2023-08-11 17:42:00 --> Helper loaded: url_helper
INFO - 2023-08-11 17:42:00 --> Helper loaded: file_helper
INFO - 2023-08-11 17:42:00 --> Database Driver Class Initialized
INFO - 2023-08-11 17:42:00 --> Email Class Initialized
DEBUG - 2023-08-11 17:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:42:01 --> Controller Class Initialized
INFO - 2023-08-11 17:42:01 --> Model "Services_model" initialized
INFO - 2023-08-11 17:42:01 --> Helper loaded: form_helper
INFO - 2023-08-11 17:42:01 --> Form Validation Class Initialized
ERROR - 2023-08-11 17:42:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 39
ERROR - 2023-08-11 17:42:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 46
ERROR - 2023-08-11 17:42:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 56
ERROR - 2023-08-11 17:42:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 75
ERROR - 2023-08-11 17:42:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 76
ERROR - 2023-08-11 17:42:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 77
ERROR - 2023-08-11 17:42:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 90
ERROR - 2023-08-11 17:42:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 100
INFO - 2023-08-11 17:42:01 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_edit.php
INFO - 2023-08-11 17:42:01 --> Final output sent to browser
DEBUG - 2023-08-11 17:42:01 --> Total execution time: 0.3962
INFO - 2023-08-11 17:42:05 --> Config Class Initialized
INFO - 2023-08-11 17:42:05 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:42:05 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:42:05 --> Utf8 Class Initialized
INFO - 2023-08-11 17:42:05 --> URI Class Initialized
INFO - 2023-08-11 17:42:05 --> Router Class Initialized
INFO - 2023-08-11 17:42:05 --> Output Class Initialized
INFO - 2023-08-11 17:42:05 --> Security Class Initialized
DEBUG - 2023-08-11 17:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:42:05 --> Input Class Initialized
INFO - 2023-08-11 17:42:05 --> Language Class Initialized
INFO - 2023-08-11 17:42:05 --> Loader Class Initialized
INFO - 2023-08-11 17:42:05 --> Helper loaded: url_helper
INFO - 2023-08-11 17:42:05 --> Helper loaded: file_helper
INFO - 2023-08-11 17:42:05 --> Database Driver Class Initialized
INFO - 2023-08-11 17:42:05 --> Email Class Initialized
DEBUG - 2023-08-11 17:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:42:05 --> Controller Class Initialized
INFO - 2023-08-11 17:42:05 --> Model "Services_model" initialized
INFO - 2023-08-11 17:42:05 --> Helper loaded: form_helper
INFO - 2023-08-11 17:42:05 --> Form Validation Class Initialized
INFO - 2023-08-11 17:42:05 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-11 17:42:05 --> Final output sent to browser
DEBUG - 2023-08-11 17:42:05 --> Total execution time: 0.0473
INFO - 2023-08-11 17:42:05 --> Config Class Initialized
INFO - 2023-08-11 17:42:05 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:42:05 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:42:05 --> Utf8 Class Initialized
INFO - 2023-08-11 17:42:05 --> URI Class Initialized
INFO - 2023-08-11 17:42:05 --> Router Class Initialized
INFO - 2023-08-11 17:42:05 --> Output Class Initialized
INFO - 2023-08-11 17:42:05 --> Security Class Initialized
DEBUG - 2023-08-11 17:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:42:05 --> Input Class Initialized
INFO - 2023-08-11 17:42:05 --> Language Class Initialized
ERROR - 2023-08-11 17:42:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-11 17:42:07 --> Config Class Initialized
INFO - 2023-08-11 17:42:07 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:42:07 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:42:07 --> Utf8 Class Initialized
INFO - 2023-08-11 17:42:07 --> URI Class Initialized
INFO - 2023-08-11 17:42:07 --> Router Class Initialized
INFO - 2023-08-11 17:42:07 --> Output Class Initialized
INFO - 2023-08-11 17:42:07 --> Security Class Initialized
DEBUG - 2023-08-11 17:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:42:07 --> Input Class Initialized
INFO - 2023-08-11 17:42:07 --> Language Class Initialized
INFO - 2023-08-11 17:42:07 --> Loader Class Initialized
INFO - 2023-08-11 17:42:07 --> Helper loaded: url_helper
INFO - 2023-08-11 17:42:07 --> Helper loaded: file_helper
INFO - 2023-08-11 17:42:07 --> Database Driver Class Initialized
INFO - 2023-08-11 17:42:07 --> Email Class Initialized
DEBUG - 2023-08-11 17:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:42:07 --> Controller Class Initialized
INFO - 2023-08-11 17:42:07 --> Model "Faq_model" initialized
INFO - 2023-08-11 17:42:07 --> Helper loaded: form_helper
INFO - 2023-08-11 17:42:07 --> Form Validation Class Initialized
INFO - 2023-08-11 17:42:07 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-11 17:42:07 --> Final output sent to browser
DEBUG - 2023-08-11 17:42:07 --> Total execution time: 0.0493
INFO - 2023-08-11 17:42:08 --> Config Class Initialized
INFO - 2023-08-11 17:42:08 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:42:08 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:42:08 --> Utf8 Class Initialized
INFO - 2023-08-11 17:42:08 --> URI Class Initialized
INFO - 2023-08-11 17:42:08 --> Router Class Initialized
INFO - 2023-08-11 17:42:08 --> Output Class Initialized
INFO - 2023-08-11 17:42:08 --> Security Class Initialized
DEBUG - 2023-08-11 17:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:42:08 --> Input Class Initialized
INFO - 2023-08-11 17:42:08 --> Language Class Initialized
INFO - 2023-08-11 17:42:08 --> Loader Class Initialized
INFO - 2023-08-11 17:42:08 --> Helper loaded: url_helper
INFO - 2023-08-11 17:42:08 --> Helper loaded: file_helper
INFO - 2023-08-11 17:42:08 --> Database Driver Class Initialized
INFO - 2023-08-11 17:42:09 --> Email Class Initialized
DEBUG - 2023-08-11 17:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:42:09 --> Controller Class Initialized
INFO - 2023-08-11 17:42:09 --> Model "Faq_model" initialized
INFO - 2023-08-11 17:42:09 --> Helper loaded: form_helper
INFO - 2023-08-11 17:42:09 --> Form Validation Class Initialized
INFO - 2023-08-11 17:42:09 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-11 17:42:09 --> Final output sent to browser
DEBUG - 2023-08-11 17:42:09 --> Total execution time: 0.0558
INFO - 2023-08-11 17:42:09 --> Config Class Initialized
INFO - 2023-08-11 17:42:09 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:42:09 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:42:09 --> Utf8 Class Initialized
INFO - 2023-08-11 17:42:09 --> URI Class Initialized
INFO - 2023-08-11 17:42:09 --> Router Class Initialized
INFO - 2023-08-11 17:42:09 --> Output Class Initialized
INFO - 2023-08-11 17:42:09 --> Security Class Initialized
DEBUG - 2023-08-11 17:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:42:09 --> Input Class Initialized
INFO - 2023-08-11 17:42:09 --> Language Class Initialized
ERROR - 2023-08-11 17:42:09 --> 404 Page Not Found: admin/Faq/images
INFO - 2023-08-11 17:45:09 --> Config Class Initialized
INFO - 2023-08-11 17:45:09 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:45:09 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:45:09 --> Utf8 Class Initialized
INFO - 2023-08-11 17:45:09 --> URI Class Initialized
INFO - 2023-08-11 17:45:09 --> Router Class Initialized
INFO - 2023-08-11 17:45:09 --> Output Class Initialized
INFO - 2023-08-11 17:45:09 --> Security Class Initialized
DEBUG - 2023-08-11 17:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:45:09 --> Input Class Initialized
INFO - 2023-08-11 17:45:09 --> Language Class Initialized
INFO - 2023-08-11 17:45:09 --> Loader Class Initialized
INFO - 2023-08-11 17:45:09 --> Helper loaded: url_helper
INFO - 2023-08-11 17:45:09 --> Helper loaded: file_helper
INFO - 2023-08-11 17:45:09 --> Database Driver Class Initialized
INFO - 2023-08-11 17:45:09 --> Email Class Initialized
DEBUG - 2023-08-11 17:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:45:09 --> Controller Class Initialized
INFO - 2023-08-11 17:45:09 --> Model "Faq_model" initialized
INFO - 2023-08-11 17:45:09 --> Helper loaded: form_helper
INFO - 2023-08-11 17:45:09 --> Form Validation Class Initialized
INFO - 2023-08-11 17:45:09 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-11 17:45:10 --> Final output sent to browser
DEBUG - 2023-08-11 17:45:10 --> Total execution time: 0.3895
INFO - 2023-08-11 17:45:12 --> Config Class Initialized
INFO - 2023-08-11 17:45:12 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:45:12 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:45:12 --> Utf8 Class Initialized
INFO - 2023-08-11 17:45:12 --> URI Class Initialized
INFO - 2023-08-11 17:45:12 --> Router Class Initialized
INFO - 2023-08-11 17:45:12 --> Output Class Initialized
INFO - 2023-08-11 17:45:12 --> Security Class Initialized
DEBUG - 2023-08-11 17:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:45:12 --> Input Class Initialized
INFO - 2023-08-11 17:45:12 --> Language Class Initialized
INFO - 2023-08-11 17:45:12 --> Loader Class Initialized
INFO - 2023-08-11 17:45:12 --> Helper loaded: url_helper
INFO - 2023-08-11 17:45:12 --> Helper loaded: file_helper
INFO - 2023-08-11 17:45:12 --> Database Driver Class Initialized
INFO - 2023-08-11 17:45:12 --> Email Class Initialized
DEBUG - 2023-08-11 17:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-11 17:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:45:12 --> Controller Class Initialized
INFO - 2023-08-11 17:45:12 --> Model "Faq_model" initialized
INFO - 2023-08-11 17:45:12 --> Helper loaded: form_helper
INFO - 2023-08-11 17:45:12 --> Form Validation Class Initialized
INFO - 2023-08-11 17:45:12 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-11 17:45:12 --> Final output sent to browser
DEBUG - 2023-08-11 17:45:12 --> Total execution time: 0.0509
