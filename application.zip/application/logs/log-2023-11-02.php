<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-02 16:13:18 --> Config Class Initialized
INFO - 2023-11-02 16:13:18 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:13:18 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:13:18 --> Utf8 Class Initialized
INFO - 2023-11-02 16:13:18 --> URI Class Initialized
DEBUG - 2023-11-02 16:13:18 --> No URI present. Default controller set.
INFO - 2023-11-02 16:13:18 --> Router Class Initialized
INFO - 2023-11-02 16:13:18 --> Output Class Initialized
INFO - 2023-11-02 16:13:18 --> Security Class Initialized
DEBUG - 2023-11-02 16:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:13:18 --> Input Class Initialized
INFO - 2023-11-02 16:13:18 --> Language Class Initialized
INFO - 2023-11-02 16:13:18 --> Loader Class Initialized
INFO - 2023-11-02 16:13:18 --> Helper loaded: url_helper
INFO - 2023-11-02 16:13:18 --> Helper loaded: file_helper
INFO - 2023-11-02 16:13:18 --> Database Driver Class Initialized
INFO - 2023-11-02 16:13:18 --> Email Class Initialized
DEBUG - 2023-11-02 16:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 16:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 16:13:18 --> Controller Class Initialized
INFO - 2023-11-02 16:13:18 --> Model "Contact_model" initialized
INFO - 2023-11-02 16:13:18 --> Model "CareerFormModel" initialized
INFO - 2023-11-02 16:13:18 --> Model "Home_model" initialized
INFO - 2023-11-02 16:13:18 --> Helper loaded: download_helper
INFO - 2023-11-02 16:13:18 --> Helper loaded: form_helper
INFO - 2023-11-02 16:13:18 --> Form Validation Class Initialized
INFO - 2023-11-02 16:13:18 --> Helper loaded: custom_helper
INFO - 2023-11-02 16:13:18 --> Model "Social_media_model" initialized
ERROR - 2023-11-02 16:13:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-02 16:13:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-02 16:13:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-02 16:13:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-02 16:13:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-02 16:13:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-02 16:13:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-02 16:13:18 --> Final output sent to browser
DEBUG - 2023-11-02 16:13:18 --> Total execution time: 0.1679
INFO - 2023-11-02 16:13:25 --> Config Class Initialized
INFO - 2023-11-02 16:13:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:13:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:13:25 --> Utf8 Class Initialized
INFO - 2023-11-02 16:13:25 --> URI Class Initialized
INFO - 2023-11-02 16:13:25 --> Router Class Initialized
INFO - 2023-11-02 16:13:25 --> Output Class Initialized
INFO - 2023-11-02 16:13:25 --> Security Class Initialized
DEBUG - 2023-11-02 16:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:13:25 --> Input Class Initialized
INFO - 2023-11-02 16:13:25 --> Language Class Initialized
INFO - 2023-11-02 16:13:25 --> Loader Class Initialized
INFO - 2023-11-02 16:13:25 --> Helper loaded: url_helper
INFO - 2023-11-02 16:13:25 --> Helper loaded: file_helper
INFO - 2023-11-02 16:13:25 --> Database Driver Class Initialized
INFO - 2023-11-02 16:13:25 --> Email Class Initialized
DEBUG - 2023-11-02 16:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 16:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 16:13:25 --> Controller Class Initialized
INFO - 2023-11-02 16:13:25 --> Model "Contact_model" initialized
INFO - 2023-11-02 16:13:25 --> Model "CareerFormModel" initialized
INFO - 2023-11-02 16:13:25 --> Model "Home_model" initialized
INFO - 2023-11-02 16:13:25 --> Helper loaded: download_helper
INFO - 2023-11-02 16:13:25 --> Helper loaded: form_helper
INFO - 2023-11-02 16:13:25 --> Form Validation Class Initialized
INFO - 2023-11-02 16:13:25 --> Helper loaded: custom_helper
INFO - 2023-11-02 16:13:25 --> Model "Social_media_model" initialized
ERROR - 2023-11-02 16:13:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-02 16:13:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-02 16:13:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-02 16:13:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-02 16:13:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-02 16:13:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-02 16:13:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-11-02 16:13:25 --> Final output sent to browser
DEBUG - 2023-11-02 16:13:25 --> Total execution time: 0.0971
INFO - 2023-11-02 16:13:29 --> Config Class Initialized
INFO - 2023-11-02 16:13:29 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:13:29 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:13:29 --> Utf8 Class Initialized
INFO - 2023-11-02 16:13:29 --> URI Class Initialized
INFO - 2023-11-02 16:13:29 --> Router Class Initialized
INFO - 2023-11-02 16:13:29 --> Output Class Initialized
INFO - 2023-11-02 16:13:29 --> Security Class Initialized
DEBUG - 2023-11-02 16:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:13:29 --> Input Class Initialized
INFO - 2023-11-02 16:13:29 --> Language Class Initialized
ERROR - 2023-11-02 16:13:29 --> 404 Page Not Found: Assets/home
INFO - 2023-11-02 16:13:30 --> Config Class Initialized
INFO - 2023-11-02 16:13:30 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:13:30 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:13:30 --> Utf8 Class Initialized
INFO - 2023-11-02 16:13:30 --> URI Class Initialized
INFO - 2023-11-02 16:13:30 --> Router Class Initialized
INFO - 2023-11-02 16:13:30 --> Output Class Initialized
INFO - 2023-11-02 16:13:30 --> Security Class Initialized
DEBUG - 2023-11-02 16:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:13:30 --> Input Class Initialized
INFO - 2023-11-02 16:13:30 --> Language Class Initialized
ERROR - 2023-11-02 16:13:30 --> 404 Page Not Found: Assets/home
INFO - 2023-11-02 16:13:30 --> Config Class Initialized
INFO - 2023-11-02 16:13:30 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:13:30 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:13:30 --> Utf8 Class Initialized
INFO - 2023-11-02 16:13:30 --> URI Class Initialized
INFO - 2023-11-02 16:13:30 --> Router Class Initialized
INFO - 2023-11-02 16:13:30 --> Output Class Initialized
INFO - 2023-11-02 16:13:30 --> Security Class Initialized
DEBUG - 2023-11-02 16:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:13:30 --> Input Class Initialized
INFO - 2023-11-02 16:13:30 --> Language Class Initialized
ERROR - 2023-11-02 16:13:30 --> 404 Page Not Found: Assets/home
INFO - 2023-11-02 16:13:30 --> Config Class Initialized
INFO - 2023-11-02 16:13:30 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:13:30 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:13:30 --> Utf8 Class Initialized
INFO - 2023-11-02 16:13:30 --> URI Class Initialized
INFO - 2023-11-02 16:13:30 --> Router Class Initialized
INFO - 2023-11-02 16:13:30 --> Output Class Initialized
INFO - 2023-11-02 16:13:30 --> Security Class Initialized
DEBUG - 2023-11-02 16:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:13:30 --> Input Class Initialized
INFO - 2023-11-02 16:13:30 --> Language Class Initialized
ERROR - 2023-11-02 16:13:30 --> 404 Page Not Found: Assets/home
INFO - 2023-11-02 16:13:30 --> Config Class Initialized
INFO - 2023-11-02 16:13:30 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:13:30 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:13:30 --> Utf8 Class Initialized
INFO - 2023-11-02 16:13:30 --> URI Class Initialized
INFO - 2023-11-02 16:13:30 --> Router Class Initialized
INFO - 2023-11-02 16:13:30 --> Output Class Initialized
INFO - 2023-11-02 16:13:30 --> Security Class Initialized
DEBUG - 2023-11-02 16:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:13:30 --> Input Class Initialized
INFO - 2023-11-02 16:13:30 --> Language Class Initialized
ERROR - 2023-11-02 16:13:30 --> 404 Page Not Found: Assets/home
INFO - 2023-11-02 16:13:30 --> Config Class Initialized
INFO - 2023-11-02 16:13:30 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:13:30 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:13:30 --> Utf8 Class Initialized
INFO - 2023-11-02 16:13:30 --> URI Class Initialized
INFO - 2023-11-02 16:13:30 --> Router Class Initialized
INFO - 2023-11-02 16:13:30 --> Output Class Initialized
INFO - 2023-11-02 16:13:30 --> Security Class Initialized
DEBUG - 2023-11-02 16:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:13:30 --> Input Class Initialized
INFO - 2023-11-02 16:13:30 --> Language Class Initialized
ERROR - 2023-11-02 16:13:30 --> 404 Page Not Found: Assets/home
INFO - 2023-11-02 16:13:30 --> Config Class Initialized
INFO - 2023-11-02 16:13:30 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:13:30 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:13:30 --> Utf8 Class Initialized
INFO - 2023-11-02 16:13:30 --> URI Class Initialized
INFO - 2023-11-02 16:13:30 --> Router Class Initialized
INFO - 2023-11-02 16:13:30 --> Output Class Initialized
INFO - 2023-11-02 16:13:30 --> Security Class Initialized
DEBUG - 2023-11-02 16:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:13:30 --> Input Class Initialized
INFO - 2023-11-02 16:13:30 --> Language Class Initialized
ERROR - 2023-11-02 16:13:30 --> 404 Page Not Found: Assets/home
INFO - 2023-11-02 16:13:50 --> Config Class Initialized
INFO - 2023-11-02 16:13:50 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:13:50 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:13:50 --> Utf8 Class Initialized
INFO - 2023-11-02 16:13:50 --> URI Class Initialized
INFO - 2023-11-02 16:13:50 --> Router Class Initialized
INFO - 2023-11-02 16:13:50 --> Output Class Initialized
INFO - 2023-11-02 16:13:50 --> Security Class Initialized
DEBUG - 2023-11-02 16:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:13:50 --> Input Class Initialized
INFO - 2023-11-02 16:13:50 --> Language Class Initialized
INFO - 2023-11-02 16:13:50 --> Loader Class Initialized
INFO - 2023-11-02 16:13:50 --> Helper loaded: url_helper
INFO - 2023-11-02 16:13:50 --> Helper loaded: file_helper
INFO - 2023-11-02 16:13:50 --> Database Driver Class Initialized
INFO - 2023-11-02 16:13:50 --> Email Class Initialized
DEBUG - 2023-11-02 16:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 16:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 16:13:50 --> Controller Class Initialized
INFO - 2023-11-02 16:13:50 --> Model "Contact_model" initialized
INFO - 2023-11-02 16:13:50 --> Model "CareerFormModel" initialized
INFO - 2023-11-02 16:13:50 --> Model "Home_model" initialized
INFO - 2023-11-02 16:13:50 --> Helper loaded: download_helper
INFO - 2023-11-02 16:13:50 --> Helper loaded: form_helper
INFO - 2023-11-02 16:13:50 --> Form Validation Class Initialized
INFO - 2023-11-02 16:15:11 --> Config Class Initialized
INFO - 2023-11-02 16:15:11 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:15:11 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:15:11 --> Utf8 Class Initialized
INFO - 2023-11-02 16:15:11 --> URI Class Initialized
INFO - 2023-11-02 16:15:11 --> Router Class Initialized
INFO - 2023-11-02 16:15:11 --> Output Class Initialized
INFO - 2023-11-02 16:15:11 --> Security Class Initialized
DEBUG - 2023-11-02 16:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:15:11 --> Input Class Initialized
INFO - 2023-11-02 16:15:11 --> Language Class Initialized
INFO - 2023-11-02 16:15:11 --> Loader Class Initialized
INFO - 2023-11-02 16:15:11 --> Helper loaded: url_helper
INFO - 2023-11-02 16:15:11 --> Helper loaded: file_helper
INFO - 2023-11-02 16:15:11 --> Database Driver Class Initialized
INFO - 2023-11-02 16:15:11 --> Email Class Initialized
DEBUG - 2023-11-02 16:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 16:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 16:15:11 --> Controller Class Initialized
INFO - 2023-11-02 16:15:11 --> Model "Contact_model" initialized
INFO - 2023-11-02 16:15:11 --> Model "CareerFormModel" initialized
INFO - 2023-11-02 16:15:11 --> Model "Home_model" initialized
INFO - 2023-11-02 16:15:11 --> Helper loaded: download_helper
INFO - 2023-11-02 16:15:11 --> Helper loaded: form_helper
INFO - 2023-11-02 16:15:11 --> Form Validation Class Initialized
ERROR - 2023-11-02 16:15:11 --> Severity: Warning --> Attempt to read property "name" on array C:\xampp\htdocs\dw\application\controllers\HomeController.php 227
INFO - 2023-11-02 16:16:23 --> Config Class Initialized
INFO - 2023-11-02 16:16:23 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:16:23 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:16:23 --> Utf8 Class Initialized
INFO - 2023-11-02 16:16:23 --> URI Class Initialized
INFO - 2023-11-02 16:16:23 --> Router Class Initialized
INFO - 2023-11-02 16:16:23 --> Output Class Initialized
INFO - 2023-11-02 16:16:23 --> Security Class Initialized
DEBUG - 2023-11-02 16:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:16:23 --> Input Class Initialized
INFO - 2023-11-02 16:16:23 --> Language Class Initialized
INFO - 2023-11-02 16:16:23 --> Loader Class Initialized
INFO - 2023-11-02 16:16:24 --> Helper loaded: url_helper
INFO - 2023-11-02 16:16:24 --> Helper loaded: file_helper
INFO - 2023-11-02 16:16:24 --> Database Driver Class Initialized
INFO - 2023-11-02 16:16:24 --> Email Class Initialized
DEBUG - 2023-11-02 16:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 16:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 16:16:24 --> Controller Class Initialized
INFO - 2023-11-02 16:16:24 --> Model "Contact_model" initialized
INFO - 2023-11-02 16:16:24 --> Model "CareerFormModel" initialized
INFO - 2023-11-02 16:16:24 --> Model "Home_model" initialized
INFO - 2023-11-02 16:16:24 --> Helper loaded: download_helper
INFO - 2023-11-02 16:16:24 --> Helper loaded: form_helper
INFO - 2023-11-02 16:16:24 --> Form Validation Class Initialized
INFO - 2023-11-02 16:17:09 --> Config Class Initialized
INFO - 2023-11-02 16:17:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:17:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:17:09 --> Utf8 Class Initialized
INFO - 2023-11-02 16:17:09 --> URI Class Initialized
INFO - 2023-11-02 16:17:09 --> Router Class Initialized
INFO - 2023-11-02 16:17:09 --> Output Class Initialized
INFO - 2023-11-02 16:17:09 --> Security Class Initialized
DEBUG - 2023-11-02 16:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:17:09 --> Input Class Initialized
INFO - 2023-11-02 16:17:09 --> Language Class Initialized
INFO - 2023-11-02 16:17:09 --> Loader Class Initialized
INFO - 2023-11-02 16:17:09 --> Helper loaded: url_helper
INFO - 2023-11-02 16:17:09 --> Helper loaded: file_helper
INFO - 2023-11-02 16:17:09 --> Database Driver Class Initialized
INFO - 2023-11-02 16:17:09 --> Email Class Initialized
DEBUG - 2023-11-02 16:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 16:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 16:17:09 --> Controller Class Initialized
INFO - 2023-11-02 16:17:09 --> Model "Contact_model" initialized
INFO - 2023-11-02 16:17:09 --> Model "CareerFormModel" initialized
INFO - 2023-11-02 16:17:09 --> Model "Home_model" initialized
INFO - 2023-11-02 16:17:09 --> Helper loaded: download_helper
INFO - 2023-11-02 16:17:09 --> Helper loaded: form_helper
INFO - 2023-11-02 16:17:09 --> Form Validation Class Initialized
INFO - 2023-11-02 16:17:27 --> Config Class Initialized
INFO - 2023-11-02 16:17:27 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:17:27 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:17:27 --> Utf8 Class Initialized
INFO - 2023-11-02 16:17:27 --> URI Class Initialized
INFO - 2023-11-02 16:17:27 --> Router Class Initialized
INFO - 2023-11-02 16:17:27 --> Output Class Initialized
INFO - 2023-11-02 16:17:27 --> Security Class Initialized
DEBUG - 2023-11-02 16:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:17:27 --> Input Class Initialized
INFO - 2023-11-02 16:17:27 --> Language Class Initialized
INFO - 2023-11-02 16:17:27 --> Loader Class Initialized
INFO - 2023-11-02 16:17:27 --> Helper loaded: url_helper
INFO - 2023-11-02 16:17:27 --> Helper loaded: file_helper
INFO - 2023-11-02 16:17:27 --> Database Driver Class Initialized
INFO - 2023-11-02 16:17:27 --> Email Class Initialized
DEBUG - 2023-11-02 16:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 16:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 16:17:27 --> Controller Class Initialized
INFO - 2023-11-02 16:17:27 --> Model "Contact_model" initialized
INFO - 2023-11-02 16:17:27 --> Model "CareerFormModel" initialized
INFO - 2023-11-02 16:17:27 --> Model "Home_model" initialized
INFO - 2023-11-02 16:17:27 --> Helper loaded: download_helper
INFO - 2023-11-02 16:17:27 --> Helper loaded: form_helper
INFO - 2023-11-02 16:17:27 --> Form Validation Class Initialized
