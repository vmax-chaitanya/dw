<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-01 15:45:50 --> Config Class Initialized
INFO - 2023-08-01 15:45:50 --> Hooks Class Initialized
DEBUG - 2023-08-01 15:45:50 --> UTF-8 Support Enabled
INFO - 2023-08-01 15:45:50 --> Utf8 Class Initialized
INFO - 2023-08-01 15:45:50 --> URI Class Initialized
INFO - 2023-08-01 15:45:50 --> Router Class Initialized
INFO - 2023-08-01 15:45:50 --> Output Class Initialized
INFO - 2023-08-01 15:45:50 --> Security Class Initialized
DEBUG - 2023-08-01 15:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 15:45:50 --> Input Class Initialized
INFO - 2023-08-01 15:45:50 --> Language Class Initialized
INFO - 2023-08-01 15:45:50 --> Loader Class Initialized
INFO - 2023-08-01 15:45:50 --> Helper loaded: url_helper
INFO - 2023-08-01 15:45:50 --> Helper loaded: file_helper
INFO - 2023-08-01 15:45:50 --> Database Driver Class Initialized
INFO - 2023-08-01 15:45:50 --> Email Class Initialized
DEBUG - 2023-08-01 15:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 15:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 15:45:50 --> Controller Class Initialized
INFO - 2023-08-01 15:45:50 --> Model "Banner_model" initialized
INFO - 2023-08-01 15:45:50 --> Helper loaded: form_helper
INFO - 2023-08-01 15:45:50 --> Form Validation Class Initialized
INFO - 2023-08-01 15:45:50 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-01 15:45:50 --> Final output sent to browser
DEBUG - 2023-08-01 15:45:50 --> Total execution time: 0.0599
INFO - 2023-08-01 15:45:50 --> Config Class Initialized
INFO - 2023-08-01 15:45:50 --> Hooks Class Initialized
DEBUG - 2023-08-01 15:45:50 --> UTF-8 Support Enabled
INFO - 2023-08-01 15:45:50 --> Utf8 Class Initialized
INFO - 2023-08-01 15:45:50 --> URI Class Initialized
INFO - 2023-08-01 15:45:50 --> Router Class Initialized
INFO - 2023-08-01 15:45:50 --> Output Class Initialized
INFO - 2023-08-01 15:45:50 --> Security Class Initialized
DEBUG - 2023-08-01 15:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 15:45:50 --> Input Class Initialized
INFO - 2023-08-01 15:45:50 --> Language Class Initialized
ERROR - 2023-08-01 15:45:50 --> 404 Page Not Found: admin/Images/faces
