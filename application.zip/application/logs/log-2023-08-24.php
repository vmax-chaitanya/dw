<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-24 18:14:33 --> Config Class Initialized
INFO - 2023-08-24 18:14:33 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:14:33 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:14:33 --> Utf8 Class Initialized
INFO - 2023-08-24 18:14:33 --> URI Class Initialized
INFO - 2023-08-24 18:14:33 --> Router Class Initialized
INFO - 2023-08-24 18:14:33 --> Output Class Initialized
INFO - 2023-08-24 18:14:33 --> Security Class Initialized
DEBUG - 2023-08-24 18:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:14:33 --> Input Class Initialized
INFO - 2023-08-24 18:14:33 --> Language Class Initialized
INFO - 2023-08-24 18:14:33 --> Loader Class Initialized
INFO - 2023-08-24 18:14:33 --> Helper loaded: url_helper
INFO - 2023-08-24 18:14:33 --> Helper loaded: file_helper
INFO - 2023-08-24 18:14:33 --> Database Driver Class Initialized
INFO - 2023-08-24 18:14:33 --> Email Class Initialized
DEBUG - 2023-08-24 18:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:14:34 --> Controller Class Initialized
INFO - 2023-08-24 18:14:34 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:14:34 --> Model "Home_model" initialized
INFO - 2023-08-24 18:14:34 --> Helper loaded: download_helper
INFO - 2023-08-24 18:14:34 --> Helper loaded: form_helper
INFO - 2023-08-24 18:14:34 --> Form Validation Class Initialized
INFO - 2023-08-24 18:14:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 18:14:34 --> Final output sent to browser
DEBUG - 2023-08-24 18:14:34 --> Total execution time: 0.6381
INFO - 2023-08-24 18:14:37 --> Config Class Initialized
INFO - 2023-08-24 18:14:37 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:14:37 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:14:37 --> Utf8 Class Initialized
INFO - 2023-08-24 18:14:37 --> URI Class Initialized
INFO - 2023-08-24 18:14:37 --> Router Class Initialized
INFO - 2023-08-24 18:14:37 --> Output Class Initialized
INFO - 2023-08-24 18:14:37 --> Security Class Initialized
DEBUG - 2023-08-24 18:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:14:37 --> Input Class Initialized
INFO - 2023-08-24 18:14:37 --> Language Class Initialized
ERROR - 2023-08-24 18:14:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 18:14:38 --> Config Class Initialized
INFO - 2023-08-24 18:14:38 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:14:38 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:14:38 --> Utf8 Class Initialized
INFO - 2023-08-24 18:14:38 --> URI Class Initialized
INFO - 2023-08-24 18:14:38 --> Router Class Initialized
INFO - 2023-08-24 18:14:38 --> Output Class Initialized
INFO - 2023-08-24 18:14:38 --> Security Class Initialized
DEBUG - 2023-08-24 18:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:14:38 --> Input Class Initialized
INFO - 2023-08-24 18:14:38 --> Language Class Initialized
ERROR - 2023-08-24 18:14:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 18:14:38 --> Config Class Initialized
INFO - 2023-08-24 18:14:38 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:14:38 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:14:38 --> Utf8 Class Initialized
INFO - 2023-08-24 18:14:38 --> URI Class Initialized
INFO - 2023-08-24 18:14:38 --> Router Class Initialized
INFO - 2023-08-24 18:14:38 --> Output Class Initialized
INFO - 2023-08-24 18:14:38 --> Security Class Initialized
DEBUG - 2023-08-24 18:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:14:38 --> Input Class Initialized
INFO - 2023-08-24 18:14:38 --> Language Class Initialized
ERROR - 2023-08-24 18:14:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 18:14:39 --> Config Class Initialized
INFO - 2023-08-24 18:14:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:14:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:14:39 --> Utf8 Class Initialized
INFO - 2023-08-24 18:14:39 --> URI Class Initialized
INFO - 2023-08-24 18:14:39 --> Router Class Initialized
INFO - 2023-08-24 18:14:39 --> Output Class Initialized
INFO - 2023-08-24 18:14:39 --> Security Class Initialized
DEBUG - 2023-08-24 18:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:14:39 --> Input Class Initialized
INFO - 2023-08-24 18:14:39 --> Language Class Initialized
ERROR - 2023-08-24 18:14:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 18:14:39 --> Config Class Initialized
INFO - 2023-08-24 18:14:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:14:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:14:39 --> Utf8 Class Initialized
INFO - 2023-08-24 18:14:39 --> URI Class Initialized
INFO - 2023-08-24 18:14:39 --> Router Class Initialized
INFO - 2023-08-24 18:14:39 --> Output Class Initialized
INFO - 2023-08-24 18:14:39 --> Security Class Initialized
DEBUG - 2023-08-24 18:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:14:39 --> Input Class Initialized
INFO - 2023-08-24 18:14:39 --> Language Class Initialized
ERROR - 2023-08-24 18:14:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 18:14:39 --> Config Class Initialized
INFO - 2023-08-24 18:14:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:14:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:14:39 --> Utf8 Class Initialized
INFO - 2023-08-24 18:14:39 --> URI Class Initialized
INFO - 2023-08-24 18:14:39 --> Router Class Initialized
INFO - 2023-08-24 18:14:39 --> Output Class Initialized
INFO - 2023-08-24 18:14:39 --> Security Class Initialized
DEBUG - 2023-08-24 18:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:14:39 --> Input Class Initialized
INFO - 2023-08-24 18:14:39 --> Language Class Initialized
ERROR - 2023-08-24 18:14:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 18:14:39 --> Config Class Initialized
INFO - 2023-08-24 18:14:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:14:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:14:39 --> Utf8 Class Initialized
INFO - 2023-08-24 18:14:40 --> URI Class Initialized
INFO - 2023-08-24 18:14:40 --> Router Class Initialized
INFO - 2023-08-24 18:14:40 --> Output Class Initialized
INFO - 2023-08-24 18:14:40 --> Security Class Initialized
DEBUG - 2023-08-24 18:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:14:40 --> Input Class Initialized
INFO - 2023-08-24 18:14:40 --> Language Class Initialized
ERROR - 2023-08-24 18:14:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 18:14:41 --> Config Class Initialized
INFO - 2023-08-24 18:14:41 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:14:41 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:14:41 --> Utf8 Class Initialized
INFO - 2023-08-24 18:14:41 --> URI Class Initialized
INFO - 2023-08-24 18:14:41 --> Router Class Initialized
INFO - 2023-08-24 18:14:41 --> Output Class Initialized
INFO - 2023-08-24 18:14:41 --> Security Class Initialized
DEBUG - 2023-08-24 18:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:14:41 --> Input Class Initialized
INFO - 2023-08-24 18:14:41 --> Language Class Initialized
ERROR - 2023-08-24 18:14:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 18:14:58 --> Config Class Initialized
INFO - 2023-08-24 18:14:58 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:14:59 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:15:00 --> Utf8 Class Initialized
INFO - 2023-08-24 18:15:00 --> URI Class Initialized
INFO - 2023-08-24 18:15:00 --> Router Class Initialized
INFO - 2023-08-24 18:15:00 --> Output Class Initialized
INFO - 2023-08-24 18:15:01 --> Security Class Initialized
DEBUG - 2023-08-24 18:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:15:01 --> Input Class Initialized
INFO - 2023-08-24 18:15:01 --> Language Class Initialized
INFO - 2023-08-24 18:15:01 --> Loader Class Initialized
INFO - 2023-08-24 18:15:01 --> Helper loaded: url_helper
INFO - 2023-08-24 18:15:01 --> Helper loaded: file_helper
INFO - 2023-08-24 18:15:01 --> Database Driver Class Initialized
INFO - 2023-08-24 18:15:01 --> Email Class Initialized
DEBUG - 2023-08-24 18:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:15:01 --> Controller Class Initialized
INFO - 2023-08-24 18:15:01 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:15:01 --> Model "Home_model" initialized
INFO - 2023-08-24 18:15:01 --> Helper loaded: download_helper
INFO - 2023-08-24 18:15:01 --> Helper loaded: form_helper
INFO - 2023-08-24 18:15:01 --> Form Validation Class Initialized
INFO - 2023-08-24 18:15:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 18:15:01 --> Final output sent to browser
DEBUG - 2023-08-24 18:15:01 --> Total execution time: 3.9941
INFO - 2023-08-24 18:15:01 --> Config Class Initialized
INFO - 2023-08-24 18:15:01 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:15:01 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:15:01 --> Utf8 Class Initialized
INFO - 2023-08-24 18:15:01 --> URI Class Initialized
INFO - 2023-08-24 18:15:01 --> Router Class Initialized
INFO - 2023-08-24 18:15:01 --> Output Class Initialized
INFO - 2023-08-24 18:15:01 --> Security Class Initialized
DEBUG - 2023-08-24 18:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:15:01 --> Input Class Initialized
INFO - 2023-08-24 18:15:01 --> Language Class Initialized
ERROR - 2023-08-24 18:15:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:15:01 --> Config Class Initialized
INFO - 2023-08-24 18:15:01 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:15:01 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:15:01 --> Utf8 Class Initialized
INFO - 2023-08-24 18:15:01 --> URI Class Initialized
INFO - 2023-08-24 18:15:01 --> Router Class Initialized
INFO - 2023-08-24 18:15:01 --> Output Class Initialized
INFO - 2023-08-24 18:15:02 --> Security Class Initialized
DEBUG - 2023-08-24 18:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:15:02 --> Input Class Initialized
INFO - 2023-08-24 18:15:02 --> Language Class Initialized
ERROR - 2023-08-24 18:15:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:15:02 --> Config Class Initialized
INFO - 2023-08-24 18:15:02 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:15:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:15:02 --> Utf8 Class Initialized
INFO - 2023-08-24 18:15:02 --> URI Class Initialized
INFO - 2023-08-24 18:15:02 --> Router Class Initialized
INFO - 2023-08-24 18:15:02 --> Output Class Initialized
INFO - 2023-08-24 18:15:02 --> Security Class Initialized
DEBUG - 2023-08-24 18:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:15:02 --> Input Class Initialized
INFO - 2023-08-24 18:15:02 --> Language Class Initialized
ERROR - 2023-08-24 18:15:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:15:02 --> Config Class Initialized
INFO - 2023-08-24 18:15:02 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:15:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:15:02 --> Utf8 Class Initialized
INFO - 2023-08-24 18:15:02 --> URI Class Initialized
INFO - 2023-08-24 18:15:02 --> Router Class Initialized
INFO - 2023-08-24 18:15:02 --> Output Class Initialized
INFO - 2023-08-24 18:15:02 --> Security Class Initialized
DEBUG - 2023-08-24 18:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:15:02 --> Input Class Initialized
INFO - 2023-08-24 18:15:02 --> Language Class Initialized
ERROR - 2023-08-24 18:15:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:15:02 --> Config Class Initialized
INFO - 2023-08-24 18:15:02 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:15:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:15:02 --> Utf8 Class Initialized
INFO - 2023-08-24 18:15:02 --> URI Class Initialized
INFO - 2023-08-24 18:15:02 --> Router Class Initialized
INFO - 2023-08-24 18:15:02 --> Output Class Initialized
INFO - 2023-08-24 18:15:02 --> Security Class Initialized
DEBUG - 2023-08-24 18:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:15:02 --> Input Class Initialized
INFO - 2023-08-24 18:15:02 --> Language Class Initialized
ERROR - 2023-08-24 18:15:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:15:02 --> Config Class Initialized
INFO - 2023-08-24 18:15:02 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:15:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:15:02 --> Utf8 Class Initialized
INFO - 2023-08-24 18:15:02 --> URI Class Initialized
INFO - 2023-08-24 18:15:02 --> Router Class Initialized
INFO - 2023-08-24 18:15:02 --> Output Class Initialized
INFO - 2023-08-24 18:15:02 --> Security Class Initialized
DEBUG - 2023-08-24 18:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:15:02 --> Input Class Initialized
INFO - 2023-08-24 18:15:02 --> Language Class Initialized
ERROR - 2023-08-24 18:15:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:15:02 --> Config Class Initialized
INFO - 2023-08-24 18:15:02 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:15:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:15:02 --> Utf8 Class Initialized
INFO - 2023-08-24 18:15:02 --> URI Class Initialized
INFO - 2023-08-24 18:15:02 --> Router Class Initialized
INFO - 2023-08-24 18:15:02 --> Output Class Initialized
INFO - 2023-08-24 18:15:02 --> Security Class Initialized
DEBUG - 2023-08-24 18:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:15:02 --> Input Class Initialized
INFO - 2023-08-24 18:15:02 --> Language Class Initialized
ERROR - 2023-08-24 18:15:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:15:03 --> Config Class Initialized
INFO - 2023-08-24 18:15:03 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:15:03 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:15:03 --> Utf8 Class Initialized
INFO - 2023-08-24 18:15:03 --> URI Class Initialized
INFO - 2023-08-24 18:15:04 --> Router Class Initialized
INFO - 2023-08-24 18:15:04 --> Output Class Initialized
INFO - 2023-08-24 18:15:04 --> Security Class Initialized
DEBUG - 2023-08-24 18:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:15:04 --> Input Class Initialized
INFO - 2023-08-24 18:15:04 --> Language Class Initialized
ERROR - 2023-08-24 18:15:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:22:15 --> Config Class Initialized
INFO - 2023-08-24 18:22:15 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:22:15 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:22:15 --> Utf8 Class Initialized
INFO - 2023-08-24 18:22:15 --> URI Class Initialized
INFO - 2023-08-24 18:22:15 --> Router Class Initialized
INFO - 2023-08-24 18:22:15 --> Output Class Initialized
INFO - 2023-08-24 18:22:15 --> Security Class Initialized
DEBUG - 2023-08-24 18:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:22:15 --> Input Class Initialized
INFO - 2023-08-24 18:22:15 --> Language Class Initialized
INFO - 2023-08-24 18:22:15 --> Loader Class Initialized
INFO - 2023-08-24 18:22:15 --> Helper loaded: url_helper
INFO - 2023-08-24 18:22:16 --> Helper loaded: file_helper
INFO - 2023-08-24 18:22:16 --> Database Driver Class Initialized
INFO - 2023-08-24 18:22:16 --> Email Class Initialized
DEBUG - 2023-08-24 18:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:22:16 --> Controller Class Initialized
INFO - 2023-08-24 18:22:16 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:22:16 --> Model "Home_model" initialized
INFO - 2023-08-24 18:22:16 --> Helper loaded: download_helper
INFO - 2023-08-24 18:22:16 --> Helper loaded: form_helper
INFO - 2023-08-24 18:22:16 --> Form Validation Class Initialized
INFO - 2023-08-24 18:22:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 18:22:17 --> Final output sent to browser
DEBUG - 2023-08-24 18:22:17 --> Total execution time: 1.5906
INFO - 2023-08-24 18:22:17 --> Config Class Initialized
INFO - 2023-08-24 18:22:17 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:22:17 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:22:18 --> Config Class Initialized
INFO - 2023-08-24 18:22:18 --> Hooks Class Initialized
INFO - 2023-08-24 18:22:18 --> Config Class Initialized
INFO - 2023-08-24 18:22:18 --> Hooks Class Initialized
INFO - 2023-08-24 18:22:18 --> Config Class Initialized
INFO - 2023-08-24 18:22:18 --> Config Class Initialized
INFO - 2023-08-24 18:22:18 --> Utf8 Class Initialized
DEBUG - 2023-08-24 18:22:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 18:22:18 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:22:18 --> Utf8 Class Initialized
INFO - 2023-08-24 18:22:18 --> Hooks Class Initialized
INFO - 2023-08-24 18:22:18 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:22:18 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:22:18 --> URI Class Initialized
DEBUG - 2023-08-24 18:22:18 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:22:18 --> Utf8 Class Initialized
INFO - 2023-08-24 18:22:18 --> Utf8 Class Initialized
INFO - 2023-08-24 18:22:18 --> URI Class Initialized
INFO - 2023-08-24 18:22:18 --> URI Class Initialized
INFO - 2023-08-24 18:22:18 --> Utf8 Class Initialized
INFO - 2023-08-24 18:22:18 --> Router Class Initialized
INFO - 2023-08-24 18:22:18 --> Router Class Initialized
INFO - 2023-08-24 18:22:18 --> Output Class Initialized
INFO - 2023-08-24 18:22:18 --> URI Class Initialized
INFO - 2023-08-24 18:22:18 --> Security Class Initialized
INFO - 2023-08-24 18:22:18 --> Router Class Initialized
INFO - 2023-08-24 18:22:18 --> Output Class Initialized
INFO - 2023-08-24 18:22:18 --> URI Class Initialized
INFO - 2023-08-24 18:22:18 --> Router Class Initialized
DEBUG - 2023-08-24 18:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:22:18 --> Output Class Initialized
INFO - 2023-08-24 18:22:18 --> Router Class Initialized
INFO - 2023-08-24 18:22:18 --> Output Class Initialized
INFO - 2023-08-24 18:22:18 --> Security Class Initialized
DEBUG - 2023-08-24 18:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:22:18 --> Input Class Initialized
INFO - 2023-08-24 18:22:18 --> Language Class Initialized
INFO - 2023-08-24 18:22:18 --> Input Class Initialized
INFO - 2023-08-24 18:22:18 --> Security Class Initialized
INFO - 2023-08-24 18:22:18 --> Output Class Initialized
ERROR - 2023-08-24 18:22:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:22:18 --> Security Class Initialized
DEBUG - 2023-08-24 18:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:22:18 --> Language Class Initialized
INFO - 2023-08-24 18:22:18 --> Security Class Initialized
DEBUG - 2023-08-24 18:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-24 18:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:22:18 --> Input Class Initialized
ERROR - 2023-08-24 18:22:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:22:18 --> Input Class Initialized
INFO - 2023-08-24 18:22:18 --> Language Class Initialized
INFO - 2023-08-24 18:22:18 --> Language Class Initialized
ERROR - 2023-08-24 18:22:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:22:18 --> Input Class Initialized
ERROR - 2023-08-24 18:22:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:22:18 --> Language Class Initialized
ERROR - 2023-08-24 18:22:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:22:47 --> Config Class Initialized
INFO - 2023-08-24 18:22:47 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:22:47 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:22:47 --> Utf8 Class Initialized
INFO - 2023-08-24 18:22:47 --> URI Class Initialized
INFO - 2023-08-24 18:22:47 --> Router Class Initialized
INFO - 2023-08-24 18:22:47 --> Output Class Initialized
INFO - 2023-08-24 18:22:47 --> Security Class Initialized
DEBUG - 2023-08-24 18:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:22:47 --> Input Class Initialized
INFO - 2023-08-24 18:22:47 --> Language Class Initialized
INFO - 2023-08-24 18:22:47 --> Loader Class Initialized
INFO - 2023-08-24 18:22:47 --> Helper loaded: url_helper
INFO - 2023-08-24 18:22:47 --> Helper loaded: file_helper
INFO - 2023-08-24 18:22:47 --> Database Driver Class Initialized
INFO - 2023-08-24 18:22:48 --> Email Class Initialized
DEBUG - 2023-08-24 18:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:22:48 --> Controller Class Initialized
INFO - 2023-08-24 18:22:48 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:22:48 --> Model "Home_model" initialized
INFO - 2023-08-24 18:22:48 --> Helper loaded: download_helper
INFO - 2023-08-24 18:22:48 --> Helper loaded: form_helper
INFO - 2023-08-24 18:22:48 --> Form Validation Class Initialized
INFO - 2023-08-24 18:22:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 18:22:48 --> Final output sent to browser
DEBUG - 2023-08-24 18:22:48 --> Total execution time: 1.0334
INFO - 2023-08-24 18:22:51 --> Config Class Initialized
INFO - 2023-08-24 18:22:51 --> Config Class Initialized
INFO - 2023-08-24 18:22:51 --> Hooks Class Initialized
INFO - 2023-08-24 18:22:51 --> Config Class Initialized
INFO - 2023-08-24 18:22:51 --> Config Class Initialized
INFO - 2023-08-24 18:22:51 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:22:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 18:22:52 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:22:52 --> Hooks Class Initialized
INFO - 2023-08-24 18:22:52 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:22:52 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:22:52 --> Utf8 Class Initialized
INFO - 2023-08-24 18:22:52 --> URI Class Initialized
INFO - 2023-08-24 18:22:52 --> Router Class Initialized
INFO - 2023-08-24 18:22:52 --> Output Class Initialized
INFO - 2023-08-24 18:22:52 --> Security Class Initialized
DEBUG - 2023-08-24 18:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:22:52 --> Input Class Initialized
INFO - 2023-08-24 18:22:52 --> Language Class Initialized
ERROR - 2023-08-24 18:22:52 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:22:52 --> Utf8 Class Initialized
DEBUG - 2023-08-24 18:22:52 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:22:52 --> Config Class Initialized
INFO - 2023-08-24 18:22:52 --> Utf8 Class Initialized
INFO - 2023-08-24 18:22:52 --> Hooks Class Initialized
INFO - 2023-08-24 18:22:52 --> URI Class Initialized
INFO - 2023-08-24 18:22:52 --> Utf8 Class Initialized
INFO - 2023-08-24 18:22:52 --> Router Class Initialized
INFO - 2023-08-24 18:22:53 --> URI Class Initialized
DEBUG - 2023-08-24 18:22:53 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:22:53 --> URI Class Initialized
INFO - 2023-08-24 18:22:53 --> Output Class Initialized
INFO - 2023-08-24 18:22:53 --> Router Class Initialized
INFO - 2023-08-24 18:22:53 --> Output Class Initialized
INFO - 2023-08-24 18:22:53 --> Security Class Initialized
DEBUG - 2023-08-24 18:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:22:53 --> Input Class Initialized
INFO - 2023-08-24 18:22:53 --> Language Class Initialized
ERROR - 2023-08-24 18:22:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:22:53 --> Router Class Initialized
INFO - 2023-08-24 18:22:53 --> Utf8 Class Initialized
INFO - 2023-08-24 18:22:53 --> URI Class Initialized
INFO - 2023-08-24 18:22:53 --> Security Class Initialized
INFO - 2023-08-24 18:22:53 --> Router Class Initialized
DEBUG - 2023-08-24 18:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:22:53 --> Output Class Initialized
INFO - 2023-08-24 18:22:54 --> Input Class Initialized
INFO - 2023-08-24 18:22:54 --> Output Class Initialized
INFO - 2023-08-24 18:22:54 --> Security Class Initialized
INFO - 2023-08-24 18:24:55 --> Config Class Initialized
INFO - 2023-08-24 18:24:55 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:24:56 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:24:56 --> Utf8 Class Initialized
INFO - 2023-08-24 18:24:56 --> URI Class Initialized
INFO - 2023-08-24 18:24:56 --> Router Class Initialized
INFO - 2023-08-24 18:24:56 --> Output Class Initialized
INFO - 2023-08-24 18:24:56 --> Security Class Initialized
DEBUG - 2023-08-24 18:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:24:56 --> Input Class Initialized
INFO - 2023-08-24 18:24:56 --> Language Class Initialized
INFO - 2023-08-24 18:24:57 --> Loader Class Initialized
INFO - 2023-08-24 18:24:57 --> Helper loaded: url_helper
INFO - 2023-08-24 18:24:57 --> Helper loaded: file_helper
INFO - 2023-08-24 18:24:57 --> Database Driver Class Initialized
INFO - 2023-08-24 18:24:57 --> Email Class Initialized
DEBUG - 2023-08-24 18:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:24:57 --> Controller Class Initialized
INFO - 2023-08-24 18:24:57 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:24:57 --> Model "Home_model" initialized
INFO - 2023-08-24 18:24:57 --> Helper loaded: download_helper
INFO - 2023-08-24 18:24:58 --> Helper loaded: form_helper
INFO - 2023-08-24 18:24:58 --> Form Validation Class Initialized
INFO - 2023-08-24 18:24:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 18:24:58 --> Final output sent to browser
DEBUG - 2023-08-24 18:24:58 --> Total execution time: 2.5750
INFO - 2023-08-24 18:24:59 --> Config Class Initialized
INFO - 2023-08-24 18:25:00 --> Config Class Initialized
INFO - 2023-08-24 18:25:00 --> Hooks Class Initialized
INFO - 2023-08-24 18:25:00 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:25:00 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:25:00 --> Utf8 Class Initialized
DEBUG - 2023-08-24 18:25:00 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:25:01 --> Config Class Initialized
INFO - 2023-08-24 18:25:01 --> Hooks Class Initialized
INFO - 2023-08-24 18:25:01 --> URI Class Initialized
DEBUG - 2023-08-24 18:25:01 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:25:01 --> Config Class Initialized
INFO - 2023-08-24 18:25:01 --> Router Class Initialized
INFO - 2023-08-24 18:25:01 --> Utf8 Class Initialized
INFO - 2023-08-24 18:25:01 --> Utf8 Class Initialized
INFO - 2023-08-24 18:25:01 --> Output Class Initialized
INFO - 2023-08-24 18:25:01 --> Config Class Initialized
INFO - 2023-08-24 18:25:01 --> Security Class Initialized
INFO - 2023-08-24 18:25:01 --> Hooks Class Initialized
INFO - 2023-08-24 18:25:01 --> Hooks Class Initialized
INFO - 2023-08-24 18:25:01 --> URI Class Initialized
INFO - 2023-08-24 18:25:01 --> URI Class Initialized
INFO - 2023-08-24 18:25:01 --> Router Class Initialized
DEBUG - 2023-08-24 18:25:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 18:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:25:01 --> Router Class Initialized
INFO - 2023-08-24 18:25:01 --> Utf8 Class Initialized
INFO - 2023-08-24 18:25:01 --> URI Class Initialized
INFO - 2023-08-24 18:25:01 --> Router Class Initialized
INFO - 2023-08-24 18:25:01 --> Output Class Initialized
INFO - 2023-08-24 18:25:01 --> Security Class Initialized
DEBUG - 2023-08-24 18:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:25:01 --> Input Class Initialized
INFO - 2023-08-24 18:25:01 --> Language Class Initialized
ERROR - 2023-08-24 18:25:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:25:01 --> Output Class Initialized
INFO - 2023-08-24 18:25:01 --> Output Class Initialized
DEBUG - 2023-08-24 18:25:01 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:25:02 --> Input Class Initialized
INFO - 2023-08-24 18:25:02 --> Security Class Initialized
INFO - 2023-08-24 18:25:02 --> Security Class Initialized
INFO - 2023-08-24 18:25:02 --> Utf8 Class Initialized
DEBUG - 2023-08-24 18:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:25:02 --> Language Class Initialized
INFO - 2023-08-24 18:25:02 --> Input Class Initialized
DEBUG - 2023-08-24 18:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:25:02 --> Language Class Initialized
ERROR - 2023-08-24 18:25:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:25:02 --> URI Class Initialized
INFO - 2023-08-24 18:25:02 --> Router Class Initialized
INFO - 2023-08-24 18:25:02 --> Input Class Initialized
INFO - 2023-08-24 18:25:02 --> Language Class Initialized
ERROR - 2023-08-24 18:25:02 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-24 18:25:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:25:02 --> Output Class Initialized
INFO - 2023-08-24 18:25:02 --> Security Class Initialized
DEBUG - 2023-08-24 18:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:25:02 --> Input Class Initialized
INFO - 2023-08-24 18:25:03 --> Language Class Initialized
ERROR - 2023-08-24 18:25:03 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:25:35 --> Config Class Initialized
INFO - 2023-08-24 18:25:35 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:25:35 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:25:35 --> Utf8 Class Initialized
INFO - 2023-08-24 18:25:35 --> URI Class Initialized
INFO - 2023-08-24 18:25:35 --> Router Class Initialized
INFO - 2023-08-24 18:25:35 --> Output Class Initialized
INFO - 2023-08-24 18:25:35 --> Security Class Initialized
DEBUG - 2023-08-24 18:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:25:35 --> Input Class Initialized
INFO - 2023-08-24 18:25:35 --> Language Class Initialized
ERROR - 2023-08-24 18:25:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:25:35 --> Config Class Initialized
INFO - 2023-08-24 18:25:35 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:25:35 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:25:35 --> Utf8 Class Initialized
INFO - 2023-08-24 18:25:35 --> URI Class Initialized
INFO - 2023-08-24 18:25:35 --> Router Class Initialized
INFO - 2023-08-24 18:25:35 --> Output Class Initialized
INFO - 2023-08-24 18:25:35 --> Security Class Initialized
DEBUG - 2023-08-24 18:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:25:35 --> Input Class Initialized
INFO - 2023-08-24 18:25:35 --> Language Class Initialized
ERROR - 2023-08-24 18:25:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:25:36 --> Config Class Initialized
INFO - 2023-08-24 18:25:36 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:25:36 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:25:36 --> Utf8 Class Initialized
INFO - 2023-08-24 18:25:36 --> URI Class Initialized
INFO - 2023-08-24 18:25:36 --> Router Class Initialized
INFO - 2023-08-24 18:25:36 --> Output Class Initialized
INFO - 2023-08-24 18:25:36 --> Security Class Initialized
DEBUG - 2023-08-24 18:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:25:36 --> Input Class Initialized
INFO - 2023-08-24 18:25:36 --> Language Class Initialized
ERROR - 2023-08-24 18:25:36 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:25:37 --> Config Class Initialized
INFO - 2023-08-24 18:25:37 --> Config Class Initialized
INFO - 2023-08-24 18:25:37 --> Hooks Class Initialized
INFO - 2023-08-24 18:25:37 --> Config Class Initialized
INFO - 2023-08-24 18:25:37 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:25:37 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:25:37 --> Utf8 Class Initialized
INFO - 2023-08-24 18:25:37 --> URI Class Initialized
INFO - 2023-08-24 18:25:37 --> Router Class Initialized
INFO - 2023-08-24 18:25:37 --> Output Class Initialized
INFO - 2023-08-24 18:25:37 --> Security Class Initialized
DEBUG - 2023-08-24 18:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:25:37 --> Input Class Initialized
INFO - 2023-08-24 18:25:37 --> Language Class Initialized
ERROR - 2023-08-24 18:25:37 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:25:37 --> Config Class Initialized
INFO - 2023-08-24 18:25:37 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:25:37 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:25:37 --> Hooks Class Initialized
INFO - 2023-08-24 18:25:38 --> Utf8 Class Initialized
DEBUG - 2023-08-24 18:25:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 18:25:38 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:25:38 --> Utf8 Class Initialized
INFO - 2023-08-24 18:25:38 --> URI Class Initialized
INFO - 2023-08-24 18:25:38 --> URI Class Initialized
INFO - 2023-08-24 18:25:38 --> Router Class Initialized
INFO - 2023-08-24 18:25:38 --> Utf8 Class Initialized
INFO - 2023-08-24 18:25:38 --> Router Class Initialized
INFO - 2023-08-24 18:25:38 --> URI Class Initialized
INFO - 2023-08-24 18:25:38 --> Output Class Initialized
INFO - 2023-08-24 18:25:38 --> Router Class Initialized
INFO - 2023-08-24 18:25:38 --> Output Class Initialized
INFO - 2023-08-24 18:25:39 --> Output Class Initialized
INFO - 2023-08-24 18:25:39 --> Security Class Initialized
INFO - 2023-08-24 18:25:39 --> Security Class Initialized
INFO - 2023-08-24 18:25:39 --> Config Class Initialized
INFO - 2023-08-24 18:25:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:25:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:25:39 --> Utf8 Class Initialized
INFO - 2023-08-24 18:25:39 --> URI Class Initialized
INFO - 2023-08-24 18:25:39 --> Router Class Initialized
INFO - 2023-08-24 18:25:39 --> Output Class Initialized
INFO - 2023-08-24 18:25:39 --> Security Class Initialized
DEBUG - 2023-08-24 18:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:25:39 --> Input Class Initialized
INFO - 2023-08-24 18:25:39 --> Language Class Initialized
INFO - 2023-08-24 18:25:39 --> Loader Class Initialized
INFO - 2023-08-24 18:25:39 --> Helper loaded: url_helper
INFO - 2023-08-24 18:25:39 --> Helper loaded: file_helper
INFO - 2023-08-24 18:25:39 --> Database Driver Class Initialized
INFO - 2023-08-24 18:25:39 --> Email Class Initialized
DEBUG - 2023-08-24 18:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:25:39 --> Controller Class Initialized
INFO - 2023-08-24 18:25:39 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:25:39 --> Model "Home_model" initialized
INFO - 2023-08-24 18:25:39 --> Helper loaded: download_helper
INFO - 2023-08-24 18:25:39 --> Helper loaded: form_helper
INFO - 2023-08-24 18:25:39 --> Form Validation Class Initialized
DEBUG - 2023-08-24 18:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:25:39 --> Security Class Initialized
DEBUG - 2023-08-24 18:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-24 18:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:25:39 --> Input Class Initialized
INFO - 2023-08-24 18:25:39 --> Input Class Initialized
INFO - 2023-08-24 18:25:40 --> Language Class Initialized
INFO - 2023-08-24 18:25:40 --> Language Class Initialized
INFO - 2023-08-24 18:25:40 --> Input Class Initialized
ERROR - 2023-08-24 18:25:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:25:40 --> Language Class Initialized
ERROR - 2023-08-24 18:25:41 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-24 18:25:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:31:21 --> Config Class Initialized
INFO - 2023-08-24 18:31:21 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:31:21 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:31:21 --> Utf8 Class Initialized
INFO - 2023-08-24 18:31:21 --> URI Class Initialized
INFO - 2023-08-24 18:31:21 --> Router Class Initialized
INFO - 2023-08-24 18:31:21 --> Output Class Initialized
INFO - 2023-08-24 18:31:21 --> Security Class Initialized
DEBUG - 2023-08-24 18:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:31:21 --> Input Class Initialized
INFO - 2023-08-24 18:31:21 --> Language Class Initialized
INFO - 2023-08-24 18:31:21 --> Loader Class Initialized
INFO - 2023-08-24 18:31:21 --> Helper loaded: url_helper
INFO - 2023-08-24 18:31:21 --> Helper loaded: file_helper
INFO - 2023-08-24 18:31:21 --> Database Driver Class Initialized
INFO - 2023-08-24 18:31:21 --> Email Class Initialized
DEBUG - 2023-08-24 18:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:31:21 --> Controller Class Initialized
INFO - 2023-08-24 18:31:21 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:31:21 --> Model "Home_model" initialized
INFO - 2023-08-24 18:31:21 --> Helper loaded: download_helper
INFO - 2023-08-24 18:31:21 --> Helper loaded: form_helper
INFO - 2023-08-24 18:31:21 --> Form Validation Class Initialized
INFO - 2023-08-24 18:33:19 --> Config Class Initialized
INFO - 2023-08-24 18:33:19 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:33:19 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:33:19 --> Utf8 Class Initialized
INFO - 2023-08-24 18:33:19 --> URI Class Initialized
INFO - 2023-08-24 18:33:19 --> Router Class Initialized
INFO - 2023-08-24 18:33:19 --> Output Class Initialized
INFO - 2023-08-24 18:33:19 --> Security Class Initialized
DEBUG - 2023-08-24 18:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:33:19 --> Input Class Initialized
INFO - 2023-08-24 18:33:19 --> Language Class Initialized
INFO - 2023-08-24 18:33:19 --> Loader Class Initialized
INFO - 2023-08-24 18:33:19 --> Helper loaded: url_helper
INFO - 2023-08-24 18:33:19 --> Helper loaded: file_helper
INFO - 2023-08-24 18:33:19 --> Database Driver Class Initialized
INFO - 2023-08-24 18:33:19 --> Email Class Initialized
DEBUG - 2023-08-24 18:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:33:19 --> Controller Class Initialized
INFO - 2023-08-24 18:33:19 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:33:19 --> Model "Home_model" initialized
INFO - 2023-08-24 18:33:19 --> Helper loaded: download_helper
INFO - 2023-08-24 18:33:20 --> Helper loaded: form_helper
INFO - 2023-08-24 18:33:20 --> Form Validation Class Initialized
INFO - 2023-08-24 18:37:21 --> Config Class Initialized
INFO - 2023-08-24 18:37:21 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:37:21 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:21 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:21 --> URI Class Initialized
INFO - 2023-08-24 18:37:21 --> Router Class Initialized
INFO - 2023-08-24 18:37:21 --> Output Class Initialized
INFO - 2023-08-24 18:37:22 --> Security Class Initialized
DEBUG - 2023-08-24 18:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:22 --> Input Class Initialized
INFO - 2023-08-24 18:37:22 --> Language Class Initialized
INFO - 2023-08-24 18:37:22 --> Loader Class Initialized
INFO - 2023-08-24 18:37:22 --> Helper loaded: url_helper
INFO - 2023-08-24 18:37:22 --> Helper loaded: file_helper
INFO - 2023-08-24 18:37:22 --> Database Driver Class Initialized
INFO - 2023-08-24 18:37:22 --> Email Class Initialized
DEBUG - 2023-08-24 18:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:37:22 --> Controller Class Initialized
INFO - 2023-08-24 18:37:22 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:37:22 --> Model "Home_model" initialized
INFO - 2023-08-24 18:37:22 --> Helper loaded: download_helper
INFO - 2023-08-24 18:37:22 --> Helper loaded: form_helper
INFO - 2023-08-24 18:37:22 --> Form Validation Class Initialized
INFO - 2023-08-24 18:37:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 18:37:22 --> Final output sent to browser
DEBUG - 2023-08-24 18:37:22 --> Total execution time: 0.6274
INFO - 2023-08-24 18:37:24 --> Config Class Initialized
INFO - 2023-08-24 18:37:24 --> Hooks Class Initialized
INFO - 2023-08-24 18:37:24 --> Config Class Initialized
INFO - 2023-08-24 18:37:24 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:37:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 18:37:24 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:24 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:24 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:24 --> URI Class Initialized
INFO - 2023-08-24 18:37:24 --> Router Class Initialized
INFO - 2023-08-24 18:37:24 --> URI Class Initialized
INFO - 2023-08-24 18:37:24 --> Output Class Initialized
INFO - 2023-08-24 18:37:24 --> Router Class Initialized
INFO - 2023-08-24 18:37:24 --> Security Class Initialized
INFO - 2023-08-24 18:37:24 --> Output Class Initialized
DEBUG - 2023-08-24 18:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:24 --> Input Class Initialized
INFO - 2023-08-24 18:37:24 --> Security Class Initialized
INFO - 2023-08-24 18:37:24 --> Language Class Initialized
DEBUG - 2023-08-24 18:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-24 18:37:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:37:24 --> Input Class Initialized
INFO - 2023-08-24 18:37:24 --> Config Class Initialized
INFO - 2023-08-24 18:37:24 --> Hooks Class Initialized
INFO - 2023-08-24 18:37:24 --> Language Class Initialized
ERROR - 2023-08-24 18:37:24 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-24 18:37:24 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:24 --> Config Class Initialized
INFO - 2023-08-24 18:37:24 --> Hooks Class Initialized
INFO - 2023-08-24 18:37:24 --> Utf8 Class Initialized
DEBUG - 2023-08-24 18:37:24 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:24 --> URI Class Initialized
INFO - 2023-08-24 18:37:24 --> Router Class Initialized
INFO - 2023-08-24 18:37:24 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:24 --> Output Class Initialized
INFO - 2023-08-24 18:37:24 --> URI Class Initialized
INFO - 2023-08-24 18:37:24 --> Security Class Initialized
DEBUG - 2023-08-24 18:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:24 --> Router Class Initialized
INFO - 2023-08-24 18:37:24 --> Input Class Initialized
INFO - 2023-08-24 18:37:24 --> Language Class Initialized
INFO - 2023-08-24 18:37:24 --> Output Class Initialized
ERROR - 2023-08-24 18:37:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:37:25 --> Security Class Initialized
INFO - 2023-08-24 18:37:25 --> Config Class Initialized
DEBUG - 2023-08-24 18:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:25 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:37:25 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:25 --> Input Class Initialized
INFO - 2023-08-24 18:37:25 --> Language Class Initialized
ERROR - 2023-08-24 18:37:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:37:25 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:25 --> Config Class Initialized
INFO - 2023-08-24 18:37:25 --> Hooks Class Initialized
INFO - 2023-08-24 18:37:25 --> URI Class Initialized
DEBUG - 2023-08-24 18:37:25 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:25 --> Router Class Initialized
INFO - 2023-08-24 18:37:25 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:25 --> URI Class Initialized
INFO - 2023-08-24 18:37:25 --> Output Class Initialized
INFO - 2023-08-24 18:37:25 --> Router Class Initialized
INFO - 2023-08-24 18:37:25 --> Security Class Initialized
INFO - 2023-08-24 18:37:25 --> Output Class Initialized
DEBUG - 2023-08-24 18:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:25 --> Security Class Initialized
INFO - 2023-08-24 18:37:25 --> Input Class Initialized
DEBUG - 2023-08-24 18:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:25 --> Input Class Initialized
INFO - 2023-08-24 18:37:25 --> Language Class Initialized
INFO - 2023-08-24 18:37:25 --> Language Class Initialized
ERROR - 2023-08-24 18:37:25 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-24 18:37:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:37:25 --> Config Class Initialized
INFO - 2023-08-24 18:37:25 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:37:25 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:25 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:25 --> URI Class Initialized
INFO - 2023-08-24 18:37:25 --> Router Class Initialized
INFO - 2023-08-24 18:37:25 --> Output Class Initialized
INFO - 2023-08-24 18:37:25 --> Security Class Initialized
DEBUG - 2023-08-24 18:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:25 --> Input Class Initialized
INFO - 2023-08-24 18:37:25 --> Language Class Initialized
ERROR - 2023-08-24 18:37:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:37:25 --> Config Class Initialized
INFO - 2023-08-24 18:37:25 --> Config Class Initialized
INFO - 2023-08-24 18:37:25 --> Hooks Class Initialized
INFO - 2023-08-24 18:37:25 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:37:25 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:25 --> Utf8 Class Initialized
DEBUG - 2023-08-24 18:37:25 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:25 --> URI Class Initialized
INFO - 2023-08-24 18:37:25 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:25 --> Router Class Initialized
INFO - 2023-08-24 18:37:25 --> URI Class Initialized
INFO - 2023-08-24 18:37:25 --> Output Class Initialized
INFO - 2023-08-24 18:37:25 --> Router Class Initialized
INFO - 2023-08-24 18:37:25 --> Security Class Initialized
DEBUG - 2023-08-24 18:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:25 --> Output Class Initialized
INFO - 2023-08-24 18:37:25 --> Input Class Initialized
INFO - 2023-08-24 18:37:25 --> Security Class Initialized
INFO - 2023-08-24 18:37:25 --> Language Class Initialized
DEBUG - 2023-08-24 18:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-24 18:37:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:37:25 --> Input Class Initialized
INFO - 2023-08-24 18:37:25 --> Language Class Initialized
ERROR - 2023-08-24 18:37:25 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:37:25 --> Config Class Initialized
INFO - 2023-08-24 18:37:25 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:37:25 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:25 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:25 --> URI Class Initialized
INFO - 2023-08-24 18:37:25 --> Router Class Initialized
INFO - 2023-08-24 18:37:25 --> Output Class Initialized
INFO - 2023-08-24 18:37:25 --> Security Class Initialized
DEBUG - 2023-08-24 18:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:25 --> Input Class Initialized
INFO - 2023-08-24 18:37:25 --> Language Class Initialized
ERROR - 2023-08-24 18:37:25 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:37:25 --> Config Class Initialized
INFO - 2023-08-24 18:37:25 --> Hooks Class Initialized
INFO - 2023-08-24 18:37:25 --> Config Class Initialized
DEBUG - 2023-08-24 18:37:25 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:25 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:25 --> Hooks Class Initialized
INFO - 2023-08-24 18:37:25 --> URI Class Initialized
INFO - 2023-08-24 18:37:25 --> Router Class Initialized
DEBUG - 2023-08-24 18:37:25 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:25 --> Output Class Initialized
INFO - 2023-08-24 18:37:25 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:25 --> Security Class Initialized
INFO - 2023-08-24 18:37:25 --> URI Class Initialized
DEBUG - 2023-08-24 18:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:25 --> Router Class Initialized
INFO - 2023-08-24 18:37:25 --> Input Class Initialized
INFO - 2023-08-24 18:37:26 --> Output Class Initialized
INFO - 2023-08-24 18:37:26 --> Language Class Initialized
ERROR - 2023-08-24 18:37:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:37:26 --> Security Class Initialized
DEBUG - 2023-08-24 18:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:26 --> Input Class Initialized
INFO - 2023-08-24 18:37:26 --> Language Class Initialized
ERROR - 2023-08-24 18:37:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:37:27 --> Config Class Initialized
INFO - 2023-08-24 18:37:27 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:37:27 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:27 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:27 --> URI Class Initialized
INFO - 2023-08-24 18:37:27 --> Router Class Initialized
INFO - 2023-08-24 18:37:27 --> Output Class Initialized
INFO - 2023-08-24 18:37:27 --> Security Class Initialized
DEBUG - 2023-08-24 18:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:27 --> Input Class Initialized
INFO - 2023-08-24 18:37:27 --> Language Class Initialized
INFO - 2023-08-24 18:37:27 --> Loader Class Initialized
INFO - 2023-08-24 18:37:27 --> Helper loaded: url_helper
INFO - 2023-08-24 18:37:27 --> Helper loaded: file_helper
INFO - 2023-08-24 18:37:27 --> Database Driver Class Initialized
INFO - 2023-08-24 18:37:28 --> Email Class Initialized
DEBUG - 2023-08-24 18:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:37:28 --> Controller Class Initialized
INFO - 2023-08-24 18:37:28 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:37:28 --> Model "Home_model" initialized
INFO - 2023-08-24 18:37:28 --> Helper loaded: download_helper
INFO - 2023-08-24 18:37:28 --> Helper loaded: form_helper
INFO - 2023-08-24 18:37:28 --> Form Validation Class Initialized
INFO - 2023-08-24 18:37:35 --> Config Class Initialized
INFO - 2023-08-24 18:37:35 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:37:35 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:35 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:35 --> URI Class Initialized
INFO - 2023-08-24 18:37:35 --> Router Class Initialized
INFO - 2023-08-24 18:37:35 --> Output Class Initialized
INFO - 2023-08-24 18:37:35 --> Security Class Initialized
DEBUG - 2023-08-24 18:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:35 --> Input Class Initialized
INFO - 2023-08-24 18:37:35 --> Language Class Initialized
INFO - 2023-08-24 18:37:35 --> Loader Class Initialized
INFO - 2023-08-24 18:37:35 --> Helper loaded: url_helper
INFO - 2023-08-24 18:37:35 --> Helper loaded: file_helper
INFO - 2023-08-24 18:37:35 --> Database Driver Class Initialized
INFO - 2023-08-24 18:37:35 --> Email Class Initialized
DEBUG - 2023-08-24 18:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:37:35 --> Controller Class Initialized
INFO - 2023-08-24 18:37:35 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:37:35 --> Model "Home_model" initialized
INFO - 2023-08-24 18:37:35 --> Helper loaded: download_helper
INFO - 2023-08-24 18:37:35 --> Helper loaded: form_helper
INFO - 2023-08-24 18:37:35 --> Form Validation Class Initialized
INFO - 2023-08-24 18:37:37 --> Config Class Initialized
INFO - 2023-08-24 18:37:37 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:37:38 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:38 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:38 --> URI Class Initialized
INFO - 2023-08-24 18:37:38 --> Router Class Initialized
INFO - 2023-08-24 18:37:38 --> Output Class Initialized
INFO - 2023-08-24 18:37:38 --> Security Class Initialized
DEBUG - 2023-08-24 18:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:38 --> Input Class Initialized
INFO - 2023-08-24 18:37:38 --> Language Class Initialized
INFO - 2023-08-24 18:37:38 --> Loader Class Initialized
INFO - 2023-08-24 18:37:38 --> Helper loaded: url_helper
INFO - 2023-08-24 18:37:38 --> Helper loaded: file_helper
INFO - 2023-08-24 18:37:38 --> Database Driver Class Initialized
INFO - 2023-08-24 18:37:38 --> Email Class Initialized
DEBUG - 2023-08-24 18:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:37:38 --> Controller Class Initialized
INFO - 2023-08-24 18:37:38 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:37:38 --> Model "Home_model" initialized
INFO - 2023-08-24 18:37:38 --> Helper loaded: download_helper
INFO - 2023-08-24 18:37:38 --> Helper loaded: form_helper
INFO - 2023-08-24 18:37:38 --> Form Validation Class Initialized
INFO - 2023-08-24 18:37:39 --> Config Class Initialized
INFO - 2023-08-24 18:37:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:37:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:39 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:39 --> URI Class Initialized
INFO - 2023-08-24 18:37:39 --> Router Class Initialized
INFO - 2023-08-24 18:37:39 --> Output Class Initialized
INFO - 2023-08-24 18:37:39 --> Security Class Initialized
DEBUG - 2023-08-24 18:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:37:39 --> Input Class Initialized
INFO - 2023-08-24 18:37:39 --> Language Class Initialized
INFO - 2023-08-24 18:37:39 --> Loader Class Initialized
INFO - 2023-08-24 18:37:39 --> Helper loaded: url_helper
INFO - 2023-08-24 18:37:39 --> Helper loaded: file_helper
INFO - 2023-08-24 18:37:39 --> Database Driver Class Initialized
INFO - 2023-08-24 18:37:39 --> Email Class Initialized
DEBUG - 2023-08-24 18:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:37:39 --> Controller Class Initialized
INFO - 2023-08-24 18:37:39 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:37:39 --> Model "Home_model" initialized
INFO - 2023-08-24 18:37:39 --> Helper loaded: download_helper
INFO - 2023-08-24 18:37:39 --> Helper loaded: form_helper
INFO - 2023-08-24 18:37:39 --> Form Validation Class Initialized
INFO - 2023-08-24 18:37:41 --> Config Class Initialized
INFO - 2023-08-24 18:37:41 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:37:41 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:37:41 --> Utf8 Class Initialized
INFO - 2023-08-24 18:37:41 --> URI Class Initialized
INFO - 2023-08-24 18:37:41 --> Router Class Initialized
INFO - 2023-08-24 18:37:41 --> Output Class Initialized
INFO - 2023-08-24 18:37:41 --> Security Class Initialized
INFO - 2023-08-24 18:39:04 --> Config Class Initialized
INFO - 2023-08-24 18:39:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:39:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:39:04 --> Utf8 Class Initialized
INFO - 2023-08-24 18:39:04 --> URI Class Initialized
INFO - 2023-08-24 18:39:04 --> Router Class Initialized
INFO - 2023-08-24 18:39:04 --> Output Class Initialized
INFO - 2023-08-24 18:39:04 --> Security Class Initialized
DEBUG - 2023-08-24 18:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:39:04 --> Input Class Initialized
INFO - 2023-08-24 18:39:04 --> Language Class Initialized
INFO - 2023-08-24 18:39:04 --> Loader Class Initialized
INFO - 2023-08-24 18:39:04 --> Helper loaded: url_helper
INFO - 2023-08-24 18:39:04 --> Helper loaded: file_helper
INFO - 2023-08-24 18:39:04 --> Database Driver Class Initialized
INFO - 2023-08-24 18:39:04 --> Email Class Initialized
DEBUG - 2023-08-24 18:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:39:04 --> Controller Class Initialized
INFO - 2023-08-24 18:39:04 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:39:04 --> Model "Home_model" initialized
INFO - 2023-08-24 18:39:04 --> Helper loaded: download_helper
INFO - 2023-08-24 18:39:04 --> Helper loaded: form_helper
INFO - 2023-08-24 18:39:04 --> Form Validation Class Initialized
INFO - 2023-08-24 18:39:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 18:39:04 --> Final output sent to browser
DEBUG - 2023-08-24 18:39:04 --> Total execution time: 0.4282
INFO - 2023-08-24 18:39:04 --> Config Class Initialized
INFO - 2023-08-24 18:39:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:39:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:39:04 --> Utf8 Class Initialized
INFO - 2023-08-24 18:39:04 --> URI Class Initialized
INFO - 2023-08-24 18:39:04 --> Router Class Initialized
INFO - 2023-08-24 18:39:04 --> Output Class Initialized
INFO - 2023-08-24 18:39:04 --> Security Class Initialized
DEBUG - 2023-08-24 18:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:39:04 --> Input Class Initialized
INFO - 2023-08-24 18:39:04 --> Language Class Initialized
ERROR - 2023-08-24 18:39:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:39:05 --> Config Class Initialized
INFO - 2023-08-24 18:39:05 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:39:05 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:39:05 --> Utf8 Class Initialized
INFO - 2023-08-24 18:39:05 --> URI Class Initialized
INFO - 2023-08-24 18:39:05 --> Router Class Initialized
INFO - 2023-08-24 18:39:05 --> Output Class Initialized
INFO - 2023-08-24 18:39:05 --> Security Class Initialized
DEBUG - 2023-08-24 18:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:39:05 --> Input Class Initialized
INFO - 2023-08-24 18:39:05 --> Language Class Initialized
ERROR - 2023-08-24 18:39:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:39:05 --> Config Class Initialized
INFO - 2023-08-24 18:39:05 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:39:05 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:39:05 --> Utf8 Class Initialized
INFO - 2023-08-24 18:39:05 --> URI Class Initialized
INFO - 2023-08-24 18:39:05 --> Router Class Initialized
INFO - 2023-08-24 18:39:05 --> Output Class Initialized
INFO - 2023-08-24 18:39:05 --> Security Class Initialized
DEBUG - 2023-08-24 18:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:39:05 --> Input Class Initialized
INFO - 2023-08-24 18:39:05 --> Language Class Initialized
ERROR - 2023-08-24 18:39:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:39:05 --> Config Class Initialized
INFO - 2023-08-24 18:39:05 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:39:05 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:39:05 --> Utf8 Class Initialized
INFO - 2023-08-24 18:39:05 --> Config Class Initialized
INFO - 2023-08-24 18:39:05 --> URI Class Initialized
INFO - 2023-08-24 18:39:05 --> Hooks Class Initialized
INFO - 2023-08-24 18:39:05 --> Router Class Initialized
DEBUG - 2023-08-24 18:39:05 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:39:05 --> Output Class Initialized
INFO - 2023-08-24 18:39:05 --> Security Class Initialized
INFO - 2023-08-24 18:39:05 --> Utf8 Class Initialized
DEBUG - 2023-08-24 18:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:39:06 --> Input Class Initialized
INFO - 2023-08-24 18:39:06 --> URI Class Initialized
INFO - 2023-08-24 18:39:06 --> Language Class Initialized
INFO - 2023-08-24 18:39:06 --> Router Class Initialized
ERROR - 2023-08-24 18:39:06 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:39:06 --> Output Class Initialized
INFO - 2023-08-24 18:39:06 --> Security Class Initialized
DEBUG - 2023-08-24 18:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:39:06 --> Input Class Initialized
INFO - 2023-08-24 18:39:06 --> Language Class Initialized
ERROR - 2023-08-24 18:39:06 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:39:06 --> Config Class Initialized
INFO - 2023-08-24 18:39:06 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:39:06 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:39:06 --> Utf8 Class Initialized
INFO - 2023-08-24 18:39:06 --> URI Class Initialized
INFO - 2023-08-24 18:39:06 --> Router Class Initialized
INFO - 2023-08-24 18:39:06 --> Output Class Initialized
INFO - 2023-08-24 18:39:06 --> Security Class Initialized
DEBUG - 2023-08-24 18:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:39:06 --> Input Class Initialized
INFO - 2023-08-24 18:39:06 --> Language Class Initialized
ERROR - 2023-08-24 18:39:06 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:39:35 --> Config Class Initialized
INFO - 2023-08-24 18:39:35 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:39:35 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:39:35 --> Utf8 Class Initialized
INFO - 2023-08-24 18:39:35 --> URI Class Initialized
INFO - 2023-08-24 18:39:35 --> Router Class Initialized
INFO - 2023-08-24 18:39:35 --> Output Class Initialized
INFO - 2023-08-24 18:39:35 --> Security Class Initialized
DEBUG - 2023-08-24 18:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:39:35 --> Input Class Initialized
INFO - 2023-08-24 18:39:35 --> Language Class Initialized
INFO - 2023-08-24 18:39:35 --> Loader Class Initialized
INFO - 2023-08-24 18:39:35 --> Helper loaded: url_helper
INFO - 2023-08-24 18:39:35 --> Helper loaded: file_helper
INFO - 2023-08-24 18:39:35 --> Database Driver Class Initialized
INFO - 2023-08-24 18:39:35 --> Email Class Initialized
DEBUG - 2023-08-24 18:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:39:35 --> Controller Class Initialized
INFO - 2023-08-24 18:39:35 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:39:35 --> Model "Home_model" initialized
INFO - 2023-08-24 18:39:35 --> Helper loaded: download_helper
INFO - 2023-08-24 18:39:35 --> Helper loaded: form_helper
INFO - 2023-08-24 18:39:35 --> Form Validation Class Initialized
INFO - 2023-08-24 18:44:48 --> Config Class Initialized
INFO - 2023-08-24 18:44:48 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:44:48 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:44:48 --> Utf8 Class Initialized
INFO - 2023-08-24 18:44:48 --> URI Class Initialized
INFO - 2023-08-24 18:44:48 --> Router Class Initialized
INFO - 2023-08-24 18:44:48 --> Output Class Initialized
INFO - 2023-08-24 18:44:48 --> Security Class Initialized
DEBUG - 2023-08-24 18:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:44:48 --> Input Class Initialized
INFO - 2023-08-24 18:44:48 --> Language Class Initialized
INFO - 2023-08-24 18:44:48 --> Loader Class Initialized
INFO - 2023-08-24 18:44:48 --> Helper loaded: url_helper
INFO - 2023-08-24 18:44:48 --> Helper loaded: file_helper
INFO - 2023-08-24 18:44:48 --> Database Driver Class Initialized
INFO - 2023-08-24 18:44:48 --> Email Class Initialized
DEBUG - 2023-08-24 18:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:44:48 --> Controller Class Initialized
INFO - 2023-08-24 18:44:48 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:44:48 --> Model "Home_model" initialized
INFO - 2023-08-24 18:44:48 --> Helper loaded: download_helper
INFO - 2023-08-24 18:44:48 --> Helper loaded: form_helper
INFO - 2023-08-24 18:44:48 --> Form Validation Class Initialized
INFO - 2023-08-24 18:44:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 18:44:49 --> Final output sent to browser
DEBUG - 2023-08-24 18:44:49 --> Total execution time: 0.4579
INFO - 2023-08-24 18:44:49 --> Config Class Initialized
INFO - 2023-08-24 18:44:49 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:44:49 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:44:49 --> Utf8 Class Initialized
INFO - 2023-08-24 18:44:49 --> URI Class Initialized
INFO - 2023-08-24 18:44:49 --> Router Class Initialized
INFO - 2023-08-24 18:44:49 --> Output Class Initialized
INFO - 2023-08-24 18:44:49 --> Security Class Initialized
DEBUG - 2023-08-24 18:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:44:49 --> Input Class Initialized
INFO - 2023-08-24 18:44:49 --> Language Class Initialized
ERROR - 2023-08-24 18:44:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:44:50 --> Config Class Initialized
INFO - 2023-08-24 18:44:50 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:44:50 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:44:50 --> Utf8 Class Initialized
INFO - 2023-08-24 18:44:50 --> URI Class Initialized
INFO - 2023-08-24 18:44:50 --> Router Class Initialized
INFO - 2023-08-24 18:44:50 --> Output Class Initialized
INFO - 2023-08-24 18:44:50 --> Security Class Initialized
DEBUG - 2023-08-24 18:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:44:50 --> Input Class Initialized
INFO - 2023-08-24 18:44:50 --> Language Class Initialized
ERROR - 2023-08-24 18:44:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:44:50 --> Config Class Initialized
INFO - 2023-08-24 18:44:50 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:44:50 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:44:50 --> Utf8 Class Initialized
INFO - 2023-08-24 18:44:50 --> URI Class Initialized
INFO - 2023-08-24 18:44:50 --> Router Class Initialized
INFO - 2023-08-24 18:44:50 --> Output Class Initialized
INFO - 2023-08-24 18:44:50 --> Security Class Initialized
DEBUG - 2023-08-24 18:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:44:50 --> Input Class Initialized
INFO - 2023-08-24 18:44:50 --> Language Class Initialized
ERROR - 2023-08-24 18:44:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:44:50 --> Config Class Initialized
INFO - 2023-08-24 18:44:50 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:44:50 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:44:50 --> Utf8 Class Initialized
INFO - 2023-08-24 18:44:50 --> URI Class Initialized
INFO - 2023-08-24 18:44:50 --> Router Class Initialized
INFO - 2023-08-24 18:44:50 --> Output Class Initialized
INFO - 2023-08-24 18:44:50 --> Security Class Initialized
DEBUG - 2023-08-24 18:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:44:50 --> Input Class Initialized
INFO - 2023-08-24 18:44:50 --> Language Class Initialized
ERROR - 2023-08-24 18:44:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:44:50 --> Config Class Initialized
INFO - 2023-08-24 18:44:50 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:44:50 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:44:50 --> Utf8 Class Initialized
INFO - 2023-08-24 18:44:50 --> URI Class Initialized
INFO - 2023-08-24 18:44:50 --> Router Class Initialized
INFO - 2023-08-24 18:44:50 --> Output Class Initialized
INFO - 2023-08-24 18:44:50 --> Security Class Initialized
DEBUG - 2023-08-24 18:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:44:50 --> Input Class Initialized
INFO - 2023-08-24 18:44:50 --> Language Class Initialized
ERROR - 2023-08-24 18:44:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:44:50 --> Config Class Initialized
INFO - 2023-08-24 18:44:50 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:44:50 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:44:50 --> Utf8 Class Initialized
INFO - 2023-08-24 18:44:50 --> URI Class Initialized
INFO - 2023-08-24 18:44:50 --> Router Class Initialized
INFO - 2023-08-24 18:44:50 --> Output Class Initialized
INFO - 2023-08-24 18:44:50 --> Security Class Initialized
DEBUG - 2023-08-24 18:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:44:50 --> Input Class Initialized
INFO - 2023-08-24 18:44:50 --> Language Class Initialized
ERROR - 2023-08-24 18:44:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:44:50 --> Config Class Initialized
INFO - 2023-08-24 18:44:50 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:44:50 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:44:50 --> Utf8 Class Initialized
INFO - 2023-08-24 18:44:50 --> URI Class Initialized
INFO - 2023-08-24 18:44:50 --> Router Class Initialized
INFO - 2023-08-24 18:44:50 --> Output Class Initialized
INFO - 2023-08-24 18:44:50 --> Security Class Initialized
DEBUG - 2023-08-24 18:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:44:50 --> Input Class Initialized
INFO - 2023-08-24 18:44:50 --> Language Class Initialized
ERROR - 2023-08-24 18:44:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:46:13 --> Config Class Initialized
INFO - 2023-08-24 18:46:13 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:46:13 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:46:13 --> Utf8 Class Initialized
INFO - 2023-08-24 18:46:13 --> URI Class Initialized
INFO - 2023-08-24 18:46:13 --> Router Class Initialized
INFO - 2023-08-24 18:46:13 --> Output Class Initialized
INFO - 2023-08-24 18:46:13 --> Security Class Initialized
DEBUG - 2023-08-24 18:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:46:13 --> Input Class Initialized
INFO - 2023-08-24 18:46:13 --> Language Class Initialized
INFO - 2023-08-24 18:46:13 --> Loader Class Initialized
INFO - 2023-08-24 18:46:13 --> Helper loaded: url_helper
INFO - 2023-08-24 18:46:13 --> Helper loaded: file_helper
INFO - 2023-08-24 18:46:13 --> Database Driver Class Initialized
INFO - 2023-08-24 18:46:13 --> Email Class Initialized
DEBUG - 2023-08-24 18:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:46:13 --> Controller Class Initialized
INFO - 2023-08-24 18:46:13 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:46:13 --> Model "Home_model" initialized
INFO - 2023-08-24 18:46:13 --> Helper loaded: download_helper
INFO - 2023-08-24 18:46:13 --> Helper loaded: form_helper
INFO - 2023-08-24 18:46:13 --> Form Validation Class Initialized
INFO - 2023-08-24 18:46:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 18:46:13 --> Final output sent to browser
DEBUG - 2023-08-24 18:46:13 --> Total execution time: 0.4100
INFO - 2023-08-24 18:46:14 --> Config Class Initialized
INFO - 2023-08-24 18:46:14 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:46:14 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:46:14 --> Utf8 Class Initialized
INFO - 2023-08-24 18:46:14 --> URI Class Initialized
INFO - 2023-08-24 18:46:14 --> Router Class Initialized
INFO - 2023-08-24 18:46:14 --> Output Class Initialized
INFO - 2023-08-24 18:46:14 --> Security Class Initialized
DEBUG - 2023-08-24 18:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:46:14 --> Input Class Initialized
INFO - 2023-08-24 18:46:14 --> Language Class Initialized
ERROR - 2023-08-24 18:46:14 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:46:14 --> Config Class Initialized
INFO - 2023-08-24 18:46:14 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:46:14 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:46:14 --> Utf8 Class Initialized
INFO - 2023-08-24 18:46:14 --> URI Class Initialized
INFO - 2023-08-24 18:46:14 --> Router Class Initialized
INFO - 2023-08-24 18:46:14 --> Output Class Initialized
INFO - 2023-08-24 18:46:14 --> Security Class Initialized
DEBUG - 2023-08-24 18:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:46:14 --> Input Class Initialized
INFO - 2023-08-24 18:46:14 --> Language Class Initialized
ERROR - 2023-08-24 18:46:14 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:46:14 --> Config Class Initialized
INFO - 2023-08-24 18:46:14 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:46:14 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:46:14 --> Utf8 Class Initialized
INFO - 2023-08-24 18:46:14 --> URI Class Initialized
INFO - 2023-08-24 18:46:14 --> Router Class Initialized
INFO - 2023-08-24 18:46:14 --> Output Class Initialized
INFO - 2023-08-24 18:46:14 --> Security Class Initialized
DEBUG - 2023-08-24 18:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:46:14 --> Input Class Initialized
INFO - 2023-08-24 18:46:14 --> Language Class Initialized
ERROR - 2023-08-24 18:46:14 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:46:14 --> Config Class Initialized
INFO - 2023-08-24 18:46:14 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:46:14 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:46:14 --> Utf8 Class Initialized
INFO - 2023-08-24 18:46:14 --> URI Class Initialized
INFO - 2023-08-24 18:46:14 --> Router Class Initialized
INFO - 2023-08-24 18:46:14 --> Output Class Initialized
INFO - 2023-08-24 18:46:15 --> Security Class Initialized
DEBUG - 2023-08-24 18:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:46:15 --> Input Class Initialized
INFO - 2023-08-24 18:46:15 --> Language Class Initialized
ERROR - 2023-08-24 18:46:15 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:46:15 --> Config Class Initialized
INFO - 2023-08-24 18:46:15 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:46:15 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:46:15 --> Utf8 Class Initialized
INFO - 2023-08-24 18:46:15 --> URI Class Initialized
INFO - 2023-08-24 18:46:15 --> Router Class Initialized
INFO - 2023-08-24 18:46:15 --> Output Class Initialized
INFO - 2023-08-24 18:46:15 --> Security Class Initialized
DEBUG - 2023-08-24 18:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:46:15 --> Input Class Initialized
INFO - 2023-08-24 18:46:15 --> Language Class Initialized
ERROR - 2023-08-24 18:46:15 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:46:58 --> Config Class Initialized
INFO - 2023-08-24 18:46:58 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:46:58 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:46:58 --> Utf8 Class Initialized
INFO - 2023-08-24 18:46:58 --> URI Class Initialized
INFO - 2023-08-24 18:46:58 --> Router Class Initialized
INFO - 2023-08-24 18:46:58 --> Output Class Initialized
INFO - 2023-08-24 18:46:58 --> Security Class Initialized
DEBUG - 2023-08-24 18:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:46:58 --> Input Class Initialized
INFO - 2023-08-24 18:46:58 --> Language Class Initialized
INFO - 2023-08-24 18:46:59 --> Loader Class Initialized
INFO - 2023-08-24 18:46:59 --> Helper loaded: url_helper
INFO - 2023-08-24 18:46:59 --> Helper loaded: file_helper
INFO - 2023-08-24 18:46:59 --> Database Driver Class Initialized
INFO - 2023-08-24 18:46:59 --> Email Class Initialized
DEBUG - 2023-08-24 18:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:46:59 --> Controller Class Initialized
INFO - 2023-08-24 18:46:59 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:46:59 --> Model "Home_model" initialized
INFO - 2023-08-24 18:46:59 --> Helper loaded: download_helper
INFO - 2023-08-24 18:46:59 --> Helper loaded: form_helper
INFO - 2023-08-24 18:46:59 --> Form Validation Class Initialized
INFO - 2023-08-24 18:46:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 18:46:59 --> Final output sent to browser
DEBUG - 2023-08-24 18:46:59 --> Total execution time: 0.4287
INFO - 2023-08-24 18:46:59 --> Config Class Initialized
INFO - 2023-08-24 18:46:59 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:46:59 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:46:59 --> Utf8 Class Initialized
INFO - 2023-08-24 18:46:59 --> URI Class Initialized
INFO - 2023-08-24 18:46:59 --> Router Class Initialized
INFO - 2023-08-24 18:46:59 --> Output Class Initialized
INFO - 2023-08-24 18:46:59 --> Security Class Initialized
DEBUG - 2023-08-24 18:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:46:59 --> Input Class Initialized
INFO - 2023-08-24 18:46:59 --> Language Class Initialized
ERROR - 2023-08-24 18:46:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:46:59 --> Config Class Initialized
INFO - 2023-08-24 18:46:59 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:46:59 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:46:59 --> Utf8 Class Initialized
INFO - 2023-08-24 18:46:59 --> URI Class Initialized
INFO - 2023-08-24 18:46:59 --> Router Class Initialized
INFO - 2023-08-24 18:46:59 --> Output Class Initialized
INFO - 2023-08-24 18:46:59 --> Security Class Initialized
DEBUG - 2023-08-24 18:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:46:59 --> Input Class Initialized
INFO - 2023-08-24 18:46:59 --> Language Class Initialized
ERROR - 2023-08-24 18:46:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:47:00 --> Config Class Initialized
INFO - 2023-08-24 18:47:00 --> Config Class Initialized
INFO - 2023-08-24 18:47:00 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:47:00 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:47:00 --> Utf8 Class Initialized
INFO - 2023-08-24 18:47:00 --> URI Class Initialized
INFO - 2023-08-24 18:47:00 --> Router Class Initialized
INFO - 2023-08-24 18:47:00 --> Output Class Initialized
INFO - 2023-08-24 18:47:00 --> Security Class Initialized
DEBUG - 2023-08-24 18:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:47:00 --> Input Class Initialized
INFO - 2023-08-24 18:47:00 --> Language Class Initialized
ERROR - 2023-08-24 18:47:00 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:47:00 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:47:00 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:47:00 --> Utf8 Class Initialized
INFO - 2023-08-24 18:47:00 --> URI Class Initialized
INFO - 2023-08-24 18:47:00 --> Router Class Initialized
INFO - 2023-08-24 18:47:00 --> Output Class Initialized
INFO - 2023-08-24 18:47:00 --> Security Class Initialized
DEBUG - 2023-08-24 18:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:47:00 --> Input Class Initialized
INFO - 2023-08-24 18:47:00 --> Language Class Initialized
ERROR - 2023-08-24 18:47:00 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:47:00 --> Config Class Initialized
INFO - 2023-08-24 18:47:00 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:47:01 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:47:01 --> Utf8 Class Initialized
INFO - 2023-08-24 18:47:01 --> URI Class Initialized
INFO - 2023-08-24 18:47:01 --> Router Class Initialized
INFO - 2023-08-24 18:47:01 --> Output Class Initialized
INFO - 2023-08-24 18:47:01 --> Security Class Initialized
DEBUG - 2023-08-24 18:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:47:01 --> Input Class Initialized
INFO - 2023-08-24 18:47:01 --> Language Class Initialized
ERROR - 2023-08-24 18:47:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:47:01 --> Config Class Initialized
INFO - 2023-08-24 18:47:01 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:47:01 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:47:01 --> Utf8 Class Initialized
INFO - 2023-08-24 18:47:01 --> URI Class Initialized
INFO - 2023-08-24 18:47:01 --> Router Class Initialized
INFO - 2023-08-24 18:47:01 --> Output Class Initialized
INFO - 2023-08-24 18:47:01 --> Security Class Initialized
DEBUG - 2023-08-24 18:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:47:01 --> Input Class Initialized
INFO - 2023-08-24 18:47:01 --> Language Class Initialized
ERROR - 2023-08-24 18:47:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:47:20 --> Config Class Initialized
INFO - 2023-08-24 18:47:20 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:47:20 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:47:20 --> Utf8 Class Initialized
INFO - 2023-08-24 18:47:20 --> URI Class Initialized
INFO - 2023-08-24 18:47:21 --> Router Class Initialized
INFO - 2023-08-24 18:47:21 --> Output Class Initialized
INFO - 2023-08-24 18:47:21 --> Security Class Initialized
DEBUG - 2023-08-24 18:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:47:21 --> Input Class Initialized
INFO - 2023-08-24 18:47:21 --> Language Class Initialized
INFO - 2023-08-24 18:47:21 --> Loader Class Initialized
INFO - 2023-08-24 18:47:21 --> Helper loaded: url_helper
INFO - 2023-08-24 18:47:21 --> Helper loaded: file_helper
INFO - 2023-08-24 18:47:21 --> Database Driver Class Initialized
INFO - 2023-08-24 18:47:21 --> Email Class Initialized
DEBUG - 2023-08-24 18:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:47:21 --> Controller Class Initialized
INFO - 2023-08-24 18:47:21 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:47:21 --> Model "Home_model" initialized
INFO - 2023-08-24 18:47:21 --> Helper loaded: download_helper
INFO - 2023-08-24 18:47:21 --> Helper loaded: form_helper
INFO - 2023-08-24 18:47:21 --> Form Validation Class Initialized
ERROR - 2023-08-24 18:47:21 --> Severity: Warning --> file_get_contents(http://localhost/dw/ /assets/images/brochure/1692525269blog-one-img-1.jpg): Failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\xampp\htdocs\dw\application\controllers\Home\HomeController.php 123
INFO - 2023-08-24 18:48:03 --> Config Class Initialized
INFO - 2023-08-24 18:48:03 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:03 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:03 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:03 --> URI Class Initialized
INFO - 2023-08-24 18:48:03 --> Router Class Initialized
INFO - 2023-08-24 18:48:03 --> Output Class Initialized
INFO - 2023-08-24 18:48:03 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:03 --> Input Class Initialized
INFO - 2023-08-24 18:48:03 --> Language Class Initialized
ERROR - 2023-08-24 18:48:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:48:04 --> Config Class Initialized
INFO - 2023-08-24 18:48:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:04 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:04 --> URI Class Initialized
INFO - 2023-08-24 18:48:04 --> Router Class Initialized
INFO - 2023-08-24 18:48:04 --> Output Class Initialized
INFO - 2023-08-24 18:48:04 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:04 --> Input Class Initialized
INFO - 2023-08-24 18:48:04 --> Language Class Initialized
ERROR - 2023-08-24 18:48:04 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:48:04 --> Config Class Initialized
INFO - 2023-08-24 18:48:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:04 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:04 --> URI Class Initialized
INFO - 2023-08-24 18:48:04 --> Router Class Initialized
INFO - 2023-08-24 18:48:04 --> Output Class Initialized
INFO - 2023-08-24 18:48:04 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:04 --> Input Class Initialized
INFO - 2023-08-24 18:48:04 --> Language Class Initialized
ERROR - 2023-08-24 18:48:04 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:48:04 --> Config Class Initialized
INFO - 2023-08-24 18:48:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:04 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:04 --> URI Class Initialized
INFO - 2023-08-24 18:48:04 --> Router Class Initialized
INFO - 2023-08-24 18:48:04 --> Output Class Initialized
INFO - 2023-08-24 18:48:04 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:04 --> Input Class Initialized
INFO - 2023-08-24 18:48:04 --> Language Class Initialized
ERROR - 2023-08-24 18:48:04 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:48:04 --> Config Class Initialized
INFO - 2023-08-24 18:48:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:04 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:04 --> URI Class Initialized
INFO - 2023-08-24 18:48:04 --> Router Class Initialized
INFO - 2023-08-24 18:48:04 --> Output Class Initialized
INFO - 2023-08-24 18:48:04 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:04 --> Input Class Initialized
INFO - 2023-08-24 18:48:04 --> Language Class Initialized
ERROR - 2023-08-24 18:48:04 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:48:04 --> Config Class Initialized
INFO - 2023-08-24 18:48:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:04 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:04 --> URI Class Initialized
INFO - 2023-08-24 18:48:04 --> Router Class Initialized
INFO - 2023-08-24 18:48:04 --> Output Class Initialized
INFO - 2023-08-24 18:48:04 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:05 --> Input Class Initialized
INFO - 2023-08-24 18:48:05 --> Language Class Initialized
ERROR - 2023-08-24 18:48:05 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:48:05 --> Config Class Initialized
INFO - 2023-08-24 18:48:05 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:05 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:05 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:05 --> URI Class Initialized
INFO - 2023-08-24 18:48:05 --> Router Class Initialized
INFO - 2023-08-24 18:48:05 --> Output Class Initialized
INFO - 2023-08-24 18:48:05 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:05 --> Input Class Initialized
INFO - 2023-08-24 18:48:05 --> Language Class Initialized
ERROR - 2023-08-24 18:48:05 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:48:07 --> Config Class Initialized
INFO - 2023-08-24 18:48:07 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:07 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:07 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:07 --> URI Class Initialized
INFO - 2023-08-24 18:48:07 --> Router Class Initialized
INFO - 2023-08-24 18:48:07 --> Output Class Initialized
INFO - 2023-08-24 18:48:07 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:07 --> Input Class Initialized
INFO - 2023-08-24 18:48:07 --> Language Class Initialized
INFO - 2023-08-24 18:48:07 --> Loader Class Initialized
INFO - 2023-08-24 18:48:07 --> Helper loaded: url_helper
INFO - 2023-08-24 18:48:07 --> Helper loaded: file_helper
INFO - 2023-08-24 18:48:07 --> Database Driver Class Initialized
INFO - 2023-08-24 18:48:07 --> Email Class Initialized
DEBUG - 2023-08-24 18:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:48:07 --> Controller Class Initialized
INFO - 2023-08-24 18:48:07 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:48:07 --> Model "Home_model" initialized
INFO - 2023-08-24 18:48:07 --> Helper loaded: download_helper
INFO - 2023-08-24 18:48:07 --> Helper loaded: form_helper
INFO - 2023-08-24 18:48:07 --> Form Validation Class Initialized
INFO - 2023-08-24 18:48:37 --> Config Class Initialized
INFO - 2023-08-24 18:48:37 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:37 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:37 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:37 --> URI Class Initialized
INFO - 2023-08-24 18:48:37 --> Router Class Initialized
INFO - 2023-08-24 18:48:37 --> Output Class Initialized
INFO - 2023-08-24 18:48:37 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:38 --> Input Class Initialized
INFO - 2023-08-24 18:48:38 --> Language Class Initialized
INFO - 2023-08-24 18:48:38 --> Loader Class Initialized
INFO - 2023-08-24 18:48:38 --> Helper loaded: url_helper
INFO - 2023-08-24 18:48:38 --> Helper loaded: file_helper
INFO - 2023-08-24 18:48:38 --> Database Driver Class Initialized
INFO - 2023-08-24 18:48:38 --> Email Class Initialized
DEBUG - 2023-08-24 18:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:48:38 --> Controller Class Initialized
INFO - 2023-08-24 18:48:38 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:48:38 --> Model "Home_model" initialized
INFO - 2023-08-24 18:48:38 --> Helper loaded: download_helper
INFO - 2023-08-24 18:48:38 --> Helper loaded: form_helper
INFO - 2023-08-24 18:48:38 --> Form Validation Class Initialized
INFO - 2023-08-24 18:48:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 18:48:38 --> Final output sent to browser
DEBUG - 2023-08-24 18:48:38 --> Total execution time: 0.7865
INFO - 2023-08-24 18:48:38 --> Config Class Initialized
INFO - 2023-08-24 18:48:38 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:38 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:38 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:38 --> URI Class Initialized
INFO - 2023-08-24 18:48:38 --> Router Class Initialized
INFO - 2023-08-24 18:48:38 --> Output Class Initialized
INFO - 2023-08-24 18:48:38 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:38 --> Input Class Initialized
INFO - 2023-08-24 18:48:38 --> Language Class Initialized
ERROR - 2023-08-24 18:48:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:48:39 --> Config Class Initialized
INFO - 2023-08-24 18:48:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:39 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:39 --> URI Class Initialized
INFO - 2023-08-24 18:48:39 --> Router Class Initialized
INFO - 2023-08-24 18:48:39 --> Output Class Initialized
INFO - 2023-08-24 18:48:39 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:39 --> Input Class Initialized
INFO - 2023-08-24 18:48:39 --> Language Class Initialized
ERROR - 2023-08-24 18:48:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:48:39 --> Config Class Initialized
INFO - 2023-08-24 18:48:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:39 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:39 --> URI Class Initialized
INFO - 2023-08-24 18:48:39 --> Router Class Initialized
INFO - 2023-08-24 18:48:39 --> Output Class Initialized
INFO - 2023-08-24 18:48:39 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:39 --> Input Class Initialized
INFO - 2023-08-24 18:48:39 --> Language Class Initialized
ERROR - 2023-08-24 18:48:39 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:48:39 --> Config Class Initialized
INFO - 2023-08-24 18:48:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:39 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:39 --> URI Class Initialized
INFO - 2023-08-24 18:48:39 --> Router Class Initialized
INFO - 2023-08-24 18:48:39 --> Output Class Initialized
INFO - 2023-08-24 18:48:39 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:39 --> Input Class Initialized
INFO - 2023-08-24 18:48:39 --> Language Class Initialized
ERROR - 2023-08-24 18:48:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:48:40 --> Config Class Initialized
INFO - 2023-08-24 18:48:40 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:40 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:40 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:40 --> URI Class Initialized
INFO - 2023-08-24 18:48:40 --> Router Class Initialized
INFO - 2023-08-24 18:48:40 --> Output Class Initialized
INFO - 2023-08-24 18:48:40 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:40 --> Input Class Initialized
INFO - 2023-08-24 18:48:40 --> Language Class Initialized
ERROR - 2023-08-24 18:48:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:48:40 --> Config Class Initialized
INFO - 2023-08-24 18:48:40 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:40 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:40 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:40 --> URI Class Initialized
INFO - 2023-08-24 18:48:40 --> Router Class Initialized
INFO - 2023-08-24 18:48:40 --> Output Class Initialized
INFO - 2023-08-24 18:48:40 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:40 --> Input Class Initialized
INFO - 2023-08-24 18:48:40 --> Language Class Initialized
ERROR - 2023-08-24 18:48:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:48:40 --> Config Class Initialized
INFO - 2023-08-24 18:48:40 --> Hooks Class Initialized
INFO - 2023-08-24 18:48:40 --> Config Class Initialized
INFO - 2023-08-24 18:48:40 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:40 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:40 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:40 --> URI Class Initialized
INFO - 2023-08-24 18:48:40 --> Router Class Initialized
INFO - 2023-08-24 18:48:40 --> Output Class Initialized
INFO - 2023-08-24 18:48:40 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:40 --> Input Class Initialized
INFO - 2023-08-24 18:48:40 --> Language Class Initialized
ERROR - 2023-08-24 18:48:40 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-24 18:48:40 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:40 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:40 --> URI Class Initialized
INFO - 2023-08-24 18:48:40 --> Router Class Initialized
INFO - 2023-08-24 18:48:40 --> Output Class Initialized
INFO - 2023-08-24 18:48:40 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:40 --> Input Class Initialized
INFO - 2023-08-24 18:48:40 --> Language Class Initialized
ERROR - 2023-08-24 18:48:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:48:40 --> Config Class Initialized
INFO - 2023-08-24 18:48:40 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:40 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:40 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:40 --> URI Class Initialized
INFO - 2023-08-24 18:48:40 --> Router Class Initialized
INFO - 2023-08-24 18:48:40 --> Output Class Initialized
INFO - 2023-08-24 18:48:40 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:40 --> Input Class Initialized
INFO - 2023-08-24 18:48:40 --> Language Class Initialized
ERROR - 2023-08-24 18:48:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:48:40 --> Config Class Initialized
INFO - 2023-08-24 18:48:40 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:40 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:40 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:40 --> URI Class Initialized
INFO - 2023-08-24 18:48:40 --> Router Class Initialized
INFO - 2023-08-24 18:48:40 --> Output Class Initialized
INFO - 2023-08-24 18:48:40 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:40 --> Input Class Initialized
INFO - 2023-08-24 18:48:40 --> Language Class Initialized
ERROR - 2023-08-24 18:48:40 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:48:41 --> Config Class Initialized
INFO - 2023-08-24 18:48:41 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:41 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:41 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:41 --> URI Class Initialized
INFO - 2023-08-24 18:48:41 --> Router Class Initialized
INFO - 2023-08-24 18:48:41 --> Output Class Initialized
INFO - 2023-08-24 18:48:41 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:41 --> Input Class Initialized
INFO - 2023-08-24 18:48:41 --> Language Class Initialized
ERROR - 2023-08-24 18:48:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:48:42 --> Config Class Initialized
INFO - 2023-08-24 18:48:42 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:42 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:42 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:42 --> URI Class Initialized
INFO - 2023-08-24 18:48:42 --> Router Class Initialized
INFO - 2023-08-24 18:48:42 --> Output Class Initialized
INFO - 2023-08-24 18:48:42 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:42 --> Input Class Initialized
INFO - 2023-08-24 18:48:42 --> Language Class Initialized
ERROR - 2023-08-24 18:48:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:48:42 --> Config Class Initialized
INFO - 2023-08-24 18:48:42 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:48:42 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:48:42 --> Utf8 Class Initialized
INFO - 2023-08-24 18:48:42 --> URI Class Initialized
INFO - 2023-08-24 18:48:42 --> Router Class Initialized
INFO - 2023-08-24 18:48:42 --> Output Class Initialized
INFO - 2023-08-24 18:48:42 --> Security Class Initialized
DEBUG - 2023-08-24 18:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:48:42 --> Input Class Initialized
INFO - 2023-08-24 18:48:42 --> Language Class Initialized
ERROR - 2023-08-24 18:48:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:49:52 --> Config Class Initialized
INFO - 2023-08-24 18:49:52 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:49:52 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:49:52 --> Utf8 Class Initialized
INFO - 2023-08-24 18:49:52 --> URI Class Initialized
INFO - 2023-08-24 18:49:52 --> Router Class Initialized
INFO - 2023-08-24 18:49:52 --> Output Class Initialized
INFO - 2023-08-24 18:49:52 --> Security Class Initialized
DEBUG - 2023-08-24 18:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:49:52 --> Input Class Initialized
INFO - 2023-08-24 18:49:52 --> Language Class Initialized
INFO - 2023-08-24 18:49:52 --> Loader Class Initialized
INFO - 2023-08-24 18:49:52 --> Helper loaded: url_helper
INFO - 2023-08-24 18:49:52 --> Helper loaded: file_helper
INFO - 2023-08-24 18:49:52 --> Database Driver Class Initialized
INFO - 2023-08-24 18:49:52 --> Email Class Initialized
DEBUG - 2023-08-24 18:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:49:52 --> Controller Class Initialized
INFO - 2023-08-24 18:49:52 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:49:52 --> Model "Home_model" initialized
INFO - 2023-08-24 18:49:52 --> Helper loaded: download_helper
INFO - 2023-08-24 18:49:52 --> Helper loaded: form_helper
INFO - 2023-08-24 18:49:52 --> Form Validation Class Initialized
ERROR - 2023-08-24 18:49:52 --> Severity: Warning --> file_get_contents(http://localhost/dw/ /assets/images/brochure/1692525269blog-one-img-1.jpg): Failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\xampp\htdocs\dw\application\controllers\Home\HomeController.php 123
INFO - 2023-08-24 18:50:28 --> Config Class Initialized
INFO - 2023-08-24 18:50:28 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:50:28 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:50:28 --> Utf8 Class Initialized
INFO - 2023-08-24 18:50:28 --> URI Class Initialized
INFO - 2023-08-24 18:50:28 --> Router Class Initialized
INFO - 2023-08-24 18:50:28 --> Output Class Initialized
INFO - 2023-08-24 18:50:28 --> Security Class Initialized
DEBUG - 2023-08-24 18:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:50:28 --> Input Class Initialized
INFO - 2023-08-24 18:50:28 --> Language Class Initialized
INFO - 2023-08-24 18:50:28 --> Loader Class Initialized
INFO - 2023-08-24 18:50:28 --> Helper loaded: url_helper
INFO - 2023-08-24 18:50:28 --> Helper loaded: file_helper
INFO - 2023-08-24 18:50:28 --> Database Driver Class Initialized
INFO - 2023-08-24 18:50:28 --> Email Class Initialized
DEBUG - 2023-08-24 18:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:50:28 --> Controller Class Initialized
INFO - 2023-08-24 18:50:28 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:50:28 --> Model "Home_model" initialized
INFO - 2023-08-24 18:50:28 --> Helper loaded: download_helper
INFO - 2023-08-24 18:50:28 --> Helper loaded: form_helper
INFO - 2023-08-24 18:50:28 --> Form Validation Class Initialized
INFO - 2023-08-24 18:50:48 --> Config Class Initialized
INFO - 2023-08-24 18:50:48 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:50:48 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:50:48 --> Utf8 Class Initialized
INFO - 2023-08-24 18:50:48 --> URI Class Initialized
INFO - 2023-08-24 18:50:48 --> Router Class Initialized
INFO - 2023-08-24 18:50:48 --> Output Class Initialized
INFO - 2023-08-24 18:50:48 --> Security Class Initialized
DEBUG - 2023-08-24 18:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:50:48 --> Input Class Initialized
INFO - 2023-08-24 18:50:48 --> Language Class Initialized
INFO - 2023-08-24 18:50:48 --> Loader Class Initialized
INFO - 2023-08-24 18:50:48 --> Helper loaded: url_helper
INFO - 2023-08-24 18:50:48 --> Helper loaded: file_helper
INFO - 2023-08-24 18:50:48 --> Database Driver Class Initialized
INFO - 2023-08-24 18:50:48 --> Email Class Initialized
DEBUG - 2023-08-24 18:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:50:48 --> Controller Class Initialized
INFO - 2023-08-24 18:50:48 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:50:48 --> Model "Home_model" initialized
INFO - 2023-08-24 18:50:48 --> Helper loaded: download_helper
INFO - 2023-08-24 18:50:48 --> Helper loaded: form_helper
INFO - 2023-08-24 18:50:48 --> Form Validation Class Initialized
INFO - 2023-08-24 18:53:50 --> Config Class Initialized
INFO - 2023-08-24 18:53:50 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:53:50 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:53:50 --> Utf8 Class Initialized
INFO - 2023-08-24 18:53:50 --> URI Class Initialized
INFO - 2023-08-24 18:53:50 --> Router Class Initialized
INFO - 2023-08-24 18:53:50 --> Output Class Initialized
INFO - 2023-08-24 18:53:50 --> Security Class Initialized
DEBUG - 2023-08-24 18:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:53:50 --> Input Class Initialized
INFO - 2023-08-24 18:53:50 --> Language Class Initialized
INFO - 2023-08-24 18:53:50 --> Loader Class Initialized
INFO - 2023-08-24 18:53:50 --> Helper loaded: url_helper
INFO - 2023-08-24 18:53:50 --> Helper loaded: file_helper
INFO - 2023-08-24 18:53:50 --> Database Driver Class Initialized
INFO - 2023-08-24 18:53:51 --> Email Class Initialized
DEBUG - 2023-08-24 18:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:53:51 --> Controller Class Initialized
INFO - 2023-08-24 18:53:51 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:53:51 --> Model "Home_model" initialized
INFO - 2023-08-24 18:53:51 --> Helper loaded: download_helper
INFO - 2023-08-24 18:53:51 --> Helper loaded: form_helper
INFO - 2023-08-24 18:53:51 --> Form Validation Class Initialized
INFO - 2023-08-24 18:55:22 --> Config Class Initialized
INFO - 2023-08-24 18:55:22 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:55:22 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:55:23 --> Utf8 Class Initialized
INFO - 2023-08-24 18:55:23 --> URI Class Initialized
INFO - 2023-08-24 18:55:23 --> Router Class Initialized
INFO - 2023-08-24 18:55:23 --> Output Class Initialized
INFO - 2023-08-24 18:55:23 --> Security Class Initialized
DEBUG - 2023-08-24 18:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:55:23 --> Input Class Initialized
INFO - 2023-08-24 18:55:23 --> Language Class Initialized
INFO - 2023-08-24 18:55:23 --> Loader Class Initialized
INFO - 2023-08-24 18:55:23 --> Helper loaded: url_helper
INFO - 2023-08-24 18:55:23 --> Helper loaded: file_helper
INFO - 2023-08-24 18:55:23 --> Database Driver Class Initialized
INFO - 2023-08-24 18:55:23 --> Email Class Initialized
DEBUG - 2023-08-24 18:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:55:23 --> Controller Class Initialized
INFO - 2023-08-24 18:55:23 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:55:23 --> Model "Home_model" initialized
INFO - 2023-08-24 18:55:23 --> Helper loaded: download_helper
INFO - 2023-08-24 18:55:23 --> Helper loaded: form_helper
INFO - 2023-08-24 18:55:23 --> Form Validation Class Initialized
INFO - 2023-08-24 18:55:41 --> Config Class Initialized
INFO - 2023-08-24 18:55:41 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:55:41 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:55:41 --> Utf8 Class Initialized
INFO - 2023-08-24 18:55:41 --> URI Class Initialized
INFO - 2023-08-24 18:55:41 --> Router Class Initialized
INFO - 2023-08-24 18:55:41 --> Output Class Initialized
INFO - 2023-08-24 18:55:42 --> Security Class Initialized
DEBUG - 2023-08-24 18:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:55:42 --> Input Class Initialized
INFO - 2023-08-24 18:55:42 --> Language Class Initialized
INFO - 2023-08-24 18:55:42 --> Loader Class Initialized
INFO - 2023-08-24 18:55:42 --> Helper loaded: url_helper
INFO - 2023-08-24 18:55:42 --> Helper loaded: file_helper
INFO - 2023-08-24 18:55:42 --> Database Driver Class Initialized
INFO - 2023-08-24 18:55:42 --> Email Class Initialized
DEBUG - 2023-08-24 18:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:55:42 --> Controller Class Initialized
INFO - 2023-08-24 18:55:42 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:55:42 --> Model "Home_model" initialized
INFO - 2023-08-24 18:55:42 --> Helper loaded: download_helper
INFO - 2023-08-24 18:55:42 --> Helper loaded: form_helper
INFO - 2023-08-24 18:55:42 --> Form Validation Class Initialized
INFO - 2023-08-24 18:55:56 --> Config Class Initialized
INFO - 2023-08-24 18:55:56 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:55:56 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:55:56 --> Utf8 Class Initialized
INFO - 2023-08-24 18:55:56 --> URI Class Initialized
INFO - 2023-08-24 18:55:56 --> Router Class Initialized
INFO - 2023-08-24 18:55:56 --> Output Class Initialized
INFO - 2023-08-24 18:55:56 --> Security Class Initialized
DEBUG - 2023-08-24 18:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:55:56 --> Input Class Initialized
INFO - 2023-08-24 18:55:56 --> Language Class Initialized
INFO - 2023-08-24 18:55:56 --> Loader Class Initialized
INFO - 2023-08-24 18:55:56 --> Helper loaded: url_helper
INFO - 2023-08-24 18:55:56 --> Helper loaded: file_helper
INFO - 2023-08-24 18:55:56 --> Database Driver Class Initialized
INFO - 2023-08-24 18:55:56 --> Email Class Initialized
DEBUG - 2023-08-24 18:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:55:56 --> Controller Class Initialized
INFO - 2023-08-24 18:55:56 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:55:56 --> Model "Home_model" initialized
INFO - 2023-08-24 18:55:56 --> Helper loaded: download_helper
INFO - 2023-08-24 18:55:56 --> Helper loaded: form_helper
INFO - 2023-08-24 18:55:56 --> Form Validation Class Initialized
INFO - 2023-08-24 18:55:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 18:55:56 --> Final output sent to browser
DEBUG - 2023-08-24 18:55:57 --> Total execution time: 0.7076
INFO - 2023-08-24 18:55:58 --> Config Class Initialized
INFO - 2023-08-24 18:55:58 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:55:58 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:55:58 --> Utf8 Class Initialized
INFO - 2023-08-24 18:55:58 --> URI Class Initialized
INFO - 2023-08-24 18:55:58 --> Router Class Initialized
INFO - 2023-08-24 18:55:58 --> Output Class Initialized
INFO - 2023-08-24 18:55:58 --> Security Class Initialized
DEBUG - 2023-08-24 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:55:58 --> Input Class Initialized
INFO - 2023-08-24 18:55:58 --> Language Class Initialized
ERROR - 2023-08-24 18:55:58 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:55:58 --> Config Class Initialized
INFO - 2023-08-24 18:55:58 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:55:58 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:55:59 --> Utf8 Class Initialized
INFO - 2023-08-24 18:55:59 --> Config Class Initialized
INFO - 2023-08-24 18:55:59 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:55:59 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:55:59 --> Utf8 Class Initialized
INFO - 2023-08-24 18:55:59 --> URI Class Initialized
INFO - 2023-08-24 18:55:59 --> Router Class Initialized
INFO - 2023-08-24 18:55:59 --> Output Class Initialized
INFO - 2023-08-24 18:55:59 --> Security Class Initialized
DEBUG - 2023-08-24 18:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:55:59 --> Input Class Initialized
INFO - 2023-08-24 18:55:59 --> Language Class Initialized
ERROR - 2023-08-24 18:55:59 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:55:59 --> URI Class Initialized
INFO - 2023-08-24 18:55:59 --> Router Class Initialized
INFO - 2023-08-24 18:55:59 --> Output Class Initialized
INFO - 2023-08-24 18:55:59 --> Security Class Initialized
DEBUG - 2023-08-24 18:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:55:59 --> Input Class Initialized
INFO - 2023-08-24 18:55:59 --> Language Class Initialized
ERROR - 2023-08-24 18:55:59 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:55:59 --> Config Class Initialized
INFO - 2023-08-24 18:55:59 --> Config Class Initialized
INFO - 2023-08-24 18:55:59 --> Config Class Initialized
INFO - 2023-08-24 18:55:59 --> Config Class Initialized
INFO - 2023-08-24 18:55:59 --> Hooks Class Initialized
INFO - 2023-08-24 18:55:59 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:55:59 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:55:59 --> Utf8 Class Initialized
INFO - 2023-08-24 18:55:59 --> Hooks Class Initialized
INFO - 2023-08-24 18:55:59 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:55:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 18:55:59 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:55:59 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:00 --> URI Class Initialized
INFO - 2023-08-24 18:56:00 --> URI Class Initialized
INFO - 2023-08-24 18:56:00 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:00 --> URI Class Initialized
INFO - 2023-08-24 18:56:00 --> Router Class Initialized
INFO - 2023-08-24 18:56:00 --> Output Class Initialized
DEBUG - 2023-08-24 18:56:00 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:56:00 --> Router Class Initialized
INFO - 2023-08-24 18:56:00 --> Security Class Initialized
INFO - 2023-08-24 18:56:00 --> Router Class Initialized
INFO - 2023-08-24 18:56:00 --> Output Class Initialized
DEBUG - 2023-08-24 18:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:00 --> Security Class Initialized
DEBUG - 2023-08-24 18:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:00 --> Output Class Initialized
INFO - 2023-08-24 18:56:00 --> Input Class Initialized
INFO - 2023-08-24 18:56:00 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:00 --> Input Class Initialized
INFO - 2023-08-24 18:56:00 --> Language Class Initialized
INFO - 2023-08-24 18:56:00 --> URI Class Initialized
ERROR - 2023-08-24 18:56:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:56:00 --> Router Class Initialized
INFO - 2023-08-24 18:56:00 --> Security Class Initialized
INFO - 2023-08-24 18:56:00 --> Language Class Initialized
INFO - 2023-08-24 18:56:00 --> Output Class Initialized
DEBUG - 2023-08-24 18:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:00 --> Security Class Initialized
INFO - 2023-08-24 18:56:00 --> Input Class Initialized
DEBUG - 2023-08-24 18:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:00 --> Language Class Initialized
ERROR - 2023-08-24 18:56:00 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-24 18:56:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:56:00 --> Input Class Initialized
INFO - 2023-08-24 18:56:00 --> Language Class Initialized
ERROR - 2023-08-24 18:56:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 18:56:00 --> Config Class Initialized
INFO - 2023-08-24 18:56:00 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:56:01 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:56:01 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:01 --> URI Class Initialized
INFO - 2023-08-24 18:56:01 --> Router Class Initialized
INFO - 2023-08-24 18:56:01 --> Output Class Initialized
INFO - 2023-08-24 18:56:01 --> Security Class Initialized
DEBUG - 2023-08-24 18:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:01 --> Input Class Initialized
INFO - 2023-08-24 18:56:01 --> Language Class Initialized
INFO - 2023-08-24 18:56:01 --> Loader Class Initialized
INFO - 2023-08-24 18:56:01 --> Helper loaded: url_helper
INFO - 2023-08-24 18:56:01 --> Helper loaded: file_helper
INFO - 2023-08-24 18:56:01 --> Database Driver Class Initialized
INFO - 2023-08-24 18:56:01 --> Email Class Initialized
DEBUG - 2023-08-24 18:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:56:01 --> Controller Class Initialized
INFO - 2023-08-24 18:56:01 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:56:01 --> Model "Home_model" initialized
INFO - 2023-08-24 18:56:01 --> Helper loaded: download_helper
INFO - 2023-08-24 18:56:01 --> Helper loaded: form_helper
INFO - 2023-08-24 18:56:01 --> Form Validation Class Initialized
INFO - 2023-08-24 18:56:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 18:56:01 --> Final output sent to browser
DEBUG - 2023-08-24 18:56:01 --> Total execution time: 0.3840
INFO - 2023-08-24 18:56:02 --> Config Class Initialized
INFO - 2023-08-24 18:56:02 --> Hooks Class Initialized
INFO - 2023-08-24 18:56:02 --> Config Class Initialized
INFO - 2023-08-24 18:56:02 --> Config Class Initialized
INFO - 2023-08-24 18:56:02 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:56:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:56:02 --> Config Class Initialized
INFO - 2023-08-24 18:56:02 --> Config Class Initialized
INFO - 2023-08-24 18:56:02 --> Utf8 Class Initialized
DEBUG - 2023-08-24 18:56:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:56:02 --> Hooks Class Initialized
INFO - 2023-08-24 18:56:02 --> Hooks Class Initialized
INFO - 2023-08-24 18:56:02 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:56:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:56:02 --> URI Class Initialized
DEBUG - 2023-08-24 18:56:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 18:56:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:56:02 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:02 --> URI Class Initialized
INFO - 2023-08-24 18:56:02 --> Router Class Initialized
INFO - 2023-08-24 18:56:02 --> Output Class Initialized
INFO - 2023-08-24 18:56:02 --> Security Class Initialized
DEBUG - 2023-08-24 18:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:02 --> Input Class Initialized
INFO - 2023-08-24 18:56:02 --> Language Class Initialized
ERROR - 2023-08-24 18:56:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:56:02 --> Router Class Initialized
INFO - 2023-08-24 18:56:02 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:02 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:02 --> Output Class Initialized
INFO - 2023-08-24 18:56:02 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:02 --> URI Class Initialized
INFO - 2023-08-24 18:56:02 --> URI Class Initialized
INFO - 2023-08-24 18:56:02 --> Security Class Initialized
INFO - 2023-08-24 18:56:02 --> URI Class Initialized
INFO - 2023-08-24 18:56:02 --> Router Class Initialized
DEBUG - 2023-08-24 18:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:02 --> Router Class Initialized
INFO - 2023-08-24 18:56:02 --> Router Class Initialized
INFO - 2023-08-24 18:56:02 --> Output Class Initialized
INFO - 2023-08-24 18:56:02 --> Output Class Initialized
INFO - 2023-08-24 18:56:02 --> Security Class Initialized
INFO - 2023-08-24 18:56:02 --> Output Class Initialized
INFO - 2023-08-24 18:56:02 --> Security Class Initialized
INFO - 2023-08-24 18:56:02 --> Input Class Initialized
INFO - 2023-08-24 18:56:02 --> Security Class Initialized
INFO - 2023-08-24 18:56:02 --> Language Class Initialized
DEBUG - 2023-08-24 18:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:02 --> Input Class Initialized
INFO - 2023-08-24 18:56:02 --> Language Class Initialized
ERROR - 2023-08-24 18:56:02 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-24 18:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-24 18:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:02 --> Input Class Initialized
INFO - 2023-08-24 18:56:02 --> Input Class Initialized
ERROR - 2023-08-24 18:56:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:56:02 --> Language Class Initialized
INFO - 2023-08-24 18:56:02 --> Language Class Initialized
ERROR - 2023-08-24 18:56:02 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-24 18:56:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:56:16 --> Config Class Initialized
INFO - 2023-08-24 18:56:16 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:56:16 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:56:16 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:16 --> URI Class Initialized
INFO - 2023-08-24 18:56:16 --> Router Class Initialized
INFO - 2023-08-24 18:56:16 --> Output Class Initialized
INFO - 2023-08-24 18:56:16 --> Security Class Initialized
DEBUG - 2023-08-24 18:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:16 --> Input Class Initialized
INFO - 2023-08-24 18:56:16 --> Language Class Initialized
INFO - 2023-08-24 18:56:16 --> Loader Class Initialized
INFO - 2023-08-24 18:56:16 --> Helper loaded: url_helper
INFO - 2023-08-24 18:56:16 --> Helper loaded: file_helper
INFO - 2023-08-24 18:56:16 --> Database Driver Class Initialized
INFO - 2023-08-24 18:56:16 --> Email Class Initialized
DEBUG - 2023-08-24 18:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:56:16 --> Controller Class Initialized
INFO - 2023-08-24 18:56:16 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:56:16 --> Model "Home_model" initialized
INFO - 2023-08-24 18:56:16 --> Helper loaded: download_helper
INFO - 2023-08-24 18:56:16 --> Helper loaded: form_helper
INFO - 2023-08-24 18:56:16 --> Form Validation Class Initialized
INFO - 2023-08-24 18:56:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 18:56:17 --> Final output sent to browser
DEBUG - 2023-08-24 18:56:17 --> Total execution time: 0.4738
INFO - 2023-08-24 18:56:17 --> Config Class Initialized
INFO - 2023-08-24 18:56:17 --> Hooks Class Initialized
INFO - 2023-08-24 18:56:18 --> Config Class Initialized
INFO - 2023-08-24 18:56:18 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:56:18 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:56:18 --> Config Class Initialized
INFO - 2023-08-24 18:56:18 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:18 --> Config Class Initialized
INFO - 2023-08-24 18:56:18 --> Config Class Initialized
INFO - 2023-08-24 18:56:18 --> URI Class Initialized
DEBUG - 2023-08-24 18:56:18 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:56:18 --> Hooks Class Initialized
INFO - 2023-08-24 18:56:18 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:56:18 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:56:18 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:56:18 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:56:18 --> Router Class Initialized
DEBUG - 2023-08-24 18:56:18 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:56:18 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:18 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:18 --> Output Class Initialized
INFO - 2023-08-24 18:56:18 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:18 --> URI Class Initialized
INFO - 2023-08-24 18:56:18 --> Security Class Initialized
INFO - 2023-08-24 18:56:18 --> URI Class Initialized
INFO - 2023-08-24 18:56:18 --> Router Class Initialized
INFO - 2023-08-24 18:56:18 --> Router Class Initialized
DEBUG - 2023-08-24 18:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:18 --> URI Class Initialized
INFO - 2023-08-24 18:56:18 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:18 --> Output Class Initialized
INFO - 2023-08-24 18:56:18 --> Input Class Initialized
INFO - 2023-08-24 18:56:18 --> Output Class Initialized
INFO - 2023-08-24 18:56:18 --> Security Class Initialized
INFO - 2023-08-24 18:56:18 --> Security Class Initialized
INFO - 2023-08-24 18:56:18 --> Router Class Initialized
INFO - 2023-08-24 18:56:18 --> URI Class Initialized
INFO - 2023-08-24 18:56:18 --> Output Class Initialized
DEBUG - 2023-08-24 18:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:18 --> Input Class Initialized
INFO - 2023-08-24 18:56:18 --> Language Class Initialized
ERROR - 2023-08-24 18:56:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:56:18 --> Security Class Initialized
INFO - 2023-08-24 18:56:18 --> Router Class Initialized
DEBUG - 2023-08-24 18:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:18 --> Language Class Initialized
ERROR - 2023-08-24 18:56:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:56:18 --> Output Class Initialized
DEBUG - 2023-08-24 18:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:18 --> Input Class Initialized
INFO - 2023-08-24 18:56:18 --> Input Class Initialized
INFO - 2023-08-24 18:56:18 --> Language Class Initialized
INFO - 2023-08-24 18:56:18 --> Security Class Initialized
INFO - 2023-08-24 18:56:18 --> Language Class Initialized
DEBUG - 2023-08-24 18:56:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-24 18:56:18 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-24 18:56:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:56:18 --> Input Class Initialized
INFO - 2023-08-24 18:56:18 --> Language Class Initialized
ERROR - 2023-08-24 18:56:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:56:40 --> Config Class Initialized
INFO - 2023-08-24 18:56:40 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:56:40 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:56:40 --> Utf8 Class Initialized
INFO - 2023-08-24 18:56:40 --> URI Class Initialized
INFO - 2023-08-24 18:56:40 --> Router Class Initialized
INFO - 2023-08-24 18:56:40 --> Output Class Initialized
INFO - 2023-08-24 18:56:40 --> Security Class Initialized
DEBUG - 2023-08-24 18:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:56:40 --> Input Class Initialized
INFO - 2023-08-24 18:56:40 --> Language Class Initialized
INFO - 2023-08-24 18:56:40 --> Loader Class Initialized
INFO - 2023-08-24 18:56:40 --> Helper loaded: url_helper
INFO - 2023-08-24 18:56:40 --> Helper loaded: file_helper
INFO - 2023-08-24 18:56:40 --> Database Driver Class Initialized
INFO - 2023-08-24 18:56:40 --> Email Class Initialized
DEBUG - 2023-08-24 18:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:56:40 --> Controller Class Initialized
INFO - 2023-08-24 18:56:40 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:56:40 --> Model "Home_model" initialized
INFO - 2023-08-24 18:56:40 --> Helper loaded: download_helper
INFO - 2023-08-24 18:56:40 --> Helper loaded: form_helper
INFO - 2023-08-24 18:56:40 --> Form Validation Class Initialized
INFO - 2023-08-24 18:57:02 --> Config Class Initialized
INFO - 2023-08-24 18:57:02 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:57:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:57:02 --> Utf8 Class Initialized
INFO - 2023-08-24 18:57:02 --> URI Class Initialized
INFO - 2023-08-24 18:57:02 --> Router Class Initialized
INFO - 2023-08-24 18:57:02 --> Output Class Initialized
INFO - 2023-08-24 18:57:02 --> Security Class Initialized
DEBUG - 2023-08-24 18:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:57:02 --> Input Class Initialized
INFO - 2023-08-24 18:57:02 --> Language Class Initialized
INFO - 2023-08-24 18:57:02 --> Loader Class Initialized
INFO - 2023-08-24 18:57:03 --> Helper loaded: url_helper
INFO - 2023-08-24 18:57:03 --> Helper loaded: file_helper
INFO - 2023-08-24 18:57:03 --> Database Driver Class Initialized
INFO - 2023-08-24 18:57:03 --> Email Class Initialized
DEBUG - 2023-08-24 18:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:57:03 --> Controller Class Initialized
INFO - 2023-08-24 18:57:03 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:57:03 --> Model "Home_model" initialized
INFO - 2023-08-24 18:57:03 --> Helper loaded: download_helper
INFO - 2023-08-24 18:57:03 --> Helper loaded: form_helper
INFO - 2023-08-24 18:57:03 --> Form Validation Class Initialized
INFO - 2023-08-24 18:57:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 18:57:03 --> Final output sent to browser
DEBUG - 2023-08-24 18:57:03 --> Total execution time: 0.4208
INFO - 2023-08-24 18:57:03 --> Config Class Initialized
INFO - 2023-08-24 18:57:03 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:57:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:57:04 --> Utf8 Class Initialized
INFO - 2023-08-24 18:57:04 --> Config Class Initialized
INFO - 2023-08-24 18:57:04 --> Config Class Initialized
INFO - 2023-08-24 18:57:04 --> Hooks Class Initialized
INFO - 2023-08-24 18:57:04 --> URI Class Initialized
INFO - 2023-08-24 18:57:04 --> Config Class Initialized
DEBUG - 2023-08-24 18:57:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:57:04 --> Utf8 Class Initialized
INFO - 2023-08-24 18:57:04 --> URI Class Initialized
INFO - 2023-08-24 18:57:04 --> Router Class Initialized
INFO - 2023-08-24 18:57:04 --> Output Class Initialized
INFO - 2023-08-24 18:57:04 --> Security Class Initialized
DEBUG - 2023-08-24 18:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:57:04 --> Input Class Initialized
INFO - 2023-08-24 18:57:04 --> Language Class Initialized
ERROR - 2023-08-24 18:57:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:57:04 --> Config Class Initialized
INFO - 2023-08-24 18:57:04 --> Hooks Class Initialized
INFO - 2023-08-24 18:57:04 --> Hooks Class Initialized
INFO - 2023-08-24 18:57:04 --> Router Class Initialized
INFO - 2023-08-24 18:57:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:57:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 18:57:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 18:57:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:57:04 --> Utf8 Class Initialized
INFO - 2023-08-24 18:57:04 --> Output Class Initialized
INFO - 2023-08-24 18:57:04 --> URI Class Initialized
INFO - 2023-08-24 18:57:04 --> Utf8 Class Initialized
INFO - 2023-08-24 18:57:04 --> Utf8 Class Initialized
INFO - 2023-08-24 18:57:04 --> URI Class Initialized
INFO - 2023-08-24 18:57:04 --> Security Class Initialized
INFO - 2023-08-24 18:57:04 --> Router Class Initialized
INFO - 2023-08-24 18:57:04 --> Router Class Initialized
DEBUG - 2023-08-24 18:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:57:04 --> URI Class Initialized
INFO - 2023-08-24 18:57:04 --> Output Class Initialized
INFO - 2023-08-24 18:57:04 --> Router Class Initialized
INFO - 2023-08-24 18:57:04 --> Output Class Initialized
INFO - 2023-08-24 18:57:04 --> Output Class Initialized
INFO - 2023-08-24 18:57:04 --> Input Class Initialized
INFO - 2023-08-24 18:57:04 --> Security Class Initialized
INFO - 2023-08-24 18:57:04 --> Security Class Initialized
INFO - 2023-08-24 18:57:04 --> Security Class Initialized
DEBUG - 2023-08-24 18:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:57:04 --> Language Class Initialized
DEBUG - 2023-08-24 18:57:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-24 18:57:04 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-24 18:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:57:04 --> Input Class Initialized
INFO - 2023-08-24 18:57:04 --> Input Class Initialized
INFO - 2023-08-24 18:57:04 --> Input Class Initialized
INFO - 2023-08-24 18:57:04 --> Language Class Initialized
INFO - 2023-08-24 18:57:04 --> Language Class Initialized
ERROR - 2023-08-24 18:57:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:57:04 --> Language Class Initialized
ERROR - 2023-08-24 18:57:04 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-24 18:57:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 18:57:22 --> Config Class Initialized
INFO - 2023-08-24 18:57:22 --> Hooks Class Initialized
DEBUG - 2023-08-24 18:57:22 --> UTF-8 Support Enabled
INFO - 2023-08-24 18:57:22 --> Utf8 Class Initialized
INFO - 2023-08-24 18:57:22 --> URI Class Initialized
INFO - 2023-08-24 18:57:22 --> Router Class Initialized
INFO - 2023-08-24 18:57:22 --> Output Class Initialized
INFO - 2023-08-24 18:57:22 --> Security Class Initialized
DEBUG - 2023-08-24 18:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 18:57:22 --> Input Class Initialized
INFO - 2023-08-24 18:57:22 --> Language Class Initialized
INFO - 2023-08-24 18:57:22 --> Loader Class Initialized
INFO - 2023-08-24 18:57:22 --> Helper loaded: url_helper
INFO - 2023-08-24 18:57:22 --> Helper loaded: file_helper
INFO - 2023-08-24 18:57:22 --> Database Driver Class Initialized
INFO - 2023-08-24 18:57:23 --> Email Class Initialized
DEBUG - 2023-08-24 18:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 18:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 18:57:23 --> Controller Class Initialized
INFO - 2023-08-24 18:57:23 --> Model "Contact_model" initialized
INFO - 2023-08-24 18:57:23 --> Model "Home_model" initialized
INFO - 2023-08-24 18:57:23 --> Helper loaded: download_helper
INFO - 2023-08-24 18:57:23 --> Helper loaded: form_helper
INFO - 2023-08-24 18:57:23 --> Form Validation Class Initialized
INFO - 2023-08-24 19:01:06 --> Config Class Initialized
INFO - 2023-08-24 19:01:06 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:01:06 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:01:06 --> Utf8 Class Initialized
INFO - 2023-08-24 19:01:06 --> URI Class Initialized
INFO - 2023-08-24 19:01:06 --> Router Class Initialized
INFO - 2023-08-24 19:01:06 --> Output Class Initialized
INFO - 2023-08-24 19:01:06 --> Security Class Initialized
DEBUG - 2023-08-24 19:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:01:06 --> Input Class Initialized
INFO - 2023-08-24 19:01:06 --> Language Class Initialized
INFO - 2023-08-24 19:01:06 --> Loader Class Initialized
INFO - 2023-08-24 19:01:06 --> Helper loaded: url_helper
INFO - 2023-08-24 19:01:06 --> Helper loaded: file_helper
INFO - 2023-08-24 19:01:06 --> Database Driver Class Initialized
INFO - 2023-08-24 19:01:06 --> Email Class Initialized
DEBUG - 2023-08-24 19:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:01:06 --> Controller Class Initialized
INFO - 2023-08-24 19:01:06 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:01:06 --> Model "Home_model" initialized
INFO - 2023-08-24 19:01:06 --> Helper loaded: download_helper
INFO - 2023-08-24 19:01:06 --> Helper loaded: form_helper
INFO - 2023-08-24 19:01:06 --> Form Validation Class Initialized
INFO - 2023-08-24 19:01:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 19:01:06 --> Final output sent to browser
DEBUG - 2023-08-24 19:01:06 --> Total execution time: 0.4705
INFO - 2023-08-24 19:01:09 --> Config Class Initialized
INFO - 2023-08-24 19:01:09 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:01:09 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:01:09 --> Utf8 Class Initialized
INFO - 2023-08-24 19:01:09 --> URI Class Initialized
INFO - 2023-08-24 19:01:09 --> Router Class Initialized
INFO - 2023-08-24 19:01:09 --> Output Class Initialized
INFO - 2023-08-24 19:01:09 --> Security Class Initialized
DEBUG - 2023-08-24 19:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:01:09 --> Input Class Initialized
INFO - 2023-08-24 19:01:09 --> Language Class Initialized
INFO - 2023-08-24 19:01:09 --> Loader Class Initialized
INFO - 2023-08-24 19:01:10 --> Config Class Initialized
INFO - 2023-08-24 19:01:10 --> Config Class Initialized
INFO - 2023-08-24 19:01:10 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:01:10 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:01:10 --> Hooks Class Initialized
INFO - 2023-08-24 19:01:10 --> Utf8 Class Initialized
INFO - 2023-08-24 19:01:10 --> Config Class Initialized
INFO - 2023-08-24 19:01:10 --> Hooks Class Initialized
INFO - 2023-08-24 19:01:10 --> URI Class Initialized
DEBUG - 2023-08-24 19:01:10 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:01:10 --> Utf8 Class Initialized
DEBUG - 2023-08-24 19:01:10 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:01:10 --> URI Class Initialized
INFO - 2023-08-24 19:01:10 --> Utf8 Class Initialized
INFO - 2023-08-24 19:01:10 --> Router Class Initialized
INFO - 2023-08-24 19:01:10 --> URI Class Initialized
INFO - 2023-08-24 19:01:10 --> Output Class Initialized
INFO - 2023-08-24 19:01:10 --> Security Class Initialized
INFO - 2023-08-24 19:01:10 --> Router Class Initialized
INFO - 2023-08-24 19:01:10 --> Router Class Initialized
DEBUG - 2023-08-24 19:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:01:10 --> Output Class Initialized
INFO - 2023-08-24 19:01:10 --> Input Class Initialized
INFO - 2023-08-24 19:01:10 --> Security Class Initialized
INFO - 2023-08-24 19:01:10 --> Output Class Initialized
INFO - 2023-08-24 19:01:10 --> Language Class Initialized
ERROR - 2023-08-24 19:01:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:01:10 --> Config Class Initialized
INFO - 2023-08-24 19:01:10 --> Security Class Initialized
DEBUG - 2023-08-24 19:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:01:10 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-24 19:01:11 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:01:11 --> Input Class Initialized
INFO - 2023-08-24 19:01:11 --> Language Class Initialized
INFO - 2023-08-24 19:01:11 --> Input Class Initialized
INFO - 2023-08-24 19:01:11 --> Language Class Initialized
ERROR - 2023-08-24 19:01:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:01:11 --> Utf8 Class Initialized
ERROR - 2023-08-24 19:01:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:01:11 --> URI Class Initialized
INFO - 2023-08-24 19:01:11 --> Router Class Initialized
INFO - 2023-08-24 19:01:11 --> Output Class Initialized
INFO - 2023-08-24 19:01:11 --> Security Class Initialized
DEBUG - 2023-08-24 19:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:01:11 --> Input Class Initialized
INFO - 2023-08-24 19:01:11 --> Language Class Initialized
ERROR - 2023-08-24 19:01:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:01:11 --> Config Class Initialized
INFO - 2023-08-24 19:01:11 --> Config Class Initialized
INFO - 2023-08-24 19:01:11 --> Hooks Class Initialized
INFO - 2023-08-24 19:01:11 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:01:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:01:11 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:01:11 --> Utf8 Class Initialized
INFO - 2023-08-24 19:01:11 --> URI Class Initialized
INFO - 2023-08-24 19:01:11 --> Utf8 Class Initialized
INFO - 2023-08-24 19:01:11 --> Router Class Initialized
INFO - 2023-08-24 19:01:11 --> URI Class Initialized
INFO - 2023-08-24 19:01:11 --> Router Class Initialized
INFO - 2023-08-24 19:01:11 --> Output Class Initialized
INFO - 2023-08-24 19:01:11 --> Output Class Initialized
INFO - 2023-08-24 19:01:11 --> Security Class Initialized
INFO - 2023-08-24 19:01:11 --> Security Class Initialized
DEBUG - 2023-08-24 19:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-24 19:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:01:11 --> Input Class Initialized
INFO - 2023-08-24 19:01:11 --> Input Class Initialized
INFO - 2023-08-24 19:01:11 --> Language Class Initialized
INFO - 2023-08-24 19:01:11 --> Language Class Initialized
ERROR - 2023-08-24 19:01:11 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-24 19:01:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:01:17 --> Config Class Initialized
INFO - 2023-08-24 19:01:18 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:01:18 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:01:18 --> Utf8 Class Initialized
INFO - 2023-08-24 19:01:18 --> URI Class Initialized
INFO - 2023-08-24 19:01:18 --> Router Class Initialized
INFO - 2023-08-24 19:01:18 --> Output Class Initialized
INFO - 2023-08-24 19:01:18 --> Security Class Initialized
DEBUG - 2023-08-24 19:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:01:18 --> Input Class Initialized
INFO - 2023-08-24 19:01:18 --> Language Class Initialized
INFO - 2023-08-24 19:01:18 --> Loader Class Initialized
INFO - 2023-08-24 19:01:18 --> Helper loaded: url_helper
INFO - 2023-08-24 19:01:18 --> Helper loaded: file_helper
INFO - 2023-08-24 19:01:18 --> Database Driver Class Initialized
INFO - 2023-08-24 19:01:18 --> Email Class Initialized
DEBUG - 2023-08-24 19:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:01:18 --> Controller Class Initialized
INFO - 2023-08-24 19:01:18 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:01:18 --> Model "Home_model" initialized
INFO - 2023-08-24 19:01:18 --> Helper loaded: download_helper
INFO - 2023-08-24 19:01:18 --> Helper loaded: form_helper
INFO - 2023-08-24 19:01:18 --> Form Validation Class Initialized
INFO - 2023-08-24 19:01:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 19:01:18 --> Final output sent to browser
DEBUG - 2023-08-24 19:01:18 --> Total execution time: 0.3909
INFO - 2023-08-24 19:01:19 --> Config Class Initialized
INFO - 2023-08-24 19:01:19 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:01:19 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:01:19 --> Utf8 Class Initialized
INFO - 2023-08-24 19:01:19 --> URI Class Initialized
INFO - 2023-08-24 19:01:19 --> Config Class Initialized
INFO - 2023-08-24 19:01:19 --> Hooks Class Initialized
INFO - 2023-08-24 19:01:19 --> Router Class Initialized
INFO - 2023-08-24 19:01:19 --> Config Class Initialized
INFO - 2023-08-24 19:01:19 --> Config Class Initialized
INFO - 2023-08-24 19:01:19 --> Output Class Initialized
DEBUG - 2023-08-24 19:01:19 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:01:19 --> Hooks Class Initialized
INFO - 2023-08-24 19:01:19 --> Security Class Initialized
DEBUG - 2023-08-24 19:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:01:19 --> Config Class Initialized
INFO - 2023-08-24 19:01:19 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:01:19 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:01:19 --> Utf8 Class Initialized
INFO - 2023-08-24 19:01:19 --> Input Class Initialized
INFO - 2023-08-24 19:01:19 --> Utf8 Class Initialized
INFO - 2023-08-24 19:01:19 --> Utf8 Class Initialized
INFO - 2023-08-24 19:01:19 --> Hooks Class Initialized
INFO - 2023-08-24 19:01:19 --> URI Class Initialized
INFO - 2023-08-24 19:01:19 --> URI Class Initialized
INFO - 2023-08-24 19:01:19 --> Language Class Initialized
INFO - 2023-08-24 19:01:19 --> URI Class Initialized
INFO - 2023-08-24 19:01:19 --> Router Class Initialized
DEBUG - 2023-08-24 19:01:19 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:01:19 --> Utf8 Class Initialized
INFO - 2023-08-24 19:01:19 --> Router Class Initialized
ERROR - 2023-08-24 19:01:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:01:19 --> Output Class Initialized
INFO - 2023-08-24 19:01:19 --> Router Class Initialized
INFO - 2023-08-24 19:01:19 --> Security Class Initialized
INFO - 2023-08-24 19:01:19 --> Output Class Initialized
DEBUG - 2023-08-24 19:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:01:19 --> URI Class Initialized
INFO - 2023-08-24 19:01:19 --> Security Class Initialized
INFO - 2023-08-24 19:01:19 --> Output Class Initialized
INFO - 2023-08-24 19:01:19 --> Input Class Initialized
DEBUG - 2023-08-24 19:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:01:19 --> Security Class Initialized
DEBUG - 2023-08-24 19:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:01:19 --> Language Class Initialized
INFO - 2023-08-24 19:01:19 --> Input Class Initialized
INFO - 2023-08-24 19:01:19 --> Router Class Initialized
INFO - 2023-08-24 19:01:19 --> Language Class Initialized
INFO - 2023-08-24 19:01:19 --> Input Class Initialized
ERROR - 2023-08-24 19:01:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:01:19 --> Language Class Initialized
ERROR - 2023-08-24 19:01:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:01:19 --> Output Class Initialized
ERROR - 2023-08-24 19:01:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:01:19 --> Security Class Initialized
DEBUG - 2023-08-24 19:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:01:20 --> Input Class Initialized
INFO - 2023-08-24 19:01:20 --> Language Class Initialized
ERROR - 2023-08-24 19:01:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:02:55 --> Config Class Initialized
INFO - 2023-08-24 19:02:55 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:02:55 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:02:55 --> Utf8 Class Initialized
INFO - 2023-08-24 19:02:55 --> URI Class Initialized
INFO - 2023-08-24 19:02:55 --> Router Class Initialized
INFO - 2023-08-24 19:02:55 --> Output Class Initialized
INFO - 2023-08-24 19:02:55 --> Security Class Initialized
DEBUG - 2023-08-24 19:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:02:55 --> Input Class Initialized
INFO - 2023-08-24 19:02:55 --> Language Class Initialized
INFO - 2023-08-24 19:02:55 --> Loader Class Initialized
INFO - 2023-08-24 19:02:55 --> Helper loaded: url_helper
INFO - 2023-08-24 19:02:55 --> Helper loaded: file_helper
INFO - 2023-08-24 19:02:55 --> Database Driver Class Initialized
INFO - 2023-08-24 19:02:55 --> Email Class Initialized
DEBUG - 2023-08-24 19:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:02:55 --> Controller Class Initialized
INFO - 2023-08-24 19:02:55 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:02:55 --> Model "Home_model" initialized
INFO - 2023-08-24 19:02:55 --> Helper loaded: download_helper
INFO - 2023-08-24 19:02:55 --> Helper loaded: form_helper
INFO - 2023-08-24 19:02:55 --> Form Validation Class Initialized
INFO - 2023-08-24 19:02:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:02:55 --> Final output sent to browser
DEBUG - 2023-08-24 19:02:55 --> Total execution time: 0.4121
INFO - 2023-08-24 19:02:59 --> Config Class Initialized
INFO - 2023-08-24 19:02:59 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:02:59 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:02:59 --> Utf8 Class Initialized
INFO - 2023-08-24 19:02:59 --> URI Class Initialized
INFO - 2023-08-24 19:02:59 --> Router Class Initialized
INFO - 2023-08-24 19:02:59 --> Output Class Initialized
INFO - 2023-08-24 19:02:59 --> Security Class Initialized
DEBUG - 2023-08-24 19:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:02:59 --> Input Class Initialized
INFO - 2023-08-24 19:02:59 --> Language Class Initialized
INFO - 2023-08-24 19:02:59 --> Loader Class Initialized
INFO - 2023-08-24 19:02:59 --> Helper loaded: url_helper
INFO - 2023-08-24 19:02:59 --> Helper loaded: file_helper
INFO - 2023-08-24 19:02:59 --> Database Driver Class Initialized
INFO - 2023-08-24 19:02:59 --> Email Class Initialized
DEBUG - 2023-08-24 19:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:02:59 --> Controller Class Initialized
INFO - 2023-08-24 19:02:59 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:02:59 --> Model "Home_model" initialized
INFO - 2023-08-24 19:02:59 --> Helper loaded: download_helper
INFO - 2023-08-24 19:02:59 --> Helper loaded: form_helper
INFO - 2023-08-24 19:02:59 --> Form Validation Class Initialized
INFO - 2023-08-24 19:02:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 19:02:59 --> Final output sent to browser
DEBUG - 2023-08-24 19:02:59 --> Total execution time: 0.4492
INFO - 2023-08-24 19:03:00 --> Config Class Initialized
INFO - 2023-08-24 19:03:00 --> Config Class Initialized
INFO - 2023-08-24 19:03:00 --> Hooks Class Initialized
INFO - 2023-08-24 19:03:00 --> Config Class Initialized
DEBUG - 2023-08-24 19:03:00 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:03:00 --> Utf8 Class Initialized
INFO - 2023-08-24 19:03:00 --> URI Class Initialized
INFO - 2023-08-24 19:03:00 --> Hooks Class Initialized
INFO - 2023-08-24 19:03:00 --> Router Class Initialized
DEBUG - 2023-08-24 19:03:00 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:03:00 --> Config Class Initialized
INFO - 2023-08-24 19:03:00 --> Config Class Initialized
INFO - 2023-08-24 19:03:00 --> Output Class Initialized
INFO - 2023-08-24 19:03:00 --> Hooks Class Initialized
INFO - 2023-08-24 19:03:00 --> Hooks Class Initialized
INFO - 2023-08-24 19:03:00 --> Hooks Class Initialized
INFO - 2023-08-24 19:03:00 --> Utf8 Class Initialized
INFO - 2023-08-24 19:03:00 --> Security Class Initialized
INFO - 2023-08-24 19:03:01 --> URI Class Initialized
DEBUG - 2023-08-24 19:03:01 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:03:01 --> Utf8 Class Initialized
INFO - 2023-08-24 19:03:01 --> Router Class Initialized
DEBUG - 2023-08-24 19:03:01 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:03:01 --> Utf8 Class Initialized
DEBUG - 2023-08-24 19:03:01 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:03:01 --> URI Class Initialized
DEBUG - 2023-08-24 19:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:03:01 --> Output Class Initialized
INFO - 2023-08-24 19:03:01 --> URI Class Initialized
INFO - 2023-08-24 19:03:01 --> Router Class Initialized
INFO - 2023-08-24 19:03:01 --> Utf8 Class Initialized
INFO - 2023-08-24 19:03:01 --> Router Class Initialized
INFO - 2023-08-24 19:03:01 --> Input Class Initialized
INFO - 2023-08-24 19:03:01 --> URI Class Initialized
INFO - 2023-08-24 19:03:01 --> Output Class Initialized
INFO - 2023-08-24 19:03:01 --> Language Class Initialized
INFO - 2023-08-24 19:03:01 --> Security Class Initialized
INFO - 2023-08-24 19:03:01 --> Security Class Initialized
DEBUG - 2023-08-24 19:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:03:01 --> Output Class Initialized
INFO - 2023-08-24 19:03:01 --> Router Class Initialized
INFO - 2023-08-24 19:03:01 --> Output Class Initialized
ERROR - 2023-08-24 19:03:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:03:01 --> Security Class Initialized
DEBUG - 2023-08-24 19:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:03:01 --> Security Class Initialized
DEBUG - 2023-08-24 19:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:03:01 --> Input Class Initialized
DEBUG - 2023-08-24 19:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:03:01 --> Input Class Initialized
INFO - 2023-08-24 19:03:01 --> Input Class Initialized
INFO - 2023-08-24 19:03:01 --> Language Class Initialized
INFO - 2023-08-24 19:03:01 --> Input Class Initialized
INFO - 2023-08-24 19:03:01 --> Language Class Initialized
INFO - 2023-08-24 19:03:01 --> Language Class Initialized
ERROR - 2023-08-24 19:03:01 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-24 19:03:01 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-24 19:03:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:03:01 --> Language Class Initialized
ERROR - 2023-08-24 19:03:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:04:27 --> Config Class Initialized
INFO - 2023-08-24 19:04:27 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:04:27 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:04:27 --> Utf8 Class Initialized
INFO - 2023-08-24 19:04:27 --> URI Class Initialized
INFO - 2023-08-24 19:04:27 --> Router Class Initialized
INFO - 2023-08-24 19:04:27 --> Output Class Initialized
INFO - 2023-08-24 19:04:27 --> Security Class Initialized
DEBUG - 2023-08-24 19:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:04:27 --> Input Class Initialized
INFO - 2023-08-24 19:04:27 --> Language Class Initialized
INFO - 2023-08-24 19:04:27 --> Loader Class Initialized
INFO - 2023-08-24 19:04:27 --> Helper loaded: url_helper
INFO - 2023-08-24 19:04:27 --> Helper loaded: file_helper
INFO - 2023-08-24 19:04:27 --> Database Driver Class Initialized
INFO - 2023-08-24 19:04:27 --> Email Class Initialized
DEBUG - 2023-08-24 19:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:04:27 --> Controller Class Initialized
INFO - 2023-08-24 19:04:27 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:04:27 --> Model "Home_model" initialized
INFO - 2023-08-24 19:04:27 --> Helper loaded: download_helper
INFO - 2023-08-24 19:04:27 --> Helper loaded: form_helper
INFO - 2023-08-24 19:04:27 --> Form Validation Class Initialized
INFO - 2023-08-24 19:04:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 19:04:28 --> Final output sent to browser
DEBUG - 2023-08-24 19:04:28 --> Total execution time: 0.5569
INFO - 2023-08-24 19:04:28 --> Config Class Initialized
INFO - 2023-08-24 19:04:28 --> Hooks Class Initialized
INFO - 2023-08-24 19:04:28 --> Config Class Initialized
DEBUG - 2023-08-24 19:04:28 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:04:28 --> Config Class Initialized
INFO - 2023-08-24 19:04:29 --> Utf8 Class Initialized
INFO - 2023-08-24 19:04:29 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:04:29 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:04:29 --> Config Class Initialized
INFO - 2023-08-24 19:04:29 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:04:29 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:04:29 --> Utf8 Class Initialized
INFO - 2023-08-24 19:04:29 --> URI Class Initialized
INFO - 2023-08-24 19:04:29 --> Router Class Initialized
INFO - 2023-08-24 19:04:29 --> Output Class Initialized
INFO - 2023-08-24 19:04:29 --> Security Class Initialized
DEBUG - 2023-08-24 19:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:04:29 --> Input Class Initialized
INFO - 2023-08-24 19:04:29 --> Language Class Initialized
ERROR - 2023-08-24 19:04:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:04:29 --> Utf8 Class Initialized
INFO - 2023-08-24 19:04:29 --> URI Class Initialized
INFO - 2023-08-24 19:04:29 --> Config Class Initialized
INFO - 2023-08-24 19:04:29 --> Router Class Initialized
INFO - 2023-08-24 19:04:29 --> Hooks Class Initialized
INFO - 2023-08-24 19:04:29 --> URI Class Initialized
INFO - 2023-08-24 19:04:29 --> Hooks Class Initialized
INFO - 2023-08-24 19:04:29 --> Router Class Initialized
INFO - 2023-08-24 19:04:29 --> Output Class Initialized
DEBUG - 2023-08-24 19:04:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:04:29 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:04:29 --> Utf8 Class Initialized
INFO - 2023-08-24 19:04:29 --> Utf8 Class Initialized
INFO - 2023-08-24 19:04:29 --> Output Class Initialized
INFO - 2023-08-24 19:04:29 --> Security Class Initialized
INFO - 2023-08-24 19:04:29 --> Security Class Initialized
DEBUG - 2023-08-24 19:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:04:29 --> URI Class Initialized
DEBUG - 2023-08-24 19:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:04:29 --> Input Class Initialized
INFO - 2023-08-24 19:04:29 --> Language Class Initialized
ERROR - 2023-08-24 19:04:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:04:29 --> Router Class Initialized
INFO - 2023-08-24 19:04:29 --> URI Class Initialized
INFO - 2023-08-24 19:04:29 --> Input Class Initialized
INFO - 2023-08-24 19:04:29 --> Output Class Initialized
INFO - 2023-08-24 19:04:29 --> Language Class Initialized
ERROR - 2023-08-24 19:04:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:04:29 --> Router Class Initialized
INFO - 2023-08-24 19:04:29 --> Security Class Initialized
INFO - 2023-08-24 19:04:29 --> Output Class Initialized
DEBUG - 2023-08-24 19:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:04:29 --> Input Class Initialized
INFO - 2023-08-24 19:04:29 --> Security Class Initialized
INFO - 2023-08-24 19:04:29 --> Language Class Initialized
DEBUG - 2023-08-24 19:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-24 19:04:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:04:29 --> Input Class Initialized
INFO - 2023-08-24 19:04:29 --> Language Class Initialized
ERROR - 2023-08-24 19:04:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:04:47 --> Config Class Initialized
INFO - 2023-08-24 19:04:47 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:04:47 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:04:47 --> Utf8 Class Initialized
INFO - 2023-08-24 19:04:47 --> URI Class Initialized
INFO - 2023-08-24 19:04:47 --> Router Class Initialized
INFO - 2023-08-24 19:04:47 --> Output Class Initialized
INFO - 2023-08-24 19:04:47 --> Security Class Initialized
DEBUG - 2023-08-24 19:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:04:47 --> Input Class Initialized
INFO - 2023-08-24 19:04:47 --> Language Class Initialized
INFO - 2023-08-24 19:04:47 --> Loader Class Initialized
INFO - 2023-08-24 19:04:47 --> Helper loaded: url_helper
INFO - 2023-08-24 19:04:47 --> Helper loaded: file_helper
INFO - 2023-08-24 19:04:47 --> Database Driver Class Initialized
INFO - 2023-08-24 19:04:47 --> Email Class Initialized
DEBUG - 2023-08-24 19:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:04:47 --> Controller Class Initialized
INFO - 2023-08-24 19:04:47 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:04:47 --> Model "Home_model" initialized
INFO - 2023-08-24 19:04:47 --> Helper loaded: download_helper
INFO - 2023-08-24 19:04:47 --> Helper loaded: form_helper
INFO - 2023-08-24 19:04:47 --> Form Validation Class Initialized
INFO - 2023-08-24 19:04:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 19:04:47 --> Final output sent to browser
DEBUG - 2023-08-24 19:04:47 --> Total execution time: 0.4725
INFO - 2023-08-24 19:04:48 --> Config Class Initialized
INFO - 2023-08-24 19:04:48 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:04:48 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:04:48 --> Utf8 Class Initialized
INFO - 2023-08-24 19:04:48 --> URI Class Initialized
INFO - 2023-08-24 19:04:48 --> Router Class Initialized
INFO - 2023-08-24 19:04:48 --> Output Class Initialized
INFO - 2023-08-24 19:04:49 --> Security Class Initialized
DEBUG - 2023-08-24 19:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:04:49 --> Input Class Initialized
INFO - 2023-08-24 19:04:49 --> Language Class Initialized
ERROR - 2023-08-24 19:04:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:04:49 --> Config Class Initialized
INFO - 2023-08-24 19:04:49 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:04:49 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:04:49 --> Utf8 Class Initialized
INFO - 2023-08-24 19:04:49 --> URI Class Initialized
INFO - 2023-08-24 19:04:49 --> Router Class Initialized
INFO - 2023-08-24 19:04:49 --> Output Class Initialized
INFO - 2023-08-24 19:04:49 --> Security Class Initialized
DEBUG - 2023-08-24 19:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:04:49 --> Input Class Initialized
INFO - 2023-08-24 19:04:49 --> Language Class Initialized
ERROR - 2023-08-24 19:04:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:04:49 --> Config Class Initialized
INFO - 2023-08-24 19:04:49 --> Config Class Initialized
INFO - 2023-08-24 19:04:49 --> Hooks Class Initialized
INFO - 2023-08-24 19:04:49 --> Config Class Initialized
DEBUG - 2023-08-24 19:04:49 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:04:49 --> Utf8 Class Initialized
INFO - 2023-08-24 19:04:49 --> Hooks Class Initialized
INFO - 2023-08-24 19:04:49 --> Hooks Class Initialized
INFO - 2023-08-24 19:04:49 --> URI Class Initialized
DEBUG - 2023-08-24 19:04:49 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:04:49 --> Router Class Initialized
INFO - 2023-08-24 19:04:49 --> Utf8 Class Initialized
DEBUG - 2023-08-24 19:04:49 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:04:49 --> Utf8 Class Initialized
INFO - 2023-08-24 19:04:49 --> Output Class Initialized
INFO - 2023-08-24 19:04:49 --> URI Class Initialized
INFO - 2023-08-24 19:04:49 --> URI Class Initialized
INFO - 2023-08-24 19:04:49 --> Security Class Initialized
INFO - 2023-08-24 19:04:49 --> Router Class Initialized
DEBUG - 2023-08-24 19:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:04:49 --> Input Class Initialized
INFO - 2023-08-24 19:04:49 --> Output Class Initialized
INFO - 2023-08-24 19:04:49 --> Router Class Initialized
INFO - 2023-08-24 19:04:49 --> Security Class Initialized
INFO - 2023-08-24 19:04:49 --> Output Class Initialized
INFO - 2023-08-24 19:04:49 --> Security Class Initialized
DEBUG - 2023-08-24 19:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:04:49 --> Language Class Initialized
ERROR - 2023-08-24 19:04:49 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-24 19:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:04:49 --> Input Class Initialized
INFO - 2023-08-24 19:04:49 --> Input Class Initialized
INFO - 2023-08-24 19:04:49 --> Language Class Initialized
INFO - 2023-08-24 19:04:49 --> Language Class Initialized
ERROR - 2023-08-24 19:04:49 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-24 19:04:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:06:27 --> Config Class Initialized
INFO - 2023-08-24 19:06:27 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:06:27 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:06:27 --> Utf8 Class Initialized
INFO - 2023-08-24 19:06:27 --> URI Class Initialized
INFO - 2023-08-24 19:06:27 --> Router Class Initialized
INFO - 2023-08-24 19:06:28 --> Output Class Initialized
INFO - 2023-08-24 19:06:28 --> Security Class Initialized
DEBUG - 2023-08-24 19:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:06:28 --> Input Class Initialized
INFO - 2023-08-24 19:06:28 --> Language Class Initialized
INFO - 2023-08-24 19:06:28 --> Loader Class Initialized
INFO - 2023-08-24 19:06:28 --> Helper loaded: url_helper
INFO - 2023-08-24 19:06:28 --> Helper loaded: file_helper
INFO - 2023-08-24 19:06:28 --> Database Driver Class Initialized
INFO - 2023-08-24 19:06:28 --> Email Class Initialized
DEBUG - 2023-08-24 19:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:06:28 --> Controller Class Initialized
INFO - 2023-08-24 19:06:28 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:06:28 --> Model "Home_model" initialized
INFO - 2023-08-24 19:06:28 --> Helper loaded: download_helper
INFO - 2023-08-24 19:06:28 --> Helper loaded: form_helper
INFO - 2023-08-24 19:06:28 --> Form Validation Class Initialized
ERROR - 2023-08-24 19:06:28 --> Severity: error --> Exception: syntax error, unexpected token "class" C:\xampp\htdocs\dw\application\views\home\training_detail.php 74
INFO - 2023-08-24 19:07:37 --> Config Class Initialized
INFO - 2023-08-24 19:07:37 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:07:37 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:07:37 --> Utf8 Class Initialized
INFO - 2023-08-24 19:07:37 --> URI Class Initialized
INFO - 2023-08-24 19:07:37 --> Router Class Initialized
INFO - 2023-08-24 19:07:37 --> Output Class Initialized
INFO - 2023-08-24 19:07:37 --> Security Class Initialized
DEBUG - 2023-08-24 19:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:07:37 --> Input Class Initialized
INFO - 2023-08-24 19:07:37 --> Language Class Initialized
INFO - 2023-08-24 19:07:37 --> Loader Class Initialized
INFO - 2023-08-24 19:07:37 --> Helper loaded: url_helper
INFO - 2023-08-24 19:07:37 --> Helper loaded: file_helper
INFO - 2023-08-24 19:07:37 --> Database Driver Class Initialized
INFO - 2023-08-24 19:07:37 --> Email Class Initialized
DEBUG - 2023-08-24 19:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:07:37 --> Controller Class Initialized
INFO - 2023-08-24 19:07:37 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:07:37 --> Model "Home_model" initialized
INFO - 2023-08-24 19:07:37 --> Helper loaded: download_helper
INFO - 2023-08-24 19:07:37 --> Helper loaded: form_helper
INFO - 2023-08-24 19:07:37 --> Form Validation Class Initialized
ERROR - 2023-08-24 19:07:37 --> Severity: error --> Exception: syntax error, unexpected token "echo" C:\xampp\htdocs\dw\application\views\home\training_detail.php 74
INFO - 2023-08-24 19:07:40 --> Config Class Initialized
INFO - 2023-08-24 19:07:40 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:07:40 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:07:40 --> Utf8 Class Initialized
INFO - 2023-08-24 19:07:40 --> URI Class Initialized
INFO - 2023-08-24 19:07:40 --> Router Class Initialized
INFO - 2023-08-24 19:07:40 --> Output Class Initialized
INFO - 2023-08-24 19:07:40 --> Security Class Initialized
DEBUG - 2023-08-24 19:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:07:40 --> Input Class Initialized
INFO - 2023-08-24 19:07:40 --> Language Class Initialized
INFO - 2023-08-24 19:07:40 --> Loader Class Initialized
INFO - 2023-08-24 19:07:40 --> Helper loaded: url_helper
INFO - 2023-08-24 19:07:40 --> Helper loaded: file_helper
INFO - 2023-08-24 19:07:40 --> Database Driver Class Initialized
INFO - 2023-08-24 19:07:40 --> Email Class Initialized
DEBUG - 2023-08-24 19:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:07:40 --> Controller Class Initialized
INFO - 2023-08-24 19:07:40 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:07:40 --> Model "Home_model" initialized
INFO - 2023-08-24 19:07:40 --> Helper loaded: download_helper
INFO - 2023-08-24 19:07:40 --> Helper loaded: form_helper
INFO - 2023-08-24 19:07:40 --> Form Validation Class Initialized
ERROR - 2023-08-24 19:07:40 --> Severity: error --> Exception: syntax error, unexpected token "echo" C:\xampp\htdocs\dw\application\views\home\training_detail.php 74
INFO - 2023-08-24 19:08:39 --> Config Class Initialized
INFO - 2023-08-24 19:08:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:08:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:08:39 --> Utf8 Class Initialized
INFO - 2023-08-24 19:08:39 --> URI Class Initialized
INFO - 2023-08-24 19:08:39 --> Router Class Initialized
INFO - 2023-08-24 19:08:39 --> Output Class Initialized
INFO - 2023-08-24 19:08:39 --> Security Class Initialized
DEBUG - 2023-08-24 19:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:08:39 --> Input Class Initialized
INFO - 2023-08-24 19:08:39 --> Language Class Initialized
INFO - 2023-08-24 19:08:39 --> Loader Class Initialized
INFO - 2023-08-24 19:08:39 --> Helper loaded: url_helper
INFO - 2023-08-24 19:08:39 --> Helper loaded: file_helper
INFO - 2023-08-24 19:08:39 --> Database Driver Class Initialized
INFO - 2023-08-24 19:08:39 --> Email Class Initialized
DEBUG - 2023-08-24 19:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:08:40 --> Controller Class Initialized
INFO - 2023-08-24 19:08:40 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:08:40 --> Model "Home_model" initialized
INFO - 2023-08-24 19:08:40 --> Helper loaded: download_helper
INFO - 2023-08-24 19:08:40 --> Helper loaded: form_helper
INFO - 2023-08-24 19:08:40 --> Form Validation Class Initialized
INFO - 2023-08-24 19:08:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 19:08:40 --> Final output sent to browser
DEBUG - 2023-08-24 19:08:40 --> Total execution time: 0.4309
INFO - 2023-08-24 19:08:40 --> Config Class Initialized
INFO - 2023-08-24 19:08:40 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:08:40 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:08:40 --> Utf8 Class Initialized
INFO - 2023-08-24 19:08:40 --> URI Class Initialized
INFO - 2023-08-24 19:08:40 --> Router Class Initialized
INFO - 2023-08-24 19:08:40 --> Output Class Initialized
INFO - 2023-08-24 19:08:40 --> Security Class Initialized
DEBUG - 2023-08-24 19:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:08:40 --> Input Class Initialized
INFO - 2023-08-24 19:08:40 --> Language Class Initialized
ERROR - 2023-08-24 19:08:40 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:08:40 --> Config Class Initialized
INFO - 2023-08-24 19:08:40 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:08:40 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:08:40 --> Utf8 Class Initialized
INFO - 2023-08-24 19:08:40 --> URI Class Initialized
INFO - 2023-08-24 19:08:40 --> Router Class Initialized
INFO - 2023-08-24 19:08:40 --> Output Class Initialized
INFO - 2023-08-24 19:08:40 --> Security Class Initialized
DEBUG - 2023-08-24 19:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:08:40 --> Input Class Initialized
INFO - 2023-08-24 19:08:40 --> Language Class Initialized
ERROR - 2023-08-24 19:08:40 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:08:40 --> Config Class Initialized
INFO - 2023-08-24 19:08:40 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:08:40 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:08:40 --> Utf8 Class Initialized
INFO - 2023-08-24 19:08:40 --> URI Class Initialized
INFO - 2023-08-24 19:08:40 --> Router Class Initialized
INFO - 2023-08-24 19:08:40 --> Output Class Initialized
INFO - 2023-08-24 19:08:40 --> Security Class Initialized
DEBUG - 2023-08-24 19:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:08:40 --> Input Class Initialized
INFO - 2023-08-24 19:08:40 --> Language Class Initialized
ERROR - 2023-08-24 19:08:40 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:08:40 --> Config Class Initialized
INFO - 2023-08-24 19:08:40 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:08:40 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:08:40 --> Utf8 Class Initialized
INFO - 2023-08-24 19:08:40 --> URI Class Initialized
INFO - 2023-08-24 19:08:40 --> Router Class Initialized
INFO - 2023-08-24 19:08:40 --> Output Class Initialized
INFO - 2023-08-24 19:08:40 --> Security Class Initialized
DEBUG - 2023-08-24 19:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:08:40 --> Input Class Initialized
INFO - 2023-08-24 19:08:40 --> Language Class Initialized
ERROR - 2023-08-24 19:08:40 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:08:41 --> Config Class Initialized
INFO - 2023-08-24 19:08:41 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:08:41 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:08:41 --> Utf8 Class Initialized
INFO - 2023-08-24 19:08:41 --> URI Class Initialized
INFO - 2023-08-24 19:08:41 --> Router Class Initialized
INFO - 2023-08-24 19:08:41 --> Output Class Initialized
INFO - 2023-08-24 19:08:41 --> Security Class Initialized
DEBUG - 2023-08-24 19:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:08:41 --> Input Class Initialized
INFO - 2023-08-24 19:08:41 --> Language Class Initialized
ERROR - 2023-08-24 19:08:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:08:41 --> Config Class Initialized
INFO - 2023-08-24 19:08:41 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:08:41 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:08:41 --> Utf8 Class Initialized
INFO - 2023-08-24 19:08:41 --> URI Class Initialized
INFO - 2023-08-24 19:08:41 --> Router Class Initialized
INFO - 2023-08-24 19:08:41 --> Output Class Initialized
INFO - 2023-08-24 19:08:41 --> Security Class Initialized
DEBUG - 2023-08-24 19:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:08:41 --> Input Class Initialized
INFO - 2023-08-24 19:08:41 --> Language Class Initialized
ERROR - 2023-08-24 19:08:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:08:41 --> Config Class Initialized
INFO - 2023-08-24 19:08:41 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:08:41 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:08:41 --> Utf8 Class Initialized
INFO - 2023-08-24 19:08:41 --> URI Class Initialized
INFO - 2023-08-24 19:08:41 --> Router Class Initialized
INFO - 2023-08-24 19:08:41 --> Output Class Initialized
INFO - 2023-08-24 19:08:41 --> Security Class Initialized
DEBUG - 2023-08-24 19:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:08:41 --> Input Class Initialized
INFO - 2023-08-24 19:08:41 --> Language Class Initialized
ERROR - 2023-08-24 19:08:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:08:46 --> Config Class Initialized
INFO - 2023-08-24 19:08:46 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:08:46 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:08:46 --> Utf8 Class Initialized
INFO - 2023-08-24 19:08:46 --> URI Class Initialized
INFO - 2023-08-24 19:08:46 --> Router Class Initialized
INFO - 2023-08-24 19:08:46 --> Output Class Initialized
INFO - 2023-08-24 19:08:46 --> Security Class Initialized
DEBUG - 2023-08-24 19:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:08:46 --> Input Class Initialized
INFO - 2023-08-24 19:08:46 --> Language Class Initialized
ERROR - 2023-08-24 19:08:46 --> 404 Page Not Found: Training-detail/mobile-applications.html
INFO - 2023-08-24 19:08:49 --> Config Class Initialized
INFO - 2023-08-24 19:08:49 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:08:49 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:08:49 --> Utf8 Class Initialized
INFO - 2023-08-24 19:08:49 --> URI Class Initialized
INFO - 2023-08-24 19:08:49 --> Router Class Initialized
INFO - 2023-08-24 19:08:49 --> Output Class Initialized
INFO - 2023-08-24 19:08:49 --> Security Class Initialized
DEBUG - 2023-08-24 19:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:08:49 --> Input Class Initialized
INFO - 2023-08-24 19:08:49 --> Language Class Initialized
INFO - 2023-08-24 19:08:49 --> Loader Class Initialized
INFO - 2023-08-24 19:08:49 --> Helper loaded: url_helper
INFO - 2023-08-24 19:08:49 --> Helper loaded: file_helper
INFO - 2023-08-24 19:08:49 --> Database Driver Class Initialized
INFO - 2023-08-24 19:08:49 --> Email Class Initialized
DEBUG - 2023-08-24 19:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:08:49 --> Controller Class Initialized
INFO - 2023-08-24 19:08:49 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:08:49 --> Model "Home_model" initialized
INFO - 2023-08-24 19:08:49 --> Helper loaded: download_helper
INFO - 2023-08-24 19:08:49 --> Helper loaded: form_helper
INFO - 2023-08-24 19:08:49 --> Form Validation Class Initialized
INFO - 2023-08-24 19:08:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 19:08:49 --> Final output sent to browser
DEBUG - 2023-08-24 19:08:49 --> Total execution time: 0.0477
INFO - 2023-08-24 19:09:22 --> Config Class Initialized
INFO - 2023-08-24 19:09:22 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:22 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:22 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:22 --> URI Class Initialized
INFO - 2023-08-24 19:09:22 --> Router Class Initialized
INFO - 2023-08-24 19:09:22 --> Output Class Initialized
INFO - 2023-08-24 19:09:22 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:22 --> Input Class Initialized
INFO - 2023-08-24 19:09:22 --> Language Class Initialized
INFO - 2023-08-24 19:09:22 --> Loader Class Initialized
INFO - 2023-08-24 19:09:22 --> Helper loaded: url_helper
INFO - 2023-08-24 19:09:22 --> Helper loaded: file_helper
INFO - 2023-08-24 19:09:22 --> Database Driver Class Initialized
INFO - 2023-08-24 19:09:22 --> Email Class Initialized
DEBUG - 2023-08-24 19:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:09:22 --> Controller Class Initialized
INFO - 2023-08-24 19:09:22 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:09:22 --> Model "Home_model" initialized
INFO - 2023-08-24 19:09:22 --> Helper loaded: download_helper
INFO - 2023-08-24 19:09:22 --> Helper loaded: form_helper
INFO - 2023-08-24 19:09:22 --> Form Validation Class Initialized
INFO - 2023-08-24 19:09:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 19:09:22 --> Final output sent to browser
DEBUG - 2023-08-24 19:09:22 --> Total execution time: 0.1634
INFO - 2023-08-24 19:09:22 --> Config Class Initialized
INFO - 2023-08-24 19:09:22 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:22 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:22 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:22 --> URI Class Initialized
INFO - 2023-08-24 19:09:22 --> Router Class Initialized
INFO - 2023-08-24 19:09:22 --> Output Class Initialized
INFO - 2023-08-24 19:09:22 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:22 --> Input Class Initialized
INFO - 2023-08-24 19:09:22 --> Language Class Initialized
ERROR - 2023-08-24 19:09:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:09:22 --> Config Class Initialized
INFO - 2023-08-24 19:09:22 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:22 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:22 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:22 --> URI Class Initialized
INFO - 2023-08-24 19:09:22 --> Router Class Initialized
INFO - 2023-08-24 19:09:22 --> Output Class Initialized
INFO - 2023-08-24 19:09:22 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:22 --> Input Class Initialized
INFO - 2023-08-24 19:09:22 --> Language Class Initialized
ERROR - 2023-08-24 19:09:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:09:22 --> Config Class Initialized
INFO - 2023-08-24 19:09:22 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:22 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:22 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:22 --> URI Class Initialized
INFO - 2023-08-24 19:09:22 --> Router Class Initialized
INFO - 2023-08-24 19:09:22 --> Output Class Initialized
INFO - 2023-08-24 19:09:22 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:22 --> Input Class Initialized
INFO - 2023-08-24 19:09:22 --> Language Class Initialized
ERROR - 2023-08-24 19:09:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:09:22 --> Config Class Initialized
INFO - 2023-08-24 19:09:22 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:23 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:23 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:23 --> URI Class Initialized
INFO - 2023-08-24 19:09:23 --> Router Class Initialized
INFO - 2023-08-24 19:09:23 --> Output Class Initialized
INFO - 2023-08-24 19:09:23 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:23 --> Input Class Initialized
INFO - 2023-08-24 19:09:23 --> Language Class Initialized
ERROR - 2023-08-24 19:09:23 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:09:23 --> Config Class Initialized
INFO - 2023-08-24 19:09:23 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:23 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:23 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:23 --> URI Class Initialized
INFO - 2023-08-24 19:09:23 --> Router Class Initialized
INFO - 2023-08-24 19:09:23 --> Output Class Initialized
INFO - 2023-08-24 19:09:23 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:23 --> Input Class Initialized
INFO - 2023-08-24 19:09:23 --> Language Class Initialized
ERROR - 2023-08-24 19:09:23 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:09:23 --> Config Class Initialized
INFO - 2023-08-24 19:09:23 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:23 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:23 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:23 --> URI Class Initialized
INFO - 2023-08-24 19:09:23 --> Router Class Initialized
INFO - 2023-08-24 19:09:23 --> Output Class Initialized
INFO - 2023-08-24 19:09:23 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:23 --> Input Class Initialized
INFO - 2023-08-24 19:09:23 --> Language Class Initialized
ERROR - 2023-08-24 19:09:23 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:09:25 --> Config Class Initialized
INFO - 2023-08-24 19:09:25 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:25 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:25 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:25 --> URI Class Initialized
INFO - 2023-08-24 19:09:25 --> Router Class Initialized
INFO - 2023-08-24 19:09:25 --> Output Class Initialized
INFO - 2023-08-24 19:09:25 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:25 --> Input Class Initialized
INFO - 2023-08-24 19:09:25 --> Language Class Initialized
INFO - 2023-08-24 19:09:25 --> Loader Class Initialized
INFO - 2023-08-24 19:09:25 --> Helper loaded: url_helper
INFO - 2023-08-24 19:09:25 --> Helper loaded: file_helper
INFO - 2023-08-24 19:09:25 --> Database Driver Class Initialized
INFO - 2023-08-24 19:09:25 --> Email Class Initialized
DEBUG - 2023-08-24 19:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:09:25 --> Controller Class Initialized
INFO - 2023-08-24 19:09:25 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:09:25 --> Model "Home_model" initialized
INFO - 2023-08-24 19:09:25 --> Helper loaded: download_helper
INFO - 2023-08-24 19:09:25 --> Helper loaded: form_helper
INFO - 2023-08-24 19:09:25 --> Form Validation Class Initialized
INFO - 2023-08-24 19:09:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 19:09:25 --> Final output sent to browser
DEBUG - 2023-08-24 19:09:25 --> Total execution time: 0.0519
INFO - 2023-08-24 19:09:26 --> Config Class Initialized
INFO - 2023-08-24 19:09:26 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:26 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:26 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:26 --> URI Class Initialized
INFO - 2023-08-24 19:09:26 --> Router Class Initialized
INFO - 2023-08-24 19:09:26 --> Output Class Initialized
INFO - 2023-08-24 19:09:26 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:26 --> Input Class Initialized
INFO - 2023-08-24 19:09:26 --> Language Class Initialized
ERROR - 2023-08-24 19:09:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:09:26 --> Config Class Initialized
INFO - 2023-08-24 19:09:26 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:26 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:26 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:26 --> URI Class Initialized
INFO - 2023-08-24 19:09:26 --> Router Class Initialized
INFO - 2023-08-24 19:09:26 --> Output Class Initialized
INFO - 2023-08-24 19:09:26 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:26 --> Input Class Initialized
INFO - 2023-08-24 19:09:26 --> Language Class Initialized
ERROR - 2023-08-24 19:09:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:09:26 --> Config Class Initialized
INFO - 2023-08-24 19:09:26 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:26 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:26 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:26 --> URI Class Initialized
INFO - 2023-08-24 19:09:26 --> Router Class Initialized
INFO - 2023-08-24 19:09:26 --> Output Class Initialized
INFO - 2023-08-24 19:09:26 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:26 --> Input Class Initialized
INFO - 2023-08-24 19:09:26 --> Language Class Initialized
ERROR - 2023-08-24 19:09:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:09:26 --> Config Class Initialized
INFO - 2023-08-24 19:09:26 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:26 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:26 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:26 --> URI Class Initialized
INFO - 2023-08-24 19:09:26 --> Router Class Initialized
INFO - 2023-08-24 19:09:26 --> Output Class Initialized
INFO - 2023-08-24 19:09:26 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:26 --> Input Class Initialized
INFO - 2023-08-24 19:09:26 --> Language Class Initialized
ERROR - 2023-08-24 19:09:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:09:26 --> Config Class Initialized
INFO - 2023-08-24 19:09:26 --> Config Class Initialized
INFO - 2023-08-24 19:09:26 --> Config Class Initialized
INFO - 2023-08-24 19:09:26 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:26 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:26 --> Hooks Class Initialized
INFO - 2023-08-24 19:09:26 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:26 --> Hooks Class Initialized
INFO - 2023-08-24 19:09:26 --> Config Class Initialized
INFO - 2023-08-24 19:09:26 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:09:26 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:26 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:26 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:26 --> URI Class Initialized
INFO - 2023-08-24 19:09:26 --> URI Class Initialized
INFO - 2023-08-24 19:09:26 --> URI Class Initialized
INFO - 2023-08-24 19:09:26 --> Router Class Initialized
DEBUG - 2023-08-24 19:09:27 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:27 --> Router Class Initialized
INFO - 2023-08-24 19:09:27 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:27 --> Output Class Initialized
INFO - 2023-08-24 19:09:27 --> Router Class Initialized
INFO - 2023-08-24 19:09:27 --> Output Class Initialized
INFO - 2023-08-24 19:09:27 --> Security Class Initialized
INFO - 2023-08-24 19:09:27 --> Security Class Initialized
INFO - 2023-08-24 19:09:27 --> URI Class Initialized
INFO - 2023-08-24 19:09:27 --> Output Class Initialized
INFO - 2023-08-24 19:09:27 --> Router Class Initialized
DEBUG - 2023-08-24 19:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-24 19:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:27 --> Security Class Initialized
INFO - 2023-08-24 19:09:27 --> Input Class Initialized
INFO - 2023-08-24 19:09:27 --> Input Class Initialized
INFO - 2023-08-24 19:09:27 --> Language Class Initialized
INFO - 2023-08-24 19:09:27 --> Output Class Initialized
ERROR - 2023-08-24 19:09:27 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-24 19:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:27 --> Language Class Initialized
ERROR - 2023-08-24 19:09:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:09:27 --> Input Class Initialized
INFO - 2023-08-24 19:09:27 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:27 --> Input Class Initialized
INFO - 2023-08-24 19:09:27 --> Language Class Initialized
INFO - 2023-08-24 19:09:27 --> Language Class Initialized
ERROR - 2023-08-24 19:09:27 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-24 19:09:27 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:09:33 --> Config Class Initialized
INFO - 2023-08-24 19:09:33 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:33 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:33 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:33 --> URI Class Initialized
INFO - 2023-08-24 19:09:33 --> Router Class Initialized
INFO - 2023-08-24 19:09:33 --> Output Class Initialized
INFO - 2023-08-24 19:09:33 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:33 --> Input Class Initialized
INFO - 2023-08-24 19:09:33 --> Language Class Initialized
INFO - 2023-08-24 19:09:33 --> Loader Class Initialized
INFO - 2023-08-24 19:09:33 --> Helper loaded: url_helper
INFO - 2023-08-24 19:09:33 --> Helper loaded: file_helper
INFO - 2023-08-24 19:09:33 --> Database Driver Class Initialized
INFO - 2023-08-24 19:09:33 --> Email Class Initialized
DEBUG - 2023-08-24 19:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:09:33 --> Controller Class Initialized
INFO - 2023-08-24 19:09:33 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:09:33 --> Model "Home_model" initialized
INFO - 2023-08-24 19:09:33 --> Helper loaded: download_helper
INFO - 2023-08-24 19:09:33 --> Helper loaded: form_helper
INFO - 2023-08-24 19:09:33 --> Form Validation Class Initialized
INFO - 2023-08-24 19:09:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 19:09:33 --> Final output sent to browser
DEBUG - 2023-08-24 19:09:33 --> Total execution time: 0.3640
INFO - 2023-08-24 19:09:34 --> Config Class Initialized
INFO - 2023-08-24 19:09:34 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:34 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:34 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:34 --> URI Class Initialized
INFO - 2023-08-24 19:09:34 --> Router Class Initialized
INFO - 2023-08-24 19:09:34 --> Output Class Initialized
INFO - 2023-08-24 19:09:34 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:34 --> Input Class Initialized
INFO - 2023-08-24 19:09:34 --> Language Class Initialized
ERROR - 2023-08-24 19:09:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:09:34 --> Config Class Initialized
INFO - 2023-08-24 19:09:34 --> Hooks Class Initialized
INFO - 2023-08-24 19:09:34 --> Config Class Initialized
INFO - 2023-08-24 19:09:34 --> Config Class Initialized
INFO - 2023-08-24 19:09:34 --> Hooks Class Initialized
INFO - 2023-08-24 19:09:34 --> Config Class Initialized
INFO - 2023-08-24 19:09:34 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:34 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:34 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:09:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:09:34 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:34 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:34 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:34 --> Utf8 Class Initialized
DEBUG - 2023-08-24 19:09:34 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:09:34 --> URI Class Initialized
INFO - 2023-08-24 19:09:34 --> URI Class Initialized
INFO - 2023-08-24 19:09:34 --> Utf8 Class Initialized
INFO - 2023-08-24 19:09:34 --> URI Class Initialized
INFO - 2023-08-24 19:09:34 --> Router Class Initialized
INFO - 2023-08-24 19:09:34 --> Router Class Initialized
INFO - 2023-08-24 19:09:34 --> URI Class Initialized
INFO - 2023-08-24 19:09:34 --> Router Class Initialized
INFO - 2023-08-24 19:09:34 --> Output Class Initialized
INFO - 2023-08-24 19:09:34 --> Output Class Initialized
INFO - 2023-08-24 19:09:34 --> Router Class Initialized
INFO - 2023-08-24 19:09:34 --> Security Class Initialized
INFO - 2023-08-24 19:09:34 --> Security Class Initialized
DEBUG - 2023-08-24 19:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:34 --> Output Class Initialized
INFO - 2023-08-24 19:09:34 --> Output Class Initialized
DEBUG - 2023-08-24 19:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:34 --> Input Class Initialized
INFO - 2023-08-24 19:09:34 --> Language Class Initialized
INFO - 2023-08-24 19:09:34 --> Security Class Initialized
ERROR - 2023-08-24 19:09:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:09:34 --> Security Class Initialized
INFO - 2023-08-24 19:09:34 --> Input Class Initialized
INFO - 2023-08-24 19:09:34 --> Language Class Initialized
DEBUG - 2023-08-24 19:09:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-24 19:09:35 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-24 19:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:09:35 --> Input Class Initialized
INFO - 2023-08-24 19:09:35 --> Input Class Initialized
INFO - 2023-08-24 19:09:35 --> Language Class Initialized
INFO - 2023-08-24 19:09:35 --> Language Class Initialized
ERROR - 2023-08-24 19:09:35 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-24 19:09:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:10:04 --> Config Class Initialized
INFO - 2023-08-24 19:10:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:10:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:10:04 --> Utf8 Class Initialized
INFO - 2023-08-24 19:10:04 --> URI Class Initialized
INFO - 2023-08-24 19:10:04 --> Router Class Initialized
INFO - 2023-08-24 19:10:04 --> Output Class Initialized
INFO - 2023-08-24 19:10:04 --> Security Class Initialized
DEBUG - 2023-08-24 19:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:10:04 --> Input Class Initialized
INFO - 2023-08-24 19:10:04 --> Language Class Initialized
INFO - 2023-08-24 19:10:04 --> Loader Class Initialized
INFO - 2023-08-24 19:10:04 --> Helper loaded: url_helper
INFO - 2023-08-24 19:10:04 --> Helper loaded: file_helper
INFO - 2023-08-24 19:10:04 --> Database Driver Class Initialized
INFO - 2023-08-24 19:10:04 --> Email Class Initialized
DEBUG - 2023-08-24 19:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:10:04 --> Controller Class Initialized
INFO - 2023-08-24 19:10:04 --> Config Class Initialized
INFO - 2023-08-24 19:10:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:10:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:10:04 --> Utf8 Class Initialized
INFO - 2023-08-24 19:10:04 --> URI Class Initialized
INFO - 2023-08-24 19:10:04 --> Router Class Initialized
INFO - 2023-08-24 19:10:04 --> Output Class Initialized
INFO - 2023-08-24 19:10:04 --> Security Class Initialized
DEBUG - 2023-08-24 19:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:10:04 --> Input Class Initialized
INFO - 2023-08-24 19:10:04 --> Language Class Initialized
INFO - 2023-08-24 19:10:04 --> Loader Class Initialized
INFO - 2023-08-24 19:10:04 --> Helper loaded: url_helper
INFO - 2023-08-24 19:10:04 --> Helper loaded: file_helper
INFO - 2023-08-24 19:10:04 --> Database Driver Class Initialized
INFO - 2023-08-24 19:10:04 --> Email Class Initialized
DEBUG - 2023-08-24 19:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:10:04 --> Controller Class Initialized
INFO - 2023-08-24 19:10:05 --> Model "User_model" initialized
INFO - 2023-08-24 19:10:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-24 19:10:05 --> Final output sent to browser
DEBUG - 2023-08-24 19:10:05 --> Total execution time: 0.3690
INFO - 2023-08-24 19:10:06 --> Config Class Initialized
INFO - 2023-08-24 19:10:06 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:10:06 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:10:06 --> Utf8 Class Initialized
INFO - 2023-08-24 19:10:06 --> URI Class Initialized
INFO - 2023-08-24 19:10:06 --> Router Class Initialized
INFO - 2023-08-24 19:10:06 --> Output Class Initialized
INFO - 2023-08-24 19:10:06 --> Security Class Initialized
DEBUG - 2023-08-24 19:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:10:06 --> Input Class Initialized
INFO - 2023-08-24 19:10:06 --> Language Class Initialized
ERROR - 2023-08-24 19:10:06 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-24 19:10:12 --> Config Class Initialized
INFO - 2023-08-24 19:10:12 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:10:12 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:10:13 --> Utf8 Class Initialized
INFO - 2023-08-24 19:10:13 --> URI Class Initialized
INFO - 2023-08-24 19:10:13 --> Router Class Initialized
INFO - 2023-08-24 19:10:13 --> Output Class Initialized
INFO - 2023-08-24 19:10:13 --> Security Class Initialized
DEBUG - 2023-08-24 19:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:10:13 --> Input Class Initialized
INFO - 2023-08-24 19:10:13 --> Language Class Initialized
INFO - 2023-08-24 19:10:13 --> Loader Class Initialized
INFO - 2023-08-24 19:10:13 --> Helper loaded: url_helper
INFO - 2023-08-24 19:10:13 --> Helper loaded: file_helper
INFO - 2023-08-24 19:10:13 --> Database Driver Class Initialized
INFO - 2023-08-24 19:10:13 --> Email Class Initialized
DEBUG - 2023-08-24 19:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:10:13 --> Controller Class Initialized
INFO - 2023-08-24 19:10:13 --> Model "User_model" initialized
INFO - 2023-08-24 19:10:13 --> Config Class Initialized
INFO - 2023-08-24 19:10:13 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:10:13 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:10:13 --> Utf8 Class Initialized
INFO - 2023-08-24 19:10:13 --> URI Class Initialized
INFO - 2023-08-24 19:10:13 --> Router Class Initialized
INFO - 2023-08-24 19:10:13 --> Output Class Initialized
INFO - 2023-08-24 19:10:13 --> Security Class Initialized
DEBUG - 2023-08-24 19:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:10:13 --> Input Class Initialized
INFO - 2023-08-24 19:10:13 --> Language Class Initialized
INFO - 2023-08-24 19:10:13 --> Loader Class Initialized
INFO - 2023-08-24 19:10:13 --> Helper loaded: url_helper
INFO - 2023-08-24 19:10:13 --> Helper loaded: file_helper
INFO - 2023-08-24 19:10:13 --> Database Driver Class Initialized
INFO - 2023-08-24 19:10:13 --> Email Class Initialized
DEBUG - 2023-08-24 19:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:10:13 --> Controller Class Initialized
INFO - 2023-08-24 19:10:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-24 19:10:13 --> Final output sent to browser
DEBUG - 2023-08-24 19:10:13 --> Total execution time: 0.4062
INFO - 2023-08-24 19:10:20 --> Config Class Initialized
INFO - 2023-08-24 19:10:20 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:10:20 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:10:20 --> Utf8 Class Initialized
INFO - 2023-08-24 19:10:20 --> URI Class Initialized
INFO - 2023-08-24 19:10:20 --> Router Class Initialized
INFO - 2023-08-24 19:10:20 --> Output Class Initialized
INFO - 2023-08-24 19:10:20 --> Security Class Initialized
DEBUG - 2023-08-24 19:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:10:20 --> Input Class Initialized
INFO - 2023-08-24 19:10:20 --> Language Class Initialized
INFO - 2023-08-24 19:10:20 --> Loader Class Initialized
INFO - 2023-08-24 19:10:20 --> Helper loaded: url_helper
INFO - 2023-08-24 19:10:20 --> Helper loaded: file_helper
INFO - 2023-08-24 19:10:20 --> Database Driver Class Initialized
INFO - 2023-08-24 19:10:20 --> Email Class Initialized
DEBUG - 2023-08-24 19:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:10:20 --> Controller Class Initialized
INFO - 2023-08-24 19:10:20 --> Model "Training_model" initialized
INFO - 2023-08-24 19:10:20 --> Helper loaded: form_helper
INFO - 2023-08-24 19:10:20 --> Form Validation Class Initialized
INFO - 2023-08-24 19:10:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-24 19:10:20 --> Final output sent to browser
DEBUG - 2023-08-24 19:10:20 --> Total execution time: 0.3931
INFO - 2023-08-24 19:10:24 --> Config Class Initialized
INFO - 2023-08-24 19:10:24 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:10:24 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:10:24 --> Utf8 Class Initialized
INFO - 2023-08-24 19:10:24 --> URI Class Initialized
INFO - 2023-08-24 19:10:24 --> Router Class Initialized
INFO - 2023-08-24 19:10:24 --> Output Class Initialized
INFO - 2023-08-24 19:10:24 --> Security Class Initialized
DEBUG - 2023-08-24 19:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:10:24 --> Input Class Initialized
INFO - 2023-08-24 19:10:24 --> Language Class Initialized
INFO - 2023-08-24 19:10:24 --> Loader Class Initialized
INFO - 2023-08-24 19:10:24 --> Helper loaded: url_helper
INFO - 2023-08-24 19:10:24 --> Helper loaded: file_helper
INFO - 2023-08-24 19:10:24 --> Database Driver Class Initialized
INFO - 2023-08-24 19:10:24 --> Email Class Initialized
DEBUG - 2023-08-24 19:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:10:24 --> Controller Class Initialized
INFO - 2023-08-24 19:10:24 --> Model "Training_model" initialized
INFO - 2023-08-24 19:10:24 --> Helper loaded: form_helper
INFO - 2023-08-24 19:10:24 --> Form Validation Class Initialized
INFO - 2023-08-24 19:10:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-24 19:10:24 --> Final output sent to browser
DEBUG - 2023-08-24 19:10:24 --> Total execution time: 0.3900
INFO - 2023-08-24 19:10:25 --> Config Class Initialized
INFO - 2023-08-24 19:10:25 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:10:25 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:10:25 --> Utf8 Class Initialized
INFO - 2023-08-24 19:10:25 --> URI Class Initialized
INFO - 2023-08-24 19:10:25 --> Router Class Initialized
INFO - 2023-08-24 19:10:25 --> Output Class Initialized
INFO - 2023-08-24 19:10:25 --> Security Class Initialized
DEBUG - 2023-08-24 19:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:10:25 --> Input Class Initialized
INFO - 2023-08-24 19:10:25 --> Language Class Initialized
INFO - 2023-08-24 19:10:25 --> Loader Class Initialized
INFO - 2023-08-24 19:10:25 --> Helper loaded: url_helper
INFO - 2023-08-24 19:10:25 --> Helper loaded: file_helper
INFO - 2023-08-24 19:10:25 --> Database Driver Class Initialized
INFO - 2023-08-24 19:10:25 --> Email Class Initialized
DEBUG - 2023-08-24 19:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:10:25 --> Controller Class Initialized
INFO - 2023-08-24 19:10:25 --> Model "Training_model" initialized
INFO - 2023-08-24 19:10:25 --> Helper loaded: form_helper
INFO - 2023-08-24 19:10:25 --> Form Validation Class Initialized
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 40
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 49
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 60
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 75
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 88
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 105
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 118
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 133
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 134
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 135
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 152
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 164
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 175
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 177
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 180
ERROR - 2023-08-24 19:10:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 182
INFO - 2023-08-24 19:10:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-24 19:10:25 --> Final output sent to browser
DEBUG - 2023-08-24 19:10:25 --> Total execution time: 0.6508
INFO - 2023-08-24 19:10:30 --> Config Class Initialized
INFO - 2023-08-24 19:10:30 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:10:30 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:10:30 --> Utf8 Class Initialized
INFO - 2023-08-24 19:10:30 --> URI Class Initialized
INFO - 2023-08-24 19:10:31 --> Router Class Initialized
INFO - 2023-08-24 19:10:31 --> Output Class Initialized
INFO - 2023-08-24 19:10:31 --> Security Class Initialized
DEBUG - 2023-08-24 19:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:10:31 --> Input Class Initialized
INFO - 2023-08-24 19:10:31 --> Language Class Initialized
INFO - 2023-08-24 19:10:31 --> Loader Class Initialized
INFO - 2023-08-24 19:10:31 --> Helper loaded: url_helper
INFO - 2023-08-24 19:10:31 --> Helper loaded: file_helper
INFO - 2023-08-24 19:10:31 --> Database Driver Class Initialized
INFO - 2023-08-24 19:10:31 --> Email Class Initialized
DEBUG - 2023-08-24 19:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:10:31 --> Controller Class Initialized
INFO - 2023-08-24 19:10:31 --> Model "Training_model" initialized
INFO - 2023-08-24 19:10:31 --> Helper loaded: form_helper
INFO - 2023-08-24 19:10:31 --> Form Validation Class Initialized
INFO - 2023-08-24 19:10:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-24 19:10:31 --> Final output sent to browser
DEBUG - 2023-08-24 19:10:31 --> Total execution time: 0.4196
INFO - 2023-08-24 19:10:36 --> Config Class Initialized
INFO - 2023-08-24 19:10:36 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:10:36 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:10:36 --> Utf8 Class Initialized
INFO - 2023-08-24 19:10:36 --> URI Class Initialized
INFO - 2023-08-24 19:10:36 --> Router Class Initialized
INFO - 2023-08-24 19:10:36 --> Output Class Initialized
INFO - 2023-08-24 19:10:36 --> Security Class Initialized
DEBUG - 2023-08-24 19:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:10:36 --> Input Class Initialized
INFO - 2023-08-24 19:10:36 --> Language Class Initialized
INFO - 2023-08-24 19:10:36 --> Loader Class Initialized
INFO - 2023-08-24 19:10:36 --> Helper loaded: url_helper
INFO - 2023-08-24 19:10:36 --> Helper loaded: file_helper
INFO - 2023-08-24 19:10:36 --> Database Driver Class Initialized
INFO - 2023-08-24 19:10:36 --> Email Class Initialized
DEBUG - 2023-08-24 19:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:10:36 --> Controller Class Initialized
INFO - 2023-08-24 19:10:36 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-24 19:10:36 --> Helper loaded: form_helper
INFO - 2023-08-24 19:10:36 --> Form Validation Class Initialized
INFO - 2023-08-24 19:10:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-24 19:10:36 --> Final output sent to browser
DEBUG - 2023-08-24 19:10:36 --> Total execution time: 0.3968
INFO - 2023-08-24 19:10:37 --> Config Class Initialized
INFO - 2023-08-24 19:10:37 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:10:37 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:10:37 --> Utf8 Class Initialized
INFO - 2023-08-24 19:10:37 --> URI Class Initialized
INFO - 2023-08-24 19:10:37 --> Router Class Initialized
INFO - 2023-08-24 19:10:37 --> Output Class Initialized
INFO - 2023-08-24 19:10:37 --> Security Class Initialized
DEBUG - 2023-08-24 19:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:10:37 --> Input Class Initialized
INFO - 2023-08-24 19:10:37 --> Language Class Initialized
ERROR - 2023-08-24 19:10:37 --> 404 Page Not Found: admin/Training_curriculum/images
INFO - 2023-08-24 19:10:38 --> Config Class Initialized
INFO - 2023-08-24 19:10:38 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:10:38 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:10:38 --> Utf8 Class Initialized
INFO - 2023-08-24 19:10:38 --> URI Class Initialized
INFO - 2023-08-24 19:10:38 --> Router Class Initialized
INFO - 2023-08-24 19:10:38 --> Output Class Initialized
INFO - 2023-08-24 19:10:39 --> Security Class Initialized
DEBUG - 2023-08-24 19:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:10:39 --> Input Class Initialized
INFO - 2023-08-24 19:10:39 --> Language Class Initialized
INFO - 2023-08-24 19:10:39 --> Loader Class Initialized
INFO - 2023-08-24 19:10:39 --> Helper loaded: url_helper
INFO - 2023-08-24 19:10:39 --> Helper loaded: file_helper
INFO - 2023-08-24 19:10:39 --> Database Driver Class Initialized
INFO - 2023-08-24 19:10:39 --> Email Class Initialized
DEBUG - 2023-08-24 19:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:10:39 --> Controller Class Initialized
INFO - 2023-08-24 19:10:39 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-24 19:10:39 --> Helper loaded: form_helper
INFO - 2023-08-24 19:10:39 --> Form Validation Class Initialized
INFO - 2023-08-24 19:10:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-08-24 19:10:39 --> Final output sent to browser
DEBUG - 2023-08-24 19:10:39 --> Total execution time: 0.4140
INFO - 2023-08-24 19:10:40 --> Config Class Initialized
INFO - 2023-08-24 19:10:40 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:10:40 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:10:40 --> Utf8 Class Initialized
INFO - 2023-08-24 19:10:40 --> URI Class Initialized
INFO - 2023-08-24 19:10:40 --> Router Class Initialized
INFO - 2023-08-24 19:10:40 --> Output Class Initialized
INFO - 2023-08-24 19:10:40 --> Security Class Initialized
DEBUG - 2023-08-24 19:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:10:40 --> Input Class Initialized
INFO - 2023-08-24 19:10:40 --> Language Class Initialized
ERROR - 2023-08-24 19:10:40 --> 404 Page Not Found: admin/Training_curriculum/add
INFO - 2023-08-24 19:22:02 --> Config Class Initialized
INFO - 2023-08-24 19:22:02 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:22:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:22:02 --> Utf8 Class Initialized
INFO - 2023-08-24 19:22:02 --> URI Class Initialized
INFO - 2023-08-24 19:22:02 --> Router Class Initialized
INFO - 2023-08-24 19:22:02 --> Output Class Initialized
INFO - 2023-08-24 19:22:02 --> Security Class Initialized
DEBUG - 2023-08-24 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:22:02 --> Input Class Initialized
INFO - 2023-08-24 19:22:02 --> Language Class Initialized
INFO - 2023-08-24 19:22:02 --> Loader Class Initialized
INFO - 2023-08-24 19:22:02 --> Helper loaded: url_helper
INFO - 2023-08-24 19:22:02 --> Helper loaded: file_helper
INFO - 2023-08-24 19:22:02 --> Database Driver Class Initialized
INFO - 2023-08-24 19:22:02 --> Email Class Initialized
DEBUG - 2023-08-24 19:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:22:02 --> Controller Class Initialized
INFO - 2023-08-24 19:22:02 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:22:02 --> Model "Home_model" initialized
INFO - 2023-08-24 19:22:02 --> Helper loaded: download_helper
INFO - 2023-08-24 19:22:02 --> Helper loaded: form_helper
INFO - 2023-08-24 19:22:02 --> Form Validation Class Initialized
INFO - 2023-08-24 19:22:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-24 19:22:02 --> Final output sent to browser
DEBUG - 2023-08-24 19:22:03 --> Total execution time: 0.5464
INFO - 2023-08-24 19:22:03 --> Config Class Initialized
INFO - 2023-08-24 19:22:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:22:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:22:04 --> Config Class Initialized
INFO - 2023-08-24 19:22:04 --> Hooks Class Initialized
INFO - 2023-08-24 19:22:04 --> Utf8 Class Initialized
INFO - 2023-08-24 19:22:04 --> URI Class Initialized
DEBUG - 2023-08-24 19:22:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:22:04 --> Config Class Initialized
INFO - 2023-08-24 19:22:04 --> Config Class Initialized
INFO - 2023-08-24 19:22:04 --> Config Class Initialized
INFO - 2023-08-24 19:22:04 --> Hooks Class Initialized
INFO - 2023-08-24 19:22:04 --> Utf8 Class Initialized
INFO - 2023-08-24 19:22:04 --> URI Class Initialized
INFO - 2023-08-24 19:22:04 --> Router Class Initialized
INFO - 2023-08-24 19:22:04 --> Output Class Initialized
INFO - 2023-08-24 19:22:04 --> Security Class Initialized
DEBUG - 2023-08-24 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:22:04 --> Input Class Initialized
INFO - 2023-08-24 19:22:04 --> Language Class Initialized
ERROR - 2023-08-24 19:22:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:22:04 --> Hooks Class Initialized
INFO - 2023-08-24 19:22:04 --> Router Class Initialized
INFO - 2023-08-24 19:22:04 --> Hooks Class Initialized
INFO - 2023-08-24 19:22:04 --> Output Class Initialized
DEBUG - 2023-08-24 19:22:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:22:04 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:22:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:22:04 --> Utf8 Class Initialized
INFO - 2023-08-24 19:22:04 --> Security Class Initialized
INFO - 2023-08-24 19:22:04 --> Utf8 Class Initialized
INFO - 2023-08-24 19:22:04 --> URI Class Initialized
INFO - 2023-08-24 19:22:04 --> URI Class Initialized
INFO - 2023-08-24 19:22:04 --> Router Class Initialized
DEBUG - 2023-08-24 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:22:04 --> Utf8 Class Initialized
INFO - 2023-08-24 19:22:04 --> Router Class Initialized
INFO - 2023-08-24 19:22:04 --> URI Class Initialized
INFO - 2023-08-24 19:22:04 --> Output Class Initialized
INFO - 2023-08-24 19:22:04 --> Output Class Initialized
INFO - 2023-08-24 19:22:04 --> Input Class Initialized
INFO - 2023-08-24 19:22:04 --> Security Class Initialized
INFO - 2023-08-24 19:22:04 --> Router Class Initialized
INFO - 2023-08-24 19:22:04 --> Language Class Initialized
INFO - 2023-08-24 19:22:04 --> Security Class Initialized
DEBUG - 2023-08-24 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:22:04 --> Output Class Initialized
ERROR - 2023-08-24 19:22:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:22:04 --> Input Class Initialized
DEBUG - 2023-08-24 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:22:04 --> Language Class Initialized
INFO - 2023-08-24 19:22:04 --> Security Class Initialized
ERROR - 2023-08-24 19:22:04 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-24 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:22:04 --> Input Class Initialized
INFO - 2023-08-24 19:22:05 --> Input Class Initialized
INFO - 2023-08-24 19:22:05 --> Language Class Initialized
INFO - 2023-08-24 19:22:05 --> Language Class Initialized
ERROR - 2023-08-24 19:22:05 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-24 19:22:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-24 19:22:19 --> Config Class Initialized
INFO - 2023-08-24 19:22:19 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:22:19 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:22:19 --> Utf8 Class Initialized
INFO - 2023-08-24 19:22:19 --> URI Class Initialized
INFO - 2023-08-24 19:22:19 --> Router Class Initialized
INFO - 2023-08-24 19:22:19 --> Output Class Initialized
INFO - 2023-08-24 19:22:19 --> Security Class Initialized
DEBUG - 2023-08-24 19:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:22:19 --> Input Class Initialized
INFO - 2023-08-24 19:22:19 --> Language Class Initialized
INFO - 2023-08-24 19:22:19 --> Loader Class Initialized
INFO - 2023-08-24 19:22:19 --> Helper loaded: url_helper
INFO - 2023-08-24 19:22:19 --> Helper loaded: file_helper
INFO - 2023-08-24 19:22:19 --> Database Driver Class Initialized
INFO - 2023-08-24 19:22:19 --> Email Class Initialized
DEBUG - 2023-08-24 19:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:22:19 --> Controller Class Initialized
INFO - 2023-08-24 19:22:19 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:22:19 --> Model "Home_model" initialized
INFO - 2023-08-24 19:22:19 --> Helper loaded: download_helper
INFO - 2023-08-24 19:22:19 --> Helper loaded: form_helper
INFO - 2023-08-24 19:22:19 --> Form Validation Class Initialized
INFO - 2023-08-24 19:22:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-24 19:22:19 --> Final output sent to browser
DEBUG - 2023-08-24 19:22:19 --> Total execution time: 0.5511
INFO - 2023-08-24 19:22:20 --> Config Class Initialized
INFO - 2023-08-24 19:22:20 --> Config Class Initialized
INFO - 2023-08-24 19:22:20 --> Hooks Class Initialized
INFO - 2023-08-24 19:22:20 --> Config Class Initialized
INFO - 2023-08-24 19:22:20 --> Hooks Class Initialized
INFO - 2023-08-24 19:22:20 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:22:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:22:20 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:22:20 --> Utf8 Class Initialized
INFO - 2023-08-24 19:22:20 --> URI Class Initialized
DEBUG - 2023-08-24 19:22:20 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:22:20 --> Router Class Initialized
INFO - 2023-08-24 19:22:20 --> Utf8 Class Initialized
INFO - 2023-08-24 19:22:20 --> Output Class Initialized
INFO - 2023-08-24 19:22:20 --> Security Class Initialized
INFO - 2023-08-24 19:22:20 --> URI Class Initialized
DEBUG - 2023-08-24 19:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:22:20 --> Utf8 Class Initialized
INFO - 2023-08-24 19:22:20 --> Input Class Initialized
INFO - 2023-08-24 19:22:20 --> URI Class Initialized
INFO - 2023-08-24 19:22:20 --> Router Class Initialized
INFO - 2023-08-24 19:22:21 --> Language Class Initialized
INFO - 2023-08-24 19:22:21 --> Output Class Initialized
ERROR - 2023-08-24 19:22:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:22:21 --> Router Class Initialized
INFO - 2023-08-24 19:22:21 --> Security Class Initialized
INFO - 2023-08-24 19:22:21 --> Output Class Initialized
DEBUG - 2023-08-24 19:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:22:21 --> Security Class Initialized
INFO - 2023-08-24 19:22:21 --> Input Class Initialized
DEBUG - 2023-08-24 19:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:22:21 --> Input Class Initialized
INFO - 2023-08-24 19:22:21 --> Language Class Initialized
INFO - 2023-08-24 19:22:21 --> Language Class Initialized
ERROR - 2023-08-24 19:22:21 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-24 19:22:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:22:21 --> Config Class Initialized
INFO - 2023-08-24 19:22:21 --> Hooks Class Initialized
INFO - 2023-08-24 19:22:21 --> Config Class Initialized
DEBUG - 2023-08-24 19:22:21 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:22:21 --> Utf8 Class Initialized
INFO - 2023-08-24 19:22:21 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:22:21 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:22:21 --> URI Class Initialized
INFO - 2023-08-24 19:22:21 --> Router Class Initialized
INFO - 2023-08-24 19:22:21 --> Utf8 Class Initialized
INFO - 2023-08-24 19:22:21 --> Output Class Initialized
INFO - 2023-08-24 19:22:21 --> URI Class Initialized
INFO - 2023-08-24 19:22:21 --> Security Class Initialized
INFO - 2023-08-24 19:22:21 --> Router Class Initialized
DEBUG - 2023-08-24 19:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:22:21 --> Output Class Initialized
INFO - 2023-08-24 19:22:21 --> Input Class Initialized
INFO - 2023-08-24 19:22:21 --> Security Class Initialized
INFO - 2023-08-24 19:22:21 --> Language Class Initialized
DEBUG - 2023-08-24 19:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:22:21 --> Input Class Initialized
ERROR - 2023-08-24 19:22:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:22:21 --> Language Class Initialized
ERROR - 2023-08-24 19:22:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:23:39 --> Config Class Initialized
INFO - 2023-08-24 19:23:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:23:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:23:39 --> Utf8 Class Initialized
INFO - 2023-08-24 19:23:39 --> URI Class Initialized
INFO - 2023-08-24 19:23:39 --> Router Class Initialized
INFO - 2023-08-24 19:23:39 --> Output Class Initialized
INFO - 2023-08-24 19:23:39 --> Security Class Initialized
DEBUG - 2023-08-24 19:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:23:39 --> Input Class Initialized
INFO - 2023-08-24 19:23:39 --> Language Class Initialized
INFO - 2023-08-24 19:23:39 --> Loader Class Initialized
INFO - 2023-08-24 19:23:39 --> Helper loaded: url_helper
INFO - 2023-08-24 19:23:39 --> Helper loaded: file_helper
INFO - 2023-08-24 19:23:39 --> Database Driver Class Initialized
INFO - 2023-08-24 19:23:39 --> Email Class Initialized
DEBUG - 2023-08-24 19:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:23:39 --> Controller Class Initialized
INFO - 2023-08-24 19:23:39 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:23:39 --> Model "Home_model" initialized
INFO - 2023-08-24 19:23:39 --> Helper loaded: download_helper
INFO - 2023-08-24 19:23:39 --> Helper loaded: form_helper
INFO - 2023-08-24 19:23:39 --> Form Validation Class Initialized
INFO - 2023-08-24 19:23:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:23:39 --> Final output sent to browser
DEBUG - 2023-08-24 19:23:40 --> Total execution time: 0.3844
INFO - 2023-08-24 19:23:41 --> Config Class Initialized
INFO - 2023-08-24 19:23:41 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:23:41 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:23:41 --> Config Class Initialized
INFO - 2023-08-24 19:23:41 --> Hooks Class Initialized
INFO - 2023-08-24 19:23:41 --> Utf8 Class Initialized
INFO - 2023-08-24 19:23:41 --> URI Class Initialized
INFO - 2023-08-24 19:23:41 --> Config Class Initialized
INFO - 2023-08-24 19:23:41 --> Router Class Initialized
INFO - 2023-08-24 19:23:41 --> Config Class Initialized
INFO - 2023-08-24 19:23:41 --> Hooks Class Initialized
INFO - 2023-08-24 19:23:41 --> Output Class Initialized
DEBUG - 2023-08-24 19:23:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:23:41 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:23:41 --> Security Class Initialized
INFO - 2023-08-24 19:23:41 --> Hooks Class Initialized
INFO - 2023-08-24 19:23:41 --> Utf8 Class Initialized
INFO - 2023-08-24 19:23:41 --> Utf8 Class Initialized
DEBUG - 2023-08-24 19:23:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:23:41 --> URI Class Initialized
INFO - 2023-08-24 19:23:41 --> Input Class Initialized
INFO - 2023-08-24 19:23:41 --> URI Class Initialized
INFO - 2023-08-24 19:23:41 --> Utf8 Class Initialized
INFO - 2023-08-24 19:23:41 --> Router Class Initialized
INFO - 2023-08-24 19:23:41 --> Router Class Initialized
INFO - 2023-08-24 19:23:41 --> Config Class Initialized
INFO - 2023-08-24 19:23:41 --> Language Class Initialized
INFO - 2023-08-24 19:23:41 --> URI Class Initialized
INFO - 2023-08-24 19:23:41 --> Config Class Initialized
INFO - 2023-08-24 19:23:41 --> Hooks Class Initialized
INFO - 2023-08-24 19:23:41 --> Output Class Initialized
INFO - 2023-08-24 19:23:41 --> Output Class Initialized
INFO - 2023-08-24 19:23:41 --> Hooks Class Initialized
ERROR - 2023-08-24 19:23:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:23:41 --> Router Class Initialized
INFO - 2023-08-24 19:23:41 --> Security Class Initialized
DEBUG - 2023-08-24 19:23:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:23:41 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:23:41 --> Security Class Initialized
DEBUG - 2023-08-24 19:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:23:41 --> Utf8 Class Initialized
INFO - 2023-08-24 19:23:41 --> Utf8 Class Initialized
DEBUG - 2023-08-24 19:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:23:41 --> Output Class Initialized
INFO - 2023-08-24 19:23:41 --> URI Class Initialized
INFO - 2023-08-24 19:23:41 --> Router Class Initialized
INFO - 2023-08-24 19:23:41 --> Security Class Initialized
INFO - 2023-08-24 19:23:42 --> Input Class Initialized
INFO - 2023-08-24 19:23:42 --> URI Class Initialized
INFO - 2023-08-24 19:23:42 --> Output Class Initialized
INFO - 2023-08-24 19:23:42 --> Router Class Initialized
INFO - 2023-08-24 19:23:42 --> Input Class Initialized
DEBUG - 2023-08-24 19:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:23:42 --> Security Class Initialized
INFO - 2023-08-24 19:23:42 --> Language Class Initialized
DEBUG - 2023-08-24 19:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:23:42 --> Language Class Initialized
INFO - 2023-08-24 19:23:42 --> Output Class Initialized
INFO - 2023-08-24 19:23:42 --> Security Class Initialized
INFO - 2023-08-24 19:23:42 --> Input Class Initialized
ERROR - 2023-08-24 19:23:42 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-24 19:23:42 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-24 19:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:23:42 --> Input Class Initialized
INFO - 2023-08-24 19:23:42 --> Language Class Initialized
ERROR - 2023-08-24 19:23:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:23:42 --> Input Class Initialized
INFO - 2023-08-24 19:23:42 --> Language Class Initialized
INFO - 2023-08-24 19:23:42 --> Language Class Initialized
ERROR - 2023-08-24 19:23:42 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-24 19:23:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:25:36 --> Config Class Initialized
INFO - 2023-08-24 19:25:36 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:25:36 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:25:36 --> Utf8 Class Initialized
INFO - 2023-08-24 19:25:36 --> URI Class Initialized
INFO - 2023-08-24 19:25:36 --> Router Class Initialized
INFO - 2023-08-24 19:25:36 --> Output Class Initialized
INFO - 2023-08-24 19:25:36 --> Security Class Initialized
DEBUG - 2023-08-24 19:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:25:36 --> Input Class Initialized
INFO - 2023-08-24 19:25:36 --> Language Class Initialized
INFO - 2023-08-24 19:25:36 --> Loader Class Initialized
INFO - 2023-08-24 19:25:37 --> Helper loaded: url_helper
INFO - 2023-08-24 19:25:37 --> Helper loaded: file_helper
INFO - 2023-08-24 19:25:37 --> Database Driver Class Initialized
INFO - 2023-08-24 19:25:37 --> Email Class Initialized
DEBUG - 2023-08-24 19:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:25:37 --> Controller Class Initialized
INFO - 2023-08-24 19:25:37 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:25:37 --> Model "Home_model" initialized
INFO - 2023-08-24 19:25:37 --> Helper loaded: download_helper
INFO - 2023-08-24 19:25:38 --> Helper loaded: form_helper
INFO - 2023-08-24 19:25:38 --> Form Validation Class Initialized
ERROR - 2023-08-24 19:25:38 --> Severity: Warning --> Undefined variable $trainings C:\xampp\htdocs\dw\application\views\home\services.php 109
ERROR - 2023-08-24 19:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\services.php 109
ERROR - 2023-08-24 19:25:38 --> Severity: Warning --> Undefined variable $trainings C:\xampp\htdocs\dw\application\views\home\services.php 139
ERROR - 2023-08-24 19:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\services.php 139
INFO - 2023-08-24 19:25:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-24 19:25:38 --> Final output sent to browser
DEBUG - 2023-08-24 19:25:38 --> Total execution time: 2.1371
INFO - 2023-08-24 19:25:38 --> Config Class Initialized
INFO - 2023-08-24 19:25:39 --> Hooks Class Initialized
INFO - 2023-08-24 19:25:39 --> Config Class Initialized
INFO - 2023-08-24 19:25:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:25:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:25:39 --> Utf8 Class Initialized
INFO - 2023-08-24 19:25:39 --> URI Class Initialized
INFO - 2023-08-24 19:25:39 --> Router Class Initialized
INFO - 2023-08-24 19:25:39 --> Output Class Initialized
INFO - 2023-08-24 19:25:39 --> Security Class Initialized
DEBUG - 2023-08-24 19:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:25:39 --> Input Class Initialized
INFO - 2023-08-24 19:25:39 --> Language Class Initialized
ERROR - 2023-08-24 19:25:39 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-24 19:25:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:25:39 --> Config Class Initialized
INFO - 2023-08-24 19:25:39 --> Config Class Initialized
INFO - 2023-08-24 19:25:39 --> Utf8 Class Initialized
INFO - 2023-08-24 19:25:39 --> Hooks Class Initialized
INFO - 2023-08-24 19:25:39 --> Config Class Initialized
INFO - 2023-08-24 19:25:39 --> URI Class Initialized
INFO - 2023-08-24 19:25:39 --> Router Class Initialized
INFO - 2023-08-24 19:25:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:25:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:25:39 --> Utf8 Class Initialized
INFO - 2023-08-24 19:25:39 --> URI Class Initialized
INFO - 2023-08-24 19:25:39 --> Router Class Initialized
INFO - 2023-08-24 19:25:39 --> Output Class Initialized
INFO - 2023-08-24 19:25:39 --> Security Class Initialized
DEBUG - 2023-08-24 19:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:25:39 --> Input Class Initialized
INFO - 2023-08-24 19:25:39 --> Language Class Initialized
ERROR - 2023-08-24 19:25:39 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-24 19:25:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:25:39 --> Output Class Initialized
INFO - 2023-08-24 19:25:39 --> Security Class Initialized
DEBUG - 2023-08-24 19:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:25:39 --> Input Class Initialized
INFO - 2023-08-24 19:25:39 --> Language Class Initialized
ERROR - 2023-08-24 19:25:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:25:39 --> Utf8 Class Initialized
INFO - 2023-08-24 19:25:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:25:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:25:39 --> Utf8 Class Initialized
INFO - 2023-08-24 19:25:39 --> URI Class Initialized
INFO - 2023-08-24 19:25:39 --> Router Class Initialized
INFO - 2023-08-24 19:25:39 --> Output Class Initialized
INFO - 2023-08-24 19:25:39 --> Security Class Initialized
DEBUG - 2023-08-24 19:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:25:39 --> Input Class Initialized
INFO - 2023-08-24 19:25:39 --> Language Class Initialized
ERROR - 2023-08-24 19:25:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:25:39 --> URI Class Initialized
INFO - 2023-08-24 19:25:39 --> Config Class Initialized
INFO - 2023-08-24 19:25:39 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:25:39 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:25:39 --> Utf8 Class Initialized
INFO - 2023-08-24 19:25:39 --> URI Class Initialized
INFO - 2023-08-24 19:25:39 --> Router Class Initialized
INFO - 2023-08-24 19:25:39 --> Output Class Initialized
INFO - 2023-08-24 19:25:39 --> Security Class Initialized
DEBUG - 2023-08-24 19:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:25:39 --> Input Class Initialized
INFO - 2023-08-24 19:25:39 --> Language Class Initialized
ERROR - 2023-08-24 19:25:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:25:39 --> Router Class Initialized
INFO - 2023-08-24 19:25:39 --> Output Class Initialized
INFO - 2023-08-24 19:25:39 --> Security Class Initialized
DEBUG - 2023-08-24 19:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:25:40 --> Input Class Initialized
INFO - 2023-08-24 19:25:40 --> Language Class Initialized
ERROR - 2023-08-24 19:25:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:31:15 --> Config Class Initialized
INFO - 2023-08-24 19:31:15 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:31:15 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:31:15 --> Utf8 Class Initialized
INFO - 2023-08-24 19:31:15 --> URI Class Initialized
INFO - 2023-08-24 19:31:15 --> Router Class Initialized
INFO - 2023-08-24 19:31:15 --> Output Class Initialized
INFO - 2023-08-24 19:31:15 --> Security Class Initialized
DEBUG - 2023-08-24 19:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:31:15 --> Input Class Initialized
INFO - 2023-08-24 19:31:15 --> Language Class Initialized
INFO - 2023-08-24 19:31:15 --> Loader Class Initialized
INFO - 2023-08-24 19:31:15 --> Helper loaded: url_helper
INFO - 2023-08-24 19:31:15 --> Helper loaded: file_helper
INFO - 2023-08-24 19:31:15 --> Database Driver Class Initialized
INFO - 2023-08-24 19:31:15 --> Email Class Initialized
DEBUG - 2023-08-24 19:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:31:15 --> Controller Class Initialized
INFO - 2023-08-24 19:31:15 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:31:15 --> Model "Home_model" initialized
INFO - 2023-08-24 19:31:15 --> Helper loaded: download_helper
INFO - 2023-08-24 19:31:15 --> Helper loaded: form_helper
INFO - 2023-08-24 19:31:15 --> Form Validation Class Initialized
INFO - 2023-08-24 19:31:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:31:15 --> Final output sent to browser
DEBUG - 2023-08-24 19:31:15 --> Total execution time: 0.5065
INFO - 2023-08-24 19:36:59 --> Config Class Initialized
INFO - 2023-08-24 19:36:59 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:36:59 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:36:59 --> Utf8 Class Initialized
INFO - 2023-08-24 19:36:59 --> URI Class Initialized
INFO - 2023-08-24 19:36:59 --> Router Class Initialized
INFO - 2023-08-24 19:36:59 --> Output Class Initialized
INFO - 2023-08-24 19:36:59 --> Security Class Initialized
DEBUG - 2023-08-24 19:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:36:59 --> Input Class Initialized
INFO - 2023-08-24 19:36:59 --> Language Class Initialized
INFO - 2023-08-24 19:36:59 --> Loader Class Initialized
INFO - 2023-08-24 19:36:59 --> Helper loaded: url_helper
INFO - 2023-08-24 19:36:59 --> Helper loaded: file_helper
INFO - 2023-08-24 19:36:59 --> Database Driver Class Initialized
INFO - 2023-08-24 19:37:00 --> Email Class Initialized
DEBUG - 2023-08-24 19:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:37:00 --> Controller Class Initialized
INFO - 2023-08-24 19:37:00 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:37:00 --> Model "Home_model" initialized
INFO - 2023-08-24 19:37:00 --> Helper loaded: download_helper
INFO - 2023-08-24 19:37:00 --> Helper loaded: form_helper
INFO - 2023-08-24 19:37:00 --> Form Validation Class Initialized
ERROR - 2023-08-24 19:37:00 --> Severity: error --> Exception: Too few arguments to function Home_model::getActiveCertification(), 0 passed in C:\xampp\htdocs\dw\application\controllers\Home\HomeController.php on line 70 and exactly 1 expected C:\xampp\htdocs\dw\application\models\Home_model.php 62
INFO - 2023-08-24 19:37:20 --> Config Class Initialized
INFO - 2023-08-24 19:37:20 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:37:20 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:37:20 --> Utf8 Class Initialized
INFO - 2023-08-24 19:37:20 --> URI Class Initialized
INFO - 2023-08-24 19:37:20 --> Router Class Initialized
INFO - 2023-08-24 19:37:20 --> Output Class Initialized
INFO - 2023-08-24 19:37:20 --> Security Class Initialized
DEBUG - 2023-08-24 19:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:37:20 --> Input Class Initialized
INFO - 2023-08-24 19:37:20 --> Language Class Initialized
INFO - 2023-08-24 19:37:20 --> Loader Class Initialized
INFO - 2023-08-24 19:37:20 --> Helper loaded: url_helper
INFO - 2023-08-24 19:37:20 --> Helper loaded: file_helper
INFO - 2023-08-24 19:37:20 --> Database Driver Class Initialized
INFO - 2023-08-24 19:37:20 --> Email Class Initialized
DEBUG - 2023-08-24 19:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:37:20 --> Controller Class Initialized
INFO - 2023-08-24 19:37:20 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:37:20 --> Model "Home_model" initialized
INFO - 2023-08-24 19:37:20 --> Helper loaded: download_helper
INFO - 2023-08-24 19:37:20 --> Helper loaded: form_helper
INFO - 2023-08-24 19:37:21 --> Form Validation Class Initialized
INFO - 2023-08-24 19:37:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:37:21 --> Final output sent to browser
DEBUG - 2023-08-24 19:37:21 --> Total execution time: 0.1340
INFO - 2023-08-24 19:37:21 --> Config Class Initialized
INFO - 2023-08-24 19:37:21 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:37:21 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:37:21 --> Utf8 Class Initialized
INFO - 2023-08-24 19:37:21 --> URI Class Initialized
INFO - 2023-08-24 19:37:21 --> Router Class Initialized
INFO - 2023-08-24 19:37:21 --> Output Class Initialized
INFO - 2023-08-24 19:37:21 --> Security Class Initialized
DEBUG - 2023-08-24 19:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:37:21 --> Input Class Initialized
INFO - 2023-08-24 19:37:21 --> Language Class Initialized
ERROR - 2023-08-24 19:37:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:37:21 --> Config Class Initialized
INFO - 2023-08-24 19:37:22 --> Config Class Initialized
INFO - 2023-08-24 19:37:22 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:37:22 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:37:22 --> Utf8 Class Initialized
INFO - 2023-08-24 19:37:22 --> URI Class Initialized
INFO - 2023-08-24 19:37:22 --> Router Class Initialized
INFO - 2023-08-24 19:37:22 --> Output Class Initialized
INFO - 2023-08-24 19:37:22 --> Security Class Initialized
DEBUG - 2023-08-24 19:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:37:22 --> Input Class Initialized
INFO - 2023-08-24 19:37:22 --> Language Class Initialized
ERROR - 2023-08-24 19:37:22 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:37:22 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:37:22 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:37:22 --> Utf8 Class Initialized
INFO - 2023-08-24 19:37:22 --> URI Class Initialized
INFO - 2023-08-24 19:37:22 --> Router Class Initialized
INFO - 2023-08-24 19:37:22 --> Output Class Initialized
INFO - 2023-08-24 19:37:22 --> Security Class Initialized
DEBUG - 2023-08-24 19:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:37:22 --> Input Class Initialized
INFO - 2023-08-24 19:37:22 --> Language Class Initialized
ERROR - 2023-08-24 19:37:22 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:37:22 --> Config Class Initialized
INFO - 2023-08-24 19:37:22 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:37:22 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:37:22 --> Utf8 Class Initialized
INFO - 2023-08-24 19:37:22 --> URI Class Initialized
INFO - 2023-08-24 19:37:22 --> Router Class Initialized
INFO - 2023-08-24 19:37:22 --> Output Class Initialized
INFO - 2023-08-24 19:37:22 --> Security Class Initialized
DEBUG - 2023-08-24 19:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:37:22 --> Input Class Initialized
INFO - 2023-08-24 19:37:22 --> Language Class Initialized
ERROR - 2023-08-24 19:37:22 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:37:22 --> Config Class Initialized
INFO - 2023-08-24 19:37:22 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:37:22 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:37:22 --> Utf8 Class Initialized
INFO - 2023-08-24 19:37:22 --> URI Class Initialized
INFO - 2023-08-24 19:37:22 --> Router Class Initialized
INFO - 2023-08-24 19:37:22 --> Output Class Initialized
INFO - 2023-08-24 19:37:22 --> Security Class Initialized
DEBUG - 2023-08-24 19:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:37:22 --> Input Class Initialized
INFO - 2023-08-24 19:37:23 --> Language Class Initialized
ERROR - 2023-08-24 19:37:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:37:23 --> Config Class Initialized
INFO - 2023-08-24 19:37:23 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:37:23 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:37:23 --> Utf8 Class Initialized
INFO - 2023-08-24 19:37:23 --> URI Class Initialized
INFO - 2023-08-24 19:37:23 --> Router Class Initialized
INFO - 2023-08-24 19:37:23 --> Output Class Initialized
INFO - 2023-08-24 19:37:23 --> Security Class Initialized
DEBUG - 2023-08-24 19:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:37:23 --> Input Class Initialized
INFO - 2023-08-24 19:37:23 --> Language Class Initialized
ERROR - 2023-08-24 19:37:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:37:23 --> Config Class Initialized
INFO - 2023-08-24 19:37:23 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:37:23 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:37:23 --> Utf8 Class Initialized
INFO - 2023-08-24 19:37:23 --> URI Class Initialized
INFO - 2023-08-24 19:37:23 --> Router Class Initialized
INFO - 2023-08-24 19:37:23 --> Output Class Initialized
INFO - 2023-08-24 19:37:23 --> Security Class Initialized
DEBUG - 2023-08-24 19:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:37:23 --> Input Class Initialized
INFO - 2023-08-24 19:37:23 --> Language Class Initialized
ERROR - 2023-08-24 19:37:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:37:30 --> Config Class Initialized
INFO - 2023-08-24 19:37:30 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:37:30 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:37:30 --> Utf8 Class Initialized
INFO - 2023-08-24 19:37:30 --> URI Class Initialized
INFO - 2023-08-24 19:37:30 --> Router Class Initialized
INFO - 2023-08-24 19:37:30 --> Output Class Initialized
INFO - 2023-08-24 19:37:30 --> Security Class Initialized
DEBUG - 2023-08-24 19:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:37:30 --> Input Class Initialized
INFO - 2023-08-24 19:37:30 --> Language Class Initialized
INFO - 2023-08-24 19:37:30 --> Loader Class Initialized
INFO - 2023-08-24 19:37:30 --> Helper loaded: url_helper
INFO - 2023-08-24 19:37:30 --> Helper loaded: file_helper
INFO - 2023-08-24 19:37:30 --> Database Driver Class Initialized
INFO - 2023-08-24 19:37:30 --> Email Class Initialized
DEBUG - 2023-08-24 19:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:37:30 --> Controller Class Initialized
INFO - 2023-08-24 19:37:31 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:37:31 --> Model "Home_model" initialized
INFO - 2023-08-24 19:37:31 --> Helper loaded: download_helper
INFO - 2023-08-24 19:37:31 --> Helper loaded: form_helper
INFO - 2023-08-24 19:37:31 --> Form Validation Class Initialized
INFO - 2023-08-24 19:37:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:37:31 --> Final output sent to browser
DEBUG - 2023-08-24 19:37:31 --> Total execution time: 0.9711
INFO - 2023-08-24 19:38:28 --> Config Class Initialized
INFO - 2023-08-24 19:38:28 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:38:28 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:38:28 --> Utf8 Class Initialized
INFO - 2023-08-24 19:38:28 --> URI Class Initialized
INFO - 2023-08-24 19:38:28 --> Router Class Initialized
INFO - 2023-08-24 19:38:28 --> Output Class Initialized
INFO - 2023-08-24 19:38:28 --> Security Class Initialized
DEBUG - 2023-08-24 19:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:38:28 --> Input Class Initialized
INFO - 2023-08-24 19:38:28 --> Language Class Initialized
INFO - 2023-08-24 19:38:28 --> Loader Class Initialized
INFO - 2023-08-24 19:38:28 --> Helper loaded: url_helper
INFO - 2023-08-24 19:38:28 --> Helper loaded: file_helper
INFO - 2023-08-24 19:38:28 --> Database Driver Class Initialized
INFO - 2023-08-24 19:38:28 --> Email Class Initialized
DEBUG - 2023-08-24 19:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:38:28 --> Controller Class Initialized
INFO - 2023-08-24 19:38:28 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:38:28 --> Model "Home_model" initialized
INFO - 2023-08-24 19:38:28 --> Helper loaded: download_helper
INFO - 2023-08-24 19:38:28 --> Helper loaded: form_helper
INFO - 2023-08-24 19:38:28 --> Form Validation Class Initialized
INFO - 2023-08-24 19:38:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:38:28 --> Final output sent to browser
DEBUG - 2023-08-24 19:38:28 --> Total execution time: 0.4614
INFO - 2023-08-24 19:38:31 --> Config Class Initialized
INFO - 2023-08-24 19:38:31 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:38:31 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:38:31 --> Utf8 Class Initialized
INFO - 2023-08-24 19:38:31 --> URI Class Initialized
INFO - 2023-08-24 19:38:31 --> Router Class Initialized
INFO - 2023-08-24 19:38:31 --> Output Class Initialized
INFO - 2023-08-24 19:38:31 --> Security Class Initialized
DEBUG - 2023-08-24 19:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:38:31 --> Input Class Initialized
INFO - 2023-08-24 19:38:31 --> Language Class Initialized
INFO - 2023-08-24 19:38:31 --> Loader Class Initialized
INFO - 2023-08-24 19:38:31 --> Helper loaded: url_helper
INFO - 2023-08-24 19:38:31 --> Helper loaded: file_helper
INFO - 2023-08-24 19:38:31 --> Database Driver Class Initialized
INFO - 2023-08-24 19:38:31 --> Email Class Initialized
DEBUG - 2023-08-24 19:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:38:31 --> Controller Class Initialized
INFO - 2023-08-24 19:38:31 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:38:31 --> Model "Home_model" initialized
INFO - 2023-08-24 19:38:31 --> Helper loaded: download_helper
INFO - 2023-08-24 19:38:31 --> Helper loaded: form_helper
INFO - 2023-08-24 19:38:31 --> Form Validation Class Initialized
INFO - 2023-08-24 19:38:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:38:31 --> Final output sent to browser
DEBUG - 2023-08-24 19:38:31 --> Total execution time: 0.0511
INFO - 2023-08-24 19:38:52 --> Config Class Initialized
INFO - 2023-08-24 19:38:52 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:38:52 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:38:52 --> Utf8 Class Initialized
INFO - 2023-08-24 19:38:52 --> URI Class Initialized
INFO - 2023-08-24 19:38:52 --> Router Class Initialized
INFO - 2023-08-24 19:38:52 --> Output Class Initialized
INFO - 2023-08-24 19:38:52 --> Security Class Initialized
DEBUG - 2023-08-24 19:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:38:52 --> Input Class Initialized
INFO - 2023-08-24 19:38:52 --> Language Class Initialized
INFO - 2023-08-24 19:38:52 --> Loader Class Initialized
INFO - 2023-08-24 19:38:52 --> Helper loaded: url_helper
INFO - 2023-08-24 19:38:52 --> Helper loaded: file_helper
INFO - 2023-08-24 19:38:52 --> Database Driver Class Initialized
INFO - 2023-08-24 19:38:52 --> Email Class Initialized
DEBUG - 2023-08-24 19:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:38:52 --> Controller Class Initialized
INFO - 2023-08-24 19:38:52 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:38:52 --> Model "Home_model" initialized
INFO - 2023-08-24 19:38:52 --> Helper loaded: download_helper
INFO - 2023-08-24 19:38:52 --> Helper loaded: form_helper
INFO - 2023-08-24 19:38:52 --> Form Validation Class Initialized
INFO - 2023-08-24 19:38:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:38:53 --> Final output sent to browser
DEBUG - 2023-08-24 19:38:53 --> Total execution time: 0.1653
INFO - 2023-08-24 19:39:02 --> Config Class Initialized
INFO - 2023-08-24 19:39:02 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:39:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:39:02 --> Utf8 Class Initialized
INFO - 2023-08-24 19:39:02 --> URI Class Initialized
INFO - 2023-08-24 19:39:02 --> Router Class Initialized
INFO - 2023-08-24 19:39:02 --> Output Class Initialized
INFO - 2023-08-24 19:39:02 --> Security Class Initialized
DEBUG - 2023-08-24 19:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:39:02 --> Input Class Initialized
INFO - 2023-08-24 19:39:02 --> Language Class Initialized
INFO - 2023-08-24 19:39:02 --> Loader Class Initialized
INFO - 2023-08-24 19:39:02 --> Helper loaded: url_helper
INFO - 2023-08-24 19:39:02 --> Helper loaded: file_helper
INFO - 2023-08-24 19:39:02 --> Database Driver Class Initialized
INFO - 2023-08-24 19:39:02 --> Email Class Initialized
DEBUG - 2023-08-24 19:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:39:02 --> Controller Class Initialized
INFO - 2023-08-24 19:39:02 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:39:02 --> Model "Home_model" initialized
INFO - 2023-08-24 19:39:02 --> Helper loaded: download_helper
INFO - 2023-08-24 19:39:02 --> Helper loaded: form_helper
INFO - 2023-08-24 19:39:02 --> Form Validation Class Initialized
INFO - 2023-08-24 19:39:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:39:02 --> Final output sent to browser
DEBUG - 2023-08-24 19:39:02 --> Total execution time: 0.0677
INFO - 2023-08-24 19:39:03 --> Config Class Initialized
INFO - 2023-08-24 19:39:03 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:39:03 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:39:03 --> Utf8 Class Initialized
INFO - 2023-08-24 19:39:03 --> URI Class Initialized
INFO - 2023-08-24 19:39:03 --> Router Class Initialized
INFO - 2023-08-24 19:39:03 --> Output Class Initialized
INFO - 2023-08-24 19:39:03 --> Security Class Initialized
DEBUG - 2023-08-24 19:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:39:03 --> Input Class Initialized
INFO - 2023-08-24 19:39:03 --> Language Class Initialized
ERROR - 2023-08-24 19:39:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:39:04 --> Config Class Initialized
INFO - 2023-08-24 19:39:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:39:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:39:04 --> Utf8 Class Initialized
INFO - 2023-08-24 19:39:04 --> URI Class Initialized
INFO - 2023-08-24 19:39:04 --> Router Class Initialized
INFO - 2023-08-24 19:39:04 --> Output Class Initialized
INFO - 2023-08-24 19:39:04 --> Security Class Initialized
DEBUG - 2023-08-24 19:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:39:04 --> Input Class Initialized
INFO - 2023-08-24 19:39:04 --> Language Class Initialized
ERROR - 2023-08-24 19:39:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:39:04 --> Config Class Initialized
INFO - 2023-08-24 19:39:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:39:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:39:04 --> Utf8 Class Initialized
INFO - 2023-08-24 19:39:04 --> URI Class Initialized
INFO - 2023-08-24 19:39:04 --> Router Class Initialized
INFO - 2023-08-24 19:39:04 --> Output Class Initialized
INFO - 2023-08-24 19:39:04 --> Security Class Initialized
DEBUG - 2023-08-24 19:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:39:04 --> Input Class Initialized
INFO - 2023-08-24 19:39:04 --> Language Class Initialized
ERROR - 2023-08-24 19:39:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:39:04 --> Config Class Initialized
INFO - 2023-08-24 19:39:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:39:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:39:04 --> Utf8 Class Initialized
INFO - 2023-08-24 19:39:04 --> URI Class Initialized
INFO - 2023-08-24 19:39:04 --> Router Class Initialized
INFO - 2023-08-24 19:39:04 --> Output Class Initialized
INFO - 2023-08-24 19:39:04 --> Security Class Initialized
DEBUG - 2023-08-24 19:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:39:04 --> Input Class Initialized
INFO - 2023-08-24 19:39:04 --> Language Class Initialized
ERROR - 2023-08-24 19:39:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:39:04 --> Config Class Initialized
INFO - 2023-08-24 19:39:04 --> Config Class Initialized
INFO - 2023-08-24 19:39:04 --> Hooks Class Initialized
INFO - 2023-08-24 19:39:04 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:39:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:39:04 --> Utf8 Class Initialized
INFO - 2023-08-24 19:39:04 --> URI Class Initialized
INFO - 2023-08-24 19:39:04 --> Router Class Initialized
INFO - 2023-08-24 19:39:04 --> Output Class Initialized
INFO - 2023-08-24 19:39:04 --> Security Class Initialized
DEBUG - 2023-08-24 19:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:39:04 --> Input Class Initialized
INFO - 2023-08-24 19:39:04 --> Language Class Initialized
ERROR - 2023-08-24 19:39:04 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-24 19:39:04 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:39:04 --> Utf8 Class Initialized
INFO - 2023-08-24 19:39:04 --> URI Class Initialized
INFO - 2023-08-24 19:39:04 --> Router Class Initialized
INFO - 2023-08-24 19:39:04 --> Output Class Initialized
INFO - 2023-08-24 19:39:04 --> Security Class Initialized
DEBUG - 2023-08-24 19:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:39:04 --> Input Class Initialized
INFO - 2023-08-24 19:39:04 --> Language Class Initialized
ERROR - 2023-08-24 19:39:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:41:12 --> Config Class Initialized
INFO - 2023-08-24 19:41:12 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:41:12 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:41:12 --> Utf8 Class Initialized
INFO - 2023-08-24 19:41:12 --> URI Class Initialized
INFO - 2023-08-24 19:41:12 --> Router Class Initialized
INFO - 2023-08-24 19:41:12 --> Output Class Initialized
INFO - 2023-08-24 19:41:12 --> Security Class Initialized
DEBUG - 2023-08-24 19:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:41:12 --> Input Class Initialized
INFO - 2023-08-24 19:41:12 --> Language Class Initialized
INFO - 2023-08-24 19:41:12 --> Loader Class Initialized
INFO - 2023-08-24 19:41:12 --> Helper loaded: url_helper
INFO - 2023-08-24 19:41:12 --> Helper loaded: file_helper
INFO - 2023-08-24 19:41:12 --> Database Driver Class Initialized
INFO - 2023-08-24 19:41:12 --> Email Class Initialized
DEBUG - 2023-08-24 19:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:41:12 --> Controller Class Initialized
INFO - 2023-08-24 19:41:12 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:41:12 --> Model "Home_model" initialized
INFO - 2023-08-24 19:41:12 --> Helper loaded: download_helper
INFO - 2023-08-24 19:41:12 --> Helper loaded: form_helper
INFO - 2023-08-24 19:41:12 --> Form Validation Class Initialized
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "tag" C:\xampp\htdocs\dw\application\views\home\training.php 215
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "rating" C:\xampp\htdocs\dw\application\views\home\training.php 219
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "learners" C:\xampp\htdocs\dw\application\views\home\training.php 220
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "tag" C:\xampp\htdocs\dw\application\views\home\training.php 215
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "rating" C:\xampp\htdocs\dw\application\views\home\training.php 219
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "learners" C:\xampp\htdocs\dw\application\views\home\training.php 220
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "tag" C:\xampp\htdocs\dw\application\views\home\training.php 215
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "rating" C:\xampp\htdocs\dw\application\views\home\training.php 219
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "learners" C:\xampp\htdocs\dw\application\views\home\training.php 220
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "tag" C:\xampp\htdocs\dw\application\views\home\training.php 215
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "rating" C:\xampp\htdocs\dw\application\views\home\training.php 219
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "learners" C:\xampp\htdocs\dw\application\views\home\training.php 220
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "tag" C:\xampp\htdocs\dw\application\views\home\training.php 215
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "rating" C:\xampp\htdocs\dw\application\views\home\training.php 219
ERROR - 2023-08-24 19:41:12 --> Severity: Warning --> Undefined array key "learners" C:\xampp\htdocs\dw\application\views\home\training.php 220
INFO - 2023-08-24 19:41:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:41:12 --> Final output sent to browser
DEBUG - 2023-08-24 19:41:12 --> Total execution time: 0.3788
INFO - 2023-08-24 19:41:13 --> Config Class Initialized
INFO - 2023-08-24 19:41:13 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:41:13 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:41:13 --> Utf8 Class Initialized
INFO - 2023-08-24 19:41:13 --> URI Class Initialized
INFO - 2023-08-24 19:41:13 --> Router Class Initialized
INFO - 2023-08-24 19:41:13 --> Output Class Initialized
INFO - 2023-08-24 19:41:13 --> Security Class Initialized
DEBUG - 2023-08-24 19:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:41:13 --> Input Class Initialized
INFO - 2023-08-24 19:41:13 --> Language Class Initialized
ERROR - 2023-08-24 19:41:13 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:41:13 --> Config Class Initialized
INFO - 2023-08-24 19:41:13 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:41:13 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:41:13 --> Utf8 Class Initialized
INFO - 2023-08-24 19:41:13 --> URI Class Initialized
INFO - 2023-08-24 19:41:13 --> Router Class Initialized
INFO - 2023-08-24 19:41:13 --> Output Class Initialized
INFO - 2023-08-24 19:41:13 --> Security Class Initialized
DEBUG - 2023-08-24 19:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:41:13 --> Input Class Initialized
INFO - 2023-08-24 19:41:13 --> Language Class Initialized
ERROR - 2023-08-24 19:41:13 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:41:13 --> Config Class Initialized
INFO - 2023-08-24 19:41:13 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:41:14 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:41:14 --> Utf8 Class Initialized
INFO - 2023-08-24 19:41:14 --> URI Class Initialized
INFO - 2023-08-24 19:41:14 --> Router Class Initialized
INFO - 2023-08-24 19:41:14 --> Output Class Initialized
INFO - 2023-08-24 19:41:14 --> Security Class Initialized
DEBUG - 2023-08-24 19:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:41:14 --> Input Class Initialized
INFO - 2023-08-24 19:41:14 --> Language Class Initialized
ERROR - 2023-08-24 19:41:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:41:14 --> Config Class Initialized
INFO - 2023-08-24 19:41:14 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:41:14 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:41:14 --> Utf8 Class Initialized
INFO - 2023-08-24 19:41:14 --> URI Class Initialized
INFO - 2023-08-24 19:41:14 --> Router Class Initialized
INFO - 2023-08-24 19:41:14 --> Output Class Initialized
INFO - 2023-08-24 19:41:14 --> Security Class Initialized
DEBUG - 2023-08-24 19:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:41:14 --> Input Class Initialized
INFO - 2023-08-24 19:41:14 --> Language Class Initialized
ERROR - 2023-08-24 19:41:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:41:14 --> Config Class Initialized
INFO - 2023-08-24 19:41:14 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:41:14 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:41:14 --> Utf8 Class Initialized
INFO - 2023-08-24 19:41:14 --> URI Class Initialized
INFO - 2023-08-24 19:41:14 --> Router Class Initialized
INFO - 2023-08-24 19:41:14 --> Output Class Initialized
INFO - 2023-08-24 19:41:14 --> Security Class Initialized
DEBUG - 2023-08-24 19:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:41:14 --> Input Class Initialized
INFO - 2023-08-24 19:41:14 --> Language Class Initialized
ERROR - 2023-08-24 19:41:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:41:14 --> Config Class Initialized
INFO - 2023-08-24 19:41:14 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:41:14 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:41:14 --> Utf8 Class Initialized
INFO - 2023-08-24 19:41:14 --> URI Class Initialized
INFO - 2023-08-24 19:41:14 --> Router Class Initialized
INFO - 2023-08-24 19:41:14 --> Output Class Initialized
INFO - 2023-08-24 19:41:14 --> Security Class Initialized
DEBUG - 2023-08-24 19:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:41:14 --> Input Class Initialized
INFO - 2023-08-24 19:41:14 --> Language Class Initialized
ERROR - 2023-08-24 19:41:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:41:14 --> Config Class Initialized
INFO - 2023-08-24 19:41:14 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:41:14 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:41:14 --> Utf8 Class Initialized
INFO - 2023-08-24 19:41:14 --> URI Class Initialized
INFO - 2023-08-24 19:41:14 --> Router Class Initialized
INFO - 2023-08-24 19:41:14 --> Output Class Initialized
INFO - 2023-08-24 19:41:14 --> Security Class Initialized
DEBUG - 2023-08-24 19:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:41:14 --> Input Class Initialized
INFO - 2023-08-24 19:41:14 --> Language Class Initialized
ERROR - 2023-08-24 19:41:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:42:27 --> Config Class Initialized
INFO - 2023-08-24 19:42:27 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:42:27 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:27 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:27 --> URI Class Initialized
INFO - 2023-08-24 19:42:28 --> Router Class Initialized
INFO - 2023-08-24 19:42:28 --> Output Class Initialized
INFO - 2023-08-24 19:42:28 --> Security Class Initialized
DEBUG - 2023-08-24 19:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:42:28 --> Input Class Initialized
INFO - 2023-08-24 19:42:28 --> Language Class Initialized
INFO - 2023-08-24 19:42:28 --> Loader Class Initialized
INFO - 2023-08-24 19:42:28 --> Helper loaded: url_helper
INFO - 2023-08-24 19:42:28 --> Helper loaded: file_helper
INFO - 2023-08-24 19:42:28 --> Database Driver Class Initialized
INFO - 2023-08-24 19:42:28 --> Email Class Initialized
DEBUG - 2023-08-24 19:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:42:28 --> Controller Class Initialized
INFO - 2023-08-24 19:42:28 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:42:28 --> Model "Home_model" initialized
INFO - 2023-08-24 19:42:28 --> Helper loaded: download_helper
INFO - 2023-08-24 19:42:28 --> Helper loaded: form_helper
INFO - 2023-08-24 19:42:28 --> Form Validation Class Initialized
INFO - 2023-08-24 19:42:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:42:28 --> Final output sent to browser
DEBUG - 2023-08-24 19:42:28 --> Total execution time: 0.6117
INFO - 2023-08-24 19:42:28 --> Config Class Initialized
INFO - 2023-08-24 19:42:28 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:42:28 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:28 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:28 --> URI Class Initialized
INFO - 2023-08-24 19:42:28 --> Router Class Initialized
INFO - 2023-08-24 19:42:28 --> Output Class Initialized
INFO - 2023-08-24 19:42:28 --> Security Class Initialized
DEBUG - 2023-08-24 19:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:42:28 --> Input Class Initialized
INFO - 2023-08-24 19:42:28 --> Language Class Initialized
ERROR - 2023-08-24 19:42:28 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:42:29 --> Config Class Initialized
INFO - 2023-08-24 19:42:29 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:42:29 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:29 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:29 --> URI Class Initialized
INFO - 2023-08-24 19:42:29 --> Router Class Initialized
INFO - 2023-08-24 19:42:29 --> Output Class Initialized
INFO - 2023-08-24 19:42:29 --> Security Class Initialized
DEBUG - 2023-08-24 19:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:42:29 --> Input Class Initialized
INFO - 2023-08-24 19:42:29 --> Language Class Initialized
ERROR - 2023-08-24 19:42:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:42:29 --> Config Class Initialized
INFO - 2023-08-24 19:42:29 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:42:29 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:29 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:29 --> URI Class Initialized
INFO - 2023-08-24 19:42:29 --> Router Class Initialized
INFO - 2023-08-24 19:42:29 --> Output Class Initialized
INFO - 2023-08-24 19:42:29 --> Security Class Initialized
DEBUG - 2023-08-24 19:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:42:29 --> Input Class Initialized
INFO - 2023-08-24 19:42:29 --> Language Class Initialized
ERROR - 2023-08-24 19:42:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:42:29 --> Config Class Initialized
INFO - 2023-08-24 19:42:29 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:42:29 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:29 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:29 --> URI Class Initialized
INFO - 2023-08-24 19:42:29 --> Router Class Initialized
INFO - 2023-08-24 19:42:29 --> Output Class Initialized
INFO - 2023-08-24 19:42:29 --> Security Class Initialized
DEBUG - 2023-08-24 19:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:42:29 --> Input Class Initialized
INFO - 2023-08-24 19:42:29 --> Language Class Initialized
ERROR - 2023-08-24 19:42:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:42:29 --> Config Class Initialized
INFO - 2023-08-24 19:42:29 --> Config Class Initialized
INFO - 2023-08-24 19:42:29 --> Config Class Initialized
INFO - 2023-08-24 19:42:29 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:42:29 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:29 --> Hooks Class Initialized
INFO - 2023-08-24 19:42:29 --> Config Class Initialized
INFO - 2023-08-24 19:42:29 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:30 --> URI Class Initialized
INFO - 2023-08-24 19:42:30 --> Hooks Class Initialized
INFO - 2023-08-24 19:42:30 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:42:30 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:30 --> Router Class Initialized
DEBUG - 2023-08-24 19:42:30 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:30 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:30 --> URI Class Initialized
INFO - 2023-08-24 19:42:30 --> Output Class Initialized
INFO - 2023-08-24 19:42:30 --> Utf8 Class Initialized
DEBUG - 2023-08-24 19:42:30 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:30 --> URI Class Initialized
INFO - 2023-08-24 19:42:30 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:30 --> Security Class Initialized
DEBUG - 2023-08-24 19:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:42:30 --> Router Class Initialized
INFO - 2023-08-24 19:42:30 --> Output Class Initialized
INFO - 2023-08-24 19:42:30 --> Input Class Initialized
INFO - 2023-08-24 19:42:30 --> Router Class Initialized
INFO - 2023-08-24 19:42:30 --> URI Class Initialized
INFO - 2023-08-24 19:42:30 --> Output Class Initialized
INFO - 2023-08-24 19:42:30 --> Security Class Initialized
INFO - 2023-08-24 19:42:30 --> Router Class Initialized
INFO - 2023-08-24 19:42:30 --> Language Class Initialized
DEBUG - 2023-08-24 19:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:42:30 --> Security Class Initialized
ERROR - 2023-08-24 19:42:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:42:30 --> Input Class Initialized
INFO - 2023-08-24 19:42:30 --> Language Class Initialized
INFO - 2023-08-24 19:42:30 --> Output Class Initialized
DEBUG - 2023-08-24 19:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:42:30 --> Security Class Initialized
ERROR - 2023-08-24 19:42:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:42:30 --> Input Class Initialized
DEBUG - 2023-08-24 19:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:42:30 --> Language Class Initialized
INFO - 2023-08-24 19:42:30 --> Input Class Initialized
ERROR - 2023-08-24 19:42:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:42:30 --> Language Class Initialized
ERROR - 2023-08-24 19:42:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:42:49 --> Config Class Initialized
INFO - 2023-08-24 19:42:49 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:42:49 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:49 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:49 --> URI Class Initialized
INFO - 2023-08-24 19:42:49 --> Router Class Initialized
INFO - 2023-08-24 19:42:49 --> Output Class Initialized
INFO - 2023-08-24 19:42:49 --> Security Class Initialized
DEBUG - 2023-08-24 19:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:42:49 --> Input Class Initialized
INFO - 2023-08-24 19:42:49 --> Language Class Initialized
INFO - 2023-08-24 19:42:49 --> Loader Class Initialized
INFO - 2023-08-24 19:42:49 --> Helper loaded: url_helper
INFO - 2023-08-24 19:42:49 --> Helper loaded: file_helper
INFO - 2023-08-24 19:42:49 --> Database Driver Class Initialized
INFO - 2023-08-24 19:42:49 --> Email Class Initialized
DEBUG - 2023-08-24 19:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:42:49 --> Controller Class Initialized
INFO - 2023-08-24 19:42:49 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:42:49 --> Model "Home_model" initialized
INFO - 2023-08-24 19:42:49 --> Helper loaded: download_helper
INFO - 2023-08-24 19:42:49 --> Helper loaded: form_helper
INFO - 2023-08-24 19:42:49 --> Form Validation Class Initialized
INFO - 2023-08-24 19:42:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:42:49 --> Final output sent to browser
DEBUG - 2023-08-24 19:42:49 --> Total execution time: 0.4583
INFO - 2023-08-24 19:42:50 --> Config Class Initialized
INFO - 2023-08-24 19:42:50 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:42:50 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:50 --> Config Class Initialized
INFO - 2023-08-24 19:42:50 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:50 --> Config Class Initialized
INFO - 2023-08-24 19:42:51 --> Config Class Initialized
INFO - 2023-08-24 19:42:51 --> Hooks Class Initialized
INFO - 2023-08-24 19:42:51 --> Hooks Class Initialized
INFO - 2023-08-24 19:42:51 --> Hooks Class Initialized
INFO - 2023-08-24 19:42:51 --> URI Class Initialized
DEBUG - 2023-08-24 19:42:51 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:51 --> Config Class Initialized
DEBUG - 2023-08-24 19:42:51 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:51 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:51 --> URI Class Initialized
DEBUG - 2023-08-24 19:42:51 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:51 --> Router Class Initialized
INFO - 2023-08-24 19:42:51 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:51 --> Hooks Class Initialized
INFO - 2023-08-24 19:42:51 --> Router Class Initialized
INFO - 2023-08-24 19:42:51 --> URI Class Initialized
DEBUG - 2023-08-24 19:42:51 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:51 --> Router Class Initialized
INFO - 2023-08-24 19:42:51 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:51 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:51 --> Output Class Initialized
INFO - 2023-08-24 19:42:51 --> Output Class Initialized
INFO - 2023-08-24 19:42:51 --> Output Class Initialized
INFO - 2023-08-24 19:42:51 --> URI Class Initialized
INFO - 2023-08-24 19:42:51 --> Config Class Initialized
INFO - 2023-08-24 19:42:51 --> Security Class Initialized
INFO - 2023-08-24 19:42:51 --> Security Class Initialized
DEBUG - 2023-08-24 19:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:42:51 --> Router Class Initialized
INFO - 2023-08-24 19:42:51 --> Security Class Initialized
INFO - 2023-08-24 19:42:51 --> Hooks Class Initialized
INFO - 2023-08-24 19:42:51 --> URI Class Initialized
DEBUG - 2023-08-24 19:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-24 19:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:42:51 --> Input Class Initialized
DEBUG - 2023-08-24 19:42:51 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:42:51 --> Input Class Initialized
INFO - 2023-08-24 19:42:51 --> Router Class Initialized
INFO - 2023-08-24 19:42:51 --> Output Class Initialized
INFO - 2023-08-24 19:42:51 --> Language Class Initialized
INFO - 2023-08-24 19:42:51 --> Language Class Initialized
INFO - 2023-08-24 19:42:51 --> Utf8 Class Initialized
INFO - 2023-08-24 19:42:51 --> Output Class Initialized
ERROR - 2023-08-24 19:42:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:42:51 --> Input Class Initialized
ERROR - 2023-08-24 19:42:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:42:51 --> Security Class Initialized
INFO - 2023-08-24 19:42:51 --> Security Class Initialized
INFO - 2023-08-24 19:42:51 --> URI Class Initialized
INFO - 2023-08-24 19:42:51 --> Language Class Initialized
DEBUG - 2023-08-24 19:42:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-24 19:42:51 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-24 19:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:42:51 --> Router Class Initialized
INFO - 2023-08-24 19:42:51 --> Input Class Initialized
INFO - 2023-08-24 19:42:51 --> Input Class Initialized
INFO - 2023-08-24 19:42:51 --> Language Class Initialized
INFO - 2023-08-24 19:42:51 --> Output Class Initialized
ERROR - 2023-08-24 19:42:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:42:51 --> Language Class Initialized
INFO - 2023-08-24 19:42:51 --> Security Class Initialized
ERROR - 2023-08-24 19:42:51 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-24 19:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:42:51 --> Input Class Initialized
INFO - 2023-08-24 19:42:51 --> Language Class Initialized
ERROR - 2023-08-24 19:42:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:43:00 --> Config Class Initialized
INFO - 2023-08-24 19:43:00 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:43:00 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:43:00 --> Utf8 Class Initialized
INFO - 2023-08-24 19:43:00 --> URI Class Initialized
INFO - 2023-08-24 19:43:00 --> Router Class Initialized
INFO - 2023-08-24 19:43:00 --> Output Class Initialized
INFO - 2023-08-24 19:43:00 --> Security Class Initialized
DEBUG - 2023-08-24 19:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:43:00 --> Input Class Initialized
INFO - 2023-08-24 19:43:00 --> Language Class Initialized
ERROR - 2023-08-24 19:43:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 19:43:01 --> Config Class Initialized
INFO - 2023-08-24 19:43:01 --> Config Class Initialized
INFO - 2023-08-24 19:43:01 --> Hooks Class Initialized
INFO - 2023-08-24 19:43:01 --> Config Class Initialized
INFO - 2023-08-24 19:43:01 --> Hooks Class Initialized
INFO - 2023-08-24 19:43:01 --> Config Class Initialized
DEBUG - 2023-08-24 19:43:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:43:02 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:43:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:43:02 --> Config Class Initialized
INFO - 2023-08-24 19:43:02 --> Hooks Class Initialized
INFO - 2023-08-24 19:43:02 --> Config Class Initialized
INFO - 2023-08-24 19:43:02 --> Utf8 Class Initialized
INFO - 2023-08-24 19:43:02 --> Hooks Class Initialized
INFO - 2023-08-24 19:43:02 --> URI Class Initialized
DEBUG - 2023-08-24 19:43:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:43:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:43:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:43:02 --> Utf8 Class Initialized
INFO - 2023-08-24 19:43:02 --> URI Class Initialized
INFO - 2023-08-24 19:43:02 --> Router Class Initialized
INFO - 2023-08-24 19:43:02 --> Output Class Initialized
INFO - 2023-08-24 19:43:02 --> Security Class Initialized
DEBUG - 2023-08-24 19:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:43:02 --> Input Class Initialized
INFO - 2023-08-24 19:43:02 --> Language Class Initialized
ERROR - 2023-08-24 19:43:02 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 19:43:02 --> Hooks Class Initialized
INFO - 2023-08-24 19:43:02 --> Utf8 Class Initialized
INFO - 2023-08-24 19:43:02 --> Utf8 Class Initialized
INFO - 2023-08-24 19:43:02 --> Router Class Initialized
INFO - 2023-08-24 19:43:02 --> Utf8 Class Initialized
DEBUG - 2023-08-24 19:43:02 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:43:02 --> URI Class Initialized
INFO - 2023-08-24 19:43:02 --> URI Class Initialized
INFO - 2023-08-24 19:43:02 --> Router Class Initialized
INFO - 2023-08-24 19:43:02 --> Output Class Initialized
INFO - 2023-08-24 19:43:02 --> URI Class Initialized
INFO - 2023-08-24 19:43:02 --> Router Class Initialized
INFO - 2023-08-24 19:43:02 --> Output Class Initialized
INFO - 2023-08-24 19:43:02 --> Utf8 Class Initialized
INFO - 2023-08-24 19:43:02 --> URI Class Initialized
INFO - 2023-08-24 19:43:02 --> Output Class Initialized
INFO - 2023-08-24 19:43:02 --> Router Class Initialized
INFO - 2023-08-24 19:43:02 --> Security Class Initialized
INFO - 2023-08-24 19:43:02 --> Security Class Initialized
INFO - 2023-08-24 19:43:02 --> Router Class Initialized
DEBUG - 2023-08-24 19:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:43:02 --> Output Class Initialized
DEBUG - 2023-08-24 19:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:43:02 --> Security Class Initialized
INFO - 2023-08-24 19:43:02 --> Security Class Initialized
INFO - 2023-08-24 19:43:02 --> Input Class Initialized
INFO - 2023-08-24 19:43:02 --> Input Class Initialized
INFO - 2023-08-24 19:43:02 --> Output Class Initialized
DEBUG - 2023-08-24 19:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:43:02 --> Security Class Initialized
INFO - 2023-08-24 19:43:02 --> Language Class Initialized
INFO - 2023-08-24 19:43:02 --> Language Class Initialized
INFO - 2023-08-24 19:43:02 --> Input Class Initialized
ERROR - 2023-08-24 19:43:02 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-24 19:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:43:02 --> Language Class Initialized
DEBUG - 2023-08-24 19:43:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-24 19:43:02 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-24 19:43:02 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 19:43:02 --> Input Class Initialized
INFO - 2023-08-24 19:43:02 --> Input Class Initialized
INFO - 2023-08-24 19:43:02 --> Language Class Initialized
INFO - 2023-08-24 19:43:02 --> Language Class Initialized
ERROR - 2023-08-24 19:43:02 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-24 19:43:02 --> 404 Page Not Found: Assets/home
INFO - 2023-08-24 19:50:18 --> Config Class Initialized
INFO - 2023-08-24 19:50:18 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:50:19 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:50:19 --> Utf8 Class Initialized
INFO - 2023-08-24 19:50:19 --> URI Class Initialized
INFO - 2023-08-24 19:50:19 --> Router Class Initialized
INFO - 2023-08-24 19:50:19 --> Output Class Initialized
INFO - 2023-08-24 19:50:19 --> Security Class Initialized
DEBUG - 2023-08-24 19:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:50:19 --> Input Class Initialized
INFO - 2023-08-24 19:50:19 --> Language Class Initialized
INFO - 2023-08-24 19:50:19 --> Loader Class Initialized
INFO - 2023-08-24 19:50:19 --> Helper loaded: url_helper
INFO - 2023-08-24 19:50:19 --> Helper loaded: file_helper
INFO - 2023-08-24 19:50:19 --> Database Driver Class Initialized
INFO - 2023-08-24 19:50:19 --> Email Class Initialized
DEBUG - 2023-08-24 19:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:50:19 --> Controller Class Initialized
INFO - 2023-08-24 19:50:19 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:50:19 --> Model "Home_model" initialized
INFO - 2023-08-24 19:50:19 --> Helper loaded: download_helper
INFO - 2023-08-24 19:50:19 --> Helper loaded: form_helper
INFO - 2023-08-24 19:50:19 --> Form Validation Class Initialized
ERROR - 2023-08-24 19:50:19 --> Severity: error --> Exception: Unclosed '{' on line 237 C:\xampp\htdocs\dw\application\views\home\training.php 473
INFO - 2023-08-24 19:50:22 --> Config Class Initialized
INFO - 2023-08-24 19:50:22 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:50:22 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:50:22 --> Utf8 Class Initialized
INFO - 2023-08-24 19:50:22 --> URI Class Initialized
INFO - 2023-08-24 19:50:22 --> Router Class Initialized
INFO - 2023-08-24 19:50:22 --> Output Class Initialized
INFO - 2023-08-24 19:50:22 --> Security Class Initialized
DEBUG - 2023-08-24 19:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:50:22 --> Input Class Initialized
INFO - 2023-08-24 19:50:22 --> Language Class Initialized
INFO - 2023-08-24 19:50:22 --> Loader Class Initialized
INFO - 2023-08-24 19:50:22 --> Helper loaded: url_helper
INFO - 2023-08-24 19:50:22 --> Helper loaded: file_helper
INFO - 2023-08-24 19:50:22 --> Database Driver Class Initialized
INFO - 2023-08-24 19:50:22 --> Email Class Initialized
DEBUG - 2023-08-24 19:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:50:22 --> Controller Class Initialized
INFO - 2023-08-24 19:50:22 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:50:22 --> Model "Home_model" initialized
INFO - 2023-08-24 19:50:22 --> Helper loaded: download_helper
INFO - 2023-08-24 19:50:22 --> Helper loaded: form_helper
INFO - 2023-08-24 19:50:22 --> Form Validation Class Initialized
ERROR - 2023-08-24 19:50:22 --> Severity: error --> Exception: Unclosed '{' on line 237 C:\xampp\htdocs\dw\application\views\home\training.php 473
INFO - 2023-08-24 19:51:10 --> Config Class Initialized
INFO - 2023-08-24 19:51:10 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:10 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:10 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:10 --> URI Class Initialized
INFO - 2023-08-24 19:51:10 --> Router Class Initialized
INFO - 2023-08-24 19:51:10 --> Output Class Initialized
INFO - 2023-08-24 19:51:10 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:10 --> Input Class Initialized
INFO - 2023-08-24 19:51:10 --> Language Class Initialized
INFO - 2023-08-24 19:51:10 --> Loader Class Initialized
INFO - 2023-08-24 19:51:10 --> Helper loaded: url_helper
INFO - 2023-08-24 19:51:10 --> Helper loaded: file_helper
INFO - 2023-08-24 19:51:10 --> Database Driver Class Initialized
INFO - 2023-08-24 19:51:10 --> Email Class Initialized
DEBUG - 2023-08-24 19:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:51:10 --> Controller Class Initialized
INFO - 2023-08-24 19:51:10 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:51:10 --> Model "Home_model" initialized
INFO - 2023-08-24 19:51:10 --> Helper loaded: download_helper
INFO - 2023-08-24 19:51:10 --> Helper loaded: form_helper
INFO - 2023-08-24 19:51:10 --> Form Validation Class Initialized
INFO - 2023-08-24 19:51:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:51:11 --> Final output sent to browser
DEBUG - 2023-08-24 19:51:11 --> Total execution time: 0.2208
INFO - 2023-08-24 19:51:11 --> Config Class Initialized
INFO - 2023-08-24 19:51:11 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:11 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:11 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:11 --> URI Class Initialized
INFO - 2023-08-24 19:51:11 --> Router Class Initialized
INFO - 2023-08-24 19:51:11 --> Output Class Initialized
INFO - 2023-08-24 19:51:11 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:11 --> Input Class Initialized
INFO - 2023-08-24 19:51:11 --> Language Class Initialized
ERROR - 2023-08-24 19:51:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:51:11 --> Config Class Initialized
INFO - 2023-08-24 19:51:11 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:11 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:11 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:11 --> URI Class Initialized
INFO - 2023-08-24 19:51:11 --> Router Class Initialized
INFO - 2023-08-24 19:51:11 --> Output Class Initialized
INFO - 2023-08-24 19:51:11 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:11 --> Input Class Initialized
INFO - 2023-08-24 19:51:11 --> Language Class Initialized
ERROR - 2023-08-24 19:51:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:51:12 --> Config Class Initialized
INFO - 2023-08-24 19:51:12 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:12 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:12 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:12 --> URI Class Initialized
INFO - 2023-08-24 19:51:12 --> Router Class Initialized
INFO - 2023-08-24 19:51:12 --> Output Class Initialized
INFO - 2023-08-24 19:51:12 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:12 --> Input Class Initialized
INFO - 2023-08-24 19:51:12 --> Language Class Initialized
ERROR - 2023-08-24 19:51:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:51:12 --> Config Class Initialized
INFO - 2023-08-24 19:51:12 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:12 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:12 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:12 --> URI Class Initialized
INFO - 2023-08-24 19:51:12 --> Router Class Initialized
INFO - 2023-08-24 19:51:12 --> Output Class Initialized
INFO - 2023-08-24 19:51:12 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:12 --> Input Class Initialized
INFO - 2023-08-24 19:51:12 --> Language Class Initialized
ERROR - 2023-08-24 19:51:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:51:12 --> Config Class Initialized
INFO - 2023-08-24 19:51:12 --> Config Class Initialized
INFO - 2023-08-24 19:51:12 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:12 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:12 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:12 --> URI Class Initialized
INFO - 2023-08-24 19:51:12 --> Router Class Initialized
INFO - 2023-08-24 19:51:12 --> Output Class Initialized
INFO - 2023-08-24 19:51:12 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:12 --> Input Class Initialized
INFO - 2023-08-24 19:51:12 --> Language Class Initialized
ERROR - 2023-08-24 19:51:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:51:12 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:12 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:12 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:12 --> URI Class Initialized
INFO - 2023-08-24 19:51:12 --> Router Class Initialized
INFO - 2023-08-24 19:51:12 --> Output Class Initialized
INFO - 2023-08-24 19:51:12 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:12 --> Input Class Initialized
INFO - 2023-08-24 19:51:12 --> Language Class Initialized
ERROR - 2023-08-24 19:51:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:51:12 --> Config Class Initialized
INFO - 2023-08-24 19:51:12 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:12 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:12 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:12 --> URI Class Initialized
INFO - 2023-08-24 19:51:12 --> Router Class Initialized
INFO - 2023-08-24 19:51:12 --> Output Class Initialized
INFO - 2023-08-24 19:51:13 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:13 --> Input Class Initialized
INFO - 2023-08-24 19:51:13 --> Language Class Initialized
ERROR - 2023-08-24 19:51:13 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:51:42 --> Config Class Initialized
INFO - 2023-08-24 19:51:42 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:42 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:42 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:42 --> URI Class Initialized
INFO - 2023-08-24 19:51:42 --> Router Class Initialized
INFO - 2023-08-24 19:51:42 --> Output Class Initialized
INFO - 2023-08-24 19:51:42 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:42 --> Input Class Initialized
INFO - 2023-08-24 19:51:42 --> Language Class Initialized
INFO - 2023-08-24 19:51:42 --> Loader Class Initialized
INFO - 2023-08-24 19:51:42 --> Helper loaded: url_helper
INFO - 2023-08-24 19:51:42 --> Helper loaded: file_helper
INFO - 2023-08-24 19:51:42 --> Database Driver Class Initialized
INFO - 2023-08-24 19:51:42 --> Email Class Initialized
DEBUG - 2023-08-24 19:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:51:43 --> Controller Class Initialized
INFO - 2023-08-24 19:51:43 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:51:43 --> Model "Home_model" initialized
INFO - 2023-08-24 19:51:43 --> Helper loaded: download_helper
INFO - 2023-08-24 19:51:43 --> Helper loaded: form_helper
INFO - 2023-08-24 19:51:43 --> Form Validation Class Initialized
INFO - 2023-08-24 19:51:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:51:43 --> Final output sent to browser
DEBUG - 2023-08-24 19:51:43 --> Total execution time: 0.4352
INFO - 2023-08-24 19:51:43 --> Config Class Initialized
INFO - 2023-08-24 19:51:43 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:43 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:43 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:43 --> URI Class Initialized
INFO - 2023-08-24 19:51:43 --> Router Class Initialized
INFO - 2023-08-24 19:51:43 --> Output Class Initialized
INFO - 2023-08-24 19:51:43 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:43 --> Input Class Initialized
INFO - 2023-08-24 19:51:43 --> Language Class Initialized
ERROR - 2023-08-24 19:51:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:51:43 --> Config Class Initialized
INFO - 2023-08-24 19:51:43 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:43 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:43 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:43 --> URI Class Initialized
INFO - 2023-08-24 19:51:43 --> Router Class Initialized
INFO - 2023-08-24 19:51:43 --> Output Class Initialized
INFO - 2023-08-24 19:51:43 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:43 --> Input Class Initialized
INFO - 2023-08-24 19:51:43 --> Language Class Initialized
ERROR - 2023-08-24 19:51:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:51:43 --> Config Class Initialized
INFO - 2023-08-24 19:51:43 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:43 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:43 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:43 --> URI Class Initialized
INFO - 2023-08-24 19:51:43 --> Router Class Initialized
INFO - 2023-08-24 19:51:43 --> Output Class Initialized
INFO - 2023-08-24 19:51:43 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:43 --> Input Class Initialized
INFO - 2023-08-24 19:51:43 --> Language Class Initialized
ERROR - 2023-08-24 19:51:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:51:43 --> Config Class Initialized
INFO - 2023-08-24 19:51:43 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:43 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:43 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:43 --> URI Class Initialized
INFO - 2023-08-24 19:51:43 --> Router Class Initialized
INFO - 2023-08-24 19:51:43 --> Output Class Initialized
INFO - 2023-08-24 19:51:43 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:43 --> Input Class Initialized
INFO - 2023-08-24 19:51:43 --> Language Class Initialized
ERROR - 2023-08-24 19:51:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:51:44 --> Config Class Initialized
INFO - 2023-08-24 19:51:44 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:44 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:44 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:44 --> URI Class Initialized
INFO - 2023-08-24 19:51:44 --> Router Class Initialized
INFO - 2023-08-24 19:51:44 --> Output Class Initialized
INFO - 2023-08-24 19:51:44 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:44 --> Input Class Initialized
INFO - 2023-08-24 19:51:44 --> Language Class Initialized
ERROR - 2023-08-24 19:51:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:51:44 --> Config Class Initialized
INFO - 2023-08-24 19:51:44 --> Hooks Class Initialized
INFO - 2023-08-24 19:51:44 --> Config Class Initialized
INFO - 2023-08-24 19:51:44 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:51:44 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:51:44 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:51:44 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:44 --> URI Class Initialized
INFO - 2023-08-24 19:51:44 --> Router Class Initialized
INFO - 2023-08-24 19:51:44 --> Output Class Initialized
INFO - 2023-08-24 19:51:44 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:44 --> Input Class Initialized
INFO - 2023-08-24 19:51:44 --> Language Class Initialized
ERROR - 2023-08-24 19:51:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:51:44 --> Utf8 Class Initialized
INFO - 2023-08-24 19:51:44 --> URI Class Initialized
INFO - 2023-08-24 19:51:44 --> Router Class Initialized
INFO - 2023-08-24 19:51:44 --> Output Class Initialized
INFO - 2023-08-24 19:51:44 --> Security Class Initialized
DEBUG - 2023-08-24 19:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:51:44 --> Input Class Initialized
INFO - 2023-08-24 19:51:44 --> Language Class Initialized
ERROR - 2023-08-24 19:51:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:55:58 --> Config Class Initialized
INFO - 2023-08-24 19:55:58 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:55:58 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:55:58 --> Utf8 Class Initialized
INFO - 2023-08-24 19:55:58 --> URI Class Initialized
INFO - 2023-08-24 19:55:58 --> Router Class Initialized
INFO - 2023-08-24 19:55:58 --> Output Class Initialized
INFO - 2023-08-24 19:55:58 --> Security Class Initialized
DEBUG - 2023-08-24 19:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:55:58 --> Input Class Initialized
INFO - 2023-08-24 19:55:58 --> Language Class Initialized
INFO - 2023-08-24 19:55:58 --> Loader Class Initialized
INFO - 2023-08-24 19:55:58 --> Helper loaded: url_helper
INFO - 2023-08-24 19:55:58 --> Helper loaded: file_helper
INFO - 2023-08-24 19:55:58 --> Database Driver Class Initialized
INFO - 2023-08-24 19:55:58 --> Email Class Initialized
DEBUG - 2023-08-24 19:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:55:58 --> Controller Class Initialized
INFO - 2023-08-24 19:55:58 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:55:58 --> Model "Home_model" initialized
INFO - 2023-08-24 19:55:58 --> Helper loaded: download_helper
INFO - 2023-08-24 19:55:58 --> Helper loaded: form_helper
INFO - 2023-08-24 19:55:58 --> Form Validation Class Initialized
INFO - 2023-08-24 19:55:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:55:58 --> Final output sent to browser
DEBUG - 2023-08-24 19:55:59 --> Total execution time: 0.5233
INFO - 2023-08-24 19:55:59 --> Config Class Initialized
INFO - 2023-08-24 19:55:59 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:55:59 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:55:59 --> Utf8 Class Initialized
INFO - 2023-08-24 19:55:59 --> URI Class Initialized
INFO - 2023-08-24 19:55:59 --> Router Class Initialized
INFO - 2023-08-24 19:55:59 --> Output Class Initialized
INFO - 2023-08-24 19:55:59 --> Security Class Initialized
DEBUG - 2023-08-24 19:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:55:59 --> Input Class Initialized
INFO - 2023-08-24 19:55:59 --> Language Class Initialized
ERROR - 2023-08-24 19:55:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:55:59 --> Config Class Initialized
INFO - 2023-08-24 19:55:59 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:55:59 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:55:59 --> Utf8 Class Initialized
INFO - 2023-08-24 19:55:59 --> URI Class Initialized
INFO - 2023-08-24 19:55:59 --> Router Class Initialized
INFO - 2023-08-24 19:55:59 --> Output Class Initialized
INFO - 2023-08-24 19:55:59 --> Security Class Initialized
DEBUG - 2023-08-24 19:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:55:59 --> Input Class Initialized
INFO - 2023-08-24 19:55:59 --> Config Class Initialized
INFO - 2023-08-24 19:55:59 --> Language Class Initialized
INFO - 2023-08-24 19:56:00 --> Hooks Class Initialized
ERROR - 2023-08-24 19:56:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:56:00 --> Config Class Initialized
DEBUG - 2023-08-24 19:56:00 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:56:00 --> Hooks Class Initialized
INFO - 2023-08-24 19:56:00 --> Config Class Initialized
DEBUG - 2023-08-24 19:56:00 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:56:00 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:56:00 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:56:00 --> Utf8 Class Initialized
INFO - 2023-08-24 19:56:00 --> Utf8 Class Initialized
INFO - 2023-08-24 19:56:00 --> URI Class Initialized
INFO - 2023-08-24 19:56:00 --> URI Class Initialized
INFO - 2023-08-24 19:56:00 --> Utf8 Class Initialized
INFO - 2023-08-24 19:56:00 --> Router Class Initialized
INFO - 2023-08-24 19:56:00 --> URI Class Initialized
INFO - 2023-08-24 19:56:00 --> Output Class Initialized
INFO - 2023-08-24 19:56:00 --> Security Class Initialized
INFO - 2023-08-24 19:56:00 --> Router Class Initialized
INFO - 2023-08-24 19:56:00 --> Router Class Initialized
INFO - 2023-08-24 19:56:00 --> Output Class Initialized
INFO - 2023-08-24 19:56:00 --> Output Class Initialized
INFO - 2023-08-24 19:56:00 --> Security Class Initialized
DEBUG - 2023-08-24 19:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-24 19:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:56:00 --> Security Class Initialized
INFO - 2023-08-24 19:56:00 --> Input Class Initialized
DEBUG - 2023-08-24 19:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:56:00 --> Input Class Initialized
INFO - 2023-08-24 19:56:00 --> Input Class Initialized
INFO - 2023-08-24 19:56:00 --> Language Class Initialized
INFO - 2023-08-24 19:56:01 --> Language Class Initialized
ERROR - 2023-08-24 19:56:01 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-24 19:56:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:56:01 --> Language Class Initialized
ERROR - 2023-08-24 19:56:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:56:01 --> Config Class Initialized
INFO - 2023-08-24 19:56:01 --> Config Class Initialized
INFO - 2023-08-24 19:56:01 --> Hooks Class Initialized
INFO - 2023-08-24 19:56:01 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:56:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:56:01 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:56:01 --> Utf8 Class Initialized
INFO - 2023-08-24 19:56:01 --> Utf8 Class Initialized
INFO - 2023-08-24 19:56:01 --> URI Class Initialized
INFO - 2023-08-24 19:56:01 --> Router Class Initialized
INFO - 2023-08-24 19:56:01 --> URI Class Initialized
INFO - 2023-08-24 19:56:01 --> Output Class Initialized
INFO - 2023-08-24 19:56:01 --> Router Class Initialized
INFO - 2023-08-24 19:56:01 --> Security Class Initialized
DEBUG - 2023-08-24 19:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:56:01 --> Output Class Initialized
INFO - 2023-08-24 19:56:01 --> Input Class Initialized
INFO - 2023-08-24 19:56:01 --> Security Class Initialized
INFO - 2023-08-24 19:56:01 --> Language Class Initialized
ERROR - 2023-08-24 19:56:01 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-24 19:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:56:01 --> Input Class Initialized
INFO - 2023-08-24 19:56:01 --> Language Class Initialized
ERROR - 2023-08-24 19:56:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:56:46 --> Config Class Initialized
INFO - 2023-08-24 19:56:46 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:56:46 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:56:46 --> Utf8 Class Initialized
INFO - 2023-08-24 19:56:46 --> URI Class Initialized
INFO - 2023-08-24 19:56:46 --> Router Class Initialized
INFO - 2023-08-24 19:56:46 --> Output Class Initialized
INFO - 2023-08-24 19:56:46 --> Security Class Initialized
DEBUG - 2023-08-24 19:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:56:46 --> Input Class Initialized
INFO - 2023-08-24 19:56:46 --> Language Class Initialized
INFO - 2023-08-24 19:56:46 --> Loader Class Initialized
INFO - 2023-08-24 19:56:46 --> Helper loaded: url_helper
INFO - 2023-08-24 19:56:46 --> Helper loaded: file_helper
INFO - 2023-08-24 19:56:46 --> Database Driver Class Initialized
INFO - 2023-08-24 19:56:46 --> Email Class Initialized
DEBUG - 2023-08-24 19:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-24 19:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-24 19:56:46 --> Controller Class Initialized
INFO - 2023-08-24 19:56:46 --> Model "Contact_model" initialized
INFO - 2023-08-24 19:56:46 --> Model "Home_model" initialized
INFO - 2023-08-24 19:56:46 --> Helper loaded: download_helper
INFO - 2023-08-24 19:56:46 --> Helper loaded: form_helper
INFO - 2023-08-24 19:56:46 --> Form Validation Class Initialized
INFO - 2023-08-24 19:56:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-24 19:56:46 --> Final output sent to browser
DEBUG - 2023-08-24 19:56:47 --> Total execution time: 0.9825
INFO - 2023-08-24 19:56:48 --> Config Class Initialized
INFO - 2023-08-24 19:56:48 --> Config Class Initialized
INFO - 2023-08-24 19:56:48 --> Hooks Class Initialized
INFO - 2023-08-24 19:56:48 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:56:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-24 19:56:48 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:56:48 --> Utf8 Class Initialized
INFO - 2023-08-24 19:56:48 --> Utf8 Class Initialized
INFO - 2023-08-24 19:56:48 --> URI Class Initialized
INFO - 2023-08-24 19:56:48 --> URI Class Initialized
INFO - 2023-08-24 19:56:48 --> Router Class Initialized
INFO - 2023-08-24 19:56:48 --> Output Class Initialized
INFO - 2023-08-24 19:56:48 --> Router Class Initialized
INFO - 2023-08-24 19:56:48 --> Security Class Initialized
DEBUG - 2023-08-24 19:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:56:48 --> Output Class Initialized
INFO - 2023-08-24 19:56:48 --> Input Class Initialized
INFO - 2023-08-24 19:56:48 --> Language Class Initialized
INFO - 2023-08-24 19:56:48 --> Security Class Initialized
ERROR - 2023-08-24 19:56:48 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-24 19:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:56:48 --> Input Class Initialized
INFO - 2023-08-24 19:56:48 --> Language Class Initialized
ERROR - 2023-08-24 19:56:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:56:48 --> Config Class Initialized
INFO - 2023-08-24 19:56:48 --> Hooks Class Initialized
DEBUG - 2023-08-24 19:56:48 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:56:48 --> Utf8 Class Initialized
INFO - 2023-08-24 19:56:48 --> URI Class Initialized
INFO - 2023-08-24 19:56:48 --> Router Class Initialized
INFO - 2023-08-24 19:56:48 --> Output Class Initialized
INFO - 2023-08-24 19:56:48 --> Security Class Initialized
DEBUG - 2023-08-24 19:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:56:48 --> Input Class Initialized
INFO - 2023-08-24 19:56:48 --> Language Class Initialized
ERROR - 2023-08-24 19:56:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-24 19:56:48 --> Config Class Initialized
INFO - 2023-08-24 19:56:48 --> Config Class Initialized
INFO - 2023-08-24 19:56:48 --> Hooks Class Initialized
INFO - 2023-08-24 19:56:48 --> Config Class Initialized
DEBUG - 2023-08-24 19:56:48 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:56:48 --> Hooks Class Initialized
INFO - 2023-08-24 19:56:48 --> Utf8 Class Initialized
INFO - 2023-08-24 19:56:48 --> Hooks Class Initialized
INFO - 2023-08-24 19:56:48 --> URI Class Initialized
DEBUG - 2023-08-24 19:56:48 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:56:48 --> Utf8 Class Initialized
INFO - 2023-08-24 19:56:48 --> Router Class Initialized
INFO - 2023-08-24 19:56:48 --> URI Class Initialized
DEBUG - 2023-08-24 19:56:48 --> UTF-8 Support Enabled
INFO - 2023-08-24 19:56:48 --> Utf8 Class Initialized
INFO - 2023-08-24 19:56:48 --> Router Class Initialized
INFO - 2023-08-24 19:56:49 --> URI Class Initialized
INFO - 2023-08-24 19:56:49 --> Router Class Initialized
INFO - 2023-08-24 19:56:49 --> Output Class Initialized
INFO - 2023-08-24 19:56:49 --> Output Class Initialized
INFO - 2023-08-24 19:56:49 --> Security Class Initialized
INFO - 2023-08-24 19:56:49 --> Output Class Initialized
INFO - 2023-08-24 19:56:49 --> Security Class Initialized
INFO - 2023-08-24 19:56:49 --> Security Class Initialized
DEBUG - 2023-08-24 19:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-24 19:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:56:49 --> Input Class Initialized
DEBUG - 2023-08-24 19:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-24 19:56:49 --> Input Class Initialized
INFO - 2023-08-24 19:56:49 --> Input Class Initialized
INFO - 2023-08-24 19:56:49 --> Language Class Initialized
INFO - 2023-08-24 19:56:49 --> Language Class Initialized
INFO - 2023-08-24 19:56:49 --> Language Class Initialized
ERROR - 2023-08-24 19:56:49 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-24 19:56:49 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-24 19:56:49 --> 404 Page Not Found: Assets/images
