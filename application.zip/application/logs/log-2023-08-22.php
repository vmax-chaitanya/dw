<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-22 16:52:22 --> Config Class Initialized
INFO - 2023-08-22 16:52:22 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:52:22 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:52:22 --> Utf8 Class Initialized
INFO - 2023-08-22 16:52:22 --> URI Class Initialized
INFO - 2023-08-22 16:52:22 --> Router Class Initialized
INFO - 2023-08-22 16:52:22 --> Output Class Initialized
INFO - 2023-08-22 16:52:22 --> Security Class Initialized
DEBUG - 2023-08-22 16:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:52:22 --> Input Class Initialized
INFO - 2023-08-22 16:52:22 --> Language Class Initialized
INFO - 2023-08-22 16:52:22 --> Loader Class Initialized
INFO - 2023-08-22 16:52:22 --> Helper loaded: url_helper
INFO - 2023-08-22 16:52:22 --> Helper loaded: file_helper
INFO - 2023-08-22 16:52:22 --> Database Driver Class Initialized
INFO - 2023-08-22 16:52:22 --> Email Class Initialized
DEBUG - 2023-08-22 16:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 16:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 16:52:22 --> Controller Class Initialized
INFO - 2023-08-22 16:52:22 --> Model "Home_model" initialized
INFO - 2023-08-22 16:52:22 --> Helper loaded: form_helper
INFO - 2023-08-22 16:52:22 --> Form Validation Class Initialized
INFO - 2023-08-22 16:52:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-22 16:52:22 --> Final output sent to browser
DEBUG - 2023-08-22 16:52:22 --> Total execution time: 0.2819
INFO - 2023-08-22 16:52:23 --> Config Class Initialized
INFO - 2023-08-22 16:52:23 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:52:23 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:52:23 --> Utf8 Class Initialized
INFO - 2023-08-22 16:52:23 --> URI Class Initialized
INFO - 2023-08-22 16:52:23 --> Router Class Initialized
INFO - 2023-08-22 16:52:23 --> Output Class Initialized
INFO - 2023-08-22 16:52:23 --> Security Class Initialized
DEBUG - 2023-08-22 16:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:52:23 --> Input Class Initialized
INFO - 2023-08-22 16:52:23 --> Language Class Initialized
ERROR - 2023-08-22 16:52:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 16:52:23 --> Config Class Initialized
INFO - 2023-08-22 16:52:23 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:52:23 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:52:23 --> Utf8 Class Initialized
INFO - 2023-08-22 16:52:23 --> URI Class Initialized
INFO - 2023-08-22 16:52:23 --> Router Class Initialized
INFO - 2023-08-22 16:52:23 --> Output Class Initialized
INFO - 2023-08-22 16:52:23 --> Security Class Initialized
DEBUG - 2023-08-22 16:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:52:23 --> Input Class Initialized
INFO - 2023-08-22 16:52:23 --> Language Class Initialized
ERROR - 2023-08-22 16:52:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 16:52:23 --> Config Class Initialized
INFO - 2023-08-22 16:52:23 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:52:23 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:52:23 --> Utf8 Class Initialized
INFO - 2023-08-22 16:52:23 --> URI Class Initialized
INFO - 2023-08-22 16:52:23 --> Router Class Initialized
INFO - 2023-08-22 16:52:23 --> Output Class Initialized
INFO - 2023-08-22 16:52:23 --> Security Class Initialized
DEBUG - 2023-08-22 16:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:52:23 --> Input Class Initialized
INFO - 2023-08-22 16:52:23 --> Language Class Initialized
ERROR - 2023-08-22 16:52:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 16:52:25 --> Config Class Initialized
INFO - 2023-08-22 16:52:25 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:52:25 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:52:25 --> Utf8 Class Initialized
INFO - 2023-08-22 16:52:25 --> URI Class Initialized
INFO - 2023-08-22 16:52:25 --> Router Class Initialized
INFO - 2023-08-22 16:52:25 --> Output Class Initialized
INFO - 2023-08-22 16:52:25 --> Security Class Initialized
DEBUG - 2023-08-22 16:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:52:25 --> Input Class Initialized
INFO - 2023-08-22 16:52:25 --> Language Class Initialized
ERROR - 2023-08-22 16:52:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 16:52:25 --> Config Class Initialized
INFO - 2023-08-22 16:52:25 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:52:25 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:52:25 --> Utf8 Class Initialized
INFO - 2023-08-22 16:52:25 --> URI Class Initialized
INFO - 2023-08-22 16:52:25 --> Router Class Initialized
INFO - 2023-08-22 16:52:25 --> Output Class Initialized
INFO - 2023-08-22 16:52:25 --> Security Class Initialized
DEBUG - 2023-08-22 16:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:52:25 --> Input Class Initialized
INFO - 2023-08-22 16:52:25 --> Language Class Initialized
ERROR - 2023-08-22 16:52:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 16:52:25 --> Config Class Initialized
INFO - 2023-08-22 16:52:25 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:52:25 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:52:25 --> Utf8 Class Initialized
INFO - 2023-08-22 16:52:25 --> URI Class Initialized
INFO - 2023-08-22 16:52:25 --> Router Class Initialized
INFO - 2023-08-22 16:52:25 --> Output Class Initialized
INFO - 2023-08-22 16:52:25 --> Security Class Initialized
DEBUG - 2023-08-22 16:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:52:25 --> Input Class Initialized
INFO - 2023-08-22 16:52:25 --> Language Class Initialized
ERROR - 2023-08-22 16:52:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 16:52:25 --> Config Class Initialized
INFO - 2023-08-22 16:52:25 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:52:25 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:52:25 --> Utf8 Class Initialized
INFO - 2023-08-22 16:52:25 --> URI Class Initialized
INFO - 2023-08-22 16:52:25 --> Router Class Initialized
INFO - 2023-08-22 16:52:25 --> Output Class Initialized
INFO - 2023-08-22 16:52:25 --> Security Class Initialized
DEBUG - 2023-08-22 16:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:52:25 --> Input Class Initialized
INFO - 2023-08-22 16:52:25 --> Language Class Initialized
ERROR - 2023-08-22 16:52:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 16:52:25 --> Config Class Initialized
INFO - 2023-08-22 16:52:25 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:52:25 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:52:25 --> Utf8 Class Initialized
INFO - 2023-08-22 16:52:25 --> URI Class Initialized
INFO - 2023-08-22 16:52:25 --> Router Class Initialized
INFO - 2023-08-22 16:52:25 --> Output Class Initialized
INFO - 2023-08-22 16:52:25 --> Security Class Initialized
DEBUG - 2023-08-22 16:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:52:25 --> Input Class Initialized
INFO - 2023-08-22 16:52:25 --> Language Class Initialized
ERROR - 2023-08-22 16:52:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 16:52:25 --> Config Class Initialized
INFO - 2023-08-22 16:52:25 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:52:25 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:52:25 --> Utf8 Class Initialized
INFO - 2023-08-22 16:52:25 --> URI Class Initialized
INFO - 2023-08-22 16:52:25 --> Router Class Initialized
INFO - 2023-08-22 16:52:25 --> Output Class Initialized
INFO - 2023-08-22 16:52:25 --> Security Class Initialized
DEBUG - 2023-08-22 16:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:52:25 --> Input Class Initialized
INFO - 2023-08-22 16:52:25 --> Language Class Initialized
ERROR - 2023-08-22 16:52:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 16:54:58 --> Config Class Initialized
INFO - 2023-08-22 16:54:58 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:54:58 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:54:58 --> Utf8 Class Initialized
INFO - 2023-08-22 16:54:58 --> URI Class Initialized
INFO - 2023-08-22 16:54:58 --> Router Class Initialized
INFO - 2023-08-22 16:54:58 --> Output Class Initialized
INFO - 2023-08-22 16:54:58 --> Security Class Initialized
DEBUG - 2023-08-22 16:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:54:58 --> Input Class Initialized
INFO - 2023-08-22 16:54:58 --> Language Class Initialized
INFO - 2023-08-22 16:54:58 --> Loader Class Initialized
INFO - 2023-08-22 16:54:58 --> Helper loaded: url_helper
INFO - 2023-08-22 16:54:58 --> Helper loaded: file_helper
INFO - 2023-08-22 16:54:58 --> Database Driver Class Initialized
INFO - 2023-08-22 16:54:58 --> Email Class Initialized
DEBUG - 2023-08-22 16:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 16:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 16:54:58 --> Controller Class Initialized
INFO - 2023-08-22 16:54:58 --> Model "Home_model" initialized
INFO - 2023-08-22 16:54:58 --> Helper loaded: form_helper
INFO - 2023-08-22 16:54:58 --> Form Validation Class Initialized
INFO - 2023-08-22 16:54:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 16:54:58 --> Final output sent to browser
DEBUG - 2023-08-22 16:54:58 --> Total execution time: 0.3548
INFO - 2023-08-22 16:54:59 --> Config Class Initialized
INFO - 2023-08-22 16:54:59 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:54:59 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:54:59 --> Utf8 Class Initialized
INFO - 2023-08-22 16:54:59 --> URI Class Initialized
INFO - 2023-08-22 16:54:59 --> Router Class Initialized
INFO - 2023-08-22 16:54:59 --> Output Class Initialized
INFO - 2023-08-22 16:54:59 --> Security Class Initialized
DEBUG - 2023-08-22 16:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:54:59 --> Input Class Initialized
INFO - 2023-08-22 16:54:59 --> Language Class Initialized
ERROR - 2023-08-22 16:54:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 16:55:00 --> Config Class Initialized
INFO - 2023-08-22 16:55:00 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:55:00 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:55:00 --> Utf8 Class Initialized
INFO - 2023-08-22 16:55:00 --> URI Class Initialized
INFO - 2023-08-22 16:55:00 --> Router Class Initialized
INFO - 2023-08-22 16:55:00 --> Output Class Initialized
INFO - 2023-08-22 16:55:00 --> Security Class Initialized
DEBUG - 2023-08-22 16:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:55:00 --> Input Class Initialized
INFO - 2023-08-22 16:55:00 --> Language Class Initialized
ERROR - 2023-08-22 16:55:00 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 16:55:00 --> Config Class Initialized
INFO - 2023-08-22 16:55:00 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:55:00 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:55:00 --> Utf8 Class Initialized
INFO - 2023-08-22 16:55:00 --> URI Class Initialized
INFO - 2023-08-22 16:55:00 --> Router Class Initialized
INFO - 2023-08-22 16:55:00 --> Output Class Initialized
INFO - 2023-08-22 16:55:00 --> Security Class Initialized
DEBUG - 2023-08-22 16:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:55:00 --> Input Class Initialized
INFO - 2023-08-22 16:55:00 --> Language Class Initialized
ERROR - 2023-08-22 16:55:00 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 16:55:02 --> Config Class Initialized
INFO - 2023-08-22 16:55:02 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:55:02 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:55:02 --> Utf8 Class Initialized
INFO - 2023-08-22 16:55:02 --> URI Class Initialized
INFO - 2023-08-22 16:55:02 --> Router Class Initialized
INFO - 2023-08-22 16:55:02 --> Output Class Initialized
INFO - 2023-08-22 16:55:02 --> Security Class Initialized
DEBUG - 2023-08-22 16:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:55:02 --> Input Class Initialized
INFO - 2023-08-22 16:55:02 --> Language Class Initialized
ERROR - 2023-08-22 16:55:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 16:55:05 --> Config Class Initialized
INFO - 2023-08-22 16:55:05 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:55:05 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:55:05 --> Utf8 Class Initialized
INFO - 2023-08-22 16:55:05 --> URI Class Initialized
INFO - 2023-08-22 16:55:05 --> Router Class Initialized
INFO - 2023-08-22 16:55:05 --> Output Class Initialized
INFO - 2023-08-22 16:55:05 --> Security Class Initialized
DEBUG - 2023-08-22 16:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:55:05 --> Input Class Initialized
INFO - 2023-08-22 16:55:05 --> Language Class Initialized
ERROR - 2023-08-22 16:55:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 16:55:06 --> Config Class Initialized
INFO - 2023-08-22 16:55:06 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:55:06 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:55:06 --> Utf8 Class Initialized
INFO - 2023-08-22 16:55:06 --> URI Class Initialized
INFO - 2023-08-22 16:55:06 --> Router Class Initialized
INFO - 2023-08-22 16:55:06 --> Output Class Initialized
INFO - 2023-08-22 16:55:06 --> Security Class Initialized
DEBUG - 2023-08-22 16:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:55:06 --> Input Class Initialized
INFO - 2023-08-22 16:55:06 --> Language Class Initialized
ERROR - 2023-08-22 16:55:06 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 16:55:06 --> Config Class Initialized
INFO - 2023-08-22 16:55:06 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:55:06 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:55:06 --> Utf8 Class Initialized
INFO - 2023-08-22 16:55:06 --> URI Class Initialized
INFO - 2023-08-22 16:55:06 --> Router Class Initialized
INFO - 2023-08-22 16:55:06 --> Output Class Initialized
INFO - 2023-08-22 16:55:06 --> Security Class Initialized
DEBUG - 2023-08-22 16:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:55:06 --> Input Class Initialized
INFO - 2023-08-22 16:55:06 --> Language Class Initialized
ERROR - 2023-08-22 16:55:06 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 16:55:06 --> Config Class Initialized
INFO - 2023-08-22 16:55:06 --> Hooks Class Initialized
DEBUG - 2023-08-22 16:55:06 --> UTF-8 Support Enabled
INFO - 2023-08-22 16:55:06 --> Utf8 Class Initialized
INFO - 2023-08-22 16:55:06 --> URI Class Initialized
INFO - 2023-08-22 16:55:06 --> Router Class Initialized
INFO - 2023-08-22 16:55:06 --> Output Class Initialized
INFO - 2023-08-22 16:55:06 --> Security Class Initialized
DEBUG - 2023-08-22 16:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 16:55:06 --> Input Class Initialized
INFO - 2023-08-22 16:55:06 --> Language Class Initialized
ERROR - 2023-08-22 16:55:06 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:02:26 --> Config Class Initialized
INFO - 2023-08-22 17:02:26 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:02:26 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:02:26 --> Utf8 Class Initialized
INFO - 2023-08-22 17:02:26 --> URI Class Initialized
INFO - 2023-08-22 17:02:26 --> Router Class Initialized
INFO - 2023-08-22 17:02:26 --> Output Class Initialized
INFO - 2023-08-22 17:02:26 --> Security Class Initialized
DEBUG - 2023-08-22 17:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:02:26 --> Input Class Initialized
INFO - 2023-08-22 17:02:27 --> Language Class Initialized
INFO - 2023-08-22 17:02:27 --> Loader Class Initialized
INFO - 2023-08-22 17:02:27 --> Helper loaded: url_helper
INFO - 2023-08-22 17:02:27 --> Helper loaded: file_helper
INFO - 2023-08-22 17:02:27 --> Database Driver Class Initialized
INFO - 2023-08-22 17:02:27 --> Email Class Initialized
DEBUG - 2023-08-22 17:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:02:27 --> Controller Class Initialized
INFO - 2023-08-22 17:02:27 --> Model "Home_model" initialized
INFO - 2023-08-22 17:02:27 --> Helper loaded: form_helper
INFO - 2023-08-22 17:02:27 --> Form Validation Class Initialized
INFO - 2023-08-22 17:02:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:02:27 --> Final output sent to browser
DEBUG - 2023-08-22 17:02:28 --> Total execution time: 1.6121
INFO - 2023-08-22 17:02:28 --> Config Class Initialized
INFO - 2023-08-22 17:02:28 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:02:28 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:02:28 --> Utf8 Class Initialized
INFO - 2023-08-22 17:02:28 --> URI Class Initialized
INFO - 2023-08-22 17:02:28 --> Router Class Initialized
INFO - 2023-08-22 17:02:28 --> Output Class Initialized
INFO - 2023-08-22 17:02:28 --> Security Class Initialized
DEBUG - 2023-08-22 17:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:02:28 --> Input Class Initialized
INFO - 2023-08-22 17:02:28 --> Language Class Initialized
INFO - 2023-08-22 17:02:28 --> Config Class Initialized
INFO - 2023-08-22 17:02:28 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:02:28 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:02:28 --> Utf8 Class Initialized
INFO - 2023-08-22 17:02:28 --> URI Class Initialized
INFO - 2023-08-22 17:02:28 --> Router Class Initialized
INFO - 2023-08-22 17:02:28 --> Output Class Initialized
INFO - 2023-08-22 17:02:28 --> Security Class Initialized
DEBUG - 2023-08-22 17:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:02:28 --> Input Class Initialized
INFO - 2023-08-22 17:02:28 --> Language Class Initialized
ERROR - 2023-08-22 17:02:28 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-22 17:02:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:02:28 --> Config Class Initialized
INFO - 2023-08-22 17:02:28 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:02:28 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:02:28 --> Utf8 Class Initialized
INFO - 2023-08-22 17:02:28 --> URI Class Initialized
INFO - 2023-08-22 17:02:28 --> Router Class Initialized
INFO - 2023-08-22 17:02:28 --> Output Class Initialized
INFO - 2023-08-22 17:02:28 --> Security Class Initialized
DEBUG - 2023-08-22 17:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:02:28 --> Input Class Initialized
INFO - 2023-08-22 17:02:28 --> Language Class Initialized
ERROR - 2023-08-22 17:02:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:02:28 --> Config Class Initialized
INFO - 2023-08-22 17:02:28 --> Hooks Class Initialized
INFO - 2023-08-22 17:02:28 --> Config Class Initialized
INFO - 2023-08-22 17:02:28 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:02:28 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:02:28 --> Utf8 Class Initialized
INFO - 2023-08-22 17:02:28 --> URI Class Initialized
INFO - 2023-08-22 17:02:28 --> Router Class Initialized
INFO - 2023-08-22 17:02:28 --> Output Class Initialized
INFO - 2023-08-22 17:02:28 --> Security Class Initialized
DEBUG - 2023-08-22 17:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:02:28 --> Input Class Initialized
INFO - 2023-08-22 17:02:28 --> Language Class Initialized
ERROR - 2023-08-22 17:02:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:02:28 --> Config Class Initialized
INFO - 2023-08-22 17:02:28 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:02:28 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:02:28 --> Utf8 Class Initialized
INFO - 2023-08-22 17:02:28 --> URI Class Initialized
INFO - 2023-08-22 17:02:28 --> Router Class Initialized
INFO - 2023-08-22 17:02:28 --> Output Class Initialized
INFO - 2023-08-22 17:02:28 --> Security Class Initialized
DEBUG - 2023-08-22 17:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:02:28 --> Input Class Initialized
INFO - 2023-08-22 17:02:28 --> Language Class Initialized
ERROR - 2023-08-22 17:02:28 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-22 17:02:28 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:02:28 --> Utf8 Class Initialized
INFO - 2023-08-22 17:02:29 --> URI Class Initialized
INFO - 2023-08-22 17:02:29 --> Router Class Initialized
INFO - 2023-08-22 17:02:29 --> Output Class Initialized
INFO - 2023-08-22 17:02:29 --> Security Class Initialized
DEBUG - 2023-08-22 17:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:02:29 --> Input Class Initialized
INFO - 2023-08-22 17:02:29 --> Language Class Initialized
ERROR - 2023-08-22 17:02:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:02:29 --> Config Class Initialized
INFO - 2023-08-22 17:02:29 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:02:29 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:02:29 --> Utf8 Class Initialized
INFO - 2023-08-22 17:02:29 --> URI Class Initialized
INFO - 2023-08-22 17:02:29 --> Router Class Initialized
INFO - 2023-08-22 17:02:29 --> Output Class Initialized
INFO - 2023-08-22 17:02:29 --> Security Class Initialized
DEBUG - 2023-08-22 17:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:02:29 --> Input Class Initialized
INFO - 2023-08-22 17:02:29 --> Language Class Initialized
ERROR - 2023-08-22 17:02:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:02:29 --> Config Class Initialized
INFO - 2023-08-22 17:02:29 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:02:29 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:02:29 --> Utf8 Class Initialized
INFO - 2023-08-22 17:02:29 --> URI Class Initialized
INFO - 2023-08-22 17:02:29 --> Router Class Initialized
INFO - 2023-08-22 17:02:29 --> Output Class Initialized
INFO - 2023-08-22 17:02:29 --> Security Class Initialized
DEBUG - 2023-08-22 17:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:02:29 --> Input Class Initialized
INFO - 2023-08-22 17:02:29 --> Language Class Initialized
ERROR - 2023-08-22 17:02:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:04:09 --> Config Class Initialized
INFO - 2023-08-22 17:04:09 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:04:09 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:04:09 --> Utf8 Class Initialized
INFO - 2023-08-22 17:04:09 --> URI Class Initialized
INFO - 2023-08-22 17:04:09 --> Router Class Initialized
INFO - 2023-08-22 17:04:09 --> Output Class Initialized
INFO - 2023-08-22 17:04:09 --> Security Class Initialized
DEBUG - 2023-08-22 17:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:04:09 --> Input Class Initialized
INFO - 2023-08-22 17:04:09 --> Language Class Initialized
INFO - 2023-08-22 17:04:09 --> Loader Class Initialized
INFO - 2023-08-22 17:04:09 --> Helper loaded: url_helper
INFO - 2023-08-22 17:04:09 --> Helper loaded: file_helper
INFO - 2023-08-22 17:04:09 --> Database Driver Class Initialized
INFO - 2023-08-22 17:04:09 --> Email Class Initialized
DEBUG - 2023-08-22 17:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:04:09 --> Controller Class Initialized
INFO - 2023-08-22 17:04:09 --> Model "Home_model" initialized
INFO - 2023-08-22 17:04:09 --> Helper loaded: form_helper
INFO - 2023-08-22 17:04:09 --> Form Validation Class Initialized
INFO - 2023-08-22 17:04:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:04:09 --> Final output sent to browser
DEBUG - 2023-08-22 17:04:09 --> Total execution time: 0.1431
INFO - 2023-08-22 17:04:09 --> Config Class Initialized
INFO - 2023-08-22 17:04:09 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:04:09 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:04:09 --> Utf8 Class Initialized
INFO - 2023-08-22 17:04:09 --> URI Class Initialized
INFO - 2023-08-22 17:04:09 --> Router Class Initialized
INFO - 2023-08-22 17:04:09 --> Output Class Initialized
INFO - 2023-08-22 17:04:09 --> Security Class Initialized
DEBUG - 2023-08-22 17:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:04:09 --> Input Class Initialized
INFO - 2023-08-22 17:04:09 --> Language Class Initialized
ERROR - 2023-08-22 17:04:09 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:04:10 --> Config Class Initialized
INFO - 2023-08-22 17:04:10 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:04:10 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:04:10 --> Utf8 Class Initialized
INFO - 2023-08-22 17:04:10 --> URI Class Initialized
INFO - 2023-08-22 17:04:10 --> Router Class Initialized
INFO - 2023-08-22 17:04:10 --> Output Class Initialized
INFO - 2023-08-22 17:04:10 --> Security Class Initialized
DEBUG - 2023-08-22 17:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:04:10 --> Input Class Initialized
INFO - 2023-08-22 17:04:10 --> Language Class Initialized
ERROR - 2023-08-22 17:04:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:04:10 --> Config Class Initialized
INFO - 2023-08-22 17:04:10 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:04:10 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:04:10 --> Utf8 Class Initialized
INFO - 2023-08-22 17:04:10 --> URI Class Initialized
INFO - 2023-08-22 17:04:10 --> Router Class Initialized
INFO - 2023-08-22 17:04:10 --> Output Class Initialized
INFO - 2023-08-22 17:04:10 --> Security Class Initialized
DEBUG - 2023-08-22 17:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:04:10 --> Input Class Initialized
INFO - 2023-08-22 17:04:10 --> Language Class Initialized
ERROR - 2023-08-22 17:04:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:04:10 --> Config Class Initialized
INFO - 2023-08-22 17:04:10 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:04:10 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:04:10 --> Utf8 Class Initialized
INFO - 2023-08-22 17:04:10 --> URI Class Initialized
INFO - 2023-08-22 17:04:10 --> Router Class Initialized
INFO - 2023-08-22 17:04:10 --> Output Class Initialized
INFO - 2023-08-22 17:04:10 --> Security Class Initialized
DEBUG - 2023-08-22 17:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:04:10 --> Input Class Initialized
INFO - 2023-08-22 17:04:10 --> Language Class Initialized
ERROR - 2023-08-22 17:04:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:04:10 --> Config Class Initialized
INFO - 2023-08-22 17:04:10 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:04:10 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:04:10 --> Utf8 Class Initialized
INFO - 2023-08-22 17:04:10 --> URI Class Initialized
INFO - 2023-08-22 17:04:10 --> Router Class Initialized
INFO - 2023-08-22 17:04:10 --> Output Class Initialized
INFO - 2023-08-22 17:04:10 --> Security Class Initialized
DEBUG - 2023-08-22 17:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:04:10 --> Input Class Initialized
INFO - 2023-08-22 17:04:10 --> Language Class Initialized
ERROR - 2023-08-22 17:04:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:04:10 --> Config Class Initialized
INFO - 2023-08-22 17:04:10 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:04:10 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:04:10 --> Utf8 Class Initialized
INFO - 2023-08-22 17:04:10 --> URI Class Initialized
INFO - 2023-08-22 17:04:10 --> Router Class Initialized
INFO - 2023-08-22 17:04:10 --> Output Class Initialized
INFO - 2023-08-22 17:04:10 --> Security Class Initialized
DEBUG - 2023-08-22 17:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:04:10 --> Input Class Initialized
INFO - 2023-08-22 17:04:10 --> Language Class Initialized
ERROR - 2023-08-22 17:04:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:04:10 --> Config Class Initialized
INFO - 2023-08-22 17:04:10 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:04:10 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:04:10 --> Utf8 Class Initialized
INFO - 2023-08-22 17:04:10 --> URI Class Initialized
INFO - 2023-08-22 17:04:10 --> Router Class Initialized
INFO - 2023-08-22 17:04:10 --> Output Class Initialized
INFO - 2023-08-22 17:04:10 --> Security Class Initialized
DEBUG - 2023-08-22 17:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:04:10 --> Input Class Initialized
INFO - 2023-08-22 17:04:10 --> Language Class Initialized
ERROR - 2023-08-22 17:04:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:05:12 --> Config Class Initialized
INFO - 2023-08-22 17:05:12 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:05:12 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:05:12 --> Utf8 Class Initialized
INFO - 2023-08-22 17:05:12 --> URI Class Initialized
INFO - 2023-08-22 17:05:12 --> Router Class Initialized
INFO - 2023-08-22 17:05:12 --> Output Class Initialized
INFO - 2023-08-22 17:05:12 --> Security Class Initialized
DEBUG - 2023-08-22 17:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:05:12 --> Input Class Initialized
INFO - 2023-08-22 17:05:12 --> Language Class Initialized
INFO - 2023-08-22 17:05:12 --> Loader Class Initialized
INFO - 2023-08-22 17:05:12 --> Helper loaded: url_helper
INFO - 2023-08-22 17:05:12 --> Helper loaded: file_helper
INFO - 2023-08-22 17:05:12 --> Database Driver Class Initialized
INFO - 2023-08-22 17:05:12 --> Email Class Initialized
DEBUG - 2023-08-22 17:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:05:12 --> Controller Class Initialized
INFO - 2023-08-22 17:05:12 --> Model "Home_model" initialized
INFO - 2023-08-22 17:05:12 --> Helper loaded: form_helper
INFO - 2023-08-22 17:05:12 --> Form Validation Class Initialized
INFO - 2023-08-22 17:05:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:05:12 --> Final output sent to browser
DEBUG - 2023-08-22 17:05:12 --> Total execution time: 0.1304
INFO - 2023-08-22 17:05:12 --> Config Class Initialized
INFO - 2023-08-22 17:05:12 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:05:12 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:05:12 --> Utf8 Class Initialized
INFO - 2023-08-22 17:05:12 --> URI Class Initialized
INFO - 2023-08-22 17:05:12 --> Router Class Initialized
INFO - 2023-08-22 17:05:12 --> Output Class Initialized
INFO - 2023-08-22 17:05:12 --> Security Class Initialized
DEBUG - 2023-08-22 17:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:05:12 --> Input Class Initialized
INFO - 2023-08-22 17:05:12 --> Language Class Initialized
ERROR - 2023-08-22 17:05:12 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:05:13 --> Config Class Initialized
INFO - 2023-08-22 17:05:13 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:05:13 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:05:13 --> Utf8 Class Initialized
INFO - 2023-08-22 17:05:13 --> URI Class Initialized
INFO - 2023-08-22 17:05:13 --> Router Class Initialized
INFO - 2023-08-22 17:05:13 --> Output Class Initialized
INFO - 2023-08-22 17:05:13 --> Security Class Initialized
DEBUG - 2023-08-22 17:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:05:13 --> Input Class Initialized
INFO - 2023-08-22 17:05:13 --> Language Class Initialized
ERROR - 2023-08-22 17:05:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:05:13 --> Config Class Initialized
INFO - 2023-08-22 17:05:13 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:05:13 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:05:13 --> Utf8 Class Initialized
INFO - 2023-08-22 17:05:13 --> URI Class Initialized
INFO - 2023-08-22 17:05:13 --> Router Class Initialized
INFO - 2023-08-22 17:05:13 --> Output Class Initialized
INFO - 2023-08-22 17:05:13 --> Security Class Initialized
DEBUG - 2023-08-22 17:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:05:13 --> Input Class Initialized
INFO - 2023-08-22 17:05:13 --> Language Class Initialized
ERROR - 2023-08-22 17:05:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:05:13 --> Config Class Initialized
INFO - 2023-08-22 17:05:13 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:05:13 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:05:13 --> Utf8 Class Initialized
INFO - 2023-08-22 17:05:13 --> URI Class Initialized
INFO - 2023-08-22 17:05:13 --> Router Class Initialized
INFO - 2023-08-22 17:05:13 --> Output Class Initialized
INFO - 2023-08-22 17:05:13 --> Security Class Initialized
DEBUG - 2023-08-22 17:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:05:13 --> Input Class Initialized
INFO - 2023-08-22 17:05:13 --> Language Class Initialized
ERROR - 2023-08-22 17:05:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:05:13 --> Config Class Initialized
INFO - 2023-08-22 17:05:13 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:05:13 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:05:13 --> Utf8 Class Initialized
INFO - 2023-08-22 17:05:13 --> URI Class Initialized
INFO - 2023-08-22 17:05:13 --> Router Class Initialized
INFO - 2023-08-22 17:05:13 --> Output Class Initialized
INFO - 2023-08-22 17:05:13 --> Security Class Initialized
DEBUG - 2023-08-22 17:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:05:13 --> Input Class Initialized
INFO - 2023-08-22 17:05:13 --> Language Class Initialized
ERROR - 2023-08-22 17:05:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:05:13 --> Config Class Initialized
INFO - 2023-08-22 17:05:13 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:05:13 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:05:13 --> Utf8 Class Initialized
INFO - 2023-08-22 17:05:13 --> URI Class Initialized
INFO - 2023-08-22 17:05:13 --> Router Class Initialized
INFO - 2023-08-22 17:05:13 --> Output Class Initialized
INFO - 2023-08-22 17:05:13 --> Security Class Initialized
DEBUG - 2023-08-22 17:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:05:13 --> Input Class Initialized
INFO - 2023-08-22 17:05:13 --> Language Class Initialized
ERROR - 2023-08-22 17:05:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:05:13 --> Config Class Initialized
INFO - 2023-08-22 17:05:13 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:05:13 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:05:13 --> Utf8 Class Initialized
INFO - 2023-08-22 17:05:13 --> URI Class Initialized
INFO - 2023-08-22 17:05:13 --> Router Class Initialized
INFO - 2023-08-22 17:05:13 --> Output Class Initialized
INFO - 2023-08-22 17:05:13 --> Security Class Initialized
DEBUG - 2023-08-22 17:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:05:13 --> Input Class Initialized
INFO - 2023-08-22 17:05:13 --> Language Class Initialized
ERROR - 2023-08-22 17:05:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:05:13 --> Config Class Initialized
INFO - 2023-08-22 17:05:13 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:05:13 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:05:13 --> Utf8 Class Initialized
INFO - 2023-08-22 17:05:13 --> URI Class Initialized
INFO - 2023-08-22 17:05:13 --> Router Class Initialized
INFO - 2023-08-22 17:05:13 --> Output Class Initialized
INFO - 2023-08-22 17:05:13 --> Security Class Initialized
DEBUG - 2023-08-22 17:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:05:13 --> Input Class Initialized
INFO - 2023-08-22 17:05:13 --> Language Class Initialized
ERROR - 2023-08-22 17:05:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:05:13 --> Config Class Initialized
INFO - 2023-08-22 17:05:13 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:05:13 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:05:13 --> Utf8 Class Initialized
INFO - 2023-08-22 17:05:13 --> URI Class Initialized
INFO - 2023-08-22 17:05:13 --> Router Class Initialized
INFO - 2023-08-22 17:05:13 --> Output Class Initialized
INFO - 2023-08-22 17:05:13 --> Security Class Initialized
DEBUG - 2023-08-22 17:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:05:13 --> Input Class Initialized
INFO - 2023-08-22 17:05:13 --> Language Class Initialized
ERROR - 2023-08-22 17:05:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:05:13 --> Config Class Initialized
INFO - 2023-08-22 17:05:13 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:05:13 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:05:13 --> Utf8 Class Initialized
INFO - 2023-08-22 17:05:13 --> URI Class Initialized
INFO - 2023-08-22 17:05:13 --> Router Class Initialized
INFO - 2023-08-22 17:05:13 --> Output Class Initialized
INFO - 2023-08-22 17:05:13 --> Security Class Initialized
DEBUG - 2023-08-22 17:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:05:13 --> Input Class Initialized
INFO - 2023-08-22 17:05:13 --> Language Class Initialized
ERROR - 2023-08-22 17:05:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:09:49 --> Config Class Initialized
INFO - 2023-08-22 17:09:49 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:09:49 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:09:49 --> Utf8 Class Initialized
INFO - 2023-08-22 17:09:49 --> URI Class Initialized
INFO - 2023-08-22 17:09:49 --> Router Class Initialized
INFO - 2023-08-22 17:09:49 --> Output Class Initialized
INFO - 2023-08-22 17:09:49 --> Security Class Initialized
DEBUG - 2023-08-22 17:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:09:49 --> Input Class Initialized
INFO - 2023-08-22 17:09:49 --> Language Class Initialized
INFO - 2023-08-22 17:09:49 --> Loader Class Initialized
INFO - 2023-08-22 17:09:49 --> Helper loaded: url_helper
INFO - 2023-08-22 17:09:49 --> Helper loaded: file_helper
INFO - 2023-08-22 17:09:49 --> Database Driver Class Initialized
INFO - 2023-08-22 17:09:49 --> Email Class Initialized
DEBUG - 2023-08-22 17:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:09:49 --> Controller Class Initialized
INFO - 2023-08-22 17:09:49 --> Model "Home_model" initialized
INFO - 2023-08-22 17:09:49 --> Helper loaded: form_helper
INFO - 2023-08-22 17:09:49 --> Form Validation Class Initialized
INFO - 2023-08-22 17:09:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:09:49 --> Final output sent to browser
DEBUG - 2023-08-22 17:09:50 --> Total execution time: 0.1740
INFO - 2023-08-22 17:09:50 --> Config Class Initialized
INFO - 2023-08-22 17:09:50 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:09:50 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:09:50 --> Utf8 Class Initialized
INFO - 2023-08-22 17:09:50 --> URI Class Initialized
INFO - 2023-08-22 17:09:50 --> Router Class Initialized
INFO - 2023-08-22 17:09:50 --> Output Class Initialized
INFO - 2023-08-22 17:09:50 --> Security Class Initialized
DEBUG - 2023-08-22 17:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:09:50 --> Input Class Initialized
INFO - 2023-08-22 17:09:50 --> Language Class Initialized
ERROR - 2023-08-22 17:09:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:09:50 --> Config Class Initialized
INFO - 2023-08-22 17:09:50 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:09:50 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:09:50 --> Utf8 Class Initialized
INFO - 2023-08-22 17:09:50 --> URI Class Initialized
INFO - 2023-08-22 17:09:50 --> Router Class Initialized
INFO - 2023-08-22 17:09:50 --> Output Class Initialized
INFO - 2023-08-22 17:09:50 --> Security Class Initialized
DEBUG - 2023-08-22 17:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:09:50 --> Input Class Initialized
INFO - 2023-08-22 17:09:50 --> Language Class Initialized
ERROR - 2023-08-22 17:09:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:09:50 --> Config Class Initialized
INFO - 2023-08-22 17:09:50 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:09:50 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:09:50 --> Utf8 Class Initialized
INFO - 2023-08-22 17:09:50 --> URI Class Initialized
INFO - 2023-08-22 17:09:50 --> Router Class Initialized
INFO - 2023-08-22 17:09:50 --> Output Class Initialized
INFO - 2023-08-22 17:09:50 --> Security Class Initialized
DEBUG - 2023-08-22 17:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:09:50 --> Input Class Initialized
INFO - 2023-08-22 17:09:50 --> Language Class Initialized
ERROR - 2023-08-22 17:09:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:09:50 --> Config Class Initialized
INFO - 2023-08-22 17:09:50 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:09:50 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:09:50 --> Utf8 Class Initialized
INFO - 2023-08-22 17:09:50 --> URI Class Initialized
INFO - 2023-08-22 17:09:50 --> Router Class Initialized
INFO - 2023-08-22 17:09:50 --> Output Class Initialized
INFO - 2023-08-22 17:09:50 --> Security Class Initialized
DEBUG - 2023-08-22 17:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:09:50 --> Input Class Initialized
INFO - 2023-08-22 17:09:50 --> Language Class Initialized
ERROR - 2023-08-22 17:09:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:09:51 --> Config Class Initialized
INFO - 2023-08-22 17:09:51 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:09:51 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:09:51 --> Utf8 Class Initialized
INFO - 2023-08-22 17:09:51 --> URI Class Initialized
INFO - 2023-08-22 17:09:51 --> Router Class Initialized
INFO - 2023-08-22 17:09:51 --> Output Class Initialized
INFO - 2023-08-22 17:09:51 --> Security Class Initialized
DEBUG - 2023-08-22 17:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:09:51 --> Input Class Initialized
INFO - 2023-08-22 17:09:51 --> Language Class Initialized
ERROR - 2023-08-22 17:09:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:09:51 --> Config Class Initialized
INFO - 2023-08-22 17:09:51 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:09:51 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:09:51 --> Utf8 Class Initialized
INFO - 2023-08-22 17:09:51 --> URI Class Initialized
INFO - 2023-08-22 17:09:51 --> Router Class Initialized
INFO - 2023-08-22 17:09:51 --> Output Class Initialized
INFO - 2023-08-22 17:09:51 --> Security Class Initialized
DEBUG - 2023-08-22 17:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:09:51 --> Input Class Initialized
INFO - 2023-08-22 17:09:51 --> Language Class Initialized
ERROR - 2023-08-22 17:09:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:10:32 --> Config Class Initialized
INFO - 2023-08-22 17:10:32 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:10:32 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:10:32 --> Utf8 Class Initialized
INFO - 2023-08-22 17:10:32 --> URI Class Initialized
INFO - 2023-08-22 17:10:32 --> Router Class Initialized
INFO - 2023-08-22 17:10:32 --> Output Class Initialized
INFO - 2023-08-22 17:10:32 --> Security Class Initialized
DEBUG - 2023-08-22 17:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:10:32 --> Input Class Initialized
INFO - 2023-08-22 17:10:32 --> Language Class Initialized
INFO - 2023-08-22 17:10:32 --> Loader Class Initialized
INFO - 2023-08-22 17:10:32 --> Helper loaded: url_helper
INFO - 2023-08-22 17:10:32 --> Helper loaded: file_helper
INFO - 2023-08-22 17:10:32 --> Database Driver Class Initialized
INFO - 2023-08-22 17:10:32 --> Email Class Initialized
DEBUG - 2023-08-22 17:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:10:32 --> Controller Class Initialized
INFO - 2023-08-22 17:10:32 --> Model "Home_model" initialized
INFO - 2023-08-22 17:10:32 --> Helper loaded: form_helper
INFO - 2023-08-22 17:10:32 --> Form Validation Class Initialized
INFO - 2023-08-22 17:10:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:10:32 --> Final output sent to browser
DEBUG - 2023-08-22 17:10:33 --> Total execution time: 0.1231
INFO - 2023-08-22 17:10:33 --> Config Class Initialized
INFO - 2023-08-22 17:10:33 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:10:33 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:10:33 --> Utf8 Class Initialized
INFO - 2023-08-22 17:10:33 --> URI Class Initialized
INFO - 2023-08-22 17:10:33 --> Router Class Initialized
INFO - 2023-08-22 17:10:33 --> Output Class Initialized
INFO - 2023-08-22 17:10:33 --> Security Class Initialized
DEBUG - 2023-08-22 17:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:10:33 --> Input Class Initialized
INFO - 2023-08-22 17:10:33 --> Language Class Initialized
ERROR - 2023-08-22 17:10:33 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:10:33 --> Config Class Initialized
INFO - 2023-08-22 17:10:33 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:10:33 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:10:33 --> Utf8 Class Initialized
INFO - 2023-08-22 17:10:33 --> URI Class Initialized
INFO - 2023-08-22 17:10:33 --> Router Class Initialized
INFO - 2023-08-22 17:10:33 --> Output Class Initialized
INFO - 2023-08-22 17:10:33 --> Security Class Initialized
DEBUG - 2023-08-22 17:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:10:33 --> Input Class Initialized
INFO - 2023-08-22 17:10:33 --> Language Class Initialized
ERROR - 2023-08-22 17:10:33 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:10:33 --> Config Class Initialized
INFO - 2023-08-22 17:10:33 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:10:33 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:10:33 --> Utf8 Class Initialized
INFO - 2023-08-22 17:10:33 --> URI Class Initialized
INFO - 2023-08-22 17:10:33 --> Router Class Initialized
INFO - 2023-08-22 17:10:33 --> Output Class Initialized
INFO - 2023-08-22 17:10:33 --> Security Class Initialized
DEBUG - 2023-08-22 17:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:10:33 --> Input Class Initialized
INFO - 2023-08-22 17:10:33 --> Language Class Initialized
ERROR - 2023-08-22 17:10:33 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:10:33 --> Config Class Initialized
INFO - 2023-08-22 17:10:33 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:10:33 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:10:33 --> Utf8 Class Initialized
INFO - 2023-08-22 17:10:33 --> URI Class Initialized
INFO - 2023-08-22 17:10:33 --> Router Class Initialized
INFO - 2023-08-22 17:10:33 --> Output Class Initialized
INFO - 2023-08-22 17:10:33 --> Security Class Initialized
DEBUG - 2023-08-22 17:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:10:33 --> Input Class Initialized
INFO - 2023-08-22 17:10:33 --> Language Class Initialized
ERROR - 2023-08-22 17:10:33 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:10:34 --> Config Class Initialized
INFO - 2023-08-22 17:10:34 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:10:34 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:10:34 --> Utf8 Class Initialized
INFO - 2023-08-22 17:10:34 --> URI Class Initialized
INFO - 2023-08-22 17:10:34 --> Router Class Initialized
INFO - 2023-08-22 17:10:34 --> Output Class Initialized
INFO - 2023-08-22 17:10:34 --> Security Class Initialized
DEBUG - 2023-08-22 17:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:10:34 --> Input Class Initialized
INFO - 2023-08-22 17:10:34 --> Language Class Initialized
ERROR - 2023-08-22 17:10:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:10:34 --> Config Class Initialized
INFO - 2023-08-22 17:10:34 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:10:34 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:10:34 --> Utf8 Class Initialized
INFO - 2023-08-22 17:10:34 --> URI Class Initialized
INFO - 2023-08-22 17:10:34 --> Router Class Initialized
INFO - 2023-08-22 17:10:34 --> Output Class Initialized
INFO - 2023-08-22 17:10:34 --> Security Class Initialized
DEBUG - 2023-08-22 17:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:10:34 --> Input Class Initialized
INFO - 2023-08-22 17:10:34 --> Language Class Initialized
ERROR - 2023-08-22 17:10:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:10:34 --> Config Class Initialized
INFO - 2023-08-22 17:10:34 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:10:34 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:10:34 --> Utf8 Class Initialized
INFO - 2023-08-22 17:10:34 --> URI Class Initialized
INFO - 2023-08-22 17:10:34 --> Router Class Initialized
INFO - 2023-08-22 17:10:34 --> Output Class Initialized
INFO - 2023-08-22 17:10:34 --> Security Class Initialized
DEBUG - 2023-08-22 17:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:10:34 --> Input Class Initialized
INFO - 2023-08-22 17:10:34 --> Language Class Initialized
ERROR - 2023-08-22 17:10:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:10:34 --> Config Class Initialized
INFO - 2023-08-22 17:10:34 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:10:34 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:10:34 --> Utf8 Class Initialized
INFO - 2023-08-22 17:10:34 --> URI Class Initialized
INFO - 2023-08-22 17:10:34 --> Router Class Initialized
INFO - 2023-08-22 17:10:34 --> Output Class Initialized
INFO - 2023-08-22 17:10:34 --> Security Class Initialized
DEBUG - 2023-08-22 17:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:10:34 --> Input Class Initialized
INFO - 2023-08-22 17:10:34 --> Language Class Initialized
ERROR - 2023-08-22 17:10:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:10:34 --> Config Class Initialized
INFO - 2023-08-22 17:10:34 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:10:34 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:10:34 --> Utf8 Class Initialized
INFO - 2023-08-22 17:10:34 --> URI Class Initialized
INFO - 2023-08-22 17:10:34 --> Router Class Initialized
INFO - 2023-08-22 17:10:34 --> Output Class Initialized
INFO - 2023-08-22 17:10:34 --> Security Class Initialized
DEBUG - 2023-08-22 17:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:10:34 --> Input Class Initialized
INFO - 2023-08-22 17:10:34 --> Language Class Initialized
ERROR - 2023-08-22 17:10:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:12:34 --> Config Class Initialized
INFO - 2023-08-22 17:12:34 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:12:34 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:12:34 --> Utf8 Class Initialized
INFO - 2023-08-22 17:12:34 --> URI Class Initialized
INFO - 2023-08-22 17:12:34 --> Router Class Initialized
INFO - 2023-08-22 17:12:34 --> Output Class Initialized
INFO - 2023-08-22 17:12:34 --> Security Class Initialized
DEBUG - 2023-08-22 17:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:12:34 --> Input Class Initialized
INFO - 2023-08-22 17:12:34 --> Language Class Initialized
INFO - 2023-08-22 17:12:34 --> Loader Class Initialized
INFO - 2023-08-22 17:12:34 --> Helper loaded: url_helper
INFO - 2023-08-22 17:12:34 --> Helper loaded: file_helper
INFO - 2023-08-22 17:12:34 --> Database Driver Class Initialized
INFO - 2023-08-22 17:12:34 --> Email Class Initialized
DEBUG - 2023-08-22 17:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:12:34 --> Controller Class Initialized
INFO - 2023-08-22 17:12:34 --> Model "Home_model" initialized
INFO - 2023-08-22 17:12:34 --> Helper loaded: form_helper
INFO - 2023-08-22 17:12:34 --> Form Validation Class Initialized
INFO - 2023-08-22 17:12:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:12:34 --> Final output sent to browser
DEBUG - 2023-08-22 17:12:34 --> Total execution time: 0.1420
INFO - 2023-08-22 17:12:34 --> Config Class Initialized
INFO - 2023-08-22 17:12:34 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:12:34 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:12:34 --> Utf8 Class Initialized
INFO - 2023-08-22 17:12:34 --> URI Class Initialized
INFO - 2023-08-22 17:12:34 --> Router Class Initialized
INFO - 2023-08-22 17:12:34 --> Output Class Initialized
INFO - 2023-08-22 17:12:34 --> Security Class Initialized
DEBUG - 2023-08-22 17:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:12:34 --> Input Class Initialized
INFO - 2023-08-22 17:12:34 --> Language Class Initialized
ERROR - 2023-08-22 17:12:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:12:34 --> Config Class Initialized
INFO - 2023-08-22 17:12:34 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:12:34 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:12:34 --> Utf8 Class Initialized
INFO - 2023-08-22 17:12:34 --> URI Class Initialized
INFO - 2023-08-22 17:12:34 --> Router Class Initialized
INFO - 2023-08-22 17:12:35 --> Config Class Initialized
INFO - 2023-08-22 17:12:35 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:12:35 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:12:35 --> Utf8 Class Initialized
INFO - 2023-08-22 17:12:35 --> URI Class Initialized
INFO - 2023-08-22 17:12:35 --> Router Class Initialized
INFO - 2023-08-22 17:12:35 --> Output Class Initialized
INFO - 2023-08-22 17:12:35 --> Security Class Initialized
DEBUG - 2023-08-22 17:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:12:35 --> Input Class Initialized
INFO - 2023-08-22 17:12:35 --> Language Class Initialized
ERROR - 2023-08-22 17:12:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:12:35 --> Output Class Initialized
INFO - 2023-08-22 17:12:35 --> Security Class Initialized
DEBUG - 2023-08-22 17:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:12:35 --> Input Class Initialized
INFO - 2023-08-22 17:12:35 --> Language Class Initialized
ERROR - 2023-08-22 17:12:36 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:12:36 --> Config Class Initialized
INFO - 2023-08-22 17:12:36 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:12:36 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:12:36 --> Utf8 Class Initialized
INFO - 2023-08-22 17:12:36 --> URI Class Initialized
INFO - 2023-08-22 17:12:36 --> Router Class Initialized
INFO - 2023-08-22 17:12:36 --> Output Class Initialized
INFO - 2023-08-22 17:12:36 --> Security Class Initialized
DEBUG - 2023-08-22 17:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:12:36 --> Input Class Initialized
INFO - 2023-08-22 17:12:36 --> Language Class Initialized
ERROR - 2023-08-22 17:12:36 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:12:36 --> Config Class Initialized
INFO - 2023-08-22 17:12:36 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:12:36 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:12:36 --> Utf8 Class Initialized
INFO - 2023-08-22 17:12:36 --> URI Class Initialized
INFO - 2023-08-22 17:12:36 --> Router Class Initialized
INFO - 2023-08-22 17:12:36 --> Output Class Initialized
INFO - 2023-08-22 17:12:36 --> Security Class Initialized
DEBUG - 2023-08-22 17:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:12:36 --> Input Class Initialized
INFO - 2023-08-22 17:12:36 --> Language Class Initialized
ERROR - 2023-08-22 17:12:36 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:12:36 --> Config Class Initialized
INFO - 2023-08-22 17:12:36 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:12:36 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:12:36 --> Utf8 Class Initialized
INFO - 2023-08-22 17:12:36 --> URI Class Initialized
INFO - 2023-08-22 17:12:36 --> Router Class Initialized
INFO - 2023-08-22 17:12:36 --> Output Class Initialized
INFO - 2023-08-22 17:12:36 --> Security Class Initialized
DEBUG - 2023-08-22 17:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:12:36 --> Input Class Initialized
INFO - 2023-08-22 17:12:36 --> Language Class Initialized
ERROR - 2023-08-22 17:12:36 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:12:36 --> Config Class Initialized
INFO - 2023-08-22 17:12:36 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:12:36 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:12:36 --> Utf8 Class Initialized
INFO - 2023-08-22 17:12:36 --> URI Class Initialized
INFO - 2023-08-22 17:12:36 --> Router Class Initialized
INFO - 2023-08-22 17:12:36 --> Output Class Initialized
INFO - 2023-08-22 17:12:36 --> Security Class Initialized
DEBUG - 2023-08-22 17:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:12:36 --> Input Class Initialized
INFO - 2023-08-22 17:12:36 --> Language Class Initialized
ERROR - 2023-08-22 17:12:36 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:13:25 --> Config Class Initialized
INFO - 2023-08-22 17:13:25 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:13:25 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:13:25 --> Utf8 Class Initialized
INFO - 2023-08-22 17:13:25 --> URI Class Initialized
INFO - 2023-08-22 17:13:25 --> Router Class Initialized
INFO - 2023-08-22 17:13:25 --> Output Class Initialized
INFO - 2023-08-22 17:13:25 --> Security Class Initialized
DEBUG - 2023-08-22 17:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:13:25 --> Input Class Initialized
INFO - 2023-08-22 17:13:25 --> Language Class Initialized
INFO - 2023-08-22 17:13:25 --> Loader Class Initialized
INFO - 2023-08-22 17:13:25 --> Helper loaded: url_helper
INFO - 2023-08-22 17:13:25 --> Helper loaded: file_helper
INFO - 2023-08-22 17:13:25 --> Database Driver Class Initialized
INFO - 2023-08-22 17:13:25 --> Email Class Initialized
DEBUG - 2023-08-22 17:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:13:25 --> Controller Class Initialized
INFO - 2023-08-22 17:13:25 --> Model "Home_model" initialized
INFO - 2023-08-22 17:13:25 --> Helper loaded: form_helper
INFO - 2023-08-22 17:13:25 --> Form Validation Class Initialized
INFO - 2023-08-22 17:13:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:13:25 --> Final output sent to browser
DEBUG - 2023-08-22 17:13:25 --> Total execution time: 0.0971
INFO - 2023-08-22 17:13:25 --> Config Class Initialized
INFO - 2023-08-22 17:13:25 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:13:25 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:13:25 --> Utf8 Class Initialized
INFO - 2023-08-22 17:13:25 --> URI Class Initialized
INFO - 2023-08-22 17:13:25 --> Router Class Initialized
INFO - 2023-08-22 17:13:25 --> Output Class Initialized
INFO - 2023-08-22 17:13:25 --> Security Class Initialized
DEBUG - 2023-08-22 17:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:13:25 --> Input Class Initialized
INFO - 2023-08-22 17:13:25 --> Language Class Initialized
ERROR - 2023-08-22 17:13:25 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:13:26 --> Config Class Initialized
INFO - 2023-08-22 17:13:26 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:13:26 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:13:26 --> Utf8 Class Initialized
INFO - 2023-08-22 17:13:26 --> URI Class Initialized
INFO - 2023-08-22 17:13:26 --> Router Class Initialized
INFO - 2023-08-22 17:13:26 --> Output Class Initialized
INFO - 2023-08-22 17:13:26 --> Security Class Initialized
DEBUG - 2023-08-22 17:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:13:26 --> Input Class Initialized
INFO - 2023-08-22 17:13:26 --> Language Class Initialized
ERROR - 2023-08-22 17:13:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:13:26 --> Config Class Initialized
INFO - 2023-08-22 17:13:26 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:13:26 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:13:26 --> Utf8 Class Initialized
INFO - 2023-08-22 17:13:26 --> URI Class Initialized
INFO - 2023-08-22 17:13:26 --> Router Class Initialized
INFO - 2023-08-22 17:13:26 --> Output Class Initialized
INFO - 2023-08-22 17:13:26 --> Security Class Initialized
DEBUG - 2023-08-22 17:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:13:26 --> Input Class Initialized
INFO - 2023-08-22 17:13:26 --> Language Class Initialized
ERROR - 2023-08-22 17:13:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:13:26 --> Config Class Initialized
INFO - 2023-08-22 17:13:26 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:13:26 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:13:26 --> Utf8 Class Initialized
INFO - 2023-08-22 17:13:26 --> URI Class Initialized
INFO - 2023-08-22 17:13:26 --> Router Class Initialized
INFO - 2023-08-22 17:13:26 --> Output Class Initialized
INFO - 2023-08-22 17:13:26 --> Security Class Initialized
DEBUG - 2023-08-22 17:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:13:26 --> Input Class Initialized
INFO - 2023-08-22 17:13:26 --> Language Class Initialized
ERROR - 2023-08-22 17:13:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:13:26 --> Config Class Initialized
INFO - 2023-08-22 17:13:26 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:13:26 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:13:26 --> Utf8 Class Initialized
INFO - 2023-08-22 17:13:26 --> URI Class Initialized
INFO - 2023-08-22 17:13:26 --> Router Class Initialized
INFO - 2023-08-22 17:13:26 --> Output Class Initialized
INFO - 2023-08-22 17:13:26 --> Security Class Initialized
DEBUG - 2023-08-22 17:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:13:26 --> Input Class Initialized
INFO - 2023-08-22 17:13:26 --> Language Class Initialized
ERROR - 2023-08-22 17:13:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:13:26 --> Config Class Initialized
INFO - 2023-08-22 17:13:26 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:13:26 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:13:26 --> Utf8 Class Initialized
INFO - 2023-08-22 17:13:26 --> URI Class Initialized
INFO - 2023-08-22 17:13:26 --> Router Class Initialized
INFO - 2023-08-22 17:13:26 --> Output Class Initialized
INFO - 2023-08-22 17:13:26 --> Security Class Initialized
DEBUG - 2023-08-22 17:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:13:26 --> Input Class Initialized
INFO - 2023-08-22 17:13:26 --> Language Class Initialized
ERROR - 2023-08-22 17:13:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:26:14 --> Config Class Initialized
INFO - 2023-08-22 17:26:14 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:26:14 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:26:14 --> Utf8 Class Initialized
INFO - 2023-08-22 17:26:14 --> URI Class Initialized
INFO - 2023-08-22 17:26:14 --> Router Class Initialized
INFO - 2023-08-22 17:26:14 --> Output Class Initialized
INFO - 2023-08-22 17:26:14 --> Security Class Initialized
DEBUG - 2023-08-22 17:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:26:14 --> Input Class Initialized
INFO - 2023-08-22 17:26:14 --> Language Class Initialized
INFO - 2023-08-22 17:26:14 --> Loader Class Initialized
INFO - 2023-08-22 17:26:14 --> Helper loaded: url_helper
INFO - 2023-08-22 17:26:14 --> Helper loaded: file_helper
INFO - 2023-08-22 17:26:14 --> Database Driver Class Initialized
INFO - 2023-08-22 17:26:14 --> Email Class Initialized
DEBUG - 2023-08-22 17:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:26:14 --> Controller Class Initialized
INFO - 2023-08-22 17:26:14 --> Model "Home_model" initialized
INFO - 2023-08-22 17:26:14 --> Helper loaded: form_helper
INFO - 2023-08-22 17:26:14 --> Form Validation Class Initialized
INFO - 2023-08-22 17:26:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-22 17:26:15 --> Final output sent to browser
DEBUG - 2023-08-22 17:26:15 --> Total execution time: 0.9998
INFO - 2023-08-22 17:26:15 --> Config Class Initialized
INFO - 2023-08-22 17:26:15 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:26:15 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:26:15 --> Utf8 Class Initialized
INFO - 2023-08-22 17:26:15 --> URI Class Initialized
INFO - 2023-08-22 17:26:15 --> Router Class Initialized
INFO - 2023-08-22 17:26:15 --> Output Class Initialized
INFO - 2023-08-22 17:26:15 --> Security Class Initialized
DEBUG - 2023-08-22 17:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:26:15 --> Input Class Initialized
INFO - 2023-08-22 17:26:15 --> Language Class Initialized
ERROR - 2023-08-22 17:26:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 17:26:16 --> Config Class Initialized
INFO - 2023-08-22 17:26:16 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:26:16 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:26:16 --> Utf8 Class Initialized
INFO - 2023-08-22 17:26:16 --> URI Class Initialized
INFO - 2023-08-22 17:26:16 --> Config Class Initialized
INFO - 2023-08-22 17:26:16 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:26:16 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:26:16 --> Utf8 Class Initialized
INFO - 2023-08-22 17:26:16 --> URI Class Initialized
INFO - 2023-08-22 17:26:16 --> Router Class Initialized
INFO - 2023-08-22 17:26:16 --> Router Class Initialized
INFO - 2023-08-22 17:26:16 --> Output Class Initialized
INFO - 2023-08-22 17:26:16 --> Security Class Initialized
DEBUG - 2023-08-22 17:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:26:16 --> Input Class Initialized
INFO - 2023-08-22 17:26:16 --> Language Class Initialized
ERROR - 2023-08-22 17:26:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 17:26:16 --> Config Class Initialized
INFO - 2023-08-22 17:26:16 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:26:16 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:26:16 --> Utf8 Class Initialized
INFO - 2023-08-22 17:26:16 --> URI Class Initialized
INFO - 2023-08-22 17:26:16 --> Router Class Initialized
INFO - 2023-08-22 17:26:16 --> Output Class Initialized
INFO - 2023-08-22 17:26:16 --> Security Class Initialized
DEBUG - 2023-08-22 17:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:26:16 --> Input Class Initialized
INFO - 2023-08-22 17:26:16 --> Language Class Initialized
ERROR - 2023-08-22 17:26:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 17:26:16 --> Output Class Initialized
INFO - 2023-08-22 17:26:16 --> Security Class Initialized
DEBUG - 2023-08-22 17:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:26:16 --> Input Class Initialized
INFO - 2023-08-22 17:26:16 --> Language Class Initialized
ERROR - 2023-08-22 17:26:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 17:26:16 --> Config Class Initialized
INFO - 2023-08-22 17:26:16 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:26:16 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:26:16 --> Utf8 Class Initialized
INFO - 2023-08-22 17:26:16 --> URI Class Initialized
INFO - 2023-08-22 17:26:16 --> Router Class Initialized
INFO - 2023-08-22 17:26:16 --> Output Class Initialized
INFO - 2023-08-22 17:26:16 --> Security Class Initialized
DEBUG - 2023-08-22 17:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:26:16 --> Input Class Initialized
INFO - 2023-08-22 17:26:16 --> Language Class Initialized
ERROR - 2023-08-22 17:26:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 17:26:17 --> Config Class Initialized
INFO - 2023-08-22 17:26:17 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:26:17 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:26:17 --> Utf8 Class Initialized
INFO - 2023-08-22 17:26:17 --> URI Class Initialized
INFO - 2023-08-22 17:26:17 --> Router Class Initialized
INFO - 2023-08-22 17:26:17 --> Output Class Initialized
INFO - 2023-08-22 17:26:17 --> Security Class Initialized
DEBUG - 2023-08-22 17:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:26:17 --> Input Class Initialized
INFO - 2023-08-22 17:26:17 --> Language Class Initialized
ERROR - 2023-08-22 17:26:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 17:26:17 --> Config Class Initialized
INFO - 2023-08-22 17:26:17 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:26:17 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:26:17 --> Utf8 Class Initialized
INFO - 2023-08-22 17:26:17 --> URI Class Initialized
INFO - 2023-08-22 17:26:17 --> Router Class Initialized
INFO - 2023-08-22 17:26:17 --> Output Class Initialized
INFO - 2023-08-22 17:26:17 --> Security Class Initialized
DEBUG - 2023-08-22 17:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:26:17 --> Input Class Initialized
INFO - 2023-08-22 17:26:17 --> Language Class Initialized
ERROR - 2023-08-22 17:26:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 17:26:17 --> Config Class Initialized
INFO - 2023-08-22 17:26:17 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:26:17 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:26:17 --> Utf8 Class Initialized
INFO - 2023-08-22 17:26:17 --> URI Class Initialized
INFO - 2023-08-22 17:26:17 --> Router Class Initialized
INFO - 2023-08-22 17:26:17 --> Output Class Initialized
INFO - 2023-08-22 17:26:17 --> Security Class Initialized
DEBUG - 2023-08-22 17:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:26:17 --> Input Class Initialized
INFO - 2023-08-22 17:26:17 --> Language Class Initialized
ERROR - 2023-08-22 17:26:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-22 17:27:45 --> Config Class Initialized
INFO - 2023-08-22 17:27:45 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:27:45 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:27:45 --> Utf8 Class Initialized
INFO - 2023-08-22 17:27:45 --> URI Class Initialized
INFO - 2023-08-22 17:27:45 --> Router Class Initialized
INFO - 2023-08-22 17:27:45 --> Output Class Initialized
INFO - 2023-08-22 17:27:45 --> Security Class Initialized
DEBUG - 2023-08-22 17:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:27:45 --> Input Class Initialized
INFO - 2023-08-22 17:27:45 --> Language Class Initialized
INFO - 2023-08-22 17:27:45 --> Loader Class Initialized
INFO - 2023-08-22 17:27:45 --> Helper loaded: url_helper
INFO - 2023-08-22 17:27:45 --> Helper loaded: file_helper
INFO - 2023-08-22 17:27:45 --> Database Driver Class Initialized
INFO - 2023-08-22 17:27:45 --> Email Class Initialized
DEBUG - 2023-08-22 17:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:27:45 --> Controller Class Initialized
INFO - 2023-08-22 17:27:45 --> Model "Home_model" initialized
INFO - 2023-08-22 17:27:45 --> Helper loaded: form_helper
INFO - 2023-08-22 17:27:45 --> Form Validation Class Initialized
INFO - 2023-08-22 17:27:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:27:46 --> Final output sent to browser
DEBUG - 2023-08-22 17:27:46 --> Total execution time: 0.1137
INFO - 2023-08-22 17:28:35 --> Config Class Initialized
INFO - 2023-08-22 17:28:35 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:28:35 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:28:35 --> Utf8 Class Initialized
INFO - 2023-08-22 17:28:35 --> URI Class Initialized
INFO - 2023-08-22 17:28:35 --> Router Class Initialized
INFO - 2023-08-22 17:28:35 --> Output Class Initialized
INFO - 2023-08-22 17:28:35 --> Security Class Initialized
DEBUG - 2023-08-22 17:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:28:35 --> Input Class Initialized
INFO - 2023-08-22 17:28:35 --> Language Class Initialized
INFO - 2023-08-22 17:28:35 --> Loader Class Initialized
INFO - 2023-08-22 17:28:35 --> Helper loaded: url_helper
INFO - 2023-08-22 17:28:35 --> Helper loaded: file_helper
INFO - 2023-08-22 17:28:35 --> Database Driver Class Initialized
INFO - 2023-08-22 17:28:35 --> Email Class Initialized
DEBUG - 2023-08-22 17:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:28:35 --> Controller Class Initialized
INFO - 2023-08-22 17:28:35 --> Model "Home_model" initialized
INFO - 2023-08-22 17:28:35 --> Helper loaded: form_helper
INFO - 2023-08-22 17:28:35 --> Form Validation Class Initialized
INFO - 2023-08-22 17:28:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:28:35 --> Final output sent to browser
DEBUG - 2023-08-22 17:28:35 --> Total execution time: 0.2596
INFO - 2023-08-22 17:28:35 --> Config Class Initialized
INFO - 2023-08-22 17:28:35 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:28:35 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:28:35 --> Utf8 Class Initialized
INFO - 2023-08-22 17:28:35 --> URI Class Initialized
INFO - 2023-08-22 17:28:35 --> Router Class Initialized
INFO - 2023-08-22 17:28:35 --> Output Class Initialized
INFO - 2023-08-22 17:28:35 --> Security Class Initialized
DEBUG - 2023-08-22 17:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:28:35 --> Input Class Initialized
INFO - 2023-08-22 17:28:35 --> Language Class Initialized
ERROR - 2023-08-22 17:28:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:28:35 --> Config Class Initialized
INFO - 2023-08-22 17:28:35 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:28:36 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:28:36 --> Utf8 Class Initialized
INFO - 2023-08-22 17:28:36 --> URI Class Initialized
INFO - 2023-08-22 17:28:36 --> Router Class Initialized
INFO - 2023-08-22 17:28:36 --> Output Class Initialized
INFO - 2023-08-22 17:28:36 --> Security Class Initialized
DEBUG - 2023-08-22 17:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:28:36 --> Input Class Initialized
INFO - 2023-08-22 17:28:36 --> Language Class Initialized
ERROR - 2023-08-22 17:28:36 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:28:36 --> Config Class Initialized
INFO - 2023-08-22 17:28:36 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:28:36 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:28:36 --> Utf8 Class Initialized
INFO - 2023-08-22 17:28:36 --> URI Class Initialized
INFO - 2023-08-22 17:28:36 --> Router Class Initialized
INFO - 2023-08-22 17:28:36 --> Output Class Initialized
INFO - 2023-08-22 17:28:36 --> Security Class Initialized
DEBUG - 2023-08-22 17:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:28:36 --> Input Class Initialized
INFO - 2023-08-22 17:28:36 --> Language Class Initialized
ERROR - 2023-08-22 17:28:36 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:28:36 --> Config Class Initialized
INFO - 2023-08-22 17:28:36 --> Config Class Initialized
INFO - 2023-08-22 17:28:36 --> Config Class Initialized
INFO - 2023-08-22 17:28:36 --> Config Class Initialized
INFO - 2023-08-22 17:28:36 --> Hooks Class Initialized
INFO - 2023-08-22 17:28:37 --> Hooks Class Initialized
INFO - 2023-08-22 17:28:37 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:28:37 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:28:37 --> Hooks Class Initialized
INFO - 2023-08-22 17:28:37 --> Utf8 Class Initialized
DEBUG - 2023-08-22 17:28:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-22 17:28:37 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:28:37 --> URI Class Initialized
INFO - 2023-08-22 17:28:37 --> Utf8 Class Initialized
DEBUG - 2023-08-22 17:28:37 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:28:37 --> URI Class Initialized
INFO - 2023-08-22 17:28:37 --> Utf8 Class Initialized
INFO - 2023-08-22 17:28:37 --> Router Class Initialized
INFO - 2023-08-22 17:28:37 --> Output Class Initialized
INFO - 2023-08-22 17:28:37 --> Utf8 Class Initialized
INFO - 2023-08-22 17:28:37 --> URI Class Initialized
INFO - 2023-08-22 17:28:37 --> Security Class Initialized
INFO - 2023-08-22 17:28:37 --> Router Class Initialized
INFO - 2023-08-22 17:28:37 --> URI Class Initialized
INFO - 2023-08-22 17:28:37 --> Output Class Initialized
INFO - 2023-08-22 17:28:37 --> Router Class Initialized
INFO - 2023-08-22 17:28:37 --> Output Class Initialized
INFO - 2023-08-22 17:28:37 --> Router Class Initialized
DEBUG - 2023-08-22 17:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:28:37 --> Output Class Initialized
INFO - 2023-08-22 17:28:37 --> Security Class Initialized
INFO - 2023-08-22 17:28:37 --> Security Class Initialized
INFO - 2023-08-22 17:28:37 --> Security Class Initialized
DEBUG - 2023-08-22 17:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:28:37 --> Input Class Initialized
INFO - 2023-08-22 17:28:37 --> Language Class Initialized
ERROR - 2023-08-22 17:28:37 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-22 17:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-22 17:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:28:37 --> Input Class Initialized
INFO - 2023-08-22 17:28:37 --> Input Class Initialized
INFO - 2023-08-22 17:28:37 --> Language Class Initialized
INFO - 2023-08-22 17:28:37 --> Language Class Initialized
ERROR - 2023-08-22 17:28:37 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:28:37 --> Input Class Initialized
INFO - 2023-08-22 17:28:37 --> Language Class Initialized
ERROR - 2023-08-22 17:28:37 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-22 17:28:37 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:33:33 --> Config Class Initialized
INFO - 2023-08-22 17:33:33 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:33:33 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:33:33 --> Utf8 Class Initialized
INFO - 2023-08-22 17:33:33 --> URI Class Initialized
INFO - 2023-08-22 17:33:33 --> Router Class Initialized
INFO - 2023-08-22 17:33:33 --> Output Class Initialized
INFO - 2023-08-22 17:33:33 --> Security Class Initialized
DEBUG - 2023-08-22 17:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:33:33 --> Input Class Initialized
INFO - 2023-08-22 17:33:33 --> Language Class Initialized
INFO - 2023-08-22 17:33:33 --> Loader Class Initialized
INFO - 2023-08-22 17:33:33 --> Helper loaded: url_helper
INFO - 2023-08-22 17:33:33 --> Helper loaded: file_helper
INFO - 2023-08-22 17:33:33 --> Database Driver Class Initialized
INFO - 2023-08-22 17:33:33 --> Email Class Initialized
DEBUG - 2023-08-22 17:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:33:33 --> Controller Class Initialized
INFO - 2023-08-22 17:33:33 --> Model "Home_model" initialized
INFO - 2023-08-22 17:33:33 --> Helper loaded: form_helper
INFO - 2023-08-22 17:33:33 --> Form Validation Class Initialized
INFO - 2023-08-22 17:33:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:33:33 --> Final output sent to browser
DEBUG - 2023-08-22 17:33:34 --> Total execution time: 0.7145
INFO - 2023-08-22 17:33:34 --> Config Class Initialized
INFO - 2023-08-22 17:33:34 --> Config Class Initialized
INFO - 2023-08-22 17:33:34 --> Config Class Initialized
INFO - 2023-08-22 17:33:34 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:33:34 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:33:34 --> Utf8 Class Initialized
INFO - 2023-08-22 17:33:34 --> URI Class Initialized
INFO - 2023-08-22 17:33:34 --> Router Class Initialized
INFO - 2023-08-22 17:33:34 --> Output Class Initialized
INFO - 2023-08-22 17:33:34 --> Security Class Initialized
DEBUG - 2023-08-22 17:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:33:34 --> Input Class Initialized
INFO - 2023-08-22 17:33:34 --> Language Class Initialized
ERROR - 2023-08-22 17:33:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:33:34 --> Hooks Class Initialized
INFO - 2023-08-22 17:33:34 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:33:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-22 17:33:34 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:33:34 --> Utf8 Class Initialized
INFO - 2023-08-22 17:33:34 --> Utf8 Class Initialized
INFO - 2023-08-22 17:33:34 --> URI Class Initialized
INFO - 2023-08-22 17:33:34 --> URI Class Initialized
INFO - 2023-08-22 17:33:34 --> Router Class Initialized
INFO - 2023-08-22 17:33:34 --> Router Class Initialized
INFO - 2023-08-22 17:33:35 --> Output Class Initialized
INFO - 2023-08-22 17:33:35 --> Output Class Initialized
INFO - 2023-08-22 17:33:35 --> Security Class Initialized
INFO - 2023-08-22 17:33:35 --> Security Class Initialized
DEBUG - 2023-08-22 17:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-22 17:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:33:35 --> Input Class Initialized
INFO - 2023-08-22 17:33:35 --> Input Class Initialized
INFO - 2023-08-22 17:33:35 --> Config Class Initialized
INFO - 2023-08-22 17:33:35 --> Language Class Initialized
INFO - 2023-08-22 17:33:35 --> Language Class Initialized
ERROR - 2023-08-22 17:33:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:33:35 --> Hooks Class Initialized
ERROR - 2023-08-22 17:33:35 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-22 17:33:35 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:33:35 --> Utf8 Class Initialized
INFO - 2023-08-22 17:33:35 --> URI Class Initialized
INFO - 2023-08-22 17:33:35 --> Router Class Initialized
INFO - 2023-08-22 17:33:35 --> Output Class Initialized
INFO - 2023-08-22 17:33:35 --> Security Class Initialized
DEBUG - 2023-08-22 17:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:33:35 --> Input Class Initialized
INFO - 2023-08-22 17:33:35 --> Language Class Initialized
ERROR - 2023-08-22 17:33:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:33:35 --> Config Class Initialized
INFO - 2023-08-22 17:33:35 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:33:35 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:33:35 --> Utf8 Class Initialized
INFO - 2023-08-22 17:33:35 --> URI Class Initialized
INFO - 2023-08-22 17:33:35 --> Router Class Initialized
INFO - 2023-08-22 17:33:35 --> Output Class Initialized
INFO - 2023-08-22 17:33:35 --> Security Class Initialized
DEBUG - 2023-08-22 17:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:33:35 --> Input Class Initialized
INFO - 2023-08-22 17:33:35 --> Language Class Initialized
ERROR - 2023-08-22 17:33:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:33:43 --> Config Class Initialized
INFO - 2023-08-22 17:33:43 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:33:43 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:33:43 --> Utf8 Class Initialized
INFO - 2023-08-22 17:33:43 --> URI Class Initialized
INFO - 2023-08-22 17:33:43 --> Router Class Initialized
INFO - 2023-08-22 17:33:43 --> Output Class Initialized
INFO - 2023-08-22 17:33:43 --> Security Class Initialized
DEBUG - 2023-08-22 17:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:33:43 --> Input Class Initialized
INFO - 2023-08-22 17:33:43 --> Language Class Initialized
INFO - 2023-08-22 17:33:43 --> Loader Class Initialized
INFO - 2023-08-22 17:33:43 --> Helper loaded: url_helper
INFO - 2023-08-22 17:33:43 --> Helper loaded: file_helper
INFO - 2023-08-22 17:33:43 --> Database Driver Class Initialized
INFO - 2023-08-22 17:33:43 --> Email Class Initialized
DEBUG - 2023-08-22 17:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:33:43 --> Controller Class Initialized
INFO - 2023-08-22 17:33:43 --> Model "Home_model" initialized
INFO - 2023-08-22 17:33:43 --> Helper loaded: form_helper
INFO - 2023-08-22 17:33:43 --> Form Validation Class Initialized
INFO - 2023-08-22 17:33:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:33:44 --> Final output sent to browser
DEBUG - 2023-08-22 17:33:44 --> Total execution time: 0.4336
INFO - 2023-08-22 17:33:44 --> Config Class Initialized
INFO - 2023-08-22 17:33:44 --> Hooks Class Initialized
INFO - 2023-08-22 17:33:44 --> Config Class Initialized
DEBUG - 2023-08-22 17:33:44 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:33:44 --> Hooks Class Initialized
INFO - 2023-08-22 17:33:45 --> Utf8 Class Initialized
INFO - 2023-08-22 17:33:45 --> Config Class Initialized
DEBUG - 2023-08-22 17:33:45 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:33:45 --> Hooks Class Initialized
INFO - 2023-08-22 17:33:45 --> Config Class Initialized
INFO - 2023-08-22 17:33:45 --> Utf8 Class Initialized
DEBUG - 2023-08-22 17:33:45 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:33:45 --> URI Class Initialized
INFO - 2023-08-22 17:33:45 --> Router Class Initialized
INFO - 2023-08-22 17:33:45 --> Output Class Initialized
INFO - 2023-08-22 17:33:45 --> Security Class Initialized
DEBUG - 2023-08-22 17:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:33:45 --> Input Class Initialized
INFO - 2023-08-22 17:33:45 --> Language Class Initialized
ERROR - 2023-08-22 17:33:45 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:33:45 --> URI Class Initialized
INFO - 2023-08-22 17:33:45 --> Config Class Initialized
INFO - 2023-08-22 17:33:45 --> Router Class Initialized
INFO - 2023-08-22 17:33:45 --> Output Class Initialized
INFO - 2023-08-22 17:33:45 --> Hooks Class Initialized
INFO - 2023-08-22 17:33:45 --> Hooks Class Initialized
INFO - 2023-08-22 17:33:45 --> Utf8 Class Initialized
INFO - 2023-08-22 17:33:45 --> Security Class Initialized
DEBUG - 2023-08-22 17:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:33:45 --> Input Class Initialized
INFO - 2023-08-22 17:33:45 --> Language Class Initialized
ERROR - 2023-08-22 17:33:45 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-22 17:33:45 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:33:45 --> URI Class Initialized
INFO - 2023-08-22 17:33:45 --> Utf8 Class Initialized
DEBUG - 2023-08-22 17:33:45 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:33:45 --> Utf8 Class Initialized
INFO - 2023-08-22 17:33:45 --> URI Class Initialized
INFO - 2023-08-22 17:33:45 --> Router Class Initialized
INFO - 2023-08-22 17:33:45 --> Router Class Initialized
INFO - 2023-08-22 17:33:45 --> Output Class Initialized
INFO - 2023-08-22 17:33:45 --> Security Class Initialized
INFO - 2023-08-22 17:33:45 --> Output Class Initialized
INFO - 2023-08-22 17:33:45 --> URI Class Initialized
INFO - 2023-08-22 17:33:45 --> Router Class Initialized
DEBUG - 2023-08-22 17:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:33:45 --> Security Class Initialized
INFO - 2023-08-22 17:33:45 --> Input Class Initialized
INFO - 2023-08-22 17:33:45 --> Language Class Initialized
DEBUG - 2023-08-22 17:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-22 17:33:45 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:33:45 --> Input Class Initialized
INFO - 2023-08-22 17:33:45 --> Output Class Initialized
INFO - 2023-08-22 17:33:45 --> Language Class Initialized
INFO - 2023-08-22 17:33:45 --> Security Class Initialized
DEBUG - 2023-08-22 17:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-22 17:33:45 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:33:45 --> Input Class Initialized
INFO - 2023-08-22 17:33:45 --> Language Class Initialized
ERROR - 2023-08-22 17:33:45 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:10 --> Config Class Initialized
INFO - 2023-08-22 17:34:10 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:10 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:10 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:10 --> URI Class Initialized
INFO - 2023-08-22 17:34:10 --> Router Class Initialized
INFO - 2023-08-22 17:34:10 --> Output Class Initialized
INFO - 2023-08-22 17:34:10 --> Security Class Initialized
DEBUG - 2023-08-22 17:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:10 --> Input Class Initialized
INFO - 2023-08-22 17:34:10 --> Language Class Initialized
INFO - 2023-08-22 17:34:10 --> Loader Class Initialized
INFO - 2023-08-22 17:34:10 --> Helper loaded: url_helper
INFO - 2023-08-22 17:34:10 --> Helper loaded: file_helper
INFO - 2023-08-22 17:34:10 --> Database Driver Class Initialized
INFO - 2023-08-22 17:34:10 --> Email Class Initialized
DEBUG - 2023-08-22 17:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:34:10 --> Controller Class Initialized
INFO - 2023-08-22 17:34:10 --> Model "Home_model" initialized
INFO - 2023-08-22 17:34:10 --> Helper loaded: form_helper
INFO - 2023-08-22 17:34:10 --> Form Validation Class Initialized
INFO - 2023-08-22 17:34:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:34:10 --> Final output sent to browser
DEBUG - 2023-08-22 17:34:10 --> Total execution time: 0.3952
INFO - 2023-08-22 17:34:11 --> Config Class Initialized
INFO - 2023-08-22 17:34:11 --> Config Class Initialized
INFO - 2023-08-22 17:34:11 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:11 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:11 --> Hooks Class Initialized
INFO - 2023-08-22 17:34:11 --> Utf8 Class Initialized
DEBUG - 2023-08-22 17:34:11 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:11 --> URI Class Initialized
INFO - 2023-08-22 17:34:11 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:11 --> Router Class Initialized
INFO - 2023-08-22 17:34:11 --> URI Class Initialized
INFO - 2023-08-22 17:34:11 --> Router Class Initialized
INFO - 2023-08-22 17:34:11 --> Output Class Initialized
INFO - 2023-08-22 17:34:11 --> Output Class Initialized
INFO - 2023-08-22 17:34:11 --> Security Class Initialized
INFO - 2023-08-22 17:34:11 --> Security Class Initialized
DEBUG - 2023-08-22 17:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-22 17:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:11 --> Input Class Initialized
INFO - 2023-08-22 17:34:11 --> Input Class Initialized
INFO - 2023-08-22 17:34:11 --> Language Class Initialized
INFO - 2023-08-22 17:34:11 --> Language Class Initialized
ERROR - 2023-08-22 17:34:11 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-22 17:34:11 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:11 --> Config Class Initialized
INFO - 2023-08-22 17:34:11 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:11 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:11 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:11 --> URI Class Initialized
INFO - 2023-08-22 17:34:11 --> Router Class Initialized
INFO - 2023-08-22 17:34:11 --> Output Class Initialized
INFO - 2023-08-22 17:34:11 --> Security Class Initialized
DEBUG - 2023-08-22 17:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:11 --> Input Class Initialized
INFO - 2023-08-22 17:34:11 --> Language Class Initialized
ERROR - 2023-08-22 17:34:11 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:11 --> Config Class Initialized
INFO - 2023-08-22 17:34:11 --> Config Class Initialized
INFO - 2023-08-22 17:34:12 --> Hooks Class Initialized
INFO - 2023-08-22 17:34:12 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-22 17:34:12 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:12 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:12 --> URI Class Initialized
INFO - 2023-08-22 17:34:12 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:12 --> Router Class Initialized
INFO - 2023-08-22 17:34:12 --> Output Class Initialized
INFO - 2023-08-22 17:34:12 --> URI Class Initialized
INFO - 2023-08-22 17:34:12 --> Security Class Initialized
INFO - 2023-08-22 17:34:12 --> Router Class Initialized
DEBUG - 2023-08-22 17:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:12 --> Output Class Initialized
INFO - 2023-08-22 17:34:12 --> Input Class Initialized
INFO - 2023-08-22 17:34:12 --> Security Class Initialized
INFO - 2023-08-22 17:34:12 --> Language Class Initialized
DEBUG - 2023-08-22 17:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:12 --> Input Class Initialized
ERROR - 2023-08-22 17:34:12 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:12 --> Language Class Initialized
ERROR - 2023-08-22 17:34:12 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:21 --> Config Class Initialized
INFO - 2023-08-22 17:34:21 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:21 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:21 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:21 --> URI Class Initialized
INFO - 2023-08-22 17:34:21 --> Router Class Initialized
INFO - 2023-08-22 17:34:21 --> Output Class Initialized
INFO - 2023-08-22 17:34:21 --> Security Class Initialized
DEBUG - 2023-08-22 17:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:22 --> Input Class Initialized
INFO - 2023-08-22 17:34:22 --> Language Class Initialized
INFO - 2023-08-22 17:34:22 --> Loader Class Initialized
INFO - 2023-08-22 17:34:22 --> Helper loaded: url_helper
INFO - 2023-08-22 17:34:22 --> Helper loaded: file_helper
INFO - 2023-08-22 17:34:22 --> Database Driver Class Initialized
INFO - 2023-08-22 17:34:22 --> Email Class Initialized
DEBUG - 2023-08-22 17:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:34:22 --> Controller Class Initialized
INFO - 2023-08-22 17:34:22 --> Model "Home_model" initialized
INFO - 2023-08-22 17:34:22 --> Helper loaded: form_helper
INFO - 2023-08-22 17:34:22 --> Form Validation Class Initialized
INFO - 2023-08-22 17:34:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:34:22 --> Final output sent to browser
DEBUG - 2023-08-22 17:34:22 --> Total execution time: 0.4039
INFO - 2023-08-22 17:34:22 --> Config Class Initialized
INFO - 2023-08-22 17:34:22 --> Config Class Initialized
INFO - 2023-08-22 17:34:22 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:22 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:22 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:22 --> URI Class Initialized
INFO - 2023-08-22 17:34:22 --> Router Class Initialized
INFO - 2023-08-22 17:34:22 --> Output Class Initialized
INFO - 2023-08-22 17:34:22 --> Security Class Initialized
INFO - 2023-08-22 17:34:22 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:22 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:23 --> Config Class Initialized
INFO - 2023-08-22 17:34:23 --> Config Class Initialized
INFO - 2023-08-22 17:34:23 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:23 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:23 --> Hooks Class Initialized
INFO - 2023-08-22 17:34:23 --> URI Class Initialized
INFO - 2023-08-22 17:34:23 --> Input Class Initialized
INFO - 2023-08-22 17:34:23 --> Config Class Initialized
INFO - 2023-08-22 17:34:23 --> Router Class Initialized
INFO - 2023-08-22 17:34:23 --> Output Class Initialized
INFO - 2023-08-22 17:34:23 --> Security Class Initialized
DEBUG - 2023-08-22 17:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:23 --> Input Class Initialized
INFO - 2023-08-22 17:34:23 --> Language Class Initialized
ERROR - 2023-08-22 17:34:23 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:23 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-22 17:34:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-22 17:34:23 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:23 --> Language Class Initialized
INFO - 2023-08-22 17:34:23 --> Utf8 Class Initialized
ERROR - 2023-08-22 17:34:23 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:23 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:23 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:23 --> URI Class Initialized
INFO - 2023-08-22 17:34:23 --> URI Class Initialized
INFO - 2023-08-22 17:34:23 --> Router Class Initialized
INFO - 2023-08-22 17:34:23 --> URI Class Initialized
INFO - 2023-08-22 17:34:23 --> Router Class Initialized
INFO - 2023-08-22 17:34:23 --> Router Class Initialized
INFO - 2023-08-22 17:34:23 --> Output Class Initialized
INFO - 2023-08-22 17:34:23 --> Output Class Initialized
INFO - 2023-08-22 17:34:23 --> Security Class Initialized
INFO - 2023-08-22 17:34:23 --> Output Class Initialized
DEBUG - 2023-08-22 17:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:23 --> Security Class Initialized
DEBUG - 2023-08-22 17:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:23 --> Input Class Initialized
INFO - 2023-08-22 17:34:23 --> Language Class Initialized
INFO - 2023-08-22 17:34:23 --> Security Class Initialized
ERROR - 2023-08-22 17:34:23 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:23 --> Input Class Initialized
DEBUG - 2023-08-22 17:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:23 --> Language Class Initialized
ERROR - 2023-08-22 17:34:23 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:23 --> Input Class Initialized
INFO - 2023-08-22 17:34:23 --> Language Class Initialized
ERROR - 2023-08-22 17:34:23 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:57 --> Config Class Initialized
INFO - 2023-08-22 17:34:57 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:57 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:57 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:57 --> URI Class Initialized
INFO - 2023-08-22 17:34:57 --> Router Class Initialized
INFO - 2023-08-22 17:34:57 --> Output Class Initialized
INFO - 2023-08-22 17:34:57 --> Security Class Initialized
DEBUG - 2023-08-22 17:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:57 --> Input Class Initialized
INFO - 2023-08-22 17:34:57 --> Language Class Initialized
INFO - 2023-08-22 17:34:57 --> Loader Class Initialized
INFO - 2023-08-22 17:34:57 --> Helper loaded: url_helper
INFO - 2023-08-22 17:34:57 --> Helper loaded: file_helper
INFO - 2023-08-22 17:34:57 --> Database Driver Class Initialized
INFO - 2023-08-22 17:34:57 --> Email Class Initialized
DEBUG - 2023-08-22 17:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:34:57 --> Controller Class Initialized
INFO - 2023-08-22 17:34:57 --> Model "Home_model" initialized
INFO - 2023-08-22 17:34:57 --> Helper loaded: form_helper
INFO - 2023-08-22 17:34:57 --> Form Validation Class Initialized
INFO - 2023-08-22 17:34:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:34:58 --> Final output sent to browser
DEBUG - 2023-08-22 17:34:58 --> Total execution time: 0.3830
INFO - 2023-08-22 17:34:58 --> Config Class Initialized
INFO - 2023-08-22 17:34:58 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:58 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:58 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:58 --> URI Class Initialized
INFO - 2023-08-22 17:34:58 --> Router Class Initialized
INFO - 2023-08-22 17:34:58 --> Output Class Initialized
INFO - 2023-08-22 17:34:58 --> Security Class Initialized
DEBUG - 2023-08-22 17:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:58 --> Input Class Initialized
INFO - 2023-08-22 17:34:58 --> Language Class Initialized
ERROR - 2023-08-22 17:34:58 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:58 --> Config Class Initialized
INFO - 2023-08-22 17:34:58 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:58 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:58 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:58 --> URI Class Initialized
INFO - 2023-08-22 17:34:58 --> Router Class Initialized
INFO - 2023-08-22 17:34:58 --> Output Class Initialized
INFO - 2023-08-22 17:34:58 --> Security Class Initialized
DEBUG - 2023-08-22 17:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:58 --> Input Class Initialized
INFO - 2023-08-22 17:34:58 --> Language Class Initialized
ERROR - 2023-08-22 17:34:58 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:58 --> Config Class Initialized
INFO - 2023-08-22 17:34:58 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:58 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:58 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:58 --> URI Class Initialized
INFO - 2023-08-22 17:34:58 --> Router Class Initialized
INFO - 2023-08-22 17:34:58 --> Output Class Initialized
INFO - 2023-08-22 17:34:58 --> Security Class Initialized
DEBUG - 2023-08-22 17:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:58 --> Input Class Initialized
INFO - 2023-08-22 17:34:58 --> Language Class Initialized
ERROR - 2023-08-22 17:34:58 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:58 --> Config Class Initialized
INFO - 2023-08-22 17:34:58 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:58 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:58 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:58 --> URI Class Initialized
INFO - 2023-08-22 17:34:58 --> Router Class Initialized
INFO - 2023-08-22 17:34:58 --> Output Class Initialized
INFO - 2023-08-22 17:34:58 --> Security Class Initialized
DEBUG - 2023-08-22 17:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:59 --> Input Class Initialized
INFO - 2023-08-22 17:34:59 --> Language Class Initialized
ERROR - 2023-08-22 17:34:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:59 --> Config Class Initialized
INFO - 2023-08-22 17:34:59 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:59 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:59 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:59 --> URI Class Initialized
INFO - 2023-08-22 17:34:59 --> Router Class Initialized
INFO - 2023-08-22 17:34:59 --> Output Class Initialized
INFO - 2023-08-22 17:34:59 --> Security Class Initialized
DEBUG - 2023-08-22 17:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:59 --> Input Class Initialized
INFO - 2023-08-22 17:34:59 --> Language Class Initialized
ERROR - 2023-08-22 17:34:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:34:59 --> Config Class Initialized
INFO - 2023-08-22 17:34:59 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:34:59 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:34:59 --> Utf8 Class Initialized
INFO - 2023-08-22 17:34:59 --> URI Class Initialized
INFO - 2023-08-22 17:34:59 --> Router Class Initialized
INFO - 2023-08-22 17:34:59 --> Output Class Initialized
INFO - 2023-08-22 17:34:59 --> Security Class Initialized
DEBUG - 2023-08-22 17:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:34:59 --> Input Class Initialized
INFO - 2023-08-22 17:34:59 --> Language Class Initialized
ERROR - 2023-08-22 17:34:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:35:04 --> Config Class Initialized
INFO - 2023-08-22 17:35:04 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:35:04 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:35:04 --> Utf8 Class Initialized
INFO - 2023-08-22 17:35:04 --> URI Class Initialized
INFO - 2023-08-22 17:35:04 --> Router Class Initialized
INFO - 2023-08-22 17:35:04 --> Output Class Initialized
INFO - 2023-08-22 17:35:04 --> Security Class Initialized
DEBUG - 2023-08-22 17:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:35:04 --> Input Class Initialized
INFO - 2023-08-22 17:35:04 --> Language Class Initialized
INFO - 2023-08-22 17:35:04 --> Loader Class Initialized
INFO - 2023-08-22 17:35:04 --> Helper loaded: url_helper
INFO - 2023-08-22 17:35:04 --> Helper loaded: file_helper
INFO - 2023-08-22 17:35:04 --> Database Driver Class Initialized
INFO - 2023-08-22 17:35:04 --> Email Class Initialized
DEBUG - 2023-08-22 17:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:35:04 --> Controller Class Initialized
INFO - 2023-08-22 17:35:04 --> Model "Home_model" initialized
INFO - 2023-08-22 17:35:04 --> Helper loaded: form_helper
INFO - 2023-08-22 17:35:04 --> Form Validation Class Initialized
INFO - 2023-08-22 17:35:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:35:04 --> Final output sent to browser
DEBUG - 2023-08-22 17:35:04 --> Total execution time: 0.0581
INFO - 2023-08-22 17:35:04 --> Config Class Initialized
INFO - 2023-08-22 17:35:04 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:35:04 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:35:04 --> Utf8 Class Initialized
INFO - 2023-08-22 17:35:04 --> URI Class Initialized
INFO - 2023-08-22 17:35:04 --> Router Class Initialized
INFO - 2023-08-22 17:35:04 --> Output Class Initialized
INFO - 2023-08-22 17:35:04 --> Security Class Initialized
DEBUG - 2023-08-22 17:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:35:04 --> Input Class Initialized
INFO - 2023-08-22 17:35:04 --> Language Class Initialized
ERROR - 2023-08-22 17:35:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:35:04 --> Config Class Initialized
INFO - 2023-08-22 17:35:04 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:35:04 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:35:04 --> Utf8 Class Initialized
INFO - 2023-08-22 17:35:04 --> URI Class Initialized
INFO - 2023-08-22 17:35:04 --> Router Class Initialized
INFO - 2023-08-22 17:35:04 --> Output Class Initialized
INFO - 2023-08-22 17:35:04 --> Security Class Initialized
DEBUG - 2023-08-22 17:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:35:04 --> Input Class Initialized
INFO - 2023-08-22 17:35:04 --> Language Class Initialized
ERROR - 2023-08-22 17:35:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:35:04 --> Config Class Initialized
INFO - 2023-08-22 17:35:04 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:35:04 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:35:04 --> Utf8 Class Initialized
INFO - 2023-08-22 17:35:04 --> URI Class Initialized
INFO - 2023-08-22 17:35:04 --> Router Class Initialized
INFO - 2023-08-22 17:35:04 --> Output Class Initialized
INFO - 2023-08-22 17:35:04 --> Security Class Initialized
DEBUG - 2023-08-22 17:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:35:04 --> Input Class Initialized
INFO - 2023-08-22 17:35:04 --> Language Class Initialized
ERROR - 2023-08-22 17:35:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:35:04 --> Config Class Initialized
INFO - 2023-08-22 17:35:04 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:35:04 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:35:04 --> Utf8 Class Initialized
INFO - 2023-08-22 17:35:04 --> URI Class Initialized
INFO - 2023-08-22 17:35:04 --> Router Class Initialized
INFO - 2023-08-22 17:35:04 --> Output Class Initialized
INFO - 2023-08-22 17:35:04 --> Security Class Initialized
DEBUG - 2023-08-22 17:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:35:04 --> Input Class Initialized
INFO - 2023-08-22 17:35:04 --> Language Class Initialized
ERROR - 2023-08-22 17:35:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:35:04 --> Config Class Initialized
INFO - 2023-08-22 17:35:04 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:35:04 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:35:04 --> Utf8 Class Initialized
INFO - 2023-08-22 17:35:04 --> URI Class Initialized
INFO - 2023-08-22 17:35:04 --> Router Class Initialized
INFO - 2023-08-22 17:35:04 --> Output Class Initialized
INFO - 2023-08-22 17:35:04 --> Security Class Initialized
DEBUG - 2023-08-22 17:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:35:04 --> Input Class Initialized
INFO - 2023-08-22 17:35:04 --> Language Class Initialized
ERROR - 2023-08-22 17:35:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:35:04 --> Config Class Initialized
INFO - 2023-08-22 17:35:04 --> Config Class Initialized
INFO - 2023-08-22 17:35:04 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:35:04 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:35:04 --> Utf8 Class Initialized
INFO - 2023-08-22 17:35:04 --> URI Class Initialized
INFO - 2023-08-22 17:35:04 --> Router Class Initialized
INFO - 2023-08-22 17:35:04 --> Output Class Initialized
INFO - 2023-08-22 17:35:04 --> Security Class Initialized
DEBUG - 2023-08-22 17:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:35:04 --> Input Class Initialized
INFO - 2023-08-22 17:35:04 --> Language Class Initialized
ERROR - 2023-08-22 17:35:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:35:04 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:35:05 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:35:05 --> Utf8 Class Initialized
INFO - 2023-08-22 17:35:05 --> URI Class Initialized
INFO - 2023-08-22 17:35:05 --> Router Class Initialized
INFO - 2023-08-22 17:35:05 --> Output Class Initialized
INFO - 2023-08-22 17:35:05 --> Security Class Initialized
DEBUG - 2023-08-22 17:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:35:05 --> Input Class Initialized
INFO - 2023-08-22 17:35:05 --> Language Class Initialized
ERROR - 2023-08-22 17:35:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:35:14 --> Config Class Initialized
INFO - 2023-08-22 17:35:14 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:35:14 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:35:14 --> Utf8 Class Initialized
INFO - 2023-08-22 17:35:14 --> URI Class Initialized
INFO - 2023-08-22 17:35:14 --> Router Class Initialized
INFO - 2023-08-22 17:35:14 --> Output Class Initialized
INFO - 2023-08-22 17:35:14 --> Security Class Initialized
DEBUG - 2023-08-22 17:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:35:14 --> Input Class Initialized
INFO - 2023-08-22 17:35:14 --> Language Class Initialized
INFO - 2023-08-22 17:35:14 --> Loader Class Initialized
INFO - 2023-08-22 17:35:14 --> Helper loaded: url_helper
INFO - 2023-08-22 17:35:14 --> Helper loaded: file_helper
INFO - 2023-08-22 17:35:14 --> Database Driver Class Initialized
INFO - 2023-08-22 17:35:14 --> Email Class Initialized
DEBUG - 2023-08-22 17:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:35:14 --> Controller Class Initialized
INFO - 2023-08-22 17:35:14 --> Model "Home_model" initialized
INFO - 2023-08-22 17:35:14 --> Helper loaded: form_helper
INFO - 2023-08-22 17:35:14 --> Form Validation Class Initialized
INFO - 2023-08-22 17:35:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 17:35:14 --> Final output sent to browser
DEBUG - 2023-08-22 17:35:15 --> Total execution time: 0.1683
INFO - 2023-08-22 17:35:15 --> Config Class Initialized
INFO - 2023-08-22 17:35:15 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:35:15 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:35:15 --> Utf8 Class Initialized
INFO - 2023-08-22 17:35:15 --> URI Class Initialized
INFO - 2023-08-22 17:35:15 --> Router Class Initialized
INFO - 2023-08-22 17:35:15 --> Output Class Initialized
INFO - 2023-08-22 17:35:15 --> Security Class Initialized
DEBUG - 2023-08-22 17:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:35:15 --> Input Class Initialized
INFO - 2023-08-22 17:35:15 --> Language Class Initialized
ERROR - 2023-08-22 17:35:15 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:35:15 --> Config Class Initialized
INFO - 2023-08-22 17:35:15 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:35:15 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:35:15 --> Utf8 Class Initialized
INFO - 2023-08-22 17:35:15 --> URI Class Initialized
INFO - 2023-08-22 17:35:15 --> Router Class Initialized
INFO - 2023-08-22 17:35:16 --> Output Class Initialized
INFO - 2023-08-22 17:35:16 --> Security Class Initialized
DEBUG - 2023-08-22 17:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:35:16 --> Input Class Initialized
INFO - 2023-08-22 17:35:16 --> Language Class Initialized
ERROR - 2023-08-22 17:35:16 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:35:16 --> Config Class Initialized
INFO - 2023-08-22 17:35:16 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:35:16 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:35:16 --> Utf8 Class Initialized
INFO - 2023-08-22 17:35:16 --> URI Class Initialized
INFO - 2023-08-22 17:35:16 --> Router Class Initialized
INFO - 2023-08-22 17:35:16 --> Output Class Initialized
INFO - 2023-08-22 17:35:16 --> Security Class Initialized
DEBUG - 2023-08-22 17:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:35:16 --> Input Class Initialized
INFO - 2023-08-22 17:35:16 --> Language Class Initialized
ERROR - 2023-08-22 17:35:16 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:35:16 --> Config Class Initialized
INFO - 2023-08-22 17:35:16 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:35:16 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:35:16 --> Utf8 Class Initialized
INFO - 2023-08-22 17:35:16 --> URI Class Initialized
INFO - 2023-08-22 17:35:16 --> Router Class Initialized
INFO - 2023-08-22 17:35:16 --> Output Class Initialized
INFO - 2023-08-22 17:35:16 --> Security Class Initialized
DEBUG - 2023-08-22 17:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:35:16 --> Input Class Initialized
INFO - 2023-08-22 17:35:16 --> Language Class Initialized
ERROR - 2023-08-22 17:35:16 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:35:16 --> Config Class Initialized
INFO - 2023-08-22 17:35:16 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:35:16 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:35:16 --> Utf8 Class Initialized
INFO - 2023-08-22 17:35:16 --> URI Class Initialized
INFO - 2023-08-22 17:35:16 --> Router Class Initialized
INFO - 2023-08-22 17:35:16 --> Output Class Initialized
INFO - 2023-08-22 17:35:16 --> Security Class Initialized
DEBUG - 2023-08-22 17:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:35:16 --> Input Class Initialized
INFO - 2023-08-22 17:35:16 --> Language Class Initialized
ERROR - 2023-08-22 17:35:16 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 17:50:27 --> Config Class Initialized
INFO - 2023-08-22 17:50:27 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:50:27 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:50:27 --> Utf8 Class Initialized
INFO - 2023-08-22 17:50:27 --> URI Class Initialized
INFO - 2023-08-22 17:50:27 --> Router Class Initialized
INFO - 2023-08-22 17:50:27 --> Output Class Initialized
INFO - 2023-08-22 17:50:27 --> Security Class Initialized
DEBUG - 2023-08-22 17:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:50:27 --> Input Class Initialized
INFO - 2023-08-22 17:50:27 --> Language Class Initialized
INFO - 2023-08-22 17:50:27 --> Loader Class Initialized
INFO - 2023-08-22 17:50:27 --> Helper loaded: url_helper
INFO - 2023-08-22 17:50:27 --> Helper loaded: file_helper
INFO - 2023-08-22 17:50:27 --> Database Driver Class Initialized
INFO - 2023-08-22 17:50:27 --> Email Class Initialized
DEBUG - 2023-08-22 17:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:50:27 --> Controller Class Initialized
INFO - 2023-08-22 17:50:27 --> Config Class Initialized
INFO - 2023-08-22 17:50:27 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:50:27 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:50:27 --> Utf8 Class Initialized
INFO - 2023-08-22 17:50:27 --> URI Class Initialized
INFO - 2023-08-22 17:50:27 --> Router Class Initialized
INFO - 2023-08-22 17:50:27 --> Output Class Initialized
INFO - 2023-08-22 17:50:27 --> Security Class Initialized
DEBUG - 2023-08-22 17:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:50:27 --> Input Class Initialized
INFO - 2023-08-22 17:50:27 --> Language Class Initialized
INFO - 2023-08-22 17:50:27 --> Loader Class Initialized
INFO - 2023-08-22 17:50:27 --> Helper loaded: url_helper
INFO - 2023-08-22 17:50:27 --> Helper loaded: file_helper
INFO - 2023-08-22 17:50:27 --> Database Driver Class Initialized
INFO - 2023-08-22 17:50:27 --> Email Class Initialized
DEBUG - 2023-08-22 17:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:50:28 --> Controller Class Initialized
INFO - 2023-08-22 17:50:28 --> Model "User_model" initialized
INFO - 2023-08-22 17:50:28 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-22 17:50:28 --> Final output sent to browser
DEBUG - 2023-08-22 17:50:28 --> Total execution time: 0.5150
INFO - 2023-08-22 17:50:29 --> Config Class Initialized
INFO - 2023-08-22 17:50:29 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:50:29 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:50:29 --> Utf8 Class Initialized
INFO - 2023-08-22 17:50:29 --> URI Class Initialized
INFO - 2023-08-22 17:50:29 --> Router Class Initialized
INFO - 2023-08-22 17:50:29 --> Output Class Initialized
INFO - 2023-08-22 17:50:30 --> Security Class Initialized
DEBUG - 2023-08-22 17:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:50:30 --> Input Class Initialized
INFO - 2023-08-22 17:50:30 --> Language Class Initialized
ERROR - 2023-08-22 17:50:30 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-22 17:50:35 --> Config Class Initialized
INFO - 2023-08-22 17:50:35 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:50:35 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:50:35 --> Utf8 Class Initialized
INFO - 2023-08-22 17:50:35 --> URI Class Initialized
INFO - 2023-08-22 17:50:35 --> Router Class Initialized
INFO - 2023-08-22 17:50:35 --> Output Class Initialized
INFO - 2023-08-22 17:50:35 --> Security Class Initialized
DEBUG - 2023-08-22 17:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:50:36 --> Input Class Initialized
INFO - 2023-08-22 17:50:36 --> Language Class Initialized
INFO - 2023-08-22 17:50:36 --> Loader Class Initialized
INFO - 2023-08-22 17:50:36 --> Helper loaded: url_helper
INFO - 2023-08-22 17:50:36 --> Helper loaded: file_helper
INFO - 2023-08-22 17:50:36 --> Database Driver Class Initialized
INFO - 2023-08-22 17:50:36 --> Email Class Initialized
DEBUG - 2023-08-22 17:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:50:36 --> Controller Class Initialized
INFO - 2023-08-22 17:50:36 --> Model "User_model" initialized
INFO - 2023-08-22 17:50:36 --> Config Class Initialized
INFO - 2023-08-22 17:50:36 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:50:36 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:50:36 --> Utf8 Class Initialized
INFO - 2023-08-22 17:50:36 --> URI Class Initialized
INFO - 2023-08-22 17:50:36 --> Router Class Initialized
INFO - 2023-08-22 17:50:36 --> Output Class Initialized
INFO - 2023-08-22 17:50:36 --> Security Class Initialized
DEBUG - 2023-08-22 17:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:50:36 --> Input Class Initialized
INFO - 2023-08-22 17:50:36 --> Language Class Initialized
INFO - 2023-08-22 17:50:36 --> Loader Class Initialized
INFO - 2023-08-22 17:50:36 --> Helper loaded: url_helper
INFO - 2023-08-22 17:50:36 --> Helper loaded: file_helper
INFO - 2023-08-22 17:50:36 --> Database Driver Class Initialized
INFO - 2023-08-22 17:50:36 --> Email Class Initialized
DEBUG - 2023-08-22 17:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:50:36 --> Controller Class Initialized
INFO - 2023-08-22 17:50:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-22 17:50:36 --> Final output sent to browser
DEBUG - 2023-08-22 17:50:36 --> Total execution time: 0.4879
INFO - 2023-08-22 17:50:41 --> Config Class Initialized
INFO - 2023-08-22 17:50:41 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:50:41 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:50:41 --> Utf8 Class Initialized
INFO - 2023-08-22 17:50:41 --> URI Class Initialized
INFO - 2023-08-22 17:50:41 --> Router Class Initialized
INFO - 2023-08-22 17:50:41 --> Output Class Initialized
INFO - 2023-08-22 17:50:41 --> Security Class Initialized
DEBUG - 2023-08-22 17:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:50:41 --> Input Class Initialized
INFO - 2023-08-22 17:50:41 --> Language Class Initialized
INFO - 2023-08-22 17:50:42 --> Loader Class Initialized
INFO - 2023-08-22 17:50:42 --> Helper loaded: url_helper
INFO - 2023-08-22 17:50:42 --> Helper loaded: file_helper
INFO - 2023-08-22 17:50:42 --> Database Driver Class Initialized
INFO - 2023-08-22 17:50:42 --> Email Class Initialized
DEBUG - 2023-08-22 17:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:50:42 --> Controller Class Initialized
INFO - 2023-08-22 17:50:42 --> Model "Training_model" initialized
INFO - 2023-08-22 17:50:42 --> Helper loaded: form_helper
INFO - 2023-08-22 17:50:42 --> Form Validation Class Initialized
INFO - 2023-08-22 17:50:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-22 17:50:42 --> Final output sent to browser
DEBUG - 2023-08-22 17:50:42 --> Total execution time: 0.5033
INFO - 2023-08-22 17:50:45 --> Config Class Initialized
INFO - 2023-08-22 17:50:45 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:50:45 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:50:45 --> Utf8 Class Initialized
INFO - 2023-08-22 17:50:45 --> URI Class Initialized
INFO - 2023-08-22 17:50:45 --> Router Class Initialized
INFO - 2023-08-22 17:50:45 --> Output Class Initialized
INFO - 2023-08-22 17:50:45 --> Security Class Initialized
DEBUG - 2023-08-22 17:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:50:45 --> Input Class Initialized
INFO - 2023-08-22 17:50:45 --> Language Class Initialized
INFO - 2023-08-22 17:50:45 --> Loader Class Initialized
INFO - 2023-08-22 17:50:45 --> Helper loaded: url_helper
INFO - 2023-08-22 17:50:45 --> Helper loaded: file_helper
INFO - 2023-08-22 17:50:45 --> Database Driver Class Initialized
INFO - 2023-08-22 17:50:45 --> Email Class Initialized
DEBUG - 2023-08-22 17:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:50:45 --> Controller Class Initialized
INFO - 2023-08-22 17:50:45 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 17:50:45 --> Helper loaded: form_helper
INFO - 2023-08-22 17:50:45 --> Form Validation Class Initialized
INFO - 2023-08-22 17:50:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-22 17:50:45 --> Final output sent to browser
DEBUG - 2023-08-22 17:50:45 --> Total execution time: 0.5778
INFO - 2023-08-22 17:50:46 --> Config Class Initialized
INFO - 2023-08-22 17:50:46 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:50:46 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:50:46 --> Utf8 Class Initialized
INFO - 2023-08-22 17:50:46 --> URI Class Initialized
INFO - 2023-08-22 17:50:46 --> Router Class Initialized
INFO - 2023-08-22 17:50:46 --> Output Class Initialized
INFO - 2023-08-22 17:50:46 --> Security Class Initialized
DEBUG - 2023-08-22 17:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:50:46 --> Input Class Initialized
INFO - 2023-08-22 17:50:46 --> Language Class Initialized
ERROR - 2023-08-22 17:50:46 --> 404 Page Not Found: admin/Training_curriculum/images
INFO - 2023-08-22 17:50:49 --> Config Class Initialized
INFO - 2023-08-22 17:50:49 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:50:49 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:50:49 --> Utf8 Class Initialized
INFO - 2023-08-22 17:50:49 --> URI Class Initialized
INFO - 2023-08-22 17:50:49 --> Router Class Initialized
INFO - 2023-08-22 17:50:49 --> Output Class Initialized
INFO - 2023-08-22 17:50:49 --> Security Class Initialized
DEBUG - 2023-08-22 17:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:50:49 --> Input Class Initialized
INFO - 2023-08-22 17:50:49 --> Language Class Initialized
INFO - 2023-08-22 17:50:49 --> Loader Class Initialized
INFO - 2023-08-22 17:50:49 --> Helper loaded: url_helper
INFO - 2023-08-22 17:50:49 --> Helper loaded: file_helper
INFO - 2023-08-22 17:50:49 --> Database Driver Class Initialized
INFO - 2023-08-22 17:50:49 --> Email Class Initialized
DEBUG - 2023-08-22 17:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:50:49 --> Controller Class Initialized
INFO - 2023-08-22 17:50:49 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 17:50:49 --> Helper loaded: form_helper
INFO - 2023-08-22 17:50:49 --> Form Validation Class Initialized
INFO - 2023-08-22 17:50:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-08-22 17:50:49 --> Final output sent to browser
DEBUG - 2023-08-22 17:50:49 --> Total execution time: 0.5328
INFO - 2023-08-22 17:50:50 --> Config Class Initialized
INFO - 2023-08-22 17:50:50 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:50:50 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:50:50 --> Utf8 Class Initialized
INFO - 2023-08-22 17:50:50 --> URI Class Initialized
INFO - 2023-08-22 17:50:50 --> Router Class Initialized
INFO - 2023-08-22 17:50:50 --> Output Class Initialized
INFO - 2023-08-22 17:50:50 --> Security Class Initialized
DEBUG - 2023-08-22 17:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:50:50 --> Input Class Initialized
INFO - 2023-08-22 17:50:50 --> Language Class Initialized
ERROR - 2023-08-22 17:50:50 --> 404 Page Not Found: admin/Training_curriculum/add
INFO - 2023-08-22 17:54:26 --> Config Class Initialized
INFO - 2023-08-22 17:54:26 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:54:26 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:54:26 --> Utf8 Class Initialized
INFO - 2023-08-22 17:54:26 --> URI Class Initialized
INFO - 2023-08-22 17:54:26 --> Router Class Initialized
INFO - 2023-08-22 17:54:26 --> Output Class Initialized
INFO - 2023-08-22 17:54:26 --> Security Class Initialized
DEBUG - 2023-08-22 17:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:54:26 --> Input Class Initialized
INFO - 2023-08-22 17:54:26 --> Language Class Initialized
ERROR - 2023-08-22 17:54:26 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 17:54:26 --> Config Class Initialized
INFO - 2023-08-22 17:54:26 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:54:26 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:54:26 --> Utf8 Class Initialized
INFO - 2023-08-22 17:54:26 --> URI Class Initialized
INFO - 2023-08-22 17:54:26 --> Router Class Initialized
INFO - 2023-08-22 17:54:26 --> Output Class Initialized
INFO - 2023-08-22 17:54:26 --> Security Class Initialized
DEBUG - 2023-08-22 17:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:54:26 --> Input Class Initialized
INFO - 2023-08-22 17:54:26 --> Language Class Initialized
ERROR - 2023-08-22 17:54:26 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 17:56:01 --> Config Class Initialized
INFO - 2023-08-22 17:56:01 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:56:01 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:56:01 --> Utf8 Class Initialized
INFO - 2023-08-22 17:56:01 --> URI Class Initialized
INFO - 2023-08-22 17:56:01 --> Router Class Initialized
INFO - 2023-08-22 17:56:01 --> Output Class Initialized
INFO - 2023-08-22 17:56:01 --> Security Class Initialized
DEBUG - 2023-08-22 17:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:56:01 --> Input Class Initialized
INFO - 2023-08-22 17:56:01 --> Language Class Initialized
INFO - 2023-08-22 17:56:01 --> Loader Class Initialized
INFO - 2023-08-22 17:56:01 --> Helper loaded: url_helper
INFO - 2023-08-22 17:56:01 --> Helper loaded: file_helper
INFO - 2023-08-22 17:56:01 --> Database Driver Class Initialized
INFO - 2023-08-22 17:56:01 --> Email Class Initialized
DEBUG - 2023-08-22 17:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:56:01 --> Controller Class Initialized
INFO - 2023-08-22 17:56:01 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 17:56:01 --> Helper loaded: form_helper
INFO - 2023-08-22 17:56:01 --> Form Validation Class Initialized
INFO - 2023-08-22 17:56:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-08-22 17:56:02 --> Final output sent to browser
DEBUG - 2023-08-22 17:56:02 --> Total execution time: 0.2636
INFO - 2023-08-22 17:56:02 --> Config Class Initialized
INFO - 2023-08-22 17:56:02 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:56:02 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:56:02 --> Utf8 Class Initialized
INFO - 2023-08-22 17:56:02 --> URI Class Initialized
INFO - 2023-08-22 17:56:02 --> Router Class Initialized
INFO - 2023-08-22 17:56:02 --> Output Class Initialized
INFO - 2023-08-22 17:56:02 --> Security Class Initialized
DEBUG - 2023-08-22 17:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:56:02 --> Input Class Initialized
INFO - 2023-08-22 17:56:02 --> Language Class Initialized
ERROR - 2023-08-22 17:56:02 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 17:56:03 --> Config Class Initialized
INFO - 2023-08-22 17:56:03 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:56:03 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:56:03 --> Utf8 Class Initialized
INFO - 2023-08-22 17:56:03 --> URI Class Initialized
INFO - 2023-08-22 17:56:03 --> Router Class Initialized
INFO - 2023-08-22 17:56:03 --> Output Class Initialized
INFO - 2023-08-22 17:56:03 --> Security Class Initialized
DEBUG - 2023-08-22 17:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:56:03 --> Input Class Initialized
INFO - 2023-08-22 17:56:03 --> Language Class Initialized
ERROR - 2023-08-22 17:56:03 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 17:56:26 --> Config Class Initialized
INFO - 2023-08-22 17:56:26 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:56:26 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:56:26 --> Utf8 Class Initialized
INFO - 2023-08-22 17:56:26 --> URI Class Initialized
INFO - 2023-08-22 17:56:26 --> Router Class Initialized
INFO - 2023-08-22 17:56:26 --> Output Class Initialized
INFO - 2023-08-22 17:56:26 --> Security Class Initialized
DEBUG - 2023-08-22 17:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:56:26 --> Input Class Initialized
INFO - 2023-08-22 17:56:26 --> Language Class Initialized
INFO - 2023-08-22 17:56:26 --> Loader Class Initialized
INFO - 2023-08-22 17:56:26 --> Helper loaded: url_helper
INFO - 2023-08-22 17:56:26 --> Helper loaded: file_helper
INFO - 2023-08-22 17:56:26 --> Database Driver Class Initialized
INFO - 2023-08-22 17:56:26 --> Email Class Initialized
DEBUG - 2023-08-22 17:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:56:26 --> Controller Class Initialized
INFO - 2023-08-22 17:56:26 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 17:56:26 --> Helper loaded: form_helper
INFO - 2023-08-22 17:56:26 --> Form Validation Class Initialized
INFO - 2023-08-22 17:56:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-22 17:56:26 --> Config Class Initialized
INFO - 2023-08-22 17:56:26 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:56:26 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:56:26 --> Utf8 Class Initialized
INFO - 2023-08-22 17:56:26 --> URI Class Initialized
INFO - 2023-08-22 17:56:26 --> Router Class Initialized
INFO - 2023-08-22 17:56:26 --> Output Class Initialized
INFO - 2023-08-22 17:56:26 --> Security Class Initialized
DEBUG - 2023-08-22 17:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:56:26 --> Input Class Initialized
INFO - 2023-08-22 17:56:26 --> Language Class Initialized
INFO - 2023-08-22 17:56:26 --> Loader Class Initialized
INFO - 2023-08-22 17:56:26 --> Helper loaded: url_helper
INFO - 2023-08-22 17:56:26 --> Helper loaded: file_helper
INFO - 2023-08-22 17:56:26 --> Database Driver Class Initialized
INFO - 2023-08-22 17:56:26 --> Email Class Initialized
DEBUG - 2023-08-22 17:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 17:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 17:56:26 --> Controller Class Initialized
INFO - 2023-08-22 17:56:26 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 17:56:26 --> Helper loaded: form_helper
INFO - 2023-08-22 17:56:26 --> Form Validation Class Initialized
INFO - 2023-08-22 17:56:26 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-22 17:56:26 --> Final output sent to browser
DEBUG - 2023-08-22 17:56:26 --> Total execution time: 0.0550
INFO - 2023-08-22 17:56:27 --> Config Class Initialized
INFO - 2023-08-22 17:56:27 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:56:27 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:56:27 --> Utf8 Class Initialized
INFO - 2023-08-22 17:56:27 --> URI Class Initialized
INFO - 2023-08-22 17:56:27 --> Router Class Initialized
INFO - 2023-08-22 17:56:27 --> Output Class Initialized
INFO - 2023-08-22 17:56:27 --> Security Class Initialized
DEBUG - 2023-08-22 17:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:56:27 --> Input Class Initialized
INFO - 2023-08-22 17:56:27 --> Language Class Initialized
ERROR - 2023-08-22 17:56:27 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 17:56:27 --> Config Class Initialized
INFO - 2023-08-22 17:56:27 --> Hooks Class Initialized
DEBUG - 2023-08-22 17:56:27 --> UTF-8 Support Enabled
INFO - 2023-08-22 17:56:27 --> Utf8 Class Initialized
INFO - 2023-08-22 17:56:27 --> URI Class Initialized
INFO - 2023-08-22 17:56:27 --> Router Class Initialized
INFO - 2023-08-22 17:56:27 --> Output Class Initialized
INFO - 2023-08-22 17:56:27 --> Security Class Initialized
DEBUG - 2023-08-22 17:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 17:56:27 --> Input Class Initialized
INFO - 2023-08-22 17:56:27 --> Language Class Initialized
ERROR - 2023-08-22 17:56:27 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 18:24:29 --> Config Class Initialized
INFO - 2023-08-22 18:24:29 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:24:29 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:24:29 --> Utf8 Class Initialized
INFO - 2023-08-22 18:24:29 --> URI Class Initialized
INFO - 2023-08-22 18:24:29 --> Router Class Initialized
INFO - 2023-08-22 18:24:29 --> Output Class Initialized
INFO - 2023-08-22 18:24:29 --> Security Class Initialized
DEBUG - 2023-08-22 18:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:24:29 --> Input Class Initialized
INFO - 2023-08-22 18:24:29 --> Language Class Initialized
INFO - 2023-08-22 18:24:29 --> Loader Class Initialized
INFO - 2023-08-22 18:24:29 --> Helper loaded: url_helper
INFO - 2023-08-22 18:24:29 --> Helper loaded: file_helper
INFO - 2023-08-22 18:24:29 --> Database Driver Class Initialized
INFO - 2023-08-22 18:24:29 --> Email Class Initialized
DEBUG - 2023-08-22 18:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 18:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 18:24:29 --> Controller Class Initialized
INFO - 2023-08-22 18:24:29 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 18:24:29 --> Helper loaded: form_helper
INFO - 2023-08-22 18:24:29 --> Form Validation Class Initialized
INFO - 2023-08-22 18:24:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_edit.php
INFO - 2023-08-22 18:24:29 --> Final output sent to browser
DEBUG - 2023-08-22 18:24:30 --> Total execution time: 0.4822
INFO - 2023-08-22 18:24:30 --> Config Class Initialized
INFO - 2023-08-22 18:24:30 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:24:30 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:24:30 --> Utf8 Class Initialized
INFO - 2023-08-22 18:24:30 --> URI Class Initialized
INFO - 2023-08-22 18:24:30 --> Router Class Initialized
INFO - 2023-08-22 18:24:30 --> Output Class Initialized
INFO - 2023-08-22 18:24:30 --> Security Class Initialized
DEBUG - 2023-08-22 18:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:24:30 --> Input Class Initialized
INFO - 2023-08-22 18:24:30 --> Language Class Initialized
ERROR - 2023-08-22 18:24:30 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 18:24:31 --> Config Class Initialized
INFO - 2023-08-22 18:24:31 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:24:31 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:24:31 --> Utf8 Class Initialized
INFO - 2023-08-22 18:24:31 --> URI Class Initialized
INFO - 2023-08-22 18:24:31 --> Router Class Initialized
INFO - 2023-08-22 18:24:31 --> Output Class Initialized
INFO - 2023-08-22 18:24:31 --> Security Class Initialized
DEBUG - 2023-08-22 18:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:24:31 --> Input Class Initialized
INFO - 2023-08-22 18:24:31 --> Language Class Initialized
ERROR - 2023-08-22 18:24:31 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 18:24:39 --> Config Class Initialized
INFO - 2023-08-22 18:24:39 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:24:39 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:24:39 --> Utf8 Class Initialized
INFO - 2023-08-22 18:24:39 --> URI Class Initialized
INFO - 2023-08-22 18:24:39 --> Router Class Initialized
INFO - 2023-08-22 18:24:39 --> Output Class Initialized
INFO - 2023-08-22 18:24:39 --> Security Class Initialized
DEBUG - 2023-08-22 18:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:24:39 --> Input Class Initialized
INFO - 2023-08-22 18:24:39 --> Language Class Initialized
INFO - 2023-08-22 18:24:39 --> Loader Class Initialized
INFO - 2023-08-22 18:24:39 --> Helper loaded: url_helper
INFO - 2023-08-22 18:24:39 --> Helper loaded: file_helper
INFO - 2023-08-22 18:24:39 --> Database Driver Class Initialized
INFO - 2023-08-22 18:24:39 --> Email Class Initialized
DEBUG - 2023-08-22 18:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 18:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 18:24:39 --> Controller Class Initialized
INFO - 2023-08-22 18:24:39 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 18:24:39 --> Helper loaded: form_helper
INFO - 2023-08-22 18:24:39 --> Form Validation Class Initialized
INFO - 2023-08-22 18:24:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-22 18:24:39 --> Config Class Initialized
INFO - 2023-08-22 18:24:39 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:24:39 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:24:39 --> Utf8 Class Initialized
INFO - 2023-08-22 18:24:39 --> URI Class Initialized
INFO - 2023-08-22 18:24:39 --> Router Class Initialized
INFO - 2023-08-22 18:24:39 --> Output Class Initialized
INFO - 2023-08-22 18:24:39 --> Security Class Initialized
DEBUG - 2023-08-22 18:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:24:39 --> Input Class Initialized
INFO - 2023-08-22 18:24:39 --> Language Class Initialized
INFO - 2023-08-22 18:24:39 --> Loader Class Initialized
INFO - 2023-08-22 18:24:39 --> Helper loaded: url_helper
INFO - 2023-08-22 18:24:39 --> Helper loaded: file_helper
INFO - 2023-08-22 18:24:39 --> Database Driver Class Initialized
INFO - 2023-08-22 18:24:39 --> Email Class Initialized
DEBUG - 2023-08-22 18:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 18:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 18:24:39 --> Controller Class Initialized
INFO - 2023-08-22 18:24:39 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 18:24:39 --> Helper loaded: form_helper
INFO - 2023-08-22 18:24:39 --> Form Validation Class Initialized
INFO - 2023-08-22 18:24:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-22 18:24:39 --> Final output sent to browser
DEBUG - 2023-08-22 18:24:39 --> Total execution time: 0.0477
INFO - 2023-08-22 18:24:40 --> Config Class Initialized
INFO - 2023-08-22 18:24:40 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:24:40 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:24:40 --> Utf8 Class Initialized
INFO - 2023-08-22 18:24:40 --> URI Class Initialized
INFO - 2023-08-22 18:24:40 --> Router Class Initialized
INFO - 2023-08-22 18:24:40 --> Output Class Initialized
INFO - 2023-08-22 18:24:40 --> Security Class Initialized
DEBUG - 2023-08-22 18:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:24:40 --> Input Class Initialized
INFO - 2023-08-22 18:24:40 --> Language Class Initialized
ERROR - 2023-08-22 18:24:40 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 18:24:40 --> Config Class Initialized
INFO - 2023-08-22 18:24:40 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:24:40 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:24:40 --> Utf8 Class Initialized
INFO - 2023-08-22 18:24:40 --> URI Class Initialized
INFO - 2023-08-22 18:24:40 --> Router Class Initialized
INFO - 2023-08-22 18:24:40 --> Output Class Initialized
INFO - 2023-08-22 18:24:40 --> Security Class Initialized
DEBUG - 2023-08-22 18:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:24:40 --> Input Class Initialized
INFO - 2023-08-22 18:24:40 --> Language Class Initialized
ERROR - 2023-08-22 18:24:40 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 18:26:57 --> Config Class Initialized
INFO - 2023-08-22 18:26:57 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:26:57 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:26:57 --> Utf8 Class Initialized
INFO - 2023-08-22 18:26:57 --> URI Class Initialized
INFO - 2023-08-22 18:26:57 --> Router Class Initialized
INFO - 2023-08-22 18:26:57 --> Output Class Initialized
INFO - 2023-08-22 18:26:57 --> Security Class Initialized
DEBUG - 2023-08-22 18:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:26:57 --> Input Class Initialized
INFO - 2023-08-22 18:26:57 --> Language Class Initialized
INFO - 2023-08-22 18:26:57 --> Loader Class Initialized
INFO - 2023-08-22 18:26:58 --> Helper loaded: url_helper
INFO - 2023-08-22 18:26:58 --> Helper loaded: file_helper
INFO - 2023-08-22 18:26:58 --> Database Driver Class Initialized
INFO - 2023-08-22 18:26:58 --> Email Class Initialized
DEBUG - 2023-08-22 18:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 18:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 18:26:58 --> Controller Class Initialized
INFO - 2023-08-22 18:26:58 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 18:26:58 --> Helper loaded: form_helper
INFO - 2023-08-22 18:26:58 --> Form Validation Class Initialized
INFO - 2023-08-22 18:26:58 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_edit.php
INFO - 2023-08-22 18:26:58 --> Final output sent to browser
DEBUG - 2023-08-22 18:26:58 --> Total execution time: 0.8613
INFO - 2023-08-22 18:26:59 --> Config Class Initialized
INFO - 2023-08-22 18:26:59 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:26:59 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:26:59 --> Utf8 Class Initialized
INFO - 2023-08-22 18:26:59 --> URI Class Initialized
INFO - 2023-08-22 18:26:59 --> Router Class Initialized
INFO - 2023-08-22 18:26:59 --> Output Class Initialized
INFO - 2023-08-22 18:26:59 --> Security Class Initialized
DEBUG - 2023-08-22 18:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:26:59 --> Input Class Initialized
INFO - 2023-08-22 18:26:59 --> Language Class Initialized
ERROR - 2023-08-22 18:26:59 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 18:26:59 --> Config Class Initialized
INFO - 2023-08-22 18:26:59 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:26:59 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:26:59 --> Utf8 Class Initialized
INFO - 2023-08-22 18:26:59 --> URI Class Initialized
INFO - 2023-08-22 18:26:59 --> Router Class Initialized
INFO - 2023-08-22 18:26:59 --> Output Class Initialized
INFO - 2023-08-22 18:26:59 --> Security Class Initialized
DEBUG - 2023-08-22 18:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:26:59 --> Input Class Initialized
INFO - 2023-08-22 18:26:59 --> Language Class Initialized
ERROR - 2023-08-22 18:26:59 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 18:27:00 --> Config Class Initialized
INFO - 2023-08-22 18:27:00 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:27:00 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:27:00 --> Utf8 Class Initialized
INFO - 2023-08-22 18:27:00 --> URI Class Initialized
INFO - 2023-08-22 18:27:00 --> Router Class Initialized
INFO - 2023-08-22 18:27:00 --> Output Class Initialized
INFO - 2023-08-22 18:27:00 --> Security Class Initialized
DEBUG - 2023-08-22 18:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:27:00 --> Input Class Initialized
INFO - 2023-08-22 18:27:00 --> Language Class Initialized
ERROR - 2023-08-22 18:27:00 --> 404 Page Not Found: admin/Training_curriculum/edit
INFO - 2023-08-22 18:28:55 --> Config Class Initialized
INFO - 2023-08-22 18:28:55 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:28:55 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:28:55 --> Utf8 Class Initialized
INFO - 2023-08-22 18:28:55 --> URI Class Initialized
INFO - 2023-08-22 18:28:55 --> Router Class Initialized
INFO - 2023-08-22 18:28:55 --> Output Class Initialized
INFO - 2023-08-22 18:28:55 --> Security Class Initialized
DEBUG - 2023-08-22 18:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:28:55 --> Input Class Initialized
INFO - 2023-08-22 18:28:55 --> Language Class Initialized
INFO - 2023-08-22 18:28:55 --> Loader Class Initialized
INFO - 2023-08-22 18:28:55 --> Helper loaded: url_helper
INFO - 2023-08-22 18:28:55 --> Helper loaded: file_helper
INFO - 2023-08-22 18:28:55 --> Database Driver Class Initialized
INFO - 2023-08-22 18:28:55 --> Email Class Initialized
DEBUG - 2023-08-22 18:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 18:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 18:28:56 --> Controller Class Initialized
INFO - 2023-08-22 18:28:56 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 18:28:56 --> Helper loaded: form_helper
INFO - 2023-08-22 18:28:56 --> Form Validation Class Initialized
INFO - 2023-08-22 18:28:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-22 18:28:56 --> Final output sent to browser
DEBUG - 2023-08-22 18:28:56 --> Total execution time: 0.8216
INFO - 2023-08-22 18:28:56 --> Config Class Initialized
INFO - 2023-08-22 18:28:56 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:28:56 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:28:56 --> Utf8 Class Initialized
INFO - 2023-08-22 18:28:56 --> URI Class Initialized
INFO - 2023-08-22 18:28:56 --> Router Class Initialized
INFO - 2023-08-22 18:28:56 --> Output Class Initialized
INFO - 2023-08-22 18:28:56 --> Security Class Initialized
DEBUG - 2023-08-22 18:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:28:56 --> Input Class Initialized
INFO - 2023-08-22 18:28:56 --> Language Class Initialized
ERROR - 2023-08-22 18:28:56 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 18:28:57 --> Config Class Initialized
INFO - 2023-08-22 18:28:57 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:28:57 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:28:57 --> Utf8 Class Initialized
INFO - 2023-08-22 18:28:57 --> URI Class Initialized
INFO - 2023-08-22 18:28:57 --> Router Class Initialized
INFO - 2023-08-22 18:28:57 --> Output Class Initialized
INFO - 2023-08-22 18:28:57 --> Security Class Initialized
DEBUG - 2023-08-22 18:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:28:57 --> Input Class Initialized
INFO - 2023-08-22 18:28:57 --> Language Class Initialized
ERROR - 2023-08-22 18:28:57 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 18:29:02 --> Config Class Initialized
INFO - 2023-08-22 18:29:02 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:29:02 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:29:02 --> Utf8 Class Initialized
INFO - 2023-08-22 18:29:02 --> URI Class Initialized
INFO - 2023-08-22 18:29:02 --> Router Class Initialized
INFO - 2023-08-22 18:29:02 --> Output Class Initialized
INFO - 2023-08-22 18:29:02 --> Security Class Initialized
DEBUG - 2023-08-22 18:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:29:02 --> Input Class Initialized
INFO - 2023-08-22 18:29:02 --> Language Class Initialized
INFO - 2023-08-22 18:29:02 --> Loader Class Initialized
INFO - 2023-08-22 18:29:02 --> Helper loaded: url_helper
INFO - 2023-08-22 18:29:02 --> Helper loaded: file_helper
INFO - 2023-08-22 18:29:02 --> Database Driver Class Initialized
INFO - 2023-08-22 18:29:02 --> Email Class Initialized
DEBUG - 2023-08-22 18:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 18:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 18:29:02 --> Controller Class Initialized
INFO - 2023-08-22 18:29:02 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 18:29:02 --> Helper loaded: form_helper
INFO - 2023-08-22 18:29:02 --> Form Validation Class Initialized
INFO - 2023-08-22 18:29:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-08-22 18:29:02 --> Final output sent to browser
DEBUG - 2023-08-22 18:29:02 --> Total execution time: 0.3749
INFO - 2023-08-22 18:29:03 --> Config Class Initialized
INFO - 2023-08-22 18:29:03 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:29:03 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:29:03 --> Utf8 Class Initialized
INFO - 2023-08-22 18:29:03 --> URI Class Initialized
INFO - 2023-08-22 18:29:03 --> Router Class Initialized
INFO - 2023-08-22 18:29:03 --> Output Class Initialized
INFO - 2023-08-22 18:29:03 --> Security Class Initialized
DEBUG - 2023-08-22 18:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:29:04 --> Input Class Initialized
INFO - 2023-08-22 18:29:04 --> Language Class Initialized
ERROR - 2023-08-22 18:29:04 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 18:29:04 --> Config Class Initialized
INFO - 2023-08-22 18:29:04 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:29:04 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:29:04 --> Utf8 Class Initialized
INFO - 2023-08-22 18:29:04 --> URI Class Initialized
INFO - 2023-08-22 18:29:04 --> Router Class Initialized
INFO - 2023-08-22 18:29:04 --> Output Class Initialized
INFO - 2023-08-22 18:29:04 --> Security Class Initialized
DEBUG - 2023-08-22 18:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:29:04 --> Input Class Initialized
INFO - 2023-08-22 18:29:04 --> Language Class Initialized
ERROR - 2023-08-22 18:29:04 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 18:30:15 --> Config Class Initialized
INFO - 2023-08-22 18:30:15 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:30:15 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:30:15 --> Utf8 Class Initialized
INFO - 2023-08-22 18:30:15 --> URI Class Initialized
INFO - 2023-08-22 18:30:15 --> Router Class Initialized
INFO - 2023-08-22 18:30:15 --> Output Class Initialized
INFO - 2023-08-22 18:30:15 --> Security Class Initialized
DEBUG - 2023-08-22 18:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:30:15 --> Input Class Initialized
INFO - 2023-08-22 18:30:15 --> Language Class Initialized
INFO - 2023-08-22 18:30:15 --> Loader Class Initialized
INFO - 2023-08-22 18:30:15 --> Helper loaded: url_helper
INFO - 2023-08-22 18:30:15 --> Helper loaded: file_helper
INFO - 2023-08-22 18:30:15 --> Database Driver Class Initialized
INFO - 2023-08-22 18:30:15 --> Email Class Initialized
DEBUG - 2023-08-22 18:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 18:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 18:30:15 --> Controller Class Initialized
INFO - 2023-08-22 18:30:15 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 18:30:15 --> Helper loaded: form_helper
INFO - 2023-08-22 18:30:15 --> Form Validation Class Initialized
INFO - 2023-08-22 18:30:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-22 18:30:16 --> Config Class Initialized
INFO - 2023-08-22 18:30:16 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:30:16 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:30:16 --> Utf8 Class Initialized
INFO - 2023-08-22 18:30:16 --> URI Class Initialized
INFO - 2023-08-22 18:30:16 --> Router Class Initialized
INFO - 2023-08-22 18:30:16 --> Output Class Initialized
INFO - 2023-08-22 18:30:16 --> Security Class Initialized
DEBUG - 2023-08-22 18:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:30:16 --> Input Class Initialized
INFO - 2023-08-22 18:30:16 --> Language Class Initialized
INFO - 2023-08-22 18:30:16 --> Loader Class Initialized
INFO - 2023-08-22 18:30:16 --> Helper loaded: url_helper
INFO - 2023-08-22 18:30:16 --> Helper loaded: file_helper
INFO - 2023-08-22 18:30:16 --> Database Driver Class Initialized
INFO - 2023-08-22 18:30:16 --> Email Class Initialized
DEBUG - 2023-08-22 18:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 18:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 18:30:16 --> Controller Class Initialized
INFO - 2023-08-22 18:30:16 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 18:30:16 --> Helper loaded: form_helper
INFO - 2023-08-22 18:30:16 --> Form Validation Class Initialized
INFO - 2023-08-22 18:30:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-22 18:30:16 --> Final output sent to browser
DEBUG - 2023-08-22 18:30:16 --> Total execution time: 0.6782
INFO - 2023-08-22 18:30:17 --> Config Class Initialized
INFO - 2023-08-22 18:30:17 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:30:17 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:30:17 --> Utf8 Class Initialized
INFO - 2023-08-22 18:30:17 --> URI Class Initialized
INFO - 2023-08-22 18:30:17 --> Router Class Initialized
INFO - 2023-08-22 18:30:17 --> Output Class Initialized
INFO - 2023-08-22 18:30:17 --> Security Class Initialized
DEBUG - 2023-08-22 18:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:30:17 --> Input Class Initialized
INFO - 2023-08-22 18:30:17 --> Language Class Initialized
INFO - 2023-08-22 18:30:17 --> Config Class Initialized
INFO - 2023-08-22 18:30:17 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:30:17 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:30:17 --> Utf8 Class Initialized
INFO - 2023-08-22 18:30:17 --> URI Class Initialized
INFO - 2023-08-22 18:30:17 --> Router Class Initialized
INFO - 2023-08-22 18:30:17 --> Output Class Initialized
INFO - 2023-08-22 18:30:17 --> Security Class Initialized
DEBUG - 2023-08-22 18:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:30:17 --> Input Class Initialized
INFO - 2023-08-22 18:30:17 --> Language Class Initialized
ERROR - 2023-08-22 18:30:17 --> 404 Page Not Found: Assets/admin
ERROR - 2023-08-22 18:30:17 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-22 18:30:26 --> Config Class Initialized
INFO - 2023-08-22 18:30:27 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:30:27 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:30:27 --> Utf8 Class Initialized
INFO - 2023-08-22 18:30:27 --> URI Class Initialized
INFO - 2023-08-22 18:30:27 --> Router Class Initialized
INFO - 2023-08-22 18:30:27 --> Output Class Initialized
INFO - 2023-08-22 18:30:27 --> Security Class Initialized
DEBUG - 2023-08-22 18:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:30:27 --> Input Class Initialized
INFO - 2023-08-22 18:30:27 --> Language Class Initialized
INFO - 2023-08-22 18:30:27 --> Loader Class Initialized
INFO - 2023-08-22 18:30:27 --> Helper loaded: url_helper
INFO - 2023-08-22 18:30:27 --> Helper loaded: file_helper
INFO - 2023-08-22 18:30:27 --> Database Driver Class Initialized
INFO - 2023-08-22 18:30:27 --> Email Class Initialized
DEBUG - 2023-08-22 18:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 18:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 18:30:27 --> Controller Class Initialized
INFO - 2023-08-22 18:30:27 --> Model "Home_model" initialized
INFO - 2023-08-22 18:30:27 --> Helper loaded: form_helper
INFO - 2023-08-22 18:30:27 --> Form Validation Class Initialized
INFO - 2023-08-22 18:30:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-22 18:30:27 --> Final output sent to browser
DEBUG - 2023-08-22 18:30:28 --> Total execution time: 0.9816
INFO - 2023-08-22 18:30:33 --> Config Class Initialized
INFO - 2023-08-22 18:30:33 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:30:33 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:30:33 --> Utf8 Class Initialized
INFO - 2023-08-22 18:30:33 --> URI Class Initialized
INFO - 2023-08-22 18:30:33 --> Router Class Initialized
INFO - 2023-08-22 18:30:33 --> Output Class Initialized
INFO - 2023-08-22 18:30:33 --> Security Class Initialized
DEBUG - 2023-08-22 18:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:30:33 --> Input Class Initialized
INFO - 2023-08-22 18:30:33 --> Language Class Initialized
INFO - 2023-08-22 18:30:33 --> Loader Class Initialized
INFO - 2023-08-22 18:30:33 --> Helper loaded: url_helper
INFO - 2023-08-22 18:30:33 --> Helper loaded: file_helper
INFO - 2023-08-22 18:30:33 --> Database Driver Class Initialized
INFO - 2023-08-22 18:30:34 --> Email Class Initialized
DEBUG - 2023-08-22 18:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 18:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 18:30:34 --> Controller Class Initialized
INFO - 2023-08-22 18:30:34 --> Model "Home_model" initialized
INFO - 2023-08-22 18:30:34 --> Helper loaded: form_helper
INFO - 2023-08-22 18:30:34 --> Form Validation Class Initialized
INFO - 2023-08-22 18:30:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 18:30:34 --> Final output sent to browser
DEBUG - 2023-08-22 18:30:34 --> Total execution time: 0.6093
INFO - 2023-08-22 18:30:34 --> Config Class Initialized
INFO - 2023-08-22 18:30:34 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:30:34 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:30:34 --> Utf8 Class Initialized
INFO - 2023-08-22 18:30:34 --> URI Class Initialized
INFO - 2023-08-22 18:30:34 --> Router Class Initialized
INFO - 2023-08-22 18:30:34 --> Output Class Initialized
INFO - 2023-08-22 18:30:34 --> Security Class Initialized
DEBUG - 2023-08-22 18:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:30:34 --> Input Class Initialized
INFO - 2023-08-22 18:30:34 --> Language Class Initialized
ERROR - 2023-08-22 18:30:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 18:30:34 --> Config Class Initialized
INFO - 2023-08-22 18:30:35 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:30:35 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:30:35 --> Utf8 Class Initialized
INFO - 2023-08-22 18:30:35 --> Config Class Initialized
INFO - 2023-08-22 18:30:35 --> URI Class Initialized
INFO - 2023-08-22 18:30:35 --> Hooks Class Initialized
INFO - 2023-08-22 18:30:35 --> Router Class Initialized
INFO - 2023-08-22 18:30:35 --> Output Class Initialized
DEBUG - 2023-08-22 18:30:35 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:30:35 --> Security Class Initialized
INFO - 2023-08-22 18:30:35 --> Utf8 Class Initialized
DEBUG - 2023-08-22 18:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:30:35 --> Input Class Initialized
INFO - 2023-08-22 18:30:35 --> URI Class Initialized
INFO - 2023-08-22 18:30:35 --> Language Class Initialized
INFO - 2023-08-22 18:30:35 --> Router Class Initialized
ERROR - 2023-08-22 18:30:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 18:30:35 --> Output Class Initialized
INFO - 2023-08-22 18:30:35 --> Security Class Initialized
DEBUG - 2023-08-22 18:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:30:35 --> Input Class Initialized
INFO - 2023-08-22 18:30:35 --> Language Class Initialized
ERROR - 2023-08-22 18:30:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 18:30:35 --> Config Class Initialized
INFO - 2023-08-22 18:30:35 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:30:35 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:30:35 --> Utf8 Class Initialized
INFO - 2023-08-22 18:30:35 --> URI Class Initialized
INFO - 2023-08-22 18:30:35 --> Router Class Initialized
INFO - 2023-08-22 18:30:35 --> Output Class Initialized
INFO - 2023-08-22 18:30:35 --> Security Class Initialized
DEBUG - 2023-08-22 18:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:30:35 --> Input Class Initialized
INFO - 2023-08-22 18:30:35 --> Language Class Initialized
ERROR - 2023-08-22 18:30:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 18:30:35 --> Config Class Initialized
INFO - 2023-08-22 18:30:35 --> Hooks Class Initialized
DEBUG - 2023-08-22 18:30:35 --> UTF-8 Support Enabled
INFO - 2023-08-22 18:30:35 --> Utf8 Class Initialized
INFO - 2023-08-22 18:30:36 --> URI Class Initialized
INFO - 2023-08-22 18:30:36 --> Router Class Initialized
INFO - 2023-08-22 18:30:36 --> Output Class Initialized
INFO - 2023-08-22 18:30:36 --> Security Class Initialized
DEBUG - 2023-08-22 18:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 18:30:36 --> Input Class Initialized
INFO - 2023-08-22 18:30:36 --> Language Class Initialized
ERROR - 2023-08-22 18:30:36 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:11:37 --> Config Class Initialized
INFO - 2023-08-22 19:11:37 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:11:37 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:11:37 --> Utf8 Class Initialized
INFO - 2023-08-22 19:11:37 --> URI Class Initialized
INFO - 2023-08-22 19:11:37 --> Router Class Initialized
INFO - 2023-08-22 19:11:37 --> Output Class Initialized
INFO - 2023-08-22 19:11:37 --> Security Class Initialized
DEBUG - 2023-08-22 19:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:11:37 --> Input Class Initialized
INFO - 2023-08-22 19:11:37 --> Language Class Initialized
INFO - 2023-08-22 19:11:37 --> Loader Class Initialized
INFO - 2023-08-22 19:11:37 --> Helper loaded: url_helper
INFO - 2023-08-22 19:11:37 --> Helper loaded: file_helper
INFO - 2023-08-22 19:11:37 --> Database Driver Class Initialized
INFO - 2023-08-22 19:11:37 --> Email Class Initialized
DEBUG - 2023-08-22 19:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 19:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 19:11:37 --> Controller Class Initialized
INFO - 2023-08-22 19:11:37 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 19:11:37 --> Helper loaded: form_helper
INFO - 2023-08-22 19:11:37 --> Form Validation Class Initialized
INFO - 2023-08-22 19:11:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-22 19:11:37 --> Final output sent to browser
DEBUG - 2023-08-22 19:11:37 --> Total execution time: 0.1095
INFO - 2023-08-22 19:11:40 --> Config Class Initialized
INFO - 2023-08-22 19:11:40 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:11:40 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:11:40 --> Utf8 Class Initialized
INFO - 2023-08-22 19:11:40 --> URI Class Initialized
INFO - 2023-08-22 19:11:40 --> Router Class Initialized
INFO - 2023-08-22 19:11:40 --> Output Class Initialized
INFO - 2023-08-22 19:11:41 --> Security Class Initialized
DEBUG - 2023-08-22 19:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:11:41 --> Input Class Initialized
INFO - 2023-08-22 19:11:41 --> Language Class Initialized
INFO - 2023-08-22 19:11:41 --> Loader Class Initialized
INFO - 2023-08-22 19:11:41 --> Helper loaded: url_helper
INFO - 2023-08-22 19:11:41 --> Helper loaded: file_helper
INFO - 2023-08-22 19:11:41 --> Database Driver Class Initialized
INFO - 2023-08-22 19:11:41 --> Email Class Initialized
DEBUG - 2023-08-22 19:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 19:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 19:11:41 --> Controller Class Initialized
INFO - 2023-08-22 19:11:41 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 19:11:41 --> Helper loaded: form_helper
INFO - 2023-08-22 19:11:41 --> Form Validation Class Initialized
INFO - 2023-08-22 19:11:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_edit.php
INFO - 2023-08-22 19:11:41 --> Final output sent to browser
DEBUG - 2023-08-22 19:11:41 --> Total execution time: 0.1916
INFO - 2023-08-22 19:12:44 --> Config Class Initialized
INFO - 2023-08-22 19:12:44 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:12:44 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:12:44 --> Utf8 Class Initialized
INFO - 2023-08-22 19:12:44 --> URI Class Initialized
INFO - 2023-08-22 19:12:44 --> Router Class Initialized
INFO - 2023-08-22 19:12:44 --> Output Class Initialized
INFO - 2023-08-22 19:12:44 --> Security Class Initialized
DEBUG - 2023-08-22 19:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:12:44 --> Input Class Initialized
INFO - 2023-08-22 19:12:44 --> Language Class Initialized
INFO - 2023-08-22 19:12:44 --> Loader Class Initialized
INFO - 2023-08-22 19:12:44 --> Helper loaded: url_helper
INFO - 2023-08-22 19:12:44 --> Helper loaded: file_helper
INFO - 2023-08-22 19:12:44 --> Database Driver Class Initialized
INFO - 2023-08-22 19:12:44 --> Email Class Initialized
DEBUG - 2023-08-22 19:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 19:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 19:12:44 --> Controller Class Initialized
INFO - 2023-08-22 19:12:44 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 19:12:44 --> Helper loaded: form_helper
INFO - 2023-08-22 19:12:45 --> Form Validation Class Initialized
INFO - 2023-08-22 19:12:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-22 19:12:45 --> Config Class Initialized
INFO - 2023-08-22 19:12:45 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:12:45 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:12:45 --> Utf8 Class Initialized
INFO - 2023-08-22 19:12:45 --> URI Class Initialized
INFO - 2023-08-22 19:12:45 --> Router Class Initialized
INFO - 2023-08-22 19:12:45 --> Output Class Initialized
INFO - 2023-08-22 19:12:45 --> Security Class Initialized
DEBUG - 2023-08-22 19:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:12:45 --> Input Class Initialized
INFO - 2023-08-22 19:12:45 --> Language Class Initialized
INFO - 2023-08-22 19:12:45 --> Loader Class Initialized
INFO - 2023-08-22 19:12:45 --> Helper loaded: url_helper
INFO - 2023-08-22 19:12:45 --> Helper loaded: file_helper
INFO - 2023-08-22 19:12:45 --> Database Driver Class Initialized
INFO - 2023-08-22 19:12:45 --> Email Class Initialized
DEBUG - 2023-08-22 19:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 19:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 19:12:45 --> Controller Class Initialized
INFO - 2023-08-22 19:12:45 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-22 19:12:45 --> Helper loaded: form_helper
INFO - 2023-08-22 19:12:45 --> Form Validation Class Initialized
INFO - 2023-08-22 19:12:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-22 19:12:45 --> Final output sent to browser
DEBUG - 2023-08-22 19:12:45 --> Total execution time: 0.0490
INFO - 2023-08-22 19:20:05 --> Config Class Initialized
INFO - 2023-08-22 19:20:05 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:20:05 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:20:05 --> Utf8 Class Initialized
INFO - 2023-08-22 19:20:05 --> URI Class Initialized
INFO - 2023-08-22 19:20:06 --> Router Class Initialized
INFO - 2023-08-22 19:20:06 --> Output Class Initialized
INFO - 2023-08-22 19:20:06 --> Security Class Initialized
DEBUG - 2023-08-22 19:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:20:06 --> Input Class Initialized
INFO - 2023-08-22 19:20:06 --> Language Class Initialized
INFO - 2023-08-22 19:20:06 --> Loader Class Initialized
INFO - 2023-08-22 19:20:06 --> Helper loaded: url_helper
INFO - 2023-08-22 19:20:06 --> Helper loaded: file_helper
INFO - 2023-08-22 19:20:06 --> Database Driver Class Initialized
INFO - 2023-08-22 19:20:06 --> Email Class Initialized
DEBUG - 2023-08-22 19:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 19:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 19:20:06 --> Controller Class Initialized
INFO - 2023-08-22 19:20:06 --> Model "Home_model" initialized
INFO - 2023-08-22 19:20:06 --> Helper loaded: form_helper
INFO - 2023-08-22 19:20:06 --> Form Validation Class Initialized
ERROR - 2023-08-22 19:20:06 --> Severity: Warning --> Undefined variable $trainings C:\xampp\htdocs\dw\application\views\home\training_detail.php 244
ERROR - 2023-08-22 19:20:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\training_detail.php 244
INFO - 2023-08-22 19:20:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 19:20:06 --> Final output sent to browser
DEBUG - 2023-08-22 19:20:07 --> Total execution time: 1.0048
INFO - 2023-08-22 19:20:07 --> Config Class Initialized
INFO - 2023-08-22 19:20:07 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:20:07 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:20:07 --> Config Class Initialized
INFO - 2023-08-22 19:20:07 --> Utf8 Class Initialized
INFO - 2023-08-22 19:20:08 --> Config Class Initialized
INFO - 2023-08-22 19:20:08 --> Hooks Class Initialized
INFO - 2023-08-22 19:20:08 --> URI Class Initialized
INFO - 2023-08-22 19:20:08 --> Config Class Initialized
INFO - 2023-08-22 19:20:08 --> Router Class Initialized
INFO - 2023-08-22 19:20:08 --> Config Class Initialized
DEBUG - 2023-08-22 19:20:08 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:20:08 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:20:08 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:20:08 --> Output Class Initialized
INFO - 2023-08-22 19:20:08 --> Security Class Initialized
DEBUG - 2023-08-22 19:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:20:08 --> Input Class Initialized
INFO - 2023-08-22 19:20:08 --> Language Class Initialized
ERROR - 2023-08-22 19:20:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:20:08 --> Utf8 Class Initialized
INFO - 2023-08-22 19:20:08 --> Utf8 Class Initialized
INFO - 2023-08-22 19:20:08 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:20:08 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:20:08 --> URI Class Initialized
INFO - 2023-08-22 19:20:08 --> Router Class Initialized
INFO - 2023-08-22 19:20:08 --> Output Class Initialized
INFO - 2023-08-22 19:20:08 --> Security Class Initialized
DEBUG - 2023-08-22 19:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:20:08 --> Input Class Initialized
INFO - 2023-08-22 19:20:08 --> Language Class Initialized
ERROR - 2023-08-22 19:20:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:20:08 --> Hooks Class Initialized
INFO - 2023-08-22 19:20:08 --> URI Class Initialized
DEBUG - 2023-08-22 19:20:08 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:20:08 --> Router Class Initialized
INFO - 2023-08-22 19:20:08 --> Utf8 Class Initialized
INFO - 2023-08-22 19:20:08 --> Output Class Initialized
INFO - 2023-08-22 19:20:08 --> Utf8 Class Initialized
INFO - 2023-08-22 19:20:08 --> Security Class Initialized
INFO - 2023-08-22 19:20:08 --> URI Class Initialized
INFO - 2023-08-22 19:20:08 --> URI Class Initialized
DEBUG - 2023-08-22 19:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:20:08 --> Router Class Initialized
INFO - 2023-08-22 19:20:08 --> Input Class Initialized
INFO - 2023-08-22 19:20:08 --> Language Class Initialized
INFO - 2023-08-22 19:20:08 --> Output Class Initialized
INFO - 2023-08-22 19:20:08 --> Router Class Initialized
INFO - 2023-08-22 19:20:08 --> Security Class Initialized
INFO - 2023-08-22 19:20:08 --> Output Class Initialized
INFO - 2023-08-22 19:20:08 --> Security Class Initialized
DEBUG - 2023-08-22 19:20:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-22 19:20:08 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-22 19:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:20:08 --> Input Class Initialized
INFO - 2023-08-22 19:20:08 --> Input Class Initialized
INFO - 2023-08-22 19:20:08 --> Language Class Initialized
INFO - 2023-08-22 19:20:08 --> Language Class Initialized
ERROR - 2023-08-22 19:20:08 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-22 19:20:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:20:34 --> Config Class Initialized
INFO - 2023-08-22 19:20:34 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:20:34 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:20:34 --> Utf8 Class Initialized
INFO - 2023-08-22 19:20:34 --> URI Class Initialized
INFO - 2023-08-22 19:20:34 --> Router Class Initialized
INFO - 2023-08-22 19:20:34 --> Output Class Initialized
INFO - 2023-08-22 19:20:34 --> Security Class Initialized
DEBUG - 2023-08-22 19:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:20:34 --> Input Class Initialized
INFO - 2023-08-22 19:20:34 --> Language Class Initialized
INFO - 2023-08-22 19:20:34 --> Loader Class Initialized
INFO - 2023-08-22 19:20:34 --> Helper loaded: url_helper
INFO - 2023-08-22 19:20:34 --> Helper loaded: file_helper
INFO - 2023-08-22 19:20:34 --> Database Driver Class Initialized
INFO - 2023-08-22 19:20:34 --> Email Class Initialized
DEBUG - 2023-08-22 19:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 19:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 19:20:34 --> Controller Class Initialized
INFO - 2023-08-22 19:20:34 --> Model "Home_model" initialized
INFO - 2023-08-22 19:20:34 --> Helper loaded: form_helper
INFO - 2023-08-22 19:20:34 --> Form Validation Class Initialized
INFO - 2023-08-22 19:20:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 19:20:34 --> Final output sent to browser
DEBUG - 2023-08-22 19:20:34 --> Total execution time: 0.5531
INFO - 2023-08-22 19:20:35 --> Config Class Initialized
INFO - 2023-08-22 19:20:35 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:20:35 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:20:35 --> Utf8 Class Initialized
INFO - 2023-08-22 19:20:35 --> URI Class Initialized
INFO - 2023-08-22 19:20:35 --> Config Class Initialized
INFO - 2023-08-22 19:20:35 --> Router Class Initialized
INFO - 2023-08-22 19:20:35 --> Config Class Initialized
INFO - 2023-08-22 19:20:35 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:20:35 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:20:35 --> Output Class Initialized
INFO - 2023-08-22 19:20:35 --> Security Class Initialized
INFO - 2023-08-22 19:20:35 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:20:35 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:20:35 --> Utf8 Class Initialized
DEBUG - 2023-08-22 19:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:20:35 --> URI Class Initialized
INFO - 2023-08-22 19:20:35 --> Utf8 Class Initialized
INFO - 2023-08-22 19:20:35 --> Router Class Initialized
INFO - 2023-08-22 19:20:36 --> URI Class Initialized
INFO - 2023-08-22 19:20:36 --> Router Class Initialized
INFO - 2023-08-22 19:20:36 --> Output Class Initialized
INFO - 2023-08-22 19:20:36 --> Output Class Initialized
INFO - 2023-08-22 19:20:36 --> Input Class Initialized
INFO - 2023-08-22 19:20:36 --> Language Class Initialized
INFO - 2023-08-22 19:20:36 --> Security Class Initialized
ERROR - 2023-08-22 19:20:36 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-22 19:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:20:36 --> Security Class Initialized
INFO - 2023-08-22 19:20:36 --> Input Class Initialized
DEBUG - 2023-08-22 19:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:20:36 --> Input Class Initialized
INFO - 2023-08-22 19:20:36 --> Language Class Initialized
INFO - 2023-08-22 19:20:36 --> Language Class Initialized
ERROR - 2023-08-22 19:20:36 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-22 19:20:36 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:20:36 --> Config Class Initialized
INFO - 2023-08-22 19:20:36 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:20:36 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:20:36 --> Utf8 Class Initialized
INFO - 2023-08-22 19:20:36 --> URI Class Initialized
INFO - 2023-08-22 19:20:36 --> Router Class Initialized
INFO - 2023-08-22 19:20:36 --> Output Class Initialized
INFO - 2023-08-22 19:20:36 --> Security Class Initialized
DEBUG - 2023-08-22 19:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:20:36 --> Input Class Initialized
INFO - 2023-08-22 19:20:36 --> Language Class Initialized
ERROR - 2023-08-22 19:20:36 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:20:36 --> Config Class Initialized
INFO - 2023-08-22 19:20:36 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:20:36 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:20:36 --> Utf8 Class Initialized
INFO - 2023-08-22 19:20:36 --> URI Class Initialized
INFO - 2023-08-22 19:20:36 --> Router Class Initialized
INFO - 2023-08-22 19:20:36 --> Output Class Initialized
INFO - 2023-08-22 19:20:36 --> Security Class Initialized
DEBUG - 2023-08-22 19:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:20:36 --> Input Class Initialized
INFO - 2023-08-22 19:20:37 --> Language Class Initialized
ERROR - 2023-08-22 19:20:37 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:21:27 --> Config Class Initialized
INFO - 2023-08-22 19:21:27 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:21:27 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:21:27 --> Utf8 Class Initialized
INFO - 2023-08-22 19:21:27 --> URI Class Initialized
INFO - 2023-08-22 19:21:27 --> Router Class Initialized
INFO - 2023-08-22 19:21:27 --> Output Class Initialized
INFO - 2023-08-22 19:21:27 --> Security Class Initialized
DEBUG - 2023-08-22 19:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:21:27 --> Input Class Initialized
INFO - 2023-08-22 19:21:27 --> Language Class Initialized
ERROR - 2023-08-22 19:21:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:21:28 --> Config Class Initialized
INFO - 2023-08-22 19:21:28 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:21:28 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:21:28 --> Utf8 Class Initialized
INFO - 2023-08-22 19:21:28 --> URI Class Initialized
INFO - 2023-08-22 19:21:28 --> Router Class Initialized
INFO - 2023-08-22 19:21:28 --> Output Class Initialized
INFO - 2023-08-22 19:21:28 --> Security Class Initialized
DEBUG - 2023-08-22 19:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:21:28 --> Input Class Initialized
INFO - 2023-08-22 19:21:28 --> Language Class Initialized
ERROR - 2023-08-22 19:21:28 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:21:28 --> Config Class Initialized
INFO - 2023-08-22 19:21:28 --> Config Class Initialized
INFO - 2023-08-22 19:21:29 --> Hooks Class Initialized
INFO - 2023-08-22 19:21:29 --> Config Class Initialized
DEBUG - 2023-08-22 19:21:29 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:21:29 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:21:29 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:21:29 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:21:29 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:21:29 --> Utf8 Class Initialized
INFO - 2023-08-22 19:21:29 --> URI Class Initialized
INFO - 2023-08-22 19:21:29 --> Router Class Initialized
INFO - 2023-08-22 19:21:29 --> Output Class Initialized
INFO - 2023-08-22 19:21:29 --> Security Class Initialized
DEBUG - 2023-08-22 19:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:21:29 --> Input Class Initialized
INFO - 2023-08-22 19:21:29 --> Language Class Initialized
ERROR - 2023-08-22 19:21:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:21:29 --> Utf8 Class Initialized
INFO - 2023-08-22 19:21:29 --> Utf8 Class Initialized
INFO - 2023-08-22 19:21:29 --> URI Class Initialized
INFO - 2023-08-22 19:21:30 --> URI Class Initialized
INFO - 2023-08-22 19:21:30 --> Router Class Initialized
INFO - 2023-08-22 19:21:30 --> Router Class Initialized
INFO - 2023-08-22 19:21:30 --> Output Class Initialized
INFO - 2023-08-22 19:21:30 --> Output Class Initialized
INFO - 2023-08-22 19:21:30 --> Security Class Initialized
INFO - 2023-08-22 19:21:30 --> Security Class Initialized
DEBUG - 2023-08-22 19:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-22 19:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:21:30 --> Input Class Initialized
INFO - 2023-08-22 19:21:30 --> Input Class Initialized
INFO - 2023-08-22 19:21:30 --> Language Class Initialized
INFO - 2023-08-22 19:21:30 --> Language Class Initialized
ERROR - 2023-08-22 19:21:30 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-22 19:21:30 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:21:30 --> Config Class Initialized
INFO - 2023-08-22 19:21:30 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:21:30 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:21:30 --> Utf8 Class Initialized
INFO - 2023-08-22 19:21:30 --> URI Class Initialized
INFO - 2023-08-22 19:21:30 --> Router Class Initialized
INFO - 2023-08-22 19:21:30 --> Output Class Initialized
INFO - 2023-08-22 19:21:30 --> Security Class Initialized
DEBUG - 2023-08-22 19:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:21:30 --> Input Class Initialized
INFO - 2023-08-22 19:21:30 --> Language Class Initialized
ERROR - 2023-08-22 19:21:30 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:21:30 --> Config Class Initialized
INFO - 2023-08-22 19:21:30 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:21:30 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:21:30 --> Utf8 Class Initialized
INFO - 2023-08-22 19:21:30 --> URI Class Initialized
INFO - 2023-08-22 19:21:30 --> Router Class Initialized
INFO - 2023-08-22 19:21:30 --> Output Class Initialized
INFO - 2023-08-22 19:21:30 --> Security Class Initialized
DEBUG - 2023-08-22 19:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:21:30 --> Input Class Initialized
INFO - 2023-08-22 19:21:30 --> Language Class Initialized
ERROR - 2023-08-22 19:21:30 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:22:37 --> Config Class Initialized
INFO - 2023-08-22 19:22:37 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:22:37 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:22:37 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:37 --> URI Class Initialized
INFO - 2023-08-22 19:22:37 --> Router Class Initialized
INFO - 2023-08-22 19:22:37 --> Output Class Initialized
INFO - 2023-08-22 19:22:37 --> Security Class Initialized
DEBUG - 2023-08-22 19:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:37 --> Input Class Initialized
INFO - 2023-08-22 19:22:37 --> Language Class Initialized
INFO - 2023-08-22 19:22:37 --> Loader Class Initialized
INFO - 2023-08-22 19:22:37 --> Helper loaded: url_helper
INFO - 2023-08-22 19:22:37 --> Helper loaded: file_helper
INFO - 2023-08-22 19:22:37 --> Database Driver Class Initialized
INFO - 2023-08-22 19:22:37 --> Email Class Initialized
DEBUG - 2023-08-22 19:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 19:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 19:22:37 --> Controller Class Initialized
INFO - 2023-08-22 19:22:37 --> Model "Home_model" initialized
INFO - 2023-08-22 19:22:37 --> Helper loaded: form_helper
INFO - 2023-08-22 19:22:37 --> Form Validation Class Initialized
INFO - 2023-08-22 19:22:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 19:22:38 --> Final output sent to browser
DEBUG - 2023-08-22 19:22:38 --> Total execution time: 0.4336
INFO - 2023-08-22 19:22:38 --> Config Class Initialized
INFO - 2023-08-22 19:22:38 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:22:38 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:22:38 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:38 --> URI Class Initialized
INFO - 2023-08-22 19:22:38 --> Router Class Initialized
INFO - 2023-08-22 19:22:38 --> Output Class Initialized
INFO - 2023-08-22 19:22:38 --> Security Class Initialized
DEBUG - 2023-08-22 19:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:38 --> Input Class Initialized
INFO - 2023-08-22 19:22:38 --> Language Class Initialized
ERROR - 2023-08-22 19:22:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:22:39 --> Config Class Initialized
INFO - 2023-08-22 19:22:39 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:22:40 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:22:40 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:41 --> Config Class Initialized
INFO - 2023-08-22 19:22:41 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:22:41 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:22:41 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:41 --> URI Class Initialized
INFO - 2023-08-22 19:22:41 --> Router Class Initialized
INFO - 2023-08-22 19:22:41 --> Output Class Initialized
INFO - 2023-08-22 19:22:41 --> Security Class Initialized
DEBUG - 2023-08-22 19:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:41 --> Input Class Initialized
INFO - 2023-08-22 19:22:41 --> Language Class Initialized
ERROR - 2023-08-22 19:22:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:22:41 --> Config Class Initialized
INFO - 2023-08-22 19:22:41 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:22:41 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:22:41 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:41 --> URI Class Initialized
INFO - 2023-08-22 19:22:41 --> Router Class Initialized
INFO - 2023-08-22 19:22:41 --> Output Class Initialized
INFO - 2023-08-22 19:22:41 --> Security Class Initialized
DEBUG - 2023-08-22 19:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:41 --> Input Class Initialized
INFO - 2023-08-22 19:22:41 --> Language Class Initialized
ERROR - 2023-08-22 19:22:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:22:41 --> URI Class Initialized
INFO - 2023-08-22 19:22:41 --> Config Class Initialized
INFO - 2023-08-22 19:22:41 --> Config Class Initialized
INFO - 2023-08-22 19:22:41 --> Router Class Initialized
INFO - 2023-08-22 19:22:41 --> Hooks Class Initialized
INFO - 2023-08-22 19:22:41 --> Output Class Initialized
INFO - 2023-08-22 19:22:41 --> Hooks Class Initialized
INFO - 2023-08-22 19:22:41 --> Security Class Initialized
DEBUG - 2023-08-22 19:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-22 19:22:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-22 19:22:42 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:22:42 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:42 --> Input Class Initialized
INFO - 2023-08-22 19:22:42 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:42 --> URI Class Initialized
INFO - 2023-08-22 19:22:42 --> URI Class Initialized
INFO - 2023-08-22 19:22:42 --> Router Class Initialized
INFO - 2023-08-22 19:22:42 --> Router Class Initialized
INFO - 2023-08-22 19:22:42 --> Output Class Initialized
INFO - 2023-08-22 19:22:42 --> Language Class Initialized
INFO - 2023-08-22 19:22:42 --> Security Class Initialized
ERROR - 2023-08-22 19:22:42 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-22 19:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:42 --> Input Class Initialized
INFO - 2023-08-22 19:22:42 --> Output Class Initialized
INFO - 2023-08-22 19:22:42 --> Config Class Initialized
INFO - 2023-08-22 19:22:42 --> Hooks Class Initialized
INFO - 2023-08-22 19:22:42 --> Language Class Initialized
INFO - 2023-08-22 19:22:42 --> Security Class Initialized
DEBUG - 2023-08-22 19:22:42 --> UTF-8 Support Enabled
DEBUG - 2023-08-22 19:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:42 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:42 --> URI Class Initialized
ERROR - 2023-08-22 19:22:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:22:42 --> Router Class Initialized
INFO - 2023-08-22 19:22:42 --> Output Class Initialized
INFO - 2023-08-22 19:22:42 --> Input Class Initialized
INFO - 2023-08-22 19:22:42 --> Config Class Initialized
INFO - 2023-08-22 19:22:42 --> Hooks Class Initialized
INFO - 2023-08-22 19:22:42 --> Security Class Initialized
INFO - 2023-08-22 19:22:42 --> Language Class Initialized
DEBUG - 2023-08-22 19:22:42 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:22:42 --> Utf8 Class Initialized
ERROR - 2023-08-22 19:22:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:22:42 --> URI Class Initialized
INFO - 2023-08-22 19:22:42 --> Router Class Initialized
DEBUG - 2023-08-22 19:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:42 --> Config Class Initialized
INFO - 2023-08-22 19:22:42 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:22:42 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:22:42 --> Output Class Initialized
INFO - 2023-08-22 19:22:43 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:43 --> Input Class Initialized
INFO - 2023-08-22 19:22:43 --> Security Class Initialized
DEBUG - 2023-08-22 19:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:43 --> URI Class Initialized
INFO - 2023-08-22 19:22:43 --> Router Class Initialized
INFO - 2023-08-22 19:22:43 --> Output Class Initialized
INFO - 2023-08-22 19:22:43 --> Language Class Initialized
ERROR - 2023-08-22 19:22:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:22:43 --> Security Class Initialized
INFO - 2023-08-22 19:22:43 --> Input Class Initialized
DEBUG - 2023-08-22 19:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:43 --> Input Class Initialized
INFO - 2023-08-22 19:22:43 --> Config Class Initialized
INFO - 2023-08-22 19:22:43 --> Language Class Initialized
ERROR - 2023-08-22 19:22:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:22:43 --> Language Class Initialized
INFO - 2023-08-22 19:22:43 --> Hooks Class Initialized
ERROR - 2023-08-22 19:22:43 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-22 19:22:43 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:22:43 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:43 --> URI Class Initialized
INFO - 2023-08-22 19:22:43 --> Router Class Initialized
INFO - 2023-08-22 19:22:43 --> Output Class Initialized
INFO - 2023-08-22 19:22:43 --> Security Class Initialized
DEBUG - 2023-08-22 19:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:43 --> Input Class Initialized
INFO - 2023-08-22 19:22:43 --> Language Class Initialized
ERROR - 2023-08-22 19:22:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:22:43 --> Config Class Initialized
INFO - 2023-08-22 19:22:43 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:22:43 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:22:43 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:43 --> URI Class Initialized
INFO - 2023-08-22 19:22:43 --> Router Class Initialized
INFO - 2023-08-22 19:22:43 --> Output Class Initialized
INFO - 2023-08-22 19:22:43 --> Security Class Initialized
DEBUG - 2023-08-22 19:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:43 --> Input Class Initialized
INFO - 2023-08-22 19:22:43 --> Language Class Initialized
ERROR - 2023-08-22 19:22:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:22:43 --> Config Class Initialized
INFO - 2023-08-22 19:22:43 --> Config Class Initialized
INFO - 2023-08-22 19:22:43 --> Hooks Class Initialized
INFO - 2023-08-22 19:22:43 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-22 19:22:43 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:22:43 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:43 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:43 --> URI Class Initialized
INFO - 2023-08-22 19:22:43 --> URI Class Initialized
INFO - 2023-08-22 19:22:43 --> Router Class Initialized
INFO - 2023-08-22 19:22:43 --> Output Class Initialized
INFO - 2023-08-22 19:22:43 --> Router Class Initialized
INFO - 2023-08-22 19:22:43 --> Security Class Initialized
INFO - 2023-08-22 19:22:43 --> Output Class Initialized
DEBUG - 2023-08-22 19:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:43 --> Security Class Initialized
INFO - 2023-08-22 19:22:43 --> Input Class Initialized
DEBUG - 2023-08-22 19:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:43 --> Language Class Initialized
INFO - 2023-08-22 19:22:43 --> Input Class Initialized
ERROR - 2023-08-22 19:22:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:22:43 --> Language Class Initialized
ERROR - 2023-08-22 19:22:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:22:58 --> Config Class Initialized
INFO - 2023-08-22 19:22:58 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:22:58 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:22:58 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:58 --> URI Class Initialized
INFO - 2023-08-22 19:22:58 --> Router Class Initialized
INFO - 2023-08-22 19:22:58 --> Output Class Initialized
INFO - 2023-08-22 19:22:58 --> Security Class Initialized
DEBUG - 2023-08-22 19:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:58 --> Input Class Initialized
INFO - 2023-08-22 19:22:58 --> Language Class Initialized
ERROR - 2023-08-22 19:22:58 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:22:58 --> Config Class Initialized
INFO - 2023-08-22 19:22:59 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:22:59 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:22:59 --> Utf8 Class Initialized
INFO - 2023-08-22 19:22:59 --> URI Class Initialized
INFO - 2023-08-22 19:22:59 --> Router Class Initialized
INFO - 2023-08-22 19:22:59 --> Output Class Initialized
INFO - 2023-08-22 19:22:59 --> Security Class Initialized
DEBUG - 2023-08-22 19:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:22:59 --> Input Class Initialized
INFO - 2023-08-22 19:22:59 --> Language Class Initialized
ERROR - 2023-08-22 19:22:59 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:22:59 --> Config Class Initialized
INFO - 2023-08-22 19:22:59 --> Config Class Initialized
INFO - 2023-08-22 19:22:59 --> Hooks Class Initialized
INFO - 2023-08-22 19:22:59 --> Config Class Initialized
DEBUG - 2023-08-22 19:22:59 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:00 --> Hooks Class Initialized
INFO - 2023-08-22 19:23:00 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:00 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:00 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:00 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:00 --> URI Class Initialized
INFO - 2023-08-22 19:23:00 --> URI Class Initialized
DEBUG - 2023-08-22 19:23:00 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:00 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:00 --> Router Class Initialized
INFO - 2023-08-22 19:23:00 --> URI Class Initialized
INFO - 2023-08-22 19:23:00 --> Router Class Initialized
INFO - 2023-08-22 19:23:00 --> Router Class Initialized
INFO - 2023-08-22 19:23:00 --> Output Class Initialized
INFO - 2023-08-22 19:23:00 --> Security Class Initialized
INFO - 2023-08-22 19:23:00 --> Output Class Initialized
DEBUG - 2023-08-22 19:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:00 --> Output Class Initialized
INFO - 2023-08-22 19:23:00 --> Input Class Initialized
INFO - 2023-08-22 19:23:00 --> Security Class Initialized
INFO - 2023-08-22 19:23:00 --> Language Class Initialized
DEBUG - 2023-08-22 19:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-22 19:23:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:23:00 --> Security Class Initialized
INFO - 2023-08-22 19:23:00 --> Input Class Initialized
DEBUG - 2023-08-22 19:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:01 --> Input Class Initialized
INFO - 2023-08-22 19:23:01 --> Language Class Initialized
INFO - 2023-08-22 19:23:01 --> Language Class Initialized
ERROR - 2023-08-22 19:23:01 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-22 19:23:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:23:01 --> Config Class Initialized
INFO - 2023-08-22 19:23:01 --> Config Class Initialized
INFO - 2023-08-22 19:23:01 --> Hooks Class Initialized
INFO - 2023-08-22 19:23:01 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-22 19:23:01 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:01 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:01 --> URI Class Initialized
INFO - 2023-08-22 19:23:01 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:01 --> Router Class Initialized
INFO - 2023-08-22 19:23:01 --> URI Class Initialized
INFO - 2023-08-22 19:23:01 --> Output Class Initialized
INFO - 2023-08-22 19:23:01 --> Router Class Initialized
INFO - 2023-08-22 19:23:01 --> Output Class Initialized
INFO - 2023-08-22 19:23:01 --> Security Class Initialized
INFO - 2023-08-22 19:23:01 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-22 19:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:01 --> Input Class Initialized
INFO - 2023-08-22 19:23:01 --> Input Class Initialized
INFO - 2023-08-22 19:23:01 --> Language Class Initialized
INFO - 2023-08-22 19:23:01 --> Language Class Initialized
ERROR - 2023-08-22 19:23:01 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-22 19:23:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:23:50 --> Config Class Initialized
INFO - 2023-08-22 19:23:50 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:50 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:50 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:50 --> URI Class Initialized
INFO - 2023-08-22 19:23:50 --> Router Class Initialized
INFO - 2023-08-22 19:23:50 --> Output Class Initialized
INFO - 2023-08-22 19:23:50 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:50 --> Input Class Initialized
INFO - 2023-08-22 19:23:50 --> Language Class Initialized
INFO - 2023-08-22 19:23:50 --> Loader Class Initialized
INFO - 2023-08-22 19:23:50 --> Helper loaded: url_helper
INFO - 2023-08-22 19:23:50 --> Helper loaded: file_helper
INFO - 2023-08-22 19:23:50 --> Database Driver Class Initialized
INFO - 2023-08-22 19:23:50 --> Email Class Initialized
DEBUG - 2023-08-22 19:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-22 19:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 19:23:51 --> Controller Class Initialized
INFO - 2023-08-22 19:23:51 --> Model "Home_model" initialized
INFO - 2023-08-22 19:23:51 --> Helper loaded: form_helper
INFO - 2023-08-22 19:23:51 --> Form Validation Class Initialized
INFO - 2023-08-22 19:23:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-22 19:23:51 --> Final output sent to browser
DEBUG - 2023-08-22 19:23:51 --> Total execution time: 0.4834
INFO - 2023-08-22 19:23:51 --> Config Class Initialized
INFO - 2023-08-22 19:23:51 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:51 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:51 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:51 --> URI Class Initialized
INFO - 2023-08-22 19:23:51 --> Router Class Initialized
INFO - 2023-08-22 19:23:51 --> Output Class Initialized
INFO - 2023-08-22 19:23:51 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:51 --> Input Class Initialized
INFO - 2023-08-22 19:23:51 --> Language Class Initialized
ERROR - 2023-08-22 19:23:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:23:51 --> Config Class Initialized
INFO - 2023-08-22 19:23:51 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:51 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:51 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:51 --> URI Class Initialized
INFO - 2023-08-22 19:23:51 --> Router Class Initialized
INFO - 2023-08-22 19:23:51 --> Output Class Initialized
INFO - 2023-08-22 19:23:51 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:51 --> Input Class Initialized
INFO - 2023-08-22 19:23:51 --> Language Class Initialized
ERROR - 2023-08-22 19:23:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:23:51 --> Config Class Initialized
INFO - 2023-08-22 19:23:51 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:51 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:51 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:51 --> URI Class Initialized
INFO - 2023-08-22 19:23:51 --> Router Class Initialized
INFO - 2023-08-22 19:23:51 --> Output Class Initialized
INFO - 2023-08-22 19:23:51 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:51 --> Input Class Initialized
INFO - 2023-08-22 19:23:51 --> Language Class Initialized
ERROR - 2023-08-22 19:23:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:23:52 --> Config Class Initialized
INFO - 2023-08-22 19:23:52 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:52 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:52 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:52 --> URI Class Initialized
INFO - 2023-08-22 19:23:52 --> Router Class Initialized
INFO - 2023-08-22 19:23:52 --> Output Class Initialized
INFO - 2023-08-22 19:23:52 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:52 --> Input Class Initialized
INFO - 2023-08-22 19:23:52 --> Language Class Initialized
ERROR - 2023-08-22 19:23:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:23:52 --> Config Class Initialized
INFO - 2023-08-22 19:23:52 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:52 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:52 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:52 --> URI Class Initialized
INFO - 2023-08-22 19:23:52 --> Router Class Initialized
INFO - 2023-08-22 19:23:52 --> Output Class Initialized
INFO - 2023-08-22 19:23:52 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:52 --> Input Class Initialized
INFO - 2023-08-22 19:23:52 --> Language Class Initialized
ERROR - 2023-08-22 19:23:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:23:52 --> Config Class Initialized
INFO - 2023-08-22 19:23:52 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:52 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:52 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:52 --> URI Class Initialized
INFO - 2023-08-22 19:23:52 --> Router Class Initialized
INFO - 2023-08-22 19:23:52 --> Output Class Initialized
INFO - 2023-08-22 19:23:52 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:52 --> Input Class Initialized
INFO - 2023-08-22 19:23:52 --> Language Class Initialized
ERROR - 2023-08-22 19:23:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:23:52 --> Config Class Initialized
INFO - 2023-08-22 19:23:52 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:52 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:52 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:52 --> URI Class Initialized
INFO - 2023-08-22 19:23:52 --> Router Class Initialized
INFO - 2023-08-22 19:23:52 --> Output Class Initialized
INFO - 2023-08-22 19:23:52 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:52 --> Input Class Initialized
INFO - 2023-08-22 19:23:52 --> Language Class Initialized
ERROR - 2023-08-22 19:23:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:23:52 --> Config Class Initialized
INFO - 2023-08-22 19:23:52 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:52 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:52 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:52 --> URI Class Initialized
INFO - 2023-08-22 19:23:52 --> Router Class Initialized
INFO - 2023-08-22 19:23:52 --> Output Class Initialized
INFO - 2023-08-22 19:23:52 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:52 --> Input Class Initialized
INFO - 2023-08-22 19:23:52 --> Language Class Initialized
ERROR - 2023-08-22 19:23:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:23:52 --> Config Class Initialized
INFO - 2023-08-22 19:23:52 --> Hooks Class Initialized
INFO - 2023-08-22 19:23:52 --> Config Class Initialized
INFO - 2023-08-22 19:23:52 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:52 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:52 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:52 --> URI Class Initialized
INFO - 2023-08-22 19:23:52 --> Router Class Initialized
INFO - 2023-08-22 19:23:52 --> Output Class Initialized
INFO - 2023-08-22 19:23:52 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:52 --> Input Class Initialized
INFO - 2023-08-22 19:23:52 --> Language Class Initialized
ERROR - 2023-08-22 19:23:52 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-22 19:23:53 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:53 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:53 --> URI Class Initialized
INFO - 2023-08-22 19:23:53 --> Router Class Initialized
INFO - 2023-08-22 19:23:53 --> Output Class Initialized
INFO - 2023-08-22 19:23:53 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:53 --> Input Class Initialized
INFO - 2023-08-22 19:23:53 --> Language Class Initialized
ERROR - 2023-08-22 19:23:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:23:53 --> Config Class Initialized
INFO - 2023-08-22 19:23:53 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:53 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:53 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:53 --> URI Class Initialized
INFO - 2023-08-22 19:23:53 --> Router Class Initialized
INFO - 2023-08-22 19:23:53 --> Output Class Initialized
INFO - 2023-08-22 19:23:53 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:53 --> Input Class Initialized
INFO - 2023-08-22 19:23:53 --> Language Class Initialized
ERROR - 2023-08-22 19:23:53 --> 404 Page Not Found: Assets/home
INFO - 2023-08-22 19:23:53 --> Config Class Initialized
INFO - 2023-08-22 19:23:53 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:53 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:53 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:53 --> URI Class Initialized
INFO - 2023-08-22 19:23:53 --> Router Class Initialized
INFO - 2023-08-22 19:23:53 --> Output Class Initialized
INFO - 2023-08-22 19:23:53 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:53 --> Input Class Initialized
INFO - 2023-08-22 19:23:53 --> Language Class Initialized
ERROR - 2023-08-22 19:23:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:23:53 --> Config Class Initialized
INFO - 2023-08-22 19:23:53 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:53 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:53 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:53 --> URI Class Initialized
INFO - 2023-08-22 19:23:53 --> Router Class Initialized
INFO - 2023-08-22 19:23:53 --> Output Class Initialized
INFO - 2023-08-22 19:23:53 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:53 --> Input Class Initialized
INFO - 2023-08-22 19:23:53 --> Language Class Initialized
ERROR - 2023-08-22 19:23:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-22 19:23:53 --> Config Class Initialized
INFO - 2023-08-22 19:23:53 --> Hooks Class Initialized
DEBUG - 2023-08-22 19:23:53 --> UTF-8 Support Enabled
INFO - 2023-08-22 19:23:53 --> Utf8 Class Initialized
INFO - 2023-08-22 19:23:53 --> URI Class Initialized
INFO - 2023-08-22 19:23:53 --> Router Class Initialized
INFO - 2023-08-22 19:23:53 --> Output Class Initialized
INFO - 2023-08-22 19:23:53 --> Security Class Initialized
DEBUG - 2023-08-22 19:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 19:23:53 --> Input Class Initialized
INFO - 2023-08-22 19:23:53 --> Language Class Initialized
ERROR - 2023-08-22 19:23:53 --> 404 Page Not Found: Training-detail/assets
