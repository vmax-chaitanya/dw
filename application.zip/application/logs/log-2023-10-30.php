<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-30 04:30:52 --> Config Class Initialized
INFO - 2023-10-30 04:30:52 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:30:55 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:30:55 --> Utf8 Class Initialized
INFO - 2023-10-30 04:30:55 --> URI Class Initialized
DEBUG - 2023-10-30 04:30:57 --> No URI present. Default controller set.
INFO - 2023-10-30 04:30:57 --> Router Class Initialized
INFO - 2023-10-30 04:30:57 --> Output Class Initialized
INFO - 2023-10-30 04:30:57 --> Security Class Initialized
DEBUG - 2023-10-30 04:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:30:58 --> Input Class Initialized
INFO - 2023-10-30 04:30:58 --> Language Class Initialized
INFO - 2023-10-30 04:30:58 --> Loader Class Initialized
INFO - 2023-10-30 04:31:00 --> Helper loaded: url_helper
INFO - 2023-10-30 04:31:01 --> Helper loaded: file_helper
INFO - 2023-10-30 04:31:03 --> Database Driver Class Initialized
INFO - 2023-10-30 04:31:03 --> Email Class Initialized
DEBUG - 2023-10-30 04:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 04:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 04:31:07 --> Controller Class Initialized
INFO - 2023-10-30 04:31:10 --> Model "Contact_model" initialized
INFO - 2023-10-30 04:31:10 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 04:31:10 --> Model "Home_model" initialized
INFO - 2023-10-30 04:31:11 --> Helper loaded: download_helper
INFO - 2023-10-30 04:31:11 --> Helper loaded: form_helper
INFO - 2023-10-30 04:31:11 --> Form Validation Class Initialized
INFO - 2023-10-30 04:31:23 --> Helper loaded: custom_helper
INFO - 2023-10-30 04:31:25 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 04:31:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 04:31:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 04:31:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 04:31:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 04:31:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 04:31:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 04:31:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 04:31:41 --> Final output sent to browser
DEBUG - 2023-10-30 04:31:41 --> Total execution time: 48.6751
INFO - 2023-10-30 04:32:30 --> Config Class Initialized
INFO - 2023-10-30 04:32:30 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:32:30 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:32:30 --> Utf8 Class Initialized
INFO - 2023-10-30 04:32:30 --> URI Class Initialized
INFO - 2023-10-30 04:32:30 --> Router Class Initialized
INFO - 2023-10-30 04:32:30 --> Output Class Initialized
INFO - 2023-10-30 04:32:30 --> Security Class Initialized
DEBUG - 2023-10-30 04:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:32:30 --> Input Class Initialized
INFO - 2023-10-30 04:32:30 --> Language Class Initialized
ERROR - 2023-10-30 04:32:30 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:32:31 --> Config Class Initialized
INFO - 2023-10-30 04:32:31 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:32:31 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:32:31 --> Utf8 Class Initialized
INFO - 2023-10-30 04:32:31 --> URI Class Initialized
INFO - 2023-10-30 04:32:31 --> Router Class Initialized
INFO - 2023-10-30 04:32:31 --> Output Class Initialized
INFO - 2023-10-30 04:32:31 --> Security Class Initialized
DEBUG - 2023-10-30 04:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:32:31 --> Input Class Initialized
INFO - 2023-10-30 04:32:31 --> Language Class Initialized
ERROR - 2023-10-30 04:32:31 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:32:38 --> Config Class Initialized
INFO - 2023-10-30 04:32:38 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:32:38 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:32:38 --> Utf8 Class Initialized
INFO - 2023-10-30 04:32:38 --> URI Class Initialized
INFO - 2023-10-30 04:32:38 --> Router Class Initialized
INFO - 2023-10-30 04:32:38 --> Output Class Initialized
INFO - 2023-10-30 04:32:38 --> Security Class Initialized
DEBUG - 2023-10-30 04:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:32:38 --> Input Class Initialized
INFO - 2023-10-30 04:32:38 --> Language Class Initialized
ERROR - 2023-10-30 04:32:38 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:32:38 --> Config Class Initialized
INFO - 2023-10-30 04:32:38 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:32:38 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:32:38 --> Utf8 Class Initialized
INFO - 2023-10-30 04:32:38 --> URI Class Initialized
INFO - 2023-10-30 04:32:38 --> Router Class Initialized
INFO - 2023-10-30 04:32:38 --> Output Class Initialized
INFO - 2023-10-30 04:32:38 --> Security Class Initialized
DEBUG - 2023-10-30 04:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:32:38 --> Input Class Initialized
INFO - 2023-10-30 04:32:38 --> Language Class Initialized
ERROR - 2023-10-30 04:32:38 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:32:38 --> Config Class Initialized
INFO - 2023-10-30 04:32:38 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:32:38 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:32:38 --> Utf8 Class Initialized
INFO - 2023-10-30 04:32:38 --> URI Class Initialized
INFO - 2023-10-30 04:32:38 --> Router Class Initialized
INFO - 2023-10-30 04:32:38 --> Output Class Initialized
INFO - 2023-10-30 04:32:38 --> Security Class Initialized
DEBUG - 2023-10-30 04:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:32:38 --> Input Class Initialized
INFO - 2023-10-30 04:32:38 --> Language Class Initialized
ERROR - 2023-10-30 04:32:38 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:32:38 --> Config Class Initialized
INFO - 2023-10-30 04:32:38 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:32:38 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:32:38 --> Utf8 Class Initialized
INFO - 2023-10-30 04:32:38 --> URI Class Initialized
INFO - 2023-10-30 04:32:38 --> Router Class Initialized
INFO - 2023-10-30 04:32:38 --> Output Class Initialized
INFO - 2023-10-30 04:32:38 --> Security Class Initialized
DEBUG - 2023-10-30 04:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:32:38 --> Input Class Initialized
INFO - 2023-10-30 04:32:39 --> Language Class Initialized
ERROR - 2023-10-30 04:32:39 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:32:40 --> Config Class Initialized
INFO - 2023-10-30 04:32:45 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:32:48 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:32:48 --> Utf8 Class Initialized
INFO - 2023-10-30 04:32:48 --> URI Class Initialized
INFO - 2023-10-30 04:32:48 --> Router Class Initialized
INFO - 2023-10-30 04:32:48 --> Output Class Initialized
INFO - 2023-10-30 04:32:48 --> Security Class Initialized
DEBUG - 2023-10-30 04:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:32:48 --> Input Class Initialized
INFO - 2023-10-30 04:32:48 --> Language Class Initialized
ERROR - 2023-10-30 04:32:48 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:33:54 --> Config Class Initialized
INFO - 2023-10-30 04:33:54 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:33:54 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:33:54 --> Utf8 Class Initialized
INFO - 2023-10-30 04:33:54 --> URI Class Initialized
DEBUG - 2023-10-30 04:33:54 --> No URI present. Default controller set.
INFO - 2023-10-30 04:33:54 --> Router Class Initialized
INFO - 2023-10-30 04:33:54 --> Output Class Initialized
INFO - 2023-10-30 04:33:54 --> Security Class Initialized
DEBUG - 2023-10-30 04:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:33:54 --> Input Class Initialized
INFO - 2023-10-30 04:33:54 --> Language Class Initialized
INFO - 2023-10-30 04:33:54 --> Loader Class Initialized
INFO - 2023-10-30 04:33:54 --> Helper loaded: url_helper
INFO - 2023-10-30 04:33:54 --> Helper loaded: file_helper
INFO - 2023-10-30 04:33:54 --> Database Driver Class Initialized
INFO - 2023-10-30 04:33:54 --> Email Class Initialized
DEBUG - 2023-10-30 04:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 04:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 04:33:55 --> Controller Class Initialized
INFO - 2023-10-30 04:33:55 --> Model "Contact_model" initialized
INFO - 2023-10-30 04:33:55 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 04:33:55 --> Model "Home_model" initialized
INFO - 2023-10-30 04:33:55 --> Helper loaded: download_helper
INFO - 2023-10-30 04:33:55 --> Helper loaded: form_helper
INFO - 2023-10-30 04:33:55 --> Form Validation Class Initialized
INFO - 2023-10-30 04:33:55 --> Helper loaded: custom_helper
INFO - 2023-10-30 04:33:55 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 04:33:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 04:33:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 04:33:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 04:33:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 04:33:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 04:33:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 04:33:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 04:33:56 --> Final output sent to browser
DEBUG - 2023-10-30 04:33:56 --> Total execution time: 2.2986
INFO - 2023-10-30 04:34:01 --> Config Class Initialized
INFO - 2023-10-30 04:34:01 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:34:01 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:34:01 --> Utf8 Class Initialized
INFO - 2023-10-30 04:34:01 --> URI Class Initialized
INFO - 2023-10-30 04:34:01 --> Router Class Initialized
INFO - 2023-10-30 04:34:01 --> Output Class Initialized
INFO - 2023-10-30 04:34:01 --> Security Class Initialized
DEBUG - 2023-10-30 04:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:34:01 --> Input Class Initialized
INFO - 2023-10-30 04:34:01 --> Language Class Initialized
ERROR - 2023-10-30 04:34:01 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:35:43 --> Config Class Initialized
INFO - 2023-10-30 04:35:43 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:35:43 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:35:43 --> Utf8 Class Initialized
INFO - 2023-10-30 04:35:43 --> URI Class Initialized
DEBUG - 2023-10-30 04:35:43 --> No URI present. Default controller set.
INFO - 2023-10-30 04:35:43 --> Router Class Initialized
INFO - 2023-10-30 04:35:43 --> Output Class Initialized
INFO - 2023-10-30 04:35:43 --> Security Class Initialized
DEBUG - 2023-10-30 04:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:35:43 --> Input Class Initialized
INFO - 2023-10-30 04:35:43 --> Language Class Initialized
INFO - 2023-10-30 04:35:43 --> Loader Class Initialized
INFO - 2023-10-30 04:35:43 --> Helper loaded: url_helper
INFO - 2023-10-30 04:35:43 --> Helper loaded: file_helper
INFO - 2023-10-30 04:35:43 --> Database Driver Class Initialized
INFO - 2023-10-30 04:35:43 --> Email Class Initialized
DEBUG - 2023-10-30 04:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 04:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 04:35:43 --> Controller Class Initialized
INFO - 2023-10-30 04:35:43 --> Model "Contact_model" initialized
INFO - 2023-10-30 04:35:43 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 04:35:43 --> Model "Home_model" initialized
INFO - 2023-10-30 04:35:43 --> Helper loaded: download_helper
INFO - 2023-10-30 04:35:43 --> Helper loaded: form_helper
INFO - 2023-10-30 04:35:43 --> Form Validation Class Initialized
INFO - 2023-10-30 04:35:44 --> Helper loaded: custom_helper
INFO - 2023-10-30 04:35:44 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 04:35:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 04:35:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 04:35:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 04:35:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 04:35:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 04:35:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 04:35:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 04:35:44 --> Final output sent to browser
DEBUG - 2023-10-30 04:35:44 --> Total execution time: 1.1850
INFO - 2023-10-30 04:36:08 --> Config Class Initialized
INFO - 2023-10-30 04:36:08 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:36:08 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:36:08 --> Utf8 Class Initialized
INFO - 2023-10-30 04:36:08 --> URI Class Initialized
DEBUG - 2023-10-30 04:36:08 --> No URI present. Default controller set.
INFO - 2023-10-30 04:36:08 --> Router Class Initialized
INFO - 2023-10-30 04:36:08 --> Output Class Initialized
INFO - 2023-10-30 04:36:08 --> Security Class Initialized
DEBUG - 2023-10-30 04:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:36:09 --> Input Class Initialized
INFO - 2023-10-30 04:36:09 --> Language Class Initialized
INFO - 2023-10-30 04:36:09 --> Loader Class Initialized
INFO - 2023-10-30 04:36:09 --> Helper loaded: url_helper
INFO - 2023-10-30 04:36:09 --> Helper loaded: file_helper
INFO - 2023-10-30 04:36:09 --> Database Driver Class Initialized
INFO - 2023-10-30 04:36:10 --> Email Class Initialized
DEBUG - 2023-10-30 04:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 04:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 04:36:10 --> Controller Class Initialized
INFO - 2023-10-30 04:36:10 --> Model "Contact_model" initialized
INFO - 2023-10-30 04:36:10 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 04:36:10 --> Model "Home_model" initialized
INFO - 2023-10-30 04:36:10 --> Helper loaded: download_helper
INFO - 2023-10-30 04:36:10 --> Helper loaded: form_helper
INFO - 2023-10-30 04:36:10 --> Form Validation Class Initialized
INFO - 2023-10-30 04:36:10 --> Helper loaded: custom_helper
INFO - 2023-10-30 04:36:10 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 04:36:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 04:36:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 04:36:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 04:36:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 04:36:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 04:36:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 04:36:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 04:36:10 --> Final output sent to browser
DEBUG - 2023-10-30 04:36:10 --> Total execution time: 1.8941
INFO - 2023-10-30 04:36:16 --> Config Class Initialized
INFO - 2023-10-30 04:36:16 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:36:16 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:36:16 --> Utf8 Class Initialized
INFO - 2023-10-30 04:36:16 --> URI Class Initialized
INFO - 2023-10-30 04:36:16 --> Router Class Initialized
INFO - 2023-10-30 04:36:16 --> Output Class Initialized
INFO - 2023-10-30 04:36:16 --> Security Class Initialized
DEBUG - 2023-10-30 04:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:36:16 --> Input Class Initialized
INFO - 2023-10-30 04:36:16 --> Language Class Initialized
ERROR - 2023-10-30 04:36:16 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:36:16 --> Config Class Initialized
INFO - 2023-10-30 04:36:16 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:36:16 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:36:16 --> Utf8 Class Initialized
INFO - 2023-10-30 04:36:16 --> URI Class Initialized
INFO - 2023-10-30 04:36:20 --> Router Class Initialized
INFO - 2023-10-30 04:36:20 --> Output Class Initialized
INFO - 2023-10-30 04:36:20 --> Security Class Initialized
DEBUG - 2023-10-30 04:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:36:20 --> Input Class Initialized
INFO - 2023-10-30 04:36:20 --> Language Class Initialized
ERROR - 2023-10-30 04:36:20 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:36:21 --> Config Class Initialized
INFO - 2023-10-30 04:36:26 --> Config Class Initialized
INFO - 2023-10-30 04:36:26 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:36:26 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:36:26 --> Utf8 Class Initialized
INFO - 2023-10-30 04:36:26 --> URI Class Initialized
INFO - 2023-10-30 04:36:26 --> Router Class Initialized
INFO - 2023-10-30 04:36:26 --> Output Class Initialized
INFO - 2023-10-30 04:36:26 --> Security Class Initialized
DEBUG - 2023-10-30 04:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:36:26 --> Input Class Initialized
INFO - 2023-10-30 04:36:26 --> Language Class Initialized
ERROR - 2023-10-30 04:36:26 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:36:26 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:36:26 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:36:26 --> Utf8 Class Initialized
INFO - 2023-10-30 04:36:26 --> URI Class Initialized
INFO - 2023-10-30 04:36:26 --> Router Class Initialized
INFO - 2023-10-30 04:36:26 --> Output Class Initialized
INFO - 2023-10-30 04:36:26 --> Security Class Initialized
DEBUG - 2023-10-30 04:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:36:26 --> Input Class Initialized
INFO - 2023-10-30 04:36:26 --> Language Class Initialized
ERROR - 2023-10-30 04:36:26 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:36:28 --> Config Class Initialized
INFO - 2023-10-30 04:36:28 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:36:28 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:36:28 --> Utf8 Class Initialized
INFO - 2023-10-30 04:36:28 --> URI Class Initialized
INFO - 2023-10-30 04:36:28 --> Router Class Initialized
INFO - 2023-10-30 04:36:28 --> Output Class Initialized
INFO - 2023-10-30 04:36:28 --> Security Class Initialized
DEBUG - 2023-10-30 04:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:36:28 --> Input Class Initialized
INFO - 2023-10-30 04:36:28 --> Language Class Initialized
ERROR - 2023-10-30 04:36:28 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:36:30 --> Config Class Initialized
INFO - 2023-10-30 04:36:30 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:36:30 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:36:30 --> Utf8 Class Initialized
INFO - 2023-10-30 04:36:30 --> URI Class Initialized
INFO - 2023-10-30 04:36:30 --> Router Class Initialized
INFO - 2023-10-30 04:36:30 --> Output Class Initialized
INFO - 2023-10-30 04:36:30 --> Security Class Initialized
DEBUG - 2023-10-30 04:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:36:30 --> Input Class Initialized
INFO - 2023-10-30 04:36:30 --> Language Class Initialized
ERROR - 2023-10-30 04:36:30 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:36:30 --> Config Class Initialized
INFO - 2023-10-30 04:36:30 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:36:30 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:36:31 --> Utf8 Class Initialized
INFO - 2023-10-30 04:36:31 --> URI Class Initialized
INFO - 2023-10-30 04:36:31 --> Router Class Initialized
INFO - 2023-10-30 04:36:31 --> Output Class Initialized
INFO - 2023-10-30 04:36:32 --> Security Class Initialized
DEBUG - 2023-10-30 04:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:36:34 --> Input Class Initialized
INFO - 2023-10-30 04:36:34 --> Language Class Initialized
ERROR - 2023-10-30 04:36:35 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:36:40 --> Config Class Initialized
INFO - 2023-10-30 04:36:40 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:36:40 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:36:40 --> Utf8 Class Initialized
INFO - 2023-10-30 04:36:40 --> URI Class Initialized
DEBUG - 2023-10-30 04:36:40 --> No URI present. Default controller set.
INFO - 2023-10-30 04:36:40 --> Router Class Initialized
INFO - 2023-10-30 04:36:40 --> Output Class Initialized
INFO - 2023-10-30 04:36:40 --> Security Class Initialized
DEBUG - 2023-10-30 04:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:36:40 --> Input Class Initialized
INFO - 2023-10-30 04:36:40 --> Language Class Initialized
INFO - 2023-10-30 04:36:40 --> Loader Class Initialized
INFO - 2023-10-30 04:36:40 --> Helper loaded: url_helper
INFO - 2023-10-30 04:36:40 --> Helper loaded: file_helper
INFO - 2023-10-30 04:36:40 --> Database Driver Class Initialized
INFO - 2023-10-30 04:36:40 --> Email Class Initialized
DEBUG - 2023-10-30 04:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 04:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 04:36:41 --> Controller Class Initialized
INFO - 2023-10-30 04:36:41 --> Model "Contact_model" initialized
INFO - 2023-10-30 04:36:41 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 04:36:42 --> Model "Home_model" initialized
INFO - 2023-10-30 04:36:42 --> Helper loaded: download_helper
INFO - 2023-10-30 04:36:42 --> Helper loaded: form_helper
INFO - 2023-10-30 04:36:42 --> Form Validation Class Initialized
INFO - 2023-10-30 04:36:42 --> Helper loaded: custom_helper
INFO - 2023-10-30 04:36:42 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 04:36:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 04:36:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 04:36:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 04:36:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 04:36:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 04:36:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 04:36:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 04:36:44 --> Final output sent to browser
DEBUG - 2023-10-30 04:36:44 --> Total execution time: 3.2305
INFO - 2023-10-30 04:36:45 --> Config Class Initialized
INFO - 2023-10-30 04:36:45 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:36:45 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:36:45 --> Utf8 Class Initialized
INFO - 2023-10-30 04:36:45 --> URI Class Initialized
INFO - 2023-10-30 04:36:45 --> Router Class Initialized
INFO - 2023-10-30 04:36:45 --> Output Class Initialized
INFO - 2023-10-30 04:36:45 --> Security Class Initialized
DEBUG - 2023-10-30 04:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:36:45 --> Input Class Initialized
INFO - 2023-10-30 04:36:45 --> Language Class Initialized
ERROR - 2023-10-30 04:36:45 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:36:49 --> Config Class Initialized
INFO - 2023-10-30 04:36:50 --> Config Class Initialized
INFO - 2023-10-30 04:36:50 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:36:50 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:36:50 --> Utf8 Class Initialized
INFO - 2023-10-30 04:36:50 --> URI Class Initialized
INFO - 2023-10-30 04:36:50 --> Router Class Initialized
INFO - 2023-10-30 04:36:50 --> Output Class Initialized
INFO - 2023-10-30 04:36:50 --> Security Class Initialized
DEBUG - 2023-10-30 04:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:36:50 --> Input Class Initialized
INFO - 2023-10-30 04:36:50 --> Language Class Initialized
ERROR - 2023-10-30 04:36:50 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:36:50 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:36:51 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:36:51 --> Config Class Initialized
INFO - 2023-10-30 04:36:51 --> Config Class Initialized
INFO - 2023-10-30 04:36:51 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:36:51 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:36:51 --> Utf8 Class Initialized
INFO - 2023-10-30 04:36:51 --> URI Class Initialized
INFO - 2023-10-30 04:36:51 --> Router Class Initialized
INFO - 2023-10-30 04:36:51 --> Output Class Initialized
INFO - 2023-10-30 04:36:51 --> Security Class Initialized
DEBUG - 2023-10-30 04:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:36:51 --> Input Class Initialized
INFO - 2023-10-30 04:36:51 --> Language Class Initialized
ERROR - 2023-10-30 04:36:51 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 04:36:55 --> Config Class Initialized
INFO - 2023-10-30 04:36:55 --> Hooks Class Initialized
DEBUG - 2023-10-30 04:36:56 --> UTF-8 Support Enabled
INFO - 2023-10-30 04:36:56 --> Utf8 Class Initialized
INFO - 2023-10-30 04:36:56 --> URI Class Initialized
INFO - 2023-10-30 04:36:56 --> Router Class Initialized
INFO - 2023-10-30 04:36:56 --> Output Class Initialized
INFO - 2023-10-30 04:36:56 --> Security Class Initialized
DEBUG - 2023-10-30 04:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 04:36:56 --> Input Class Initialized
INFO - 2023-10-30 04:36:56 --> Language Class Initialized
ERROR - 2023-10-30 04:36:56 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:17:18 --> Config Class Initialized
INFO - 2023-10-30 15:17:18 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:17:18 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:17:18 --> Utf8 Class Initialized
INFO - 2023-10-30 15:17:18 --> URI Class Initialized
DEBUG - 2023-10-30 15:17:18 --> No URI present. Default controller set.
INFO - 2023-10-30 15:17:18 --> Router Class Initialized
INFO - 2023-10-30 15:17:18 --> Output Class Initialized
INFO - 2023-10-30 15:17:18 --> Security Class Initialized
DEBUG - 2023-10-30 15:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:17:18 --> Input Class Initialized
INFO - 2023-10-30 15:17:18 --> Language Class Initialized
INFO - 2023-10-30 15:17:19 --> Loader Class Initialized
INFO - 2023-10-30 15:17:19 --> Helper loaded: url_helper
INFO - 2023-10-30 15:17:19 --> Helper loaded: file_helper
INFO - 2023-10-30 15:17:19 --> Database Driver Class Initialized
INFO - 2023-10-30 15:17:19 --> Email Class Initialized
DEBUG - 2023-10-30 15:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 15:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:17:19 --> Controller Class Initialized
INFO - 2023-10-30 15:17:19 --> Model "Contact_model" initialized
INFO - 2023-10-30 15:17:19 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 15:17:19 --> Model "Home_model" initialized
INFO - 2023-10-30 15:17:19 --> Helper loaded: download_helper
INFO - 2023-10-30 15:17:19 --> Helper loaded: form_helper
INFO - 2023-10-30 15:17:19 --> Form Validation Class Initialized
INFO - 2023-10-30 15:17:19 --> Helper loaded: custom_helper
INFO - 2023-10-30 15:17:19 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 15:17:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 15:17:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 15:17:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 15:17:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 15:17:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 15:17:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 15:17:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 15:17:20 --> Final output sent to browser
DEBUG - 2023-10-30 15:17:20 --> Total execution time: 1.6056
INFO - 2023-10-30 15:19:11 --> Config Class Initialized
INFO - 2023-10-30 15:19:11 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:19:11 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:19:11 --> Utf8 Class Initialized
INFO - 2023-10-30 15:19:11 --> URI Class Initialized
DEBUG - 2023-10-30 15:19:11 --> No URI present. Default controller set.
INFO - 2023-10-30 15:19:11 --> Router Class Initialized
INFO - 2023-10-30 15:19:11 --> Output Class Initialized
INFO - 2023-10-30 15:19:11 --> Security Class Initialized
DEBUG - 2023-10-30 15:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:19:11 --> Input Class Initialized
INFO - 2023-10-30 15:19:11 --> Language Class Initialized
INFO - 2023-10-30 15:19:11 --> Loader Class Initialized
INFO - 2023-10-30 15:19:11 --> Helper loaded: url_helper
INFO - 2023-10-30 15:19:11 --> Helper loaded: file_helper
INFO - 2023-10-30 15:19:11 --> Database Driver Class Initialized
INFO - 2023-10-30 15:19:11 --> Email Class Initialized
DEBUG - 2023-10-30 15:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 15:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:19:11 --> Controller Class Initialized
INFO - 2023-10-30 15:19:11 --> Model "Contact_model" initialized
INFO - 2023-10-30 15:19:11 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 15:19:11 --> Model "Home_model" initialized
INFO - 2023-10-30 15:19:11 --> Helper loaded: download_helper
INFO - 2023-10-30 15:19:11 --> Helper loaded: form_helper
INFO - 2023-10-30 15:19:11 --> Form Validation Class Initialized
INFO - 2023-10-30 15:19:12 --> Helper loaded: custom_helper
INFO - 2023-10-30 15:19:12 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 15:19:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 15:19:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 15:19:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 15:19:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 15:19:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 15:19:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 15:19:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 15:19:12 --> Final output sent to browser
DEBUG - 2023-10-30 15:19:12 --> Total execution time: 0.4561
INFO - 2023-10-30 15:19:19 --> Config Class Initialized
INFO - 2023-10-30 15:19:19 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:19:19 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:19:19 --> Utf8 Class Initialized
INFO - 2023-10-30 15:19:19 --> URI Class Initialized
DEBUG - 2023-10-30 15:19:19 --> No URI present. Default controller set.
INFO - 2023-10-30 15:19:19 --> Router Class Initialized
INFO - 2023-10-30 15:19:19 --> Output Class Initialized
INFO - 2023-10-30 15:19:19 --> Security Class Initialized
DEBUG - 2023-10-30 15:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:19:19 --> Input Class Initialized
INFO - 2023-10-30 15:19:19 --> Language Class Initialized
INFO - 2023-10-30 15:19:19 --> Loader Class Initialized
INFO - 2023-10-30 15:19:19 --> Helper loaded: url_helper
INFO - 2023-10-30 15:19:19 --> Helper loaded: file_helper
INFO - 2023-10-30 15:19:19 --> Database Driver Class Initialized
INFO - 2023-10-30 15:19:19 --> Email Class Initialized
DEBUG - 2023-10-30 15:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 15:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:19:19 --> Controller Class Initialized
INFO - 2023-10-30 15:19:19 --> Model "Contact_model" initialized
INFO - 2023-10-30 15:19:19 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 15:19:19 --> Model "Home_model" initialized
INFO - 2023-10-30 15:19:19 --> Helper loaded: download_helper
INFO - 2023-10-30 15:19:19 --> Helper loaded: form_helper
INFO - 2023-10-30 15:19:19 --> Form Validation Class Initialized
INFO - 2023-10-30 15:19:19 --> Helper loaded: custom_helper
INFO - 2023-10-30 15:19:19 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 15:19:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 15:19:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 15:19:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 15:19:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 15:19:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 15:19:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 15:19:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 15:19:19 --> Final output sent to browser
DEBUG - 2023-10-30 15:19:19 --> Total execution time: 0.1332
INFO - 2023-10-30 15:22:18 --> Config Class Initialized
INFO - 2023-10-30 15:22:18 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:22:18 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:22:18 --> Utf8 Class Initialized
INFO - 2023-10-30 15:22:18 --> URI Class Initialized
DEBUG - 2023-10-30 15:22:18 --> No URI present. Default controller set.
INFO - 2023-10-30 15:22:18 --> Router Class Initialized
INFO - 2023-10-30 15:22:18 --> Output Class Initialized
INFO - 2023-10-30 15:22:18 --> Security Class Initialized
DEBUG - 2023-10-30 15:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:22:18 --> Input Class Initialized
INFO - 2023-10-30 15:22:18 --> Language Class Initialized
INFO - 2023-10-30 15:22:18 --> Loader Class Initialized
INFO - 2023-10-30 15:22:18 --> Helper loaded: url_helper
INFO - 2023-10-30 15:22:18 --> Helper loaded: file_helper
INFO - 2023-10-30 15:22:18 --> Database Driver Class Initialized
INFO - 2023-10-30 15:22:18 --> Email Class Initialized
DEBUG - 2023-10-30 15:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 15:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:22:18 --> Controller Class Initialized
INFO - 2023-10-30 15:22:18 --> Model "Contact_model" initialized
INFO - 2023-10-30 15:22:18 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 15:22:18 --> Model "Home_model" initialized
INFO - 2023-10-30 15:22:18 --> Helper loaded: download_helper
INFO - 2023-10-30 15:22:18 --> Helper loaded: form_helper
INFO - 2023-10-30 15:22:18 --> Form Validation Class Initialized
INFO - 2023-10-30 15:22:18 --> Helper loaded: custom_helper
INFO - 2023-10-30 15:22:18 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 15:22:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 15:22:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 15:22:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 15:22:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 15:22:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 15:22:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 15:22:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 15:22:18 --> Final output sent to browser
DEBUG - 2023-10-30 15:22:19 --> Total execution time: 0.1557
INFO - 2023-10-30 15:23:35 --> Config Class Initialized
INFO - 2023-10-30 15:23:35 --> Config Class Initialized
INFO - 2023-10-30 15:23:35 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:23:35 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:23:35 --> Utf8 Class Initialized
INFO - 2023-10-30 15:23:35 --> Hooks Class Initialized
INFO - 2023-10-30 15:23:35 --> URI Class Initialized
INFO - 2023-10-30 15:23:35 --> Config Class Initialized
INFO - 2023-10-30 15:23:35 --> Hooks Class Initialized
INFO - 2023-10-30 15:23:35 --> Router Class Initialized
DEBUG - 2023-10-30 15:23:35 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:23:35 --> Output Class Initialized
DEBUG - 2023-10-30 15:23:35 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:23:35 --> Utf8 Class Initialized
INFO - 2023-10-30 15:23:35 --> Security Class Initialized
INFO - 2023-10-30 15:23:35 --> Utf8 Class Initialized
INFO - 2023-10-30 15:23:35 --> URI Class Initialized
INFO - 2023-10-30 15:23:35 --> URI Class Initialized
INFO - 2023-10-30 15:23:36 --> Router Class Initialized
INFO - 2023-10-30 15:23:36 --> Router Class Initialized
DEBUG - 2023-10-30 15:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:23:36 --> Output Class Initialized
INFO - 2023-10-30 15:23:36 --> Output Class Initialized
INFO - 2023-10-30 15:23:36 --> Input Class Initialized
INFO - 2023-10-30 15:23:36 --> Security Class Initialized
INFO - 2023-10-30 15:23:36 --> Security Class Initialized
INFO - 2023-10-30 15:23:36 --> Language Class Initialized
DEBUG - 2023-10-30 15:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-30 15:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:23:36 --> Input Class Initialized
ERROR - 2023-10-30 15:23:36 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:23:36 --> Language Class Initialized
INFO - 2023-10-30 15:23:36 --> Input Class Initialized
ERROR - 2023-10-30 15:23:36 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:23:36 --> Language Class Initialized
ERROR - 2023-10-30 15:23:36 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:23:36 --> Config Class Initialized
INFO - 2023-10-30 15:23:36 --> Config Class Initialized
INFO - 2023-10-30 15:23:36 --> Hooks Class Initialized
INFO - 2023-10-30 15:23:36 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:23:36 --> UTF-8 Support Enabled
DEBUG - 2023-10-30 15:23:36 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:23:36 --> Utf8 Class Initialized
INFO - 2023-10-30 15:23:36 --> Utf8 Class Initialized
INFO - 2023-10-30 15:23:37 --> URI Class Initialized
INFO - 2023-10-30 15:23:37 --> Router Class Initialized
INFO - 2023-10-30 15:23:37 --> Output Class Initialized
INFO - 2023-10-30 15:23:37 --> Security Class Initialized
DEBUG - 2023-10-30 15:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:23:37 --> Input Class Initialized
INFO - 2023-10-30 15:23:37 --> Language Class Initialized
ERROR - 2023-10-30 15:23:37 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:23:37 --> URI Class Initialized
INFO - 2023-10-30 15:23:37 --> Router Class Initialized
INFO - 2023-10-30 15:23:37 --> Output Class Initialized
INFO - 2023-10-30 15:23:37 --> Config Class Initialized
INFO - 2023-10-30 15:23:37 --> Security Class Initialized
INFO - 2023-10-30 15:23:37 --> Config Class Initialized
INFO - 2023-10-30 15:23:37 --> Hooks Class Initialized
INFO - 2023-10-30 15:23:37 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-30 15:23:37 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:23:37 --> Input Class Initialized
INFO - 2023-10-30 15:23:37 --> Utf8 Class Initialized
DEBUG - 2023-10-30 15:23:37 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:23:37 --> URI Class Initialized
INFO - 2023-10-30 15:23:37 --> Language Class Initialized
INFO - 2023-10-30 15:23:37 --> Router Class Initialized
INFO - 2023-10-30 15:23:37 --> Utf8 Class Initialized
ERROR - 2023-10-30 15:23:37 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:23:37 --> URI Class Initialized
INFO - 2023-10-30 15:23:37 --> Output Class Initialized
INFO - 2023-10-30 15:23:37 --> Router Class Initialized
INFO - 2023-10-30 15:23:37 --> Security Class Initialized
INFO - 2023-10-30 15:23:37 --> Output Class Initialized
DEBUG - 2023-10-30 15:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:23:37 --> Security Class Initialized
INFO - 2023-10-30 15:23:37 --> Input Class Initialized
DEBUG - 2023-10-30 15:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:23:37 --> Language Class Initialized
INFO - 2023-10-30 15:23:37 --> Input Class Initialized
ERROR - 2023-10-30 15:23:37 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:23:37 --> Language Class Initialized
ERROR - 2023-10-30 15:23:37 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:23:48 --> Config Class Initialized
INFO - 2023-10-30 15:23:49 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:23:49 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:23:49 --> Utf8 Class Initialized
INFO - 2023-10-30 15:23:49 --> URI Class Initialized
DEBUG - 2023-10-30 15:23:49 --> No URI present. Default controller set.
INFO - 2023-10-30 15:23:49 --> Router Class Initialized
INFO - 2023-10-30 15:23:49 --> Output Class Initialized
INFO - 2023-10-30 15:23:49 --> Security Class Initialized
DEBUG - 2023-10-30 15:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:23:49 --> Input Class Initialized
INFO - 2023-10-30 15:23:49 --> Language Class Initialized
INFO - 2023-10-30 15:23:49 --> Loader Class Initialized
INFO - 2023-10-30 15:23:49 --> Helper loaded: url_helper
INFO - 2023-10-30 15:23:49 --> Helper loaded: file_helper
INFO - 2023-10-30 15:23:49 --> Database Driver Class Initialized
INFO - 2023-10-30 15:23:49 --> Email Class Initialized
DEBUG - 2023-10-30 15:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 15:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:23:49 --> Controller Class Initialized
INFO - 2023-10-30 15:23:49 --> Model "Contact_model" initialized
INFO - 2023-10-30 15:23:49 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 15:23:49 --> Model "Home_model" initialized
INFO - 2023-10-30 15:23:49 --> Helper loaded: download_helper
INFO - 2023-10-30 15:23:49 --> Helper loaded: form_helper
INFO - 2023-10-30 15:23:49 --> Form Validation Class Initialized
INFO - 2023-10-30 15:23:49 --> Helper loaded: custom_helper
INFO - 2023-10-30 15:23:49 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 15:23:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 15:23:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 15:23:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 15:23:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 15:23:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 15:23:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 15:23:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 15:23:49 --> Final output sent to browser
DEBUG - 2023-10-30 15:23:49 --> Total execution time: 0.1305
INFO - 2023-10-30 15:23:49 --> Config Class Initialized
INFO - 2023-10-30 15:23:49 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:23:49 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:23:49 --> Utf8 Class Initialized
INFO - 2023-10-30 15:23:49 --> URI Class Initialized
INFO - 2023-10-30 15:23:49 --> Router Class Initialized
INFO - 2023-10-30 15:23:49 --> Output Class Initialized
INFO - 2023-10-30 15:23:49 --> Security Class Initialized
DEBUG - 2023-10-30 15:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:23:52 --> Input Class Initialized
INFO - 2023-10-30 15:23:52 --> Language Class Initialized
ERROR - 2023-10-30 15:23:52 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:23:53 --> Config Class Initialized
INFO - 2023-10-30 15:23:53 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:23:53 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:23:53 --> Utf8 Class Initialized
INFO - 2023-10-30 15:23:53 --> URI Class Initialized
INFO - 2023-10-30 15:23:53 --> Router Class Initialized
INFO - 2023-10-30 15:23:53 --> Output Class Initialized
INFO - 2023-10-30 15:23:53 --> Security Class Initialized
DEBUG - 2023-10-30 15:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:23:53 --> Input Class Initialized
INFO - 2023-10-30 15:23:53 --> Language Class Initialized
ERROR - 2023-10-30 15:23:53 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:23:53 --> Config Class Initialized
INFO - 2023-10-30 15:23:53 --> Hooks Class Initialized
INFO - 2023-10-30 15:23:54 --> Config Class Initialized
DEBUG - 2023-10-30 15:23:54 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:23:54 --> Hooks Class Initialized
INFO - 2023-10-30 15:23:54 --> Utf8 Class Initialized
DEBUG - 2023-10-30 15:23:54 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:23:54 --> URI Class Initialized
INFO - 2023-10-30 15:23:54 --> Utf8 Class Initialized
INFO - 2023-10-30 15:23:54 --> Router Class Initialized
INFO - 2023-10-30 15:23:54 --> URI Class Initialized
INFO - 2023-10-30 15:23:54 --> Output Class Initialized
INFO - 2023-10-30 15:23:54 --> Security Class Initialized
INFO - 2023-10-30 15:23:54 --> Router Class Initialized
DEBUG - 2023-10-30 15:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:23:54 --> Output Class Initialized
INFO - 2023-10-30 15:23:54 --> Input Class Initialized
INFO - 2023-10-30 15:23:54 --> Security Class Initialized
INFO - 2023-10-30 15:23:54 --> Language Class Initialized
DEBUG - 2023-10-30 15:23:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-10-30 15:23:54 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:23:54 --> Input Class Initialized
INFO - 2023-10-30 15:23:54 --> Language Class Initialized
ERROR - 2023-10-30 15:23:54 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:23:54 --> Config Class Initialized
INFO - 2023-10-30 15:23:54 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:23:54 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:23:54 --> Utf8 Class Initialized
INFO - 2023-10-30 15:23:54 --> URI Class Initialized
INFO - 2023-10-30 15:23:54 --> Router Class Initialized
INFO - 2023-10-30 15:23:54 --> Output Class Initialized
INFO - 2023-10-30 15:23:54 --> Security Class Initialized
DEBUG - 2023-10-30 15:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:23:54 --> Input Class Initialized
INFO - 2023-10-30 15:23:54 --> Language Class Initialized
ERROR - 2023-10-30 15:23:54 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:23:54 --> Config Class Initialized
INFO - 2023-10-30 15:23:54 --> Config Class Initialized
INFO - 2023-10-30 15:23:54 --> Hooks Class Initialized
INFO - 2023-10-30 15:23:54 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:23:54 --> UTF-8 Support Enabled
DEBUG - 2023-10-30 15:23:54 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:23:54 --> Utf8 Class Initialized
INFO - 2023-10-30 15:23:54 --> Utf8 Class Initialized
INFO - 2023-10-30 15:23:54 --> URI Class Initialized
INFO - 2023-10-30 15:23:54 --> URI Class Initialized
INFO - 2023-10-30 15:23:54 --> Router Class Initialized
INFO - 2023-10-30 15:23:54 --> Router Class Initialized
INFO - 2023-10-30 15:23:54 --> Output Class Initialized
INFO - 2023-10-30 15:23:54 --> Output Class Initialized
INFO - 2023-10-30 15:23:54 --> Security Class Initialized
DEBUG - 2023-10-30 15:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:23:54 --> Input Class Initialized
INFO - 2023-10-30 15:23:54 --> Language Class Initialized
ERROR - 2023-10-30 15:23:54 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:23:54 --> Security Class Initialized
DEBUG - 2023-10-30 15:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:23:54 --> Input Class Initialized
INFO - 2023-10-30 15:23:54 --> Language Class Initialized
ERROR - 2023-10-30 15:23:54 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:23:57 --> Config Class Initialized
INFO - 2023-10-30 15:23:57 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:23:57 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:23:57 --> Utf8 Class Initialized
INFO - 2023-10-30 15:23:57 --> URI Class Initialized
DEBUG - 2023-10-30 15:23:57 --> No URI present. Default controller set.
INFO - 2023-10-30 15:23:57 --> Router Class Initialized
INFO - 2023-10-30 15:23:57 --> Output Class Initialized
INFO - 2023-10-30 15:23:57 --> Security Class Initialized
DEBUG - 2023-10-30 15:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:23:57 --> Input Class Initialized
INFO - 2023-10-30 15:23:57 --> Language Class Initialized
INFO - 2023-10-30 15:23:57 --> Loader Class Initialized
INFO - 2023-10-30 15:23:57 --> Helper loaded: url_helper
INFO - 2023-10-30 15:23:57 --> Helper loaded: file_helper
INFO - 2023-10-30 15:23:57 --> Database Driver Class Initialized
INFO - 2023-10-30 15:23:57 --> Email Class Initialized
DEBUG - 2023-10-30 15:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 15:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:23:57 --> Controller Class Initialized
INFO - 2023-10-30 15:23:57 --> Model "Contact_model" initialized
INFO - 2023-10-30 15:23:57 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 15:23:57 --> Model "Home_model" initialized
INFO - 2023-10-30 15:23:57 --> Helper loaded: download_helper
INFO - 2023-10-30 15:23:57 --> Helper loaded: form_helper
INFO - 2023-10-30 15:23:57 --> Form Validation Class Initialized
INFO - 2023-10-30 15:23:57 --> Helper loaded: custom_helper
INFO - 2023-10-30 15:23:57 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 15:23:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 15:23:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 15:23:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 15:23:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 15:23:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 15:23:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 15:23:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 15:23:57 --> Final output sent to browser
DEBUG - 2023-10-30 15:23:57 --> Total execution time: 0.1854
INFO - 2023-10-30 15:24:00 --> Config Class Initialized
INFO - 2023-10-30 15:24:00 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:24:00 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:24:00 --> Config Class Initialized
INFO - 2023-10-30 15:24:00 --> Config Class Initialized
INFO - 2023-10-30 15:24:00 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:24:00 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:24:00 --> Utf8 Class Initialized
INFO - 2023-10-30 15:24:00 --> URI Class Initialized
INFO - 2023-10-30 15:24:00 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:24:00 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:24:02 --> Config Class Initialized
INFO - 2023-10-30 15:24:02 --> Router Class Initialized
INFO - 2023-10-30 15:24:02 --> Hooks Class Initialized
INFO - 2023-10-30 15:24:02 --> Utf8 Class Initialized
INFO - 2023-10-30 15:24:02 --> Output Class Initialized
INFO - 2023-10-30 15:24:02 --> Utf8 Class Initialized
INFO - 2023-10-30 15:24:02 --> URI Class Initialized
INFO - 2023-10-30 15:24:02 --> Router Class Initialized
INFO - 2023-10-30 15:24:02 --> Output Class Initialized
INFO - 2023-10-30 15:24:02 --> Security Class Initialized
DEBUG - 2023-10-30 15:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:24:02 --> Input Class Initialized
INFO - 2023-10-30 15:24:02 --> Language Class Initialized
ERROR - 2023-10-30 15:24:02 --> 404 Page Not Found: Assets/home
DEBUG - 2023-10-30 15:24:02 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:24:02 --> URI Class Initialized
INFO - 2023-10-30 15:24:02 --> Utf8 Class Initialized
INFO - 2023-10-30 15:24:02 --> Security Class Initialized
INFO - 2023-10-30 15:24:02 --> URI Class Initialized
DEBUG - 2023-10-30 15:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:24:02 --> Router Class Initialized
INFO - 2023-10-30 15:24:02 --> Router Class Initialized
INFO - 2023-10-30 15:24:02 --> Config Class Initialized
INFO - 2023-10-30 15:24:02 --> Config Class Initialized
INFO - 2023-10-30 15:24:02 --> Config Class Initialized
INFO - 2023-10-30 15:24:02 --> Hooks Class Initialized
INFO - 2023-10-30 15:24:02 --> Output Class Initialized
INFO - 2023-10-30 15:24:02 --> Output Class Initialized
INFO - 2023-10-30 15:24:02 --> Input Class Initialized
INFO - 2023-10-30 15:24:02 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:24:02 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:24:02 --> Security Class Initialized
DEBUG - 2023-10-30 15:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:24:02 --> Utf8 Class Initialized
INFO - 2023-10-30 15:24:02 --> Language Class Initialized
INFO - 2023-10-30 15:24:02 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:24:02 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:24:02 --> Input Class Initialized
INFO - 2023-10-30 15:24:02 --> URI Class Initialized
INFO - 2023-10-30 15:24:02 --> Security Class Initialized
INFO - 2023-10-30 15:24:02 --> Router Class Initialized
DEBUG - 2023-10-30 15:24:02 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:24:02 --> Utf8 Class Initialized
INFO - 2023-10-30 15:24:02 --> URI Class Initialized
INFO - 2023-10-30 15:24:02 --> Router Class Initialized
INFO - 2023-10-30 15:24:02 --> Output Class Initialized
INFO - 2023-10-30 15:24:02 --> Security Class Initialized
DEBUG - 2023-10-30 15:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:24:02 --> Input Class Initialized
INFO - 2023-10-30 15:24:02 --> Language Class Initialized
ERROR - 2023-10-30 15:24:02 --> 404 Page Not Found: Assets/home
ERROR - 2023-10-30 15:24:02 --> 404 Page Not Found: Assets/home
DEBUG - 2023-10-30 15:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:24:03 --> Utf8 Class Initialized
INFO - 2023-10-30 15:24:03 --> Language Class Initialized
INFO - 2023-10-30 15:24:03 --> Output Class Initialized
ERROR - 2023-10-30 15:24:03 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:24:03 --> Input Class Initialized
INFO - 2023-10-30 15:24:03 --> URI Class Initialized
INFO - 2023-10-30 15:24:03 --> Security Class Initialized
INFO - 2023-10-30 15:24:03 --> Router Class Initialized
DEBUG - 2023-10-30 15:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:24:03 --> Language Class Initialized
INFO - 2023-10-30 15:24:03 --> Output Class Initialized
INFO - 2023-10-30 15:24:03 --> Input Class Initialized
ERROR - 2023-10-30 15:24:03 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:24:03 --> Language Class Initialized
INFO - 2023-10-30 15:24:03 --> Security Class Initialized
DEBUG - 2023-10-30 15:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:24:03 --> Input Class Initialized
INFO - 2023-10-30 15:24:03 --> Language Class Initialized
ERROR - 2023-10-30 15:24:03 --> 404 Page Not Found: Assets/home
ERROR - 2023-10-30 15:24:03 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:25:59 --> Config Class Initialized
INFO - 2023-10-30 15:25:59 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:25:59 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:25:59 --> Utf8 Class Initialized
INFO - 2023-10-30 15:25:59 --> URI Class Initialized
DEBUG - 2023-10-30 15:25:59 --> No URI present. Default controller set.
INFO - 2023-10-30 15:25:59 --> Router Class Initialized
INFO - 2023-10-30 15:25:59 --> Output Class Initialized
INFO - 2023-10-30 15:25:59 --> Security Class Initialized
DEBUG - 2023-10-30 15:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:25:59 --> Input Class Initialized
INFO - 2023-10-30 15:25:59 --> Language Class Initialized
INFO - 2023-10-30 15:25:59 --> Loader Class Initialized
INFO - 2023-10-30 15:25:59 --> Helper loaded: url_helper
INFO - 2023-10-30 15:25:59 --> Helper loaded: file_helper
INFO - 2023-10-30 15:25:59 --> Database Driver Class Initialized
INFO - 2023-10-30 15:25:59 --> Email Class Initialized
DEBUG - 2023-10-30 15:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 15:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:25:59 --> Controller Class Initialized
INFO - 2023-10-30 15:25:59 --> Model "Contact_model" initialized
INFO - 2023-10-30 15:25:59 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 15:25:59 --> Model "Home_model" initialized
INFO - 2023-10-30 15:25:59 --> Helper loaded: download_helper
INFO - 2023-10-30 15:25:59 --> Helper loaded: form_helper
INFO - 2023-10-30 15:25:59 --> Form Validation Class Initialized
INFO - 2023-10-30 15:25:59 --> Helper loaded: custom_helper
INFO - 2023-10-30 15:25:59 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 15:25:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 15:25:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 15:25:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 15:25:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 15:25:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 15:25:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 15:25:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 15:25:59 --> Final output sent to browser
DEBUG - 2023-10-30 15:25:59 --> Total execution time: 0.1305
INFO - 2023-10-30 15:26:02 --> Config Class Initialized
INFO - 2023-10-30 15:26:02 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:26:03 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:26:03 --> Utf8 Class Initialized
INFO - 2023-10-30 15:26:03 --> URI Class Initialized
INFO - 2023-10-30 15:26:03 --> Router Class Initialized
INFO - 2023-10-30 15:26:03 --> Output Class Initialized
INFO - 2023-10-30 15:26:03 --> Security Class Initialized
DEBUG - 2023-10-30 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:26:03 --> Input Class Initialized
INFO - 2023-10-30 15:26:03 --> Language Class Initialized
ERROR - 2023-10-30 15:26:03 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:26:03 --> Config Class Initialized
INFO - 2023-10-30 15:26:05 --> Hooks Class Initialized
INFO - 2023-10-30 15:26:06 --> Config Class Initialized
INFO - 2023-10-30 15:26:06 --> Config Class Initialized
DEBUG - 2023-10-30 15:26:06 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:26:06 --> Hooks Class Initialized
INFO - 2023-10-30 15:26:06 --> Config Class Initialized
INFO - 2023-10-30 15:26:06 --> Config Class Initialized
INFO - 2023-10-30 15:26:06 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:26:06 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:26:06 --> Utf8 Class Initialized
INFO - 2023-10-30 15:26:06 --> URI Class Initialized
INFO - 2023-10-30 15:26:07 --> Utf8 Class Initialized
INFO - 2023-10-30 15:26:07 --> URI Class Initialized
INFO - 2023-10-30 15:26:07 --> Router Class Initialized
INFO - 2023-10-30 15:26:07 --> Output Class Initialized
INFO - 2023-10-30 15:26:07 --> Security Class Initialized
DEBUG - 2023-10-30 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:26:07 --> Input Class Initialized
INFO - 2023-10-30 15:26:07 --> Language Class Initialized
ERROR - 2023-10-30 15:26:07 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:26:07 --> Hooks Class Initialized
INFO - 2023-10-30 15:26:07 --> Config Class Initialized
INFO - 2023-10-30 15:26:07 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:26:07 --> UTF-8 Support Enabled
DEBUG - 2023-10-30 15:26:07 --> UTF-8 Support Enabled
DEBUG - 2023-10-30 15:26:07 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:26:07 --> Router Class Initialized
INFO - 2023-10-30 15:26:07 --> Utf8 Class Initialized
INFO - 2023-10-30 15:26:07 --> Utf8 Class Initialized
INFO - 2023-10-30 15:26:07 --> Utf8 Class Initialized
INFO - 2023-10-30 15:26:07 --> Hooks Class Initialized
INFO - 2023-10-30 15:26:07 --> URI Class Initialized
INFO - 2023-10-30 15:26:07 --> Output Class Initialized
INFO - 2023-10-30 15:26:07 --> URI Class Initialized
INFO - 2023-10-30 15:26:07 --> URI Class Initialized
INFO - 2023-10-30 15:26:07 --> Security Class Initialized
DEBUG - 2023-10-30 15:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-30 15:26:07 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:26:07 --> Router Class Initialized
INFO - 2023-10-30 15:26:07 --> Utf8 Class Initialized
INFO - 2023-10-30 15:26:07 --> Input Class Initialized
INFO - 2023-10-30 15:26:07 --> Router Class Initialized
INFO - 2023-10-30 15:26:07 --> Router Class Initialized
INFO - 2023-10-30 15:26:07 --> Language Class Initialized
INFO - 2023-10-30 15:26:07 --> URI Class Initialized
INFO - 2023-10-30 15:26:07 --> Router Class Initialized
INFO - 2023-10-30 15:26:07 --> Output Class Initialized
INFO - 2023-10-30 15:26:07 --> Security Class Initialized
DEBUG - 2023-10-30 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:26:07 --> Input Class Initialized
INFO - 2023-10-30 15:26:07 --> Language Class Initialized
ERROR - 2023-10-30 15:26:07 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:26:07 --> Output Class Initialized
INFO - 2023-10-30 15:26:07 --> Output Class Initialized
INFO - 2023-10-30 15:26:07 --> Security Class Initialized
DEBUG - 2023-10-30 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:26:07 --> Input Class Initialized
INFO - 2023-10-30 15:26:07 --> Language Class Initialized
ERROR - 2023-10-30 15:26:07 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:26:07 --> Output Class Initialized
INFO - 2023-10-30 15:26:07 --> Security Class Initialized
INFO - 2023-10-30 15:26:07 --> Security Class Initialized
ERROR - 2023-10-30 15:26:07 --> 404 Page Not Found: Assets/home
DEBUG - 2023-10-30 15:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-30 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:26:07 --> Input Class Initialized
INFO - 2023-10-30 15:26:07 --> Language Class Initialized
INFO - 2023-10-30 15:26:07 --> Input Class Initialized
ERROR - 2023-10-30 15:26:07 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 15:26:07 --> Language Class Initialized
ERROR - 2023-10-30 15:26:07 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 16:01:38 --> Config Class Initialized
INFO - 2023-10-30 16:01:38 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:01:38 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:01:38 --> Utf8 Class Initialized
INFO - 2023-10-30 16:01:38 --> URI Class Initialized
INFO - 2023-10-30 16:01:38 --> Router Class Initialized
INFO - 2023-10-30 16:01:38 --> Output Class Initialized
INFO - 2023-10-30 16:01:38 --> Security Class Initialized
DEBUG - 2023-10-30 16:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:01:38 --> Input Class Initialized
INFO - 2023-10-30 16:01:38 --> Language Class Initialized
INFO - 2023-10-30 16:01:38 --> Loader Class Initialized
INFO - 2023-10-30 16:01:38 --> Helper loaded: url_helper
INFO - 2023-10-30 16:01:38 --> Helper loaded: file_helper
INFO - 2023-10-30 16:01:38 --> Database Driver Class Initialized
INFO - 2023-10-30 16:01:38 --> Email Class Initialized
DEBUG - 2023-10-30 16:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 16:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:01:38 --> Controller Class Initialized
INFO - 2023-10-30 16:01:38 --> Model "Contact_model" initialized
INFO - 2023-10-30 16:01:38 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 16:01:38 --> Model "Home_model" initialized
INFO - 2023-10-30 16:01:38 --> Helper loaded: download_helper
INFO - 2023-10-30 16:01:38 --> Helper loaded: form_helper
INFO - 2023-10-30 16:01:38 --> Form Validation Class Initialized
INFO - 2023-10-30 16:01:38 --> Helper loaded: custom_helper
INFO - 2023-10-30 16:01:38 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 16:01:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 16:01:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 16:01:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 16:01:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 16:01:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 16:01:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 16:01:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-10-30 16:01:38 --> Final output sent to browser
DEBUG - 2023-10-30 16:01:39 --> Total execution time: 0.2244
INFO - 2023-10-30 16:04:16 --> Config Class Initialized
INFO - 2023-10-30 16:04:16 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:04:16 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:04:16 --> Utf8 Class Initialized
INFO - 2023-10-30 16:04:16 --> URI Class Initialized
INFO - 2023-10-30 16:04:16 --> Router Class Initialized
INFO - 2023-10-30 16:04:16 --> Output Class Initialized
INFO - 2023-10-30 16:04:16 --> Security Class Initialized
DEBUG - 2023-10-30 16:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:04:16 --> Input Class Initialized
INFO - 2023-10-30 16:04:16 --> Language Class Initialized
INFO - 2023-10-30 16:04:16 --> Loader Class Initialized
INFO - 2023-10-30 16:04:16 --> Helper loaded: url_helper
INFO - 2023-10-30 16:04:16 --> Helper loaded: file_helper
INFO - 2023-10-30 16:04:16 --> Database Driver Class Initialized
INFO - 2023-10-30 16:04:16 --> Email Class Initialized
DEBUG - 2023-10-30 16:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 16:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:04:16 --> Controller Class Initialized
INFO - 2023-10-30 16:04:16 --> Model "Contact_model" initialized
INFO - 2023-10-30 16:04:16 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 16:04:16 --> Model "Home_model" initialized
INFO - 2023-10-30 16:04:16 --> Helper loaded: download_helper
INFO - 2023-10-30 16:04:16 --> Helper loaded: form_helper
INFO - 2023-10-30 16:04:16 --> Form Validation Class Initialized
INFO - 2023-10-30 16:04:16 --> Helper loaded: custom_helper
INFO - 2023-10-30 16:04:16 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 16:04:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 16:04:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 16:04:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 16:04:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 16:04:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 16:04:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 16:04:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-10-30 16:04:16 --> Final output sent to browser
DEBUG - 2023-10-30 16:04:16 --> Total execution time: 0.2059
INFO - 2023-10-30 16:07:48 --> Config Class Initialized
INFO - 2023-10-30 16:07:48 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:07:48 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:07:48 --> Utf8 Class Initialized
INFO - 2023-10-30 16:07:48 --> URI Class Initialized
INFO - 2023-10-30 16:07:48 --> Router Class Initialized
INFO - 2023-10-30 16:07:48 --> Output Class Initialized
INFO - 2023-10-30 16:07:48 --> Security Class Initialized
DEBUG - 2023-10-30 16:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:07:48 --> Input Class Initialized
INFO - 2023-10-30 16:07:48 --> Language Class Initialized
INFO - 2023-10-30 16:07:48 --> Loader Class Initialized
INFO - 2023-10-30 16:07:48 --> Helper loaded: url_helper
INFO - 2023-10-30 16:07:48 --> Helper loaded: file_helper
INFO - 2023-10-30 16:07:48 --> Database Driver Class Initialized
INFO - 2023-10-30 16:07:48 --> Email Class Initialized
DEBUG - 2023-10-30 16:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 16:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:07:48 --> Controller Class Initialized
INFO - 2023-10-30 16:07:48 --> Model "Contact_model" initialized
INFO - 2023-10-30 16:07:48 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 16:07:48 --> Model "Home_model" initialized
INFO - 2023-10-30 16:07:48 --> Helper loaded: download_helper
INFO - 2023-10-30 16:07:48 --> Helper loaded: form_helper
INFO - 2023-10-30 16:07:48 --> Form Validation Class Initialized
INFO - 2023-10-30 16:07:48 --> Helper loaded: custom_helper
INFO - 2023-10-30 16:07:48 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 16:07:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 16:07:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 16:07:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 16:07:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 16:07:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 16:07:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 16:07:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-10-30 16:07:48 --> Final output sent to browser
DEBUG - 2023-10-30 16:07:48 --> Total execution time: 0.2135
INFO - 2023-10-30 16:08:20 --> Config Class Initialized
INFO - 2023-10-30 16:08:20 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:08:20 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:08:20 --> Utf8 Class Initialized
INFO - 2023-10-30 16:08:20 --> URI Class Initialized
INFO - 2023-10-30 16:08:20 --> Router Class Initialized
INFO - 2023-10-30 16:08:20 --> Output Class Initialized
INFO - 2023-10-30 16:08:20 --> Security Class Initialized
DEBUG - 2023-10-30 16:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:08:20 --> Input Class Initialized
INFO - 2023-10-30 16:08:20 --> Language Class Initialized
ERROR - 2023-10-30 16:08:20 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 16:08:20 --> Config Class Initialized
INFO - 2023-10-30 16:08:20 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:08:20 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:08:20 --> Utf8 Class Initialized
INFO - 2023-10-30 16:08:20 --> URI Class Initialized
INFO - 2023-10-30 16:08:20 --> Router Class Initialized
INFO - 2023-10-30 16:08:20 --> Output Class Initialized
INFO - 2023-10-30 16:08:20 --> Security Class Initialized
DEBUG - 2023-10-30 16:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:08:20 --> Input Class Initialized
INFO - 2023-10-30 16:08:20 --> Language Class Initialized
ERROR - 2023-10-30 16:08:20 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 16:08:20 --> Config Class Initialized
INFO - 2023-10-30 16:08:20 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:08:20 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:08:20 --> Utf8 Class Initialized
INFO - 2023-10-30 16:08:20 --> URI Class Initialized
INFO - 2023-10-30 16:08:20 --> Router Class Initialized
INFO - 2023-10-30 16:08:20 --> Output Class Initialized
INFO - 2023-10-30 16:08:20 --> Security Class Initialized
DEBUG - 2023-10-30 16:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:08:20 --> Input Class Initialized
INFO - 2023-10-30 16:08:20 --> Language Class Initialized
ERROR - 2023-10-30 16:08:20 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 16:08:20 --> Config Class Initialized
INFO - 2023-10-30 16:08:20 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:08:20 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:08:20 --> Utf8 Class Initialized
INFO - 2023-10-30 16:08:20 --> URI Class Initialized
INFO - 2023-10-30 16:08:20 --> Router Class Initialized
INFO - 2023-10-30 16:08:20 --> Output Class Initialized
INFO - 2023-10-30 16:08:20 --> Security Class Initialized
DEBUG - 2023-10-30 16:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:08:20 --> Input Class Initialized
INFO - 2023-10-30 16:08:20 --> Language Class Initialized
ERROR - 2023-10-30 16:08:20 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 16:08:20 --> Config Class Initialized
INFO - 2023-10-30 16:08:20 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:08:20 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:08:20 --> Utf8 Class Initialized
INFO - 2023-10-30 16:08:20 --> URI Class Initialized
INFO - 2023-10-30 16:08:20 --> Router Class Initialized
INFO - 2023-10-30 16:08:20 --> Output Class Initialized
INFO - 2023-10-30 16:08:20 --> Security Class Initialized
DEBUG - 2023-10-30 16:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:08:21 --> Input Class Initialized
INFO - 2023-10-30 16:08:21 --> Language Class Initialized
ERROR - 2023-10-30 16:08:21 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 16:08:21 --> Config Class Initialized
INFO - 2023-10-30 16:08:21 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:08:21 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:08:21 --> Utf8 Class Initialized
INFO - 2023-10-30 16:08:21 --> URI Class Initialized
INFO - 2023-10-30 16:08:21 --> Router Class Initialized
INFO - 2023-10-30 16:08:21 --> Output Class Initialized
INFO - 2023-10-30 16:08:21 --> Security Class Initialized
DEBUG - 2023-10-30 16:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:08:21 --> Input Class Initialized
INFO - 2023-10-30 16:08:21 --> Language Class Initialized
ERROR - 2023-10-30 16:08:21 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 16:08:21 --> Config Class Initialized
INFO - 2023-10-30 16:08:21 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:08:21 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:08:21 --> Utf8 Class Initialized
INFO - 2023-10-30 16:08:21 --> URI Class Initialized
INFO - 2023-10-30 16:08:21 --> Router Class Initialized
INFO - 2023-10-30 16:08:21 --> Output Class Initialized
INFO - 2023-10-30 16:08:21 --> Security Class Initialized
DEBUG - 2023-10-30 16:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:08:21 --> Input Class Initialized
INFO - 2023-10-30 16:08:21 --> Language Class Initialized
ERROR - 2023-10-30 16:08:21 --> 404 Page Not Found: Assets/home
INFO - 2023-10-30 16:09:26 --> Config Class Initialized
INFO - 2023-10-30 16:09:26 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:09:26 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:09:26 --> Utf8 Class Initialized
INFO - 2023-10-30 16:09:26 --> URI Class Initialized
INFO - 2023-10-30 16:09:26 --> Router Class Initialized
INFO - 2023-10-30 16:09:26 --> Output Class Initialized
INFO - 2023-10-30 16:09:26 --> Security Class Initialized
DEBUG - 2023-10-30 16:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:09:26 --> Input Class Initialized
INFO - 2023-10-30 16:09:26 --> Language Class Initialized
INFO - 2023-10-30 16:09:26 --> Loader Class Initialized
INFO - 2023-10-30 16:09:26 --> Helper loaded: url_helper
INFO - 2023-10-30 16:09:26 --> Helper loaded: file_helper
INFO - 2023-10-30 16:09:26 --> Database Driver Class Initialized
INFO - 2023-10-30 16:09:26 --> Email Class Initialized
DEBUG - 2023-10-30 16:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 16:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:09:26 --> Controller Class Initialized
INFO - 2023-10-30 16:09:26 --> Model "Contact_model" initialized
INFO - 2023-10-30 16:09:26 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 16:09:26 --> Model "Home_model" initialized
INFO - 2023-10-30 16:09:26 --> Helper loaded: download_helper
INFO - 2023-10-30 16:09:26 --> Helper loaded: form_helper
INFO - 2023-10-30 16:09:26 --> Form Validation Class Initialized
INFO - 2023-10-30 16:09:26 --> Helper loaded: custom_helper
INFO - 2023-10-30 16:09:26 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 16:09:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 16:09:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 16:09:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 16:09:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 16:09:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 16:09:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 16:09:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-10-30 16:09:26 --> Final output sent to browser
DEBUG - 2023-10-30 16:09:26 --> Total execution time: 0.1592
INFO - 2023-10-30 17:33:01 --> Config Class Initialized
INFO - 2023-10-30 17:33:01 --> Hooks Class Initialized
DEBUG - 2023-10-30 17:33:01 --> UTF-8 Support Enabled
INFO - 2023-10-30 17:33:01 --> Utf8 Class Initialized
INFO - 2023-10-30 17:33:01 --> URI Class Initialized
INFO - 2023-10-30 17:33:01 --> Router Class Initialized
INFO - 2023-10-30 17:33:01 --> Output Class Initialized
INFO - 2023-10-30 17:33:01 --> Security Class Initialized
DEBUG - 2023-10-30 17:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 17:33:01 --> Input Class Initialized
INFO - 2023-10-30 17:33:01 --> Language Class Initialized
INFO - 2023-10-30 17:33:01 --> Loader Class Initialized
INFO - 2023-10-30 17:33:01 --> Helper loaded: url_helper
INFO - 2023-10-30 17:33:01 --> Helper loaded: file_helper
INFO - 2023-10-30 17:33:01 --> Database Driver Class Initialized
INFO - 2023-10-30 17:33:01 --> Email Class Initialized
DEBUG - 2023-10-30 17:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 17:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 17:33:01 --> Controller Class Initialized
INFO - 2023-10-30 17:33:01 --> Model "Contact_model" initialized
INFO - 2023-10-30 17:33:01 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 17:33:01 --> Model "Home_model" initialized
INFO - 2023-10-30 17:33:01 --> Helper loaded: download_helper
INFO - 2023-10-30 17:33:01 --> Helper loaded: form_helper
INFO - 2023-10-30 17:33:01 --> Form Validation Class Initialized
INFO - 2023-10-30 17:33:01 --> Helper loaded: custom_helper
INFO - 2023-10-30 17:33:01 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 17:33:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 17:33:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 17:33:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 17:33:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 17:33:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 17:33:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 17:33:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-10-30 17:33:01 --> Final output sent to browser
DEBUG - 2023-10-30 17:33:01 --> Total execution time: 0.1586
INFO - 2023-10-30 17:58:28 --> Config Class Initialized
INFO - 2023-10-30 17:58:28 --> Hooks Class Initialized
DEBUG - 2023-10-30 17:58:28 --> UTF-8 Support Enabled
INFO - 2023-10-30 17:58:28 --> Utf8 Class Initialized
INFO - 2023-10-30 17:58:28 --> URI Class Initialized
DEBUG - 2023-10-30 17:58:28 --> No URI present. Default controller set.
INFO - 2023-10-30 17:58:28 --> Router Class Initialized
INFO - 2023-10-30 17:58:28 --> Output Class Initialized
INFO - 2023-10-30 17:58:28 --> Security Class Initialized
DEBUG - 2023-10-30 17:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 17:58:28 --> Input Class Initialized
INFO - 2023-10-30 17:58:28 --> Language Class Initialized
INFO - 2023-10-30 17:58:28 --> Loader Class Initialized
INFO - 2023-10-30 17:58:28 --> Helper loaded: url_helper
INFO - 2023-10-30 17:58:28 --> Helper loaded: file_helper
INFO - 2023-10-30 17:58:28 --> Database Driver Class Initialized
INFO - 2023-10-30 17:58:28 --> Email Class Initialized
DEBUG - 2023-10-30 17:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 17:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 17:58:28 --> Controller Class Initialized
INFO - 2023-10-30 17:58:28 --> Model "Contact_model" initialized
INFO - 2023-10-30 17:58:28 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 17:58:28 --> Model "Home_model" initialized
INFO - 2023-10-30 17:58:28 --> Helper loaded: download_helper
INFO - 2023-10-30 17:58:28 --> Helper loaded: form_helper
INFO - 2023-10-30 17:58:28 --> Form Validation Class Initialized
INFO - 2023-10-30 17:58:28 --> Helper loaded: custom_helper
INFO - 2023-10-30 17:58:28 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 17:58:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 17:58:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 17:58:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 17:58:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 17:58:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 17:58:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 17:58:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 17:58:28 --> Final output sent to browser
DEBUG - 2023-10-30 17:58:28 --> Total execution time: 0.2291
INFO - 2023-10-30 17:58:38 --> Config Class Initialized
INFO - 2023-10-30 17:58:38 --> Hooks Class Initialized
DEBUG - 2023-10-30 17:58:38 --> UTF-8 Support Enabled
INFO - 2023-10-30 17:58:38 --> Utf8 Class Initialized
INFO - 2023-10-30 17:58:38 --> URI Class Initialized
DEBUG - 2023-10-30 17:58:38 --> No URI present. Default controller set.
INFO - 2023-10-30 17:58:38 --> Router Class Initialized
INFO - 2023-10-30 17:58:38 --> Output Class Initialized
INFO - 2023-10-30 17:58:38 --> Security Class Initialized
DEBUG - 2023-10-30 17:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 17:58:38 --> Input Class Initialized
INFO - 2023-10-30 17:58:38 --> Language Class Initialized
INFO - 2023-10-30 17:58:38 --> Loader Class Initialized
INFO - 2023-10-30 17:58:38 --> Helper loaded: url_helper
INFO - 2023-10-30 17:58:38 --> Helper loaded: file_helper
INFO - 2023-10-30 17:58:38 --> Database Driver Class Initialized
INFO - 2023-10-30 17:58:38 --> Email Class Initialized
DEBUG - 2023-10-30 17:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 17:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 17:58:38 --> Controller Class Initialized
INFO - 2023-10-30 17:58:38 --> Model "Contact_model" initialized
INFO - 2023-10-30 17:58:38 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 17:58:38 --> Model "Home_model" initialized
INFO - 2023-10-30 17:58:38 --> Helper loaded: download_helper
INFO - 2023-10-30 17:58:38 --> Helper loaded: form_helper
INFO - 2023-10-30 17:58:38 --> Form Validation Class Initialized
INFO - 2023-10-30 17:58:38 --> Helper loaded: custom_helper
INFO - 2023-10-30 17:58:38 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 17:58:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 17:58:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 17:58:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 17:58:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 17:58:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 17:58:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 17:58:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 17:58:38 --> Final output sent to browser
DEBUG - 2023-10-30 17:58:38 --> Total execution time: 0.2309
INFO - 2023-10-30 18:00:01 --> Config Class Initialized
INFO - 2023-10-30 18:00:01 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:00:01 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:00:01 --> Utf8 Class Initialized
INFO - 2023-10-30 18:00:01 --> URI Class Initialized
DEBUG - 2023-10-30 18:00:01 --> No URI present. Default controller set.
INFO - 2023-10-30 18:00:01 --> Router Class Initialized
INFO - 2023-10-30 18:00:01 --> Output Class Initialized
INFO - 2023-10-30 18:00:01 --> Security Class Initialized
DEBUG - 2023-10-30 18:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:00:01 --> Input Class Initialized
INFO - 2023-10-30 18:00:01 --> Language Class Initialized
INFO - 2023-10-30 18:00:01 --> Loader Class Initialized
INFO - 2023-10-30 18:00:01 --> Helper loaded: url_helper
INFO - 2023-10-30 18:00:01 --> Helper loaded: file_helper
INFO - 2023-10-30 18:00:01 --> Database Driver Class Initialized
INFO - 2023-10-30 18:00:01 --> Email Class Initialized
DEBUG - 2023-10-30 18:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:00:01 --> Controller Class Initialized
INFO - 2023-10-30 18:00:01 --> Model "Contact_model" initialized
INFO - 2023-10-30 18:00:01 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 18:00:01 --> Model "Home_model" initialized
INFO - 2023-10-30 18:00:01 --> Helper loaded: download_helper
INFO - 2023-10-30 18:00:01 --> Helper loaded: form_helper
INFO - 2023-10-30 18:00:01 --> Form Validation Class Initialized
INFO - 2023-10-30 18:00:01 --> Helper loaded: custom_helper
INFO - 2023-10-30 18:00:01 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 18:00:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 18:00:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 18:00:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 18:00:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 18:00:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 18:00:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 18:00:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 18:00:02 --> Final output sent to browser
DEBUG - 2023-10-30 18:00:02 --> Total execution time: 0.1405
INFO - 2023-10-30 18:00:15 --> Config Class Initialized
INFO - 2023-10-30 18:00:15 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:00:15 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:00:15 --> Utf8 Class Initialized
INFO - 2023-10-30 18:00:15 --> URI Class Initialized
DEBUG - 2023-10-30 18:00:15 --> No URI present. Default controller set.
INFO - 2023-10-30 18:00:15 --> Router Class Initialized
INFO - 2023-10-30 18:00:15 --> Output Class Initialized
INFO - 2023-10-30 18:00:15 --> Security Class Initialized
DEBUG - 2023-10-30 18:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:00:15 --> Input Class Initialized
INFO - 2023-10-30 18:00:15 --> Language Class Initialized
INFO - 2023-10-30 18:00:15 --> Loader Class Initialized
INFO - 2023-10-30 18:00:15 --> Helper loaded: url_helper
INFO - 2023-10-30 18:00:15 --> Helper loaded: file_helper
INFO - 2023-10-30 18:00:15 --> Database Driver Class Initialized
INFO - 2023-10-30 18:00:15 --> Email Class Initialized
DEBUG - 2023-10-30 18:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:00:15 --> Controller Class Initialized
INFO - 2023-10-30 18:00:15 --> Model "Contact_model" initialized
INFO - 2023-10-30 18:00:15 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 18:00:15 --> Model "Home_model" initialized
INFO - 2023-10-30 18:00:15 --> Helper loaded: download_helper
INFO - 2023-10-30 18:00:15 --> Helper loaded: form_helper
INFO - 2023-10-30 18:00:15 --> Form Validation Class Initialized
INFO - 2023-10-30 18:00:15 --> Helper loaded: custom_helper
INFO - 2023-10-30 18:00:15 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 18:00:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 18:00:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 18:00:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 18:00:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 18:00:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 18:00:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 18:00:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 18:00:15 --> Final output sent to browser
DEBUG - 2023-10-30 18:00:15 --> Total execution time: 0.1514
INFO - 2023-10-30 18:00:41 --> Config Class Initialized
INFO - 2023-10-30 18:00:41 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:00:41 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:00:41 --> Utf8 Class Initialized
INFO - 2023-10-30 18:00:41 --> URI Class Initialized
DEBUG - 2023-10-30 18:00:41 --> No URI present. Default controller set.
INFO - 2023-10-30 18:00:41 --> Router Class Initialized
INFO - 2023-10-30 18:00:41 --> Output Class Initialized
INFO - 2023-10-30 18:00:41 --> Security Class Initialized
DEBUG - 2023-10-30 18:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:00:41 --> Input Class Initialized
INFO - 2023-10-30 18:00:41 --> Language Class Initialized
INFO - 2023-10-30 18:00:41 --> Loader Class Initialized
INFO - 2023-10-30 18:00:41 --> Helper loaded: url_helper
INFO - 2023-10-30 18:00:41 --> Helper loaded: file_helper
INFO - 2023-10-30 18:00:41 --> Database Driver Class Initialized
INFO - 2023-10-30 18:00:41 --> Email Class Initialized
DEBUG - 2023-10-30 18:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:00:41 --> Controller Class Initialized
INFO - 2023-10-30 18:00:41 --> Model "Contact_model" initialized
INFO - 2023-10-30 18:00:41 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 18:00:41 --> Model "Home_model" initialized
INFO - 2023-10-30 18:00:41 --> Helper loaded: download_helper
INFO - 2023-10-30 18:00:41 --> Helper loaded: form_helper
INFO - 2023-10-30 18:00:41 --> Form Validation Class Initialized
INFO - 2023-10-30 18:00:41 --> Helper loaded: custom_helper
INFO - 2023-10-30 18:00:41 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 18:00:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 18:00:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 18:00:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 18:00:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 18:00:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 18:00:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 18:00:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 18:00:42 --> Final output sent to browser
DEBUG - 2023-10-30 18:00:42 --> Total execution time: 0.1675
INFO - 2023-10-30 18:01:02 --> Config Class Initialized
INFO - 2023-10-30 18:01:02 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:01:02 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:01:02 --> Utf8 Class Initialized
INFO - 2023-10-30 18:01:02 --> URI Class Initialized
DEBUG - 2023-10-30 18:01:02 --> No URI present. Default controller set.
INFO - 2023-10-30 18:01:02 --> Router Class Initialized
INFO - 2023-10-30 18:01:02 --> Output Class Initialized
INFO - 2023-10-30 18:01:02 --> Security Class Initialized
DEBUG - 2023-10-30 18:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:01:02 --> Input Class Initialized
INFO - 2023-10-30 18:01:02 --> Language Class Initialized
INFO - 2023-10-30 18:01:02 --> Loader Class Initialized
INFO - 2023-10-30 18:01:02 --> Helper loaded: url_helper
INFO - 2023-10-30 18:01:02 --> Helper loaded: file_helper
INFO - 2023-10-30 18:01:02 --> Database Driver Class Initialized
INFO - 2023-10-30 18:01:02 --> Email Class Initialized
DEBUG - 2023-10-30 18:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:01:02 --> Controller Class Initialized
INFO - 2023-10-30 18:01:02 --> Model "Contact_model" initialized
INFO - 2023-10-30 18:01:02 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 18:01:02 --> Model "Home_model" initialized
INFO - 2023-10-30 18:01:02 --> Helper loaded: download_helper
INFO - 2023-10-30 18:01:02 --> Helper loaded: form_helper
INFO - 2023-10-30 18:01:02 --> Form Validation Class Initialized
INFO - 2023-10-30 18:01:02 --> Helper loaded: custom_helper
INFO - 2023-10-30 18:01:02 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 18:01:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 18:01:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 18:01:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 18:01:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 18:01:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 18:01:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 18:01:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 18:01:02 --> Final output sent to browser
DEBUG - 2023-10-30 18:01:02 --> Total execution time: 0.1480
INFO - 2023-10-30 18:01:53 --> Config Class Initialized
INFO - 2023-10-30 18:01:53 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:01:53 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:01:53 --> Utf8 Class Initialized
INFO - 2023-10-30 18:01:53 --> URI Class Initialized
DEBUG - 2023-10-30 18:01:53 --> No URI present. Default controller set.
INFO - 2023-10-30 18:01:53 --> Router Class Initialized
INFO - 2023-10-30 18:01:53 --> Output Class Initialized
INFO - 2023-10-30 18:01:53 --> Security Class Initialized
DEBUG - 2023-10-30 18:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:01:53 --> Input Class Initialized
INFO - 2023-10-30 18:01:53 --> Language Class Initialized
INFO - 2023-10-30 18:01:53 --> Loader Class Initialized
INFO - 2023-10-30 18:01:53 --> Helper loaded: url_helper
INFO - 2023-10-30 18:01:53 --> Helper loaded: file_helper
INFO - 2023-10-30 18:01:53 --> Database Driver Class Initialized
INFO - 2023-10-30 18:01:53 --> Email Class Initialized
DEBUG - 2023-10-30 18:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:01:53 --> Controller Class Initialized
INFO - 2023-10-30 18:01:53 --> Model "Contact_model" initialized
INFO - 2023-10-30 18:01:53 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 18:01:53 --> Model "Home_model" initialized
INFO - 2023-10-30 18:01:53 --> Helper loaded: download_helper
INFO - 2023-10-30 18:01:53 --> Helper loaded: form_helper
INFO - 2023-10-30 18:01:53 --> Form Validation Class Initialized
INFO - 2023-10-30 18:01:53 --> Helper loaded: custom_helper
INFO - 2023-10-30 18:01:53 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 18:01:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 18:01:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 18:01:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 18:01:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 18:01:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 18:01:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 18:01:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 18:01:53 --> Final output sent to browser
DEBUG - 2023-10-30 18:01:53 --> Total execution time: 0.1673
INFO - 2023-10-30 18:02:31 --> Config Class Initialized
INFO - 2023-10-30 18:02:31 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:02:31 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:02:31 --> Utf8 Class Initialized
INFO - 2023-10-30 18:02:31 --> URI Class Initialized
DEBUG - 2023-10-30 18:02:31 --> No URI present. Default controller set.
INFO - 2023-10-30 18:02:31 --> Router Class Initialized
INFO - 2023-10-30 18:02:31 --> Output Class Initialized
INFO - 2023-10-30 18:02:31 --> Security Class Initialized
DEBUG - 2023-10-30 18:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:02:31 --> Input Class Initialized
INFO - 2023-10-30 18:02:31 --> Language Class Initialized
INFO - 2023-10-30 18:02:31 --> Loader Class Initialized
INFO - 2023-10-30 18:02:31 --> Helper loaded: url_helper
INFO - 2023-10-30 18:02:31 --> Helper loaded: file_helper
INFO - 2023-10-30 18:02:31 --> Database Driver Class Initialized
INFO - 2023-10-30 18:02:31 --> Email Class Initialized
DEBUG - 2023-10-30 18:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:02:31 --> Controller Class Initialized
INFO - 2023-10-30 18:02:31 --> Model "Contact_model" initialized
INFO - 2023-10-30 18:02:31 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 18:02:31 --> Model "Home_model" initialized
INFO - 2023-10-30 18:02:31 --> Helper loaded: download_helper
INFO - 2023-10-30 18:02:31 --> Helper loaded: form_helper
INFO - 2023-10-30 18:02:31 --> Form Validation Class Initialized
INFO - 2023-10-30 18:02:31 --> Helper loaded: custom_helper
INFO - 2023-10-30 18:02:31 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 18:02:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 18:02:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 18:02:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 18:02:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 18:02:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 18:02:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 18:02:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-30 18:02:32 --> Final output sent to browser
DEBUG - 2023-10-30 18:02:32 --> Total execution time: 0.9522
INFO - 2023-10-30 18:06:45 --> Config Class Initialized
INFO - 2023-10-30 18:06:45 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:06:45 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:06:45 --> Utf8 Class Initialized
INFO - 2023-10-30 18:06:45 --> URI Class Initialized
INFO - 2023-10-30 18:06:45 --> Router Class Initialized
INFO - 2023-10-30 18:06:45 --> Output Class Initialized
INFO - 2023-10-30 18:06:45 --> Security Class Initialized
DEBUG - 2023-10-30 18:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:06:45 --> Input Class Initialized
INFO - 2023-10-30 18:06:45 --> Language Class Initialized
INFO - 2023-10-30 18:06:45 --> Loader Class Initialized
INFO - 2023-10-30 18:06:45 --> Helper loaded: url_helper
INFO - 2023-10-30 18:06:45 --> Helper loaded: file_helper
INFO - 2023-10-30 18:06:45 --> Database Driver Class Initialized
INFO - 2023-10-30 18:06:45 --> Email Class Initialized
DEBUG - 2023-10-30 18:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:06:45 --> Controller Class Initialized
INFO - 2023-10-30 18:06:45 --> Model "Contact_model" initialized
INFO - 2023-10-30 18:06:45 --> Model "CareerFormModel" initialized
INFO - 2023-10-30 18:06:45 --> Model "Home_model" initialized
INFO - 2023-10-30 18:06:45 --> Helper loaded: download_helper
INFO - 2023-10-30 18:06:45 --> Helper loaded: form_helper
INFO - 2023-10-30 18:06:45 --> Form Validation Class Initialized
INFO - 2023-10-30 18:06:45 --> Helper loaded: custom_helper
INFO - 2023-10-30 18:06:45 --> Model "Social_media_model" initialized
ERROR - 2023-10-30 18:06:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 18:06:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-30 18:06:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 18:06:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-30 18:06:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-30 18:06:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-30 18:06:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-10-30 18:06:45 --> Final output sent to browser
DEBUG - 2023-10-30 18:06:45 --> Total execution time: 0.1537
