<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-17 19:22:52 --> Config Class Initialized
INFO - 2023-10-17 19:22:52 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:22:52 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:22:52 --> Utf8 Class Initialized
INFO - 2023-10-17 19:22:52 --> URI Class Initialized
DEBUG - 2023-10-17 19:22:52 --> No URI present. Default controller set.
INFO - 2023-10-17 19:22:52 --> Router Class Initialized
INFO - 2023-10-17 19:22:52 --> Output Class Initialized
INFO - 2023-10-17 19:22:52 --> Security Class Initialized
DEBUG - 2023-10-17 19:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:22:52 --> Input Class Initialized
INFO - 2023-10-17 19:22:52 --> Language Class Initialized
INFO - 2023-10-17 19:22:52 --> Loader Class Initialized
INFO - 2023-10-17 19:22:52 --> Helper loaded: url_helper
INFO - 2023-10-17 19:22:52 --> Helper loaded: file_helper
INFO - 2023-10-17 19:22:52 --> Database Driver Class Initialized
INFO - 2023-10-17 19:22:52 --> Email Class Initialized
DEBUG - 2023-10-17 19:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:22:52 --> Controller Class Initialized
INFO - 2023-10-17 19:22:52 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:22:52 --> Model "Home_model" initialized
INFO - 2023-10-17 19:22:52 --> Helper loaded: download_helper
INFO - 2023-10-17 19:22:52 --> Helper loaded: form_helper
INFO - 2023-10-17 19:22:52 --> Form Validation Class Initialized
INFO - 2023-10-17 19:22:52 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:22:52 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:22:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 19:22:52 --> Final output sent to browser
DEBUG - 2023-10-17 19:22:52 --> Total execution time: 0.1701
INFO - 2023-10-17 19:23:01 --> Config Class Initialized
INFO - 2023-10-17 19:23:01 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:23:01 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:23:01 --> Utf8 Class Initialized
INFO - 2023-10-17 19:23:01 --> URI Class Initialized
INFO - 2023-10-17 19:23:01 --> Router Class Initialized
INFO - 2023-10-17 19:23:01 --> Output Class Initialized
INFO - 2023-10-17 19:23:01 --> Security Class Initialized
DEBUG - 2023-10-17 19:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:23:01 --> Input Class Initialized
INFO - 2023-10-17 19:23:01 --> Language Class Initialized
INFO - 2023-10-17 19:23:01 --> Loader Class Initialized
INFO - 2023-10-17 19:23:01 --> Helper loaded: url_helper
INFO - 2023-10-17 19:23:01 --> Helper loaded: file_helper
INFO - 2023-10-17 19:23:01 --> Database Driver Class Initialized
INFO - 2023-10-17 19:23:01 --> Email Class Initialized
DEBUG - 2023-10-17 19:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:23:01 --> Controller Class Initialized
INFO - 2023-10-17 19:23:01 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:23:01 --> Model "Home_model" initialized
INFO - 2023-10-17 19:23:01 --> Helper loaded: download_helper
INFO - 2023-10-17 19:23:01 --> Helper loaded: form_helper
INFO - 2023-10-17 19:23:01 --> Form Validation Class Initialized
INFO - 2023-10-17 19:23:01 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:23:01 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:23:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-10-17 19:23:01 --> Final output sent to browser
DEBUG - 2023-10-17 19:23:01 --> Total execution time: 0.0847
INFO - 2023-10-17 19:23:06 --> Config Class Initialized
INFO - 2023-10-17 19:23:06 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:23:06 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:23:06 --> Utf8 Class Initialized
INFO - 2023-10-17 19:23:06 --> URI Class Initialized
DEBUG - 2023-10-17 19:23:06 --> No URI present. Default controller set.
INFO - 2023-10-17 19:23:06 --> Router Class Initialized
INFO - 2023-10-17 19:23:06 --> Output Class Initialized
INFO - 2023-10-17 19:23:06 --> Security Class Initialized
DEBUG - 2023-10-17 19:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:23:06 --> Input Class Initialized
INFO - 2023-10-17 19:23:06 --> Language Class Initialized
INFO - 2023-10-17 19:23:06 --> Loader Class Initialized
INFO - 2023-10-17 19:23:06 --> Helper loaded: url_helper
INFO - 2023-10-17 19:23:06 --> Helper loaded: file_helper
INFO - 2023-10-17 19:23:06 --> Database Driver Class Initialized
INFO - 2023-10-17 19:23:06 --> Email Class Initialized
DEBUG - 2023-10-17 19:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:23:06 --> Controller Class Initialized
INFO - 2023-10-17 19:23:06 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:23:06 --> Model "Home_model" initialized
INFO - 2023-10-17 19:23:06 --> Helper loaded: download_helper
INFO - 2023-10-17 19:23:06 --> Helper loaded: form_helper
INFO - 2023-10-17 19:23:06 --> Form Validation Class Initialized
INFO - 2023-10-17 19:23:06 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:23:06 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:23:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 19:23:06 --> Final output sent to browser
DEBUG - 2023-10-17 19:23:06 --> Total execution time: 0.0777
INFO - 2023-10-17 19:36:21 --> Config Class Initialized
INFO - 2023-10-17 19:36:21 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:36:21 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:36:21 --> Utf8 Class Initialized
INFO - 2023-10-17 19:36:21 --> URI Class Initialized
DEBUG - 2023-10-17 19:36:21 --> No URI present. Default controller set.
INFO - 2023-10-17 19:36:21 --> Router Class Initialized
INFO - 2023-10-17 19:36:21 --> Output Class Initialized
INFO - 2023-10-17 19:36:21 --> Security Class Initialized
DEBUG - 2023-10-17 19:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:36:21 --> Input Class Initialized
INFO - 2023-10-17 19:36:21 --> Language Class Initialized
INFO - 2023-10-17 19:36:22 --> Loader Class Initialized
INFO - 2023-10-17 19:36:22 --> Helper loaded: url_helper
INFO - 2023-10-17 19:36:22 --> Helper loaded: file_helper
INFO - 2023-10-17 19:36:22 --> Database Driver Class Initialized
INFO - 2023-10-17 19:36:22 --> Email Class Initialized
DEBUG - 2023-10-17 19:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:36:22 --> Controller Class Initialized
INFO - 2023-10-17 19:36:22 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:36:22 --> Model "Home_model" initialized
INFO - 2023-10-17 19:36:22 --> Helper loaded: download_helper
INFO - 2023-10-17 19:36:22 --> Helper loaded: form_helper
INFO - 2023-10-17 19:36:22 --> Form Validation Class Initialized
INFO - 2023-10-17 19:36:23 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:36:23 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:36:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 19:36:23 --> Final output sent to browser
DEBUG - 2023-10-17 19:36:23 --> Total execution time: 2.3253
INFO - 2023-10-17 19:41:13 --> Config Class Initialized
INFO - 2023-10-17 19:41:13 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:41:13 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:41:13 --> Utf8 Class Initialized
INFO - 2023-10-17 19:41:13 --> URI Class Initialized
DEBUG - 2023-10-17 19:41:13 --> No URI present. Default controller set.
INFO - 2023-10-17 19:41:13 --> Router Class Initialized
INFO - 2023-10-17 19:41:13 --> Output Class Initialized
INFO - 2023-10-17 19:41:13 --> Security Class Initialized
DEBUG - 2023-10-17 19:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:41:13 --> Input Class Initialized
INFO - 2023-10-17 19:41:13 --> Language Class Initialized
INFO - 2023-10-17 19:41:13 --> Loader Class Initialized
INFO - 2023-10-17 19:41:13 --> Helper loaded: url_helper
INFO - 2023-10-17 19:41:13 --> Helper loaded: file_helper
INFO - 2023-10-17 19:41:13 --> Database Driver Class Initialized
INFO - 2023-10-17 19:41:13 --> Email Class Initialized
DEBUG - 2023-10-17 19:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:41:13 --> Controller Class Initialized
INFO - 2023-10-17 19:41:13 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:41:13 --> Model "Home_model" initialized
INFO - 2023-10-17 19:41:13 --> Helper loaded: download_helper
INFO - 2023-10-17 19:41:13 --> Helper loaded: form_helper
INFO - 2023-10-17 19:41:13 --> Form Validation Class Initialized
ERROR - 2023-10-17 19:41:14 --> Severity: Warning --> Undefined variable $social_media C:\xampp\htdocs\dw\application\views\home\includes\styles.php 372
ERROR - 2023-10-17 19:41:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\includes\styles.php 372
INFO - 2023-10-17 19:41:14 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:41:14 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:41:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 19:41:14 --> Final output sent to browser
DEBUG - 2023-10-17 19:41:14 --> Total execution time: 0.3671
INFO - 2023-10-17 19:42:29 --> Config Class Initialized
INFO - 2023-10-17 19:42:29 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:42:29 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:42:29 --> Utf8 Class Initialized
INFO - 2023-10-17 19:42:29 --> URI Class Initialized
DEBUG - 2023-10-17 19:42:29 --> No URI present. Default controller set.
INFO - 2023-10-17 19:42:29 --> Router Class Initialized
INFO - 2023-10-17 19:42:29 --> Output Class Initialized
INFO - 2023-10-17 19:42:29 --> Security Class Initialized
DEBUG - 2023-10-17 19:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:42:29 --> Input Class Initialized
INFO - 2023-10-17 19:42:29 --> Language Class Initialized
INFO - 2023-10-17 19:42:29 --> Loader Class Initialized
INFO - 2023-10-17 19:42:29 --> Helper loaded: url_helper
INFO - 2023-10-17 19:42:29 --> Helper loaded: file_helper
INFO - 2023-10-17 19:42:29 --> Database Driver Class Initialized
INFO - 2023-10-17 19:42:29 --> Email Class Initialized
DEBUG - 2023-10-17 19:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:42:29 --> Controller Class Initialized
INFO - 2023-10-17 19:42:29 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:42:29 --> Model "Home_model" initialized
INFO - 2023-10-17 19:42:29 --> Helper loaded: download_helper
INFO - 2023-10-17 19:42:29 --> Helper loaded: form_helper
INFO - 2023-10-17 19:42:29 --> Form Validation Class Initialized
INFO - 2023-10-17 19:42:29 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:42:29 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:42:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 19:42:29 --> Final output sent to browser
DEBUG - 2023-10-17 19:42:29 --> Total execution time: 0.1747
INFO - 2023-10-17 19:45:26 --> Config Class Initialized
INFO - 2023-10-17 19:45:26 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:45:26 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:45:26 --> Utf8 Class Initialized
INFO - 2023-10-17 19:45:26 --> URI Class Initialized
DEBUG - 2023-10-17 19:45:26 --> No URI present. Default controller set.
INFO - 2023-10-17 19:45:26 --> Router Class Initialized
INFO - 2023-10-17 19:45:26 --> Output Class Initialized
INFO - 2023-10-17 19:45:26 --> Security Class Initialized
DEBUG - 2023-10-17 19:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:45:26 --> Input Class Initialized
INFO - 2023-10-17 19:45:26 --> Language Class Initialized
INFO - 2023-10-17 19:45:26 --> Loader Class Initialized
INFO - 2023-10-17 19:45:26 --> Helper loaded: url_helper
INFO - 2023-10-17 19:45:26 --> Helper loaded: file_helper
INFO - 2023-10-17 19:45:26 --> Database Driver Class Initialized
INFO - 2023-10-17 19:45:26 --> Email Class Initialized
DEBUG - 2023-10-17 19:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:45:26 --> Controller Class Initialized
INFO - 2023-10-17 19:45:26 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:45:26 --> Model "Home_model" initialized
INFO - 2023-10-17 19:45:26 --> Helper loaded: download_helper
INFO - 2023-10-17 19:45:26 --> Helper loaded: form_helper
INFO - 2023-10-17 19:45:26 --> Form Validation Class Initialized
INFO - 2023-10-17 19:45:26 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:45:26 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:45:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 19:45:26 --> Final output sent to browser
DEBUG - 2023-10-17 19:45:26 --> Total execution time: 0.2321
INFO - 2023-10-17 19:46:57 --> Config Class Initialized
INFO - 2023-10-17 19:46:57 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:46:57 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:46:57 --> Utf8 Class Initialized
INFO - 2023-10-17 19:46:57 --> URI Class Initialized
DEBUG - 2023-10-17 19:46:57 --> No URI present. Default controller set.
INFO - 2023-10-17 19:46:57 --> Router Class Initialized
INFO - 2023-10-17 19:46:57 --> Output Class Initialized
INFO - 2023-10-17 19:46:57 --> Security Class Initialized
DEBUG - 2023-10-17 19:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:46:57 --> Input Class Initialized
INFO - 2023-10-17 19:46:57 --> Language Class Initialized
INFO - 2023-10-17 19:46:57 --> Loader Class Initialized
INFO - 2023-10-17 19:46:57 --> Helper loaded: url_helper
INFO - 2023-10-17 19:46:57 --> Helper loaded: file_helper
INFO - 2023-10-17 19:46:57 --> Database Driver Class Initialized
INFO - 2023-10-17 19:46:57 --> Email Class Initialized
DEBUG - 2023-10-17 19:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:46:57 --> Controller Class Initialized
INFO - 2023-10-17 19:46:57 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:46:57 --> Model "Home_model" initialized
INFO - 2023-10-17 19:46:57 --> Helper loaded: download_helper
INFO - 2023-10-17 19:46:57 --> Helper loaded: form_helper
INFO - 2023-10-17 19:46:57 --> Form Validation Class Initialized
INFO - 2023-10-17 19:46:57 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:46:57 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:46:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 19:46:57 --> Final output sent to browser
DEBUG - 2023-10-17 19:46:57 --> Total execution time: 0.2979
INFO - 2023-10-17 19:47:10 --> Config Class Initialized
INFO - 2023-10-17 19:47:10 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:47:10 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:47:10 --> Utf8 Class Initialized
INFO - 2023-10-17 19:47:10 --> URI Class Initialized
DEBUG - 2023-10-17 19:47:10 --> No URI present. Default controller set.
INFO - 2023-10-17 19:47:10 --> Router Class Initialized
INFO - 2023-10-17 19:47:10 --> Output Class Initialized
INFO - 2023-10-17 19:47:10 --> Security Class Initialized
DEBUG - 2023-10-17 19:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:47:10 --> Input Class Initialized
INFO - 2023-10-17 19:47:10 --> Language Class Initialized
INFO - 2023-10-17 19:47:10 --> Loader Class Initialized
INFO - 2023-10-17 19:47:10 --> Helper loaded: url_helper
INFO - 2023-10-17 19:47:10 --> Helper loaded: file_helper
INFO - 2023-10-17 19:47:10 --> Database Driver Class Initialized
INFO - 2023-10-17 19:47:10 --> Email Class Initialized
DEBUG - 2023-10-17 19:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:47:10 --> Controller Class Initialized
INFO - 2023-10-17 19:47:10 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:47:10 --> Model "Home_model" initialized
INFO - 2023-10-17 19:47:10 --> Helper loaded: download_helper
INFO - 2023-10-17 19:47:10 --> Helper loaded: form_helper
INFO - 2023-10-17 19:47:10 --> Form Validation Class Initialized
INFO - 2023-10-17 19:47:10 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:47:10 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:47:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 19:47:10 --> Final output sent to browser
DEBUG - 2023-10-17 19:47:10 --> Total execution time: 0.1499
INFO - 2023-10-17 19:48:35 --> Config Class Initialized
INFO - 2023-10-17 19:48:35 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:48:35 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:48:35 --> Utf8 Class Initialized
INFO - 2023-10-17 19:48:35 --> URI Class Initialized
INFO - 2023-10-17 19:48:35 --> Router Class Initialized
INFO - 2023-10-17 19:48:35 --> Output Class Initialized
INFO - 2023-10-17 19:48:35 --> Security Class Initialized
DEBUG - 2023-10-17 19:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:48:35 --> Input Class Initialized
INFO - 2023-10-17 19:48:35 --> Language Class Initialized
INFO - 2023-10-17 19:48:35 --> Loader Class Initialized
INFO - 2023-10-17 19:48:35 --> Helper loaded: url_helper
INFO - 2023-10-17 19:48:35 --> Helper loaded: file_helper
INFO - 2023-10-17 19:48:35 --> Database Driver Class Initialized
INFO - 2023-10-17 19:48:35 --> Email Class Initialized
DEBUG - 2023-10-17 19:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:48:35 --> Controller Class Initialized
INFO - 2023-10-17 19:48:35 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:48:35 --> Model "Home_model" initialized
INFO - 2023-10-17 19:48:35 --> Helper loaded: download_helper
INFO - 2023-10-17 19:48:35 --> Helper loaded: form_helper
INFO - 2023-10-17 19:48:35 --> Form Validation Class Initialized
INFO - 2023-10-17 19:48:35 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:48:35 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:48:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-10-17 19:48:35 --> Final output sent to browser
DEBUG - 2023-10-17 19:48:35 --> Total execution time: 0.2339
INFO - 2023-10-17 19:48:50 --> Config Class Initialized
INFO - 2023-10-17 19:48:50 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:48:50 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:48:50 --> Utf8 Class Initialized
INFO - 2023-10-17 19:48:50 --> URI Class Initialized
INFO - 2023-10-17 19:48:50 --> Router Class Initialized
INFO - 2023-10-17 19:48:50 --> Output Class Initialized
INFO - 2023-10-17 19:48:50 --> Security Class Initialized
DEBUG - 2023-10-17 19:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:48:50 --> Input Class Initialized
INFO - 2023-10-17 19:48:50 --> Language Class Initialized
INFO - 2023-10-17 19:48:50 --> Loader Class Initialized
INFO - 2023-10-17 19:48:50 --> Helper loaded: url_helper
INFO - 2023-10-17 19:48:50 --> Helper loaded: file_helper
INFO - 2023-10-17 19:48:50 --> Database Driver Class Initialized
INFO - 2023-10-17 19:48:50 --> Email Class Initialized
DEBUG - 2023-10-17 19:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:48:50 --> Controller Class Initialized
INFO - 2023-10-17 19:48:50 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:48:50 --> Model "Home_model" initialized
INFO - 2023-10-17 19:48:50 --> Helper loaded: download_helper
INFO - 2023-10-17 19:48:50 --> Helper loaded: form_helper
INFO - 2023-10-17 19:48:50 --> Form Validation Class Initialized
INFO - 2023-10-17 19:48:51 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:48:51 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:48:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 19:48:51 --> Final output sent to browser
DEBUG - 2023-10-17 19:48:51 --> Total execution time: 0.2837
INFO - 2023-10-17 19:53:02 --> Config Class Initialized
INFO - 2023-10-17 19:53:02 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:53:02 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:53:02 --> Utf8 Class Initialized
INFO - 2023-10-17 19:53:02 --> URI Class Initialized
INFO - 2023-10-17 19:53:02 --> Router Class Initialized
INFO - 2023-10-17 19:53:02 --> Output Class Initialized
INFO - 2023-10-17 19:53:02 --> Security Class Initialized
DEBUG - 2023-10-17 19:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:53:02 --> Input Class Initialized
INFO - 2023-10-17 19:53:02 --> Language Class Initialized
INFO - 2023-10-17 19:53:02 --> Loader Class Initialized
INFO - 2023-10-17 19:53:02 --> Helper loaded: url_helper
INFO - 2023-10-17 19:53:02 --> Helper loaded: file_helper
INFO - 2023-10-17 19:53:02 --> Database Driver Class Initialized
INFO - 2023-10-17 19:53:02 --> Email Class Initialized
DEBUG - 2023-10-17 19:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:53:02 --> Controller Class Initialized
INFO - 2023-10-17 19:53:02 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:53:02 --> Model "Home_model" initialized
INFO - 2023-10-17 19:53:02 --> Helper loaded: download_helper
INFO - 2023-10-17 19:53:02 --> Helper loaded: form_helper
INFO - 2023-10-17 19:53:02 --> Form Validation Class Initialized
INFO - 2023-10-17 19:53:02 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:53:02 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:53:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-10-17 19:53:02 --> Final output sent to browser
DEBUG - 2023-10-17 19:53:02 --> Total execution time: 0.1500
INFO - 2023-10-17 19:53:07 --> Config Class Initialized
INFO - 2023-10-17 19:53:07 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:53:07 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:53:07 --> Utf8 Class Initialized
INFO - 2023-10-17 19:53:07 --> URI Class Initialized
INFO - 2023-10-17 19:53:07 --> Router Class Initialized
INFO - 2023-10-17 19:53:07 --> Output Class Initialized
INFO - 2023-10-17 19:53:07 --> Security Class Initialized
DEBUG - 2023-10-17 19:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:53:07 --> Input Class Initialized
INFO - 2023-10-17 19:53:07 --> Language Class Initialized
INFO - 2023-10-17 19:53:07 --> Loader Class Initialized
INFO - 2023-10-17 19:53:07 --> Helper loaded: url_helper
INFO - 2023-10-17 19:53:07 --> Helper loaded: file_helper
INFO - 2023-10-17 19:53:07 --> Database Driver Class Initialized
INFO - 2023-10-17 19:53:07 --> Email Class Initialized
DEBUG - 2023-10-17 19:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:53:07 --> Controller Class Initialized
INFO - 2023-10-17 19:53:07 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:53:07 --> Model "Home_model" initialized
INFO - 2023-10-17 19:53:07 --> Helper loaded: download_helper
INFO - 2023-10-17 19:53:07 --> Helper loaded: form_helper
INFO - 2023-10-17 19:53:07 --> Form Validation Class Initialized
INFO - 2023-10-17 19:53:07 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:53:07 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:53:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 19:53:07 --> Final output sent to browser
DEBUG - 2023-10-17 19:53:07 --> Total execution time: 0.1088
INFO - 2023-10-17 19:53:51 --> Config Class Initialized
INFO - 2023-10-17 19:53:51 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:53:51 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:53:51 --> Utf8 Class Initialized
INFO - 2023-10-17 19:53:51 --> URI Class Initialized
INFO - 2023-10-17 19:53:51 --> Router Class Initialized
INFO - 2023-10-17 19:53:51 --> Output Class Initialized
INFO - 2023-10-17 19:53:51 --> Security Class Initialized
DEBUG - 2023-10-17 19:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:53:51 --> Input Class Initialized
INFO - 2023-10-17 19:53:51 --> Language Class Initialized
INFO - 2023-10-17 19:53:52 --> Loader Class Initialized
INFO - 2023-10-17 19:53:52 --> Helper loaded: url_helper
INFO - 2023-10-17 19:53:52 --> Helper loaded: file_helper
INFO - 2023-10-17 19:53:52 --> Database Driver Class Initialized
INFO - 2023-10-17 19:53:52 --> Email Class Initialized
DEBUG - 2023-10-17 19:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:53:52 --> Controller Class Initialized
INFO - 2023-10-17 19:53:52 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:53:52 --> Model "Home_model" initialized
INFO - 2023-10-17 19:53:52 --> Helper loaded: download_helper
INFO - 2023-10-17 19:53:52 --> Helper loaded: form_helper
INFO - 2023-10-17 19:53:52 --> Form Validation Class Initialized
INFO - 2023-10-17 19:54:50 --> Config Class Initialized
INFO - 2023-10-17 19:54:50 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:54:50 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:54:50 --> Utf8 Class Initialized
INFO - 2023-10-17 19:54:50 --> URI Class Initialized
INFO - 2023-10-17 19:54:50 --> Router Class Initialized
INFO - 2023-10-17 19:54:50 --> Output Class Initialized
INFO - 2023-10-17 19:54:50 --> Security Class Initialized
DEBUG - 2023-10-17 19:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:54:50 --> Input Class Initialized
INFO - 2023-10-17 19:54:50 --> Language Class Initialized
INFO - 2023-10-17 19:54:50 --> Loader Class Initialized
INFO - 2023-10-17 19:54:50 --> Helper loaded: url_helper
INFO - 2023-10-17 19:54:50 --> Helper loaded: file_helper
INFO - 2023-10-17 19:54:50 --> Database Driver Class Initialized
INFO - 2023-10-17 19:54:50 --> Email Class Initialized
DEBUG - 2023-10-17 19:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:54:50 --> Controller Class Initialized
INFO - 2023-10-17 19:54:50 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:54:50 --> Model "Home_model" initialized
INFO - 2023-10-17 19:54:50 --> Helper loaded: download_helper
INFO - 2023-10-17 19:54:50 --> Helper loaded: form_helper
INFO - 2023-10-17 19:54:50 --> Form Validation Class Initialized
INFO - 2023-10-17 19:55:07 --> Config Class Initialized
INFO - 2023-10-17 19:55:07 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:55:07 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:55:07 --> Utf8 Class Initialized
INFO - 2023-10-17 19:55:07 --> URI Class Initialized
INFO - 2023-10-17 19:55:07 --> Router Class Initialized
INFO - 2023-10-17 19:55:07 --> Output Class Initialized
INFO - 2023-10-17 19:55:07 --> Security Class Initialized
DEBUG - 2023-10-17 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:55:07 --> Input Class Initialized
INFO - 2023-10-17 19:55:07 --> Language Class Initialized
INFO - 2023-10-17 19:55:07 --> Loader Class Initialized
INFO - 2023-10-17 19:55:07 --> Helper loaded: url_helper
INFO - 2023-10-17 19:55:07 --> Helper loaded: file_helper
INFO - 2023-10-17 19:55:07 --> Database Driver Class Initialized
INFO - 2023-10-17 19:55:07 --> Email Class Initialized
DEBUG - 2023-10-17 19:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:55:07 --> Controller Class Initialized
INFO - 2023-10-17 19:55:07 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:55:07 --> Model "Home_model" initialized
INFO - 2023-10-17 19:55:07 --> Helper loaded: download_helper
INFO - 2023-10-17 19:55:07 --> Helper loaded: form_helper
INFO - 2023-10-17 19:55:07 --> Form Validation Class Initialized
ERROR - 2023-10-17 19:55:07 --> Severity: error --> Exception: Undefined constant "id" C:\xampp\htdocs\dw\application\controllers\HomeController.php 110
INFO - 2023-10-17 19:55:08 --> Config Class Initialized
INFO - 2023-10-17 19:55:08 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:55:08 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:55:08 --> Utf8 Class Initialized
INFO - 2023-10-17 19:55:08 --> URI Class Initialized
INFO - 2023-10-17 19:55:08 --> Router Class Initialized
INFO - 2023-10-17 19:55:08 --> Output Class Initialized
INFO - 2023-10-17 19:55:08 --> Security Class Initialized
DEBUG - 2023-10-17 19:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:55:08 --> Input Class Initialized
INFO - 2023-10-17 19:55:08 --> Language Class Initialized
INFO - 2023-10-17 19:55:08 --> Loader Class Initialized
INFO - 2023-10-17 19:55:08 --> Helper loaded: url_helper
INFO - 2023-10-17 19:55:08 --> Helper loaded: file_helper
INFO - 2023-10-17 19:55:08 --> Database Driver Class Initialized
INFO - 2023-10-17 19:55:08 --> Email Class Initialized
DEBUG - 2023-10-17 19:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:55:08 --> Controller Class Initialized
INFO - 2023-10-17 19:55:08 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:55:08 --> Model "Home_model" initialized
INFO - 2023-10-17 19:55:08 --> Helper loaded: download_helper
INFO - 2023-10-17 19:55:08 --> Helper loaded: form_helper
INFO - 2023-10-17 19:55:08 --> Form Validation Class Initialized
ERROR - 2023-10-17 19:55:08 --> Severity: error --> Exception: Undefined constant "id" C:\xampp\htdocs\dw\application\controllers\HomeController.php 110
INFO - 2023-10-17 19:55:24 --> Config Class Initialized
INFO - 2023-10-17 19:55:24 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:55:24 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:55:24 --> Utf8 Class Initialized
INFO - 2023-10-17 19:55:24 --> URI Class Initialized
INFO - 2023-10-17 19:55:24 --> Router Class Initialized
INFO - 2023-10-17 19:55:24 --> Output Class Initialized
INFO - 2023-10-17 19:55:24 --> Security Class Initialized
DEBUG - 2023-10-17 19:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:55:24 --> Input Class Initialized
INFO - 2023-10-17 19:55:24 --> Language Class Initialized
INFO - 2023-10-17 19:55:24 --> Loader Class Initialized
INFO - 2023-10-17 19:55:24 --> Helper loaded: url_helper
INFO - 2023-10-17 19:55:24 --> Helper loaded: file_helper
INFO - 2023-10-17 19:55:24 --> Database Driver Class Initialized
INFO - 2023-10-17 19:55:24 --> Email Class Initialized
DEBUG - 2023-10-17 19:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:55:24 --> Controller Class Initialized
INFO - 2023-10-17 19:55:24 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:55:24 --> Model "Home_model" initialized
INFO - 2023-10-17 19:55:24 --> Helper loaded: download_helper
INFO - 2023-10-17 19:55:24 --> Helper loaded: form_helper
INFO - 2023-10-17 19:55:24 --> Form Validation Class Initialized
ERROR - 2023-10-17 19:55:24 --> Severity: error --> Exception: Undefined constant "id" C:\xampp\htdocs\dw\application\controllers\HomeController.php 110
INFO - 2023-10-17 19:55:38 --> Config Class Initialized
INFO - 2023-10-17 19:55:38 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:55:38 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:55:38 --> Utf8 Class Initialized
INFO - 2023-10-17 19:55:38 --> URI Class Initialized
INFO - 2023-10-17 19:55:38 --> Router Class Initialized
INFO - 2023-10-17 19:55:38 --> Output Class Initialized
INFO - 2023-10-17 19:55:38 --> Security Class Initialized
DEBUG - 2023-10-17 19:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:55:38 --> Input Class Initialized
INFO - 2023-10-17 19:55:38 --> Language Class Initialized
INFO - 2023-10-17 19:55:38 --> Loader Class Initialized
INFO - 2023-10-17 19:55:38 --> Helper loaded: url_helper
INFO - 2023-10-17 19:55:38 --> Helper loaded: file_helper
INFO - 2023-10-17 19:55:38 --> Database Driver Class Initialized
INFO - 2023-10-17 19:55:38 --> Email Class Initialized
DEBUG - 2023-10-17 19:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:55:38 --> Controller Class Initialized
INFO - 2023-10-17 19:55:38 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:55:38 --> Model "Home_model" initialized
INFO - 2023-10-17 19:55:38 --> Helper loaded: download_helper
INFO - 2023-10-17 19:55:38 --> Helper loaded: form_helper
INFO - 2023-10-17 19:55:38 --> Form Validation Class Initialized
INFO - 2023-10-17 19:56:36 --> Config Class Initialized
INFO - 2023-10-17 19:56:36 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:56:36 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:56:36 --> Utf8 Class Initialized
INFO - 2023-10-17 19:56:36 --> URI Class Initialized
INFO - 2023-10-17 19:56:36 --> Router Class Initialized
INFO - 2023-10-17 19:56:36 --> Output Class Initialized
INFO - 2023-10-17 19:56:36 --> Security Class Initialized
DEBUG - 2023-10-17 19:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:56:36 --> Input Class Initialized
INFO - 2023-10-17 19:56:36 --> Language Class Initialized
INFO - 2023-10-17 19:56:36 --> Loader Class Initialized
INFO - 2023-10-17 19:56:36 --> Helper loaded: url_helper
INFO - 2023-10-17 19:56:36 --> Helper loaded: file_helper
INFO - 2023-10-17 19:56:36 --> Database Driver Class Initialized
INFO - 2023-10-17 19:56:36 --> Email Class Initialized
DEBUG - 2023-10-17 19:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:56:36 --> Controller Class Initialized
INFO - 2023-10-17 19:56:36 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:56:36 --> Model "Home_model" initialized
INFO - 2023-10-17 19:56:36 --> Helper loaded: download_helper
INFO - 2023-10-17 19:56:36 --> Helper loaded: form_helper
INFO - 2023-10-17 19:56:36 --> Form Validation Class Initialized
INFO - 2023-10-17 19:56:36 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:56:36 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:56:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 19:56:36 --> Final output sent to browser
DEBUG - 2023-10-17 19:56:36 --> Total execution time: 0.1152
INFO - 2023-10-17 19:57:57 --> Config Class Initialized
INFO - 2023-10-17 19:57:57 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:57:57 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:57:57 --> Utf8 Class Initialized
INFO - 2023-10-17 19:57:57 --> URI Class Initialized
INFO - 2023-10-17 19:57:57 --> Router Class Initialized
INFO - 2023-10-17 19:57:57 --> Output Class Initialized
INFO - 2023-10-17 19:57:57 --> Security Class Initialized
DEBUG - 2023-10-17 19:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:57:57 --> Input Class Initialized
INFO - 2023-10-17 19:57:57 --> Language Class Initialized
ERROR - 2023-10-17 19:57:57 --> 404 Page Not Found: Service-detail/1
INFO - 2023-10-17 19:58:03 --> Config Class Initialized
INFO - 2023-10-17 19:58:03 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:58:03 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:58:03 --> Utf8 Class Initialized
INFO - 2023-10-17 19:58:03 --> URI Class Initialized
INFO - 2023-10-17 19:58:03 --> Router Class Initialized
INFO - 2023-10-17 19:58:03 --> Output Class Initialized
INFO - 2023-10-17 19:58:03 --> Security Class Initialized
DEBUG - 2023-10-17 19:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:58:03 --> Input Class Initialized
INFO - 2023-10-17 19:58:03 --> Language Class Initialized
INFO - 2023-10-17 19:58:03 --> Loader Class Initialized
INFO - 2023-10-17 19:58:03 --> Helper loaded: url_helper
INFO - 2023-10-17 19:58:03 --> Helper loaded: file_helper
INFO - 2023-10-17 19:58:03 --> Database Driver Class Initialized
INFO - 2023-10-17 19:58:03 --> Email Class Initialized
DEBUG - 2023-10-17 19:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:58:03 --> Controller Class Initialized
INFO - 2023-10-17 19:58:03 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:58:03 --> Model "Home_model" initialized
INFO - 2023-10-17 19:58:03 --> Helper loaded: download_helper
INFO - 2023-10-17 19:58:03 --> Helper loaded: form_helper
INFO - 2023-10-17 19:58:03 --> Form Validation Class Initialized
INFO - 2023-10-17 19:58:03 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:58:03 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:58:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 19:58:03 --> Final output sent to browser
DEBUG - 2023-10-17 19:58:04 --> Total execution time: 0.1353
INFO - 2023-10-17 19:58:28 --> Config Class Initialized
INFO - 2023-10-17 19:58:28 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:58:28 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:58:28 --> Utf8 Class Initialized
INFO - 2023-10-17 19:58:28 --> URI Class Initialized
INFO - 2023-10-17 19:58:28 --> Router Class Initialized
INFO - 2023-10-17 19:58:28 --> Output Class Initialized
INFO - 2023-10-17 19:58:28 --> Security Class Initialized
DEBUG - 2023-10-17 19:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:58:28 --> Input Class Initialized
INFO - 2023-10-17 19:58:28 --> Language Class Initialized
INFO - 2023-10-17 19:58:28 --> Loader Class Initialized
INFO - 2023-10-17 19:58:28 --> Helper loaded: url_helper
INFO - 2023-10-17 19:58:28 --> Helper loaded: file_helper
INFO - 2023-10-17 19:58:28 --> Database Driver Class Initialized
INFO - 2023-10-17 19:58:28 --> Email Class Initialized
DEBUG - 2023-10-17 19:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:58:28 --> Controller Class Initialized
INFO - 2023-10-17 19:58:28 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:58:28 --> Model "Home_model" initialized
INFO - 2023-10-17 19:58:28 --> Helper loaded: download_helper
INFO - 2023-10-17 19:58:28 --> Helper loaded: form_helper
INFO - 2023-10-17 19:58:28 --> Form Validation Class Initialized
INFO - 2023-10-17 19:58:28 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:58:28 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:58:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 19:58:28 --> Final output sent to browser
DEBUG - 2023-10-17 19:58:28 --> Total execution time: 0.1375
INFO - 2023-10-17 19:59:25 --> Config Class Initialized
INFO - 2023-10-17 19:59:25 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:59:25 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:59:25 --> Utf8 Class Initialized
INFO - 2023-10-17 19:59:25 --> URI Class Initialized
INFO - 2023-10-17 19:59:25 --> Router Class Initialized
INFO - 2023-10-17 19:59:25 --> Output Class Initialized
INFO - 2023-10-17 19:59:25 --> Security Class Initialized
DEBUG - 2023-10-17 19:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:59:25 --> Input Class Initialized
INFO - 2023-10-17 19:59:25 --> Language Class Initialized
INFO - 2023-10-17 19:59:25 --> Loader Class Initialized
INFO - 2023-10-17 19:59:25 --> Helper loaded: url_helper
INFO - 2023-10-17 19:59:25 --> Helper loaded: file_helper
INFO - 2023-10-17 19:59:25 --> Database Driver Class Initialized
INFO - 2023-10-17 19:59:25 --> Email Class Initialized
DEBUG - 2023-10-17 19:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:59:25 --> Controller Class Initialized
INFO - 2023-10-17 19:59:25 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:59:25 --> Model "Home_model" initialized
INFO - 2023-10-17 19:59:25 --> Helper loaded: download_helper
INFO - 2023-10-17 19:59:25 --> Helper loaded: form_helper
INFO - 2023-10-17 19:59:25 --> Form Validation Class Initialized
INFO - 2023-10-17 19:59:25 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:59:25 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:59:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-10-17 19:59:25 --> Final output sent to browser
DEBUG - 2023-10-17 19:59:25 --> Total execution time: 0.1512
INFO - 2023-10-17 19:59:30 --> Config Class Initialized
INFO - 2023-10-17 19:59:30 --> Hooks Class Initialized
DEBUG - 2023-10-17 19:59:30 --> UTF-8 Support Enabled
INFO - 2023-10-17 19:59:30 --> Utf8 Class Initialized
INFO - 2023-10-17 19:59:30 --> URI Class Initialized
INFO - 2023-10-17 19:59:30 --> Router Class Initialized
INFO - 2023-10-17 19:59:30 --> Output Class Initialized
INFO - 2023-10-17 19:59:30 --> Security Class Initialized
DEBUG - 2023-10-17 19:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 19:59:30 --> Input Class Initialized
INFO - 2023-10-17 19:59:30 --> Language Class Initialized
INFO - 2023-10-17 19:59:30 --> Loader Class Initialized
INFO - 2023-10-17 19:59:30 --> Helper loaded: url_helper
INFO - 2023-10-17 19:59:30 --> Helper loaded: file_helper
INFO - 2023-10-17 19:59:30 --> Database Driver Class Initialized
INFO - 2023-10-17 19:59:30 --> Email Class Initialized
DEBUG - 2023-10-17 19:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 19:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 19:59:30 --> Controller Class Initialized
INFO - 2023-10-17 19:59:30 --> Model "Contact_model" initialized
INFO - 2023-10-17 19:59:30 --> Model "Home_model" initialized
INFO - 2023-10-17 19:59:31 --> Helper loaded: download_helper
INFO - 2023-10-17 19:59:31 --> Helper loaded: form_helper
INFO - 2023-10-17 19:59:31 --> Form Validation Class Initialized
INFO - 2023-10-17 19:59:31 --> Helper loaded: custom_helper
INFO - 2023-10-17 19:59:31 --> Model "Social_media_model" initialized
INFO - 2023-10-17 19:59:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 19:59:31 --> Final output sent to browser
DEBUG - 2023-10-17 19:59:31 --> Total execution time: 0.0661
INFO - 2023-10-17 20:00:07 --> Config Class Initialized
INFO - 2023-10-17 20:00:07 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:00:07 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:00:07 --> Utf8 Class Initialized
INFO - 2023-10-17 20:00:07 --> URI Class Initialized
INFO - 2023-10-17 20:00:07 --> Router Class Initialized
INFO - 2023-10-17 20:00:07 --> Output Class Initialized
INFO - 2023-10-17 20:00:07 --> Security Class Initialized
DEBUG - 2023-10-17 20:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:00:07 --> Input Class Initialized
INFO - 2023-10-17 20:00:07 --> Language Class Initialized
INFO - 2023-10-17 20:00:07 --> Loader Class Initialized
INFO - 2023-10-17 20:00:07 --> Helper loaded: url_helper
INFO - 2023-10-17 20:00:07 --> Helper loaded: file_helper
INFO - 2023-10-17 20:00:07 --> Database Driver Class Initialized
INFO - 2023-10-17 20:00:07 --> Email Class Initialized
DEBUG - 2023-10-17 20:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:00:07 --> Controller Class Initialized
INFO - 2023-10-17 20:00:07 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:00:07 --> Model "Home_model" initialized
INFO - 2023-10-17 20:00:07 --> Helper loaded: download_helper
INFO - 2023-10-17 20:00:07 --> Helper loaded: form_helper
INFO - 2023-10-17 20:00:07 --> Form Validation Class Initialized
INFO - 2023-10-17 20:00:07 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:00:07 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:00:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:00:08 --> Final output sent to browser
DEBUG - 2023-10-17 20:00:08 --> Total execution time: 1.1524
INFO - 2023-10-17 20:00:17 --> Config Class Initialized
INFO - 2023-10-17 20:00:17 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:00:17 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:00:17 --> Utf8 Class Initialized
INFO - 2023-10-17 20:00:17 --> URI Class Initialized
INFO - 2023-10-17 20:00:17 --> Router Class Initialized
INFO - 2023-10-17 20:00:17 --> Output Class Initialized
INFO - 2023-10-17 20:00:17 --> Security Class Initialized
DEBUG - 2023-10-17 20:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:00:17 --> Input Class Initialized
INFO - 2023-10-17 20:00:17 --> Language Class Initialized
INFO - 2023-10-17 20:00:17 --> Loader Class Initialized
INFO - 2023-10-17 20:00:17 --> Helper loaded: url_helper
INFO - 2023-10-17 20:00:17 --> Helper loaded: file_helper
INFO - 2023-10-17 20:00:17 --> Database Driver Class Initialized
INFO - 2023-10-17 20:00:17 --> Email Class Initialized
DEBUG - 2023-10-17 20:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:00:17 --> Controller Class Initialized
INFO - 2023-10-17 20:00:17 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:00:17 --> Model "Home_model" initialized
INFO - 2023-10-17 20:00:17 --> Helper loaded: download_helper
INFO - 2023-10-17 20:00:17 --> Helper loaded: form_helper
INFO - 2023-10-17 20:00:17 --> Form Validation Class Initialized
INFO - 2023-10-17 20:00:17 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:00:17 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:00:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:00:17 --> Final output sent to browser
DEBUG - 2023-10-17 20:00:17 --> Total execution time: 0.0650
INFO - 2023-10-17 20:00:24 --> Config Class Initialized
INFO - 2023-10-17 20:00:24 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:00:24 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:00:24 --> Utf8 Class Initialized
INFO - 2023-10-17 20:00:24 --> URI Class Initialized
INFO - 2023-10-17 20:00:24 --> Router Class Initialized
INFO - 2023-10-17 20:00:24 --> Output Class Initialized
INFO - 2023-10-17 20:00:24 --> Security Class Initialized
DEBUG - 2023-10-17 20:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:00:24 --> Input Class Initialized
INFO - 2023-10-17 20:00:24 --> Language Class Initialized
INFO - 2023-10-17 20:00:24 --> Loader Class Initialized
INFO - 2023-10-17 20:00:24 --> Helper loaded: url_helper
INFO - 2023-10-17 20:00:24 --> Helper loaded: file_helper
INFO - 2023-10-17 20:00:24 --> Database Driver Class Initialized
INFO - 2023-10-17 20:00:24 --> Email Class Initialized
DEBUG - 2023-10-17 20:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:00:24 --> Controller Class Initialized
INFO - 2023-10-17 20:00:24 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:00:24 --> Model "Home_model" initialized
INFO - 2023-10-17 20:00:24 --> Helper loaded: download_helper
INFO - 2023-10-17 20:00:24 --> Helper loaded: form_helper
INFO - 2023-10-17 20:00:24 --> Form Validation Class Initialized
INFO - 2023-10-17 20:00:24 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:00:24 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:00:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:00:24 --> Final output sent to browser
DEBUG - 2023-10-17 20:00:24 --> Total execution time: 0.0727
INFO - 2023-10-17 20:01:37 --> Config Class Initialized
INFO - 2023-10-17 20:01:37 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:01:37 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:01:37 --> Utf8 Class Initialized
INFO - 2023-10-17 20:01:37 --> URI Class Initialized
INFO - 2023-10-17 20:01:37 --> Router Class Initialized
INFO - 2023-10-17 20:01:37 --> Output Class Initialized
INFO - 2023-10-17 20:01:37 --> Security Class Initialized
DEBUG - 2023-10-17 20:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:01:37 --> Input Class Initialized
INFO - 2023-10-17 20:01:37 --> Language Class Initialized
INFO - 2023-10-17 20:01:37 --> Loader Class Initialized
INFO - 2023-10-17 20:01:37 --> Helper loaded: url_helper
INFO - 2023-10-17 20:01:37 --> Helper loaded: file_helper
INFO - 2023-10-17 20:01:37 --> Database Driver Class Initialized
INFO - 2023-10-17 20:01:37 --> Email Class Initialized
DEBUG - 2023-10-17 20:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:01:37 --> Controller Class Initialized
INFO - 2023-10-17 20:01:37 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:01:37 --> Model "Home_model" initialized
INFO - 2023-10-17 20:01:37 --> Helper loaded: download_helper
INFO - 2023-10-17 20:01:37 --> Helper loaded: form_helper
INFO - 2023-10-17 20:01:37 --> Form Validation Class Initialized
INFO - 2023-10-17 20:01:37 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:01:37 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:01:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:01:37 --> Final output sent to browser
DEBUG - 2023-10-17 20:01:37 --> Total execution time: 0.2151
INFO - 2023-10-17 20:01:48 --> Config Class Initialized
INFO - 2023-10-17 20:01:48 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:01:48 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:01:48 --> Utf8 Class Initialized
INFO - 2023-10-17 20:01:48 --> URI Class Initialized
INFO - 2023-10-17 20:01:48 --> Router Class Initialized
INFO - 2023-10-17 20:01:48 --> Output Class Initialized
INFO - 2023-10-17 20:01:48 --> Security Class Initialized
DEBUG - 2023-10-17 20:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:01:48 --> Input Class Initialized
INFO - 2023-10-17 20:01:48 --> Language Class Initialized
INFO - 2023-10-17 20:01:48 --> Loader Class Initialized
INFO - 2023-10-17 20:01:48 --> Helper loaded: url_helper
INFO - 2023-10-17 20:01:48 --> Helper loaded: file_helper
INFO - 2023-10-17 20:01:48 --> Database Driver Class Initialized
INFO - 2023-10-17 20:01:48 --> Email Class Initialized
DEBUG - 2023-10-17 20:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:01:48 --> Controller Class Initialized
INFO - 2023-10-17 20:01:48 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:01:48 --> Model "Home_model" initialized
INFO - 2023-10-17 20:01:48 --> Helper loaded: download_helper
INFO - 2023-10-17 20:01:48 --> Helper loaded: form_helper
INFO - 2023-10-17 20:01:48 --> Form Validation Class Initialized
INFO - 2023-10-17 20:01:48 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:01:48 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:01:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:01:48 --> Final output sent to browser
DEBUG - 2023-10-17 20:01:48 --> Total execution time: 0.1301
INFO - 2023-10-17 20:01:53 --> Config Class Initialized
INFO - 2023-10-17 20:01:53 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:01:53 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:01:53 --> Utf8 Class Initialized
INFO - 2023-10-17 20:01:53 --> URI Class Initialized
INFO - 2023-10-17 20:01:53 --> Router Class Initialized
INFO - 2023-10-17 20:01:53 --> Output Class Initialized
INFO - 2023-10-17 20:01:53 --> Security Class Initialized
DEBUG - 2023-10-17 20:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:01:53 --> Input Class Initialized
INFO - 2023-10-17 20:01:53 --> Language Class Initialized
INFO - 2023-10-17 20:01:53 --> Loader Class Initialized
INFO - 2023-10-17 20:01:53 --> Helper loaded: url_helper
INFO - 2023-10-17 20:01:53 --> Helper loaded: file_helper
INFO - 2023-10-17 20:01:53 --> Database Driver Class Initialized
INFO - 2023-10-17 20:01:53 --> Email Class Initialized
DEBUG - 2023-10-17 20:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:01:53 --> Controller Class Initialized
INFO - 2023-10-17 20:01:53 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:01:53 --> Model "Home_model" initialized
INFO - 2023-10-17 20:01:53 --> Helper loaded: download_helper
INFO - 2023-10-17 20:01:53 --> Helper loaded: form_helper
INFO - 2023-10-17 20:01:53 --> Form Validation Class Initialized
INFO - 2023-10-17 20:01:53 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:01:53 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:01:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:01:53 --> Final output sent to browser
DEBUG - 2023-10-17 20:01:53 --> Total execution time: 0.1138
INFO - 2023-10-17 20:02:00 --> Config Class Initialized
INFO - 2023-10-17 20:02:00 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:02:00 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:02:00 --> Utf8 Class Initialized
INFO - 2023-10-17 20:02:00 --> URI Class Initialized
DEBUG - 2023-10-17 20:02:00 --> No URI present. Default controller set.
INFO - 2023-10-17 20:02:00 --> Router Class Initialized
INFO - 2023-10-17 20:02:00 --> Output Class Initialized
INFO - 2023-10-17 20:02:00 --> Security Class Initialized
DEBUG - 2023-10-17 20:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:02:00 --> Input Class Initialized
INFO - 2023-10-17 20:02:00 --> Language Class Initialized
INFO - 2023-10-17 20:02:00 --> Loader Class Initialized
INFO - 2023-10-17 20:02:00 --> Helper loaded: url_helper
INFO - 2023-10-17 20:02:00 --> Helper loaded: file_helper
INFO - 2023-10-17 20:02:00 --> Database Driver Class Initialized
INFO - 2023-10-17 20:02:00 --> Email Class Initialized
DEBUG - 2023-10-17 20:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:02:00 --> Controller Class Initialized
INFO - 2023-10-17 20:02:00 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:02:00 --> Model "Home_model" initialized
INFO - 2023-10-17 20:02:00 --> Helper loaded: download_helper
INFO - 2023-10-17 20:02:00 --> Helper loaded: form_helper
INFO - 2023-10-17 20:02:00 --> Form Validation Class Initialized
INFO - 2023-10-17 20:02:01 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:02:01 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:02:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 20:02:01 --> Final output sent to browser
DEBUG - 2023-10-17 20:02:01 --> Total execution time: 0.2234
INFO - 2023-10-17 20:02:32 --> Config Class Initialized
INFO - 2023-10-17 20:02:32 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:02:32 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:02:32 --> Utf8 Class Initialized
INFO - 2023-10-17 20:02:32 --> URI Class Initialized
INFO - 2023-10-17 20:02:32 --> Router Class Initialized
INFO - 2023-10-17 20:02:32 --> Output Class Initialized
INFO - 2023-10-17 20:02:32 --> Security Class Initialized
DEBUG - 2023-10-17 20:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:02:32 --> Input Class Initialized
INFO - 2023-10-17 20:02:32 --> Language Class Initialized
INFO - 2023-10-17 20:02:32 --> Loader Class Initialized
INFO - 2023-10-17 20:02:32 --> Helper loaded: url_helper
INFO - 2023-10-17 20:02:32 --> Helper loaded: file_helper
INFO - 2023-10-17 20:02:32 --> Database Driver Class Initialized
INFO - 2023-10-17 20:02:32 --> Email Class Initialized
DEBUG - 2023-10-17 20:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:02:32 --> Controller Class Initialized
INFO - 2023-10-17 20:02:32 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:02:32 --> Model "Home_model" initialized
INFO - 2023-10-17 20:02:32 --> Helper loaded: download_helper
INFO - 2023-10-17 20:02:32 --> Helper loaded: form_helper
INFO - 2023-10-17 20:02:32 --> Form Validation Class Initialized
INFO - 2023-10-17 20:02:32 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:02:32 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:02:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:02:32 --> Final output sent to browser
DEBUG - 2023-10-17 20:02:33 --> Total execution time: 0.5666
INFO - 2023-10-17 20:02:36 --> Config Class Initialized
INFO - 2023-10-17 20:02:36 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:02:36 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:02:36 --> Utf8 Class Initialized
INFO - 2023-10-17 20:02:36 --> URI Class Initialized
INFO - 2023-10-17 20:02:36 --> Router Class Initialized
INFO - 2023-10-17 20:02:36 --> Output Class Initialized
INFO - 2023-10-17 20:02:36 --> Security Class Initialized
DEBUG - 2023-10-17 20:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:02:36 --> Input Class Initialized
INFO - 2023-10-17 20:02:36 --> Language Class Initialized
INFO - 2023-10-17 20:02:36 --> Loader Class Initialized
INFO - 2023-10-17 20:02:36 --> Helper loaded: url_helper
INFO - 2023-10-17 20:02:36 --> Helper loaded: file_helper
INFO - 2023-10-17 20:02:36 --> Database Driver Class Initialized
INFO - 2023-10-17 20:02:36 --> Email Class Initialized
DEBUG - 2023-10-17 20:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:02:36 --> Controller Class Initialized
INFO - 2023-10-17 20:02:36 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:02:36 --> Model "Home_model" initialized
INFO - 2023-10-17 20:02:36 --> Helper loaded: download_helper
INFO - 2023-10-17 20:02:36 --> Helper loaded: form_helper
INFO - 2023-10-17 20:02:36 --> Form Validation Class Initialized
INFO - 2023-10-17 20:02:36 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:02:36 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:02:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:02:36 --> Final output sent to browser
DEBUG - 2023-10-17 20:02:36 --> Total execution time: 0.1596
INFO - 2023-10-17 20:02:58 --> Config Class Initialized
INFO - 2023-10-17 20:02:58 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:02:58 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:02:58 --> Utf8 Class Initialized
INFO - 2023-10-17 20:02:58 --> URI Class Initialized
DEBUG - 2023-10-17 20:02:58 --> No URI present. Default controller set.
INFO - 2023-10-17 20:02:58 --> Router Class Initialized
INFO - 2023-10-17 20:02:58 --> Output Class Initialized
INFO - 2023-10-17 20:02:58 --> Security Class Initialized
DEBUG - 2023-10-17 20:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:02:58 --> Input Class Initialized
INFO - 2023-10-17 20:02:58 --> Language Class Initialized
INFO - 2023-10-17 20:02:58 --> Loader Class Initialized
INFO - 2023-10-17 20:02:58 --> Helper loaded: url_helper
INFO - 2023-10-17 20:02:58 --> Helper loaded: file_helper
INFO - 2023-10-17 20:02:58 --> Database Driver Class Initialized
INFO - 2023-10-17 20:02:58 --> Email Class Initialized
DEBUG - 2023-10-17 20:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:02:58 --> Controller Class Initialized
INFO - 2023-10-17 20:02:58 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:02:58 --> Model "Home_model" initialized
INFO - 2023-10-17 20:02:58 --> Helper loaded: download_helper
INFO - 2023-10-17 20:02:58 --> Helper loaded: form_helper
INFO - 2023-10-17 20:02:58 --> Form Validation Class Initialized
INFO - 2023-10-17 20:02:58 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:02:58 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:02:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 20:02:59 --> Final output sent to browser
DEBUG - 2023-10-17 20:02:59 --> Total execution time: 0.1223
INFO - 2023-10-17 20:03:52 --> Config Class Initialized
INFO - 2023-10-17 20:03:52 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:03:52 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:03:52 --> Utf8 Class Initialized
INFO - 2023-10-17 20:03:52 --> URI Class Initialized
DEBUG - 2023-10-17 20:03:52 --> No URI present. Default controller set.
INFO - 2023-10-17 20:03:52 --> Router Class Initialized
INFO - 2023-10-17 20:03:52 --> Output Class Initialized
INFO - 2023-10-17 20:03:52 --> Security Class Initialized
DEBUG - 2023-10-17 20:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:03:52 --> Input Class Initialized
INFO - 2023-10-17 20:03:52 --> Language Class Initialized
INFO - 2023-10-17 20:03:52 --> Loader Class Initialized
INFO - 2023-10-17 20:03:52 --> Helper loaded: url_helper
INFO - 2023-10-17 20:03:52 --> Helper loaded: file_helper
INFO - 2023-10-17 20:03:52 --> Database Driver Class Initialized
INFO - 2023-10-17 20:03:52 --> Email Class Initialized
DEBUG - 2023-10-17 20:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:03:52 --> Controller Class Initialized
INFO - 2023-10-17 20:03:52 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:03:52 --> Model "Home_model" initialized
INFO - 2023-10-17 20:03:52 --> Helper loaded: download_helper
INFO - 2023-10-17 20:03:52 --> Helper loaded: form_helper
INFO - 2023-10-17 20:03:52 --> Form Validation Class Initialized
INFO - 2023-10-17 20:03:52 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:03:52 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:03:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 20:03:52 --> Final output sent to browser
DEBUG - 2023-10-17 20:03:53 --> Total execution time: 0.1583
INFO - 2023-10-17 20:05:05 --> Config Class Initialized
INFO - 2023-10-17 20:05:05 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:05:05 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:05:05 --> Utf8 Class Initialized
INFO - 2023-10-17 20:05:05 --> URI Class Initialized
INFO - 2023-10-17 20:05:05 --> Router Class Initialized
INFO - 2023-10-17 20:05:05 --> Output Class Initialized
INFO - 2023-10-17 20:05:05 --> Security Class Initialized
DEBUG - 2023-10-17 20:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:05:05 --> Input Class Initialized
INFO - 2023-10-17 20:05:05 --> Language Class Initialized
INFO - 2023-10-17 20:05:05 --> Loader Class Initialized
INFO - 2023-10-17 20:05:05 --> Helper loaded: url_helper
INFO - 2023-10-17 20:05:05 --> Helper loaded: file_helper
INFO - 2023-10-17 20:05:05 --> Database Driver Class Initialized
INFO - 2023-10-17 20:05:06 --> Email Class Initialized
DEBUG - 2023-10-17 20:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:05:06 --> Controller Class Initialized
INFO - 2023-10-17 20:05:06 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:05:06 --> Model "Home_model" initialized
INFO - 2023-10-17 20:05:06 --> Helper loaded: download_helper
INFO - 2023-10-17 20:05:06 --> Helper loaded: form_helper
INFO - 2023-10-17 20:05:06 --> Form Validation Class Initialized
INFO - 2023-10-17 20:05:06 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:05:06 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:05:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:05:06 --> Final output sent to browser
DEBUG - 2023-10-17 20:05:06 --> Total execution time: 0.1524
INFO - 2023-10-17 20:06:21 --> Config Class Initialized
INFO - 2023-10-17 20:06:21 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:06:21 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:06:21 --> Utf8 Class Initialized
INFO - 2023-10-17 20:06:21 --> URI Class Initialized
INFO - 2023-10-17 20:06:21 --> Router Class Initialized
INFO - 2023-10-17 20:06:21 --> Output Class Initialized
INFO - 2023-10-17 20:06:21 --> Security Class Initialized
DEBUG - 2023-10-17 20:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:06:21 --> Input Class Initialized
INFO - 2023-10-17 20:06:21 --> Language Class Initialized
INFO - 2023-10-17 20:06:21 --> Loader Class Initialized
INFO - 2023-10-17 20:06:21 --> Helper loaded: url_helper
INFO - 2023-10-17 20:06:21 --> Helper loaded: file_helper
INFO - 2023-10-17 20:06:21 --> Database Driver Class Initialized
INFO - 2023-10-17 20:06:21 --> Email Class Initialized
DEBUG - 2023-10-17 20:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:06:21 --> Controller Class Initialized
INFO - 2023-10-17 20:06:21 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:06:21 --> Model "Home_model" initialized
INFO - 2023-10-17 20:06:21 --> Helper loaded: download_helper
INFO - 2023-10-17 20:06:21 --> Helper loaded: form_helper
INFO - 2023-10-17 20:06:21 --> Form Validation Class Initialized
INFO - 2023-10-17 20:06:21 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:06:21 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:06:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:06:21 --> Final output sent to browser
DEBUG - 2023-10-17 20:06:21 --> Total execution time: 0.1492
INFO - 2023-10-17 20:07:08 --> Config Class Initialized
INFO - 2023-10-17 20:07:08 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:07:08 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:07:08 --> Utf8 Class Initialized
INFO - 2023-10-17 20:07:08 --> URI Class Initialized
INFO - 2023-10-17 20:07:08 --> Router Class Initialized
INFO - 2023-10-17 20:07:08 --> Output Class Initialized
INFO - 2023-10-17 20:07:08 --> Security Class Initialized
DEBUG - 2023-10-17 20:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:07:08 --> Input Class Initialized
INFO - 2023-10-17 20:07:08 --> Language Class Initialized
INFO - 2023-10-17 20:07:08 --> Loader Class Initialized
INFO - 2023-10-17 20:07:08 --> Helper loaded: url_helper
INFO - 2023-10-17 20:07:08 --> Helper loaded: file_helper
INFO - 2023-10-17 20:07:08 --> Database Driver Class Initialized
INFO - 2023-10-17 20:07:08 --> Email Class Initialized
DEBUG - 2023-10-17 20:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:07:08 --> Controller Class Initialized
INFO - 2023-10-17 20:07:08 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:07:08 --> Model "Home_model" initialized
INFO - 2023-10-17 20:07:08 --> Helper loaded: download_helper
INFO - 2023-10-17 20:07:08 --> Helper loaded: form_helper
INFO - 2023-10-17 20:07:08 --> Form Validation Class Initialized
INFO - 2023-10-17 20:07:08 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:07:08 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:07:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:07:08 --> Final output sent to browser
DEBUG - 2023-10-17 20:07:09 --> Total execution time: 0.1794
INFO - 2023-10-17 20:07:28 --> Config Class Initialized
INFO - 2023-10-17 20:07:28 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:07:28 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:07:28 --> Utf8 Class Initialized
INFO - 2023-10-17 20:07:28 --> URI Class Initialized
INFO - 2023-10-17 20:07:28 --> Router Class Initialized
INFO - 2023-10-17 20:07:28 --> Output Class Initialized
INFO - 2023-10-17 20:07:28 --> Security Class Initialized
DEBUG - 2023-10-17 20:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:07:28 --> Input Class Initialized
INFO - 2023-10-17 20:07:28 --> Language Class Initialized
INFO - 2023-10-17 20:07:28 --> Loader Class Initialized
INFO - 2023-10-17 20:07:28 --> Helper loaded: url_helper
INFO - 2023-10-17 20:07:28 --> Helper loaded: file_helper
INFO - 2023-10-17 20:07:28 --> Database Driver Class Initialized
INFO - 2023-10-17 20:07:28 --> Email Class Initialized
DEBUG - 2023-10-17 20:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:07:28 --> Controller Class Initialized
INFO - 2023-10-17 20:07:28 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:07:28 --> Model "Home_model" initialized
INFO - 2023-10-17 20:07:28 --> Helper loaded: download_helper
INFO - 2023-10-17 20:07:28 --> Helper loaded: form_helper
INFO - 2023-10-17 20:07:28 --> Form Validation Class Initialized
INFO - 2023-10-17 20:07:28 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:07:28 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:07:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:07:28 --> Final output sent to browser
DEBUG - 2023-10-17 20:07:28 --> Total execution time: 0.1772
INFO - 2023-10-17 20:07:53 --> Config Class Initialized
INFO - 2023-10-17 20:07:53 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:07:53 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:07:53 --> Utf8 Class Initialized
INFO - 2023-10-17 20:07:53 --> URI Class Initialized
INFO - 2023-10-17 20:07:53 --> Router Class Initialized
INFO - 2023-10-17 20:07:53 --> Output Class Initialized
INFO - 2023-10-17 20:07:53 --> Security Class Initialized
DEBUG - 2023-10-17 20:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:07:53 --> Input Class Initialized
INFO - 2023-10-17 20:07:53 --> Language Class Initialized
INFO - 2023-10-17 20:07:53 --> Loader Class Initialized
INFO - 2023-10-17 20:07:53 --> Helper loaded: url_helper
INFO - 2023-10-17 20:07:53 --> Helper loaded: file_helper
INFO - 2023-10-17 20:07:53 --> Database Driver Class Initialized
INFO - 2023-10-17 20:07:53 --> Email Class Initialized
DEBUG - 2023-10-17 20:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:07:53 --> Controller Class Initialized
INFO - 2023-10-17 20:07:53 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:07:53 --> Model "Home_model" initialized
INFO - 2023-10-17 20:07:53 --> Helper loaded: download_helper
INFO - 2023-10-17 20:07:53 --> Helper loaded: form_helper
INFO - 2023-10-17 20:07:53 --> Form Validation Class Initialized
INFO - 2023-10-17 20:07:53 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:07:53 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:07:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:07:53 --> Final output sent to browser
DEBUG - 2023-10-17 20:07:53 --> Total execution time: 0.1529
INFO - 2023-10-17 20:08:14 --> Config Class Initialized
INFO - 2023-10-17 20:08:14 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:08:14 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:08:14 --> Utf8 Class Initialized
INFO - 2023-10-17 20:08:14 --> URI Class Initialized
DEBUG - 2023-10-17 20:08:14 --> No URI present. Default controller set.
INFO - 2023-10-17 20:08:14 --> Router Class Initialized
INFO - 2023-10-17 20:08:14 --> Output Class Initialized
INFO - 2023-10-17 20:08:14 --> Security Class Initialized
DEBUG - 2023-10-17 20:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:08:14 --> Input Class Initialized
INFO - 2023-10-17 20:08:14 --> Language Class Initialized
INFO - 2023-10-17 20:08:14 --> Loader Class Initialized
INFO - 2023-10-17 20:08:14 --> Helper loaded: url_helper
INFO - 2023-10-17 20:08:14 --> Helper loaded: file_helper
INFO - 2023-10-17 20:08:14 --> Database Driver Class Initialized
INFO - 2023-10-17 20:08:14 --> Email Class Initialized
DEBUG - 2023-10-17 20:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:08:14 --> Controller Class Initialized
INFO - 2023-10-17 20:08:14 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:08:14 --> Model "Home_model" initialized
INFO - 2023-10-17 20:08:14 --> Helper loaded: download_helper
INFO - 2023-10-17 20:08:14 --> Helper loaded: form_helper
INFO - 2023-10-17 20:08:14 --> Form Validation Class Initialized
INFO - 2023-10-17 20:08:14 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:08:14 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:08:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 20:08:14 --> Final output sent to browser
DEBUG - 2023-10-17 20:08:14 --> Total execution time: 0.1945
INFO - 2023-10-17 20:08:23 --> Config Class Initialized
INFO - 2023-10-17 20:08:23 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:08:23 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:08:23 --> Utf8 Class Initialized
INFO - 2023-10-17 20:08:23 --> URI Class Initialized
INFO - 2023-10-17 20:08:23 --> Router Class Initialized
INFO - 2023-10-17 20:08:23 --> Output Class Initialized
INFO - 2023-10-17 20:08:23 --> Security Class Initialized
DEBUG - 2023-10-17 20:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:08:23 --> Input Class Initialized
INFO - 2023-10-17 20:08:23 --> Language Class Initialized
INFO - 2023-10-17 20:08:23 --> Loader Class Initialized
INFO - 2023-10-17 20:08:23 --> Helper loaded: url_helper
INFO - 2023-10-17 20:08:23 --> Helper loaded: file_helper
INFO - 2023-10-17 20:08:23 --> Database Driver Class Initialized
INFO - 2023-10-17 20:08:23 --> Email Class Initialized
DEBUG - 2023-10-17 20:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:08:23 --> Controller Class Initialized
INFO - 2023-10-17 20:08:23 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:08:23 --> Model "Home_model" initialized
INFO - 2023-10-17 20:08:23 --> Helper loaded: download_helper
INFO - 2023-10-17 20:08:23 --> Helper loaded: form_helper
INFO - 2023-10-17 20:08:23 --> Form Validation Class Initialized
INFO - 2023-10-17 20:08:23 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:08:23 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:08:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:08:23 --> Final output sent to browser
DEBUG - 2023-10-17 20:08:23 --> Total execution time: 0.0711
INFO - 2023-10-17 20:08:26 --> Config Class Initialized
INFO - 2023-10-17 20:08:26 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:08:26 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:08:26 --> Utf8 Class Initialized
INFO - 2023-10-17 20:08:26 --> URI Class Initialized
DEBUG - 2023-10-17 20:08:26 --> No URI present. Default controller set.
INFO - 2023-10-17 20:08:26 --> Router Class Initialized
INFO - 2023-10-17 20:08:26 --> Output Class Initialized
INFO - 2023-10-17 20:08:26 --> Security Class Initialized
DEBUG - 2023-10-17 20:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:08:26 --> Input Class Initialized
INFO - 2023-10-17 20:08:26 --> Language Class Initialized
INFO - 2023-10-17 20:08:26 --> Loader Class Initialized
INFO - 2023-10-17 20:08:26 --> Helper loaded: url_helper
INFO - 2023-10-17 20:08:26 --> Helper loaded: file_helper
INFO - 2023-10-17 20:08:26 --> Database Driver Class Initialized
INFO - 2023-10-17 20:08:26 --> Email Class Initialized
DEBUG - 2023-10-17 20:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:08:26 --> Controller Class Initialized
INFO - 2023-10-17 20:08:26 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:08:26 --> Model "Home_model" initialized
INFO - 2023-10-17 20:08:26 --> Helper loaded: download_helper
INFO - 2023-10-17 20:08:26 --> Helper loaded: form_helper
INFO - 2023-10-17 20:08:26 --> Form Validation Class Initialized
INFO - 2023-10-17 20:08:26 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:08:26 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:08:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 20:08:26 --> Final output sent to browser
DEBUG - 2023-10-17 20:08:26 --> Total execution time: 0.0797
INFO - 2023-10-17 20:08:32 --> Config Class Initialized
INFO - 2023-10-17 20:08:32 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:08:32 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:08:32 --> Utf8 Class Initialized
INFO - 2023-10-17 20:08:32 --> URI Class Initialized
INFO - 2023-10-17 20:08:32 --> Router Class Initialized
INFO - 2023-10-17 20:08:32 --> Output Class Initialized
INFO - 2023-10-17 20:08:32 --> Security Class Initialized
DEBUG - 2023-10-17 20:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:08:32 --> Input Class Initialized
INFO - 2023-10-17 20:08:32 --> Language Class Initialized
INFO - 2023-10-17 20:08:32 --> Loader Class Initialized
INFO - 2023-10-17 20:08:32 --> Helper loaded: url_helper
INFO - 2023-10-17 20:08:32 --> Helper loaded: file_helper
INFO - 2023-10-17 20:08:32 --> Database Driver Class Initialized
INFO - 2023-10-17 20:08:32 --> Email Class Initialized
DEBUG - 2023-10-17 20:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:08:32 --> Controller Class Initialized
INFO - 2023-10-17 20:08:32 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:08:32 --> Model "Home_model" initialized
INFO - 2023-10-17 20:08:32 --> Helper loaded: download_helper
INFO - 2023-10-17 20:08:32 --> Helper loaded: form_helper
INFO - 2023-10-17 20:08:32 --> Form Validation Class Initialized
INFO - 2023-10-17 20:08:32 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:08:32 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:08:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:08:32 --> Final output sent to browser
DEBUG - 2023-10-17 20:08:32 --> Total execution time: 0.0638
INFO - 2023-10-17 20:08:34 --> Config Class Initialized
INFO - 2023-10-17 20:08:34 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:08:34 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:08:34 --> Utf8 Class Initialized
INFO - 2023-10-17 20:08:34 --> URI Class Initialized
DEBUG - 2023-10-17 20:08:34 --> No URI present. Default controller set.
INFO - 2023-10-17 20:08:34 --> Router Class Initialized
INFO - 2023-10-17 20:08:34 --> Output Class Initialized
INFO - 2023-10-17 20:08:34 --> Security Class Initialized
DEBUG - 2023-10-17 20:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:08:34 --> Input Class Initialized
INFO - 2023-10-17 20:08:34 --> Language Class Initialized
INFO - 2023-10-17 20:08:34 --> Loader Class Initialized
INFO - 2023-10-17 20:08:34 --> Helper loaded: url_helper
INFO - 2023-10-17 20:08:34 --> Helper loaded: file_helper
INFO - 2023-10-17 20:08:34 --> Database Driver Class Initialized
INFO - 2023-10-17 20:08:34 --> Email Class Initialized
DEBUG - 2023-10-17 20:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:08:34 --> Controller Class Initialized
INFO - 2023-10-17 20:08:34 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:08:34 --> Model "Home_model" initialized
INFO - 2023-10-17 20:08:34 --> Helper loaded: download_helper
INFO - 2023-10-17 20:08:34 --> Helper loaded: form_helper
INFO - 2023-10-17 20:08:34 --> Form Validation Class Initialized
INFO - 2023-10-17 20:08:34 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:08:34 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:08:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 20:08:34 --> Final output sent to browser
DEBUG - 2023-10-17 20:08:34 --> Total execution time: 0.0688
INFO - 2023-10-17 20:08:43 --> Config Class Initialized
INFO - 2023-10-17 20:08:43 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:08:43 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:08:43 --> Utf8 Class Initialized
INFO - 2023-10-17 20:08:43 --> URI Class Initialized
INFO - 2023-10-17 20:08:43 --> Router Class Initialized
INFO - 2023-10-17 20:08:43 --> Output Class Initialized
INFO - 2023-10-17 20:08:43 --> Security Class Initialized
DEBUG - 2023-10-17 20:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:08:43 --> Input Class Initialized
INFO - 2023-10-17 20:08:43 --> Language Class Initialized
INFO - 2023-10-17 20:08:43 --> Loader Class Initialized
INFO - 2023-10-17 20:08:43 --> Helper loaded: url_helper
INFO - 2023-10-17 20:08:43 --> Helper loaded: file_helper
INFO - 2023-10-17 20:08:43 --> Database Driver Class Initialized
INFO - 2023-10-17 20:08:43 --> Email Class Initialized
DEBUG - 2023-10-17 20:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:08:43 --> Controller Class Initialized
INFO - 2023-10-17 20:08:43 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:08:43 --> Model "Home_model" initialized
INFO - 2023-10-17 20:08:43 --> Helper loaded: download_helper
INFO - 2023-10-17 20:08:43 --> Helper loaded: form_helper
INFO - 2023-10-17 20:08:43 --> Form Validation Class Initialized
INFO - 2023-10-17 20:08:43 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:08:43 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:08:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:08:43 --> Final output sent to browser
DEBUG - 2023-10-17 20:08:43 --> Total execution time: 0.1435
INFO - 2023-10-17 20:08:48 --> Config Class Initialized
INFO - 2023-10-17 20:08:48 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:08:48 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:08:48 --> Utf8 Class Initialized
INFO - 2023-10-17 20:08:48 --> URI Class Initialized
DEBUG - 2023-10-17 20:08:48 --> No URI present. Default controller set.
INFO - 2023-10-17 20:08:48 --> Router Class Initialized
INFO - 2023-10-17 20:08:48 --> Output Class Initialized
INFO - 2023-10-17 20:08:48 --> Security Class Initialized
DEBUG - 2023-10-17 20:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:08:48 --> Input Class Initialized
INFO - 2023-10-17 20:08:48 --> Language Class Initialized
INFO - 2023-10-17 20:08:48 --> Loader Class Initialized
INFO - 2023-10-17 20:08:48 --> Helper loaded: url_helper
INFO - 2023-10-17 20:08:48 --> Helper loaded: file_helper
INFO - 2023-10-17 20:08:49 --> Database Driver Class Initialized
INFO - 2023-10-17 20:08:49 --> Email Class Initialized
DEBUG - 2023-10-17 20:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:08:49 --> Controller Class Initialized
INFO - 2023-10-17 20:08:49 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:08:49 --> Model "Home_model" initialized
INFO - 2023-10-17 20:08:49 --> Helper loaded: download_helper
INFO - 2023-10-17 20:08:49 --> Helper loaded: form_helper
INFO - 2023-10-17 20:08:49 --> Form Validation Class Initialized
INFO - 2023-10-17 20:08:49 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:08:49 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:08:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-17 20:08:49 --> Final output sent to browser
DEBUG - 2023-10-17 20:08:50 --> Total execution time: 2.2179
INFO - 2023-10-17 20:08:53 --> Config Class Initialized
INFO - 2023-10-17 20:08:53 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:08:53 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:08:53 --> Utf8 Class Initialized
INFO - 2023-10-17 20:08:53 --> URI Class Initialized
INFO - 2023-10-17 20:08:53 --> Router Class Initialized
INFO - 2023-10-17 20:08:53 --> Output Class Initialized
INFO - 2023-10-17 20:08:53 --> Security Class Initialized
DEBUG - 2023-10-17 20:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:08:53 --> Input Class Initialized
INFO - 2023-10-17 20:08:53 --> Language Class Initialized
INFO - 2023-10-17 20:08:53 --> Loader Class Initialized
INFO - 2023-10-17 20:08:53 --> Helper loaded: url_helper
INFO - 2023-10-17 20:08:53 --> Helper loaded: file_helper
INFO - 2023-10-17 20:08:53 --> Database Driver Class Initialized
INFO - 2023-10-17 20:08:53 --> Email Class Initialized
DEBUG - 2023-10-17 20:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:08:53 --> Controller Class Initialized
INFO - 2023-10-17 20:08:53 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:08:53 --> Model "Home_model" initialized
INFO - 2023-10-17 20:08:53 --> Helper loaded: download_helper
INFO - 2023-10-17 20:08:53 --> Helper loaded: form_helper
INFO - 2023-10-17 20:08:53 --> Form Validation Class Initialized
INFO - 2023-10-17 20:08:53 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:08:53 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:08:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:08:53 --> Final output sent to browser
DEBUG - 2023-10-17 20:08:53 --> Total execution time: 0.1100
INFO - 2023-10-17 20:08:56 --> Config Class Initialized
INFO - 2023-10-17 20:08:56 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:08:56 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:08:56 --> Utf8 Class Initialized
INFO - 2023-10-17 20:08:56 --> URI Class Initialized
INFO - 2023-10-17 20:08:56 --> Router Class Initialized
INFO - 2023-10-17 20:08:56 --> Output Class Initialized
INFO - 2023-10-17 20:08:56 --> Security Class Initialized
DEBUG - 2023-10-17 20:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:08:56 --> Input Class Initialized
INFO - 2023-10-17 20:08:56 --> Language Class Initialized
INFO - 2023-10-17 20:08:56 --> Loader Class Initialized
INFO - 2023-10-17 20:08:56 --> Helper loaded: url_helper
INFO - 2023-10-17 20:08:56 --> Helper loaded: file_helper
INFO - 2023-10-17 20:08:56 --> Database Driver Class Initialized
INFO - 2023-10-17 20:08:56 --> Email Class Initialized
DEBUG - 2023-10-17 20:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:08:56 --> Controller Class Initialized
INFO - 2023-10-17 20:08:56 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:08:56 --> Model "Home_model" initialized
INFO - 2023-10-17 20:08:56 --> Helper loaded: download_helper
INFO - 2023-10-17 20:08:56 --> Helper loaded: form_helper
INFO - 2023-10-17 20:08:56 --> Form Validation Class Initialized
INFO - 2023-10-17 20:08:56 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:08:56 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:08:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:08:57 --> Final output sent to browser
DEBUG - 2023-10-17 20:08:57 --> Total execution time: 0.1363
INFO - 2023-10-17 20:08:59 --> Config Class Initialized
INFO - 2023-10-17 20:08:59 --> Hooks Class Initialized
DEBUG - 2023-10-17 20:08:59 --> UTF-8 Support Enabled
INFO - 2023-10-17 20:08:59 --> Utf8 Class Initialized
INFO - 2023-10-17 20:08:59 --> URI Class Initialized
INFO - 2023-10-17 20:08:59 --> Router Class Initialized
INFO - 2023-10-17 20:08:59 --> Output Class Initialized
INFO - 2023-10-17 20:08:59 --> Security Class Initialized
DEBUG - 2023-10-17 20:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-17 20:08:59 --> Input Class Initialized
INFO - 2023-10-17 20:08:59 --> Language Class Initialized
INFO - 2023-10-17 20:08:59 --> Loader Class Initialized
INFO - 2023-10-17 20:08:59 --> Helper loaded: url_helper
INFO - 2023-10-17 20:08:59 --> Helper loaded: file_helper
INFO - 2023-10-17 20:08:59 --> Database Driver Class Initialized
INFO - 2023-10-17 20:08:59 --> Email Class Initialized
DEBUG - 2023-10-17 20:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-17 20:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-17 20:08:59 --> Controller Class Initialized
INFO - 2023-10-17 20:08:59 --> Model "Contact_model" initialized
INFO - 2023-10-17 20:08:59 --> Model "Home_model" initialized
INFO - 2023-10-17 20:08:59 --> Helper loaded: download_helper
INFO - 2023-10-17 20:08:59 --> Helper loaded: form_helper
INFO - 2023-10-17 20:08:59 --> Form Validation Class Initialized
INFO - 2023-10-17 20:08:59 --> Helper loaded: custom_helper
INFO - 2023-10-17 20:08:59 --> Model "Social_media_model" initialized
INFO - 2023-10-17 20:08:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-17 20:08:59 --> Final output sent to browser
DEBUG - 2023-10-17 20:08:59 --> Total execution time: 0.1164
