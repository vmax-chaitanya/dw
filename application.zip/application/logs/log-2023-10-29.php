<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-29 19:07:04 --> Config Class Initialized
INFO - 2023-10-29 19:07:05 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:07:05 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:07:05 --> Utf8 Class Initialized
INFO - 2023-10-29 19:07:05 --> URI Class Initialized
DEBUG - 2023-10-29 19:07:05 --> No URI present. Default controller set.
INFO - 2023-10-29 19:07:05 --> Router Class Initialized
INFO - 2023-10-29 19:07:05 --> Output Class Initialized
INFO - 2023-10-29 19:07:05 --> Security Class Initialized
DEBUG - 2023-10-29 19:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:07:05 --> Input Class Initialized
INFO - 2023-10-29 19:07:05 --> Language Class Initialized
INFO - 2023-10-29 19:07:05 --> Loader Class Initialized
INFO - 2023-10-29 19:07:05 --> Helper loaded: url_helper
INFO - 2023-10-29 19:07:05 --> Helper loaded: file_helper
INFO - 2023-10-29 19:07:05 --> Database Driver Class Initialized
INFO - 2023-10-29 19:07:05 --> Email Class Initialized
DEBUG - 2023-10-29 19:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:07:05 --> Controller Class Initialized
INFO - 2023-10-29 19:07:05 --> Model "Contact_model" initialized
INFO - 2023-10-29 19:07:05 --> Model "CareerFormModel" initialized
INFO - 2023-10-29 19:07:05 --> Model "Home_model" initialized
INFO - 2023-10-29 19:07:05 --> Helper loaded: download_helper
INFO - 2023-10-29 19:07:05 --> Helper loaded: form_helper
INFO - 2023-10-29 19:07:05 --> Form Validation Class Initialized
INFO - 2023-10-29 19:07:05 --> Helper loaded: custom_helper
INFO - 2023-10-29 19:07:05 --> Model "Social_media_model" initialized
ERROR - 2023-10-29 19:07:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-29 19:07:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-29 19:07:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-29 19:07:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-29 19:07:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-29 19:07:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-29 19:07:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-29 19:07:05 --> Final output sent to browser
DEBUG - 2023-10-29 19:07:05 --> Total execution time: 0.1458
INFO - 2023-10-29 19:07:06 --> Config Class Initialized
INFO - 2023-10-29 19:07:06 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:07:06 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:07:06 --> Utf8 Class Initialized
INFO - 2023-10-29 19:07:06 --> URI Class Initialized
INFO - 2023-10-29 19:07:06 --> Router Class Initialized
INFO - 2023-10-29 19:07:06 --> Output Class Initialized
INFO - 2023-10-29 19:07:06 --> Security Class Initialized
DEBUG - 2023-10-29 19:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:07:08 --> Config Class Initialized
INFO - 2023-10-29 19:07:08 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:07:08 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:07:08 --> Utf8 Class Initialized
INFO - 2023-10-29 19:07:08 --> URI Class Initialized
INFO - 2023-10-29 19:07:08 --> Router Class Initialized
INFO - 2023-10-29 19:07:08 --> Output Class Initialized
INFO - 2023-10-29 19:07:08 --> Security Class Initialized
DEBUG - 2023-10-29 19:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:07:08 --> Input Class Initialized
INFO - 2023-10-29 19:07:08 --> Language Class Initialized
ERROR - 2023-10-29 19:07:08 --> 404 Page Not Found: Assets/home
INFO - 2023-10-29 19:07:09 --> Input Class Initialized
INFO - 2023-10-29 19:07:09 --> Language Class Initialized
ERROR - 2023-10-29 19:07:09 --> 404 Page Not Found: Assets/home
INFO - 2023-10-29 19:07:32 --> Config Class Initialized
INFO - 2023-10-29 19:07:32 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:07:32 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:07:32 --> Utf8 Class Initialized
INFO - 2023-10-29 19:07:32 --> URI Class Initialized
DEBUG - 2023-10-29 19:07:32 --> No URI present. Default controller set.
INFO - 2023-10-29 19:07:32 --> Router Class Initialized
INFO - 2023-10-29 19:07:32 --> Output Class Initialized
INFO - 2023-10-29 19:07:32 --> Security Class Initialized
DEBUG - 2023-10-29 19:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:07:32 --> Input Class Initialized
INFO - 2023-10-29 19:07:32 --> Language Class Initialized
INFO - 2023-10-29 19:07:32 --> Loader Class Initialized
INFO - 2023-10-29 19:07:32 --> Helper loaded: url_helper
INFO - 2023-10-29 19:07:32 --> Helper loaded: file_helper
INFO - 2023-10-29 19:07:32 --> Database Driver Class Initialized
INFO - 2023-10-29 19:07:32 --> Email Class Initialized
DEBUG - 2023-10-29 19:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:07:32 --> Controller Class Initialized
INFO - 2023-10-29 19:07:32 --> Model "Contact_model" initialized
INFO - 2023-10-29 19:07:32 --> Model "CareerFormModel" initialized
INFO - 2023-10-29 19:07:32 --> Model "Home_model" initialized
INFO - 2023-10-29 19:07:32 --> Helper loaded: download_helper
INFO - 2023-10-29 19:07:32 --> Helper loaded: form_helper
INFO - 2023-10-29 19:07:32 --> Form Validation Class Initialized
INFO - 2023-10-29 19:07:32 --> Helper loaded: custom_helper
INFO - 2023-10-29 19:07:32 --> Model "Social_media_model" initialized
ERROR - 2023-10-29 19:07:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-29 19:07:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-29 19:07:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-29 19:07:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-29 19:07:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-29 19:07:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-29 19:07:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-29 19:07:32 --> Final output sent to browser
DEBUG - 2023-10-29 19:07:32 --> Total execution time: 0.2064
INFO - 2023-10-29 19:07:36 --> Config Class Initialized
INFO - 2023-10-29 19:07:36 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:07:36 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:07:36 --> Utf8 Class Initialized
INFO - 2023-10-29 19:07:36 --> URI Class Initialized
DEBUG - 2023-10-29 19:07:36 --> No URI present. Default controller set.
INFO - 2023-10-29 19:07:36 --> Router Class Initialized
INFO - 2023-10-29 19:07:36 --> Output Class Initialized
INFO - 2023-10-29 19:07:36 --> Security Class Initialized
DEBUG - 2023-10-29 19:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:07:36 --> Input Class Initialized
INFO - 2023-10-29 19:07:36 --> Language Class Initialized
INFO - 2023-10-29 19:07:36 --> Loader Class Initialized
INFO - 2023-10-29 19:07:36 --> Helper loaded: url_helper
INFO - 2023-10-29 19:07:36 --> Helper loaded: file_helper
INFO - 2023-10-29 19:07:36 --> Database Driver Class Initialized
INFO - 2023-10-29 19:07:36 --> Email Class Initialized
DEBUG - 2023-10-29 19:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:07:36 --> Controller Class Initialized
INFO - 2023-10-29 19:07:36 --> Model "Contact_model" initialized
INFO - 2023-10-29 19:07:36 --> Model "CareerFormModel" initialized
INFO - 2023-10-29 19:07:36 --> Model "Home_model" initialized
INFO - 2023-10-29 19:07:36 --> Helper loaded: download_helper
INFO - 2023-10-29 19:07:36 --> Helper loaded: form_helper
INFO - 2023-10-29 19:07:36 --> Form Validation Class Initialized
INFO - 2023-10-29 19:07:36 --> Helper loaded: custom_helper
INFO - 2023-10-29 19:07:36 --> Model "Social_media_model" initialized
ERROR - 2023-10-29 19:07:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-29 19:07:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-29 19:07:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-29 19:07:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-29 19:07:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-29 19:07:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-29 19:07:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-29 19:07:36 --> Final output sent to browser
DEBUG - 2023-10-29 19:07:36 --> Total execution time: 0.1711
INFO - 2023-10-29 19:07:53 --> Config Class Initialized
INFO - 2023-10-29 19:07:53 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:07:53 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:07:53 --> Utf8 Class Initialized
INFO - 2023-10-29 19:07:53 --> URI Class Initialized
INFO - 2023-10-29 19:07:53 --> Router Class Initialized
INFO - 2023-10-29 19:07:53 --> Output Class Initialized
INFO - 2023-10-29 19:07:53 --> Security Class Initialized
INFO - 2023-10-29 19:07:53 --> Config Class Initialized
INFO - 2023-10-29 19:07:55 --> Hooks Class Initialized
INFO - 2023-10-29 19:07:55 --> Config Class Initialized
INFO - 2023-10-29 19:07:55 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:07:55 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:07:55 --> Utf8 Class Initialized
INFO - 2023-10-29 19:07:55 --> URI Class Initialized
INFO - 2023-10-29 19:07:55 --> Router Class Initialized
INFO - 2023-10-29 19:07:55 --> Output Class Initialized
INFO - 2023-10-29 19:07:55 --> Security Class Initialized
DEBUG - 2023-10-29 19:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:07:55 --> Input Class Initialized
INFO - 2023-10-29 19:07:55 --> Language Class Initialized
ERROR - 2023-10-29 19:07:55 --> 404 Page Not Found: Assets/home
DEBUG - 2023-10-29 19:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:07:55 --> Input Class Initialized
INFO - 2023-10-29 19:07:55 --> Language Class Initialized
ERROR - 2023-10-29 19:07:55 --> 404 Page Not Found: Assets/home
DEBUG - 2023-10-29 19:07:56 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:07:56 --> Utf8 Class Initialized
INFO - 2023-10-29 19:07:56 --> URI Class Initialized
INFO - 2023-10-29 19:07:56 --> Router Class Initialized
INFO - 2023-10-29 19:07:56 --> Output Class Initialized
INFO - 2023-10-29 19:07:56 --> Security Class Initialized
DEBUG - 2023-10-29 19:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:07:56 --> Input Class Initialized
INFO - 2023-10-29 19:07:56 --> Language Class Initialized
ERROR - 2023-10-29 19:07:56 --> 404 Page Not Found: Assets/home
INFO - 2023-10-29 19:07:57 --> Config Class Initialized
INFO - 2023-10-29 19:07:57 --> Config Class Initialized
INFO - 2023-10-29 19:07:57 --> Config Class Initialized
INFO - 2023-10-29 19:07:57 --> Hooks Class Initialized
INFO - 2023-10-29 19:07:57 --> Hooks Class Initialized
INFO - 2023-10-29 19:07:57 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:07:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:07:57 --> Config Class Initialized
DEBUG - 2023-10-29 19:07:57 --> UTF-8 Support Enabled
DEBUG - 2023-10-29 19:07:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:07:57 --> Utf8 Class Initialized
INFO - 2023-10-29 19:07:57 --> Utf8 Class Initialized
INFO - 2023-10-29 19:07:57 --> Utf8 Class Initialized
INFO - 2023-10-29 19:07:57 --> Hooks Class Initialized
INFO - 2023-10-29 19:07:57 --> URI Class Initialized
INFO - 2023-10-29 19:07:57 --> URI Class Initialized
INFO - 2023-10-29 19:07:57 --> Router Class Initialized
INFO - 2023-10-29 19:07:57 --> Router Class Initialized
INFO - 2023-10-29 19:07:57 --> URI Class Initialized
INFO - 2023-10-29 19:07:57 --> Output Class Initialized
DEBUG - 2023-10-29 19:07:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:07:57 --> Output Class Initialized
INFO - 2023-10-29 19:07:57 --> Router Class Initialized
INFO - 2023-10-29 19:07:57 --> Output Class Initialized
INFO - 2023-10-29 19:07:57 --> Security Class Initialized
DEBUG - 2023-10-29 19:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:07:57 --> Input Class Initialized
INFO - 2023-10-29 19:07:57 --> Language Class Initialized
ERROR - 2023-10-29 19:07:57 --> 404 Page Not Found: Assets/home
INFO - 2023-10-29 19:07:57 --> Utf8 Class Initialized
INFO - 2023-10-29 19:07:57 --> Security Class Initialized
INFO - 2023-10-29 19:07:57 --> Security Class Initialized
INFO - 2023-10-29 19:07:57 --> URI Class Initialized
DEBUG - 2023-10-29 19:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:07:57 --> Router Class Initialized
DEBUG - 2023-10-29 19:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:07:57 --> Output Class Initialized
INFO - 2023-10-29 19:07:57 --> Security Class Initialized
INFO - 2023-10-29 19:07:57 --> Input Class Initialized
INFO - 2023-10-29 19:07:57 --> Input Class Initialized
DEBUG - 2023-10-29 19:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:07:57 --> Language Class Initialized
INFO - 2023-10-29 19:07:57 --> Language Class Initialized
INFO - 2023-10-29 19:07:57 --> Input Class Initialized
ERROR - 2023-10-29 19:07:57 --> 404 Page Not Found: Assets/home
ERROR - 2023-10-29 19:07:57 --> 404 Page Not Found: Assets/home
INFO - 2023-10-29 19:07:57 --> Language Class Initialized
ERROR - 2023-10-29 19:07:57 --> 404 Page Not Found: Assets/home
INFO - 2023-10-29 19:09:06 --> Config Class Initialized
INFO - 2023-10-29 19:09:06 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:09:06 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:09:06 --> Utf8 Class Initialized
INFO - 2023-10-29 19:09:06 --> URI Class Initialized
INFO - 2023-10-29 19:09:06 --> Router Class Initialized
INFO - 2023-10-29 19:09:06 --> Output Class Initialized
INFO - 2023-10-29 19:09:06 --> Security Class Initialized
DEBUG - 2023-10-29 19:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:09:06 --> Input Class Initialized
INFO - 2023-10-29 19:09:06 --> Language Class Initialized
INFO - 2023-10-29 19:09:06 --> Loader Class Initialized
INFO - 2023-10-29 19:09:06 --> Helper loaded: url_helper
INFO - 2023-10-29 19:09:06 --> Helper loaded: file_helper
INFO - 2023-10-29 19:09:06 --> Database Driver Class Initialized
INFO - 2023-10-29 19:09:06 --> Email Class Initialized
DEBUG - 2023-10-29 19:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:09:06 --> Controller Class Initialized
INFO - 2023-10-29 19:09:06 --> Model "Contact_model" initialized
INFO - 2023-10-29 19:09:06 --> Model "CareerFormModel" initialized
INFO - 2023-10-29 19:09:06 --> Model "Home_model" initialized
INFO - 2023-10-29 19:09:06 --> Helper loaded: download_helper
INFO - 2023-10-29 19:09:06 --> Helper loaded: form_helper
INFO - 2023-10-29 19:09:06 --> Form Validation Class Initialized
INFO - 2023-10-29 19:09:06 --> Helper loaded: custom_helper
INFO - 2023-10-29 19:09:06 --> Model "Social_media_model" initialized
ERROR - 2023-10-29 19:09:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-29 19:09:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-29 19:09:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-29 19:09:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-29 19:09:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-29 19:09:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-29 19:09:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-10-29 19:09:06 --> Final output sent to browser
DEBUG - 2023-10-29 19:09:06 --> Total execution time: 0.2203
INFO - 2023-10-29 19:09:13 --> Config Class Initialized
INFO - 2023-10-29 19:09:13 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:09:13 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:09:13 --> Utf8 Class Initialized
INFO - 2023-10-29 19:09:13 --> URI Class Initialized
INFO - 2023-10-29 19:09:13 --> Router Class Initialized
INFO - 2023-10-29 19:09:13 --> Output Class Initialized
INFO - 2023-10-29 19:09:13 --> Security Class Initialized
DEBUG - 2023-10-29 19:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:09:13 --> Input Class Initialized
INFO - 2023-10-29 19:09:13 --> Language Class Initialized
INFO - 2023-10-29 19:09:13 --> Loader Class Initialized
INFO - 2023-10-29 19:09:13 --> Helper loaded: url_helper
INFO - 2023-10-29 19:09:13 --> Helper loaded: file_helper
INFO - 2023-10-29 19:09:13 --> Database Driver Class Initialized
INFO - 2023-10-29 19:09:13 --> Email Class Initialized
DEBUG - 2023-10-29 19:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:09:13 --> Controller Class Initialized
INFO - 2023-10-29 19:09:13 --> Model "Contact_model" initialized
INFO - 2023-10-29 19:09:13 --> Model "CareerFormModel" initialized
INFO - 2023-10-29 19:09:13 --> Model "Home_model" initialized
INFO - 2023-10-29 19:09:13 --> Helper loaded: download_helper
INFO - 2023-10-29 19:09:13 --> Helper loaded: form_helper
INFO - 2023-10-29 19:09:13 --> Form Validation Class Initialized
INFO - 2023-10-29 19:09:13 --> Helper loaded: custom_helper
INFO - 2023-10-29 19:09:13 --> Model "Social_media_model" initialized
ERROR - 2023-10-29 19:09:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-29 19:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-29 19:09:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-29 19:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-29 19:09:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-29 19:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-29 19:09:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-10-29 19:09:13 --> Final output sent to browser
DEBUG - 2023-10-29 19:09:13 --> Total execution time: 0.1488
