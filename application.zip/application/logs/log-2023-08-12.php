<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-12 08:57:43 --> Config Class Initialized
INFO - 2023-08-12 08:57:43 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:57:43 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:57:43 --> Utf8 Class Initialized
INFO - 2023-08-12 08:57:43 --> URI Class Initialized
DEBUG - 2023-08-12 08:57:43 --> No URI present. Default controller set.
INFO - 2023-08-12 08:57:43 --> Router Class Initialized
INFO - 2023-08-12 08:57:44 --> Output Class Initialized
INFO - 2023-08-12 08:57:44 --> Security Class Initialized
DEBUG - 2023-08-12 08:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:57:44 --> Input Class Initialized
INFO - 2023-08-12 08:57:44 --> Language Class Initialized
INFO - 2023-08-12 08:57:44 --> Loader Class Initialized
INFO - 2023-08-12 08:57:44 --> Helper loaded: url_helper
INFO - 2023-08-12 08:57:44 --> Helper loaded: file_helper
INFO - 2023-08-12 08:57:44 --> Database Driver Class Initialized
INFO - 2023-08-12 08:57:44 --> Email Class Initialized
DEBUG - 2023-08-12 08:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 08:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 08:57:45 --> Controller Class Initialized
INFO - 2023-08-12 08:57:45 --> File loaded: C:\xampp\htdocs\dw\application\views\welcome_message.php
INFO - 2023-08-12 08:57:45 --> Final output sent to browser
DEBUG - 2023-08-12 08:57:45 --> Total execution time: 1.7278
INFO - 2023-08-12 08:57:51 --> Config Class Initialized
INFO - 2023-08-12 08:57:51 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:57:51 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:57:51 --> Utf8 Class Initialized
INFO - 2023-08-12 08:57:51 --> URI Class Initialized
INFO - 2023-08-12 08:57:51 --> Router Class Initialized
INFO - 2023-08-12 08:57:51 --> Output Class Initialized
INFO - 2023-08-12 08:57:51 --> Security Class Initialized
DEBUG - 2023-08-12 08:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:57:51 --> Input Class Initialized
INFO - 2023-08-12 08:57:51 --> Language Class Initialized
ERROR - 2023-08-12 08:57:51 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:58:01 --> Config Class Initialized
INFO - 2023-08-12 08:58:01 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:58:01 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:58:01 --> Utf8 Class Initialized
INFO - 2023-08-12 08:58:01 --> URI Class Initialized
INFO - 2023-08-12 08:58:01 --> Router Class Initialized
INFO - 2023-08-12 08:58:01 --> Output Class Initialized
INFO - 2023-08-12 08:58:01 --> Security Class Initialized
DEBUG - 2023-08-12 08:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:58:01 --> Input Class Initialized
INFO - 2023-08-12 08:58:01 --> Language Class Initialized
ERROR - 2023-08-12 08:58:01 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:58:03 --> Config Class Initialized
INFO - 2023-08-12 08:58:03 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:58:03 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:58:03 --> Utf8 Class Initialized
INFO - 2023-08-12 08:58:03 --> URI Class Initialized
INFO - 2023-08-12 08:58:03 --> Router Class Initialized
INFO - 2023-08-12 08:58:03 --> Output Class Initialized
INFO - 2023-08-12 08:58:03 --> Security Class Initialized
DEBUG - 2023-08-12 08:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:58:03 --> Input Class Initialized
INFO - 2023-08-12 08:58:03 --> Language Class Initialized
ERROR - 2023-08-12 08:58:03 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:58:08 --> Config Class Initialized
INFO - 2023-08-12 08:58:08 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:58:08 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:58:08 --> Utf8 Class Initialized
INFO - 2023-08-12 08:58:08 --> URI Class Initialized
INFO - 2023-08-12 08:58:08 --> Router Class Initialized
INFO - 2023-08-12 08:58:08 --> Output Class Initialized
INFO - 2023-08-12 08:58:08 --> Security Class Initialized
DEBUG - 2023-08-12 08:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:58:08 --> Input Class Initialized
INFO - 2023-08-12 08:58:08 --> Language Class Initialized
ERROR - 2023-08-12 08:58:08 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:58:21 --> Config Class Initialized
INFO - 2023-08-12 08:58:21 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:58:21 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:58:21 --> Utf8 Class Initialized
INFO - 2023-08-12 08:58:21 --> URI Class Initialized
INFO - 2023-08-12 08:58:21 --> Router Class Initialized
INFO - 2023-08-12 08:58:21 --> Output Class Initialized
INFO - 2023-08-12 08:58:21 --> Security Class Initialized
DEBUG - 2023-08-12 08:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:58:21 --> Input Class Initialized
INFO - 2023-08-12 08:58:21 --> Language Class Initialized
ERROR - 2023-08-12 08:58:21 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:58:32 --> Config Class Initialized
INFO - 2023-08-12 08:58:32 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:58:32 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:58:32 --> Utf8 Class Initialized
INFO - 2023-08-12 08:58:32 --> URI Class Initialized
INFO - 2023-08-12 08:58:32 --> Router Class Initialized
INFO - 2023-08-12 08:58:32 --> Output Class Initialized
INFO - 2023-08-12 08:58:32 --> Security Class Initialized
DEBUG - 2023-08-12 08:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:58:32 --> Input Class Initialized
INFO - 2023-08-12 08:58:32 --> Language Class Initialized
ERROR - 2023-08-12 08:58:33 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:58:41 --> Config Class Initialized
INFO - 2023-08-12 08:58:41 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:58:41 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:58:41 --> Utf8 Class Initialized
INFO - 2023-08-12 08:58:41 --> URI Class Initialized
INFO - 2023-08-12 08:58:41 --> Router Class Initialized
INFO - 2023-08-12 08:58:41 --> Output Class Initialized
INFO - 2023-08-12 08:58:41 --> Security Class Initialized
DEBUG - 2023-08-12 08:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:58:41 --> Input Class Initialized
INFO - 2023-08-12 08:58:41 --> Language Class Initialized
ERROR - 2023-08-12 08:58:41 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:58:57 --> Config Class Initialized
INFO - 2023-08-12 08:58:57 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:58:57 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:58:57 --> Utf8 Class Initialized
INFO - 2023-08-12 08:58:57 --> URI Class Initialized
INFO - 2023-08-12 08:58:57 --> Router Class Initialized
INFO - 2023-08-12 08:58:57 --> Output Class Initialized
INFO - 2023-08-12 08:58:57 --> Security Class Initialized
DEBUG - 2023-08-12 08:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:58:57 --> Input Class Initialized
INFO - 2023-08-12 08:58:57 --> Language Class Initialized
ERROR - 2023-08-12 08:58:57 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:59:04 --> Config Class Initialized
INFO - 2023-08-12 08:59:04 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:59:04 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:59:04 --> Utf8 Class Initialized
INFO - 2023-08-12 08:59:04 --> URI Class Initialized
DEBUG - 2023-08-12 08:59:04 --> No URI present. Default controller set.
INFO - 2023-08-12 08:59:04 --> Router Class Initialized
INFO - 2023-08-12 08:59:04 --> Output Class Initialized
INFO - 2023-08-12 08:59:04 --> Security Class Initialized
DEBUG - 2023-08-12 08:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:59:04 --> Input Class Initialized
INFO - 2023-08-12 08:59:04 --> Language Class Initialized
INFO - 2023-08-12 08:59:04 --> Loader Class Initialized
INFO - 2023-08-12 08:59:04 --> Helper loaded: url_helper
INFO - 2023-08-12 08:59:04 --> Helper loaded: file_helper
INFO - 2023-08-12 08:59:04 --> Database Driver Class Initialized
INFO - 2023-08-12 08:59:04 --> Email Class Initialized
DEBUG - 2023-08-12 08:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 08:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 08:59:04 --> Controller Class Initialized
INFO - 2023-08-12 08:59:04 --> File loaded: C:\xampp\htdocs\dw\application\views\welcome_message.php
INFO - 2023-08-12 08:59:04 --> Final output sent to browser
DEBUG - 2023-08-12 08:59:04 --> Total execution time: 0.0519
INFO - 2023-08-12 08:59:24 --> Config Class Initialized
INFO - 2023-08-12 08:59:24 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:59:24 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:59:24 --> Utf8 Class Initialized
INFO - 2023-08-12 08:59:24 --> URI Class Initialized
DEBUG - 2023-08-12 08:59:24 --> No URI present. Default controller set.
INFO - 2023-08-12 08:59:24 --> Router Class Initialized
INFO - 2023-08-12 08:59:24 --> Output Class Initialized
INFO - 2023-08-12 08:59:24 --> Security Class Initialized
DEBUG - 2023-08-12 08:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:59:24 --> Input Class Initialized
INFO - 2023-08-12 08:59:24 --> Language Class Initialized
INFO - 2023-08-12 08:59:24 --> Loader Class Initialized
INFO - 2023-08-12 08:59:24 --> Helper loaded: url_helper
INFO - 2023-08-12 08:59:24 --> Helper loaded: file_helper
INFO - 2023-08-12 08:59:24 --> Database Driver Class Initialized
INFO - 2023-08-12 08:59:24 --> Email Class Initialized
DEBUG - 2023-08-12 08:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 08:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 08:59:24 --> Controller Class Initialized
INFO - 2023-08-12 08:59:24 --> File loaded: C:\xampp\htdocs\dw\application\views\welcome_message.php
INFO - 2023-08-12 08:59:24 --> Final output sent to browser
DEBUG - 2023-08-12 08:59:24 --> Total execution time: 0.1783
INFO - 2023-08-12 08:59:28 --> Config Class Initialized
INFO - 2023-08-12 08:59:28 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:59:28 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:59:28 --> Utf8 Class Initialized
INFO - 2023-08-12 08:59:28 --> URI Class Initialized
INFO - 2023-08-12 08:59:28 --> Router Class Initialized
INFO - 2023-08-12 08:59:28 --> Output Class Initialized
INFO - 2023-08-12 08:59:28 --> Security Class Initialized
DEBUG - 2023-08-12 08:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:59:28 --> Input Class Initialized
INFO - 2023-08-12 08:59:28 --> Language Class Initialized
ERROR - 2023-08-12 08:59:28 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:59:34 --> Config Class Initialized
INFO - 2023-08-12 08:59:34 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:59:34 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:59:34 --> Utf8 Class Initialized
INFO - 2023-08-12 08:59:34 --> URI Class Initialized
INFO - 2023-08-12 08:59:34 --> Router Class Initialized
INFO - 2023-08-12 08:59:34 --> Output Class Initialized
INFO - 2023-08-12 08:59:34 --> Security Class Initialized
DEBUG - 2023-08-12 08:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:59:34 --> Input Class Initialized
INFO - 2023-08-12 08:59:34 --> Language Class Initialized
ERROR - 2023-08-12 08:59:34 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:59:43 --> Config Class Initialized
INFO - 2023-08-12 08:59:43 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:59:43 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:59:43 --> Utf8 Class Initialized
INFO - 2023-08-12 08:59:43 --> URI Class Initialized
INFO - 2023-08-12 08:59:43 --> Router Class Initialized
INFO - 2023-08-12 08:59:43 --> Output Class Initialized
INFO - 2023-08-12 08:59:43 --> Security Class Initialized
DEBUG - 2023-08-12 08:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:59:43 --> Input Class Initialized
INFO - 2023-08-12 08:59:43 --> Language Class Initialized
ERROR - 2023-08-12 08:59:43 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:59:44 --> Config Class Initialized
INFO - 2023-08-12 08:59:44 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:59:44 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:59:44 --> Utf8 Class Initialized
INFO - 2023-08-12 08:59:44 --> URI Class Initialized
INFO - 2023-08-12 08:59:44 --> Router Class Initialized
INFO - 2023-08-12 08:59:44 --> Output Class Initialized
INFO - 2023-08-12 08:59:44 --> Security Class Initialized
DEBUG - 2023-08-12 08:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:59:44 --> Input Class Initialized
INFO - 2023-08-12 08:59:44 --> Language Class Initialized
ERROR - 2023-08-12 08:59:44 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:59:48 --> Config Class Initialized
INFO - 2023-08-12 08:59:48 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:59:48 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:59:48 --> Utf8 Class Initialized
INFO - 2023-08-12 08:59:48 --> URI Class Initialized
INFO - 2023-08-12 08:59:48 --> Router Class Initialized
INFO - 2023-08-12 08:59:48 --> Output Class Initialized
INFO - 2023-08-12 08:59:48 --> Security Class Initialized
DEBUG - 2023-08-12 08:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:59:48 --> Input Class Initialized
INFO - 2023-08-12 08:59:48 --> Language Class Initialized
ERROR - 2023-08-12 08:59:48 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:59:50 --> Config Class Initialized
INFO - 2023-08-12 08:59:50 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:59:50 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:59:50 --> Utf8 Class Initialized
INFO - 2023-08-12 08:59:50 --> URI Class Initialized
INFO - 2023-08-12 08:59:50 --> Router Class Initialized
INFO - 2023-08-12 08:59:50 --> Output Class Initialized
INFO - 2023-08-12 08:59:50 --> Security Class Initialized
DEBUG - 2023-08-12 08:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:59:50 --> Input Class Initialized
INFO - 2023-08-12 08:59:50 --> Language Class Initialized
ERROR - 2023-08-12 08:59:50 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:59:52 --> Config Class Initialized
INFO - 2023-08-12 08:59:52 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:59:52 --> Utf8 Class Initialized
INFO - 2023-08-12 08:59:52 --> URI Class Initialized
INFO - 2023-08-12 08:59:52 --> Router Class Initialized
INFO - 2023-08-12 08:59:52 --> Output Class Initialized
INFO - 2023-08-12 08:59:52 --> Security Class Initialized
DEBUG - 2023-08-12 08:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:59:52 --> Input Class Initialized
INFO - 2023-08-12 08:59:52 --> Language Class Initialized
ERROR - 2023-08-12 08:59:52 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 09:00:05 --> Config Class Initialized
INFO - 2023-08-12 09:00:05 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:00:05 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:00:05 --> Utf8 Class Initialized
INFO - 2023-08-12 09:00:05 --> URI Class Initialized
INFO - 2023-08-12 09:00:05 --> Router Class Initialized
INFO - 2023-08-12 09:00:05 --> Output Class Initialized
INFO - 2023-08-12 09:00:05 --> Security Class Initialized
DEBUG - 2023-08-12 09:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:00:05 --> Input Class Initialized
INFO - 2023-08-12 09:00:05 --> Language Class Initialized
ERROR - 2023-08-12 09:00:05 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 09:01:00 --> Config Class Initialized
INFO - 2023-08-12 09:01:00 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:01:00 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:01:00 --> Utf8 Class Initialized
INFO - 2023-08-12 09:01:00 --> URI Class Initialized
INFO - 2023-08-12 09:01:00 --> Router Class Initialized
INFO - 2023-08-12 09:01:00 --> Output Class Initialized
INFO - 2023-08-12 09:01:00 --> Security Class Initialized
DEBUG - 2023-08-12 09:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:01:00 --> Input Class Initialized
INFO - 2023-08-12 09:01:00 --> Language Class Initialized
ERROR - 2023-08-12 09:01:00 --> 404 Page Not Found: admin/Logi/index
INFO - 2023-08-12 09:01:06 --> Config Class Initialized
INFO - 2023-08-12 09:01:06 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:01:06 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:01:06 --> Utf8 Class Initialized
INFO - 2023-08-12 09:01:06 --> URI Class Initialized
INFO - 2023-08-12 09:01:06 --> Router Class Initialized
INFO - 2023-08-12 09:01:06 --> Output Class Initialized
INFO - 2023-08-12 09:01:06 --> Security Class Initialized
DEBUG - 2023-08-12 09:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:01:06 --> Input Class Initialized
INFO - 2023-08-12 09:01:06 --> Language Class Initialized
ERROR - 2023-08-12 09:01:06 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 09:01:12 --> Config Class Initialized
INFO - 2023-08-12 09:01:12 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:01:12 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:01:12 --> Utf8 Class Initialized
INFO - 2023-08-12 09:01:12 --> URI Class Initialized
DEBUG - 2023-08-12 09:01:12 --> No URI present. Default controller set.
INFO - 2023-08-12 09:01:12 --> Router Class Initialized
INFO - 2023-08-12 09:01:12 --> Output Class Initialized
INFO - 2023-08-12 09:01:12 --> Security Class Initialized
DEBUG - 2023-08-12 09:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:01:12 --> Input Class Initialized
INFO - 2023-08-12 09:01:12 --> Language Class Initialized
INFO - 2023-08-12 09:01:12 --> Loader Class Initialized
INFO - 2023-08-12 09:01:12 --> Helper loaded: url_helper
INFO - 2023-08-12 09:01:12 --> Helper loaded: file_helper
INFO - 2023-08-12 09:01:12 --> Database Driver Class Initialized
INFO - 2023-08-12 09:01:12 --> Email Class Initialized
DEBUG - 2023-08-12 09:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:01:12 --> Controller Class Initialized
INFO - 2023-08-12 09:01:12 --> File loaded: C:\xampp\htdocs\dw\application\views\welcome_message.php
INFO - 2023-08-12 09:01:12 --> Final output sent to browser
DEBUG - 2023-08-12 09:01:12 --> Total execution time: 0.0683
INFO - 2023-08-12 09:01:19 --> Config Class Initialized
INFO - 2023-08-12 09:01:19 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:01:19 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:01:19 --> Utf8 Class Initialized
INFO - 2023-08-12 09:01:19 --> URI Class Initialized
INFO - 2023-08-12 09:01:19 --> Router Class Initialized
INFO - 2023-08-12 09:01:19 --> Output Class Initialized
INFO - 2023-08-12 09:01:19 --> Security Class Initialized
DEBUG - 2023-08-12 09:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:01:19 --> Input Class Initialized
INFO - 2023-08-12 09:01:19 --> Language Class Initialized
ERROR - 2023-08-12 09:01:19 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 09:01:20 --> Config Class Initialized
INFO - 2023-08-12 09:01:20 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:01:20 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:01:20 --> Utf8 Class Initialized
INFO - 2023-08-12 09:01:20 --> URI Class Initialized
INFO - 2023-08-12 09:01:20 --> Router Class Initialized
INFO - 2023-08-12 09:01:20 --> Output Class Initialized
INFO - 2023-08-12 09:01:20 --> Security Class Initialized
DEBUG - 2023-08-12 09:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:01:20 --> Input Class Initialized
INFO - 2023-08-12 09:01:20 --> Language Class Initialized
ERROR - 2023-08-12 09:01:20 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 09:01:50 --> Config Class Initialized
INFO - 2023-08-12 09:01:50 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:01:50 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:01:50 --> Utf8 Class Initialized
INFO - 2023-08-12 09:01:50 --> URI Class Initialized
INFO - 2023-08-12 09:01:50 --> Router Class Initialized
INFO - 2023-08-12 09:01:50 --> Output Class Initialized
INFO - 2023-08-12 09:01:50 --> Security Class Initialized
DEBUG - 2023-08-12 09:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:01:50 --> Input Class Initialized
INFO - 2023-08-12 09:01:50 --> Language Class Initialized
INFO - 2023-08-12 09:01:50 --> Loader Class Initialized
INFO - 2023-08-12 09:01:50 --> Helper loaded: url_helper
INFO - 2023-08-12 09:01:50 --> Helper loaded: file_helper
INFO - 2023-08-12 09:01:50 --> Database Driver Class Initialized
INFO - 2023-08-12 09:01:50 --> Email Class Initialized
DEBUG - 2023-08-12 09:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:01:50 --> Controller Class Initialized
INFO - 2023-08-12 09:01:50 --> Model "User_model" initialized
INFO - 2023-08-12 09:01:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-12 09:01:50 --> Final output sent to browser
DEBUG - 2023-08-12 09:01:50 --> Total execution time: 0.3446
INFO - 2023-08-12 09:01:52 --> Config Class Initialized
INFO - 2023-08-12 09:01:52 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:01:52 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:01:52 --> Utf8 Class Initialized
INFO - 2023-08-12 09:01:52 --> URI Class Initialized
INFO - 2023-08-12 09:01:52 --> Router Class Initialized
INFO - 2023-08-12 09:01:52 --> Output Class Initialized
INFO - 2023-08-12 09:01:52 --> Security Class Initialized
DEBUG - 2023-08-12 09:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:01:52 --> Input Class Initialized
INFO - 2023-08-12 09:01:52 --> Language Class Initialized
ERROR - 2023-08-12 09:01:52 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-12 09:02:03 --> Config Class Initialized
INFO - 2023-08-12 09:02:03 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:02:03 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:02:03 --> Utf8 Class Initialized
INFO - 2023-08-12 09:02:03 --> URI Class Initialized
INFO - 2023-08-12 09:02:03 --> Router Class Initialized
INFO - 2023-08-12 09:02:03 --> Output Class Initialized
INFO - 2023-08-12 09:02:03 --> Security Class Initialized
DEBUG - 2023-08-12 09:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:02:03 --> Input Class Initialized
INFO - 2023-08-12 09:02:03 --> Language Class Initialized
INFO - 2023-08-12 09:02:03 --> Loader Class Initialized
INFO - 2023-08-12 09:02:03 --> Helper loaded: url_helper
INFO - 2023-08-12 09:02:03 --> Helper loaded: file_helper
INFO - 2023-08-12 09:02:03 --> Database Driver Class Initialized
INFO - 2023-08-12 09:02:03 --> Email Class Initialized
DEBUG - 2023-08-12 09:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:02:03 --> Controller Class Initialized
INFO - 2023-08-12 09:02:03 --> Model "User_model" initialized
INFO - 2023-08-12 09:02:03 --> Config Class Initialized
INFO - 2023-08-12 09:02:03 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:02:03 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:02:03 --> Utf8 Class Initialized
INFO - 2023-08-12 09:02:03 --> URI Class Initialized
INFO - 2023-08-12 09:02:03 --> Router Class Initialized
INFO - 2023-08-12 09:02:03 --> Output Class Initialized
INFO - 2023-08-12 09:02:03 --> Security Class Initialized
DEBUG - 2023-08-12 09:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:02:03 --> Input Class Initialized
INFO - 2023-08-12 09:02:03 --> Language Class Initialized
INFO - 2023-08-12 09:02:03 --> Loader Class Initialized
INFO - 2023-08-12 09:02:03 --> Helper loaded: url_helper
INFO - 2023-08-12 09:02:03 --> Helper loaded: file_helper
INFO - 2023-08-12 09:02:03 --> Database Driver Class Initialized
INFO - 2023-08-12 09:02:03 --> Email Class Initialized
DEBUG - 2023-08-12 09:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:02:03 --> Controller Class Initialized
INFO - 2023-08-12 09:02:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-12 09:02:04 --> Final output sent to browser
DEBUG - 2023-08-12 09:02:04 --> Total execution time: 0.0512
INFO - 2023-08-12 09:02:09 --> Config Class Initialized
INFO - 2023-08-12 09:02:09 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:02:09 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:02:09 --> Utf8 Class Initialized
INFO - 2023-08-12 09:02:09 --> URI Class Initialized
INFO - 2023-08-12 09:02:09 --> Router Class Initialized
INFO - 2023-08-12 09:02:09 --> Output Class Initialized
INFO - 2023-08-12 09:02:09 --> Security Class Initialized
DEBUG - 2023-08-12 09:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:02:09 --> Input Class Initialized
INFO - 2023-08-12 09:02:09 --> Language Class Initialized
ERROR - 2023-08-12 09:02:09 --> 404 Page Not Found: admin//index
INFO - 2023-08-12 09:02:13 --> Config Class Initialized
INFO - 2023-08-12 09:02:13 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:02:13 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:02:13 --> Utf8 Class Initialized
INFO - 2023-08-12 09:02:13 --> URI Class Initialized
INFO - 2023-08-12 09:02:13 --> Router Class Initialized
INFO - 2023-08-12 09:02:13 --> Output Class Initialized
INFO - 2023-08-12 09:02:13 --> Security Class Initialized
DEBUG - 2023-08-12 09:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:02:13 --> Input Class Initialized
INFO - 2023-08-12 09:02:13 --> Language Class Initialized
INFO - 2023-08-12 09:02:13 --> Loader Class Initialized
INFO - 2023-08-12 09:02:13 --> Helper loaded: url_helper
INFO - 2023-08-12 09:02:13 --> Helper loaded: file_helper
INFO - 2023-08-12 09:02:13 --> Database Driver Class Initialized
INFO - 2023-08-12 09:02:13 --> Email Class Initialized
DEBUG - 2023-08-12 09:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:02:13 --> Controller Class Initialized
INFO - 2023-08-12 09:02:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-12 09:02:13 --> Final output sent to browser
DEBUG - 2023-08-12 09:02:13 --> Total execution time: 0.0508
INFO - 2023-08-12 09:02:18 --> Config Class Initialized
INFO - 2023-08-12 09:02:18 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:02:18 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:02:18 --> Utf8 Class Initialized
INFO - 2023-08-12 09:02:18 --> URI Class Initialized
INFO - 2023-08-12 09:02:18 --> Router Class Initialized
INFO - 2023-08-12 09:02:18 --> Output Class Initialized
INFO - 2023-08-12 09:02:18 --> Security Class Initialized
DEBUG - 2023-08-12 09:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:02:18 --> Input Class Initialized
INFO - 2023-08-12 09:02:18 --> Language Class Initialized
INFO - 2023-08-12 09:02:18 --> Loader Class Initialized
INFO - 2023-08-12 09:02:18 --> Helper loaded: url_helper
INFO - 2023-08-12 09:02:18 --> Helper loaded: file_helper
INFO - 2023-08-12 09:02:18 --> Database Driver Class Initialized
INFO - 2023-08-12 09:02:18 --> Email Class Initialized
DEBUG - 2023-08-12 09:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:02:18 --> Controller Class Initialized
INFO - 2023-08-12 09:02:18 --> Model "Testimonials_model" initialized
INFO - 2023-08-12 09:02:18 --> Helper loaded: form_helper
INFO - 2023-08-12 09:02:18 --> Form Validation Class Initialized
INFO - 2023-08-12 09:02:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/testimonials_list.php
INFO - 2023-08-12 09:02:18 --> Final output sent to browser
DEBUG - 2023-08-12 09:02:18 --> Total execution time: 0.0784
INFO - 2023-08-12 09:02:27 --> Config Class Initialized
INFO - 2023-08-12 09:02:27 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:02:27 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:02:27 --> Utf8 Class Initialized
INFO - 2023-08-12 09:02:27 --> URI Class Initialized
INFO - 2023-08-12 09:02:27 --> Router Class Initialized
INFO - 2023-08-12 09:02:27 --> Output Class Initialized
INFO - 2023-08-12 09:02:27 --> Security Class Initialized
DEBUG - 2023-08-12 09:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:02:27 --> Input Class Initialized
INFO - 2023-08-12 09:02:27 --> Language Class Initialized
INFO - 2023-08-12 09:02:27 --> Loader Class Initialized
INFO - 2023-08-12 09:02:27 --> Helper loaded: url_helper
INFO - 2023-08-12 09:02:27 --> Helper loaded: file_helper
INFO - 2023-08-12 09:02:27 --> Database Driver Class Initialized
INFO - 2023-08-12 09:02:27 --> Email Class Initialized
DEBUG - 2023-08-12 09:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:02:27 --> Controller Class Initialized
INFO - 2023-08-12 09:02:27 --> Model "Testimonials_model" initialized
INFO - 2023-08-12 09:02:27 --> Helper loaded: form_helper
INFO - 2023-08-12 09:02:27 --> Form Validation Class Initialized
INFO - 2023-08-12 09:02:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/testimonials_create.php
INFO - 2023-08-12 09:02:27 --> Final output sent to browser
DEBUG - 2023-08-12 09:02:27 --> Total execution time: 0.0607
INFO - 2023-08-12 09:02:28 --> Config Class Initialized
INFO - 2023-08-12 09:02:28 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:02:28 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:02:28 --> Utf8 Class Initialized
INFO - 2023-08-12 09:02:28 --> URI Class Initialized
INFO - 2023-08-12 09:02:28 --> Router Class Initialized
INFO - 2023-08-12 09:02:28 --> Output Class Initialized
INFO - 2023-08-12 09:02:28 --> Security Class Initialized
DEBUG - 2023-08-12 09:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:02:28 --> Input Class Initialized
INFO - 2023-08-12 09:02:28 --> Language Class Initialized
ERROR - 2023-08-12 09:02:28 --> 404 Page Not Found: admin/Testimonials/images
INFO - 2023-08-12 09:02:40 --> Config Class Initialized
INFO - 2023-08-12 09:02:40 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:02:40 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:02:40 --> Utf8 Class Initialized
INFO - 2023-08-12 09:02:40 --> URI Class Initialized
INFO - 2023-08-12 09:02:40 --> Router Class Initialized
INFO - 2023-08-12 09:02:40 --> Output Class Initialized
INFO - 2023-08-12 09:02:40 --> Security Class Initialized
DEBUG - 2023-08-12 09:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:02:40 --> Input Class Initialized
INFO - 2023-08-12 09:02:40 --> Language Class Initialized
INFO - 2023-08-12 09:02:40 --> Loader Class Initialized
INFO - 2023-08-12 09:02:40 --> Helper loaded: url_helper
INFO - 2023-08-12 09:02:40 --> Helper loaded: file_helper
INFO - 2023-08-12 09:02:40 --> Database Driver Class Initialized
INFO - 2023-08-12 09:02:40 --> Email Class Initialized
DEBUG - 2023-08-12 09:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:02:40 --> Controller Class Initialized
INFO - 2023-08-12 09:02:40 --> Model "Testimonials_model" initialized
INFO - 2023-08-12 09:02:40 --> Helper loaded: form_helper
INFO - 2023-08-12 09:02:40 --> Form Validation Class Initialized
INFO - 2023-08-12 09:02:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-12 09:02:40 --> Config Class Initialized
INFO - 2023-08-12 09:02:40 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:02:40 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:02:40 --> Utf8 Class Initialized
INFO - 2023-08-12 09:02:40 --> URI Class Initialized
INFO - 2023-08-12 09:02:40 --> Router Class Initialized
INFO - 2023-08-12 09:02:40 --> Output Class Initialized
INFO - 2023-08-12 09:02:40 --> Security Class Initialized
DEBUG - 2023-08-12 09:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:02:40 --> Input Class Initialized
INFO - 2023-08-12 09:02:40 --> Language Class Initialized
INFO - 2023-08-12 09:02:40 --> Loader Class Initialized
INFO - 2023-08-12 09:02:40 --> Helper loaded: url_helper
INFO - 2023-08-12 09:02:40 --> Helper loaded: file_helper
INFO - 2023-08-12 09:02:40 --> Database Driver Class Initialized
INFO - 2023-08-12 09:02:40 --> Email Class Initialized
DEBUG - 2023-08-12 09:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:02:40 --> Controller Class Initialized
INFO - 2023-08-12 09:02:40 --> Model "Testimonials_model" initialized
INFO - 2023-08-12 09:02:40 --> Helper loaded: form_helper
INFO - 2023-08-12 09:02:40 --> Form Validation Class Initialized
INFO - 2023-08-12 09:02:40 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/testimonials_list.php
INFO - 2023-08-12 09:02:40 --> Final output sent to browser
DEBUG - 2023-08-12 09:02:40 --> Total execution time: 0.2759
INFO - 2023-08-12 09:07:27 --> Config Class Initialized
INFO - 2023-08-12 09:07:27 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:07:27 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:07:27 --> Utf8 Class Initialized
INFO - 2023-08-12 09:07:27 --> URI Class Initialized
INFO - 2023-08-12 09:07:27 --> Router Class Initialized
INFO - 2023-08-12 09:07:27 --> Output Class Initialized
INFO - 2023-08-12 09:07:27 --> Security Class Initialized
DEBUG - 2023-08-12 09:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:07:27 --> Input Class Initialized
INFO - 2023-08-12 09:07:27 --> Language Class Initialized
INFO - 2023-08-12 09:07:27 --> Loader Class Initialized
INFO - 2023-08-12 09:07:27 --> Helper loaded: url_helper
INFO - 2023-08-12 09:07:27 --> Helper loaded: file_helper
INFO - 2023-08-12 09:07:27 --> Database Driver Class Initialized
INFO - 2023-08-12 09:07:27 --> Email Class Initialized
DEBUG - 2023-08-12 09:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:07:27 --> Controller Class Initialized
INFO - 2023-08-12 09:07:27 --> Model "Banner_model" initialized
INFO - 2023-08-12 09:07:27 --> Helper loaded: form_helper
INFO - 2023-08-12 09:07:27 --> Form Validation Class Initialized
INFO - 2023-08-12 09:07:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-12 09:07:27 --> Final output sent to browser
DEBUG - 2023-08-12 09:07:27 --> Total execution time: 0.0990
INFO - 2023-08-12 09:07:31 --> Config Class Initialized
INFO - 2023-08-12 09:07:31 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:07:31 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:07:31 --> Utf8 Class Initialized
INFO - 2023-08-12 09:07:31 --> URI Class Initialized
INFO - 2023-08-12 09:07:31 --> Router Class Initialized
INFO - 2023-08-12 09:07:31 --> Output Class Initialized
INFO - 2023-08-12 09:07:31 --> Security Class Initialized
DEBUG - 2023-08-12 09:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:07:31 --> Input Class Initialized
INFO - 2023-08-12 09:07:31 --> Language Class Initialized
ERROR - 2023-08-12 09:07:31 --> 404 Page Not Found: admin//index
INFO - 2023-08-12 09:20:40 --> Config Class Initialized
INFO - 2023-08-12 09:20:40 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:20:40 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:20:40 --> Utf8 Class Initialized
INFO - 2023-08-12 09:20:40 --> URI Class Initialized
INFO - 2023-08-12 09:20:40 --> Router Class Initialized
INFO - 2023-08-12 09:20:40 --> Output Class Initialized
INFO - 2023-08-12 09:20:40 --> Security Class Initialized
DEBUG - 2023-08-12 09:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:20:40 --> Input Class Initialized
INFO - 2023-08-12 09:20:40 --> Language Class Initialized
ERROR - 2023-08-12 09:20:40 --> 404 Page Not Found: admin//index
INFO - 2023-08-12 09:20:47 --> Config Class Initialized
INFO - 2023-08-12 09:20:47 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:20:47 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:20:47 --> Utf8 Class Initialized
INFO - 2023-08-12 09:20:47 --> URI Class Initialized
INFO - 2023-08-12 09:20:47 --> Router Class Initialized
INFO - 2023-08-12 09:20:47 --> Output Class Initialized
INFO - 2023-08-12 09:20:47 --> Security Class Initialized
DEBUG - 2023-08-12 09:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:20:47 --> Input Class Initialized
INFO - 2023-08-12 09:20:47 --> Language Class Initialized
INFO - 2023-08-12 09:20:47 --> Loader Class Initialized
INFO - 2023-08-12 09:20:47 --> Helper loaded: url_helper
INFO - 2023-08-12 09:20:47 --> Helper loaded: file_helper
INFO - 2023-08-12 09:20:47 --> Database Driver Class Initialized
INFO - 2023-08-12 09:20:47 --> Email Class Initialized
DEBUG - 2023-08-12 09:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:20:47 --> Controller Class Initialized
INFO - 2023-08-12 09:20:47 --> Model "User_model" initialized
INFO - 2023-08-12 09:20:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-12 09:20:47 --> Final output sent to browser
DEBUG - 2023-08-12 09:20:47 --> Total execution time: 0.0508
INFO - 2023-08-12 09:20:49 --> Config Class Initialized
INFO - 2023-08-12 09:20:49 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:20:49 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:20:49 --> Utf8 Class Initialized
INFO - 2023-08-12 09:20:49 --> URI Class Initialized
INFO - 2023-08-12 09:20:49 --> Router Class Initialized
INFO - 2023-08-12 09:20:49 --> Output Class Initialized
INFO - 2023-08-12 09:20:49 --> Security Class Initialized
DEBUG - 2023-08-12 09:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:20:49 --> Input Class Initialized
INFO - 2023-08-12 09:20:49 --> Language Class Initialized
INFO - 2023-08-12 09:20:49 --> Loader Class Initialized
INFO - 2023-08-12 09:20:49 --> Helper loaded: url_helper
INFO - 2023-08-12 09:20:49 --> Helper loaded: file_helper
INFO - 2023-08-12 09:20:49 --> Database Driver Class Initialized
INFO - 2023-08-12 09:20:49 --> Email Class Initialized
DEBUG - 2023-08-12 09:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:20:49 --> Controller Class Initialized
INFO - 2023-08-12 09:20:49 --> Model "User_model" initialized
INFO - 2023-08-12 09:20:50 --> Config Class Initialized
INFO - 2023-08-12 09:20:50 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:20:50 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:20:50 --> Utf8 Class Initialized
INFO - 2023-08-12 09:20:50 --> URI Class Initialized
INFO - 2023-08-12 09:20:50 --> Router Class Initialized
INFO - 2023-08-12 09:20:50 --> Output Class Initialized
INFO - 2023-08-12 09:20:50 --> Security Class Initialized
DEBUG - 2023-08-12 09:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:20:50 --> Input Class Initialized
INFO - 2023-08-12 09:20:50 --> Language Class Initialized
INFO - 2023-08-12 09:20:50 --> Loader Class Initialized
INFO - 2023-08-12 09:20:50 --> Helper loaded: url_helper
INFO - 2023-08-12 09:20:50 --> Helper loaded: file_helper
INFO - 2023-08-12 09:20:50 --> Database Driver Class Initialized
INFO - 2023-08-12 09:20:50 --> Email Class Initialized
DEBUG - 2023-08-12 09:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:20:50 --> Controller Class Initialized
INFO - 2023-08-12 09:20:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-12 09:20:50 --> Final output sent to browser
DEBUG - 2023-08-12 09:20:50 --> Total execution time: 0.0577
INFO - 2023-08-12 09:20:58 --> Config Class Initialized
INFO - 2023-08-12 09:20:58 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:20:58 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:20:58 --> Utf8 Class Initialized
INFO - 2023-08-12 09:20:58 --> URI Class Initialized
INFO - 2023-08-12 09:20:58 --> Router Class Initialized
INFO - 2023-08-12 09:20:58 --> Output Class Initialized
INFO - 2023-08-12 09:20:58 --> Security Class Initialized
DEBUG - 2023-08-12 09:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:20:58 --> Input Class Initialized
INFO - 2023-08-12 09:20:58 --> Language Class Initialized
INFO - 2023-08-12 09:20:58 --> Loader Class Initialized
INFO - 2023-08-12 09:20:58 --> Helper loaded: url_helper
INFO - 2023-08-12 09:20:58 --> Helper loaded: file_helper
INFO - 2023-08-12 09:20:58 --> Database Driver Class Initialized
INFO - 2023-08-12 09:20:58 --> Email Class Initialized
DEBUG - 2023-08-12 09:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:20:58 --> Controller Class Initialized
INFO - 2023-08-12 09:20:58 --> Model "Banner_model" initialized
INFO - 2023-08-12 09:20:59 --> Helper loaded: form_helper
INFO - 2023-08-12 09:20:59 --> Form Validation Class Initialized
INFO - 2023-08-12 09:20:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-12 09:20:59 --> Final output sent to browser
DEBUG - 2023-08-12 09:20:59 --> Total execution time: 0.6075
INFO - 2023-08-12 09:30:41 --> Config Class Initialized
INFO - 2023-08-12 09:30:41 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:30:41 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:30:41 --> Utf8 Class Initialized
INFO - 2023-08-12 09:30:41 --> URI Class Initialized
INFO - 2023-08-12 09:30:41 --> Router Class Initialized
INFO - 2023-08-12 09:30:41 --> Output Class Initialized
INFO - 2023-08-12 09:30:41 --> Security Class Initialized
DEBUG - 2023-08-12 09:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:30:41 --> Input Class Initialized
INFO - 2023-08-12 09:30:41 --> Language Class Initialized
INFO - 2023-08-12 09:30:42 --> Loader Class Initialized
INFO - 2023-08-12 09:30:42 --> Helper loaded: url_helper
INFO - 2023-08-12 09:30:42 --> Helper loaded: file_helper
INFO - 2023-08-12 09:30:42 --> Database Driver Class Initialized
INFO - 2023-08-12 09:30:42 --> Email Class Initialized
DEBUG - 2023-08-12 09:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:30:42 --> Controller Class Initialized
INFO - 2023-08-12 09:30:42 --> Model "Banner_model" initialized
INFO - 2023-08-12 09:30:42 --> Helper loaded: form_helper
INFO - 2023-08-12 09:30:42 --> Form Validation Class Initialized
INFO - 2023-08-12 09:30:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-12 09:30:42 --> Final output sent to browser
DEBUG - 2023-08-12 09:30:42 --> Total execution time: 0.0990
INFO - 2023-08-12 09:30:44 --> Config Class Initialized
INFO - 2023-08-12 09:30:44 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:30:44 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:30:44 --> Utf8 Class Initialized
INFO - 2023-08-12 09:30:44 --> URI Class Initialized
INFO - 2023-08-12 09:30:44 --> Router Class Initialized
INFO - 2023-08-12 09:30:44 --> Output Class Initialized
INFO - 2023-08-12 09:30:44 --> Security Class Initialized
DEBUG - 2023-08-12 09:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:30:44 --> Input Class Initialized
INFO - 2023-08-12 09:30:44 --> Language Class Initialized
ERROR - 2023-08-12 09:30:44 --> 404 Page Not Found: admin//index
INFO - 2023-08-12 09:30:45 --> Config Class Initialized
INFO - 2023-08-12 09:30:45 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:30:45 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:30:45 --> Utf8 Class Initialized
INFO - 2023-08-12 09:30:45 --> URI Class Initialized
INFO - 2023-08-12 09:30:45 --> Router Class Initialized
INFO - 2023-08-12 09:30:45 --> Output Class Initialized
INFO - 2023-08-12 09:30:45 --> Security Class Initialized
DEBUG - 2023-08-12 09:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:30:45 --> Input Class Initialized
INFO - 2023-08-12 09:30:45 --> Language Class Initialized
INFO - 2023-08-12 09:30:45 --> Loader Class Initialized
INFO - 2023-08-12 09:30:45 --> Helper loaded: url_helper
INFO - 2023-08-12 09:30:45 --> Helper loaded: file_helper
INFO - 2023-08-12 09:30:45 --> Database Driver Class Initialized
INFO - 2023-08-12 09:30:45 --> Email Class Initialized
DEBUG - 2023-08-12 09:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:30:45 --> Controller Class Initialized
INFO - 2023-08-12 09:30:45 --> Model "Banner_model" initialized
INFO - 2023-08-12 09:30:45 --> Helper loaded: form_helper
INFO - 2023-08-12 09:30:45 --> Form Validation Class Initialized
INFO - 2023-08-12 09:30:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-12 09:30:46 --> Final output sent to browser
DEBUG - 2023-08-12 09:30:46 --> Total execution time: 0.0463
INFO - 2023-08-12 09:30:47 --> Config Class Initialized
INFO - 2023-08-12 09:30:47 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:30:47 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:30:47 --> Utf8 Class Initialized
INFO - 2023-08-12 09:30:47 --> URI Class Initialized
INFO - 2023-08-12 09:30:47 --> Router Class Initialized
INFO - 2023-08-12 09:30:47 --> Output Class Initialized
INFO - 2023-08-12 09:30:47 --> Security Class Initialized
DEBUG - 2023-08-12 09:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:30:47 --> Input Class Initialized
INFO - 2023-08-12 09:30:47 --> Language Class Initialized
ERROR - 2023-08-12 09:30:47 --> 404 Page Not Found: admin//index
INFO - 2023-08-12 09:30:48 --> Config Class Initialized
INFO - 2023-08-12 09:30:48 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:30:48 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:30:48 --> Utf8 Class Initialized
INFO - 2023-08-12 09:30:48 --> URI Class Initialized
INFO - 2023-08-12 09:30:48 --> Router Class Initialized
INFO - 2023-08-12 09:30:48 --> Output Class Initialized
INFO - 2023-08-12 09:30:48 --> Security Class Initialized
DEBUG - 2023-08-12 09:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:30:48 --> Input Class Initialized
INFO - 2023-08-12 09:30:48 --> Language Class Initialized
INFO - 2023-08-12 09:30:48 --> Loader Class Initialized
INFO - 2023-08-12 09:30:48 --> Helper loaded: url_helper
INFO - 2023-08-12 09:30:48 --> Helper loaded: file_helper
INFO - 2023-08-12 09:30:48 --> Database Driver Class Initialized
INFO - 2023-08-12 09:30:48 --> Email Class Initialized
DEBUG - 2023-08-12 09:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:30:48 --> Controller Class Initialized
INFO - 2023-08-12 09:30:48 --> Model "Banner_model" initialized
INFO - 2023-08-12 09:30:48 --> Helper loaded: form_helper
INFO - 2023-08-12 09:30:48 --> Form Validation Class Initialized
INFO - 2023-08-12 09:30:48 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-12 09:30:48 --> Final output sent to browser
DEBUG - 2023-08-12 09:30:48 --> Total execution time: 0.7709
INFO - 2023-08-12 09:30:50 --> Config Class Initialized
INFO - 2023-08-12 09:30:50 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:30:50 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:30:50 --> Utf8 Class Initialized
INFO - 2023-08-12 09:30:50 --> URI Class Initialized
INFO - 2023-08-12 09:30:50 --> Router Class Initialized
INFO - 2023-08-12 09:30:50 --> Output Class Initialized
INFO - 2023-08-12 09:30:50 --> Security Class Initialized
DEBUG - 2023-08-12 09:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:30:50 --> Input Class Initialized
INFO - 2023-08-12 09:30:50 --> Language Class Initialized
INFO - 2023-08-12 09:30:50 --> Loader Class Initialized
INFO - 2023-08-12 09:30:50 --> Helper loaded: url_helper
INFO - 2023-08-12 09:30:50 --> Helper loaded: file_helper
INFO - 2023-08-12 09:30:50 --> Database Driver Class Initialized
INFO - 2023-08-12 09:30:50 --> Email Class Initialized
DEBUG - 2023-08-12 09:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:30:50 --> Controller Class Initialized
INFO - 2023-08-12 09:30:50 --> Model "Gallery_model" initialized
INFO - 2023-08-12 09:30:50 --> Helper loaded: form_helper
INFO - 2023-08-12 09:30:50 --> Form Validation Class Initialized
INFO - 2023-08-12 09:30:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/gallery_list.php
INFO - 2023-08-12 09:30:51 --> Final output sent to browser
DEBUG - 2023-08-12 09:30:51 --> Total execution time: 0.3654
INFO - 2023-08-12 09:30:53 --> Config Class Initialized
INFO - 2023-08-12 09:30:53 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:30:53 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:30:53 --> Utf8 Class Initialized
INFO - 2023-08-12 09:30:53 --> URI Class Initialized
INFO - 2023-08-12 09:30:53 --> Router Class Initialized
INFO - 2023-08-12 09:30:53 --> Output Class Initialized
INFO - 2023-08-12 09:30:53 --> Security Class Initialized
DEBUG - 2023-08-12 09:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:30:53 --> Input Class Initialized
INFO - 2023-08-12 09:30:53 --> Language Class Initialized
INFO - 2023-08-12 09:30:53 --> Loader Class Initialized
INFO - 2023-08-12 09:30:53 --> Helper loaded: url_helper
INFO - 2023-08-12 09:30:53 --> Helper loaded: file_helper
INFO - 2023-08-12 09:30:53 --> Database Driver Class Initialized
INFO - 2023-08-12 09:30:53 --> Email Class Initialized
DEBUG - 2023-08-12 09:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:30:53 --> Controller Class Initialized
INFO - 2023-08-12 09:30:53 --> Model "Training_model" initialized
INFO - 2023-08-12 09:30:53 --> Helper loaded: form_helper
INFO - 2023-08-12 09:30:53 --> Form Validation Class Initialized
INFO - 2023-08-12 09:30:53 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-12 09:30:53 --> Final output sent to browser
DEBUG - 2023-08-12 09:30:53 --> Total execution time: 0.1344
INFO - 2023-08-12 09:30:54 --> Config Class Initialized
INFO - 2023-08-12 09:30:54 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:30:54 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:30:54 --> Utf8 Class Initialized
INFO - 2023-08-12 09:30:54 --> URI Class Initialized
INFO - 2023-08-12 09:30:54 --> Router Class Initialized
INFO - 2023-08-12 09:30:54 --> Output Class Initialized
INFO - 2023-08-12 09:30:54 --> Security Class Initialized
DEBUG - 2023-08-12 09:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:30:54 --> Input Class Initialized
INFO - 2023-08-12 09:30:54 --> Language Class Initialized
INFO - 2023-08-12 09:30:54 --> Loader Class Initialized
INFO - 2023-08-12 09:30:54 --> Helper loaded: url_helper
INFO - 2023-08-12 09:30:54 --> Helper loaded: file_helper
INFO - 2023-08-12 09:30:54 --> Database Driver Class Initialized
INFO - 2023-08-12 09:30:54 --> Email Class Initialized
DEBUG - 2023-08-12 09:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:30:54 --> Controller Class Initialized
INFO - 2023-08-12 09:30:54 --> Model "Testimonials_model" initialized
INFO - 2023-08-12 09:30:54 --> Helper loaded: form_helper
INFO - 2023-08-12 09:30:54 --> Form Validation Class Initialized
INFO - 2023-08-12 09:30:54 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/testimonials_list.php
INFO - 2023-08-12 09:30:54 --> Final output sent to browser
DEBUG - 2023-08-12 09:30:54 --> Total execution time: 0.0555
INFO - 2023-08-12 09:30:55 --> Config Class Initialized
INFO - 2023-08-12 09:30:55 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:30:55 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:30:55 --> Utf8 Class Initialized
INFO - 2023-08-12 09:30:55 --> URI Class Initialized
INFO - 2023-08-12 09:30:55 --> Router Class Initialized
INFO - 2023-08-12 09:30:55 --> Output Class Initialized
INFO - 2023-08-12 09:30:55 --> Security Class Initialized
DEBUG - 2023-08-12 09:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:30:55 --> Input Class Initialized
INFO - 2023-08-12 09:30:55 --> Language Class Initialized
INFO - 2023-08-12 09:30:55 --> Loader Class Initialized
INFO - 2023-08-12 09:30:55 --> Helper loaded: url_helper
INFO - 2023-08-12 09:30:55 --> Helper loaded: file_helper
INFO - 2023-08-12 09:30:55 --> Database Driver Class Initialized
INFO - 2023-08-12 09:30:55 --> Email Class Initialized
DEBUG - 2023-08-12 09:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:30:55 --> Controller Class Initialized
INFO - 2023-08-12 09:30:55 --> Model "Address_model" initialized
INFO - 2023-08-12 09:30:55 --> Helper loaded: form_helper
INFO - 2023-08-12 09:30:55 --> Form Validation Class Initialized
INFO - 2023-08-12 09:30:55 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/address_list.php
INFO - 2023-08-12 09:30:56 --> Final output sent to browser
DEBUG - 2023-08-12 09:30:56 --> Total execution time: 0.1656
INFO - 2023-08-12 09:30:57 --> Config Class Initialized
INFO - 2023-08-12 09:30:57 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:30:57 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:30:57 --> Utf8 Class Initialized
INFO - 2023-08-12 09:30:57 --> URI Class Initialized
INFO - 2023-08-12 09:30:57 --> Router Class Initialized
INFO - 2023-08-12 09:30:57 --> Output Class Initialized
INFO - 2023-08-12 09:30:57 --> Security Class Initialized
DEBUG - 2023-08-12 09:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:30:57 --> Input Class Initialized
INFO - 2023-08-12 09:30:57 --> Language Class Initialized
INFO - 2023-08-12 09:30:57 --> Loader Class Initialized
INFO - 2023-08-12 09:30:57 --> Helper loaded: url_helper
INFO - 2023-08-12 09:30:57 --> Helper loaded: file_helper
INFO - 2023-08-12 09:30:57 --> Database Driver Class Initialized
INFO - 2023-08-12 09:30:57 --> Email Class Initialized
DEBUG - 2023-08-12 09:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:30:57 --> Controller Class Initialized
INFO - 2023-08-12 09:30:57 --> Model "Contact_model" initialized
INFO - 2023-08-12 09:30:57 --> Helper loaded: form_helper
INFO - 2023-08-12 09:30:57 --> Form Validation Class Initialized
INFO - 2023-08-12 09:30:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_list.php
INFO - 2023-08-12 09:30:57 --> Final output sent to browser
DEBUG - 2023-08-12 09:30:57 --> Total execution time: 0.1346
INFO - 2023-08-12 09:31:00 --> Config Class Initialized
INFO - 2023-08-12 09:31:00 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:31:00 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:31:00 --> Utf8 Class Initialized
INFO - 2023-08-12 09:31:00 --> URI Class Initialized
INFO - 2023-08-12 09:31:00 --> Router Class Initialized
INFO - 2023-08-12 09:31:00 --> Output Class Initialized
INFO - 2023-08-12 09:31:00 --> Security Class Initialized
DEBUG - 2023-08-12 09:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:31:00 --> Input Class Initialized
INFO - 2023-08-12 09:31:00 --> Language Class Initialized
ERROR - 2023-08-12 09:31:00 --> 404 Page Not Found: admin/Apps/gallery.html
INFO - 2023-08-12 09:31:02 --> Config Class Initialized
INFO - 2023-08-12 09:31:02 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:31:02 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:31:02 --> Utf8 Class Initialized
INFO - 2023-08-12 09:31:02 --> URI Class Initialized
INFO - 2023-08-12 09:31:02 --> Router Class Initialized
INFO - 2023-08-12 09:31:02 --> Output Class Initialized
INFO - 2023-08-12 09:31:02 --> Security Class Initialized
DEBUG - 2023-08-12 09:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:31:02 --> Input Class Initialized
INFO - 2023-08-12 09:31:02 --> Language Class Initialized
INFO - 2023-08-12 09:31:02 --> Loader Class Initialized
INFO - 2023-08-12 09:31:02 --> Helper loaded: url_helper
INFO - 2023-08-12 09:31:02 --> Helper loaded: file_helper
INFO - 2023-08-12 09:31:02 --> Database Driver Class Initialized
INFO - 2023-08-12 09:31:02 --> Email Class Initialized
DEBUG - 2023-08-12 09:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:31:02 --> Controller Class Initialized
INFO - 2023-08-12 09:31:02 --> Model "Contact_model" initialized
INFO - 2023-08-12 09:31:02 --> Helper loaded: form_helper
INFO - 2023-08-12 09:31:02 --> Form Validation Class Initialized
INFO - 2023-08-12 09:31:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_list.php
INFO - 2023-08-12 09:31:02 --> Final output sent to browser
DEBUG - 2023-08-12 09:31:02 --> Total execution time: 0.0484
INFO - 2023-08-12 09:31:25 --> Config Class Initialized
INFO - 2023-08-12 09:31:25 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:31:25 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:31:25 --> Utf8 Class Initialized
INFO - 2023-08-12 09:31:25 --> URI Class Initialized
INFO - 2023-08-12 09:31:25 --> Router Class Initialized
INFO - 2023-08-12 09:31:25 --> Output Class Initialized
INFO - 2023-08-12 09:31:25 --> Security Class Initialized
DEBUG - 2023-08-12 09:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:31:25 --> Input Class Initialized
INFO - 2023-08-12 09:31:25 --> Language Class Initialized
ERROR - 2023-08-12 09:31:25 --> 404 Page Not Found: admin/Indexhtml/index
INFO - 2023-08-12 09:31:26 --> Config Class Initialized
INFO - 2023-08-12 09:31:26 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:31:26 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:31:26 --> Utf8 Class Initialized
INFO - 2023-08-12 09:31:26 --> URI Class Initialized
INFO - 2023-08-12 09:31:26 --> Router Class Initialized
INFO - 2023-08-12 09:31:26 --> Output Class Initialized
INFO - 2023-08-12 09:31:26 --> Security Class Initialized
DEBUG - 2023-08-12 09:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:31:26 --> Input Class Initialized
INFO - 2023-08-12 09:31:26 --> Language Class Initialized
INFO - 2023-08-12 09:31:26 --> Loader Class Initialized
INFO - 2023-08-12 09:31:26 --> Helper loaded: url_helper
INFO - 2023-08-12 09:31:26 --> Helper loaded: file_helper
INFO - 2023-08-12 09:31:26 --> Database Driver Class Initialized
INFO - 2023-08-12 09:31:26 --> Email Class Initialized
DEBUG - 2023-08-12 09:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:31:26 --> Controller Class Initialized
INFO - 2023-08-12 09:31:26 --> Model "Contact_model" initialized
INFO - 2023-08-12 09:31:26 --> Helper loaded: form_helper
INFO - 2023-08-12 09:31:26 --> Form Validation Class Initialized
INFO - 2023-08-12 09:31:26 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_list.php
INFO - 2023-08-12 09:31:27 --> Final output sent to browser
DEBUG - 2023-08-12 09:31:27 --> Total execution time: 0.0524
INFO - 2023-08-12 09:32:05 --> Config Class Initialized
INFO - 2023-08-12 09:32:05 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:32:05 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:32:05 --> Utf8 Class Initialized
INFO - 2023-08-12 09:32:05 --> URI Class Initialized
INFO - 2023-08-12 09:32:05 --> Router Class Initialized
INFO - 2023-08-12 09:32:05 --> Output Class Initialized
INFO - 2023-08-12 09:32:05 --> Security Class Initialized
DEBUG - 2023-08-12 09:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:32:05 --> Input Class Initialized
INFO - 2023-08-12 09:32:05 --> Language Class Initialized
INFO - 2023-08-12 09:32:05 --> Loader Class Initialized
INFO - 2023-08-12 09:32:05 --> Helper loaded: url_helper
INFO - 2023-08-12 09:32:05 --> Helper loaded: file_helper
INFO - 2023-08-12 09:32:05 --> Database Driver Class Initialized
INFO - 2023-08-12 09:32:05 --> Email Class Initialized
DEBUG - 2023-08-12 09:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:32:06 --> Controller Class Initialized
INFO - 2023-08-12 09:32:06 --> Model "Banner_model" initialized
INFO - 2023-08-12 09:32:06 --> Helper loaded: form_helper
INFO - 2023-08-12 09:32:06 --> Form Validation Class Initialized
INFO - 2023-08-12 09:32:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-12 09:32:06 --> Final output sent to browser
DEBUG - 2023-08-12 09:32:06 --> Total execution time: 0.3542
INFO - 2023-08-12 09:32:38 --> Config Class Initialized
INFO - 2023-08-12 09:32:38 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:32:38 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:32:38 --> Utf8 Class Initialized
INFO - 2023-08-12 09:32:38 --> URI Class Initialized
INFO - 2023-08-12 09:32:38 --> Router Class Initialized
INFO - 2023-08-12 09:32:38 --> Output Class Initialized
INFO - 2023-08-12 09:32:38 --> Security Class Initialized
DEBUG - 2023-08-12 09:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:32:38 --> Input Class Initialized
INFO - 2023-08-12 09:32:38 --> Language Class Initialized
ERROR - 2023-08-12 09:32:38 --> 404 Page Not Found: admin/Indexhtml/index
INFO - 2023-08-12 09:32:40 --> Config Class Initialized
INFO - 2023-08-12 09:32:40 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:32:40 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:32:40 --> Utf8 Class Initialized
INFO - 2023-08-12 09:32:40 --> URI Class Initialized
INFO - 2023-08-12 09:32:40 --> Router Class Initialized
INFO - 2023-08-12 09:32:40 --> Output Class Initialized
INFO - 2023-08-12 09:32:40 --> Security Class Initialized
DEBUG - 2023-08-12 09:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:32:40 --> Input Class Initialized
INFO - 2023-08-12 09:32:40 --> Language Class Initialized
INFO - 2023-08-12 09:32:40 --> Loader Class Initialized
INFO - 2023-08-12 09:32:40 --> Helper loaded: url_helper
INFO - 2023-08-12 09:32:40 --> Helper loaded: file_helper
INFO - 2023-08-12 09:32:40 --> Database Driver Class Initialized
INFO - 2023-08-12 09:32:40 --> Email Class Initialized
DEBUG - 2023-08-12 09:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:32:40 --> Controller Class Initialized
INFO - 2023-08-12 09:32:40 --> Model "Banner_model" initialized
INFO - 2023-08-12 09:32:40 --> Helper loaded: form_helper
INFO - 2023-08-12 09:32:40 --> Form Validation Class Initialized
INFO - 2023-08-12 09:32:40 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-12 09:32:40 --> Final output sent to browser
DEBUG - 2023-08-12 09:32:40 --> Total execution time: 0.0515
INFO - 2023-08-12 10:44:07 --> Config Class Initialized
INFO - 2023-08-12 10:44:07 --> Hooks Class Initialized
DEBUG - 2023-08-12 10:44:07 --> UTF-8 Support Enabled
INFO - 2023-08-12 10:44:07 --> Utf8 Class Initialized
INFO - 2023-08-12 10:44:07 --> URI Class Initialized
INFO - 2023-08-12 10:44:07 --> Router Class Initialized
INFO - 2023-08-12 10:44:07 --> Output Class Initialized
INFO - 2023-08-12 10:44:07 --> Security Class Initialized
DEBUG - 2023-08-12 10:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 10:44:07 --> Input Class Initialized
INFO - 2023-08-12 10:44:07 --> Language Class Initialized
ERROR - 2023-08-12 10:44:07 --> 404 Page Not Found: admin//index
INFO - 2023-08-12 10:44:35 --> Config Class Initialized
INFO - 2023-08-12 10:44:35 --> Hooks Class Initialized
DEBUG - 2023-08-12 10:44:35 --> UTF-8 Support Enabled
INFO - 2023-08-12 10:44:35 --> Utf8 Class Initialized
INFO - 2023-08-12 10:44:35 --> URI Class Initialized
INFO - 2023-08-12 10:44:35 --> Router Class Initialized
INFO - 2023-08-12 10:44:35 --> Output Class Initialized
INFO - 2023-08-12 10:44:35 --> Security Class Initialized
DEBUG - 2023-08-12 10:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 10:44:35 --> Input Class Initialized
INFO - 2023-08-12 10:44:35 --> Language Class Initialized
INFO - 2023-08-12 10:44:35 --> Loader Class Initialized
INFO - 2023-08-12 10:44:35 --> Helper loaded: url_helper
INFO - 2023-08-12 10:44:35 --> Helper loaded: file_helper
INFO - 2023-08-12 10:44:35 --> Database Driver Class Initialized
INFO - 2023-08-12 10:44:35 --> Email Class Initialized
DEBUG - 2023-08-12 10:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 10:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 10:44:35 --> Controller Class Initialized
INFO - 2023-08-12 10:44:35 --> Model "Banner_model" initialized
INFO - 2023-08-12 10:44:35 --> Helper loaded: form_helper
INFO - 2023-08-12 10:44:35 --> Form Validation Class Initialized
INFO - 2023-08-12 10:44:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-12 10:44:36 --> Final output sent to browser
DEBUG - 2023-08-12 10:44:36 --> Total execution time: 0.7479
INFO - 2023-08-12 10:44:38 --> Config Class Initialized
INFO - 2023-08-12 10:44:38 --> Hooks Class Initialized
DEBUG - 2023-08-12 10:44:38 --> UTF-8 Support Enabled
INFO - 2023-08-12 10:44:38 --> Utf8 Class Initialized
INFO - 2023-08-12 10:44:38 --> URI Class Initialized
INFO - 2023-08-12 10:44:38 --> Router Class Initialized
INFO - 2023-08-12 10:44:38 --> Output Class Initialized
INFO - 2023-08-12 10:44:38 --> Security Class Initialized
DEBUG - 2023-08-12 10:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 10:44:38 --> Input Class Initialized
INFO - 2023-08-12 10:44:38 --> Language Class Initialized
INFO - 2023-08-12 10:44:38 --> Loader Class Initialized
INFO - 2023-08-12 10:44:38 --> Helper loaded: url_helper
INFO - 2023-08-12 10:44:39 --> Helper loaded: file_helper
INFO - 2023-08-12 10:44:39 --> Database Driver Class Initialized
INFO - 2023-08-12 10:44:39 --> Email Class Initialized
DEBUG - 2023-08-12 10:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 10:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 10:44:39 --> Controller Class Initialized
INFO - 2023-08-12 10:44:39 --> Model "Blog_model" initialized
INFO - 2023-08-12 10:44:39 --> Helper loaded: form_helper
INFO - 2023-08-12 10:44:39 --> Form Validation Class Initialized
INFO - 2023-08-12 10:51:58 --> Config Class Initialized
INFO - 2023-08-12 10:51:58 --> Hooks Class Initialized
DEBUG - 2023-08-12 10:51:58 --> UTF-8 Support Enabled
INFO - 2023-08-12 10:51:58 --> Utf8 Class Initialized
INFO - 2023-08-12 10:51:58 --> URI Class Initialized
INFO - 2023-08-12 10:51:58 --> Router Class Initialized
INFO - 2023-08-12 10:51:58 --> Output Class Initialized
INFO - 2023-08-12 10:51:58 --> Security Class Initialized
DEBUG - 2023-08-12 10:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 10:51:58 --> Input Class Initialized
INFO - 2023-08-12 10:51:58 --> Language Class Initialized
INFO - 2023-08-12 10:51:58 --> Loader Class Initialized
INFO - 2023-08-12 10:51:58 --> Helper loaded: url_helper
INFO - 2023-08-12 10:51:58 --> Helper loaded: file_helper
INFO - 2023-08-12 10:51:58 --> Database Driver Class Initialized
INFO - 2023-08-12 10:51:58 --> Email Class Initialized
DEBUG - 2023-08-12 10:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 10:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 10:51:59 --> Controller Class Initialized
INFO - 2023-08-12 10:51:59 --> Model "Banner_model" initialized
INFO - 2023-08-12 10:51:59 --> Helper loaded: form_helper
INFO - 2023-08-12 10:51:59 --> Form Validation Class Initialized
INFO - 2023-08-12 10:51:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-12 10:51:59 --> Final output sent to browser
DEBUG - 2023-08-12 10:51:59 --> Total execution time: 0.2050
INFO - 2023-08-12 10:52:39 --> Config Class Initialized
INFO - 2023-08-12 10:52:39 --> Hooks Class Initialized
DEBUG - 2023-08-12 10:52:39 --> UTF-8 Support Enabled
INFO - 2023-08-12 10:52:39 --> Utf8 Class Initialized
INFO - 2023-08-12 10:52:39 --> URI Class Initialized
INFO - 2023-08-12 10:52:39 --> Router Class Initialized
INFO - 2023-08-12 10:52:39 --> Output Class Initialized
INFO - 2023-08-12 10:52:39 --> Security Class Initialized
DEBUG - 2023-08-12 10:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 10:52:39 --> Input Class Initialized
INFO - 2023-08-12 10:52:39 --> Language Class Initialized
INFO - 2023-08-12 10:52:39 --> Loader Class Initialized
INFO - 2023-08-12 10:52:39 --> Helper loaded: url_helper
INFO - 2023-08-12 10:52:39 --> Helper loaded: file_helper
INFO - 2023-08-12 10:52:39 --> Database Driver Class Initialized
INFO - 2023-08-12 10:52:39 --> Email Class Initialized
DEBUG - 2023-08-12 10:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 10:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 10:52:39 --> Controller Class Initialized
INFO - 2023-08-12 10:52:39 --> Model "Social_media_model" initialized
INFO - 2023-08-12 10:52:39 --> Helper loaded: form_helper
INFO - 2023-08-12 10:52:39 --> Form Validation Class Initialized
INFO - 2023-08-12 10:52:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-08-12 10:52:39 --> Final output sent to browser
DEBUG - 2023-08-12 10:52:39 --> Total execution time: 0.1199
INFO - 2023-08-12 10:52:39 --> Config Class Initialized
INFO - 2023-08-12 10:52:39 --> Hooks Class Initialized
DEBUG - 2023-08-12 10:52:39 --> UTF-8 Support Enabled
INFO - 2023-08-12 10:52:39 --> Utf8 Class Initialized
INFO - 2023-08-12 10:52:39 --> URI Class Initialized
INFO - 2023-08-12 10:52:39 --> Router Class Initialized
INFO - 2023-08-12 10:52:39 --> Output Class Initialized
INFO - 2023-08-12 10:52:39 --> Security Class Initialized
DEBUG - 2023-08-12 10:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 10:52:39 --> Input Class Initialized
INFO - 2023-08-12 10:52:39 --> Language Class Initialized
ERROR - 2023-08-12 10:52:39 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-08-12 10:53:10 --> Config Class Initialized
INFO - 2023-08-12 10:53:10 --> Hooks Class Initialized
DEBUG - 2023-08-12 10:53:10 --> UTF-8 Support Enabled
INFO - 2023-08-12 10:53:10 --> Utf8 Class Initialized
INFO - 2023-08-12 10:53:10 --> URI Class Initialized
INFO - 2023-08-12 10:53:10 --> Router Class Initialized
INFO - 2023-08-12 10:53:10 --> Output Class Initialized
INFO - 2023-08-12 10:53:10 --> Security Class Initialized
DEBUG - 2023-08-12 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 10:53:10 --> Input Class Initialized
INFO - 2023-08-12 10:53:10 --> Language Class Initialized
INFO - 2023-08-12 10:53:10 --> Loader Class Initialized
INFO - 2023-08-12 10:53:10 --> Helper loaded: url_helper
INFO - 2023-08-12 10:53:10 --> Helper loaded: file_helper
INFO - 2023-08-12 10:53:10 --> Database Driver Class Initialized
INFO - 2023-08-12 10:53:10 --> Email Class Initialized
DEBUG - 2023-08-12 10:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 10:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 10:53:10 --> Controller Class Initialized
INFO - 2023-08-12 10:53:10 --> Model "Banner_model" initialized
INFO - 2023-08-12 10:53:10 --> Helper loaded: form_helper
INFO - 2023-08-12 10:53:10 --> Form Validation Class Initialized
INFO - 2023-08-12 10:53:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-12 10:53:10 --> Final output sent to browser
DEBUG - 2023-08-12 10:53:10 --> Total execution time: 0.2275
INFO - 2023-08-12 10:53:12 --> Config Class Initialized
INFO - 2023-08-12 10:53:12 --> Hooks Class Initialized
DEBUG - 2023-08-12 10:53:12 --> UTF-8 Support Enabled
INFO - 2023-08-12 10:53:12 --> Utf8 Class Initialized
INFO - 2023-08-12 10:53:12 --> URI Class Initialized
INFO - 2023-08-12 10:53:12 --> Router Class Initialized
INFO - 2023-08-12 10:53:12 --> Output Class Initialized
INFO - 2023-08-12 10:53:12 --> Security Class Initialized
DEBUG - 2023-08-12 10:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 10:53:12 --> Input Class Initialized
INFO - 2023-08-12 10:53:12 --> Language Class Initialized
INFO - 2023-08-12 10:53:12 --> Loader Class Initialized
INFO - 2023-08-12 10:53:12 --> Helper loaded: url_helper
INFO - 2023-08-12 10:53:12 --> Helper loaded: file_helper
INFO - 2023-08-12 10:53:12 --> Database Driver Class Initialized
INFO - 2023-08-12 10:53:12 --> Email Class Initialized
DEBUG - 2023-08-12 10:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 10:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 10:53:12 --> Controller Class Initialized
INFO - 2023-08-12 10:53:12 --> Model "Banner_model" initialized
INFO - 2023-08-12 10:53:12 --> Helper loaded: form_helper
INFO - 2023-08-12 10:53:12 --> Form Validation Class Initialized
INFO - 2023-08-12 10:53:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_create.php
INFO - 2023-08-12 10:53:12 --> Final output sent to browser
DEBUG - 2023-08-12 10:53:12 --> Total execution time: 0.0668
INFO - 2023-08-12 10:53:12 --> Config Class Initialized
INFO - 2023-08-12 10:53:12 --> Hooks Class Initialized
DEBUG - 2023-08-12 10:53:12 --> UTF-8 Support Enabled
INFO - 2023-08-12 10:53:12 --> Utf8 Class Initialized
INFO - 2023-08-12 10:53:12 --> URI Class Initialized
INFO - 2023-08-12 10:53:12 --> Router Class Initialized
INFO - 2023-08-12 10:53:12 --> Output Class Initialized
INFO - 2023-08-12 10:53:12 --> Security Class Initialized
DEBUG - 2023-08-12 10:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 10:53:12 --> Input Class Initialized
INFO - 2023-08-12 10:53:12 --> Language Class Initialized
ERROR - 2023-08-12 10:53:12 --> 404 Page Not Found: admin/Banner/images
INFO - 2023-08-12 10:53:23 --> Config Class Initialized
INFO - 2023-08-12 10:53:23 --> Hooks Class Initialized
DEBUG - 2023-08-12 10:53:23 --> UTF-8 Support Enabled
INFO - 2023-08-12 10:53:23 --> Utf8 Class Initialized
INFO - 2023-08-12 10:53:23 --> URI Class Initialized
INFO - 2023-08-12 10:53:23 --> Router Class Initialized
INFO - 2023-08-12 10:53:23 --> Output Class Initialized
INFO - 2023-08-12 10:53:23 --> Security Class Initialized
DEBUG - 2023-08-12 10:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 10:53:23 --> Input Class Initialized
INFO - 2023-08-12 10:53:23 --> Language Class Initialized
INFO - 2023-08-12 10:53:23 --> Loader Class Initialized
INFO - 2023-08-12 10:53:23 --> Helper loaded: url_helper
INFO - 2023-08-12 10:53:23 --> Helper loaded: file_helper
INFO - 2023-08-12 10:53:23 --> Database Driver Class Initialized
INFO - 2023-08-12 10:53:23 --> Email Class Initialized
DEBUG - 2023-08-12 10:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 10:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 10:53:23 --> Controller Class Initialized
INFO - 2023-08-12 10:53:23 --> Model "Banner_model" initialized
INFO - 2023-08-12 10:53:23 --> Helper loaded: form_helper
INFO - 2023-08-12 10:53:23 --> Form Validation Class Initialized
INFO - 2023-08-12 10:53:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-12 10:53:23 --> Final output sent to browser
DEBUG - 2023-08-12 10:53:23 --> Total execution time: 0.0501
INFO - 2023-08-12 11:02:09 --> Config Class Initialized
INFO - 2023-08-12 11:02:09 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:02:09 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:02:09 --> Utf8 Class Initialized
INFO - 2023-08-12 11:02:09 --> URI Class Initialized
INFO - 2023-08-12 11:02:09 --> Router Class Initialized
INFO - 2023-08-12 11:02:09 --> Output Class Initialized
INFO - 2023-08-12 11:02:09 --> Security Class Initialized
DEBUG - 2023-08-12 11:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:02:09 --> Input Class Initialized
INFO - 2023-08-12 11:02:09 --> Language Class Initialized
INFO - 2023-08-12 11:02:09 --> Loader Class Initialized
INFO - 2023-08-12 11:02:09 --> Helper loaded: url_helper
INFO - 2023-08-12 11:02:09 --> Helper loaded: file_helper
INFO - 2023-08-12 11:02:09 --> Database Driver Class Initialized
INFO - 2023-08-12 11:02:09 --> Email Class Initialized
DEBUG - 2023-08-12 11:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:02:09 --> Controller Class Initialized
INFO - 2023-08-12 11:02:09 --> Model "Banner_model" initialized
INFO - 2023-08-12 11:02:09 --> Helper loaded: form_helper
INFO - 2023-08-12 11:02:09 --> Form Validation Class Initialized
INFO - 2023-08-12 11:02:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-12 11:02:10 --> Final output sent to browser
DEBUG - 2023-08-12 11:02:10 --> Total execution time: 0.0589
INFO - 2023-08-12 11:02:11 --> Config Class Initialized
INFO - 2023-08-12 11:02:11 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:02:11 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:02:11 --> Utf8 Class Initialized
INFO - 2023-08-12 11:02:11 --> URI Class Initialized
INFO - 2023-08-12 11:02:11 --> Router Class Initialized
INFO - 2023-08-12 11:02:11 --> Output Class Initialized
INFO - 2023-08-12 11:02:11 --> Security Class Initialized
DEBUG - 2023-08-12 11:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:02:11 --> Input Class Initialized
INFO - 2023-08-12 11:02:11 --> Language Class Initialized
INFO - 2023-08-12 11:02:11 --> Loader Class Initialized
INFO - 2023-08-12 11:02:11 --> Helper loaded: url_helper
INFO - 2023-08-12 11:02:11 --> Helper loaded: file_helper
INFO - 2023-08-12 11:02:11 --> Database Driver Class Initialized
INFO - 2023-08-12 11:02:11 --> Email Class Initialized
DEBUG - 2023-08-12 11:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:02:12 --> Controller Class Initialized
INFO - 2023-08-12 11:02:12 --> Model "Gallery_model" initialized
INFO - 2023-08-12 11:02:12 --> Helper loaded: form_helper
INFO - 2023-08-12 11:02:12 --> Form Validation Class Initialized
INFO - 2023-08-12 11:02:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/gallery_list.php
INFO - 2023-08-12 11:02:12 --> Final output sent to browser
DEBUG - 2023-08-12 11:02:12 --> Total execution time: 0.2752
INFO - 2023-08-12 11:02:13 --> Config Class Initialized
INFO - 2023-08-12 11:02:13 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:02:13 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:02:13 --> Utf8 Class Initialized
INFO - 2023-08-12 11:02:13 --> URI Class Initialized
INFO - 2023-08-12 11:02:13 --> Router Class Initialized
INFO - 2023-08-12 11:02:13 --> Output Class Initialized
INFO - 2023-08-12 11:02:13 --> Security Class Initialized
DEBUG - 2023-08-12 11:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:02:13 --> Input Class Initialized
INFO - 2023-08-12 11:02:13 --> Language Class Initialized
INFO - 2023-08-12 11:02:13 --> Loader Class Initialized
INFO - 2023-08-12 11:02:13 --> Helper loaded: url_helper
INFO - 2023-08-12 11:02:13 --> Helper loaded: file_helper
INFO - 2023-08-12 11:02:13 --> Database Driver Class Initialized
INFO - 2023-08-12 11:02:13 --> Email Class Initialized
DEBUG - 2023-08-12 11:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:02:13 --> Controller Class Initialized
INFO - 2023-08-12 11:02:13 --> Model "Training_model" initialized
INFO - 2023-08-12 11:02:13 --> Helper loaded: form_helper
INFO - 2023-08-12 11:02:13 --> Form Validation Class Initialized
INFO - 2023-08-12 11:02:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-12 11:02:13 --> Final output sent to browser
DEBUG - 2023-08-12 11:02:13 --> Total execution time: 0.0541
INFO - 2023-08-12 11:19:32 --> Config Class Initialized
INFO - 2023-08-12 11:19:32 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:19:32 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:19:32 --> Utf8 Class Initialized
INFO - 2023-08-12 11:19:32 --> URI Class Initialized
INFO - 2023-08-12 11:19:32 --> Router Class Initialized
INFO - 2023-08-12 11:19:32 --> Output Class Initialized
INFO - 2023-08-12 11:19:32 --> Security Class Initialized
DEBUG - 2023-08-12 11:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:19:32 --> Input Class Initialized
INFO - 2023-08-12 11:19:32 --> Language Class Initialized
INFO - 2023-08-12 11:19:32 --> Loader Class Initialized
INFO - 2023-08-12 11:19:32 --> Helper loaded: url_helper
INFO - 2023-08-12 11:19:32 --> Helper loaded: file_helper
INFO - 2023-08-12 11:19:32 --> Database Driver Class Initialized
INFO - 2023-08-12 11:19:32 --> Email Class Initialized
DEBUG - 2023-08-12 11:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:19:32 --> Controller Class Initialized
INFO - 2023-08-12 11:19:32 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:19:32 --> Helper loaded: form_helper
INFO - 2023-08-12 11:19:32 --> Form Validation Class Initialized
INFO - 2023-08-12 11:19:59 --> Config Class Initialized
INFO - 2023-08-12 11:19:59 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:19:59 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:19:59 --> Utf8 Class Initialized
INFO - 2023-08-12 11:19:59 --> URI Class Initialized
INFO - 2023-08-12 11:19:59 --> Router Class Initialized
INFO - 2023-08-12 11:19:59 --> Output Class Initialized
INFO - 2023-08-12 11:20:00 --> Security Class Initialized
DEBUG - 2023-08-12 11:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:20:00 --> Input Class Initialized
INFO - 2023-08-12 11:20:00 --> Language Class Initialized
INFO - 2023-08-12 11:20:00 --> Loader Class Initialized
INFO - 2023-08-12 11:20:00 --> Helper loaded: url_helper
INFO - 2023-08-12 11:20:00 --> Helper loaded: file_helper
INFO - 2023-08-12 11:20:00 --> Database Driver Class Initialized
INFO - 2023-08-12 11:20:00 --> Email Class Initialized
DEBUG - 2023-08-12 11:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:20:00 --> Controller Class Initialized
INFO - 2023-08-12 11:20:00 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:20:00 --> Helper loaded: form_helper
INFO - 2023-08-12 11:20:00 --> Form Validation Class Initialized
INFO - 2023-08-12 11:21:22 --> Config Class Initialized
INFO - 2023-08-12 11:21:22 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:21:23 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:21:23 --> Utf8 Class Initialized
INFO - 2023-08-12 11:21:23 --> URI Class Initialized
INFO - 2023-08-12 11:21:23 --> Router Class Initialized
INFO - 2023-08-12 11:21:23 --> Output Class Initialized
INFO - 2023-08-12 11:21:23 --> Security Class Initialized
DEBUG - 2023-08-12 11:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:21:23 --> Input Class Initialized
INFO - 2023-08-12 11:21:23 --> Language Class Initialized
INFO - 2023-08-12 11:21:23 --> Loader Class Initialized
INFO - 2023-08-12 11:21:23 --> Helper loaded: url_helper
INFO - 2023-08-12 11:21:23 --> Helper loaded: file_helper
INFO - 2023-08-12 11:21:23 --> Database Driver Class Initialized
INFO - 2023-08-12 11:21:23 --> Email Class Initialized
DEBUG - 2023-08-12 11:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:21:23 --> Controller Class Initialized
INFO - 2023-08-12 11:21:23 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:21:23 --> Helper loaded: form_helper
INFO - 2023-08-12 11:21:23 --> Form Validation Class Initialized
INFO - 2023-08-12 11:21:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-12 11:21:23 --> Final output sent to browser
DEBUG - 2023-08-12 11:21:23 --> Total execution time: 0.4513
INFO - 2023-08-12 11:21:26 --> Config Class Initialized
INFO - 2023-08-12 11:21:26 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:21:26 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:21:26 --> Utf8 Class Initialized
INFO - 2023-08-12 11:21:26 --> URI Class Initialized
INFO - 2023-08-12 11:21:26 --> Router Class Initialized
INFO - 2023-08-12 11:21:26 --> Output Class Initialized
INFO - 2023-08-12 11:21:26 --> Security Class Initialized
DEBUG - 2023-08-12 11:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:21:26 --> Input Class Initialized
INFO - 2023-08-12 11:21:26 --> Language Class Initialized
INFO - 2023-08-12 11:21:26 --> Loader Class Initialized
INFO - 2023-08-12 11:21:26 --> Helper loaded: url_helper
INFO - 2023-08-12 11:21:26 --> Helper loaded: file_helper
INFO - 2023-08-12 11:21:27 --> Database Driver Class Initialized
INFO - 2023-08-12 11:21:27 --> Email Class Initialized
DEBUG - 2023-08-12 11:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:21:27 --> Controller Class Initialized
INFO - 2023-08-12 11:21:27 --> Model "Banner_model" initialized
INFO - 2023-08-12 11:21:27 --> Helper loaded: form_helper
INFO - 2023-08-12 11:21:27 --> Form Validation Class Initialized
INFO - 2023-08-12 11:21:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_create.php
INFO - 2023-08-12 11:21:27 --> Final output sent to browser
DEBUG - 2023-08-12 11:21:27 --> Total execution time: 0.3110
INFO - 2023-08-12 11:21:31 --> Config Class Initialized
INFO - 2023-08-12 11:21:31 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:21:31 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:21:31 --> Utf8 Class Initialized
INFO - 2023-08-12 11:21:31 --> URI Class Initialized
INFO - 2023-08-12 11:21:31 --> Router Class Initialized
INFO - 2023-08-12 11:21:31 --> Output Class Initialized
INFO - 2023-08-12 11:21:31 --> Security Class Initialized
DEBUG - 2023-08-12 11:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:21:31 --> Input Class Initialized
INFO - 2023-08-12 11:21:31 --> Language Class Initialized
INFO - 2023-08-12 11:21:31 --> Loader Class Initialized
INFO - 2023-08-12 11:21:31 --> Helper loaded: url_helper
INFO - 2023-08-12 11:21:31 --> Helper loaded: file_helper
INFO - 2023-08-12 11:21:31 --> Database Driver Class Initialized
INFO - 2023-08-12 11:21:31 --> Email Class Initialized
DEBUG - 2023-08-12 11:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:21:32 --> Controller Class Initialized
INFO - 2023-08-12 11:21:32 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:21:32 --> Helper loaded: form_helper
INFO - 2023-08-12 11:21:32 --> Form Validation Class Initialized
INFO - 2023-08-12 11:21:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-08-12 11:21:32 --> Final output sent to browser
DEBUG - 2023-08-12 11:21:32 --> Total execution time: 0.4284
INFO - 2023-08-12 11:21:32 --> Config Class Initialized
INFO - 2023-08-12 11:21:32 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:21:32 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:21:32 --> Utf8 Class Initialized
INFO - 2023-08-12 11:21:32 --> URI Class Initialized
INFO - 2023-08-12 11:21:32 --> Router Class Initialized
INFO - 2023-08-12 11:21:32 --> Output Class Initialized
INFO - 2023-08-12 11:21:32 --> Security Class Initialized
DEBUG - 2023-08-12 11:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:21:32 --> Input Class Initialized
INFO - 2023-08-12 11:21:32 --> Language Class Initialized
ERROR - 2023-08-12 11:21:32 --> 404 Page Not Found: admin/Blog/images
INFO - 2023-08-12 11:22:08 --> Config Class Initialized
INFO - 2023-08-12 11:22:08 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:22:08 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:22:08 --> Utf8 Class Initialized
INFO - 2023-08-12 11:22:08 --> URI Class Initialized
INFO - 2023-08-12 11:22:08 --> Router Class Initialized
INFO - 2023-08-12 11:22:08 --> Output Class Initialized
INFO - 2023-08-12 11:22:08 --> Security Class Initialized
DEBUG - 2023-08-12 11:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:22:08 --> Input Class Initialized
INFO - 2023-08-12 11:22:08 --> Language Class Initialized
INFO - 2023-08-12 11:22:08 --> Loader Class Initialized
INFO - 2023-08-12 11:22:08 --> Helper loaded: url_helper
INFO - 2023-08-12 11:22:08 --> Helper loaded: file_helper
INFO - 2023-08-12 11:22:08 --> Database Driver Class Initialized
INFO - 2023-08-12 11:22:08 --> Email Class Initialized
DEBUG - 2023-08-12 11:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:22:08 --> Controller Class Initialized
INFO - 2023-08-12 11:22:08 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:22:08 --> Helper loaded: form_helper
INFO - 2023-08-12 11:22:08 --> Form Validation Class Initialized
INFO - 2023-08-12 11:22:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-12 11:22:08 --> Config Class Initialized
INFO - 2023-08-12 11:22:08 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:22:08 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:22:08 --> Utf8 Class Initialized
INFO - 2023-08-12 11:22:08 --> URI Class Initialized
INFO - 2023-08-12 11:22:08 --> Router Class Initialized
INFO - 2023-08-12 11:22:08 --> Output Class Initialized
INFO - 2023-08-12 11:22:09 --> Security Class Initialized
DEBUG - 2023-08-12 11:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:22:09 --> Input Class Initialized
INFO - 2023-08-12 11:22:09 --> Language Class Initialized
INFO - 2023-08-12 11:22:09 --> Loader Class Initialized
INFO - 2023-08-12 11:22:09 --> Helper loaded: url_helper
INFO - 2023-08-12 11:22:09 --> Helper loaded: file_helper
INFO - 2023-08-12 11:22:09 --> Database Driver Class Initialized
INFO - 2023-08-12 11:22:09 --> Email Class Initialized
DEBUG - 2023-08-12 11:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:22:09 --> Controller Class Initialized
INFO - 2023-08-12 11:22:09 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:22:09 --> Helper loaded: form_helper
INFO - 2023-08-12 11:22:09 --> Form Validation Class Initialized
ERROR - 2023-08-12 11:22:09 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\dw\application\views\admin\blog_list.php 72
INFO - 2023-08-12 11:22:54 --> Config Class Initialized
INFO - 2023-08-12 11:22:54 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:22:54 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:22:54 --> Utf8 Class Initialized
INFO - 2023-08-12 11:22:54 --> URI Class Initialized
INFO - 2023-08-12 11:22:54 --> Router Class Initialized
INFO - 2023-08-12 11:22:54 --> Output Class Initialized
INFO - 2023-08-12 11:22:54 --> Security Class Initialized
DEBUG - 2023-08-12 11:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:22:54 --> Input Class Initialized
INFO - 2023-08-12 11:22:54 --> Language Class Initialized
INFO - 2023-08-12 11:22:54 --> Loader Class Initialized
INFO - 2023-08-12 11:22:54 --> Helper loaded: url_helper
INFO - 2023-08-12 11:22:54 --> Helper loaded: file_helper
INFO - 2023-08-12 11:22:54 --> Database Driver Class Initialized
INFO - 2023-08-12 11:22:54 --> Email Class Initialized
DEBUG - 2023-08-12 11:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:22:54 --> Controller Class Initialized
INFO - 2023-08-12 11:22:54 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:22:54 --> Helper loaded: form_helper
INFO - 2023-08-12 11:22:54 --> Form Validation Class Initialized
INFO - 2023-08-12 11:22:54 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-12 11:22:54 --> Config Class Initialized
INFO - 2023-08-12 11:22:54 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:22:54 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:22:54 --> Utf8 Class Initialized
INFO - 2023-08-12 11:22:54 --> URI Class Initialized
INFO - 2023-08-12 11:22:54 --> Router Class Initialized
INFO - 2023-08-12 11:22:54 --> Output Class Initialized
INFO - 2023-08-12 11:22:54 --> Security Class Initialized
DEBUG - 2023-08-12 11:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:22:54 --> Input Class Initialized
INFO - 2023-08-12 11:22:54 --> Language Class Initialized
ERROR - 2023-08-12 11:22:54 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-12 11:22:54 --> Final output sent to browser
DEBUG - 2023-08-12 11:22:54 --> Total execution time: 0.2374
INFO - 2023-08-12 11:24:12 --> Config Class Initialized
INFO - 2023-08-12 11:24:12 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:24:12 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:24:12 --> Utf8 Class Initialized
INFO - 2023-08-12 11:24:12 --> URI Class Initialized
INFO - 2023-08-12 11:24:12 --> Router Class Initialized
INFO - 2023-08-12 11:24:12 --> Output Class Initialized
INFO - 2023-08-12 11:24:12 --> Security Class Initialized
DEBUG - 2023-08-12 11:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:24:12 --> Input Class Initialized
INFO - 2023-08-12 11:24:12 --> Language Class Initialized
INFO - 2023-08-12 11:24:12 --> Loader Class Initialized
INFO - 2023-08-12 11:24:12 --> Helper loaded: url_helper
INFO - 2023-08-12 11:24:12 --> Helper loaded: file_helper
INFO - 2023-08-12 11:24:12 --> Database Driver Class Initialized
INFO - 2023-08-12 11:24:12 --> Email Class Initialized
DEBUG - 2023-08-12 11:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:24:12 --> Controller Class Initialized
INFO - 2023-08-12 11:24:12 --> Model "Banner_model" initialized
INFO - 2023-08-12 11:24:12 --> Helper loaded: form_helper
INFO - 2023-08-12 11:24:12 --> Form Validation Class Initialized
INFO - 2023-08-12 11:24:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_create.php
INFO - 2023-08-12 11:24:12 --> Final output sent to browser
DEBUG - 2023-08-12 11:24:12 --> Total execution time: 0.2292
INFO - 2023-08-12 11:24:15 --> Config Class Initialized
INFO - 2023-08-12 11:24:15 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:24:15 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:24:15 --> Utf8 Class Initialized
INFO - 2023-08-12 11:24:15 --> URI Class Initialized
INFO - 2023-08-12 11:24:15 --> Router Class Initialized
INFO - 2023-08-12 11:24:15 --> Output Class Initialized
INFO - 2023-08-12 11:24:15 --> Security Class Initialized
DEBUG - 2023-08-12 11:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:24:15 --> Input Class Initialized
INFO - 2023-08-12 11:24:15 --> Language Class Initialized
INFO - 2023-08-12 11:24:31 --> Config Class Initialized
INFO - 2023-08-12 11:24:31 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:24:31 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:24:31 --> Utf8 Class Initialized
INFO - 2023-08-12 11:24:31 --> URI Class Initialized
INFO - 2023-08-12 11:24:31 --> Router Class Initialized
INFO - 2023-08-12 11:24:31 --> Output Class Initialized
INFO - 2023-08-12 11:24:31 --> Security Class Initialized
DEBUG - 2023-08-12 11:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:24:31 --> Input Class Initialized
INFO - 2023-08-12 11:24:31 --> Language Class Initialized
INFO - 2023-08-12 11:24:31 --> Loader Class Initialized
INFO - 2023-08-12 11:24:31 --> Helper loaded: url_helper
INFO - 2023-08-12 11:24:31 --> Helper loaded: file_helper
INFO - 2023-08-12 11:24:31 --> Database Driver Class Initialized
INFO - 2023-08-12 11:24:31 --> Email Class Initialized
DEBUG - 2023-08-12 11:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:24:31 --> Controller Class Initialized
INFO - 2023-08-12 11:24:31 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:24:31 --> Helper loaded: form_helper
INFO - 2023-08-12 11:24:31 --> Form Validation Class Initialized
INFO - 2023-08-12 11:24:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-12 11:24:32 --> Config Class Initialized
INFO - 2023-08-12 11:24:32 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:24:32 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:24:32 --> Utf8 Class Initialized
INFO - 2023-08-12 11:24:32 --> URI Class Initialized
INFO - 2023-08-12 11:24:32 --> Router Class Initialized
INFO - 2023-08-12 11:24:32 --> Output Class Initialized
INFO - 2023-08-12 11:24:32 --> Security Class Initialized
DEBUG - 2023-08-12 11:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:24:32 --> Input Class Initialized
INFO - 2023-08-12 11:24:32 --> Language Class Initialized
INFO - 2023-08-12 11:24:32 --> Loader Class Initialized
INFO - 2023-08-12 11:24:32 --> Helper loaded: url_helper
INFO - 2023-08-12 11:24:32 --> Helper loaded: file_helper
INFO - 2023-08-12 11:24:32 --> Database Driver Class Initialized
INFO - 2023-08-12 11:24:32 --> Email Class Initialized
DEBUG - 2023-08-12 11:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:24:32 --> Controller Class Initialized
INFO - 2023-08-12 11:24:32 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:24:32 --> Helper loaded: form_helper
INFO - 2023-08-12 11:24:32 --> Form Validation Class Initialized
INFO - 2023-08-12 11:24:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-12 11:24:32 --> Final output sent to browser
DEBUG - 2023-08-12 11:24:32 --> Total execution time: 0.6975
INFO - 2023-08-12 11:24:32 --> Config Class Initialized
INFO - 2023-08-12 11:24:32 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:24:32 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:24:32 --> Utf8 Class Initialized
INFO - 2023-08-12 11:24:32 --> URI Class Initialized
INFO - 2023-08-12 11:24:33 --> Router Class Initialized
INFO - 2023-08-12 11:24:33 --> Output Class Initialized
INFO - 2023-08-12 11:24:33 --> Security Class Initialized
DEBUG - 2023-08-12 11:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:24:33 --> Input Class Initialized
INFO - 2023-08-12 11:24:33 --> Language Class Initialized
ERROR - 2023-08-12 11:24:33 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-12 11:24:35 --> Config Class Initialized
INFO - 2023-08-12 11:24:36 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:24:36 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:24:36 --> Utf8 Class Initialized
INFO - 2023-08-12 11:24:36 --> URI Class Initialized
INFO - 2023-08-12 11:24:36 --> Router Class Initialized
INFO - 2023-08-12 11:24:36 --> Output Class Initialized
INFO - 2023-08-12 11:24:36 --> Security Class Initialized
DEBUG - 2023-08-12 11:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:24:36 --> Input Class Initialized
INFO - 2023-08-12 11:24:36 --> Language Class Initialized
INFO - 2023-08-12 11:24:36 --> Loader Class Initialized
INFO - 2023-08-12 11:24:36 --> Helper loaded: url_helper
INFO - 2023-08-12 11:24:36 --> Helper loaded: file_helper
INFO - 2023-08-12 11:24:36 --> Database Driver Class Initialized
INFO - 2023-08-12 11:24:36 --> Email Class Initialized
DEBUG - 2023-08-12 11:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:24:36 --> Controller Class Initialized
INFO - 2023-08-12 11:24:36 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:24:36 --> Helper loaded: form_helper
INFO - 2023-08-12 11:24:36 --> Form Validation Class Initialized
ERROR - 2023-08-12 11:24:36 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
INFO - 2023-08-12 11:24:36 --> Config Class Initialized
INFO - 2023-08-12 11:24:36 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:24:36 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:24:36 --> Utf8 Class Initialized
INFO - 2023-08-12 11:24:36 --> URI Class Initialized
INFO - 2023-08-12 11:24:36 --> Router Class Initialized
INFO - 2023-08-12 11:24:36 --> Output Class Initialized
INFO - 2023-08-12 11:24:36 --> Security Class Initialized
DEBUG - 2023-08-12 11:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:24:36 --> Input Class Initialized
INFO - 2023-08-12 11:24:36 --> Language Class Initialized
INFO - 2023-08-12 11:24:36 --> Loader Class Initialized
INFO - 2023-08-12 11:24:36 --> Helper loaded: url_helper
INFO - 2023-08-12 11:24:36 --> Helper loaded: file_helper
INFO - 2023-08-12 11:24:36 --> Database Driver Class Initialized
INFO - 2023-08-12 11:24:37 --> Email Class Initialized
DEBUG - 2023-08-12 11:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:24:37 --> Controller Class Initialized
INFO - 2023-08-12 11:24:37 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:24:37 --> Helper loaded: form_helper
INFO - 2023-08-12 11:24:37 --> Form Validation Class Initialized
ERROR - 2023-08-12 11:24:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-08-12 11:24:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-08-12 11:24:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-08-12 11:24:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-08-12 11:24:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-08-12 11:24:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-08-12 11:24:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-08-12 11:24:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
INFO - 2023-08-12 11:24:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:24:37 --> Final output sent to browser
DEBUG - 2023-08-12 11:24:37 --> Total execution time: 0.5798
INFO - 2023-08-12 11:25:02 --> Config Class Initialized
INFO - 2023-08-12 11:25:02 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:25:02 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:25:02 --> Utf8 Class Initialized
INFO - 2023-08-12 11:25:02 --> URI Class Initialized
INFO - 2023-08-12 11:25:02 --> Router Class Initialized
INFO - 2023-08-12 11:25:02 --> Output Class Initialized
INFO - 2023-08-12 11:25:02 --> Security Class Initialized
DEBUG - 2023-08-12 11:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:25:02 --> Input Class Initialized
INFO - 2023-08-12 11:25:02 --> Language Class Initialized
INFO - 2023-08-12 11:25:02 --> Loader Class Initialized
INFO - 2023-08-12 11:25:02 --> Helper loaded: url_helper
INFO - 2023-08-12 11:25:02 --> Helper loaded: file_helper
INFO - 2023-08-12 11:25:02 --> Database Driver Class Initialized
INFO - 2023-08-12 11:25:02 --> Email Class Initialized
DEBUG - 2023-08-12 11:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:25:02 --> Controller Class Initialized
INFO - 2023-08-12 11:25:02 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:25:02 --> Helper loaded: form_helper
INFO - 2023-08-12 11:25:02 --> Form Validation Class Initialized
INFO - 2023-08-12 11:25:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:25:03 --> Final output sent to browser
DEBUG - 2023-08-12 11:25:03 --> Total execution time: 0.3937
INFO - 2023-08-12 11:25:03 --> Config Class Initialized
INFO - 2023-08-12 11:25:03 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:25:03 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:25:03 --> Utf8 Class Initialized
INFO - 2023-08-12 11:25:03 --> URI Class Initialized
INFO - 2023-08-12 11:25:03 --> Router Class Initialized
INFO - 2023-08-12 11:25:03 --> Output Class Initialized
INFO - 2023-08-12 11:25:03 --> Security Class Initialized
DEBUG - 2023-08-12 11:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:25:03 --> Input Class Initialized
INFO - 2023-08-12 11:25:03 --> Language Class Initialized
INFO - 2023-08-12 11:25:03 --> Loader Class Initialized
INFO - 2023-08-12 11:25:03 --> Helper loaded: url_helper
INFO - 2023-08-12 11:25:04 --> Helper loaded: file_helper
INFO - 2023-08-12 11:25:04 --> Database Driver Class Initialized
INFO - 2023-08-12 11:25:04 --> Email Class Initialized
DEBUG - 2023-08-12 11:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:25:04 --> Controller Class Initialized
INFO - 2023-08-12 11:25:04 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:25:04 --> Helper loaded: form_helper
INFO - 2023-08-12 11:25:04 --> Form Validation Class Initialized
ERROR - 2023-08-12 11:25:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-08-12 11:25:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-08-12 11:25:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-08-12 11:25:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-08-12 11:25:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-08-12 11:25:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-08-12 11:25:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-08-12 11:25:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
INFO - 2023-08-12 11:25:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:25:04 --> Final output sent to browser
DEBUG - 2023-08-12 11:25:04 --> Total execution time: 0.9865
INFO - 2023-08-12 11:25:10 --> Config Class Initialized
INFO - 2023-08-12 11:25:10 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:25:10 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:25:10 --> Utf8 Class Initialized
INFO - 2023-08-12 11:25:10 --> URI Class Initialized
INFO - 2023-08-12 11:25:11 --> Router Class Initialized
INFO - 2023-08-12 11:25:11 --> Output Class Initialized
INFO - 2023-08-12 11:25:11 --> Security Class Initialized
DEBUG - 2023-08-12 11:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:25:11 --> Input Class Initialized
INFO - 2023-08-12 11:25:11 --> Language Class Initialized
INFO - 2023-08-12 11:25:11 --> Loader Class Initialized
INFO - 2023-08-12 11:25:11 --> Helper loaded: url_helper
INFO - 2023-08-12 11:25:11 --> Helper loaded: file_helper
INFO - 2023-08-12 11:25:11 --> Database Driver Class Initialized
INFO - 2023-08-12 11:25:11 --> Email Class Initialized
DEBUG - 2023-08-12 11:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:25:11 --> Controller Class Initialized
INFO - 2023-08-12 11:25:11 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:25:11 --> Helper loaded: form_helper
INFO - 2023-08-12 11:25:11 --> Form Validation Class Initialized
INFO - 2023-08-12 11:25:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-12 11:25:11 --> Config Class Initialized
INFO - 2023-08-12 11:25:11 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:25:11 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:25:11 --> Utf8 Class Initialized
INFO - 2023-08-12 11:25:11 --> URI Class Initialized
INFO - 2023-08-12 11:25:11 --> Router Class Initialized
INFO - 2023-08-12 11:25:11 --> Output Class Initialized
INFO - 2023-08-12 11:25:11 --> Security Class Initialized
DEBUG - 2023-08-12 11:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:25:11 --> Input Class Initialized
INFO - 2023-08-12 11:25:11 --> Language Class Initialized
INFO - 2023-08-12 11:25:11 --> Loader Class Initialized
INFO - 2023-08-12 11:25:11 --> Helper loaded: url_helper
INFO - 2023-08-12 11:25:11 --> Helper loaded: file_helper
INFO - 2023-08-12 11:25:11 --> Database Driver Class Initialized
INFO - 2023-08-12 11:25:11 --> Email Class Initialized
DEBUG - 2023-08-12 11:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:25:11 --> Controller Class Initialized
INFO - 2023-08-12 11:25:11 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:25:11 --> Helper loaded: form_helper
INFO - 2023-08-12 11:25:11 --> Form Validation Class Initialized
INFO - 2023-08-12 11:25:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-12 11:25:12 --> Config Class Initialized
INFO - 2023-08-12 11:25:12 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:25:12 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:25:12 --> Final output sent to browser
INFO - 2023-08-12 11:25:12 --> Utf8 Class Initialized
INFO - 2023-08-12 11:25:12 --> URI Class Initialized
DEBUG - 2023-08-12 11:25:12 --> Total execution time: 0.6000
INFO - 2023-08-12 11:25:12 --> Router Class Initialized
INFO - 2023-08-12 11:25:12 --> Output Class Initialized
INFO - 2023-08-12 11:25:12 --> Security Class Initialized
DEBUG - 2023-08-12 11:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:25:12 --> Input Class Initialized
INFO - 2023-08-12 11:25:12 --> Language Class Initialized
ERROR - 2023-08-12 11:25:12 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-12 11:27:34 --> Config Class Initialized
INFO - 2023-08-12 11:27:34 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:27:34 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:27:34 --> Utf8 Class Initialized
INFO - 2023-08-12 11:27:34 --> URI Class Initialized
INFO - 2023-08-12 11:27:34 --> Router Class Initialized
INFO - 2023-08-12 11:27:34 --> Output Class Initialized
INFO - 2023-08-12 11:27:34 --> Security Class Initialized
DEBUG - 2023-08-12 11:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:27:34 --> Input Class Initialized
INFO - 2023-08-12 11:27:34 --> Language Class Initialized
INFO - 2023-08-12 11:27:34 --> Loader Class Initialized
INFO - 2023-08-12 11:27:34 --> Helper loaded: url_helper
INFO - 2023-08-12 11:27:34 --> Helper loaded: file_helper
INFO - 2023-08-12 11:27:34 --> Database Driver Class Initialized
INFO - 2023-08-12 11:27:34 --> Email Class Initialized
DEBUG - 2023-08-12 11:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:27:34 --> Controller Class Initialized
INFO - 2023-08-12 11:27:34 --> Model "Banner_model" initialized
INFO - 2023-08-12 11:27:34 --> Helper loaded: form_helper
INFO - 2023-08-12 11:27:34 --> Form Validation Class Initialized
INFO - 2023-08-12 11:27:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_create.php
INFO - 2023-08-12 11:27:34 --> Final output sent to browser
DEBUG - 2023-08-12 11:27:34 --> Total execution time: 0.4019
INFO - 2023-08-12 11:27:48 --> Config Class Initialized
INFO - 2023-08-12 11:27:48 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:27:48 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:27:48 --> Utf8 Class Initialized
INFO - 2023-08-12 11:27:48 --> URI Class Initialized
INFO - 2023-08-12 11:27:48 --> Router Class Initialized
INFO - 2023-08-12 11:27:48 --> Output Class Initialized
INFO - 2023-08-12 11:27:48 --> Security Class Initialized
DEBUG - 2023-08-12 11:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:27:48 --> Input Class Initialized
INFO - 2023-08-12 11:27:48 --> Language Class Initialized
INFO - 2023-08-12 11:27:48 --> Loader Class Initialized
INFO - 2023-08-12 11:27:48 --> Helper loaded: url_helper
INFO - 2023-08-12 11:27:48 --> Helper loaded: file_helper
INFO - 2023-08-12 11:27:48 --> Database Driver Class Initialized
INFO - 2023-08-12 11:27:48 --> Email Class Initialized
DEBUG - 2023-08-12 11:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:27:48 --> Controller Class Initialized
INFO - 2023-08-12 11:27:48 --> Model "Banner_model" initialized
INFO - 2023-08-12 11:27:48 --> Helper loaded: form_helper
INFO - 2023-08-12 11:27:48 --> Form Validation Class Initialized
INFO - 2023-08-12 11:27:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-12 11:27:49 --> Config Class Initialized
INFO - 2023-08-12 11:27:49 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:27:49 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:27:49 --> Utf8 Class Initialized
INFO - 2023-08-12 11:27:49 --> URI Class Initialized
INFO - 2023-08-12 11:27:49 --> Router Class Initialized
INFO - 2023-08-12 11:27:49 --> Output Class Initialized
INFO - 2023-08-12 11:27:49 --> Security Class Initialized
DEBUG - 2023-08-12 11:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:27:49 --> Input Class Initialized
INFO - 2023-08-12 11:27:49 --> Language Class Initialized
INFO - 2023-08-12 11:27:49 --> Loader Class Initialized
INFO - 2023-08-12 11:27:49 --> Helper loaded: url_helper
INFO - 2023-08-12 11:27:49 --> Helper loaded: file_helper
INFO - 2023-08-12 11:27:49 --> Database Driver Class Initialized
INFO - 2023-08-12 11:27:49 --> Email Class Initialized
DEBUG - 2023-08-12 11:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:27:49 --> Controller Class Initialized
INFO - 2023-08-12 11:27:49 --> Model "Banner_model" initialized
INFO - 2023-08-12 11:27:49 --> Helper loaded: form_helper
INFO - 2023-08-12 11:27:49 --> Form Validation Class Initialized
INFO - 2023-08-12 11:27:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-12 11:27:50 --> Final output sent to browser
DEBUG - 2023-08-12 11:27:50 --> Total execution time: 0.8666
INFO - 2023-08-12 11:27:53 --> Config Class Initialized
INFO - 2023-08-12 11:27:53 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:27:54 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:27:54 --> Utf8 Class Initialized
INFO - 2023-08-12 11:27:54 --> URI Class Initialized
INFO - 2023-08-12 11:27:54 --> Router Class Initialized
INFO - 2023-08-12 11:27:54 --> Output Class Initialized
INFO - 2023-08-12 11:27:54 --> Security Class Initialized
DEBUG - 2023-08-12 11:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:27:54 --> Input Class Initialized
INFO - 2023-08-12 11:27:54 --> Language Class Initialized
INFO - 2023-08-12 11:27:54 --> Loader Class Initialized
INFO - 2023-08-12 11:27:54 --> Helper loaded: url_helper
INFO - 2023-08-12 11:27:54 --> Helper loaded: file_helper
INFO - 2023-08-12 11:27:54 --> Database Driver Class Initialized
INFO - 2023-08-12 11:27:54 --> Email Class Initialized
DEBUG - 2023-08-12 11:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:27:54 --> Controller Class Initialized
INFO - 2023-08-12 11:27:54 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:27:54 --> Helper loaded: form_helper
INFO - 2023-08-12 11:27:54 --> Form Validation Class Initialized
INFO - 2023-08-12 11:27:54 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-12 11:27:55 --> Final output sent to browser
DEBUG - 2023-08-12 11:27:55 --> Total execution time: 1.1056
INFO - 2023-08-12 11:27:55 --> Config Class Initialized
INFO - 2023-08-12 11:27:55 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:27:55 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:27:55 --> Utf8 Class Initialized
INFO - 2023-08-12 11:27:55 --> URI Class Initialized
INFO - 2023-08-12 11:27:55 --> Router Class Initialized
INFO - 2023-08-12 11:27:55 --> Output Class Initialized
INFO - 2023-08-12 11:27:55 --> Security Class Initialized
DEBUG - 2023-08-12 11:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:27:55 --> Input Class Initialized
INFO - 2023-08-12 11:27:55 --> Language Class Initialized
ERROR - 2023-08-12 11:27:55 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-12 11:27:56 --> Config Class Initialized
INFO - 2023-08-12 11:27:56 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:27:56 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:27:56 --> Utf8 Class Initialized
INFO - 2023-08-12 11:27:56 --> URI Class Initialized
INFO - 2023-08-12 11:27:56 --> Router Class Initialized
INFO - 2023-08-12 11:27:56 --> Output Class Initialized
INFO - 2023-08-12 11:27:56 --> Security Class Initialized
DEBUG - 2023-08-12 11:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:27:56 --> Input Class Initialized
INFO - 2023-08-12 11:27:56 --> Language Class Initialized
INFO - 2023-08-12 11:27:57 --> Loader Class Initialized
INFO - 2023-08-12 11:27:57 --> Helper loaded: url_helper
INFO - 2023-08-12 11:27:57 --> Helper loaded: file_helper
INFO - 2023-08-12 11:27:57 --> Database Driver Class Initialized
INFO - 2023-08-12 11:27:57 --> Email Class Initialized
DEBUG - 2023-08-12 11:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:27:57 --> Controller Class Initialized
INFO - 2023-08-12 11:27:57 --> Model "Banner_model" initialized
INFO - 2023-08-12 11:27:57 --> Helper loaded: form_helper
INFO - 2023-08-12 11:27:57 --> Form Validation Class Initialized
INFO - 2023-08-12 11:27:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_create.php
INFO - 2023-08-12 11:27:57 --> Final output sent to browser
DEBUG - 2023-08-12 11:27:57 --> Total execution time: 0.4002
INFO - 2023-08-12 11:28:00 --> Config Class Initialized
INFO - 2023-08-12 11:28:00 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:28:00 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:28:00 --> Utf8 Class Initialized
INFO - 2023-08-12 11:28:00 --> URI Class Initialized
INFO - 2023-08-12 11:28:00 --> Router Class Initialized
INFO - 2023-08-12 11:28:00 --> Output Class Initialized
INFO - 2023-08-12 11:28:00 --> Security Class Initialized
DEBUG - 2023-08-12 11:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:28:00 --> Input Class Initialized
INFO - 2023-08-12 11:28:00 --> Language Class Initialized
INFO - 2023-08-12 11:28:00 --> Loader Class Initialized
INFO - 2023-08-12 11:28:00 --> Helper loaded: url_helper
INFO - 2023-08-12 11:28:00 --> Helper loaded: file_helper
INFO - 2023-08-12 11:28:00 --> Database Driver Class Initialized
INFO - 2023-08-12 11:28:00 --> Email Class Initialized
DEBUG - 2023-08-12 11:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:28:00 --> Controller Class Initialized
INFO - 2023-08-12 11:28:00 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:28:00 --> Helper loaded: form_helper
INFO - 2023-08-12 11:28:00 --> Form Validation Class Initialized
INFO - 2023-08-12 11:28:00 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-08-12 11:28:00 --> Final output sent to browser
DEBUG - 2023-08-12 11:28:00 --> Total execution time: 0.3784
INFO - 2023-08-12 11:29:05 --> Config Class Initialized
INFO - 2023-08-12 11:29:05 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:29:05 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:29:05 --> Utf8 Class Initialized
INFO - 2023-08-12 11:29:05 --> URI Class Initialized
INFO - 2023-08-12 11:29:05 --> Router Class Initialized
INFO - 2023-08-12 11:29:05 --> Output Class Initialized
INFO - 2023-08-12 11:29:05 --> Security Class Initialized
DEBUG - 2023-08-12 11:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:29:05 --> Input Class Initialized
INFO - 2023-08-12 11:29:05 --> Language Class Initialized
INFO - 2023-08-12 11:29:05 --> Loader Class Initialized
INFO - 2023-08-12 11:29:05 --> Helper loaded: url_helper
INFO - 2023-08-12 11:29:05 --> Helper loaded: file_helper
INFO - 2023-08-12 11:29:05 --> Database Driver Class Initialized
INFO - 2023-08-12 11:29:05 --> Email Class Initialized
DEBUG - 2023-08-12 11:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:29:05 --> Controller Class Initialized
INFO - 2023-08-12 11:29:05 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:29:05 --> Helper loaded: form_helper
INFO - 2023-08-12 11:29:05 --> Form Validation Class Initialized
INFO - 2023-08-12 11:29:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-08-12 11:29:05 --> Final output sent to browser
DEBUG - 2023-08-12 11:29:05 --> Total execution time: 0.4970
INFO - 2023-08-12 11:29:14 --> Config Class Initialized
INFO - 2023-08-12 11:29:14 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:29:14 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:29:14 --> Utf8 Class Initialized
INFO - 2023-08-12 11:29:14 --> URI Class Initialized
INFO - 2023-08-12 11:29:14 --> Router Class Initialized
INFO - 2023-08-12 11:29:14 --> Output Class Initialized
INFO - 2023-08-12 11:29:14 --> Security Class Initialized
DEBUG - 2023-08-12 11:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:29:15 --> Input Class Initialized
INFO - 2023-08-12 11:29:15 --> Language Class Initialized
INFO - 2023-08-12 11:29:15 --> Loader Class Initialized
INFO - 2023-08-12 11:29:15 --> Helper loaded: url_helper
INFO - 2023-08-12 11:29:15 --> Helper loaded: file_helper
INFO - 2023-08-12 11:29:15 --> Database Driver Class Initialized
INFO - 2023-08-12 11:29:15 --> Email Class Initialized
DEBUG - 2023-08-12 11:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:29:15 --> Controller Class Initialized
INFO - 2023-08-12 11:29:15 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:29:15 --> Helper loaded: form_helper
INFO - 2023-08-12 11:29:15 --> Form Validation Class Initialized
INFO - 2023-08-12 11:29:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-12 11:29:15 --> Config Class Initialized
INFO - 2023-08-12 11:29:15 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:29:15 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:29:15 --> Utf8 Class Initialized
INFO - 2023-08-12 11:29:15 --> URI Class Initialized
INFO - 2023-08-12 11:29:15 --> Router Class Initialized
INFO - 2023-08-12 11:29:15 --> Output Class Initialized
INFO - 2023-08-12 11:29:15 --> Security Class Initialized
DEBUG - 2023-08-12 11:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:29:15 --> Input Class Initialized
INFO - 2023-08-12 11:29:15 --> Language Class Initialized
INFO - 2023-08-12 11:29:15 --> Loader Class Initialized
INFO - 2023-08-12 11:29:15 --> Helper loaded: url_helper
INFO - 2023-08-12 11:29:15 --> Helper loaded: file_helper
INFO - 2023-08-12 11:29:15 --> Database Driver Class Initialized
INFO - 2023-08-12 11:29:15 --> Email Class Initialized
DEBUG - 2023-08-12 11:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:29:15 --> Controller Class Initialized
INFO - 2023-08-12 11:29:15 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:29:15 --> Helper loaded: form_helper
INFO - 2023-08-12 11:29:15 --> Form Validation Class Initialized
INFO - 2023-08-12 11:29:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-12 11:29:16 --> Final output sent to browser
DEBUG - 2023-08-12 11:29:16 --> Total execution time: 0.3943
INFO - 2023-08-12 11:29:16 --> Config Class Initialized
INFO - 2023-08-12 11:29:16 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:29:16 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:29:16 --> Utf8 Class Initialized
INFO - 2023-08-12 11:29:16 --> URI Class Initialized
INFO - 2023-08-12 11:29:16 --> Router Class Initialized
INFO - 2023-08-12 11:29:16 --> Output Class Initialized
INFO - 2023-08-12 11:29:16 --> Security Class Initialized
DEBUG - 2023-08-12 11:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:29:16 --> Input Class Initialized
INFO - 2023-08-12 11:29:16 --> Language Class Initialized
ERROR - 2023-08-12 11:29:16 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-12 11:29:19 --> Config Class Initialized
INFO - 2023-08-12 11:29:19 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:29:19 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:29:19 --> Utf8 Class Initialized
INFO - 2023-08-12 11:29:19 --> URI Class Initialized
INFO - 2023-08-12 11:29:19 --> Router Class Initialized
INFO - 2023-08-12 11:29:19 --> Output Class Initialized
INFO - 2023-08-12 11:29:19 --> Security Class Initialized
DEBUG - 2023-08-12 11:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:29:19 --> Input Class Initialized
INFO - 2023-08-12 11:29:19 --> Language Class Initialized
INFO - 2023-08-12 11:29:19 --> Loader Class Initialized
INFO - 2023-08-12 11:29:19 --> Helper loaded: url_helper
INFO - 2023-08-12 11:29:19 --> Helper loaded: file_helper
INFO - 2023-08-12 11:29:19 --> Database Driver Class Initialized
INFO - 2023-08-12 11:29:19 --> Email Class Initialized
DEBUG - 2023-08-12 11:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:29:19 --> Controller Class Initialized
INFO - 2023-08-12 11:29:19 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:29:19 --> Helper loaded: form_helper
INFO - 2023-08-12 11:29:19 --> Form Validation Class Initialized
INFO - 2023-08-12 11:29:19 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:29:20 --> Final output sent to browser
DEBUG - 2023-08-12 11:29:20 --> Total execution time: 0.0592
INFO - 2023-08-12 11:29:20 --> Config Class Initialized
INFO - 2023-08-12 11:29:20 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:29:20 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:29:20 --> Utf8 Class Initialized
INFO - 2023-08-12 11:29:20 --> URI Class Initialized
INFO - 2023-08-12 11:29:20 --> Router Class Initialized
INFO - 2023-08-12 11:29:20 --> Output Class Initialized
INFO - 2023-08-12 11:29:20 --> Security Class Initialized
DEBUG - 2023-08-12 11:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:29:20 --> Input Class Initialized
INFO - 2023-08-12 11:29:20 --> Language Class Initialized
INFO - 2023-08-12 11:29:20 --> Loader Class Initialized
INFO - 2023-08-12 11:29:20 --> Helper loaded: url_helper
INFO - 2023-08-12 11:29:20 --> Helper loaded: file_helper
INFO - 2023-08-12 11:29:20 --> Database Driver Class Initialized
INFO - 2023-08-12 11:29:20 --> Email Class Initialized
DEBUG - 2023-08-12 11:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:29:20 --> Controller Class Initialized
INFO - 2023-08-12 11:29:20 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:29:20 --> Helper loaded: form_helper
INFO - 2023-08-12 11:29:20 --> Form Validation Class Initialized
ERROR - 2023-08-12 11:29:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-08-12 11:29:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-08-12 11:29:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-08-12 11:29:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-08-12 11:29:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-08-12 11:29:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-08-12 11:29:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-08-12 11:29:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
INFO - 2023-08-12 11:29:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:29:20 --> Final output sent to browser
DEBUG - 2023-08-12 11:29:20 --> Total execution time: 0.0502
INFO - 2023-08-12 11:29:25 --> Config Class Initialized
INFO - 2023-08-12 11:29:25 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:29:25 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:29:25 --> Utf8 Class Initialized
INFO - 2023-08-12 11:29:25 --> URI Class Initialized
INFO - 2023-08-12 11:29:25 --> Router Class Initialized
INFO - 2023-08-12 11:29:25 --> Output Class Initialized
INFO - 2023-08-12 11:29:25 --> Security Class Initialized
DEBUG - 2023-08-12 11:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:29:25 --> Input Class Initialized
INFO - 2023-08-12 11:29:25 --> Language Class Initialized
INFO - 2023-08-12 11:29:25 --> Loader Class Initialized
INFO - 2023-08-12 11:29:25 --> Helper loaded: url_helper
INFO - 2023-08-12 11:29:25 --> Helper loaded: file_helper
INFO - 2023-08-12 11:29:25 --> Database Driver Class Initialized
INFO - 2023-08-12 11:29:25 --> Email Class Initialized
DEBUG - 2023-08-12 11:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:29:25 --> Controller Class Initialized
INFO - 2023-08-12 11:29:25 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:29:25 --> Helper loaded: form_helper
INFO - 2023-08-12 11:29:25 --> Form Validation Class Initialized
INFO - 2023-08-12 11:29:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-12 11:29:25 --> Severity: Warning --> Undefined variable $image_name C:\xampp\htdocs\dw\application\controllers\Admin\Blog.php 94
INFO - 2023-08-12 11:29:25 --> Config Class Initialized
INFO - 2023-08-12 11:29:25 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:29:25 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:29:25 --> Utf8 Class Initialized
INFO - 2023-08-12 11:29:25 --> URI Class Initialized
INFO - 2023-08-12 11:29:25 --> Router Class Initialized
INFO - 2023-08-12 11:29:25 --> Output Class Initialized
INFO - 2023-08-12 11:29:25 --> Security Class Initialized
DEBUG - 2023-08-12 11:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:29:25 --> Input Class Initialized
INFO - 2023-08-12 11:29:25 --> Language Class Initialized
INFO - 2023-08-12 11:29:25 --> Loader Class Initialized
INFO - 2023-08-12 11:29:25 --> Helper loaded: url_helper
INFO - 2023-08-12 11:29:25 --> Helper loaded: file_helper
INFO - 2023-08-12 11:29:25 --> Database Driver Class Initialized
INFO - 2023-08-12 11:29:25 --> Email Class Initialized
DEBUG - 2023-08-12 11:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:29:25 --> Controller Class Initialized
INFO - 2023-08-12 11:29:25 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:29:25 --> Helper loaded: form_helper
INFO - 2023-08-12 11:29:25 --> Form Validation Class Initialized
INFO - 2023-08-12 11:29:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-12 11:29:26 --> Final output sent to browser
DEBUG - 2023-08-12 11:29:26 --> Total execution time: 0.1375
INFO - 2023-08-12 11:29:26 --> Config Class Initialized
INFO - 2023-08-12 11:29:26 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:29:26 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:29:26 --> Utf8 Class Initialized
INFO - 2023-08-12 11:29:26 --> URI Class Initialized
INFO - 2023-08-12 11:29:26 --> Router Class Initialized
INFO - 2023-08-12 11:29:26 --> Output Class Initialized
INFO - 2023-08-12 11:29:26 --> Security Class Initialized
DEBUG - 2023-08-12 11:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:29:26 --> Input Class Initialized
INFO - 2023-08-12 11:29:26 --> Language Class Initialized
ERROR - 2023-08-12 11:29:26 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-12 11:29:29 --> Config Class Initialized
INFO - 2023-08-12 11:29:29 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:29:29 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:29:29 --> Utf8 Class Initialized
INFO - 2023-08-12 11:29:29 --> URI Class Initialized
INFO - 2023-08-12 11:29:29 --> Router Class Initialized
INFO - 2023-08-12 11:29:29 --> Output Class Initialized
INFO - 2023-08-12 11:29:29 --> Security Class Initialized
DEBUG - 2023-08-12 11:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:29:29 --> Input Class Initialized
INFO - 2023-08-12 11:29:29 --> Language Class Initialized
INFO - 2023-08-12 11:29:29 --> Loader Class Initialized
INFO - 2023-08-12 11:29:29 --> Helper loaded: url_helper
INFO - 2023-08-12 11:29:29 --> Helper loaded: file_helper
INFO - 2023-08-12 11:29:29 --> Database Driver Class Initialized
INFO - 2023-08-12 11:29:29 --> Email Class Initialized
DEBUG - 2023-08-12 11:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:29:29 --> Controller Class Initialized
INFO - 2023-08-12 11:29:29 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:29:29 --> Helper loaded: form_helper
INFO - 2023-08-12 11:29:29 --> Form Validation Class Initialized
INFO - 2023-08-12 11:29:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:29:29 --> Final output sent to browser
DEBUG - 2023-08-12 11:29:29 --> Total execution time: 0.0558
INFO - 2023-08-12 11:29:30 --> Config Class Initialized
INFO - 2023-08-12 11:29:30 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:29:30 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:29:30 --> Utf8 Class Initialized
INFO - 2023-08-12 11:29:30 --> URI Class Initialized
INFO - 2023-08-12 11:29:30 --> Router Class Initialized
INFO - 2023-08-12 11:29:30 --> Output Class Initialized
INFO - 2023-08-12 11:29:30 --> Security Class Initialized
DEBUG - 2023-08-12 11:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:29:30 --> Input Class Initialized
INFO - 2023-08-12 11:29:30 --> Language Class Initialized
INFO - 2023-08-12 11:29:30 --> Loader Class Initialized
INFO - 2023-08-12 11:29:30 --> Helper loaded: url_helper
INFO - 2023-08-12 11:29:30 --> Helper loaded: file_helper
INFO - 2023-08-12 11:29:30 --> Database Driver Class Initialized
INFO - 2023-08-12 11:29:30 --> Email Class Initialized
DEBUG - 2023-08-12 11:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:29:30 --> Controller Class Initialized
INFO - 2023-08-12 11:29:30 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:29:30 --> Helper loaded: form_helper
INFO - 2023-08-12 11:29:30 --> Form Validation Class Initialized
ERROR - 2023-08-12 11:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-08-12 11:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-08-12 11:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-08-12 11:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-08-12 11:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-08-12 11:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-08-12 11:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-08-12 11:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
INFO - 2023-08-12 11:29:30 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:29:30 --> Final output sent to browser
DEBUG - 2023-08-12 11:29:30 --> Total execution time: 0.4707
INFO - 2023-08-12 11:32:21 --> Config Class Initialized
INFO - 2023-08-12 11:32:21 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:32:21 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:32:21 --> Utf8 Class Initialized
INFO - 2023-08-12 11:32:21 --> URI Class Initialized
INFO - 2023-08-12 11:32:21 --> Router Class Initialized
INFO - 2023-08-12 11:32:21 --> Output Class Initialized
INFO - 2023-08-12 11:32:21 --> Security Class Initialized
DEBUG - 2023-08-12 11:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:32:21 --> Input Class Initialized
INFO - 2023-08-12 11:32:21 --> Language Class Initialized
INFO - 2023-08-12 11:32:22 --> Loader Class Initialized
INFO - 2023-08-12 11:32:22 --> Helper loaded: url_helper
INFO - 2023-08-12 11:32:22 --> Helper loaded: file_helper
INFO - 2023-08-12 11:32:22 --> Database Driver Class Initialized
INFO - 2023-08-12 11:32:22 --> Email Class Initialized
DEBUG - 2023-08-12 11:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:32:22 --> Controller Class Initialized
INFO - 2023-08-12 11:32:22 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:32:22 --> Helper loaded: form_helper
INFO - 2023-08-12 11:32:22 --> Form Validation Class Initialized
INFO - 2023-08-12 11:32:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:32:22 --> Final output sent to browser
DEBUG - 2023-08-12 11:32:22 --> Total execution time: 0.2493
INFO - 2023-08-12 11:32:22 --> Config Class Initialized
INFO - 2023-08-12 11:32:22 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:32:22 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:32:22 --> Utf8 Class Initialized
INFO - 2023-08-12 11:32:22 --> URI Class Initialized
INFO - 2023-08-12 11:32:22 --> Router Class Initialized
INFO - 2023-08-12 11:32:22 --> Output Class Initialized
INFO - 2023-08-12 11:32:22 --> Security Class Initialized
DEBUG - 2023-08-12 11:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:32:22 --> Input Class Initialized
INFO - 2023-08-12 11:32:22 --> Language Class Initialized
INFO - 2023-08-12 11:32:22 --> Loader Class Initialized
INFO - 2023-08-12 11:32:22 --> Helper loaded: url_helper
INFO - 2023-08-12 11:32:22 --> Helper loaded: file_helper
INFO - 2023-08-12 11:32:22 --> Database Driver Class Initialized
INFO - 2023-08-12 11:32:22 --> Email Class Initialized
DEBUG - 2023-08-12 11:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:32:22 --> Controller Class Initialized
INFO - 2023-08-12 11:32:23 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:32:23 --> Helper loaded: form_helper
INFO - 2023-08-12 11:32:23 --> Form Validation Class Initialized
ERROR - 2023-08-12 11:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-08-12 11:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-08-12 11:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-08-12 11:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-08-12 11:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-08-12 11:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-08-12 11:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-08-12 11:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-08-12 11:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 106
INFO - 2023-08-12 11:32:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:32:23 --> Final output sent to browser
DEBUG - 2023-08-12 11:32:23 --> Total execution time: 0.1336
INFO - 2023-08-12 11:32:23 --> Config Class Initialized
INFO - 2023-08-12 11:32:23 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:32:23 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:32:23 --> Utf8 Class Initialized
INFO - 2023-08-12 11:32:23 --> URI Class Initialized
INFO - 2023-08-12 11:32:23 --> Router Class Initialized
INFO - 2023-08-12 11:32:23 --> Output Class Initialized
INFO - 2023-08-12 11:32:23 --> Security Class Initialized
DEBUG - 2023-08-12 11:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:32:23 --> Input Class Initialized
INFO - 2023-08-12 11:32:23 --> Language Class Initialized
INFO - 2023-08-12 11:32:23 --> Loader Class Initialized
INFO - 2023-08-12 11:32:23 --> Helper loaded: url_helper
INFO - 2023-08-12 11:32:23 --> Helper loaded: file_helper
INFO - 2023-08-12 11:32:23 --> Database Driver Class Initialized
INFO - 2023-08-12 11:32:23 --> Email Class Initialized
DEBUG - 2023-08-12 11:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:32:23 --> Controller Class Initialized
INFO - 2023-08-12 11:32:23 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:32:23 --> Helper loaded: form_helper
INFO - 2023-08-12 11:32:23 --> Form Validation Class Initialized
INFO - 2023-08-12 11:32:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-12 11:32:23 --> Final output sent to browser
DEBUG - 2023-08-12 11:32:23 --> Total execution time: 0.0886
INFO - 2023-08-12 11:32:23 --> Config Class Initialized
INFO - 2023-08-12 11:32:23 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:32:23 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:32:23 --> Utf8 Class Initialized
INFO - 2023-08-12 11:32:23 --> URI Class Initialized
INFO - 2023-08-12 11:32:23 --> Router Class Initialized
INFO - 2023-08-12 11:32:23 --> Output Class Initialized
INFO - 2023-08-12 11:32:23 --> Security Class Initialized
DEBUG - 2023-08-12 11:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:32:23 --> Input Class Initialized
INFO - 2023-08-12 11:32:23 --> Language Class Initialized
ERROR - 2023-08-12 11:32:23 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-12 11:32:25 --> Config Class Initialized
INFO - 2023-08-12 11:32:25 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:32:25 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:32:25 --> Utf8 Class Initialized
INFO - 2023-08-12 11:32:25 --> URI Class Initialized
INFO - 2023-08-12 11:32:25 --> Router Class Initialized
INFO - 2023-08-12 11:32:25 --> Output Class Initialized
INFO - 2023-08-12 11:32:25 --> Security Class Initialized
DEBUG - 2023-08-12 11:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:32:25 --> Input Class Initialized
INFO - 2023-08-12 11:32:25 --> Language Class Initialized
INFO - 2023-08-12 11:32:25 --> Loader Class Initialized
INFO - 2023-08-12 11:32:25 --> Helper loaded: url_helper
INFO - 2023-08-12 11:32:25 --> Helper loaded: file_helper
INFO - 2023-08-12 11:32:25 --> Database Driver Class Initialized
INFO - 2023-08-12 11:32:25 --> Email Class Initialized
DEBUG - 2023-08-12 11:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:32:25 --> Controller Class Initialized
INFO - 2023-08-12 11:32:25 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:32:25 --> Helper loaded: form_helper
INFO - 2023-08-12 11:32:25 --> Form Validation Class Initialized
INFO - 2023-08-12 11:32:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-08-12 11:32:25 --> Final output sent to browser
DEBUG - 2023-08-12 11:32:25 --> Total execution time: 0.2059
INFO - 2023-08-12 11:32:33 --> Config Class Initialized
INFO - 2023-08-12 11:32:33 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:32:33 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:32:33 --> Utf8 Class Initialized
INFO - 2023-08-12 11:32:33 --> URI Class Initialized
INFO - 2023-08-12 11:32:33 --> Router Class Initialized
INFO - 2023-08-12 11:32:33 --> Output Class Initialized
INFO - 2023-08-12 11:32:33 --> Security Class Initialized
DEBUG - 2023-08-12 11:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:32:33 --> Input Class Initialized
INFO - 2023-08-12 11:32:33 --> Language Class Initialized
INFO - 2023-08-12 11:32:33 --> Loader Class Initialized
INFO - 2023-08-12 11:32:33 --> Helper loaded: url_helper
INFO - 2023-08-12 11:32:33 --> Helper loaded: file_helper
INFO - 2023-08-12 11:32:33 --> Database Driver Class Initialized
INFO - 2023-08-12 11:32:33 --> Email Class Initialized
DEBUG - 2023-08-12 11:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:32:33 --> Controller Class Initialized
INFO - 2023-08-12 11:32:33 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:32:33 --> Helper loaded: form_helper
INFO - 2023-08-12 11:32:33 --> Form Validation Class Initialized
INFO - 2023-08-12 11:32:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-12 11:32:33 --> Config Class Initialized
INFO - 2023-08-12 11:32:33 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:32:33 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:32:33 --> Utf8 Class Initialized
INFO - 2023-08-12 11:32:33 --> URI Class Initialized
INFO - 2023-08-12 11:32:33 --> Router Class Initialized
INFO - 2023-08-12 11:32:33 --> Output Class Initialized
INFO - 2023-08-12 11:32:33 --> Security Class Initialized
DEBUG - 2023-08-12 11:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:32:33 --> Input Class Initialized
INFO - 2023-08-12 11:32:33 --> Language Class Initialized
INFO - 2023-08-12 11:32:33 --> Loader Class Initialized
INFO - 2023-08-12 11:32:33 --> Helper loaded: url_helper
INFO - 2023-08-12 11:32:33 --> Helper loaded: file_helper
INFO - 2023-08-12 11:32:33 --> Database Driver Class Initialized
INFO - 2023-08-12 11:32:33 --> Email Class Initialized
DEBUG - 2023-08-12 11:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:32:34 --> Controller Class Initialized
INFO - 2023-08-12 11:32:34 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:32:34 --> Helper loaded: form_helper
INFO - 2023-08-12 11:32:34 --> Form Validation Class Initialized
INFO - 2023-08-12 11:32:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-12 11:32:34 --> Final output sent to browser
DEBUG - 2023-08-12 11:32:34 --> Total execution time: 0.7285
INFO - 2023-08-12 11:32:34 --> Config Class Initialized
INFO - 2023-08-12 11:32:34 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:32:34 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:32:34 --> Utf8 Class Initialized
INFO - 2023-08-12 11:32:34 --> URI Class Initialized
INFO - 2023-08-12 11:32:34 --> Router Class Initialized
INFO - 2023-08-12 11:32:34 --> Output Class Initialized
INFO - 2023-08-12 11:32:34 --> Security Class Initialized
DEBUG - 2023-08-12 11:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:32:34 --> Input Class Initialized
INFO - 2023-08-12 11:32:34 --> Language Class Initialized
ERROR - 2023-08-12 11:32:34 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-12 11:32:37 --> Config Class Initialized
INFO - 2023-08-12 11:32:37 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:32:37 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:32:37 --> Utf8 Class Initialized
INFO - 2023-08-12 11:32:37 --> URI Class Initialized
INFO - 2023-08-12 11:32:37 --> Router Class Initialized
INFO - 2023-08-12 11:32:37 --> Output Class Initialized
INFO - 2023-08-12 11:32:37 --> Security Class Initialized
DEBUG - 2023-08-12 11:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:32:37 --> Input Class Initialized
INFO - 2023-08-12 11:32:37 --> Language Class Initialized
INFO - 2023-08-12 11:32:37 --> Loader Class Initialized
INFO - 2023-08-12 11:32:37 --> Helper loaded: url_helper
INFO - 2023-08-12 11:32:37 --> Helper loaded: file_helper
INFO - 2023-08-12 11:32:37 --> Database Driver Class Initialized
INFO - 2023-08-12 11:32:37 --> Email Class Initialized
DEBUG - 2023-08-12 11:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:32:37 --> Controller Class Initialized
INFO - 2023-08-12 11:32:37 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:32:37 --> Helper loaded: form_helper
INFO - 2023-08-12 11:32:37 --> Form Validation Class Initialized
INFO - 2023-08-12 11:32:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:32:37 --> Final output sent to browser
DEBUG - 2023-08-12 11:32:37 --> Total execution time: 0.0630
INFO - 2023-08-12 11:32:37 --> Config Class Initialized
INFO - 2023-08-12 11:32:37 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:32:37 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:32:37 --> Utf8 Class Initialized
INFO - 2023-08-12 11:32:37 --> URI Class Initialized
INFO - 2023-08-12 11:32:37 --> Router Class Initialized
INFO - 2023-08-12 11:32:37 --> Output Class Initialized
INFO - 2023-08-12 11:32:37 --> Security Class Initialized
DEBUG - 2023-08-12 11:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:32:37 --> Input Class Initialized
INFO - 2023-08-12 11:32:37 --> Language Class Initialized
INFO - 2023-08-12 11:32:37 --> Loader Class Initialized
INFO - 2023-08-12 11:32:37 --> Helper loaded: url_helper
INFO - 2023-08-12 11:32:37 --> Helper loaded: file_helper
INFO - 2023-08-12 11:32:37 --> Database Driver Class Initialized
INFO - 2023-08-12 11:32:37 --> Email Class Initialized
DEBUG - 2023-08-12 11:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:32:37 --> Controller Class Initialized
INFO - 2023-08-12 11:32:37 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:32:37 --> Helper loaded: form_helper
INFO - 2023-08-12 11:32:37 --> Form Validation Class Initialized
ERROR - 2023-08-12 11:32:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-08-12 11:32:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-08-12 11:32:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-08-12 11:32:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-08-12 11:32:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-08-12 11:32:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-08-12 11:32:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-08-12 11:32:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-08-12 11:32:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 106
INFO - 2023-08-12 11:32:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:32:37 --> Final output sent to browser
DEBUG - 2023-08-12 11:32:37 --> Total execution time: 0.0577
INFO - 2023-08-12 11:32:41 --> Config Class Initialized
INFO - 2023-08-12 11:32:41 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:32:41 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:32:41 --> Utf8 Class Initialized
INFO - 2023-08-12 11:32:41 --> URI Class Initialized
INFO - 2023-08-12 11:32:41 --> Router Class Initialized
INFO - 2023-08-12 11:32:41 --> Output Class Initialized
INFO - 2023-08-12 11:32:41 --> Security Class Initialized
DEBUG - 2023-08-12 11:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:32:41 --> Input Class Initialized
INFO - 2023-08-12 11:32:41 --> Language Class Initialized
INFO - 2023-08-12 11:32:41 --> Loader Class Initialized
INFO - 2023-08-12 11:32:41 --> Helper loaded: url_helper
INFO - 2023-08-12 11:32:41 --> Helper loaded: file_helper
INFO - 2023-08-12 11:32:41 --> Database Driver Class Initialized
INFO - 2023-08-12 11:32:41 --> Email Class Initialized
DEBUG - 2023-08-12 11:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:32:41 --> Controller Class Initialized
INFO - 2023-08-12 11:32:41 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:32:41 --> Helper loaded: form_helper
INFO - 2023-08-12 11:32:41 --> Form Validation Class Initialized
INFO - 2023-08-12 11:32:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-12 11:32:41 --> Severity: Warning --> Undefined variable $image_name C:\xampp\htdocs\dw\application\controllers\Admin\Blog.php 96
INFO - 2023-08-12 11:32:41 --> Config Class Initialized
INFO - 2023-08-12 11:32:41 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:32:41 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:32:41 --> Utf8 Class Initialized
INFO - 2023-08-12 11:32:41 --> URI Class Initialized
INFO - 2023-08-12 11:32:41 --> Router Class Initialized
INFO - 2023-08-12 11:32:41 --> Output Class Initialized
INFO - 2023-08-12 11:32:41 --> Security Class Initialized
DEBUG - 2023-08-12 11:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:32:41 --> Input Class Initialized
INFO - 2023-08-12 11:32:41 --> Language Class Initialized
INFO - 2023-08-12 11:32:41 --> Loader Class Initialized
INFO - 2023-08-12 11:32:41 --> Helper loaded: url_helper
INFO - 2023-08-12 11:32:41 --> Helper loaded: file_helper
INFO - 2023-08-12 11:32:41 --> Database Driver Class Initialized
INFO - 2023-08-12 11:32:41 --> Email Class Initialized
DEBUG - 2023-08-12 11:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:32:41 --> Controller Class Initialized
INFO - 2023-08-12 11:32:41 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:32:41 --> Helper loaded: form_helper
INFO - 2023-08-12 11:32:41 --> Form Validation Class Initialized
INFO - 2023-08-12 11:32:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-12 11:32:41 --> Config Class Initialized
INFO - 2023-08-12 11:32:41 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:32:41 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:32:41 --> Utf8 Class Initialized
INFO - 2023-08-12 11:32:41 --> URI Class Initialized
INFO - 2023-08-12 11:32:41 --> Router Class Initialized
INFO - 2023-08-12 11:32:41 --> Output Class Initialized
INFO - 2023-08-12 11:32:41 --> Security Class Initialized
DEBUG - 2023-08-12 11:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:32:41 --> Input Class Initialized
INFO - 2023-08-12 11:32:41 --> Language Class Initialized
ERROR - 2023-08-12 11:32:41 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-12 11:32:41 --> Final output sent to browser
DEBUG - 2023-08-12 11:32:41 --> Total execution time: 0.3239
INFO - 2023-08-12 11:33:59 --> Config Class Initialized
INFO - 2023-08-12 11:33:59 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:33:59 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:33:59 --> Utf8 Class Initialized
INFO - 2023-08-12 11:33:59 --> URI Class Initialized
INFO - 2023-08-12 11:33:59 --> Router Class Initialized
INFO - 2023-08-12 11:33:59 --> Output Class Initialized
INFO - 2023-08-12 11:33:59 --> Security Class Initialized
DEBUG - 2023-08-12 11:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:33:59 --> Input Class Initialized
INFO - 2023-08-12 11:33:59 --> Language Class Initialized
INFO - 2023-08-12 11:33:59 --> Loader Class Initialized
INFO - 2023-08-12 11:33:59 --> Helper loaded: url_helper
INFO - 2023-08-12 11:33:59 --> Helper loaded: file_helper
INFO - 2023-08-12 11:33:59 --> Database Driver Class Initialized
INFO - 2023-08-12 11:33:59 --> Email Class Initialized
DEBUG - 2023-08-12 11:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:33:59 --> Controller Class Initialized
INFO - 2023-08-12 11:33:59 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:33:59 --> Helper loaded: form_helper
INFO - 2023-08-12 11:33:59 --> Form Validation Class Initialized
INFO - 2023-08-12 11:33:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:33:59 --> Final output sent to browser
DEBUG - 2023-08-12 11:33:59 --> Total execution time: 0.2892
INFO - 2023-08-12 11:33:59 --> Config Class Initialized
INFO - 2023-08-12 11:33:59 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:33:59 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:33:59 --> Utf8 Class Initialized
INFO - 2023-08-12 11:33:59 --> URI Class Initialized
INFO - 2023-08-12 11:33:59 --> Router Class Initialized
INFO - 2023-08-12 11:33:59 --> Output Class Initialized
INFO - 2023-08-12 11:33:59 --> Security Class Initialized
DEBUG - 2023-08-12 11:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:33:59 --> Input Class Initialized
INFO - 2023-08-12 11:33:59 --> Language Class Initialized
INFO - 2023-08-12 11:33:59 --> Loader Class Initialized
INFO - 2023-08-12 11:33:59 --> Helper loaded: url_helper
INFO - 2023-08-12 11:33:59 --> Helper loaded: file_helper
INFO - 2023-08-12 11:33:59 --> Database Driver Class Initialized
INFO - 2023-08-12 11:33:59 --> Email Class Initialized
DEBUG - 2023-08-12 11:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:33:59 --> Controller Class Initialized
INFO - 2023-08-12 11:33:59 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:33:59 --> Helper loaded: form_helper
INFO - 2023-08-12 11:33:59 --> Form Validation Class Initialized
ERROR - 2023-08-12 11:33:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-08-12 11:33:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-08-12 11:33:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-08-12 11:33:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-08-12 11:33:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-08-12 11:33:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-08-12 11:33:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-08-12 11:33:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-08-12 11:33:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 106
INFO - 2023-08-12 11:33:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:33:59 --> Final output sent to browser
DEBUG - 2023-08-12 11:33:59 --> Total execution time: 0.0508
INFO - 2023-08-12 11:34:03 --> Config Class Initialized
INFO - 2023-08-12 11:34:03 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:34:03 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:34:03 --> Utf8 Class Initialized
INFO - 2023-08-12 11:34:03 --> URI Class Initialized
INFO - 2023-08-12 11:34:03 --> Router Class Initialized
INFO - 2023-08-12 11:34:03 --> Output Class Initialized
INFO - 2023-08-12 11:34:03 --> Security Class Initialized
DEBUG - 2023-08-12 11:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:34:03 --> Input Class Initialized
INFO - 2023-08-12 11:34:03 --> Language Class Initialized
INFO - 2023-08-12 11:34:03 --> Loader Class Initialized
INFO - 2023-08-12 11:34:03 --> Helper loaded: url_helper
INFO - 2023-08-12 11:34:03 --> Helper loaded: file_helper
INFO - 2023-08-12 11:34:03 --> Database Driver Class Initialized
INFO - 2023-08-12 11:34:03 --> Email Class Initialized
DEBUG - 2023-08-12 11:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:34:03 --> Controller Class Initialized
INFO - 2023-08-12 11:34:03 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:34:03 --> Helper loaded: form_helper
INFO - 2023-08-12 11:34:03 --> Form Validation Class Initialized
INFO - 2023-08-12 11:34:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-12 11:34:04 --> Config Class Initialized
INFO - 2023-08-12 11:34:04 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:34:04 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:34:04 --> Utf8 Class Initialized
INFO - 2023-08-12 11:34:04 --> URI Class Initialized
INFO - 2023-08-12 11:34:04 --> Router Class Initialized
INFO - 2023-08-12 11:34:04 --> Output Class Initialized
INFO - 2023-08-12 11:34:04 --> Security Class Initialized
DEBUG - 2023-08-12 11:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:34:04 --> Input Class Initialized
INFO - 2023-08-12 11:34:04 --> Language Class Initialized
INFO - 2023-08-12 11:34:04 --> Loader Class Initialized
INFO - 2023-08-12 11:34:04 --> Helper loaded: url_helper
INFO - 2023-08-12 11:34:04 --> Helper loaded: file_helper
INFO - 2023-08-12 11:34:04 --> Database Driver Class Initialized
INFO - 2023-08-12 11:34:04 --> Email Class Initialized
DEBUG - 2023-08-12 11:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:34:04 --> Controller Class Initialized
INFO - 2023-08-12 11:34:04 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:34:04 --> Helper loaded: form_helper
INFO - 2023-08-12 11:34:04 --> Form Validation Class Initialized
INFO - 2023-08-12 11:34:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-12 11:34:04 --> Final output sent to browser
DEBUG - 2023-08-12 11:34:04 --> Total execution time: 0.2266
INFO - 2023-08-12 11:34:04 --> Config Class Initialized
INFO - 2023-08-12 11:34:04 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:34:04 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:34:04 --> Utf8 Class Initialized
INFO - 2023-08-12 11:34:04 --> URI Class Initialized
INFO - 2023-08-12 11:34:04 --> Router Class Initialized
INFO - 2023-08-12 11:34:04 --> Output Class Initialized
INFO - 2023-08-12 11:34:04 --> Security Class Initialized
DEBUG - 2023-08-12 11:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:34:04 --> Input Class Initialized
INFO - 2023-08-12 11:34:04 --> Language Class Initialized
ERROR - 2023-08-12 11:34:04 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-12 11:34:06 --> Config Class Initialized
INFO - 2023-08-12 11:34:06 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:34:06 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:34:06 --> Utf8 Class Initialized
INFO - 2023-08-12 11:34:06 --> URI Class Initialized
INFO - 2023-08-12 11:34:06 --> Router Class Initialized
INFO - 2023-08-12 11:34:06 --> Output Class Initialized
INFO - 2023-08-12 11:34:06 --> Security Class Initialized
DEBUG - 2023-08-12 11:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:34:06 --> Input Class Initialized
INFO - 2023-08-12 11:34:06 --> Language Class Initialized
INFO - 2023-08-12 11:34:06 --> Loader Class Initialized
INFO - 2023-08-12 11:34:06 --> Helper loaded: url_helper
INFO - 2023-08-12 11:34:06 --> Helper loaded: file_helper
INFO - 2023-08-12 11:34:06 --> Database Driver Class Initialized
INFO - 2023-08-12 11:34:06 --> Email Class Initialized
DEBUG - 2023-08-12 11:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:34:06 --> Controller Class Initialized
INFO - 2023-08-12 11:34:06 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:34:07 --> Helper loaded: form_helper
INFO - 2023-08-12 11:34:07 --> Form Validation Class Initialized
INFO - 2023-08-12 11:34:07 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:34:07 --> Final output sent to browser
DEBUG - 2023-08-12 11:34:07 --> Total execution time: 0.1121
INFO - 2023-08-12 11:34:07 --> Config Class Initialized
INFO - 2023-08-12 11:34:07 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:34:07 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:34:07 --> Utf8 Class Initialized
INFO - 2023-08-12 11:34:07 --> URI Class Initialized
INFO - 2023-08-12 11:34:07 --> Router Class Initialized
INFO - 2023-08-12 11:34:07 --> Output Class Initialized
INFO - 2023-08-12 11:34:07 --> Security Class Initialized
DEBUG - 2023-08-12 11:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:34:07 --> Input Class Initialized
INFO - 2023-08-12 11:34:07 --> Language Class Initialized
INFO - 2023-08-12 11:34:07 --> Loader Class Initialized
INFO - 2023-08-12 11:34:07 --> Helper loaded: url_helper
INFO - 2023-08-12 11:34:07 --> Helper loaded: file_helper
INFO - 2023-08-12 11:34:07 --> Database Driver Class Initialized
INFO - 2023-08-12 11:34:07 --> Email Class Initialized
DEBUG - 2023-08-12 11:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:34:07 --> Controller Class Initialized
INFO - 2023-08-12 11:34:07 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:34:07 --> Helper loaded: form_helper
INFO - 2023-08-12 11:34:07 --> Form Validation Class Initialized
ERROR - 2023-08-12 11:34:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-08-12 11:34:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-08-12 11:34:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-08-12 11:34:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-08-12 11:34:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-08-12 11:34:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-08-12 11:34:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-08-12 11:34:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-08-12 11:34:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 106
INFO - 2023-08-12 11:34:07 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-08-12 11:34:07 --> Final output sent to browser
DEBUG - 2023-08-12 11:34:07 --> Total execution time: 0.0497
INFO - 2023-08-12 11:34:09 --> Config Class Initialized
INFO - 2023-08-12 11:34:09 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:34:09 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:34:09 --> Utf8 Class Initialized
INFO - 2023-08-12 11:34:09 --> URI Class Initialized
INFO - 2023-08-12 11:34:09 --> Router Class Initialized
INFO - 2023-08-12 11:34:09 --> Output Class Initialized
INFO - 2023-08-12 11:34:09 --> Security Class Initialized
DEBUG - 2023-08-12 11:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:34:09 --> Input Class Initialized
INFO - 2023-08-12 11:34:09 --> Language Class Initialized
INFO - 2023-08-12 11:34:09 --> Loader Class Initialized
INFO - 2023-08-12 11:34:09 --> Helper loaded: url_helper
INFO - 2023-08-12 11:34:09 --> Helper loaded: file_helper
INFO - 2023-08-12 11:34:09 --> Database Driver Class Initialized
INFO - 2023-08-12 11:34:09 --> Email Class Initialized
DEBUG - 2023-08-12 11:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:34:09 --> Controller Class Initialized
INFO - 2023-08-12 11:34:09 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:34:09 --> Helper loaded: form_helper
INFO - 2023-08-12 11:34:09 --> Form Validation Class Initialized
INFO - 2023-08-12 11:34:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-12 11:34:09 --> Config Class Initialized
INFO - 2023-08-12 11:34:09 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:34:09 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:34:09 --> Utf8 Class Initialized
INFO - 2023-08-12 11:34:09 --> URI Class Initialized
INFO - 2023-08-12 11:34:09 --> Router Class Initialized
INFO - 2023-08-12 11:34:09 --> Output Class Initialized
INFO - 2023-08-12 11:34:09 --> Security Class Initialized
DEBUG - 2023-08-12 11:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:34:09 --> Input Class Initialized
INFO - 2023-08-12 11:34:09 --> Language Class Initialized
INFO - 2023-08-12 11:34:09 --> Loader Class Initialized
INFO - 2023-08-12 11:34:09 --> Helper loaded: url_helper
INFO - 2023-08-12 11:34:09 --> Helper loaded: file_helper
INFO - 2023-08-12 11:34:09 --> Database Driver Class Initialized
INFO - 2023-08-12 11:34:09 --> Email Class Initialized
DEBUG - 2023-08-12 11:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:34:09 --> Controller Class Initialized
INFO - 2023-08-12 11:34:09 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:34:09 --> Helper loaded: form_helper
INFO - 2023-08-12 11:34:09 --> Form Validation Class Initialized
INFO - 2023-08-12 11:34:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-12 11:34:09 --> Final output sent to browser
DEBUG - 2023-08-12 11:34:09 --> Total execution time: 0.0762
INFO - 2023-08-12 11:34:09 --> Config Class Initialized
INFO - 2023-08-12 11:34:09 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:34:09 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:34:09 --> Utf8 Class Initialized
INFO - 2023-08-12 11:34:09 --> URI Class Initialized
INFO - 2023-08-12 11:34:09 --> Router Class Initialized
INFO - 2023-08-12 11:34:09 --> Output Class Initialized
INFO - 2023-08-12 11:34:09 --> Security Class Initialized
DEBUG - 2023-08-12 11:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:34:09 --> Input Class Initialized
INFO - 2023-08-12 11:34:09 --> Language Class Initialized
ERROR - 2023-08-12 11:34:09 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-12 11:34:31 --> Config Class Initialized
INFO - 2023-08-12 11:34:31 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:34:31 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:34:31 --> Utf8 Class Initialized
INFO - 2023-08-12 11:34:31 --> URI Class Initialized
INFO - 2023-08-12 11:34:31 --> Router Class Initialized
INFO - 2023-08-12 11:34:31 --> Output Class Initialized
INFO - 2023-08-12 11:34:31 --> Security Class Initialized
DEBUG - 2023-08-12 11:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:34:31 --> Input Class Initialized
INFO - 2023-08-12 11:34:31 --> Language Class Initialized
INFO - 2023-08-12 11:34:31 --> Loader Class Initialized
INFO - 2023-08-12 11:34:31 --> Helper loaded: url_helper
INFO - 2023-08-12 11:34:31 --> Helper loaded: file_helper
INFO - 2023-08-12 11:34:31 --> Database Driver Class Initialized
INFO - 2023-08-12 11:34:31 --> Email Class Initialized
DEBUG - 2023-08-12 11:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 11:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 11:34:31 --> Controller Class Initialized
INFO - 2023-08-12 11:34:31 --> Model "Blog_model" initialized
INFO - 2023-08-12 11:34:31 --> Helper loaded: form_helper
INFO - 2023-08-12 11:34:31 --> Form Validation Class Initialized
INFO - 2023-08-12 11:34:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-12 11:34:31 --> Config Class Initialized
INFO - 2023-08-12 11:34:31 --> Hooks Class Initialized
DEBUG - 2023-08-12 11:34:31 --> UTF-8 Support Enabled
INFO - 2023-08-12 11:34:31 --> Utf8 Class Initialized
INFO - 2023-08-12 11:34:31 --> URI Class Initialized
INFO - 2023-08-12 11:34:31 --> Router Class Initialized
INFO - 2023-08-12 11:34:31 --> Output Class Initialized
INFO - 2023-08-12 11:34:31 --> Security Class Initialized
DEBUG - 2023-08-12 11:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 11:34:31 --> Input Class Initialized
INFO - 2023-08-12 11:34:31 --> Language Class Initialized
ERROR - 2023-08-12 11:34:31 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-12 11:34:31 --> Final output sent to browser
DEBUG - 2023-08-12 11:34:31 --> Total execution time: 0.0538
INFO - 2023-08-12 13:30:22 --> Config Class Initialized
INFO - 2023-08-12 13:30:22 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:30:22 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:30:22 --> Utf8 Class Initialized
INFO - 2023-08-12 13:30:22 --> URI Class Initialized
INFO - 2023-08-12 13:30:22 --> Router Class Initialized
INFO - 2023-08-12 13:30:22 --> Output Class Initialized
INFO - 2023-08-12 13:30:22 --> Security Class Initialized
DEBUG - 2023-08-12 13:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:30:22 --> Input Class Initialized
INFO - 2023-08-12 13:30:22 --> Language Class Initialized
ERROR - 2023-08-12 13:30:22 --> 404 Page Not Found: /index
INFO - 2023-08-12 13:30:51 --> Config Class Initialized
INFO - 2023-08-12 13:30:51 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:30:51 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:30:52 --> Utf8 Class Initialized
INFO - 2023-08-12 13:30:52 --> URI Class Initialized
INFO - 2023-08-12 13:30:52 --> Router Class Initialized
INFO - 2023-08-12 13:30:52 --> Output Class Initialized
INFO - 2023-08-12 13:30:52 --> Security Class Initialized
DEBUG - 2023-08-12 13:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:30:52 --> Input Class Initialized
INFO - 2023-08-12 13:30:52 --> Language Class Initialized
ERROR - 2023-08-12 13:30:52 --> 404 Page Not Found: HomeController/contact
INFO - 2023-08-12 13:31:12 --> Config Class Initialized
INFO - 2023-08-12 13:31:12 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:31:12 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:31:12 --> Utf8 Class Initialized
INFO - 2023-08-12 13:31:12 --> URI Class Initialized
INFO - 2023-08-12 13:31:12 --> Router Class Initialized
INFO - 2023-08-12 13:31:12 --> Output Class Initialized
INFO - 2023-08-12 13:31:12 --> Security Class Initialized
DEBUG - 2023-08-12 13:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:31:12 --> Input Class Initialized
INFO - 2023-08-12 13:31:12 --> Language Class Initialized
ERROR - 2023-08-12 13:31:12 --> 404 Page Not Found: HomeController/contact
INFO - 2023-08-12 13:31:14 --> Config Class Initialized
INFO - 2023-08-12 13:31:14 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:31:14 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:31:14 --> Utf8 Class Initialized
INFO - 2023-08-12 13:31:14 --> URI Class Initialized
INFO - 2023-08-12 13:31:14 --> Router Class Initialized
INFO - 2023-08-12 13:31:14 --> Output Class Initialized
INFO - 2023-08-12 13:31:14 --> Security Class Initialized
DEBUG - 2023-08-12 13:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:31:14 --> Input Class Initialized
INFO - 2023-08-12 13:31:14 --> Language Class Initialized
ERROR - 2023-08-12 13:31:14 --> 404 Page Not Found: HomeController/contact
INFO - 2023-08-12 13:31:15 --> Config Class Initialized
INFO - 2023-08-12 13:31:15 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:31:15 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:31:15 --> Utf8 Class Initialized
INFO - 2023-08-12 13:31:15 --> URI Class Initialized
INFO - 2023-08-12 13:31:15 --> Router Class Initialized
INFO - 2023-08-12 13:31:15 --> Output Class Initialized
INFO - 2023-08-12 13:31:15 --> Security Class Initialized
DEBUG - 2023-08-12 13:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:31:15 --> Input Class Initialized
INFO - 2023-08-12 13:31:15 --> Language Class Initialized
ERROR - 2023-08-12 13:31:15 --> 404 Page Not Found: HomeController/contact
INFO - 2023-08-12 13:31:15 --> Config Class Initialized
INFO - 2023-08-12 13:31:15 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:31:15 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:31:15 --> Utf8 Class Initialized
INFO - 2023-08-12 13:31:16 --> URI Class Initialized
INFO - 2023-08-12 13:31:16 --> Router Class Initialized
INFO - 2023-08-12 13:31:16 --> Output Class Initialized
INFO - 2023-08-12 13:31:16 --> Security Class Initialized
DEBUG - 2023-08-12 13:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:31:16 --> Input Class Initialized
INFO - 2023-08-12 13:31:16 --> Language Class Initialized
ERROR - 2023-08-12 13:31:16 --> 404 Page Not Found: HomeController/contact
INFO - 2023-08-12 13:31:16 --> Config Class Initialized
INFO - 2023-08-12 13:31:16 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:31:16 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:31:16 --> Utf8 Class Initialized
INFO - 2023-08-12 13:31:16 --> URI Class Initialized
INFO - 2023-08-12 13:31:16 --> Router Class Initialized
INFO - 2023-08-12 13:31:16 --> Output Class Initialized
INFO - 2023-08-12 13:31:16 --> Security Class Initialized
DEBUG - 2023-08-12 13:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:31:16 --> Input Class Initialized
INFO - 2023-08-12 13:31:16 --> Language Class Initialized
ERROR - 2023-08-12 13:31:16 --> 404 Page Not Found: HomeController/contact
INFO - 2023-08-12 13:32:48 --> Config Class Initialized
INFO - 2023-08-12 13:32:48 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:32:48 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:32:48 --> Utf8 Class Initialized
INFO - 2023-08-12 13:32:48 --> URI Class Initialized
INFO - 2023-08-12 13:32:48 --> Router Class Initialized
INFO - 2023-08-12 13:32:49 --> Output Class Initialized
INFO - 2023-08-12 13:32:49 --> Security Class Initialized
DEBUG - 2023-08-12 13:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:32:49 --> Input Class Initialized
INFO - 2023-08-12 13:32:49 --> Language Class Initialized
INFO - 2023-08-12 13:32:49 --> Loader Class Initialized
INFO - 2023-08-12 13:32:49 --> Helper loaded: url_helper
INFO - 2023-08-12 13:32:49 --> Helper loaded: file_helper
INFO - 2023-08-12 13:32:49 --> Database Driver Class Initialized
INFO - 2023-08-12 13:32:49 --> Email Class Initialized
DEBUG - 2023-08-12 13:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 13:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 13:32:49 --> Controller Class Initialized
INFO - 2023-08-12 13:33:10 --> Config Class Initialized
INFO - 2023-08-12 13:33:10 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:33:10 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:33:10 --> Utf8 Class Initialized
INFO - 2023-08-12 13:33:10 --> URI Class Initialized
INFO - 2023-08-12 13:33:10 --> Router Class Initialized
INFO - 2023-08-12 13:33:10 --> Output Class Initialized
INFO - 2023-08-12 13:33:10 --> Security Class Initialized
DEBUG - 2023-08-12 13:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:33:10 --> Input Class Initialized
INFO - 2023-08-12 13:33:10 --> Language Class Initialized
INFO - 2023-08-12 13:33:10 --> Loader Class Initialized
INFO - 2023-08-12 13:33:10 --> Helper loaded: url_helper
INFO - 2023-08-12 13:33:10 --> Helper loaded: file_helper
INFO - 2023-08-12 13:33:10 --> Database Driver Class Initialized
INFO - 2023-08-12 13:33:10 --> Email Class Initialized
DEBUG - 2023-08-12 13:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 13:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 13:33:11 --> Controller Class Initialized
INFO - 2023-08-12 13:33:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-08-12 13:33:11 --> Final output sent to browser
DEBUG - 2023-08-12 13:33:11 --> Total execution time: 0.6144
INFO - 2023-08-12 13:33:14 --> Config Class Initialized
INFO - 2023-08-12 13:33:14 --> Hooks Class Initialized
INFO - 2023-08-12 13:33:14 --> Config Class Initialized
DEBUG - 2023-08-12 13:33:14 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:33:14 --> Utf8 Class Initialized
INFO - 2023-08-12 13:33:14 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:33:14 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:33:14 --> URI Class Initialized
INFO - 2023-08-12 13:33:14 --> Utf8 Class Initialized
INFO - 2023-08-12 13:33:14 --> URI Class Initialized
INFO - 2023-08-12 13:33:14 --> Router Class Initialized
INFO - 2023-08-12 13:33:14 --> Router Class Initialized
INFO - 2023-08-12 13:33:14 --> Output Class Initialized
INFO - 2023-08-12 13:33:14 --> Output Class Initialized
INFO - 2023-08-12 13:33:14 --> Security Class Initialized
INFO - 2023-08-12 13:33:14 --> Security Class Initialized
DEBUG - 2023-08-12 13:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 13:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:33:14 --> Input Class Initialized
INFO - 2023-08-12 13:33:14 --> Input Class Initialized
INFO - 2023-08-12 13:33:14 --> Language Class Initialized
INFO - 2023-08-12 13:33:14 --> Language Class Initialized
ERROR - 2023-08-12 13:33:14 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-12 13:33:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 13:34:52 --> Config Class Initialized
INFO - 2023-08-12 13:34:52 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:34:52 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:34:52 --> Utf8 Class Initialized
INFO - 2023-08-12 13:34:52 --> URI Class Initialized
INFO - 2023-08-12 13:34:52 --> Router Class Initialized
INFO - 2023-08-12 13:34:52 --> Output Class Initialized
INFO - 2023-08-12 13:34:52 --> Security Class Initialized
DEBUG - 2023-08-12 13:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:34:52 --> Input Class Initialized
INFO - 2023-08-12 13:34:52 --> Language Class Initialized
INFO - 2023-08-12 13:34:52 --> Loader Class Initialized
INFO - 2023-08-12 13:34:52 --> Helper loaded: url_helper
INFO - 2023-08-12 13:34:52 --> Helper loaded: file_helper
INFO - 2023-08-12 13:34:52 --> Database Driver Class Initialized
INFO - 2023-08-12 13:34:52 --> Email Class Initialized
DEBUG - 2023-08-12 13:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 13:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 13:34:53 --> Controller Class Initialized
INFO - 2023-08-12 13:34:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-08-12 13:34:53 --> Final output sent to browser
DEBUG - 2023-08-12 13:34:53 --> Total execution time: 0.5706
INFO - 2023-08-12 13:34:53 --> Config Class Initialized
INFO - 2023-08-12 13:34:53 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:34:53 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:34:53 --> Utf8 Class Initialized
INFO - 2023-08-12 13:34:53 --> URI Class Initialized
INFO - 2023-08-12 13:34:53 --> Router Class Initialized
INFO - 2023-08-12 13:34:53 --> Output Class Initialized
INFO - 2023-08-12 13:34:53 --> Security Class Initialized
DEBUG - 2023-08-12 13:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:34:53 --> Config Class Initialized
INFO - 2023-08-12 13:34:53 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:34:53 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:34:53 --> Utf8 Class Initialized
INFO - 2023-08-12 13:34:53 --> URI Class Initialized
INFO - 2023-08-12 13:34:53 --> Router Class Initialized
INFO - 2023-08-12 13:34:53 --> Output Class Initialized
INFO - 2023-08-12 13:34:53 --> Security Class Initialized
DEBUG - 2023-08-12 13:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:34:53 --> Input Class Initialized
INFO - 2023-08-12 13:34:53 --> Language Class Initialized
ERROR - 2023-08-12 13:34:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 13:34:53 --> Input Class Initialized
INFO - 2023-08-12 13:34:54 --> Language Class Initialized
ERROR - 2023-08-12 13:34:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 13:35:14 --> Config Class Initialized
INFO - 2023-08-12 13:35:14 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:35:14 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:35:14 --> Utf8 Class Initialized
INFO - 2023-08-12 13:35:14 --> URI Class Initialized
INFO - 2023-08-12 13:35:14 --> Router Class Initialized
INFO - 2023-08-12 13:35:14 --> Output Class Initialized
INFO - 2023-08-12 13:35:14 --> Security Class Initialized
DEBUG - 2023-08-12 13:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:35:14 --> Input Class Initialized
INFO - 2023-08-12 13:35:14 --> Language Class Initialized
INFO - 2023-08-12 13:35:14 --> Loader Class Initialized
INFO - 2023-08-12 13:35:14 --> Helper loaded: url_helper
INFO - 2023-08-12 13:35:14 --> Helper loaded: file_helper
INFO - 2023-08-12 13:35:14 --> Database Driver Class Initialized
INFO - 2023-08-12 13:35:14 --> Email Class Initialized
DEBUG - 2023-08-12 13:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 13:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 13:35:14 --> Controller Class Initialized
INFO - 2023-08-12 13:35:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-08-12 13:35:14 --> Final output sent to browser
DEBUG - 2023-08-12 13:35:14 --> Total execution time: 0.7648
INFO - 2023-08-12 13:35:15 --> Config Class Initialized
INFO - 2023-08-12 13:35:15 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:35:15 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:35:15 --> Utf8 Class Initialized
INFO - 2023-08-12 13:35:15 --> URI Class Initialized
INFO - 2023-08-12 13:35:15 --> Router Class Initialized
INFO - 2023-08-12 13:35:15 --> Output Class Initialized
INFO - 2023-08-12 13:35:15 --> Security Class Initialized
DEBUG - 2023-08-12 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:35:15 --> Input Class Initialized
INFO - 2023-08-12 13:35:15 --> Language Class Initialized
ERROR - 2023-08-12 13:35:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 13:35:15 --> Config Class Initialized
INFO - 2023-08-12 13:35:15 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:35:15 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:35:15 --> Utf8 Class Initialized
INFO - 2023-08-12 13:35:15 --> URI Class Initialized
INFO - 2023-08-12 13:35:15 --> Router Class Initialized
INFO - 2023-08-12 13:35:15 --> Output Class Initialized
INFO - 2023-08-12 13:35:15 --> Security Class Initialized
DEBUG - 2023-08-12 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:35:15 --> Input Class Initialized
INFO - 2023-08-12 13:35:15 --> Language Class Initialized
ERROR - 2023-08-12 13:35:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 13:44:00 --> Config Class Initialized
INFO - 2023-08-12 13:44:00 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:44:00 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:44:00 --> Utf8 Class Initialized
INFO - 2023-08-12 13:44:00 --> URI Class Initialized
INFO - 2023-08-12 13:44:00 --> Router Class Initialized
INFO - 2023-08-12 13:44:00 --> Output Class Initialized
INFO - 2023-08-12 13:44:00 --> Security Class Initialized
DEBUG - 2023-08-12 13:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:44:00 --> Input Class Initialized
INFO - 2023-08-12 13:44:00 --> Language Class Initialized
INFO - 2023-08-12 13:44:01 --> Loader Class Initialized
INFO - 2023-08-12 13:44:01 --> Helper loaded: url_helper
INFO - 2023-08-12 13:44:01 --> Helper loaded: file_helper
INFO - 2023-08-12 13:44:01 --> Database Driver Class Initialized
INFO - 2023-08-12 13:44:01 --> Email Class Initialized
DEBUG - 2023-08-12 13:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 13:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 13:44:01 --> Controller Class Initialized
INFO - 2023-08-12 13:44:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-12 13:44:01 --> Final output sent to browser
DEBUG - 2023-08-12 13:44:01 --> Total execution time: 0.6492
INFO - 2023-08-12 13:44:01 --> Config Class Initialized
INFO - 2023-08-12 13:44:01 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:44:01 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:44:01 --> Utf8 Class Initialized
INFO - 2023-08-12 13:44:01 --> URI Class Initialized
INFO - 2023-08-12 13:44:01 --> Router Class Initialized
INFO - 2023-08-12 13:44:01 --> Output Class Initialized
INFO - 2023-08-12 13:44:01 --> Security Class Initialized
DEBUG - 2023-08-12 13:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:44:01 --> Input Class Initialized
INFO - 2023-08-12 13:44:02 --> Language Class Initialized
INFO - 2023-08-12 13:44:02 --> Config Class Initialized
INFO - 2023-08-12 13:44:02 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:44:02 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:44:02 --> Utf8 Class Initialized
INFO - 2023-08-12 13:44:02 --> URI Class Initialized
INFO - 2023-08-12 13:44:02 --> Router Class Initialized
INFO - 2023-08-12 13:44:02 --> Output Class Initialized
INFO - 2023-08-12 13:44:02 --> Security Class Initialized
INFO - 2023-08-12 13:44:02 --> Config Class Initialized
INFO - 2023-08-12 13:44:02 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:44:02 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:44:02 --> Utf8 Class Initialized
INFO - 2023-08-12 13:44:02 --> URI Class Initialized
INFO - 2023-08-12 13:44:02 --> Router Class Initialized
INFO - 2023-08-12 13:44:02 --> Output Class Initialized
INFO - 2023-08-12 13:44:02 --> Security Class Initialized
DEBUG - 2023-08-12 13:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:44:02 --> Input Class Initialized
INFO - 2023-08-12 13:44:02 --> Language Class Initialized
ERROR - 2023-08-12 13:44:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 13:44:02 --> Config Class Initialized
INFO - 2023-08-12 13:44:02 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:44:02 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:44:02 --> Utf8 Class Initialized
INFO - 2023-08-12 13:44:02 --> URI Class Initialized
INFO - 2023-08-12 13:44:02 --> Router Class Initialized
INFO - 2023-08-12 13:44:02 --> Output Class Initialized
INFO - 2023-08-12 13:44:02 --> Security Class Initialized
DEBUG - 2023-08-12 13:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:44:02 --> Input Class Initialized
INFO - 2023-08-12 13:44:02 --> Language Class Initialized
ERROR - 2023-08-12 13:44:02 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-12 13:44:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 13:44:03 --> Config Class Initialized
INFO - 2023-08-12 13:44:03 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:44:03 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:44:03 --> Utf8 Class Initialized
INFO - 2023-08-12 13:44:03 --> URI Class Initialized
INFO - 2023-08-12 13:44:03 --> Router Class Initialized
INFO - 2023-08-12 13:44:03 --> Output Class Initialized
INFO - 2023-08-12 13:44:03 --> Security Class Initialized
DEBUG - 2023-08-12 13:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:44:03 --> Input Class Initialized
INFO - 2023-08-12 13:44:03 --> Language Class Initialized
ERROR - 2023-08-12 13:44:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 13:44:03 --> Config Class Initialized
INFO - 2023-08-12 13:44:03 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:44:03 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:44:03 --> Utf8 Class Initialized
INFO - 2023-08-12 13:44:03 --> URI Class Initialized
INFO - 2023-08-12 13:44:03 --> Router Class Initialized
INFO - 2023-08-12 13:44:03 --> Output Class Initialized
INFO - 2023-08-12 13:44:03 --> Security Class Initialized
DEBUG - 2023-08-12 13:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:44:03 --> Input Class Initialized
INFO - 2023-08-12 13:44:03 --> Language Class Initialized
ERROR - 2023-08-12 13:44:03 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-12 13:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:44:03 --> Config Class Initialized
INFO - 2023-08-12 13:44:03 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:44:03 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:44:03 --> Utf8 Class Initialized
INFO - 2023-08-12 13:44:03 --> URI Class Initialized
INFO - 2023-08-12 13:44:03 --> Router Class Initialized
INFO - 2023-08-12 13:44:03 --> Output Class Initialized
INFO - 2023-08-12 13:44:03 --> Security Class Initialized
DEBUG - 2023-08-12 13:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:44:03 --> Input Class Initialized
INFO - 2023-08-12 13:44:03 --> Language Class Initialized
ERROR - 2023-08-12 13:44:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 13:44:03 --> Config Class Initialized
INFO - 2023-08-12 13:44:03 --> Hooks Class Initialized
INFO - 2023-08-12 13:44:03 --> Config Class Initialized
INFO - 2023-08-12 13:44:03 --> Input Class Initialized
INFO - 2023-08-12 13:44:03 --> Hooks Class Initialized
INFO - 2023-08-12 13:44:03 --> Language Class Initialized
DEBUG - 2023-08-12 13:44:03 --> UTF-8 Support Enabled
ERROR - 2023-08-12 13:44:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 13:44:03 --> Utf8 Class Initialized
INFO - 2023-08-12 13:44:03 --> URI Class Initialized
INFO - 2023-08-12 13:44:03 --> Router Class Initialized
INFO - 2023-08-12 13:44:03 --> Output Class Initialized
INFO - 2023-08-12 13:44:03 --> Security Class Initialized
DEBUG - 2023-08-12 13:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:44:03 --> Input Class Initialized
INFO - 2023-08-12 13:44:03 --> Language Class Initialized
ERROR - 2023-08-12 13:44:03 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-12 13:44:03 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:44:03 --> Utf8 Class Initialized
INFO - 2023-08-12 13:44:03 --> URI Class Initialized
INFO - 2023-08-12 13:44:03 --> Router Class Initialized
INFO - 2023-08-12 13:44:03 --> Output Class Initialized
INFO - 2023-08-12 13:44:03 --> Security Class Initialized
DEBUG - 2023-08-12 13:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:44:03 --> Input Class Initialized
INFO - 2023-08-12 13:44:03 --> Language Class Initialized
ERROR - 2023-08-12 13:44:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 13:46:14 --> Config Class Initialized
INFO - 2023-08-12 13:46:14 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:46:14 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:46:14 --> Utf8 Class Initialized
INFO - 2023-08-12 13:46:14 --> URI Class Initialized
INFO - 2023-08-12 13:46:14 --> Router Class Initialized
INFO - 2023-08-12 13:46:14 --> Output Class Initialized
INFO - 2023-08-12 13:46:14 --> Security Class Initialized
DEBUG - 2023-08-12 13:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:46:14 --> Input Class Initialized
INFO - 2023-08-12 13:46:14 --> Language Class Initialized
INFO - 2023-08-12 13:46:15 --> Loader Class Initialized
INFO - 2023-08-12 13:46:15 --> Helper loaded: url_helper
INFO - 2023-08-12 13:46:15 --> Helper loaded: file_helper
INFO - 2023-08-12 13:46:15 --> Database Driver Class Initialized
INFO - 2023-08-12 13:46:15 --> Email Class Initialized
DEBUG - 2023-08-12 13:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 13:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 13:46:15 --> Controller Class Initialized
INFO - 2023-08-12 13:46:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-12 13:46:15 --> Final output sent to browser
DEBUG - 2023-08-12 13:46:15 --> Total execution time: 0.3810
INFO - 2023-08-12 13:46:15 --> Config Class Initialized
INFO - 2023-08-12 13:46:15 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:46:15 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:46:15 --> Utf8 Class Initialized
INFO - 2023-08-12 13:46:15 --> URI Class Initialized
INFO - 2023-08-12 13:46:15 --> Router Class Initialized
INFO - 2023-08-12 13:46:15 --> Output Class Initialized
INFO - 2023-08-12 13:46:15 --> Security Class Initialized
DEBUG - 2023-08-12 13:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:46:15 --> Input Class Initialized
INFO - 2023-08-12 13:46:15 --> Language Class Initialized
ERROR - 2023-08-12 13:46:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 13:46:16 --> Config Class Initialized
INFO - 2023-08-12 13:46:16 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:46:16 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:46:16 --> Utf8 Class Initialized
INFO - 2023-08-12 13:46:16 --> URI Class Initialized
INFO - 2023-08-12 13:46:16 --> Router Class Initialized
INFO - 2023-08-12 13:46:16 --> Output Class Initialized
INFO - 2023-08-12 13:46:16 --> Security Class Initialized
DEBUG - 2023-08-12 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:46:16 --> Input Class Initialized
INFO - 2023-08-12 13:46:16 --> Language Class Initialized
ERROR - 2023-08-12 13:46:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-12 13:46:16 --> Config Class Initialized
INFO - 2023-08-12 13:46:16 --> Config Class Initialized
INFO - 2023-08-12 13:46:16 --> Hooks Class Initialized
INFO - 2023-08-12 13:46:16 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:46:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 13:46:16 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:46:16 --> Utf8 Class Initialized
INFO - 2023-08-12 13:46:16 --> URI Class Initialized
INFO - 2023-08-12 13:46:16 --> Router Class Initialized
INFO - 2023-08-12 13:46:16 --> Output Class Initialized
INFO - 2023-08-12 13:46:16 --> Security Class Initialized
DEBUG - 2023-08-12 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:46:16 --> Input Class Initialized
INFO - 2023-08-12 13:46:16 --> Language Class Initialized
ERROR - 2023-08-12 13:46:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 13:46:16 --> Utf8 Class Initialized
INFO - 2023-08-12 13:46:16 --> URI Class Initialized
INFO - 2023-08-12 13:46:16 --> Router Class Initialized
INFO - 2023-08-12 13:46:16 --> Output Class Initialized
INFO - 2023-08-12 13:46:16 --> Security Class Initialized
DEBUG - 2023-08-12 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:46:16 --> Input Class Initialized
INFO - 2023-08-12 13:46:16 --> Language Class Initialized
ERROR - 2023-08-12 13:46:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-12 13:49:30 --> Config Class Initialized
INFO - 2023-08-12 13:49:30 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:49:30 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:49:30 --> Utf8 Class Initialized
INFO - 2023-08-12 13:49:30 --> URI Class Initialized
INFO - 2023-08-12 13:49:30 --> Router Class Initialized
INFO - 2023-08-12 13:49:30 --> Output Class Initialized
INFO - 2023-08-12 13:49:30 --> Security Class Initialized
DEBUG - 2023-08-12 13:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:49:30 --> Input Class Initialized
INFO - 2023-08-12 13:49:30 --> Language Class Initialized
ERROR - 2023-08-12 13:49:30 --> 404 Page Not Found: Indexhtml/index
INFO - 2023-08-12 13:49:31 --> Config Class Initialized
INFO - 2023-08-12 13:49:31 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:49:31 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:49:31 --> Utf8 Class Initialized
INFO - 2023-08-12 13:49:31 --> URI Class Initialized
INFO - 2023-08-12 13:49:31 --> Router Class Initialized
INFO - 2023-08-12 13:49:31 --> Output Class Initialized
INFO - 2023-08-12 13:49:31 --> Security Class Initialized
DEBUG - 2023-08-12 13:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:49:31 --> Input Class Initialized
INFO - 2023-08-12 13:49:31 --> Language Class Initialized
INFO - 2023-08-12 13:49:31 --> Loader Class Initialized
INFO - 2023-08-12 13:49:31 --> Helper loaded: url_helper
INFO - 2023-08-12 13:49:31 --> Helper loaded: file_helper
INFO - 2023-08-12 13:49:31 --> Database Driver Class Initialized
INFO - 2023-08-12 13:49:31 --> Email Class Initialized
DEBUG - 2023-08-12 13:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 13:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 13:49:31 --> Controller Class Initialized
INFO - 2023-08-12 13:49:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-12 13:49:31 --> Final output sent to browser
DEBUG - 2023-08-12 13:49:31 --> Total execution time: 0.0420
INFO - 2023-08-12 13:49:37 --> Config Class Initialized
INFO - 2023-08-12 13:49:37 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:49:37 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:49:37 --> Utf8 Class Initialized
INFO - 2023-08-12 13:49:37 --> URI Class Initialized
INFO - 2023-08-12 13:49:37 --> Router Class Initialized
INFO - 2023-08-12 13:49:37 --> Output Class Initialized
INFO - 2023-08-12 13:49:37 --> Security Class Initialized
DEBUG - 2023-08-12 13:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:49:37 --> Input Class Initialized
INFO - 2023-08-12 13:49:37 --> Language Class Initialized
INFO - 2023-08-12 13:49:37 --> Loader Class Initialized
INFO - 2023-08-12 13:49:37 --> Helper loaded: url_helper
INFO - 2023-08-12 13:49:37 --> Helper loaded: file_helper
INFO - 2023-08-12 13:49:37 --> Database Driver Class Initialized
INFO - 2023-08-12 13:49:37 --> Email Class Initialized
DEBUG - 2023-08-12 13:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 13:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 13:49:37 --> Controller Class Initialized
INFO - 2023-08-12 13:49:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-08-12 13:49:38 --> Config Class Initialized
INFO - 2023-08-12 13:49:38 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:49:38 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:49:38 --> Utf8 Class Initialized
INFO - 2023-08-12 13:49:38 --> URI Class Initialized
INFO - 2023-08-12 13:49:38 --> Router Class Initialized
INFO - 2023-08-12 13:49:38 --> Output Class Initialized
INFO - 2023-08-12 13:49:38 --> Security Class Initialized
DEBUG - 2023-08-12 13:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:49:38 --> Input Class Initialized
INFO - 2023-08-12 13:49:38 --> Language Class Initialized
ERROR - 2023-08-12 13:49:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 13:49:38 --> Final output sent to browser
DEBUG - 2023-08-12 13:49:38 --> Total execution time: 0.3518
INFO - 2023-08-12 13:49:38 --> Config Class Initialized
INFO - 2023-08-12 13:49:39 --> Hooks Class Initialized
DEBUG - 2023-08-12 13:49:39 --> UTF-8 Support Enabled
INFO - 2023-08-12 13:49:39 --> Utf8 Class Initialized
INFO - 2023-08-12 13:49:39 --> URI Class Initialized
INFO - 2023-08-12 13:49:39 --> Router Class Initialized
INFO - 2023-08-12 13:49:39 --> Output Class Initialized
INFO - 2023-08-12 13:49:39 --> Security Class Initialized
DEBUG - 2023-08-12 13:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 13:49:39 --> Input Class Initialized
INFO - 2023-08-12 13:49:39 --> Language Class Initialized
ERROR - 2023-08-12 13:49:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 14:54:07 --> Config Class Initialized
INFO - 2023-08-12 14:54:07 --> Hooks Class Initialized
DEBUG - 2023-08-12 14:54:07 --> UTF-8 Support Enabled
INFO - 2023-08-12 14:54:08 --> Utf8 Class Initialized
INFO - 2023-08-12 14:54:08 --> URI Class Initialized
INFO - 2023-08-12 14:54:08 --> Router Class Initialized
INFO - 2023-08-12 14:54:08 --> Output Class Initialized
INFO - 2023-08-12 14:54:08 --> Security Class Initialized
DEBUG - 2023-08-12 14:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 14:54:08 --> Input Class Initialized
INFO - 2023-08-12 14:54:08 --> Language Class Initialized
ERROR - 2023-08-12 14:54:08 --> 404 Page Not Found: /index
INFO - 2023-08-12 14:54:11 --> Config Class Initialized
INFO - 2023-08-12 14:54:11 --> Hooks Class Initialized
DEBUG - 2023-08-12 14:54:11 --> UTF-8 Support Enabled
INFO - 2023-08-12 14:54:11 --> Utf8 Class Initialized
INFO - 2023-08-12 14:54:11 --> URI Class Initialized
INFO - 2023-08-12 14:54:11 --> Router Class Initialized
INFO - 2023-08-12 14:54:11 --> Output Class Initialized
INFO - 2023-08-12 14:54:11 --> Security Class Initialized
DEBUG - 2023-08-12 14:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 14:54:11 --> Input Class Initialized
INFO - 2023-08-12 14:54:11 --> Language Class Initialized
ERROR - 2023-08-12 14:54:11 --> 404 Page Not Found: /index
INFO - 2023-08-12 14:57:07 --> Config Class Initialized
INFO - 2023-08-12 14:57:07 --> Hooks Class Initialized
DEBUG - 2023-08-12 14:57:07 --> UTF-8 Support Enabled
INFO - 2023-08-12 14:57:07 --> Utf8 Class Initialized
INFO - 2023-08-12 14:57:07 --> URI Class Initialized
INFO - 2023-08-12 14:57:07 --> Router Class Initialized
INFO - 2023-08-12 14:57:07 --> Output Class Initialized
INFO - 2023-08-12 14:57:07 --> Security Class Initialized
DEBUG - 2023-08-12 14:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 14:57:07 --> Input Class Initialized
INFO - 2023-08-12 14:57:07 --> Language Class Initialized
ERROR - 2023-08-12 14:57:07 --> 404 Page Not Found: /index
INFO - 2023-08-12 14:57:19 --> Config Class Initialized
INFO - 2023-08-12 14:57:19 --> Hooks Class Initialized
DEBUG - 2023-08-12 14:57:19 --> UTF-8 Support Enabled
INFO - 2023-08-12 14:57:19 --> Utf8 Class Initialized
INFO - 2023-08-12 14:57:19 --> URI Class Initialized
INFO - 2023-08-12 14:57:19 --> Router Class Initialized
INFO - 2023-08-12 14:57:19 --> Output Class Initialized
INFO - 2023-08-12 14:57:19 --> Security Class Initialized
DEBUG - 2023-08-12 14:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 14:57:19 --> Input Class Initialized
INFO - 2023-08-12 14:57:19 --> Language Class Initialized
ERROR - 2023-08-12 14:57:19 --> 404 Page Not Found: /index
INFO - 2023-08-12 14:57:33 --> Config Class Initialized
INFO - 2023-08-12 14:57:33 --> Hooks Class Initialized
DEBUG - 2023-08-12 14:57:33 --> UTF-8 Support Enabled
INFO - 2023-08-12 14:57:33 --> Utf8 Class Initialized
INFO - 2023-08-12 14:57:33 --> URI Class Initialized
INFO - 2023-08-12 14:57:33 --> Router Class Initialized
INFO - 2023-08-12 14:57:33 --> Output Class Initialized
INFO - 2023-08-12 14:57:33 --> Security Class Initialized
DEBUG - 2023-08-12 14:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 14:57:34 --> Input Class Initialized
INFO - 2023-08-12 14:57:34 --> Language Class Initialized
ERROR - 2023-08-12 14:57:34 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:00:30 --> Config Class Initialized
INFO - 2023-08-12 15:00:30 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:00:30 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:00:30 --> Utf8 Class Initialized
INFO - 2023-08-12 15:00:30 --> URI Class Initialized
DEBUG - 2023-08-12 15:00:30 --> No URI present. Default controller set.
INFO - 2023-08-12 15:00:30 --> Router Class Initialized
INFO - 2023-08-12 15:00:30 --> Output Class Initialized
INFO - 2023-08-12 15:00:30 --> Security Class Initialized
DEBUG - 2023-08-12 15:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:00:30 --> Input Class Initialized
INFO - 2023-08-12 15:00:30 --> Language Class Initialized
INFO - 2023-08-12 15:00:30 --> Loader Class Initialized
INFO - 2023-08-12 15:00:30 --> Helper loaded: url_helper
INFO - 2023-08-12 15:00:30 --> Helper loaded: file_helper
INFO - 2023-08-12 15:00:30 --> Database Driver Class Initialized
INFO - 2023-08-12 15:00:30 --> Email Class Initialized
DEBUG - 2023-08-12 15:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 15:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 15:00:31 --> Controller Class Initialized
INFO - 2023-08-12 15:00:31 --> File loaded: C:\xampp\htdocs\dw\application\views\welcome_message.php
INFO - 2023-08-12 15:00:31 --> Final output sent to browser
DEBUG - 2023-08-12 15:00:31 --> Total execution time: 0.9012
INFO - 2023-08-12 15:00:47 --> Config Class Initialized
INFO - 2023-08-12 15:00:47 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:00:47 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:00:47 --> Utf8 Class Initialized
INFO - 2023-08-12 15:00:47 --> URI Class Initialized
INFO - 2023-08-12 15:00:48 --> Router Class Initialized
INFO - 2023-08-12 15:00:48 --> Output Class Initialized
INFO - 2023-08-12 15:00:48 --> Security Class Initialized
DEBUG - 2023-08-12 15:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:00:48 --> Input Class Initialized
INFO - 2023-08-12 15:00:48 --> Language Class Initialized
ERROR - 2023-08-12 15:00:48 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:00:49 --> Config Class Initialized
INFO - 2023-08-12 15:00:49 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:00:49 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:00:49 --> Utf8 Class Initialized
INFO - 2023-08-12 15:00:49 --> URI Class Initialized
INFO - 2023-08-12 15:00:49 --> Router Class Initialized
INFO - 2023-08-12 15:00:49 --> Output Class Initialized
INFO - 2023-08-12 15:00:49 --> Security Class Initialized
DEBUG - 2023-08-12 15:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:00:49 --> Input Class Initialized
INFO - 2023-08-12 15:00:49 --> Language Class Initialized
ERROR - 2023-08-12 15:00:49 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:00:50 --> Config Class Initialized
INFO - 2023-08-12 15:00:50 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:00:50 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:00:50 --> Utf8 Class Initialized
INFO - 2023-08-12 15:00:50 --> URI Class Initialized
INFO - 2023-08-12 15:00:50 --> Router Class Initialized
INFO - 2023-08-12 15:00:50 --> Output Class Initialized
INFO - 2023-08-12 15:00:50 --> Security Class Initialized
DEBUG - 2023-08-12 15:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:00:50 --> Input Class Initialized
INFO - 2023-08-12 15:00:50 --> Language Class Initialized
ERROR - 2023-08-12 15:00:50 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:00:51 --> Config Class Initialized
INFO - 2023-08-12 15:00:51 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:00:51 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:00:51 --> Utf8 Class Initialized
INFO - 2023-08-12 15:00:51 --> URI Class Initialized
INFO - 2023-08-12 15:00:51 --> Router Class Initialized
INFO - 2023-08-12 15:00:51 --> Output Class Initialized
INFO - 2023-08-12 15:00:51 --> Security Class Initialized
DEBUG - 2023-08-12 15:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:00:51 --> Input Class Initialized
INFO - 2023-08-12 15:00:51 --> Language Class Initialized
ERROR - 2023-08-12 15:00:51 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:01:42 --> Config Class Initialized
INFO - 2023-08-12 15:01:42 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:01:42 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:01:42 --> Utf8 Class Initialized
INFO - 2023-08-12 15:01:42 --> URI Class Initialized
INFO - 2023-08-12 15:01:42 --> Router Class Initialized
INFO - 2023-08-12 15:01:42 --> Output Class Initialized
INFO - 2023-08-12 15:01:42 --> Security Class Initialized
DEBUG - 2023-08-12 15:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:01:42 --> Input Class Initialized
INFO - 2023-08-12 15:01:42 --> Language Class Initialized
ERROR - 2023-08-12 15:01:42 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:01:43 --> Config Class Initialized
INFO - 2023-08-12 15:01:43 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:01:43 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:01:43 --> Utf8 Class Initialized
INFO - 2023-08-12 15:01:43 --> URI Class Initialized
INFO - 2023-08-12 15:01:43 --> Router Class Initialized
INFO - 2023-08-12 15:01:43 --> Output Class Initialized
INFO - 2023-08-12 15:01:43 --> Security Class Initialized
DEBUG - 2023-08-12 15:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:01:43 --> Input Class Initialized
INFO - 2023-08-12 15:01:43 --> Language Class Initialized
ERROR - 2023-08-12 15:01:43 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:01:43 --> Config Class Initialized
INFO - 2023-08-12 15:01:43 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:01:43 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:01:43 --> Utf8 Class Initialized
INFO - 2023-08-12 15:01:43 --> URI Class Initialized
INFO - 2023-08-12 15:01:43 --> Router Class Initialized
INFO - 2023-08-12 15:01:43 --> Output Class Initialized
INFO - 2023-08-12 15:01:43 --> Security Class Initialized
DEBUG - 2023-08-12 15:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:01:43 --> Input Class Initialized
INFO - 2023-08-12 15:01:43 --> Language Class Initialized
ERROR - 2023-08-12 15:01:43 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:01:44 --> Config Class Initialized
INFO - 2023-08-12 15:01:44 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:01:44 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:01:44 --> Utf8 Class Initialized
INFO - 2023-08-12 15:01:44 --> URI Class Initialized
INFO - 2023-08-12 15:01:44 --> Router Class Initialized
INFO - 2023-08-12 15:01:44 --> Output Class Initialized
INFO - 2023-08-12 15:01:44 --> Security Class Initialized
DEBUG - 2023-08-12 15:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:01:44 --> Input Class Initialized
INFO - 2023-08-12 15:01:44 --> Language Class Initialized
ERROR - 2023-08-12 15:01:44 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:01:44 --> Config Class Initialized
INFO - 2023-08-12 15:01:44 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:01:44 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:01:44 --> Utf8 Class Initialized
INFO - 2023-08-12 15:01:44 --> URI Class Initialized
INFO - 2023-08-12 15:01:44 --> Router Class Initialized
INFO - 2023-08-12 15:01:44 --> Output Class Initialized
INFO - 2023-08-12 15:01:44 --> Security Class Initialized
DEBUG - 2023-08-12 15:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:01:44 --> Input Class Initialized
INFO - 2023-08-12 15:01:44 --> Language Class Initialized
ERROR - 2023-08-12 15:01:44 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:01:45 --> Config Class Initialized
INFO - 2023-08-12 15:01:45 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:01:45 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:01:45 --> Utf8 Class Initialized
INFO - 2023-08-12 15:01:45 --> URI Class Initialized
INFO - 2023-08-12 15:01:45 --> Router Class Initialized
INFO - 2023-08-12 15:01:45 --> Output Class Initialized
INFO - 2023-08-12 15:01:45 --> Security Class Initialized
DEBUG - 2023-08-12 15:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:01:45 --> Input Class Initialized
INFO - 2023-08-12 15:01:45 --> Language Class Initialized
ERROR - 2023-08-12 15:01:45 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:01:47 --> Config Class Initialized
INFO - 2023-08-12 15:01:47 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:01:47 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:01:47 --> Utf8 Class Initialized
INFO - 2023-08-12 15:01:47 --> URI Class Initialized
INFO - 2023-08-12 15:01:47 --> Router Class Initialized
INFO - 2023-08-12 15:01:47 --> Output Class Initialized
INFO - 2023-08-12 15:01:47 --> Security Class Initialized
DEBUG - 2023-08-12 15:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:01:47 --> Input Class Initialized
INFO - 2023-08-12 15:01:47 --> Language Class Initialized
ERROR - 2023-08-12 15:01:47 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:01:47 --> Config Class Initialized
INFO - 2023-08-12 15:01:47 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:01:47 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:01:47 --> Utf8 Class Initialized
INFO - 2023-08-12 15:01:47 --> URI Class Initialized
INFO - 2023-08-12 15:01:47 --> Router Class Initialized
INFO - 2023-08-12 15:01:47 --> Output Class Initialized
INFO - 2023-08-12 15:01:47 --> Security Class Initialized
DEBUG - 2023-08-12 15:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:01:47 --> Input Class Initialized
INFO - 2023-08-12 15:01:47 --> Language Class Initialized
ERROR - 2023-08-12 15:01:47 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:01:48 --> Config Class Initialized
INFO - 2023-08-12 15:01:48 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:01:48 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:01:48 --> Utf8 Class Initialized
INFO - 2023-08-12 15:01:48 --> URI Class Initialized
INFO - 2023-08-12 15:01:48 --> Router Class Initialized
INFO - 2023-08-12 15:01:48 --> Output Class Initialized
INFO - 2023-08-12 15:01:48 --> Security Class Initialized
DEBUG - 2023-08-12 15:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:01:48 --> Input Class Initialized
INFO - 2023-08-12 15:01:48 --> Language Class Initialized
ERROR - 2023-08-12 15:01:48 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:01:48 --> Config Class Initialized
INFO - 2023-08-12 15:01:48 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:01:48 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:01:48 --> Utf8 Class Initialized
INFO - 2023-08-12 15:01:48 --> URI Class Initialized
INFO - 2023-08-12 15:01:48 --> Router Class Initialized
INFO - 2023-08-12 15:01:48 --> Output Class Initialized
INFO - 2023-08-12 15:01:48 --> Security Class Initialized
DEBUG - 2023-08-12 15:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:01:48 --> Input Class Initialized
INFO - 2023-08-12 15:01:48 --> Language Class Initialized
ERROR - 2023-08-12 15:01:48 --> 404 Page Not Found: /index
INFO - 2023-08-12 15:02:05 --> Config Class Initialized
INFO - 2023-08-12 15:02:05 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:02:05 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:02:05 --> Utf8 Class Initialized
INFO - 2023-08-12 15:02:05 --> URI Class Initialized
INFO - 2023-08-12 15:02:05 --> Router Class Initialized
INFO - 2023-08-12 15:02:05 --> Output Class Initialized
INFO - 2023-08-12 15:02:05 --> Security Class Initialized
DEBUG - 2023-08-12 15:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:02:05 --> Input Class Initialized
INFO - 2023-08-12 15:02:05 --> Language Class Initialized
INFO - 2023-08-12 15:02:05 --> Loader Class Initialized
INFO - 2023-08-12 15:02:05 --> Helper loaded: url_helper
INFO - 2023-08-12 15:02:05 --> Helper loaded: file_helper
INFO - 2023-08-12 15:02:05 --> Database Driver Class Initialized
INFO - 2023-08-12 15:02:05 --> Email Class Initialized
DEBUG - 2023-08-12 15:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 15:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 15:02:05 --> Controller Class Initialized
INFO - 2023-08-12 15:02:13 --> Config Class Initialized
INFO - 2023-08-12 15:02:13 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:02:13 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:02:13 --> Utf8 Class Initialized
INFO - 2023-08-12 15:02:13 --> URI Class Initialized
INFO - 2023-08-12 15:02:13 --> Router Class Initialized
INFO - 2023-08-12 15:02:13 --> Output Class Initialized
INFO - 2023-08-12 15:02:13 --> Security Class Initialized
DEBUG - 2023-08-12 15:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:02:13 --> Input Class Initialized
INFO - 2023-08-12 15:02:13 --> Language Class Initialized
INFO - 2023-08-12 15:02:13 --> Loader Class Initialized
INFO - 2023-08-12 15:02:14 --> Helper loaded: url_helper
INFO - 2023-08-12 15:02:14 --> Helper loaded: file_helper
INFO - 2023-08-12 15:02:14 --> Database Driver Class Initialized
INFO - 2023-08-12 15:02:14 --> Email Class Initialized
DEBUG - 2023-08-12 15:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 15:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 15:02:14 --> Controller Class Initialized
INFO - 2023-08-12 15:03:30 --> Config Class Initialized
INFO - 2023-08-12 15:03:30 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:03:30 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:30 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:30 --> URI Class Initialized
INFO - 2023-08-12 15:03:30 --> Router Class Initialized
INFO - 2023-08-12 15:03:30 --> Output Class Initialized
INFO - 2023-08-12 15:03:30 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:30 --> Input Class Initialized
INFO - 2023-08-12 15:03:30 --> Language Class Initialized
INFO - 2023-08-12 15:03:31 --> Loader Class Initialized
INFO - 2023-08-12 15:03:31 --> Helper loaded: url_helper
INFO - 2023-08-12 15:03:31 --> Helper loaded: file_helper
INFO - 2023-08-12 15:03:31 --> Database Driver Class Initialized
INFO - 2023-08-12 15:03:31 --> Email Class Initialized
DEBUG - 2023-08-12 15:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 15:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 15:03:31 --> Controller Class Initialized
INFO - 2023-08-12 15:03:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-12 15:03:31 --> Final output sent to browser
DEBUG - 2023-08-12 15:03:31 --> Total execution time: 0.6083
INFO - 2023-08-12 15:03:32 --> Config Class Initialized
INFO - 2023-08-12 15:03:32 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:03:32 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:32 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:32 --> URI Class Initialized
INFO - 2023-08-12 15:03:32 --> Router Class Initialized
INFO - 2023-08-12 15:03:32 --> Output Class Initialized
INFO - 2023-08-12 15:03:32 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:32 --> Input Class Initialized
INFO - 2023-08-12 15:03:32 --> Language Class Initialized
ERROR - 2023-08-12 15:03:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:03:32 --> Config Class Initialized
INFO - 2023-08-12 15:03:32 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:33 --> Config Class Initialized
INFO - 2023-08-12 15:03:33 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:03:33 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:33 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:33 --> URI Class Initialized
INFO - 2023-08-12 15:03:33 --> Router Class Initialized
INFO - 2023-08-12 15:03:33 --> Output Class Initialized
INFO - 2023-08-12 15:03:33 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:33 --> Input Class Initialized
INFO - 2023-08-12 15:03:33 --> Language Class Initialized
ERROR - 2023-08-12 15:03:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:03:33 --> Config Class Initialized
INFO - 2023-08-12 15:03:33 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:03:33 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:33 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:33 --> URI Class Initialized
INFO - 2023-08-12 15:03:33 --> Router Class Initialized
INFO - 2023-08-12 15:03:34 --> Output Class Initialized
INFO - 2023-08-12 15:03:34 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:34 --> Input Class Initialized
INFO - 2023-08-12 15:03:34 --> Language Class Initialized
ERROR - 2023-08-12 15:03:34 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-12 15:03:35 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:35 --> Config Class Initialized
INFO - 2023-08-12 15:03:35 --> Config Class Initialized
INFO - 2023-08-12 15:03:35 --> Config Class Initialized
INFO - 2023-08-12 15:03:35 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:35 --> Config Class Initialized
INFO - 2023-08-12 15:03:35 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:03:35 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:35 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:35 --> URI Class Initialized
INFO - 2023-08-12 15:03:35 --> Router Class Initialized
INFO - 2023-08-12 15:03:35 --> Output Class Initialized
INFO - 2023-08-12 15:03:35 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:35 --> Input Class Initialized
INFO - 2023-08-12 15:03:35 --> Language Class Initialized
ERROR - 2023-08-12 15:03:35 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:03:35 --> Config Class Initialized
INFO - 2023-08-12 15:03:35 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:35 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:35 --> URI Class Initialized
INFO - 2023-08-12 15:03:35 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:03:35 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:35 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:35 --> URI Class Initialized
INFO - 2023-08-12 15:03:35 --> Router Class Initialized
INFO - 2023-08-12 15:03:35 --> Output Class Initialized
INFO - 2023-08-12 15:03:35 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:35 --> Input Class Initialized
INFO - 2023-08-12 15:03:35 --> Language Class Initialized
ERROR - 2023-08-12 15:03:35 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-12 15:03:35 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:35 --> Config Class Initialized
DEBUG - 2023-08-12 15:03:35 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:35 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:35 --> URI Class Initialized
INFO - 2023-08-12 15:03:35 --> Router Class Initialized
INFO - 2023-08-12 15:03:35 --> Output Class Initialized
INFO - 2023-08-12 15:03:35 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:35 --> Input Class Initialized
INFO - 2023-08-12 15:03:35 --> Language Class Initialized
ERROR - 2023-08-12 15:03:35 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:03:36 --> Config Class Initialized
INFO - 2023-08-12 15:03:36 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:36 --> Router Class Initialized
INFO - 2023-08-12 15:03:36 --> Output Class Initialized
INFO - 2023-08-12 15:03:36 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:36 --> Utf8 Class Initialized
DEBUG - 2023-08-12 15:03:36 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:36 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:36 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:36 --> URI Class Initialized
INFO - 2023-08-12 15:03:36 --> URI Class Initialized
INFO - 2023-08-12 15:03:36 --> Security Class Initialized
INFO - 2023-08-12 15:03:36 --> Config Class Initialized
DEBUG - 2023-08-12 15:03:36 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:36 --> Router Class Initialized
DEBUG - 2023-08-12 15:03:36 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:36 --> Router Class Initialized
INFO - 2023-08-12 15:03:36 --> Output Class Initialized
DEBUG - 2023-08-12 15:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:36 --> Input Class Initialized
INFO - 2023-08-12 15:03:36 --> Language Class Initialized
ERROR - 2023-08-12 15:03:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:03:36 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:36 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:36 --> Security Class Initialized
INFO - 2023-08-12 15:03:36 --> Output Class Initialized
INFO - 2023-08-12 15:03:36 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:36 --> URI Class Initialized
INFO - 2023-08-12 15:03:36 --> Router Class Initialized
INFO - 2023-08-12 15:03:36 --> Output Class Initialized
INFO - 2023-08-12 15:03:36 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:36 --> Input Class Initialized
INFO - 2023-08-12 15:03:36 --> Language Class Initialized
ERROR - 2023-08-12 15:03:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:03:36 --> Utf8 Class Initialized
DEBUG - 2023-08-12 15:03:36 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:36 --> Config Class Initialized
INFO - 2023-08-12 15:03:36 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:03:36 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:36 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:36 --> URI Class Initialized
INFO - 2023-08-12 15:03:36 --> Router Class Initialized
INFO - 2023-08-12 15:03:36 --> Output Class Initialized
INFO - 2023-08-12 15:03:36 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:36 --> Input Class Initialized
INFO - 2023-08-12 15:03:36 --> Language Class Initialized
ERROR - 2023-08-12 15:03:36 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-12 15:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:36 --> Input Class Initialized
INFO - 2023-08-12 15:03:36 --> URI Class Initialized
INFO - 2023-08-12 15:03:36 --> Language Class Initialized
INFO - 2023-08-12 15:03:36 --> Utf8 Class Initialized
ERROR - 2023-08-12 15:03:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:03:36 --> Input Class Initialized
INFO - 2023-08-12 15:03:36 --> Router Class Initialized
INFO - 2023-08-12 15:03:36 --> URI Class Initialized
INFO - 2023-08-12 15:03:36 --> Output Class Initialized
INFO - 2023-08-12 15:03:36 --> Language Class Initialized
ERROR - 2023-08-12 15:03:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:03:36 --> Config Class Initialized
INFO - 2023-08-12 15:03:36 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:36 --> Router Class Initialized
INFO - 2023-08-12 15:03:36 --> Config Class Initialized
INFO - 2023-08-12 15:03:36 --> Security Class Initialized
INFO - 2023-08-12 15:03:36 --> Config Class Initialized
INFO - 2023-08-12 15:03:37 --> Output Class Initialized
INFO - 2023-08-12 15:03:37 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:03:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:37 --> Config Class Initialized
DEBUG - 2023-08-12 15:03:37 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:37 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:37 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:37 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:37 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:37 --> Security Class Initialized
INFO - 2023-08-12 15:03:37 --> URI Class Initialized
INFO - 2023-08-12 15:03:37 --> Router Class Initialized
INFO - 2023-08-12 15:03:37 --> Output Class Initialized
INFO - 2023-08-12 15:03:37 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:37 --> Input Class Initialized
INFO - 2023-08-12 15:03:37 --> Language Class Initialized
ERROR - 2023-08-12 15:03:37 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-12 15:03:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:37 --> Input Class Initialized
INFO - 2023-08-12 15:03:37 --> Input Class Initialized
INFO - 2023-08-12 15:03:37 --> URI Class Initialized
INFO - 2023-08-12 15:03:37 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:37 --> URI Class Initialized
INFO - 2023-08-12 15:03:37 --> Language Class Initialized
INFO - 2023-08-12 15:03:37 --> Language Class Initialized
DEBUG - 2023-08-12 15:03:37 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:37 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:37 --> URI Class Initialized
INFO - 2023-08-12 15:03:37 --> Router Class Initialized
INFO - 2023-08-12 15:03:37 --> Output Class Initialized
INFO - 2023-08-12 15:03:37 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:37 --> Input Class Initialized
INFO - 2023-08-12 15:03:37 --> Language Class Initialized
ERROR - 2023-08-12 15:03:37 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-12 15:03:37 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-12 15:03:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:03:37 --> Config Class Initialized
INFO - 2023-08-12 15:03:37 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:37 --> Router Class Initialized
INFO - 2023-08-12 15:03:37 --> Config Class Initialized
INFO - 2023-08-12 15:03:37 --> Config Class Initialized
INFO - 2023-08-12 15:03:37 --> Router Class Initialized
INFO - 2023-08-12 15:03:37 --> Output Class Initialized
INFO - 2023-08-12 15:03:37 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:37 --> Input Class Initialized
INFO - 2023-08-12 15:03:37 --> Language Class Initialized
ERROR - 2023-08-12 15:03:37 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-12 15:03:37 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:37 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:37 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:37 --> URI Class Initialized
INFO - 2023-08-12 15:03:37 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:37 --> Router Class Initialized
INFO - 2023-08-12 15:03:37 --> Output Class Initialized
DEBUG - 2023-08-12 15:03:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-12 15:03:37 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:37 --> Config Class Initialized
INFO - 2023-08-12 15:03:37 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:37 --> Config Class Initialized
INFO - 2023-08-12 15:03:37 --> Security Class Initialized
INFO - 2023-08-12 15:03:37 --> Output Class Initialized
INFO - 2023-08-12 15:03:37 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:37 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:37 --> URI Class Initialized
INFO - 2023-08-12 15:03:37 --> Router Class Initialized
DEBUG - 2023-08-12 15:03:37 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:37 --> Input Class Initialized
INFO - 2023-08-12 15:03:37 --> URI Class Initialized
INFO - 2023-08-12 15:03:37 --> Router Class Initialized
INFO - 2023-08-12 15:03:37 --> Output Class Initialized
INFO - 2023-08-12 15:03:37 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:37 --> Input Class Initialized
INFO - 2023-08-12 15:03:37 --> Language Class Initialized
ERROR - 2023-08-12 15:03:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:03:37 --> Language Class Initialized
INFO - 2023-08-12 15:03:37 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:37 --> Security Class Initialized
INFO - 2023-08-12 15:03:37 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:37 --> Output Class Initialized
ERROR - 2023-08-12 15:03:37 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-12 15:03:37 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:37 --> Config Class Initialized
INFO - 2023-08-12 15:03:37 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:03:37 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:37 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:37 --> URI Class Initialized
INFO - 2023-08-12 15:03:37 --> Router Class Initialized
INFO - 2023-08-12 15:03:37 --> Output Class Initialized
INFO - 2023-08-12 15:03:37 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:37 --> Input Class Initialized
INFO - 2023-08-12 15:03:37 --> Language Class Initialized
ERROR - 2023-08-12 15:03:37 --> 404 Page Not Found: Assets/home
INFO - 2023-08-12 15:03:37 --> Security Class Initialized
INFO - 2023-08-12 15:03:37 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:37 --> Config Class Initialized
INFO - 2023-08-12 15:03:37 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:03:37 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:37 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:37 --> URI Class Initialized
INFO - 2023-08-12 15:03:37 --> URI Class Initialized
DEBUG - 2023-08-12 15:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 15:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:38 --> Router Class Initialized
INFO - 2023-08-12 15:03:38 --> Output Class Initialized
INFO - 2023-08-12 15:03:38 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:38 --> Input Class Initialized
INFO - 2023-08-12 15:03:38 --> Language Class Initialized
ERROR - 2023-08-12 15:03:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:03:38 --> Config Class Initialized
INFO - 2023-08-12 15:03:38 --> URI Class Initialized
INFO - 2023-08-12 15:03:38 --> Router Class Initialized
INFO - 2023-08-12 15:03:38 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:38 --> Input Class Initialized
INFO - 2023-08-12 15:03:38 --> Input Class Initialized
INFO - 2023-08-12 15:03:38 --> Router Class Initialized
INFO - 2023-08-12 15:03:38 --> Language Class Initialized
INFO - 2023-08-12 15:03:38 --> Config Class Initialized
INFO - 2023-08-12 15:03:38 --> Output Class Initialized
DEBUG - 2023-08-12 15:03:38 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:38 --> Language Class Initialized
ERROR - 2023-08-12 15:03:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:03:38 --> Output Class Initialized
INFO - 2023-08-12 15:03:38 --> Security Class Initialized
ERROR - 2023-08-12 15:03:38 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-12 15:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:38 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:38 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:38 --> Security Class Initialized
INFO - 2023-08-12 15:03:38 --> URI Class Initialized
DEBUG - 2023-08-12 15:03:38 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:38 --> Input Class Initialized
INFO - 2023-08-12 15:03:38 --> Config Class Initialized
INFO - 2023-08-12 15:03:38 --> Config Class Initialized
INFO - 2023-08-12 15:03:38 --> Utf8 Class Initialized
DEBUG - 2023-08-12 15:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:38 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:38 --> Hooks Class Initialized
INFO - 2023-08-12 15:03:38 --> Language Class Initialized
DEBUG - 2023-08-12 15:03:38 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:38 --> Router Class Initialized
INFO - 2023-08-12 15:03:38 --> URI Class Initialized
ERROR - 2023-08-12 15:03:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:03:38 --> Input Class Initialized
INFO - 2023-08-12 15:03:38 --> Utf8 Class Initialized
INFO - 2023-08-12 15:03:38 --> URI Class Initialized
INFO - 2023-08-12 15:03:38 --> Router Class Initialized
INFO - 2023-08-12 15:03:38 --> Output Class Initialized
INFO - 2023-08-12 15:03:38 --> Router Class Initialized
INFO - 2023-08-12 15:03:38 --> Language Class Initialized
ERROR - 2023-08-12 15:03:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:03:38 --> Output Class Initialized
DEBUG - 2023-08-12 15:03:38 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:03:38 --> Output Class Initialized
INFO - 2023-08-12 15:03:38 --> Security Class Initialized
INFO - 2023-08-12 15:03:38 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:38 --> Security Class Initialized
INFO - 2023-08-12 15:03:38 --> Utf8 Class Initialized
DEBUG - 2023-08-12 15:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-12 15:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:38 --> Input Class Initialized
INFO - 2023-08-12 15:03:38 --> URI Class Initialized
INFO - 2023-08-12 15:03:38 --> Input Class Initialized
INFO - 2023-08-12 15:03:38 --> Language Class Initialized
ERROR - 2023-08-12 15:03:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-12 15:03:38 --> Language Class Initialized
INFO - 2023-08-12 15:03:38 --> Input Class Initialized
INFO - 2023-08-12 15:03:38 --> Language Class Initialized
ERROR - 2023-08-12 15:03:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-12 15:03:38 --> Router Class Initialized
ERROR - 2023-08-12 15:03:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-12 15:03:38 --> Output Class Initialized
INFO - 2023-08-12 15:03:38 --> Security Class Initialized
DEBUG - 2023-08-12 15:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:03:38 --> Input Class Initialized
INFO - 2023-08-12 15:03:38 --> Language Class Initialized
ERROR - 2023-08-12 15:03:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-12 15:04:44 --> Config Class Initialized
INFO - 2023-08-12 15:04:44 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:04:44 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:04:44 --> Utf8 Class Initialized
INFO - 2023-08-12 15:04:44 --> URI Class Initialized
INFO - 2023-08-12 15:04:44 --> Router Class Initialized
INFO - 2023-08-12 15:04:45 --> Output Class Initialized
INFO - 2023-08-12 15:04:45 --> Security Class Initialized
DEBUG - 2023-08-12 15:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:04:45 --> Input Class Initialized
INFO - 2023-08-12 15:04:45 --> Language Class Initialized
INFO - 2023-08-12 15:04:45 --> Loader Class Initialized
INFO - 2023-08-12 15:04:45 --> Helper loaded: url_helper
INFO - 2023-08-12 15:04:45 --> Helper loaded: file_helper
INFO - 2023-08-12 15:04:45 --> Database Driver Class Initialized
INFO - 2023-08-12 15:04:45 --> Email Class Initialized
DEBUG - 2023-08-12 15:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 15:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 15:04:46 --> Controller Class Initialized
INFO - 2023-08-12 15:04:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-12 15:04:46 --> Final output sent to browser
DEBUG - 2023-08-12 15:04:46 --> Total execution time: 1.3195
INFO - 2023-08-12 15:04:47 --> Config Class Initialized
INFO - 2023-08-12 15:04:47 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:04:47 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:04:47 --> Utf8 Class Initialized
INFO - 2023-08-12 15:04:47 --> URI Class Initialized
INFO - 2023-08-12 15:04:47 --> Router Class Initialized
INFO - 2023-08-12 15:04:47 --> Output Class Initialized
INFO - 2023-08-12 15:04:47 --> Security Class Initialized
DEBUG - 2023-08-12 15:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:04:47 --> Input Class Initialized
INFO - 2023-08-12 15:04:47 --> Language Class Initialized
ERROR - 2023-08-12 15:04:47 --> 404 Page Not Found: Assets/home
INFO - 2023-08-12 15:04:47 --> Config Class Initialized
INFO - 2023-08-12 15:04:47 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:04:47 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:04:47 --> Utf8 Class Initialized
INFO - 2023-08-12 15:04:47 --> URI Class Initialized
INFO - 2023-08-12 15:04:47 --> Router Class Initialized
INFO - 2023-08-12 15:04:47 --> Config Class Initialized
INFO - 2023-08-12 15:04:47 --> Output Class Initialized
INFO - 2023-08-12 15:04:47 --> Hooks Class Initialized
DEBUG - 2023-08-12 15:04:47 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:04:47 --> Security Class Initialized
INFO - 2023-08-12 15:04:47 --> Config Class Initialized
INFO - 2023-08-12 15:04:47 --> Utf8 Class Initialized
INFO - 2023-08-12 15:04:47 --> URI Class Initialized
INFO - 2023-08-12 15:04:47 --> Router Class Initialized
INFO - 2023-08-12 15:04:47 --> Hooks Class Initialized
INFO - 2023-08-12 15:04:47 --> Output Class Initialized
DEBUG - 2023-08-12 15:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:04:47 --> Input Class Initialized
INFO - 2023-08-12 15:04:47 --> Security Class Initialized
DEBUG - 2023-08-12 15:04:47 --> UTF-8 Support Enabled
INFO - 2023-08-12 15:04:47 --> Utf8 Class Initialized
INFO - 2023-08-12 15:04:47 --> URI Class Initialized
INFO - 2023-08-12 15:04:47 --> Language Class Initialized
ERROR - 2023-08-12 15:04:47 --> 404 Page Not Found: Assets/home
INFO - 2023-08-12 15:04:47 --> Router Class Initialized
DEBUG - 2023-08-12 15:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 15:04:48 --> Output Class Initialized
INFO - 2023-08-12 15:04:48 --> Input Class Initialized
INFO - 2023-08-12 15:04:48 --> Security Class Initialized
INFO - 2023-08-12 15:04:48 --> Language Class Initialized
DEBUG - 2023-08-12 15:04:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-12 15:04:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-12 15:04:48 --> Input Class Initialized
INFO - 2023-08-12 15:04:48 --> Language Class Initialized
ERROR - 2023-08-12 15:04:48 --> 404 Page Not Found: Assets/images
