<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-12 08:55:53 --> Config Class Initialized
INFO - 2023-08-12 08:55:53 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:55:54 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:55:54 --> Utf8 Class Initialized
INFO - 2023-08-12 08:55:54 --> URI Class Initialized
INFO - 2023-08-12 08:55:54 --> Router Class Initialized
INFO - 2023-08-12 08:55:54 --> Output Class Initialized
INFO - 2023-08-12 08:55:54 --> Security Class Initialized
DEBUG - 2023-08-12 08:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:55:54 --> Input Class Initialized
INFO - 2023-08-12 08:55:54 --> Language Class Initialized
INFO - 2023-08-12 08:55:54 --> Loader Class Initialized
INFO - 2023-08-12 08:55:54 --> Helper loaded: url_helper
INFO - 2023-08-12 08:55:54 --> Helper loaded: file_helper
INFO - 2023-08-12 08:55:54 --> Database Driver Class Initialized
INFO - 2023-08-12 08:55:54 --> Email Class Initialized
DEBUG - 2023-08-12 08:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 08:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 08:55:54 --> Controller Class Initialized
INFO - 2023-08-12 08:55:54 --> Config Class Initialized
INFO - 2023-08-12 08:55:54 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:55:54 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:55:54 --> Utf8 Class Initialized
INFO - 2023-08-12 08:55:54 --> URI Class Initialized
INFO - 2023-08-12 08:55:54 --> Router Class Initialized
INFO - 2023-08-12 08:55:54 --> Output Class Initialized
INFO - 2023-08-12 08:55:54 --> Security Class Initialized
DEBUG - 2023-08-12 08:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:55:54 --> Input Class Initialized
INFO - 2023-08-12 08:55:54 --> Language Class Initialized
ERROR - 2023-08-12 08:55:54 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 08:56:02 --> Config Class Initialized
INFO - 2023-08-12 08:56:02 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:56:02 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:56:02 --> Utf8 Class Initialized
INFO - 2023-08-12 08:56:02 --> URI Class Initialized
INFO - 2023-08-12 08:56:02 --> Router Class Initialized
INFO - 2023-08-12 08:56:02 --> Output Class Initialized
INFO - 2023-08-12 08:56:02 --> Security Class Initialized
DEBUG - 2023-08-12 08:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:56:02 --> Input Class Initialized
INFO - 2023-08-12 08:56:02 --> Language Class Initialized
INFO - 2023-08-12 08:56:02 --> Loader Class Initialized
INFO - 2023-08-12 08:56:02 --> Helper loaded: url_helper
INFO - 2023-08-12 08:56:02 --> Helper loaded: file_helper
INFO - 2023-08-12 08:56:02 --> Database Driver Class Initialized
INFO - 2023-08-12 08:56:02 --> Email Class Initialized
DEBUG - 2023-08-12 08:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 08:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 08:56:02 --> Controller Class Initialized
INFO - 2023-08-12 08:56:02 --> Model "User_model" initialized
INFO - 2023-08-12 08:56:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-12 08:56:02 --> Final output sent to browser
DEBUG - 2023-08-12 08:56:02 --> Total execution time: 0.1219
INFO - 2023-08-12 08:56:02 --> Config Class Initialized
INFO - 2023-08-12 08:56:02 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:56:02 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:56:02 --> Utf8 Class Initialized
INFO - 2023-08-12 08:56:02 --> URI Class Initialized
INFO - 2023-08-12 08:56:02 --> Router Class Initialized
INFO - 2023-08-12 08:56:02 --> Output Class Initialized
INFO - 2023-08-12 08:56:02 --> Security Class Initialized
DEBUG - 2023-08-12 08:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:56:02 --> Input Class Initialized
INFO - 2023-08-12 08:56:02 --> Language Class Initialized
ERROR - 2023-08-12 08:56:02 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-12 08:56:09 --> Config Class Initialized
INFO - 2023-08-12 08:56:09 --> Hooks Class Initialized
DEBUG - 2023-08-12 08:56:09 --> UTF-8 Support Enabled
INFO - 2023-08-12 08:56:09 --> Utf8 Class Initialized
INFO - 2023-08-12 08:56:09 --> URI Class Initialized
INFO - 2023-08-12 08:56:09 --> Router Class Initialized
INFO - 2023-08-12 08:56:09 --> Output Class Initialized
INFO - 2023-08-12 08:56:09 --> Security Class Initialized
DEBUG - 2023-08-12 08:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 08:56:09 --> Input Class Initialized
INFO - 2023-08-12 08:56:09 --> Language Class Initialized
ERROR - 2023-08-12 08:56:09 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 09:03:01 --> Config Class Initialized
INFO - 2023-08-12 09:03:01 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:03:01 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:03:01 --> Utf8 Class Initialized
INFO - 2023-08-12 09:03:01 --> URI Class Initialized
INFO - 2023-08-12 09:03:01 --> Router Class Initialized
INFO - 2023-08-12 09:03:01 --> Output Class Initialized
INFO - 2023-08-12 09:03:01 --> Security Class Initialized
DEBUG - 2023-08-12 09:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:03:01 --> Input Class Initialized
INFO - 2023-08-12 09:03:01 --> Language Class Initialized
INFO - 2023-08-12 09:03:01 --> Loader Class Initialized
INFO - 2023-08-12 09:03:01 --> Helper loaded: url_helper
INFO - 2023-08-12 09:03:01 --> Helper loaded: file_helper
INFO - 2023-08-12 09:03:01 --> Database Driver Class Initialized
INFO - 2023-08-12 09:03:01 --> Email Class Initialized
DEBUG - 2023-08-12 09:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:03:01 --> Controller Class Initialized
INFO - 2023-08-12 09:03:01 --> Model "User_model" initialized
INFO - 2023-08-12 09:03:01 --> Config Class Initialized
INFO - 2023-08-12 09:03:01 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:03:01 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:03:01 --> Utf8 Class Initialized
INFO - 2023-08-12 09:03:01 --> URI Class Initialized
INFO - 2023-08-12 09:03:01 --> Router Class Initialized
INFO - 2023-08-12 09:03:01 --> Output Class Initialized
INFO - 2023-08-12 09:03:01 --> Security Class Initialized
DEBUG - 2023-08-12 09:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:03:01 --> Input Class Initialized
INFO - 2023-08-12 09:03:01 --> Language Class Initialized
ERROR - 2023-08-12 09:03:01 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 09:03:24 --> Config Class Initialized
INFO - 2023-08-12 09:03:24 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:03:24 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:03:24 --> Utf8 Class Initialized
INFO - 2023-08-12 09:03:24 --> URI Class Initialized
INFO - 2023-08-12 09:03:24 --> Router Class Initialized
INFO - 2023-08-12 09:03:24 --> Output Class Initialized
INFO - 2023-08-12 09:03:24 --> Security Class Initialized
DEBUG - 2023-08-12 09:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:03:24 --> Input Class Initialized
INFO - 2023-08-12 09:03:24 --> Language Class Initialized
INFO - 2023-08-12 09:03:24 --> Loader Class Initialized
INFO - 2023-08-12 09:03:24 --> Helper loaded: url_helper
INFO - 2023-08-12 09:03:24 --> Helper loaded: file_helper
INFO - 2023-08-12 09:03:24 --> Database Driver Class Initialized
INFO - 2023-08-12 09:03:24 --> Email Class Initialized
DEBUG - 2023-08-12 09:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:03:24 --> Controller Class Initialized
INFO - 2023-08-12 09:03:24 --> Config Class Initialized
INFO - 2023-08-12 09:03:24 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:03:24 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:03:24 --> Utf8 Class Initialized
INFO - 2023-08-12 09:03:24 --> URI Class Initialized
INFO - 2023-08-12 09:03:24 --> Router Class Initialized
INFO - 2023-08-12 09:03:24 --> Output Class Initialized
INFO - 2023-08-12 09:03:24 --> Security Class Initialized
DEBUG - 2023-08-12 09:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:03:24 --> Input Class Initialized
INFO - 2023-08-12 09:03:24 --> Language Class Initialized
ERROR - 2023-08-12 09:03:24 --> 404 Page Not Found: DW/admin
INFO - 2023-08-12 09:03:29 --> Config Class Initialized
INFO - 2023-08-12 09:03:29 --> Hooks Class Initialized
DEBUG - 2023-08-12 09:03:29 --> UTF-8 Support Enabled
INFO - 2023-08-12 09:03:29 --> Utf8 Class Initialized
INFO - 2023-08-12 09:03:29 --> URI Class Initialized
INFO - 2023-08-12 09:03:29 --> Router Class Initialized
INFO - 2023-08-12 09:03:29 --> Output Class Initialized
INFO - 2023-08-12 09:03:29 --> Security Class Initialized
DEBUG - 2023-08-12 09:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-12 09:03:29 --> Input Class Initialized
INFO - 2023-08-12 09:03:29 --> Language Class Initialized
INFO - 2023-08-12 09:03:29 --> Loader Class Initialized
INFO - 2023-08-12 09:03:29 --> Helper loaded: url_helper
INFO - 2023-08-12 09:03:29 --> Helper loaded: file_helper
INFO - 2023-08-12 09:03:29 --> Database Driver Class Initialized
INFO - 2023-08-12 09:03:29 --> Email Class Initialized
DEBUG - 2023-08-12 09:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-12 09:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-12 09:03:29 --> Controller Class Initialized
INFO - 2023-08-12 09:03:29 --> Model "User_model" initialized
INFO - 2023-08-12 09:03:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-12 09:03:29 --> Final output sent to browser
DEBUG - 2023-08-12 09:03:29 --> Total execution time: 0.0505
