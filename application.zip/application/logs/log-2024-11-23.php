<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-11-23 12:15:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:45:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:45:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:54 --> Total execution time: 0.2324
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:55 --> Total execution time: 0.1413
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:55 --> Total execution time: 0.2000
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:55 --> Total execution time: 0.2813
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:55 --> Total execution time: 0.3430
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:55 --> Total execution time: 0.4130
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:55 --> Total execution time: 0.4662
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:55 --> Total execution time: 0.3863
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:55 --> Total execution time: 0.4132
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:55 --> Total execution time: 0.2279
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:55 --> Total execution time: 0.2242
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:15:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:15:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 16:45:55 --> Total execution time: 0.2406
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:55 --> Total execution time: 0.1542
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:55 --> Total execution time: 0.1982
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:56 --> Total execution time: 0.2474
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:45:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:45:56 --> Total execution time: 0.2999
DEBUG - 2024-11-23 12:27:52 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:53 --> Total execution time: 0.1553
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:53 --> Total execution time: 0.1602
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:53 --> Total execution time: 0.2145
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:53 --> Total execution time: 0.2596
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:53 --> Total execution time: 0.3198
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:53 --> Total execution time: 0.3780
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:53 --> Total execution time: 0.4236
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:53 --> Total execution time: 0.3180
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:53 --> Total execution time: 0.2592
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:53 --> Total execution time: 0.3231
DEBUG - 2024-11-23 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 12:27:53 --> UTF-8 Support Enabled
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:53 --> Total execution time: 0.3382
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 12:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:54 --> Total execution time: 0.3022
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:54 --> Total execution time: 0.3624
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:54 --> Total execution time: 0.3460
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:54 --> Total execution time: 0.3254
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 16:57:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 16:57:54 --> Total execution time: 0.3174
DEBUG - 2024-11-23 12:30:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:13 --> Total execution time: 0.1923
DEBUG - 2024-11-23 12:30:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:30:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:30:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:14 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 12:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 12:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 17:00:14 --> Total execution time: 0.1652
DEBUG - 2024-11-23 12:30:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:30:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 12:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:14 --> Total execution time: 0.1537
DEBUG - 2024-11-23 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:30:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:14 --> Total execution time: 0.1969
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:14 --> Total execution time: 0.2595
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:14 --> Total execution time: 0.2494
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 12:30:14 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 12:30:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:14 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:14 --> Total execution time: 0.4103
DEBUG - 2024-11-23 12:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 12:30:14 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:14 --> Total execution time: 0.5122
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-23 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:14 --> Total execution time: 0.4462
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:14 --> Total execution time: 0.2844
DEBUG - 2024-11-23 12:30:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:14 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:14 --> Total execution time: 0.3502
DEBUG - 2024-11-23 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:14 --> Total execution time: 0.4182
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:14 --> Total execution time: 0.3902
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:14 --> Total execution time: 0.2724
ERROR - 2024-11-23 17:00:15 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:15 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:15 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:15 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:15 --> Total execution time: 0.3912
DEBUG - 2024-11-23 12:30:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:42 --> Total execution time: 0.1536
DEBUG - 2024-11-23 12:30:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:30:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 12:30:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-23 12:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 12:30:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:42 --> Total execution time: 0.1603
DEBUG - 2024-11-23 12:30:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 12:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-23 12:30:42 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:30:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 12:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:43 --> Total execution time: 0.1917
DEBUG - 2024-11-23 12:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:30:43 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 12:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:43 --> Total execution time: 0.2469
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:43 --> Total execution time: 0.3140
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:43 --> Total execution time: 0.3725
DEBUG - 2024-11-23 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 12:30:43 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 12:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 12:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:43 --> Total execution time: 0.4667
DEBUG - 2024-11-23 12:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:43 --> Total execution time: 0.3925
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 17:00:43 --> Total execution time: 0.3808
DEBUG - 2024-11-23 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 12:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 17:00:43 --> Total execution time: 0.2867
DEBUG - 2024-11-23 12:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:43 --> Total execution time: 0.3402
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:43 --> Total execution time: 0.3569
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:43 --> Total execution time: 0.2480
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:00:43 --> Total execution time: 0.3094
DEBUG - 2024-11-23 12:33:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:03:24 --> Total execution time: 0.1630
DEBUG - 2024-11-23 12:33:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:33:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:33:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:33:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:33:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:33:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-23 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:03:24 --> Total execution time: 0.1464
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-23 12:33:24 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:03:24 --> Total execution time: 0.2040
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:03:24 --> Total execution time: 0.2511
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:33:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:33:24 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 12:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-23 12:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:03:24 --> Total execution time: 0.3049
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 12:33:24 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-23 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:03:24 --> Total execution time: 0.3468
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:03:24 --> Total execution time: 0.4134
DEBUG - 2024-11-23 12:33:24 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:03:24 --> Total execution time: 0.3227
DEBUG - 2024-11-23 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:03:24 --> Total execution time: 0.2763
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:03:24 --> Total execution time: 0.3429
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:03:24 --> Total execution time: 0.3467
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:03:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:03:24 --> Total execution time: 0.2959
DEBUG - 2024-11-23 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:06:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:21 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:21 --> Total execution time: 0.1635
DEBUG - 2024-11-23 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:22 --> Total execution time: 0.1718
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:36:22 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 12:36:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:22 --> Total execution time: 0.2270
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-23 12:36:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:22 --> Total execution time: 0.2930
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-23 12:36:22 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-23 12:36:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:22 --> Total execution time: 0.3513
DEBUG - 2024-11-23 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:22 --> Total execution time: 0.3869
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:22 --> Total execution time: 0.4274
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:22 --> Total execution time: 0.3212
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:22 --> Total execution time: 0.3036
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:22 --> Total execution time: 0.2970
DEBUG - 2024-11-23 12:36:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:47 --> Total execution time: 0.1578
DEBUG - 2024-11-23 12:36:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-23 12:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:47 --> Total execution time: 0.1564
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:36:47 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-23 12:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:47 --> Total execution time: 0.2158
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 12:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:47 --> Total execution time: 0.2488
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:47 --> Total execution time: 0.3012
DEBUG - 2024-11-23 12:36:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 12:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 17:06:48 --> Total execution time: 0.3677
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:48 --> Total execution time: 0.4145
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:48 --> Total execution time: 0.2951
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:06:48 --> Total execution time: 0.2247
DEBUG - 2024-11-23 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:07:24 --> Total execution time: 0.1347
DEBUG - 2024-11-23 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:07:24 --> Total execution time: 0.1609
DEBUG - 2024-11-23 12:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-23 12:37:24 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-23 12:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:07:24 --> Total execution time: 0.1994
DEBUG - 2024-11-23 12:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:07:24 --> Total execution time: 0.2737
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:07:24 --> Total execution time: 0.3228
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:07:25 --> Total execution time: 0.3801
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:07:25 --> Total execution time: 0.4285
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:07:25 --> Total execution time: 0.3261
DEBUG - 2024-11-23 12:38:05 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:08:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:05 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:05 --> Total execution time: 0.1776
DEBUG - 2024-11-23 12:38:05 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:05 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:05 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:38:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 12:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 17:08:06 --> Total execution time: 0.1787
DEBUG - 2024-11-23 12:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 12:38:06 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:38:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:06 --> Total execution time: 0.2514
DEBUG - 2024-11-23 12:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:06 --> Total execution time: 0.2941
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:06 --> Total execution time: 0.4394
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:06 --> Total execution time: 0.4530
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:06 --> Total execution time: 0.5918
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:06 --> Total execution time: 0.4962
DEBUG - 2024-11-23 12:38:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:16 --> Total execution time: 0.1830
DEBUG - 2024-11-23 12:38:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 12:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:16 --> Total execution time: 0.1820
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-23 12:38:16 --> UTF-8 Support Enabled
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:38:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:16 --> Total execution time: 0.2526
DEBUG - 2024-11-23 12:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:16 --> Total execution time: 0.2859
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:16 --> Total execution time: 0.3424
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:16 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:17 --> Total execution time: 0.4134
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:17 --> Total execution time: 0.4738
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:17 --> Total execution time: 0.3535
DEBUG - 2024-11-23 12:38:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:54 --> Total execution time: 0.1256
DEBUG - 2024-11-23 12:38:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:54 --> Total execution time: 0.2283
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:54 --> Total execution time: 0.2866
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:54 --> Total execution time: 0.3286
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:54 --> Total execution time: 0.3936
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:54 --> Total execution time: 0.4577
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:08:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:08:54 --> Total execution time: 0.5047
DEBUG - 2024-11-23 12:41:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:11:13 --> Total execution time: 0.1044
DEBUG - 2024-11-23 12:41:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:41:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:41:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:41:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:41:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:11:13 --> Total execution time: 0.0937
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:11:13 --> Total execution time: 0.1359
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:11:13 --> Total execution time: 0.1671
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:11:13 --> Total execution time: 0.1959
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:11:13 --> Total execution time: 0.2384
DEBUG - 2024-11-23 12:42:38 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:12:39 --> Total execution time: 0.1287
DEBUG - 2024-11-23 12:42:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:42:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:42:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:42:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:42:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 12:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-23 12:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 12:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:12:39 --> Total execution time: 0.0879
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:12:39 --> Total execution time: 0.0999
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:12:39 --> Total execution time: 0.1368
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:12:39 --> Total execution time: 0.1633
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:12:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:12:39 --> Total execution time: 0.1889
DEBUG - 2024-11-23 12:44:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:14:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:14:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:14:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:14:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:14:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:14:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:14:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:14:49 --> Total execution time: 0.0872
DEBUG - 2024-11-23 12:44:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:44:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:44:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:44:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:14:50 --> Total execution time: 0.0866
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:14:50 --> Total execution time: 0.1209
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:14:50 --> Total execution time: 0.1460
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:14:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:14:50 --> Total execution time: 0.1747
DEBUG - 2024-11-23 12:46:35 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:16:35 --> Total execution time: 0.1372
DEBUG - 2024-11-23 12:46:35 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:46:35 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:46:35 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:16:35 --> Total execution time: 0.0985
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:16:35 --> Total execution time: 0.1243
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:16:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:16:35 --> Total execution time: 0.1494
DEBUG - 2024-11-23 12:50:01 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:20:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:20:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:20:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:20:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:20:01 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:20:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:20:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:20:01 --> Total execution time: 0.1577
DEBUG - 2024-11-23 12:50:01 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:50:01 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:50:01 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 12:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 12:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 12:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 17:20:01 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:20:01 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:20:01 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:20:02 --> Total execution time: 0.1082
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:20:02 --> Total execution time: 0.1786
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 17:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 17:20:02 --> Total execution time: 0.1866
DEBUG - 2024-11-23 14:25:19 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 18:55:19 --> Total execution time: 0.1335
DEBUG - 2024-11-23 14:25:19 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:25:19 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-23 14:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 18:55:19 --> Total execution time: 0.0806
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 18:55:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 18:55:19 --> Total execution time: 0.0727
DEBUG - 2024-11-23 14:27:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 18:57:49 --> Total execution time: 0.1246
DEBUG - 2024-11-23 14:27:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:27:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:27:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:27:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:27:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:27:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:27:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 14:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-23 14:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-23 14:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 18:57:49 --> Total execution time: 0.0772
DEBUG - 2024-11-23 14:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 18:57:49 --> Total execution time: 0.1046
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 18:57:49 --> Total execution time: 0.1136
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 18:57:49 --> Total execution time: 0.1490
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 18:57:49 --> Total execution time: 0.1808
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 18:57:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 18:57:49 --> Total execution time: 0.2184
DEBUG - 2024-11-23 14:33:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:03:39 --> Total execution time: 0.1122
DEBUG - 2024-11-23 14:33:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:33:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:33:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:33:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:33:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:33:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:03:39 --> Total execution time: 0.0867
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:03:39 --> Total execution time: 0.1199
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:03:39 --> Total execution time: 0.1347
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:03:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:03:39 --> Total execution time: 0.1523
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:03:40 --> Total execution time: 0.1833
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:03:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:03:40 --> Total execution time: 0.2160
DEBUG - 2024-11-23 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:04:24 --> Total execution time: 0.1429
DEBUG - 2024-11-23 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:04:24 --> Total execution time: 0.0914
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:04:24 --> Total execution time: 0.1250
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:04:24 --> Total execution time: 0.1418
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:04:24 --> Total execution time: 0.1738
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:04:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:04:24 --> Total execution time: 0.2055
DEBUG - 2024-11-23 14:35:20 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:05:20 --> Total execution time: 0.1346
DEBUG - 2024-11-23 14:35:20 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:35:20 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:35:20 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:35:20 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 14:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:05:20 --> Total execution time: 0.1109
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:05:20 --> Total execution time: 0.1248
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:05:20 --> Total execution time: 0.1908
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:05:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:05:20 --> Total execution time: 0.1867
DEBUG - 2024-11-23 14:36:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:06:54 --> Total execution time: 0.1402
DEBUG - 2024-11-23 14:36:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:36:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:36:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:36:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-23 14:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 14:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:06:54 --> Total execution time: 0.0727
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:06:54 --> Total execution time: 0.0866
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:06:54 --> Total execution time: 0.1153
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:06:54 --> Total execution time: 0.1532
DEBUG - 2024-11-23 14:37:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:07:57 --> Total execution time: 0.0774
DEBUG - 2024-11-23 14:37:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:37:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:37:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-23 14:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:07:57 --> Total execution time: 0.0801
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:07:57 --> Total execution time: 0.1046
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:07:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:07:57 --> Total execution time: 0.1276
DEBUG - 2024-11-23 14:38:41 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:08:41 --> Total execution time: 0.1307
DEBUG - 2024-11-23 14:38:41 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:38:41 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-23 14:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:08:41 --> Total execution time: 0.0762
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:08:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:08:41 --> Total execution time: 0.1144
DEBUG - 2024-11-23 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:09:30 --> Total execution time: 0.1117
DEBUG - 2024-11-23 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:09:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:09:30 --> Total execution time: 0.0946
DEBUG - 2024-11-23 14:40:25 --> UTF-8 Support Enabled
DEBUG - 2024-11-23 14:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-23 14:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-23 19:10:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:10:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-23 19:10:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:10:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-23 19:10:26 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-23 19:10:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-23 19:10:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-23 19:10:26 --> Total execution time: 0.0845
