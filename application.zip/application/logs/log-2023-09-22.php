<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-22 16:09:12 --> Config Class Initialized
INFO - 2023-09-22 16:09:12 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:09:12 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:09:12 --> Utf8 Class Initialized
INFO - 2023-09-22 16:09:12 --> URI Class Initialized
DEBUG - 2023-09-22 16:09:12 --> No URI present. Default controller set.
INFO - 2023-09-22 16:09:12 --> Router Class Initialized
INFO - 2023-09-22 16:09:13 --> Output Class Initialized
INFO - 2023-09-22 16:09:13 --> Security Class Initialized
DEBUG - 2023-09-22 16:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:09:13 --> Input Class Initialized
INFO - 2023-09-22 16:09:13 --> Language Class Initialized
INFO - 2023-09-22 16:09:13 --> Loader Class Initialized
INFO - 2023-09-22 16:09:13 --> Helper loaded: url_helper
INFO - 2023-09-22 16:09:13 --> Helper loaded: file_helper
INFO - 2023-09-22 16:09:13 --> Database Driver Class Initialized
INFO - 2023-09-22 16:09:13 --> Email Class Initialized
DEBUG - 2023-09-22 16:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:09:13 --> Controller Class Initialized
INFO - 2023-09-22 16:09:13 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:09:13 --> Model "Home_model" initialized
INFO - 2023-09-22 16:09:13 --> Helper loaded: download_helper
INFO - 2023-09-22 16:09:13 --> Helper loaded: form_helper
INFO - 2023-09-22 16:09:13 --> Form Validation Class Initialized
INFO - 2023-09-22 16:09:13 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:09:13 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:09:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-22 16:09:13 --> Final output sent to browser
DEBUG - 2023-09-22 16:09:13 --> Total execution time: 1.1727
INFO - 2023-09-22 16:09:21 --> Config Class Initialized
INFO - 2023-09-22 16:09:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:09:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:09:21 --> Utf8 Class Initialized
INFO - 2023-09-22 16:09:21 --> URI Class Initialized
INFO - 2023-09-22 16:09:21 --> Router Class Initialized
INFO - 2023-09-22 16:09:21 --> Output Class Initialized
INFO - 2023-09-22 16:09:21 --> Security Class Initialized
DEBUG - 2023-09-22 16:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:09:21 --> Input Class Initialized
INFO - 2023-09-22 16:09:21 --> Language Class Initialized
INFO - 2023-09-22 16:09:21 --> Loader Class Initialized
INFO - 2023-09-22 16:09:21 --> Helper loaded: url_helper
INFO - 2023-09-22 16:09:21 --> Helper loaded: file_helper
INFO - 2023-09-22 16:09:21 --> Database Driver Class Initialized
INFO - 2023-09-22 16:09:21 --> Email Class Initialized
DEBUG - 2023-09-22 16:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:09:21 --> Controller Class Initialized
INFO - 2023-09-22 16:09:21 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:09:21 --> Model "Home_model" initialized
INFO - 2023-09-22 16:09:21 --> Helper loaded: download_helper
INFO - 2023-09-22 16:09:21 --> Helper loaded: form_helper
INFO - 2023-09-22 16:09:21 --> Form Validation Class Initialized
INFO - 2023-09-22 16:09:22 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:09:22 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:09:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 16:09:22 --> Final output sent to browser
DEBUG - 2023-09-22 16:09:22 --> Total execution time: 0.2912
INFO - 2023-09-22 16:09:22 --> Config Class Initialized
INFO - 2023-09-22 16:09:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:09:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:09:22 --> Utf8 Class Initialized
INFO - 2023-09-22 16:09:22 --> URI Class Initialized
INFO - 2023-09-22 16:09:22 --> Router Class Initialized
INFO - 2023-09-22 16:09:22 --> Output Class Initialized
INFO - 2023-09-22 16:09:22 --> Security Class Initialized
DEBUG - 2023-09-22 16:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:09:22 --> Input Class Initialized
INFO - 2023-09-22 16:09:22 --> Language Class Initialized
ERROR - 2023-09-22 16:09:23 --> 404 Page Not Found: Assets/images
INFO - 2023-09-22 16:09:59 --> Config Class Initialized
INFO - 2023-09-22 16:09:59 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:09:59 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:09:59 --> Utf8 Class Initialized
INFO - 2023-09-22 16:09:59 --> URI Class Initialized
INFO - 2023-09-22 16:09:59 --> Router Class Initialized
INFO - 2023-09-22 16:09:59 --> Output Class Initialized
INFO - 2023-09-22 16:09:59 --> Security Class Initialized
DEBUG - 2023-09-22 16:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:09:59 --> Input Class Initialized
INFO - 2023-09-22 16:09:59 --> Language Class Initialized
INFO - 2023-09-22 16:09:59 --> Loader Class Initialized
INFO - 2023-09-22 16:09:59 --> Helper loaded: url_helper
INFO - 2023-09-22 16:09:59 --> Helper loaded: file_helper
INFO - 2023-09-22 16:09:59 --> Database Driver Class Initialized
INFO - 2023-09-22 16:09:59 --> Email Class Initialized
DEBUG - 2023-09-22 16:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:09:59 --> Controller Class Initialized
INFO - 2023-09-22 16:09:59 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:09:59 --> Model "Home_model" initialized
INFO - 2023-09-22 16:09:59 --> Helper loaded: download_helper
INFO - 2023-09-22 16:09:59 --> Helper loaded: form_helper
INFO - 2023-09-22 16:09:59 --> Form Validation Class Initialized
INFO - 2023-09-22 16:09:59 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:09:59 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:09:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 16:09:59 --> Final output sent to browser
DEBUG - 2023-09-22 16:09:59 --> Total execution time: 0.1313
INFO - 2023-09-22 16:13:07 --> Config Class Initialized
INFO - 2023-09-22 16:13:07 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:13:07 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:13:07 --> Utf8 Class Initialized
INFO - 2023-09-22 16:13:07 --> URI Class Initialized
INFO - 2023-09-22 16:13:07 --> Router Class Initialized
INFO - 2023-09-22 16:13:07 --> Output Class Initialized
INFO - 2023-09-22 16:13:07 --> Security Class Initialized
DEBUG - 2023-09-22 16:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:13:07 --> Input Class Initialized
INFO - 2023-09-22 16:13:07 --> Language Class Initialized
INFO - 2023-09-22 16:13:07 --> Loader Class Initialized
INFO - 2023-09-22 16:13:07 --> Helper loaded: url_helper
INFO - 2023-09-22 16:13:07 --> Helper loaded: file_helper
INFO - 2023-09-22 16:13:07 --> Database Driver Class Initialized
INFO - 2023-09-22 16:13:07 --> Email Class Initialized
DEBUG - 2023-09-22 16:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:13:07 --> Controller Class Initialized
INFO - 2023-09-22 16:13:07 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:13:07 --> Model "Home_model" initialized
INFO - 2023-09-22 16:13:07 --> Helper loaded: download_helper
INFO - 2023-09-22 16:13:07 --> Helper loaded: form_helper
INFO - 2023-09-22 16:13:07 --> Form Validation Class Initialized
INFO - 2023-09-22 16:13:07 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:13:07 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:13:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 16:13:07 --> Final output sent to browser
DEBUG - 2023-09-22 16:13:07 --> Total execution time: 0.0640
INFO - 2023-09-22 16:13:11 --> Config Class Initialized
INFO - 2023-09-22 16:13:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:13:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:13:11 --> Utf8 Class Initialized
INFO - 2023-09-22 16:13:11 --> URI Class Initialized
INFO - 2023-09-22 16:13:11 --> Router Class Initialized
INFO - 2023-09-22 16:13:11 --> Output Class Initialized
INFO - 2023-09-22 16:13:11 --> Security Class Initialized
DEBUG - 2023-09-22 16:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:13:11 --> Input Class Initialized
INFO - 2023-09-22 16:13:11 --> Language Class Initialized
INFO - 2023-09-22 16:13:11 --> Loader Class Initialized
INFO - 2023-09-22 16:13:11 --> Helper loaded: url_helper
INFO - 2023-09-22 16:13:11 --> Helper loaded: file_helper
INFO - 2023-09-22 16:13:11 --> Database Driver Class Initialized
INFO - 2023-09-22 16:13:11 --> Email Class Initialized
DEBUG - 2023-09-22 16:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:13:11 --> Controller Class Initialized
INFO - 2023-09-22 16:13:11 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:13:11 --> Model "Home_model" initialized
INFO - 2023-09-22 16:13:11 --> Helper loaded: download_helper
INFO - 2023-09-22 16:13:11 --> Helper loaded: form_helper
INFO - 2023-09-22 16:13:11 --> Form Validation Class Initialized
INFO - 2023-09-22 16:13:11 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:13:11 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:13:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 16:13:11 --> Final output sent to browser
DEBUG - 2023-09-22 16:13:11 --> Total execution time: 0.0643
INFO - 2023-09-22 16:14:23 --> Config Class Initialized
INFO - 2023-09-22 16:14:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:14:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:14:23 --> Utf8 Class Initialized
INFO - 2023-09-22 16:14:23 --> URI Class Initialized
INFO - 2023-09-22 16:14:23 --> Router Class Initialized
INFO - 2023-09-22 16:14:23 --> Output Class Initialized
INFO - 2023-09-22 16:14:23 --> Security Class Initialized
DEBUG - 2023-09-22 16:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:14:23 --> Input Class Initialized
INFO - 2023-09-22 16:14:23 --> Language Class Initialized
INFO - 2023-09-22 16:14:23 --> Loader Class Initialized
INFO - 2023-09-22 16:14:23 --> Helper loaded: url_helper
INFO - 2023-09-22 16:14:23 --> Helper loaded: file_helper
INFO - 2023-09-22 16:14:23 --> Database Driver Class Initialized
INFO - 2023-09-22 16:14:23 --> Email Class Initialized
DEBUG - 2023-09-22 16:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:14:23 --> Controller Class Initialized
INFO - 2023-09-22 16:14:23 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:14:23 --> Model "Home_model" initialized
INFO - 2023-09-22 16:14:23 --> Helper loaded: download_helper
INFO - 2023-09-22 16:14:23 --> Helper loaded: form_helper
INFO - 2023-09-22 16:14:23 --> Form Validation Class Initialized
INFO - 2023-09-22 16:14:23 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:14:23 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:14:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 16:14:23 --> Final output sent to browser
DEBUG - 2023-09-22 16:14:23 --> Total execution time: 0.0870
INFO - 2023-09-22 16:14:33 --> Config Class Initialized
INFO - 2023-09-22 16:14:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:14:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:14:33 --> Utf8 Class Initialized
INFO - 2023-09-22 16:14:33 --> URI Class Initialized
INFO - 2023-09-22 16:14:33 --> Router Class Initialized
INFO - 2023-09-22 16:14:33 --> Output Class Initialized
INFO - 2023-09-22 16:14:33 --> Security Class Initialized
DEBUG - 2023-09-22 16:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:14:33 --> Input Class Initialized
INFO - 2023-09-22 16:14:33 --> Language Class Initialized
INFO - 2023-09-22 16:14:33 --> Loader Class Initialized
INFO - 2023-09-22 16:14:33 --> Helper loaded: url_helper
INFO - 2023-09-22 16:14:33 --> Helper loaded: file_helper
INFO - 2023-09-22 16:14:34 --> Database Driver Class Initialized
INFO - 2023-09-22 16:14:34 --> Email Class Initialized
DEBUG - 2023-09-22 16:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:14:34 --> Controller Class Initialized
INFO - 2023-09-22 16:14:34 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:14:34 --> Model "Home_model" initialized
INFO - 2023-09-22 16:14:34 --> Helper loaded: download_helper
INFO - 2023-09-22 16:14:34 --> Helper loaded: form_helper
INFO - 2023-09-22 16:14:34 --> Form Validation Class Initialized
INFO - 2023-09-22 16:14:34 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:14:34 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:14:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 16:14:34 --> Final output sent to browser
DEBUG - 2023-09-22 16:14:34 --> Total execution time: 0.0627
INFO - 2023-09-22 16:20:29 --> Config Class Initialized
INFO - 2023-09-22 16:20:29 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:20:29 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:20:29 --> Utf8 Class Initialized
INFO - 2023-09-22 16:20:29 --> URI Class Initialized
INFO - 2023-09-22 16:20:29 --> Router Class Initialized
INFO - 2023-09-22 16:20:29 --> Output Class Initialized
INFO - 2023-09-22 16:20:29 --> Security Class Initialized
DEBUG - 2023-09-22 16:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:20:29 --> Input Class Initialized
INFO - 2023-09-22 16:20:29 --> Language Class Initialized
INFO - 2023-09-22 16:20:29 --> Loader Class Initialized
INFO - 2023-09-22 16:20:29 --> Helper loaded: url_helper
INFO - 2023-09-22 16:20:29 --> Helper loaded: file_helper
INFO - 2023-09-22 16:20:29 --> Database Driver Class Initialized
INFO - 2023-09-22 16:20:29 --> Email Class Initialized
DEBUG - 2023-09-22 16:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:20:29 --> Controller Class Initialized
INFO - 2023-09-22 16:20:29 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:20:29 --> Model "Home_model" initialized
INFO - 2023-09-22 16:20:29 --> Helper loaded: download_helper
INFO - 2023-09-22 16:20:29 --> Helper loaded: form_helper
INFO - 2023-09-22 16:20:29 --> Form Validation Class Initialized
INFO - 2023-09-22 16:20:29 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:20:29 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:20:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 16:20:29 --> Final output sent to browser
DEBUG - 2023-09-22 16:20:29 --> Total execution time: 0.0647
INFO - 2023-09-22 16:20:43 --> Config Class Initialized
INFO - 2023-09-22 16:20:43 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:20:43 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:20:43 --> Utf8 Class Initialized
INFO - 2023-09-22 16:20:43 --> URI Class Initialized
INFO - 2023-09-22 16:20:43 --> Router Class Initialized
INFO - 2023-09-22 16:20:43 --> Output Class Initialized
INFO - 2023-09-22 16:20:43 --> Security Class Initialized
DEBUG - 2023-09-22 16:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:20:43 --> Input Class Initialized
INFO - 2023-09-22 16:20:43 --> Language Class Initialized
INFO - 2023-09-22 16:20:43 --> Loader Class Initialized
INFO - 2023-09-22 16:20:43 --> Helper loaded: url_helper
INFO - 2023-09-22 16:20:43 --> Helper loaded: file_helper
INFO - 2023-09-22 16:20:43 --> Database Driver Class Initialized
INFO - 2023-09-22 16:20:43 --> Email Class Initialized
DEBUG - 2023-09-22 16:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:20:43 --> Controller Class Initialized
INFO - 2023-09-22 16:20:43 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:20:43 --> Model "Home_model" initialized
INFO - 2023-09-22 16:20:43 --> Helper loaded: download_helper
INFO - 2023-09-22 16:20:43 --> Helper loaded: form_helper
INFO - 2023-09-22 16:20:43 --> Form Validation Class Initialized
INFO - 2023-09-22 16:20:43 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:20:43 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:20:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-22 16:20:43 --> Final output sent to browser
DEBUG - 2023-09-22 16:20:43 --> Total execution time: 0.0672
INFO - 2023-09-22 16:20:47 --> Config Class Initialized
INFO - 2023-09-22 16:20:47 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:20:47 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:20:47 --> Utf8 Class Initialized
INFO - 2023-09-22 16:20:47 --> URI Class Initialized
INFO - 2023-09-22 16:20:47 --> Router Class Initialized
INFO - 2023-09-22 16:20:47 --> Output Class Initialized
INFO - 2023-09-22 16:20:47 --> Security Class Initialized
DEBUG - 2023-09-22 16:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:20:47 --> Input Class Initialized
INFO - 2023-09-22 16:20:47 --> Language Class Initialized
INFO - 2023-09-22 16:20:47 --> Loader Class Initialized
INFO - 2023-09-22 16:20:47 --> Helper loaded: url_helper
INFO - 2023-09-22 16:20:47 --> Helper loaded: file_helper
INFO - 2023-09-22 16:20:47 --> Database Driver Class Initialized
INFO - 2023-09-22 16:20:47 --> Email Class Initialized
DEBUG - 2023-09-22 16:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:20:47 --> Controller Class Initialized
INFO - 2023-09-22 16:20:47 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:20:47 --> Model "Home_model" initialized
INFO - 2023-09-22 16:20:47 --> Helper loaded: download_helper
INFO - 2023-09-22 16:20:47 --> Helper loaded: form_helper
INFO - 2023-09-22 16:20:47 --> Form Validation Class Initialized
INFO - 2023-09-22 16:20:47 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:20:47 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:20:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-22 16:20:47 --> Final output sent to browser
DEBUG - 2023-09-22 16:20:47 --> Total execution time: 0.0613
INFO - 2023-09-22 16:21:32 --> Config Class Initialized
INFO - 2023-09-22 16:21:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:21:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:21:32 --> Utf8 Class Initialized
INFO - 2023-09-22 16:21:32 --> URI Class Initialized
INFO - 2023-09-22 16:21:32 --> Router Class Initialized
INFO - 2023-09-22 16:21:32 --> Output Class Initialized
INFO - 2023-09-22 16:21:32 --> Security Class Initialized
DEBUG - 2023-09-22 16:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:21:32 --> Input Class Initialized
INFO - 2023-09-22 16:21:32 --> Language Class Initialized
ERROR - 2023-09-22 16:21:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:21:32 --> Config Class Initialized
INFO - 2023-09-22 16:21:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:21:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:21:32 --> Utf8 Class Initialized
INFO - 2023-09-22 16:21:32 --> URI Class Initialized
INFO - 2023-09-22 16:21:32 --> Router Class Initialized
INFO - 2023-09-22 16:21:32 --> Output Class Initialized
INFO - 2023-09-22 16:21:32 --> Security Class Initialized
DEBUG - 2023-09-22 16:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:21:32 --> Input Class Initialized
INFO - 2023-09-22 16:21:32 --> Language Class Initialized
ERROR - 2023-09-22 16:21:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:21:32 --> Config Class Initialized
INFO - 2023-09-22 16:21:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:21:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:21:32 --> Utf8 Class Initialized
INFO - 2023-09-22 16:21:32 --> URI Class Initialized
INFO - 2023-09-22 16:21:32 --> Router Class Initialized
INFO - 2023-09-22 16:21:32 --> Output Class Initialized
INFO - 2023-09-22 16:21:32 --> Security Class Initialized
DEBUG - 2023-09-22 16:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:21:32 --> Input Class Initialized
INFO - 2023-09-22 16:21:32 --> Language Class Initialized
ERROR - 2023-09-22 16:21:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:21:32 --> Config Class Initialized
INFO - 2023-09-22 16:21:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:21:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:21:32 --> Utf8 Class Initialized
INFO - 2023-09-22 16:21:32 --> URI Class Initialized
INFO - 2023-09-22 16:21:32 --> Router Class Initialized
INFO - 2023-09-22 16:21:32 --> Output Class Initialized
INFO - 2023-09-22 16:21:32 --> Security Class Initialized
DEBUG - 2023-09-22 16:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:21:32 --> Input Class Initialized
INFO - 2023-09-22 16:21:32 --> Language Class Initialized
ERROR - 2023-09-22 16:21:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:21:33 --> Config Class Initialized
INFO - 2023-09-22 16:21:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:21:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:21:33 --> Utf8 Class Initialized
INFO - 2023-09-22 16:21:33 --> URI Class Initialized
INFO - 2023-09-22 16:21:33 --> Router Class Initialized
INFO - 2023-09-22 16:21:33 --> Output Class Initialized
INFO - 2023-09-22 16:21:33 --> Security Class Initialized
DEBUG - 2023-09-22 16:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:21:33 --> Input Class Initialized
INFO - 2023-09-22 16:21:33 --> Language Class Initialized
ERROR - 2023-09-22 16:21:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:21:34 --> Config Class Initialized
INFO - 2023-09-22 16:21:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:21:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:21:34 --> Utf8 Class Initialized
INFO - 2023-09-22 16:21:34 --> URI Class Initialized
INFO - 2023-09-22 16:21:34 --> Router Class Initialized
INFO - 2023-09-22 16:21:34 --> Output Class Initialized
INFO - 2023-09-22 16:21:34 --> Security Class Initialized
DEBUG - 2023-09-22 16:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:21:34 --> Input Class Initialized
INFO - 2023-09-22 16:21:34 --> Language Class Initialized
ERROR - 2023-09-22 16:21:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:21:34 --> Config Class Initialized
INFO - 2023-09-22 16:21:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:21:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:21:34 --> Utf8 Class Initialized
INFO - 2023-09-22 16:21:34 --> URI Class Initialized
INFO - 2023-09-22 16:21:34 --> Router Class Initialized
INFO - 2023-09-22 16:21:34 --> Output Class Initialized
INFO - 2023-09-22 16:21:34 --> Security Class Initialized
DEBUG - 2023-09-22 16:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:21:34 --> Input Class Initialized
INFO - 2023-09-22 16:21:34 --> Language Class Initialized
ERROR - 2023-09-22 16:21:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:23:05 --> Config Class Initialized
INFO - 2023-09-22 16:23:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:23:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:23:05 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:05 --> URI Class Initialized
INFO - 2023-09-22 16:23:05 --> Router Class Initialized
INFO - 2023-09-22 16:23:05 --> Output Class Initialized
INFO - 2023-09-22 16:23:05 --> Security Class Initialized
DEBUG - 2023-09-22 16:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:23:05 --> Input Class Initialized
INFO - 2023-09-22 16:23:05 --> Language Class Initialized
INFO - 2023-09-22 16:23:05 --> Loader Class Initialized
INFO - 2023-09-22 16:23:05 --> Helper loaded: url_helper
INFO - 2023-09-22 16:23:05 --> Helper loaded: file_helper
INFO - 2023-09-22 16:23:05 --> Database Driver Class Initialized
INFO - 2023-09-22 16:23:05 --> Email Class Initialized
DEBUG - 2023-09-22 16:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:23:05 --> Controller Class Initialized
INFO - 2023-09-22 16:23:05 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:23:05 --> Model "Home_model" initialized
INFO - 2023-09-22 16:23:05 --> Helper loaded: download_helper
INFO - 2023-09-22 16:23:05 --> Helper loaded: form_helper
INFO - 2023-09-22 16:23:05 --> Form Validation Class Initialized
INFO - 2023-09-22 16:23:05 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:23:05 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:23:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-22 16:23:05 --> Final output sent to browser
DEBUG - 2023-09-22 16:23:05 --> Total execution time: 0.2139
INFO - 2023-09-22 16:23:06 --> Config Class Initialized
INFO - 2023-09-22 16:23:06 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:23:06 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:23:06 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:06 --> URI Class Initialized
INFO - 2023-09-22 16:23:06 --> Router Class Initialized
INFO - 2023-09-22 16:23:06 --> Output Class Initialized
INFO - 2023-09-22 16:23:06 --> Security Class Initialized
DEBUG - 2023-09-22 16:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:23:06 --> Input Class Initialized
INFO - 2023-09-22 16:23:06 --> Language Class Initialized
ERROR - 2023-09-22 16:23:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:23:07 --> Config Class Initialized
INFO - 2023-09-22 16:23:07 --> Hooks Class Initialized
INFO - 2023-09-22 16:23:08 --> Config Class Initialized
INFO - 2023-09-22 16:23:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:23:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:23:08 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:08 --> URI Class Initialized
INFO - 2023-09-22 16:23:08 --> Router Class Initialized
INFO - 2023-09-22 16:23:08 --> Output Class Initialized
INFO - 2023-09-22 16:23:08 --> Security Class Initialized
DEBUG - 2023-09-22 16:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:23:08 --> Input Class Initialized
INFO - 2023-09-22 16:23:08 --> Language Class Initialized
ERROR - 2023-09-22 16:23:08 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-22 16:23:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:23:08 --> Config Class Initialized
INFO - 2023-09-22 16:23:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:23:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:23:08 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:08 --> URI Class Initialized
INFO - 2023-09-22 16:23:08 --> Router Class Initialized
INFO - 2023-09-22 16:23:08 --> Output Class Initialized
INFO - 2023-09-22 16:23:08 --> Security Class Initialized
DEBUG - 2023-09-22 16:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:23:08 --> Input Class Initialized
INFO - 2023-09-22 16:23:08 --> Language Class Initialized
ERROR - 2023-09-22 16:23:08 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:23:08 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:08 --> URI Class Initialized
INFO - 2023-09-22 16:23:08 --> Router Class Initialized
INFO - 2023-09-22 16:23:08 --> Output Class Initialized
INFO - 2023-09-22 16:23:09 --> Security Class Initialized
DEBUG - 2023-09-22 16:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:23:09 --> Input Class Initialized
INFO - 2023-09-22 16:23:09 --> Language Class Initialized
ERROR - 2023-09-22 16:23:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:23:10 --> Config Class Initialized
INFO - 2023-09-22 16:23:10 --> Config Class Initialized
INFO - 2023-09-22 16:23:10 --> Config Class Initialized
INFO - 2023-09-22 16:23:10 --> Hooks Class Initialized
INFO - 2023-09-22 16:23:10 --> Hooks Class Initialized
INFO - 2023-09-22 16:23:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:23:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-22 16:23:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:23:10 --> Utf8 Class Initialized
DEBUG - 2023-09-22 16:23:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:23:10 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:10 --> URI Class Initialized
INFO - 2023-09-22 16:23:10 --> URI Class Initialized
INFO - 2023-09-22 16:23:10 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:10 --> Router Class Initialized
INFO - 2023-09-22 16:23:10 --> Router Class Initialized
INFO - 2023-09-22 16:23:10 --> Output Class Initialized
INFO - 2023-09-22 16:23:10 --> URI Class Initialized
INFO - 2023-09-22 16:23:10 --> Output Class Initialized
INFO - 2023-09-22 16:23:10 --> Security Class Initialized
INFO - 2023-09-22 16:23:10 --> Router Class Initialized
INFO - 2023-09-22 16:23:10 --> Security Class Initialized
DEBUG - 2023-09-22 16:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:23:10 --> Output Class Initialized
INFO - 2023-09-22 16:23:10 --> Input Class Initialized
DEBUG - 2023-09-22 16:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:23:10 --> Security Class Initialized
INFO - 2023-09-22 16:23:10 --> Language Class Initialized
INFO - 2023-09-22 16:23:10 --> Input Class Initialized
DEBUG - 2023-09-22 16:23:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-22 16:23:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:23:10 --> Language Class Initialized
ERROR - 2023-09-22 16:23:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:23:10 --> Input Class Initialized
INFO - 2023-09-22 16:23:10 --> Language Class Initialized
ERROR - 2023-09-22 16:23:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:23:33 --> Config Class Initialized
INFO - 2023-09-22 16:23:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:23:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:23:33 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:33 --> URI Class Initialized
INFO - 2023-09-22 16:23:33 --> Router Class Initialized
INFO - 2023-09-22 16:23:33 --> Output Class Initialized
INFO - 2023-09-22 16:23:33 --> Security Class Initialized
DEBUG - 2023-09-22 16:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:23:33 --> Input Class Initialized
INFO - 2023-09-22 16:23:33 --> Language Class Initialized
INFO - 2023-09-22 16:23:33 --> Loader Class Initialized
INFO - 2023-09-22 16:23:33 --> Helper loaded: url_helper
INFO - 2023-09-22 16:23:33 --> Helper loaded: file_helper
INFO - 2023-09-22 16:23:33 --> Database Driver Class Initialized
INFO - 2023-09-22 16:23:33 --> Email Class Initialized
DEBUG - 2023-09-22 16:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:23:33 --> Controller Class Initialized
INFO - 2023-09-22 16:23:33 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:23:33 --> Model "Home_model" initialized
INFO - 2023-09-22 16:23:33 --> Helper loaded: download_helper
INFO - 2023-09-22 16:23:33 --> Helper loaded: form_helper
INFO - 2023-09-22 16:23:33 --> Form Validation Class Initialized
INFO - 2023-09-22 16:23:33 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:23:33 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:23:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-22 16:23:33 --> Final output sent to browser
DEBUG - 2023-09-22 16:23:33 --> Total execution time: 0.0995
INFO - 2023-09-22 16:23:34 --> Config Class Initialized
INFO - 2023-09-22 16:23:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:23:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:23:34 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:34 --> URI Class Initialized
INFO - 2023-09-22 16:23:35 --> Router Class Initialized
INFO - 2023-09-22 16:23:35 --> Config Class Initialized
INFO - 2023-09-22 16:23:35 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:23:35 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:23:35 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:35 --> URI Class Initialized
INFO - 2023-09-22 16:23:35 --> Router Class Initialized
INFO - 2023-09-22 16:23:35 --> Output Class Initialized
INFO - 2023-09-22 16:23:35 --> Security Class Initialized
DEBUG - 2023-09-22 16:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:23:35 --> Input Class Initialized
INFO - 2023-09-22 16:23:35 --> Language Class Initialized
ERROR - 2023-09-22 16:23:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:23:35 --> Output Class Initialized
INFO - 2023-09-22 16:23:35 --> Security Class Initialized
INFO - 2023-09-22 16:23:35 --> Config Class Initialized
INFO - 2023-09-22 16:23:35 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:23:35 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:23:35 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:35 --> URI Class Initialized
INFO - 2023-09-22 16:23:35 --> Router Class Initialized
INFO - 2023-09-22 16:23:35 --> Output Class Initialized
INFO - 2023-09-22 16:23:35 --> Security Class Initialized
DEBUG - 2023-09-22 16:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:23:35 --> Input Class Initialized
INFO - 2023-09-22 16:23:35 --> Language Class Initialized
ERROR - 2023-09-22 16:23:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:23:35 --> Config Class Initialized
INFO - 2023-09-22 16:23:35 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:23:35 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:23:35 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:35 --> URI Class Initialized
INFO - 2023-09-22 16:23:35 --> Router Class Initialized
INFO - 2023-09-22 16:23:35 --> Output Class Initialized
INFO - 2023-09-22 16:23:35 --> Security Class Initialized
DEBUG - 2023-09-22 16:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:23:35 --> Input Class Initialized
INFO - 2023-09-22 16:23:35 --> Language Class Initialized
ERROR - 2023-09-22 16:23:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:23:36 --> Config Class Initialized
INFO - 2023-09-22 16:23:36 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:23:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-22 16:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:23:36 --> Config Class Initialized
INFO - 2023-09-22 16:23:37 --> Config Class Initialized
INFO - 2023-09-22 16:23:37 --> Input Class Initialized
INFO - 2023-09-22 16:23:37 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:37 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:23:37 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:23:37 --> Hooks Class Initialized
INFO - 2023-09-22 16:23:37 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:37 --> Language Class Initialized
INFO - 2023-09-22 16:23:37 --> URI Class Initialized
ERROR - 2023-09-22 16:23:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:23:37 --> URI Class Initialized
DEBUG - 2023-09-22 16:23:37 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:23:38 --> Router Class Initialized
INFO - 2023-09-22 16:23:38 --> Router Class Initialized
INFO - 2023-09-22 16:23:38 --> Output Class Initialized
INFO - 2023-09-22 16:23:38 --> Output Class Initialized
INFO - 2023-09-22 16:23:38 --> Utf8 Class Initialized
INFO - 2023-09-22 16:23:38 --> Security Class Initialized
INFO - 2023-09-22 16:23:38 --> Security Class Initialized
DEBUG - 2023-09-22 16:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:23:38 --> URI Class Initialized
INFO - 2023-09-22 16:23:38 --> Input Class Initialized
INFO - 2023-09-22 16:23:38 --> Router Class Initialized
INFO - 2023-09-22 16:23:38 --> Language Class Initialized
INFO - 2023-09-22 16:23:38 --> Output Class Initialized
ERROR - 2023-09-22 16:23:38 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-22 16:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:23:38 --> Security Class Initialized
INFO - 2023-09-22 16:23:38 --> Input Class Initialized
INFO - 2023-09-22 16:23:38 --> Language Class Initialized
DEBUG - 2023-09-22 16:23:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-22 16:23:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:23:38 --> Input Class Initialized
INFO - 2023-09-22 16:23:38 --> Language Class Initialized
ERROR - 2023-09-22 16:23:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:26:46 --> Config Class Initialized
INFO - 2023-09-22 16:26:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:26:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:26:46 --> Utf8 Class Initialized
INFO - 2023-09-22 16:26:46 --> URI Class Initialized
INFO - 2023-09-22 16:26:46 --> Router Class Initialized
INFO - 2023-09-22 16:26:46 --> Output Class Initialized
INFO - 2023-09-22 16:26:46 --> Security Class Initialized
DEBUG - 2023-09-22 16:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:26:46 --> Input Class Initialized
INFO - 2023-09-22 16:26:46 --> Language Class Initialized
INFO - 2023-09-22 16:26:46 --> Loader Class Initialized
INFO - 2023-09-22 16:26:46 --> Helper loaded: url_helper
INFO - 2023-09-22 16:26:46 --> Helper loaded: file_helper
INFO - 2023-09-22 16:26:46 --> Database Driver Class Initialized
INFO - 2023-09-22 16:26:46 --> Email Class Initialized
DEBUG - 2023-09-22 16:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:26:46 --> Controller Class Initialized
INFO - 2023-09-22 16:26:46 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:26:46 --> Model "Home_model" initialized
INFO - 2023-09-22 16:26:46 --> Helper loaded: download_helper
INFO - 2023-09-22 16:26:46 --> Helper loaded: form_helper
INFO - 2023-09-22 16:26:46 --> Form Validation Class Initialized
INFO - 2023-09-22 16:26:46 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:26:46 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:26:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-22 16:26:46 --> Final output sent to browser
DEBUG - 2023-09-22 16:26:46 --> Total execution time: 0.1620
INFO - 2023-09-22 16:26:47 --> Config Class Initialized
INFO - 2023-09-22 16:26:47 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:26:47 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:26:47 --> Utf8 Class Initialized
INFO - 2023-09-22 16:26:47 --> URI Class Initialized
INFO - 2023-09-22 16:26:47 --> Router Class Initialized
INFO - 2023-09-22 16:26:47 --> Output Class Initialized
INFO - 2023-09-22 16:26:47 --> Security Class Initialized
DEBUG - 2023-09-22 16:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:26:47 --> Input Class Initialized
INFO - 2023-09-22 16:26:47 --> Language Class Initialized
ERROR - 2023-09-22 16:26:48 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:26:49 --> Config Class Initialized
INFO - 2023-09-22 16:26:49 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:26:49 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:26:49 --> Utf8 Class Initialized
INFO - 2023-09-22 16:26:49 --> URI Class Initialized
INFO - 2023-09-22 16:26:49 --> Router Class Initialized
INFO - 2023-09-22 16:26:49 --> Output Class Initialized
INFO - 2023-09-22 16:26:49 --> Security Class Initialized
DEBUG - 2023-09-22 16:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:26:49 --> Input Class Initialized
INFO - 2023-09-22 16:26:49 --> Language Class Initialized
ERROR - 2023-09-22 16:26:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:26:49 --> Config Class Initialized
INFO - 2023-09-22 16:26:49 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:26:50 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:26:50 --> Config Class Initialized
INFO - 2023-09-22 16:26:50 --> Utf8 Class Initialized
INFO - 2023-09-22 16:26:50 --> Hooks Class Initialized
INFO - 2023-09-22 16:26:50 --> URI Class Initialized
INFO - 2023-09-22 16:26:50 --> Router Class Initialized
DEBUG - 2023-09-22 16:26:50 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:26:50 --> Utf8 Class Initialized
INFO - 2023-09-22 16:26:50 --> Output Class Initialized
INFO - 2023-09-22 16:26:50 --> URI Class Initialized
INFO - 2023-09-22 16:26:51 --> Security Class Initialized
INFO - 2023-09-22 16:26:51 --> Router Class Initialized
DEBUG - 2023-09-22 16:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:26:51 --> Output Class Initialized
INFO - 2023-09-22 16:26:51 --> Input Class Initialized
INFO - 2023-09-22 16:26:51 --> Security Class Initialized
INFO - 2023-09-22 16:26:51 --> Language Class Initialized
DEBUG - 2023-09-22 16:26:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-22 16:26:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:26:51 --> Input Class Initialized
INFO - 2023-09-22 16:26:51 --> Language Class Initialized
ERROR - 2023-09-22 16:26:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:26:51 --> Config Class Initialized
INFO - 2023-09-22 16:26:51 --> Config Class Initialized
INFO - 2023-09-22 16:26:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:26:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:26:51 --> Hooks Class Initialized
INFO - 2023-09-22 16:26:51 --> Config Class Initialized
INFO - 2023-09-22 16:26:51 --> Utf8 Class Initialized
DEBUG - 2023-09-22 16:26:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:26:51 --> URI Class Initialized
INFO - 2023-09-22 16:26:51 --> Utf8 Class Initialized
INFO - 2023-09-22 16:26:51 --> Hooks Class Initialized
INFO - 2023-09-22 16:26:51 --> URI Class Initialized
DEBUG - 2023-09-22 16:26:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:26:51 --> Router Class Initialized
INFO - 2023-09-22 16:26:51 --> Utf8 Class Initialized
INFO - 2023-09-22 16:26:51 --> Router Class Initialized
INFO - 2023-09-22 16:26:51 --> Output Class Initialized
INFO - 2023-09-22 16:26:51 --> URI Class Initialized
INFO - 2023-09-22 16:26:51 --> Output Class Initialized
INFO - 2023-09-22 16:26:51 --> Security Class Initialized
INFO - 2023-09-22 16:26:51 --> Security Class Initialized
INFO - 2023-09-22 16:26:51 --> Router Class Initialized
DEBUG - 2023-09-22 16:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-22 16:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:26:51 --> Output Class Initialized
INFO - 2023-09-22 16:26:51 --> Input Class Initialized
INFO - 2023-09-22 16:26:51 --> Input Class Initialized
INFO - 2023-09-22 16:26:51 --> Language Class Initialized
INFO - 2023-09-22 16:26:51 --> Language Class Initialized
INFO - 2023-09-22 16:26:51 --> Security Class Initialized
ERROR - 2023-09-22 16:26:51 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-22 16:26:51 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-22 16:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:26:51 --> Input Class Initialized
INFO - 2023-09-22 16:26:51 --> Language Class Initialized
ERROR - 2023-09-22 16:26:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 16:27:16 --> Config Class Initialized
INFO - 2023-09-22 16:27:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:27:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:27:16 --> Utf8 Class Initialized
INFO - 2023-09-22 16:27:16 --> URI Class Initialized
DEBUG - 2023-09-22 16:27:16 --> No URI present. Default controller set.
INFO - 2023-09-22 16:27:16 --> Router Class Initialized
INFO - 2023-09-22 16:27:16 --> Output Class Initialized
INFO - 2023-09-22 16:27:16 --> Security Class Initialized
DEBUG - 2023-09-22 16:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:27:16 --> Input Class Initialized
INFO - 2023-09-22 16:27:16 --> Language Class Initialized
INFO - 2023-09-22 16:27:16 --> Loader Class Initialized
INFO - 2023-09-22 16:27:16 --> Helper loaded: url_helper
INFO - 2023-09-22 16:27:16 --> Helper loaded: file_helper
INFO - 2023-09-22 16:27:16 --> Database Driver Class Initialized
INFO - 2023-09-22 16:27:16 --> Email Class Initialized
DEBUG - 2023-09-22 16:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:27:16 --> Controller Class Initialized
INFO - 2023-09-22 16:27:16 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:27:16 --> Model "Home_model" initialized
INFO - 2023-09-22 16:27:16 --> Helper loaded: download_helper
INFO - 2023-09-22 16:27:16 --> Helper loaded: form_helper
INFO - 2023-09-22 16:27:16 --> Form Validation Class Initialized
INFO - 2023-09-22 16:27:16 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:27:16 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:27:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-22 16:27:16 --> Final output sent to browser
DEBUG - 2023-09-22 16:27:16 --> Total execution time: 0.1372
INFO - 2023-09-22 16:27:49 --> Config Class Initialized
INFO - 2023-09-22 16:27:49 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:27:49 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:27:49 --> Utf8 Class Initialized
INFO - 2023-09-22 16:27:49 --> URI Class Initialized
DEBUG - 2023-09-22 16:27:49 --> No URI present. Default controller set.
INFO - 2023-09-22 16:27:49 --> Router Class Initialized
INFO - 2023-09-22 16:27:49 --> Output Class Initialized
INFO - 2023-09-22 16:27:49 --> Security Class Initialized
DEBUG - 2023-09-22 16:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:27:49 --> Input Class Initialized
INFO - 2023-09-22 16:27:49 --> Language Class Initialized
INFO - 2023-09-22 16:27:49 --> Loader Class Initialized
INFO - 2023-09-22 16:27:49 --> Helper loaded: url_helper
INFO - 2023-09-22 16:27:49 --> Helper loaded: file_helper
INFO - 2023-09-22 16:27:49 --> Database Driver Class Initialized
INFO - 2023-09-22 16:27:49 --> Email Class Initialized
DEBUG - 2023-09-22 16:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:27:49 --> Controller Class Initialized
INFO - 2023-09-22 16:27:49 --> Model "Contact_model" initialized
INFO - 2023-09-22 16:27:49 --> Model "Home_model" initialized
INFO - 2023-09-22 16:27:49 --> Helper loaded: download_helper
INFO - 2023-09-22 16:27:49 --> Helper loaded: form_helper
INFO - 2023-09-22 16:27:49 --> Form Validation Class Initialized
INFO - 2023-09-22 16:27:49 --> Helper loaded: custom_helper
INFO - 2023-09-22 16:27:49 --> Model "Social_media_model" initialized
INFO - 2023-09-22 16:27:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-22 16:27:49 --> Final output sent to browser
DEBUG - 2023-09-22 16:27:49 --> Total execution time: 0.1261
INFO - 2023-09-22 16:44:14 --> Config Class Initialized
INFO - 2023-09-22 16:44:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:44:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:44:14 --> Utf8 Class Initialized
INFO - 2023-09-22 16:44:14 --> URI Class Initialized
INFO - 2023-09-22 16:44:14 --> Router Class Initialized
INFO - 2023-09-22 16:44:14 --> Output Class Initialized
INFO - 2023-09-22 16:44:14 --> Security Class Initialized
DEBUG - 2023-09-22 16:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:44:14 --> Input Class Initialized
INFO - 2023-09-22 16:44:14 --> Language Class Initialized
INFO - 2023-09-22 16:44:14 --> Loader Class Initialized
INFO - 2023-09-22 16:44:14 --> Helper loaded: url_helper
INFO - 2023-09-22 16:44:14 --> Helper loaded: file_helper
INFO - 2023-09-22 16:44:14 --> Database Driver Class Initialized
INFO - 2023-09-22 16:44:14 --> Email Class Initialized
DEBUG - 2023-09-22 16:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:44:14 --> Controller Class Initialized
INFO - 2023-09-22 16:44:14 --> Config Class Initialized
INFO - 2023-09-22 16:44:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:44:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:44:14 --> Utf8 Class Initialized
INFO - 2023-09-22 16:44:14 --> URI Class Initialized
INFO - 2023-09-22 16:44:14 --> Router Class Initialized
INFO - 2023-09-22 16:44:14 --> Output Class Initialized
INFO - 2023-09-22 16:44:14 --> Security Class Initialized
DEBUG - 2023-09-22 16:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:44:14 --> Input Class Initialized
INFO - 2023-09-22 16:44:14 --> Language Class Initialized
INFO - 2023-09-22 16:44:14 --> Loader Class Initialized
INFO - 2023-09-22 16:44:14 --> Helper loaded: url_helper
INFO - 2023-09-22 16:44:14 --> Helper loaded: file_helper
INFO - 2023-09-22 16:44:14 --> Database Driver Class Initialized
INFO - 2023-09-22 16:44:14 --> Email Class Initialized
DEBUG - 2023-09-22 16:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:44:14 --> Controller Class Initialized
INFO - 2023-09-22 16:44:14 --> Model "User_model" initialized
INFO - 2023-09-22 16:44:14 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-09-22 16:44:14 --> Final output sent to browser
DEBUG - 2023-09-22 16:44:14 --> Total execution time: 0.0981
INFO - 2023-09-22 16:44:16 --> Config Class Initialized
INFO - 2023-09-22 16:44:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:44:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:44:16 --> Utf8 Class Initialized
INFO - 2023-09-22 16:44:16 --> URI Class Initialized
INFO - 2023-09-22 16:44:16 --> Router Class Initialized
INFO - 2023-09-22 16:44:16 --> Output Class Initialized
INFO - 2023-09-22 16:44:16 --> Security Class Initialized
DEBUG - 2023-09-22 16:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:44:16 --> Input Class Initialized
INFO - 2023-09-22 16:44:16 --> Language Class Initialized
ERROR - 2023-09-22 16:44:16 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-22 16:44:23 --> Config Class Initialized
INFO - 2023-09-22 16:44:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:44:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:44:23 --> Utf8 Class Initialized
INFO - 2023-09-22 16:44:23 --> URI Class Initialized
INFO - 2023-09-22 16:44:23 --> Router Class Initialized
INFO - 2023-09-22 16:44:23 --> Output Class Initialized
INFO - 2023-09-22 16:44:23 --> Security Class Initialized
DEBUG - 2023-09-22 16:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:44:23 --> Input Class Initialized
INFO - 2023-09-22 16:44:23 --> Language Class Initialized
INFO - 2023-09-22 16:44:23 --> Loader Class Initialized
INFO - 2023-09-22 16:44:23 --> Helper loaded: url_helper
INFO - 2023-09-22 16:44:23 --> Helper loaded: file_helper
INFO - 2023-09-22 16:44:23 --> Database Driver Class Initialized
INFO - 2023-09-22 16:44:23 --> Email Class Initialized
DEBUG - 2023-09-22 16:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:44:23 --> Controller Class Initialized
INFO - 2023-09-22 16:44:23 --> Model "User_model" initialized
INFO - 2023-09-22 16:44:23 --> Config Class Initialized
INFO - 2023-09-22 16:44:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:44:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:44:23 --> Utf8 Class Initialized
INFO - 2023-09-22 16:44:23 --> URI Class Initialized
INFO - 2023-09-22 16:44:23 --> Router Class Initialized
INFO - 2023-09-22 16:44:23 --> Output Class Initialized
INFO - 2023-09-22 16:44:23 --> Security Class Initialized
DEBUG - 2023-09-22 16:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:44:23 --> Input Class Initialized
INFO - 2023-09-22 16:44:23 --> Language Class Initialized
INFO - 2023-09-22 16:44:23 --> Loader Class Initialized
INFO - 2023-09-22 16:44:23 --> Helper loaded: url_helper
INFO - 2023-09-22 16:44:23 --> Helper loaded: file_helper
INFO - 2023-09-22 16:44:23 --> Database Driver Class Initialized
INFO - 2023-09-22 16:44:23 --> Email Class Initialized
DEBUG - 2023-09-22 16:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:44:23 --> Controller Class Initialized
INFO - 2023-09-22 16:44:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-09-22 16:44:23 --> Final output sent to browser
DEBUG - 2023-09-22 16:44:23 --> Total execution time: 0.0784
INFO - 2023-09-22 16:44:29 --> Config Class Initialized
INFO - 2023-09-22 16:44:29 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:44:29 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:44:29 --> Utf8 Class Initialized
INFO - 2023-09-22 16:44:29 --> URI Class Initialized
INFO - 2023-09-22 16:44:29 --> Router Class Initialized
INFO - 2023-09-22 16:44:29 --> Output Class Initialized
INFO - 2023-09-22 16:44:29 --> Security Class Initialized
DEBUG - 2023-09-22 16:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:44:29 --> Input Class Initialized
INFO - 2023-09-22 16:44:29 --> Language Class Initialized
INFO - 2023-09-22 16:44:29 --> Loader Class Initialized
INFO - 2023-09-22 16:44:29 --> Helper loaded: url_helper
INFO - 2023-09-22 16:44:29 --> Helper loaded: file_helper
INFO - 2023-09-22 16:44:29 --> Database Driver Class Initialized
INFO - 2023-09-22 16:44:29 --> Email Class Initialized
DEBUG - 2023-09-22 16:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:44:29 --> Controller Class Initialized
INFO - 2023-09-22 16:44:29 --> Model "Services_model" initialized
INFO - 2023-09-22 16:44:29 --> Helper loaded: form_helper
INFO - 2023-09-22 16:44:29 --> Form Validation Class Initialized
INFO - 2023-09-22 16:44:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-22 16:44:29 --> Final output sent to browser
DEBUG - 2023-09-22 16:44:29 --> Total execution time: 0.0982
INFO - 2023-09-22 16:44:45 --> Config Class Initialized
INFO - 2023-09-22 16:44:45 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:44:45 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:44:45 --> Utf8 Class Initialized
INFO - 2023-09-22 16:44:45 --> URI Class Initialized
INFO - 2023-09-22 16:44:45 --> Router Class Initialized
INFO - 2023-09-22 16:44:45 --> Output Class Initialized
INFO - 2023-09-22 16:44:45 --> Security Class Initialized
DEBUG - 2023-09-22 16:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:44:45 --> Input Class Initialized
INFO - 2023-09-22 16:44:45 --> Language Class Initialized
INFO - 2023-09-22 16:44:45 --> Loader Class Initialized
INFO - 2023-09-22 16:44:45 --> Helper loaded: url_helper
INFO - 2023-09-22 16:44:45 --> Helper loaded: file_helper
INFO - 2023-09-22 16:44:45 --> Database Driver Class Initialized
INFO - 2023-09-22 16:44:45 --> Email Class Initialized
DEBUG - 2023-09-22 16:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:44:45 --> Controller Class Initialized
INFO - 2023-09-22 16:44:45 --> Model "Services_model" initialized
INFO - 2023-09-22 16:44:45 --> Helper loaded: form_helper
INFO - 2023-09-22 16:44:45 --> Form Validation Class Initialized
INFO - 2023-09-22 16:44:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-09-22 16:44:45 --> Final output sent to browser
DEBUG - 2023-09-22 16:44:45 --> Total execution time: 0.1077
INFO - 2023-09-22 16:44:46 --> Config Class Initialized
INFO - 2023-09-22 16:44:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:44:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:44:46 --> Utf8 Class Initialized
INFO - 2023-09-22 16:44:46 --> URI Class Initialized
INFO - 2023-09-22 16:44:46 --> Router Class Initialized
INFO - 2023-09-22 16:44:46 --> Output Class Initialized
INFO - 2023-09-22 16:44:46 --> Security Class Initialized
DEBUG - 2023-09-22 16:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:44:46 --> Input Class Initialized
INFO - 2023-09-22 16:44:46 --> Language Class Initialized
ERROR - 2023-09-22 16:44:46 --> 404 Page Not Found: admin/Services/images
INFO - 2023-09-22 16:46:59 --> Config Class Initialized
INFO - 2023-09-22 16:46:59 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:46:59 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:46:59 --> Utf8 Class Initialized
INFO - 2023-09-22 16:46:59 --> URI Class Initialized
INFO - 2023-09-22 16:46:59 --> Router Class Initialized
INFO - 2023-09-22 16:46:59 --> Output Class Initialized
INFO - 2023-09-22 16:46:59 --> Security Class Initialized
DEBUG - 2023-09-22 16:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:46:59 --> Input Class Initialized
INFO - 2023-09-22 16:46:59 --> Language Class Initialized
INFO - 2023-09-22 16:46:59 --> Loader Class Initialized
INFO - 2023-09-22 16:47:00 --> Helper loaded: url_helper
INFO - 2023-09-22 16:47:00 --> Helper loaded: file_helper
INFO - 2023-09-22 16:47:00 --> Database Driver Class Initialized
INFO - 2023-09-22 16:47:00 --> Email Class Initialized
DEBUG - 2023-09-22 16:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:47:00 --> Controller Class Initialized
INFO - 2023-09-22 16:47:00 --> Model "Services_model" initialized
INFO - 2023-09-22 16:47:00 --> Helper loaded: form_helper
INFO - 2023-09-22 16:47:00 --> Form Validation Class Initialized
INFO - 2023-09-22 16:47:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 16:47:00 --> Config Class Initialized
INFO - 2023-09-22 16:47:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:47:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:47:00 --> Utf8 Class Initialized
INFO - 2023-09-22 16:47:00 --> URI Class Initialized
INFO - 2023-09-22 16:47:00 --> Router Class Initialized
INFO - 2023-09-22 16:47:00 --> Output Class Initialized
INFO - 2023-09-22 16:47:00 --> Security Class Initialized
DEBUG - 2023-09-22 16:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:47:00 --> Input Class Initialized
INFO - 2023-09-22 16:47:00 --> Language Class Initialized
INFO - 2023-09-22 16:47:00 --> Loader Class Initialized
INFO - 2023-09-22 16:47:00 --> Helper loaded: url_helper
INFO - 2023-09-22 16:47:00 --> Helper loaded: file_helper
INFO - 2023-09-22 16:47:00 --> Database Driver Class Initialized
INFO - 2023-09-22 16:47:00 --> Email Class Initialized
DEBUG - 2023-09-22 16:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:47:00 --> Controller Class Initialized
INFO - 2023-09-22 16:47:00 --> Model "Services_model" initialized
INFO - 2023-09-22 16:47:00 --> Helper loaded: form_helper
INFO - 2023-09-22 16:47:00 --> Form Validation Class Initialized
INFO - 2023-09-22 16:47:00 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-22 16:47:00 --> Final output sent to browser
DEBUG - 2023-09-22 16:47:00 --> Total execution time: 0.1386
INFO - 2023-09-22 16:47:09 --> Config Class Initialized
INFO - 2023-09-22 16:47:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:47:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:47:09 --> Utf8 Class Initialized
INFO - 2023-09-22 16:47:09 --> URI Class Initialized
INFO - 2023-09-22 16:47:09 --> Router Class Initialized
INFO - 2023-09-22 16:47:09 --> Output Class Initialized
INFO - 2023-09-22 16:47:09 --> Security Class Initialized
DEBUG - 2023-09-22 16:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:47:09 --> Input Class Initialized
INFO - 2023-09-22 16:47:09 --> Language Class Initialized
INFO - 2023-09-22 16:47:09 --> Loader Class Initialized
INFO - 2023-09-22 16:47:09 --> Helper loaded: url_helper
INFO - 2023-09-22 16:47:09 --> Helper loaded: file_helper
INFO - 2023-09-22 16:47:09 --> Database Driver Class Initialized
INFO - 2023-09-22 16:47:09 --> Email Class Initialized
DEBUG - 2023-09-22 16:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:47:10 --> Controller Class Initialized
INFO - 2023-09-22 16:47:10 --> Model "Services_model" initialized
INFO - 2023-09-22 16:47:10 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:47:10 --> Helper loaded: form_helper
INFO - 2023-09-22 16:47:10 --> Form Validation Class Initialized
INFO - 2023-09-22 16:47:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 16:47:10 --> Final output sent to browser
DEBUG - 2023-09-22 16:47:10 --> Total execution time: 0.1535
INFO - 2023-09-22 16:47:10 --> Config Class Initialized
INFO - 2023-09-22 16:47:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:47:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:47:10 --> Utf8 Class Initialized
INFO - 2023-09-22 16:47:10 --> URI Class Initialized
INFO - 2023-09-22 16:47:10 --> Router Class Initialized
INFO - 2023-09-22 16:47:10 --> Output Class Initialized
INFO - 2023-09-22 16:47:10 --> Security Class Initialized
DEBUG - 2023-09-22 16:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:47:10 --> Input Class Initialized
INFO - 2023-09-22 16:47:10 --> Language Class Initialized
ERROR - 2023-09-22 16:47:10 --> 404 Page Not Found: admin/Services_cards/images
INFO - 2023-09-22 16:47:12 --> Config Class Initialized
INFO - 2023-09-22 16:47:12 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:47:12 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:47:12 --> Utf8 Class Initialized
INFO - 2023-09-22 16:47:12 --> URI Class Initialized
INFO - 2023-09-22 16:47:12 --> Router Class Initialized
INFO - 2023-09-22 16:47:12 --> Output Class Initialized
INFO - 2023-09-22 16:47:12 --> Security Class Initialized
DEBUG - 2023-09-22 16:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:47:12 --> Input Class Initialized
INFO - 2023-09-22 16:47:12 --> Language Class Initialized
INFO - 2023-09-22 16:47:12 --> Loader Class Initialized
INFO - 2023-09-22 16:47:12 --> Helper loaded: url_helper
INFO - 2023-09-22 16:47:12 --> Helper loaded: file_helper
INFO - 2023-09-22 16:47:12 --> Database Driver Class Initialized
INFO - 2023-09-22 16:47:12 --> Email Class Initialized
DEBUG - 2023-09-22 16:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:47:12 --> Controller Class Initialized
INFO - 2023-09-22 16:47:12 --> Model "Services_model" initialized
INFO - 2023-09-22 16:47:12 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:47:12 --> Helper loaded: form_helper
INFO - 2023-09-22 16:47:12 --> Form Validation Class Initialized
INFO - 2023-09-22 16:47:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:47:12 --> Final output sent to browser
DEBUG - 2023-09-22 16:47:12 --> Total execution time: 0.1222
INFO - 2023-09-22 16:48:08 --> Config Class Initialized
INFO - 2023-09-22 16:48:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:48:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:48:08 --> Utf8 Class Initialized
INFO - 2023-09-22 16:48:08 --> URI Class Initialized
INFO - 2023-09-22 16:48:08 --> Router Class Initialized
INFO - 2023-09-22 16:48:08 --> Output Class Initialized
INFO - 2023-09-22 16:48:08 --> Security Class Initialized
DEBUG - 2023-09-22 16:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:48:08 --> Input Class Initialized
INFO - 2023-09-22 16:48:08 --> Language Class Initialized
INFO - 2023-09-22 16:48:08 --> Loader Class Initialized
INFO - 2023-09-22 16:48:08 --> Helper loaded: url_helper
INFO - 2023-09-22 16:48:08 --> Helper loaded: file_helper
INFO - 2023-09-22 16:48:08 --> Database Driver Class Initialized
INFO - 2023-09-22 16:48:08 --> Email Class Initialized
DEBUG - 2023-09-22 16:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:48:08 --> Controller Class Initialized
INFO - 2023-09-22 16:48:08 --> Model "Services_model" initialized
INFO - 2023-09-22 16:48:08 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:48:08 --> Helper loaded: form_helper
INFO - 2023-09-22 16:48:08 --> Form Validation Class Initialized
INFO - 2023-09-22 16:48:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 16:48:08 --> Config Class Initialized
INFO - 2023-09-22 16:48:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:48:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:48:08 --> Utf8 Class Initialized
INFO - 2023-09-22 16:48:09 --> URI Class Initialized
INFO - 2023-09-22 16:48:09 --> Router Class Initialized
INFO - 2023-09-22 16:48:09 --> Output Class Initialized
INFO - 2023-09-22 16:48:09 --> Security Class Initialized
DEBUG - 2023-09-22 16:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:48:09 --> Input Class Initialized
INFO - 2023-09-22 16:48:09 --> Language Class Initialized
INFO - 2023-09-22 16:48:09 --> Loader Class Initialized
INFO - 2023-09-22 16:48:09 --> Helper loaded: url_helper
INFO - 2023-09-22 16:48:09 --> Helper loaded: file_helper
INFO - 2023-09-22 16:48:09 --> Database Driver Class Initialized
INFO - 2023-09-22 16:48:09 --> Email Class Initialized
DEBUG - 2023-09-22 16:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:48:09 --> Controller Class Initialized
INFO - 2023-09-22 16:48:09 --> Model "Services_model" initialized
INFO - 2023-09-22 16:48:09 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:48:09 --> Helper loaded: form_helper
INFO - 2023-09-22 16:48:09 --> Form Validation Class Initialized
INFO - 2023-09-22 16:48:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 16:48:09 --> Final output sent to browser
DEBUG - 2023-09-22 16:48:09 --> Total execution time: 0.4263
INFO - 2023-09-22 16:48:20 --> Config Class Initialized
INFO - 2023-09-22 16:48:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:48:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:48:20 --> Utf8 Class Initialized
INFO - 2023-09-22 16:48:20 --> URI Class Initialized
INFO - 2023-09-22 16:48:20 --> Router Class Initialized
INFO - 2023-09-22 16:48:20 --> Output Class Initialized
INFO - 2023-09-22 16:48:20 --> Security Class Initialized
DEBUG - 2023-09-22 16:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:48:20 --> Input Class Initialized
INFO - 2023-09-22 16:48:20 --> Language Class Initialized
INFO - 2023-09-22 16:48:20 --> Loader Class Initialized
INFO - 2023-09-22 16:48:20 --> Helper loaded: url_helper
INFO - 2023-09-22 16:48:20 --> Helper loaded: file_helper
INFO - 2023-09-22 16:48:20 --> Database Driver Class Initialized
INFO - 2023-09-22 16:48:20 --> Email Class Initialized
DEBUG - 2023-09-22 16:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:48:20 --> Controller Class Initialized
INFO - 2023-09-22 16:48:20 --> Model "Services_model" initialized
INFO - 2023-09-22 16:48:20 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:48:20 --> Helper loaded: form_helper
INFO - 2023-09-22 16:48:20 --> Form Validation Class Initialized
INFO - 2023-09-22 16:48:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:48:20 --> Final output sent to browser
DEBUG - 2023-09-22 16:48:20 --> Total execution time: 0.1134
INFO - 2023-09-22 16:48:21 --> Config Class Initialized
INFO - 2023-09-22 16:48:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:48:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:48:21 --> Utf8 Class Initialized
INFO - 2023-09-22 16:48:21 --> URI Class Initialized
INFO - 2023-09-22 16:48:21 --> Router Class Initialized
INFO - 2023-09-22 16:48:21 --> Output Class Initialized
INFO - 2023-09-22 16:48:21 --> Security Class Initialized
DEBUG - 2023-09-22 16:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:48:21 --> Input Class Initialized
INFO - 2023-09-22 16:48:21 --> Language Class Initialized
INFO - 2023-09-22 16:48:21 --> Loader Class Initialized
INFO - 2023-09-22 16:48:21 --> Helper loaded: url_helper
INFO - 2023-09-22 16:48:21 --> Helper loaded: file_helper
INFO - 2023-09-22 16:48:21 --> Database Driver Class Initialized
INFO - 2023-09-22 16:48:21 --> Email Class Initialized
DEBUG - 2023-09-22 16:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:48:21 --> Controller Class Initialized
INFO - 2023-09-22 16:48:21 --> Model "Services_model" initialized
INFO - 2023-09-22 16:48:21 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:48:21 --> Helper loaded: form_helper
INFO - 2023-09-22 16:48:21 --> Form Validation Class Initialized
INFO - 2023-09-22 16:48:21 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:48:21 --> Final output sent to browser
DEBUG - 2023-09-22 16:48:21 --> Total execution time: 0.1349
INFO - 2023-09-22 16:48:51 --> Config Class Initialized
INFO - 2023-09-22 16:48:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:48:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:48:51 --> Utf8 Class Initialized
INFO - 2023-09-22 16:48:51 --> URI Class Initialized
INFO - 2023-09-22 16:48:51 --> Router Class Initialized
INFO - 2023-09-22 16:48:51 --> Output Class Initialized
INFO - 2023-09-22 16:48:51 --> Security Class Initialized
DEBUG - 2023-09-22 16:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:48:51 --> Input Class Initialized
INFO - 2023-09-22 16:48:51 --> Language Class Initialized
INFO - 2023-09-22 16:48:51 --> Loader Class Initialized
INFO - 2023-09-22 16:48:51 --> Helper loaded: url_helper
INFO - 2023-09-22 16:48:51 --> Helper loaded: file_helper
INFO - 2023-09-22 16:48:51 --> Database Driver Class Initialized
INFO - 2023-09-22 16:48:51 --> Email Class Initialized
DEBUG - 2023-09-22 16:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:48:51 --> Controller Class Initialized
INFO - 2023-09-22 16:48:51 --> Model "Services_model" initialized
INFO - 2023-09-22 16:48:51 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:48:51 --> Helper loaded: form_helper
INFO - 2023-09-22 16:48:51 --> Form Validation Class Initialized
INFO - 2023-09-22 16:48:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 16:48:51 --> Config Class Initialized
INFO - 2023-09-22 16:48:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:48:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:48:51 --> Utf8 Class Initialized
INFO - 2023-09-22 16:48:51 --> URI Class Initialized
INFO - 2023-09-22 16:48:51 --> Router Class Initialized
INFO - 2023-09-22 16:48:51 --> Output Class Initialized
INFO - 2023-09-22 16:48:51 --> Security Class Initialized
DEBUG - 2023-09-22 16:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:48:51 --> Input Class Initialized
INFO - 2023-09-22 16:48:51 --> Language Class Initialized
INFO - 2023-09-22 16:48:51 --> Loader Class Initialized
INFO - 2023-09-22 16:48:51 --> Helper loaded: url_helper
INFO - 2023-09-22 16:48:51 --> Helper loaded: file_helper
INFO - 2023-09-22 16:48:51 --> Database Driver Class Initialized
INFO - 2023-09-22 16:48:51 --> Email Class Initialized
DEBUG - 2023-09-22 16:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:48:51 --> Controller Class Initialized
INFO - 2023-09-22 16:48:51 --> Model "Services_model" initialized
INFO - 2023-09-22 16:48:51 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:48:51 --> Helper loaded: form_helper
INFO - 2023-09-22 16:48:51 --> Form Validation Class Initialized
INFO - 2023-09-22 16:48:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 16:48:51 --> Final output sent to browser
DEBUG - 2023-09-22 16:48:51 --> Total execution time: 0.1246
INFO - 2023-09-22 16:48:59 --> Config Class Initialized
INFO - 2023-09-22 16:48:59 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:48:59 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:48:59 --> Utf8 Class Initialized
INFO - 2023-09-22 16:48:59 --> URI Class Initialized
INFO - 2023-09-22 16:48:59 --> Router Class Initialized
INFO - 2023-09-22 16:48:59 --> Output Class Initialized
INFO - 2023-09-22 16:48:59 --> Security Class Initialized
DEBUG - 2023-09-22 16:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:48:59 --> Input Class Initialized
INFO - 2023-09-22 16:48:59 --> Language Class Initialized
INFO - 2023-09-22 16:48:59 --> Loader Class Initialized
INFO - 2023-09-22 16:48:59 --> Helper loaded: url_helper
INFO - 2023-09-22 16:48:59 --> Helper loaded: file_helper
INFO - 2023-09-22 16:48:59 --> Database Driver Class Initialized
INFO - 2023-09-22 16:48:59 --> Email Class Initialized
DEBUG - 2023-09-22 16:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:48:59 --> Controller Class Initialized
INFO - 2023-09-22 16:48:59 --> Model "Services_model" initialized
INFO - 2023-09-22 16:48:59 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:48:59 --> Helper loaded: form_helper
INFO - 2023-09-22 16:48:59 --> Form Validation Class Initialized
INFO - 2023-09-22 16:48:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:48:59 --> Final output sent to browser
DEBUG - 2023-09-22 16:48:59 --> Total execution time: 0.1018
INFO - 2023-09-22 16:49:00 --> Config Class Initialized
INFO - 2023-09-22 16:49:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:49:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:49:00 --> Utf8 Class Initialized
INFO - 2023-09-22 16:49:00 --> URI Class Initialized
INFO - 2023-09-22 16:49:00 --> Router Class Initialized
INFO - 2023-09-22 16:49:00 --> Output Class Initialized
INFO - 2023-09-22 16:49:00 --> Security Class Initialized
DEBUG - 2023-09-22 16:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:49:00 --> Input Class Initialized
INFO - 2023-09-22 16:49:00 --> Language Class Initialized
INFO - 2023-09-22 16:49:00 --> Loader Class Initialized
INFO - 2023-09-22 16:49:00 --> Helper loaded: url_helper
INFO - 2023-09-22 16:49:00 --> Helper loaded: file_helper
INFO - 2023-09-22 16:49:00 --> Database Driver Class Initialized
INFO - 2023-09-22 16:49:00 --> Email Class Initialized
DEBUG - 2023-09-22 16:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:49:00 --> Controller Class Initialized
INFO - 2023-09-22 16:49:00 --> Model "Services_model" initialized
INFO - 2023-09-22 16:49:00 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:49:00 --> Helper loaded: form_helper
INFO - 2023-09-22 16:49:00 --> Form Validation Class Initialized
INFO - 2023-09-22 16:49:00 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:49:00 --> Final output sent to browser
DEBUG - 2023-09-22 16:49:00 --> Total execution time: 0.1087
INFO - 2023-09-22 16:49:21 --> Config Class Initialized
INFO - 2023-09-22 16:49:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:49:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:49:21 --> Utf8 Class Initialized
INFO - 2023-09-22 16:49:21 --> URI Class Initialized
INFO - 2023-09-22 16:49:21 --> Router Class Initialized
INFO - 2023-09-22 16:49:21 --> Output Class Initialized
INFO - 2023-09-22 16:49:21 --> Security Class Initialized
DEBUG - 2023-09-22 16:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:49:21 --> Input Class Initialized
INFO - 2023-09-22 16:49:21 --> Language Class Initialized
INFO - 2023-09-22 16:49:21 --> Loader Class Initialized
INFO - 2023-09-22 16:49:21 --> Helper loaded: url_helper
INFO - 2023-09-22 16:49:21 --> Helper loaded: file_helper
INFO - 2023-09-22 16:49:21 --> Database Driver Class Initialized
INFO - 2023-09-22 16:49:21 --> Email Class Initialized
DEBUG - 2023-09-22 16:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:49:21 --> Controller Class Initialized
INFO - 2023-09-22 16:49:21 --> Model "Services_model" initialized
INFO - 2023-09-22 16:49:21 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:49:21 --> Helper loaded: form_helper
INFO - 2023-09-22 16:49:21 --> Form Validation Class Initialized
INFO - 2023-09-22 16:49:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 16:49:21 --> Config Class Initialized
INFO - 2023-09-22 16:49:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:49:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:49:21 --> Utf8 Class Initialized
INFO - 2023-09-22 16:49:21 --> URI Class Initialized
INFO - 2023-09-22 16:49:21 --> Router Class Initialized
INFO - 2023-09-22 16:49:21 --> Output Class Initialized
INFO - 2023-09-22 16:49:21 --> Security Class Initialized
DEBUG - 2023-09-22 16:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:49:21 --> Input Class Initialized
INFO - 2023-09-22 16:49:21 --> Language Class Initialized
INFO - 2023-09-22 16:49:21 --> Loader Class Initialized
INFO - 2023-09-22 16:49:21 --> Helper loaded: url_helper
INFO - 2023-09-22 16:49:21 --> Helper loaded: file_helper
INFO - 2023-09-22 16:49:21 --> Database Driver Class Initialized
INFO - 2023-09-22 16:49:21 --> Email Class Initialized
DEBUG - 2023-09-22 16:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:49:21 --> Controller Class Initialized
INFO - 2023-09-22 16:49:21 --> Model "Services_model" initialized
INFO - 2023-09-22 16:49:21 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:49:21 --> Helper loaded: form_helper
INFO - 2023-09-22 16:49:21 --> Form Validation Class Initialized
INFO - 2023-09-22 16:49:21 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 16:49:21 --> Final output sent to browser
DEBUG - 2023-09-22 16:49:21 --> Total execution time: 0.1308
INFO - 2023-09-22 16:49:30 --> Config Class Initialized
INFO - 2023-09-22 16:49:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:49:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:49:30 --> Utf8 Class Initialized
INFO - 2023-09-22 16:49:30 --> URI Class Initialized
INFO - 2023-09-22 16:49:30 --> Router Class Initialized
INFO - 2023-09-22 16:49:30 --> Output Class Initialized
INFO - 2023-09-22 16:49:30 --> Security Class Initialized
DEBUG - 2023-09-22 16:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:49:30 --> Input Class Initialized
INFO - 2023-09-22 16:49:30 --> Language Class Initialized
INFO - 2023-09-22 16:49:30 --> Loader Class Initialized
INFO - 2023-09-22 16:49:30 --> Helper loaded: url_helper
INFO - 2023-09-22 16:49:30 --> Helper loaded: file_helper
INFO - 2023-09-22 16:49:30 --> Database Driver Class Initialized
INFO - 2023-09-22 16:49:30 --> Email Class Initialized
DEBUG - 2023-09-22 16:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:49:30 --> Controller Class Initialized
INFO - 2023-09-22 16:49:30 --> Model "Services_model" initialized
INFO - 2023-09-22 16:49:30 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:49:30 --> Helper loaded: form_helper
INFO - 2023-09-22 16:49:30 --> Form Validation Class Initialized
INFO - 2023-09-22 16:49:30 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:49:30 --> Final output sent to browser
DEBUG - 2023-09-22 16:49:30 --> Total execution time: 0.1071
INFO - 2023-09-22 16:49:31 --> Config Class Initialized
INFO - 2023-09-22 16:49:31 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:49:31 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:49:31 --> Utf8 Class Initialized
INFO - 2023-09-22 16:49:31 --> URI Class Initialized
INFO - 2023-09-22 16:49:31 --> Router Class Initialized
INFO - 2023-09-22 16:49:31 --> Output Class Initialized
INFO - 2023-09-22 16:49:31 --> Security Class Initialized
DEBUG - 2023-09-22 16:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:49:31 --> Input Class Initialized
INFO - 2023-09-22 16:49:31 --> Language Class Initialized
INFO - 2023-09-22 16:49:31 --> Loader Class Initialized
INFO - 2023-09-22 16:49:31 --> Helper loaded: url_helper
INFO - 2023-09-22 16:49:31 --> Helper loaded: file_helper
INFO - 2023-09-22 16:49:31 --> Database Driver Class Initialized
INFO - 2023-09-22 16:49:31 --> Email Class Initialized
DEBUG - 2023-09-22 16:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:49:31 --> Controller Class Initialized
INFO - 2023-09-22 16:49:31 --> Model "Services_model" initialized
INFO - 2023-09-22 16:49:31 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:49:31 --> Helper loaded: form_helper
INFO - 2023-09-22 16:49:31 --> Form Validation Class Initialized
INFO - 2023-09-22 16:49:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:49:31 --> Final output sent to browser
DEBUG - 2023-09-22 16:49:31 --> Total execution time: 0.1361
INFO - 2023-09-22 16:49:54 --> Config Class Initialized
INFO - 2023-09-22 16:49:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:49:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:49:54 --> Utf8 Class Initialized
INFO - 2023-09-22 16:49:54 --> URI Class Initialized
INFO - 2023-09-22 16:49:54 --> Router Class Initialized
INFO - 2023-09-22 16:49:54 --> Output Class Initialized
INFO - 2023-09-22 16:49:54 --> Security Class Initialized
DEBUG - 2023-09-22 16:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:49:54 --> Input Class Initialized
INFO - 2023-09-22 16:49:54 --> Language Class Initialized
INFO - 2023-09-22 16:49:54 --> Loader Class Initialized
INFO - 2023-09-22 16:49:54 --> Helper loaded: url_helper
INFO - 2023-09-22 16:49:54 --> Helper loaded: file_helper
INFO - 2023-09-22 16:49:54 --> Database Driver Class Initialized
INFO - 2023-09-22 16:49:54 --> Email Class Initialized
DEBUG - 2023-09-22 16:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:49:54 --> Controller Class Initialized
INFO - 2023-09-22 16:49:54 --> Model "Services_model" initialized
INFO - 2023-09-22 16:49:54 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:49:54 --> Helper loaded: form_helper
INFO - 2023-09-22 16:49:54 --> Form Validation Class Initialized
INFO - 2023-09-22 16:49:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 16:49:54 --> Config Class Initialized
INFO - 2023-09-22 16:49:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:49:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:49:54 --> Utf8 Class Initialized
INFO - 2023-09-22 16:49:54 --> URI Class Initialized
INFO - 2023-09-22 16:49:54 --> Router Class Initialized
INFO - 2023-09-22 16:49:54 --> Output Class Initialized
INFO - 2023-09-22 16:49:54 --> Security Class Initialized
DEBUG - 2023-09-22 16:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:49:54 --> Input Class Initialized
INFO - 2023-09-22 16:49:54 --> Language Class Initialized
INFO - 2023-09-22 16:49:54 --> Loader Class Initialized
INFO - 2023-09-22 16:49:54 --> Helper loaded: url_helper
INFO - 2023-09-22 16:49:54 --> Helper loaded: file_helper
INFO - 2023-09-22 16:49:54 --> Database Driver Class Initialized
INFO - 2023-09-22 16:49:54 --> Email Class Initialized
DEBUG - 2023-09-22 16:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:49:54 --> Controller Class Initialized
INFO - 2023-09-22 16:49:54 --> Model "Services_model" initialized
INFO - 2023-09-22 16:49:54 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:49:54 --> Helper loaded: form_helper
INFO - 2023-09-22 16:49:54 --> Form Validation Class Initialized
INFO - 2023-09-22 16:49:54 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 16:49:54 --> Final output sent to browser
DEBUG - 2023-09-22 16:49:55 --> Total execution time: 0.5476
INFO - 2023-09-22 16:50:01 --> Config Class Initialized
INFO - 2023-09-22 16:50:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:50:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:50:01 --> Utf8 Class Initialized
INFO - 2023-09-22 16:50:01 --> URI Class Initialized
INFO - 2023-09-22 16:50:01 --> Router Class Initialized
INFO - 2023-09-22 16:50:01 --> Output Class Initialized
INFO - 2023-09-22 16:50:01 --> Security Class Initialized
DEBUG - 2023-09-22 16:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:50:01 --> Input Class Initialized
INFO - 2023-09-22 16:50:01 --> Language Class Initialized
INFO - 2023-09-22 16:50:01 --> Loader Class Initialized
INFO - 2023-09-22 16:50:01 --> Helper loaded: url_helper
INFO - 2023-09-22 16:50:01 --> Helper loaded: file_helper
INFO - 2023-09-22 16:50:01 --> Database Driver Class Initialized
INFO - 2023-09-22 16:50:01 --> Email Class Initialized
DEBUG - 2023-09-22 16:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:50:01 --> Controller Class Initialized
INFO - 2023-09-22 16:50:01 --> Model "Services_model" initialized
INFO - 2023-09-22 16:50:01 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:50:01 --> Helper loaded: form_helper
INFO - 2023-09-22 16:50:01 --> Form Validation Class Initialized
INFO - 2023-09-22 16:50:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:50:01 --> Final output sent to browser
DEBUG - 2023-09-22 16:50:01 --> Total execution time: 0.1253
INFO - 2023-09-22 16:50:02 --> Config Class Initialized
INFO - 2023-09-22 16:50:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:50:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:50:02 --> Utf8 Class Initialized
INFO - 2023-09-22 16:50:02 --> URI Class Initialized
INFO - 2023-09-22 16:50:02 --> Router Class Initialized
INFO - 2023-09-22 16:50:02 --> Output Class Initialized
INFO - 2023-09-22 16:50:02 --> Security Class Initialized
DEBUG - 2023-09-22 16:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:50:02 --> Input Class Initialized
INFO - 2023-09-22 16:50:02 --> Language Class Initialized
INFO - 2023-09-22 16:50:02 --> Loader Class Initialized
INFO - 2023-09-22 16:50:02 --> Helper loaded: url_helper
INFO - 2023-09-22 16:50:02 --> Helper loaded: file_helper
INFO - 2023-09-22 16:50:02 --> Database Driver Class Initialized
INFO - 2023-09-22 16:50:02 --> Email Class Initialized
DEBUG - 2023-09-22 16:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:50:02 --> Controller Class Initialized
INFO - 2023-09-22 16:50:02 --> Model "Services_model" initialized
INFO - 2023-09-22 16:50:02 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:50:02 --> Helper loaded: form_helper
INFO - 2023-09-22 16:50:02 --> Form Validation Class Initialized
INFO - 2023-09-22 16:50:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:50:02 --> Final output sent to browser
DEBUG - 2023-09-22 16:50:02 --> Total execution time: 0.1494
INFO - 2023-09-22 16:50:24 --> Config Class Initialized
INFO - 2023-09-22 16:50:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:50:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:50:25 --> Utf8 Class Initialized
INFO - 2023-09-22 16:50:25 --> URI Class Initialized
INFO - 2023-09-22 16:50:25 --> Router Class Initialized
INFO - 2023-09-22 16:50:25 --> Output Class Initialized
INFO - 2023-09-22 16:50:25 --> Security Class Initialized
DEBUG - 2023-09-22 16:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:50:25 --> Input Class Initialized
INFO - 2023-09-22 16:50:25 --> Language Class Initialized
INFO - 2023-09-22 16:50:25 --> Loader Class Initialized
INFO - 2023-09-22 16:50:25 --> Helper loaded: url_helper
INFO - 2023-09-22 16:50:25 --> Helper loaded: file_helper
INFO - 2023-09-22 16:50:25 --> Database Driver Class Initialized
INFO - 2023-09-22 16:50:25 --> Email Class Initialized
DEBUG - 2023-09-22 16:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:50:25 --> Controller Class Initialized
INFO - 2023-09-22 16:50:25 --> Model "Services_model" initialized
INFO - 2023-09-22 16:50:25 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:50:25 --> Helper loaded: form_helper
INFO - 2023-09-22 16:50:25 --> Form Validation Class Initialized
INFO - 2023-09-22 16:50:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 16:50:25 --> Config Class Initialized
INFO - 2023-09-22 16:50:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:50:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:50:25 --> Utf8 Class Initialized
INFO - 2023-09-22 16:50:25 --> URI Class Initialized
INFO - 2023-09-22 16:50:25 --> Router Class Initialized
INFO - 2023-09-22 16:50:25 --> Output Class Initialized
INFO - 2023-09-22 16:50:25 --> Security Class Initialized
DEBUG - 2023-09-22 16:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:50:25 --> Input Class Initialized
INFO - 2023-09-22 16:50:25 --> Language Class Initialized
INFO - 2023-09-22 16:50:25 --> Loader Class Initialized
INFO - 2023-09-22 16:50:25 --> Helper loaded: url_helper
INFO - 2023-09-22 16:50:25 --> Helper loaded: file_helper
INFO - 2023-09-22 16:50:25 --> Database Driver Class Initialized
INFO - 2023-09-22 16:50:25 --> Email Class Initialized
DEBUG - 2023-09-22 16:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:50:25 --> Controller Class Initialized
INFO - 2023-09-22 16:50:25 --> Model "Services_model" initialized
INFO - 2023-09-22 16:50:25 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:50:25 --> Helper loaded: form_helper
INFO - 2023-09-22 16:50:25 --> Form Validation Class Initialized
INFO - 2023-09-22 16:50:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 16:50:25 --> Final output sent to browser
DEBUG - 2023-09-22 16:50:25 --> Total execution time: 0.2376
INFO - 2023-09-22 16:50:32 --> Config Class Initialized
INFO - 2023-09-22 16:50:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:50:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:50:32 --> Utf8 Class Initialized
INFO - 2023-09-22 16:50:32 --> URI Class Initialized
INFO - 2023-09-22 16:50:32 --> Router Class Initialized
INFO - 2023-09-22 16:50:32 --> Output Class Initialized
INFO - 2023-09-22 16:50:32 --> Security Class Initialized
DEBUG - 2023-09-22 16:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:50:32 --> Input Class Initialized
INFO - 2023-09-22 16:50:32 --> Language Class Initialized
INFO - 2023-09-22 16:50:32 --> Loader Class Initialized
INFO - 2023-09-22 16:50:32 --> Helper loaded: url_helper
INFO - 2023-09-22 16:50:32 --> Helper loaded: file_helper
INFO - 2023-09-22 16:50:32 --> Database Driver Class Initialized
INFO - 2023-09-22 16:50:32 --> Email Class Initialized
DEBUG - 2023-09-22 16:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:50:32 --> Controller Class Initialized
INFO - 2023-09-22 16:50:32 --> Model "Services_model" initialized
INFO - 2023-09-22 16:50:32 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:50:32 --> Helper loaded: form_helper
INFO - 2023-09-22 16:50:32 --> Form Validation Class Initialized
INFO - 2023-09-22 16:50:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:50:32 --> Final output sent to browser
DEBUG - 2023-09-22 16:50:32 --> Total execution time: 0.1035
INFO - 2023-09-22 16:50:33 --> Config Class Initialized
INFO - 2023-09-22 16:50:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:50:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:50:33 --> Utf8 Class Initialized
INFO - 2023-09-22 16:50:33 --> URI Class Initialized
INFO - 2023-09-22 16:50:33 --> Router Class Initialized
INFO - 2023-09-22 16:50:33 --> Output Class Initialized
INFO - 2023-09-22 16:50:33 --> Security Class Initialized
DEBUG - 2023-09-22 16:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:50:33 --> Input Class Initialized
INFO - 2023-09-22 16:50:33 --> Language Class Initialized
INFO - 2023-09-22 16:50:33 --> Loader Class Initialized
INFO - 2023-09-22 16:50:33 --> Helper loaded: url_helper
INFO - 2023-09-22 16:50:33 --> Helper loaded: file_helper
INFO - 2023-09-22 16:50:33 --> Database Driver Class Initialized
INFO - 2023-09-22 16:50:33 --> Email Class Initialized
DEBUG - 2023-09-22 16:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:50:33 --> Controller Class Initialized
INFO - 2023-09-22 16:50:33 --> Model "Services_model" initialized
INFO - 2023-09-22 16:50:33 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:50:33 --> Helper loaded: form_helper
INFO - 2023-09-22 16:50:33 --> Form Validation Class Initialized
INFO - 2023-09-22 16:50:33 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:50:33 --> Final output sent to browser
DEBUG - 2023-09-22 16:50:33 --> Total execution time: 0.0553
INFO - 2023-09-22 16:51:09 --> Config Class Initialized
INFO - 2023-09-22 16:51:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:51:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:51:09 --> Utf8 Class Initialized
INFO - 2023-09-22 16:51:09 --> URI Class Initialized
INFO - 2023-09-22 16:51:09 --> Router Class Initialized
INFO - 2023-09-22 16:51:09 --> Output Class Initialized
INFO - 2023-09-22 16:51:09 --> Security Class Initialized
DEBUG - 2023-09-22 16:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:51:09 --> Input Class Initialized
INFO - 2023-09-22 16:51:09 --> Language Class Initialized
INFO - 2023-09-22 16:51:09 --> Loader Class Initialized
INFO - 2023-09-22 16:51:09 --> Helper loaded: url_helper
INFO - 2023-09-22 16:51:09 --> Helper loaded: file_helper
INFO - 2023-09-22 16:51:09 --> Database Driver Class Initialized
INFO - 2023-09-22 16:51:09 --> Email Class Initialized
DEBUG - 2023-09-22 16:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:51:09 --> Controller Class Initialized
INFO - 2023-09-22 16:51:09 --> Model "Services_model" initialized
INFO - 2023-09-22 16:51:09 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:51:09 --> Helper loaded: form_helper
INFO - 2023-09-22 16:51:09 --> Form Validation Class Initialized
INFO - 2023-09-22 16:51:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 16:51:09 --> Config Class Initialized
INFO - 2023-09-22 16:51:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:51:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:51:09 --> Utf8 Class Initialized
INFO - 2023-09-22 16:51:09 --> URI Class Initialized
INFO - 2023-09-22 16:51:09 --> Router Class Initialized
INFO - 2023-09-22 16:51:09 --> Output Class Initialized
INFO - 2023-09-22 16:51:09 --> Security Class Initialized
DEBUG - 2023-09-22 16:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:51:09 --> Input Class Initialized
INFO - 2023-09-22 16:51:09 --> Language Class Initialized
INFO - 2023-09-22 16:51:09 --> Loader Class Initialized
INFO - 2023-09-22 16:51:09 --> Helper loaded: url_helper
INFO - 2023-09-22 16:51:09 --> Helper loaded: file_helper
INFO - 2023-09-22 16:51:09 --> Database Driver Class Initialized
INFO - 2023-09-22 16:51:09 --> Email Class Initialized
DEBUG - 2023-09-22 16:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:51:09 --> Controller Class Initialized
INFO - 2023-09-22 16:51:09 --> Model "Services_model" initialized
INFO - 2023-09-22 16:51:09 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:51:09 --> Helper loaded: form_helper
INFO - 2023-09-22 16:51:09 --> Form Validation Class Initialized
INFO - 2023-09-22 16:51:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 16:51:09 --> Final output sent to browser
DEBUG - 2023-09-22 16:51:09 --> Total execution time: 0.0628
INFO - 2023-09-22 16:51:17 --> Config Class Initialized
INFO - 2023-09-22 16:51:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:51:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:51:17 --> Utf8 Class Initialized
INFO - 2023-09-22 16:51:17 --> URI Class Initialized
INFO - 2023-09-22 16:51:17 --> Router Class Initialized
INFO - 2023-09-22 16:51:17 --> Output Class Initialized
INFO - 2023-09-22 16:51:17 --> Security Class Initialized
DEBUG - 2023-09-22 16:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:51:17 --> Input Class Initialized
INFO - 2023-09-22 16:51:17 --> Language Class Initialized
INFO - 2023-09-22 16:51:17 --> Loader Class Initialized
INFO - 2023-09-22 16:51:17 --> Helper loaded: url_helper
INFO - 2023-09-22 16:51:17 --> Helper loaded: file_helper
INFO - 2023-09-22 16:51:17 --> Database Driver Class Initialized
INFO - 2023-09-22 16:51:17 --> Email Class Initialized
DEBUG - 2023-09-22 16:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:51:17 --> Controller Class Initialized
INFO - 2023-09-22 16:51:17 --> Model "Services_model" initialized
INFO - 2023-09-22 16:51:17 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:51:17 --> Helper loaded: form_helper
INFO - 2023-09-22 16:51:17 --> Form Validation Class Initialized
INFO - 2023-09-22 16:51:17 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:51:17 --> Final output sent to browser
DEBUG - 2023-09-22 16:51:17 --> Total execution time: 0.1003
INFO - 2023-09-22 16:51:18 --> Config Class Initialized
INFO - 2023-09-22 16:51:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:51:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:51:18 --> Utf8 Class Initialized
INFO - 2023-09-22 16:51:18 --> URI Class Initialized
INFO - 2023-09-22 16:51:18 --> Router Class Initialized
INFO - 2023-09-22 16:51:18 --> Output Class Initialized
INFO - 2023-09-22 16:51:18 --> Security Class Initialized
DEBUG - 2023-09-22 16:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:51:18 --> Input Class Initialized
INFO - 2023-09-22 16:51:18 --> Language Class Initialized
INFO - 2023-09-22 16:51:18 --> Loader Class Initialized
INFO - 2023-09-22 16:51:18 --> Helper loaded: url_helper
INFO - 2023-09-22 16:51:18 --> Helper loaded: file_helper
INFO - 2023-09-22 16:51:18 --> Database Driver Class Initialized
INFO - 2023-09-22 16:51:18 --> Email Class Initialized
DEBUG - 2023-09-22 16:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:51:18 --> Controller Class Initialized
INFO - 2023-09-22 16:51:18 --> Model "Services_model" initialized
INFO - 2023-09-22 16:51:18 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:51:18 --> Helper loaded: form_helper
INFO - 2023-09-22 16:51:18 --> Form Validation Class Initialized
INFO - 2023-09-22 16:51:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:51:18 --> Final output sent to browser
DEBUG - 2023-09-22 16:51:18 --> Total execution time: 0.0496
INFO - 2023-09-22 16:51:40 --> Config Class Initialized
INFO - 2023-09-22 16:51:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:51:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:51:40 --> Utf8 Class Initialized
INFO - 2023-09-22 16:51:40 --> URI Class Initialized
INFO - 2023-09-22 16:51:40 --> Router Class Initialized
INFO - 2023-09-22 16:51:40 --> Output Class Initialized
INFO - 2023-09-22 16:51:40 --> Security Class Initialized
DEBUG - 2023-09-22 16:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:51:40 --> Input Class Initialized
INFO - 2023-09-22 16:51:40 --> Language Class Initialized
INFO - 2023-09-22 16:51:40 --> Loader Class Initialized
INFO - 2023-09-22 16:51:40 --> Helper loaded: url_helper
INFO - 2023-09-22 16:51:40 --> Helper loaded: file_helper
INFO - 2023-09-22 16:51:40 --> Database Driver Class Initialized
INFO - 2023-09-22 16:51:40 --> Email Class Initialized
DEBUG - 2023-09-22 16:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:51:40 --> Controller Class Initialized
INFO - 2023-09-22 16:51:40 --> Model "Services_model" initialized
INFO - 2023-09-22 16:51:40 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:51:40 --> Helper loaded: form_helper
INFO - 2023-09-22 16:51:40 --> Form Validation Class Initialized
INFO - 2023-09-22 16:51:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 16:51:40 --> Config Class Initialized
INFO - 2023-09-22 16:51:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:51:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:51:40 --> Utf8 Class Initialized
INFO - 2023-09-22 16:51:40 --> URI Class Initialized
INFO - 2023-09-22 16:51:40 --> Router Class Initialized
INFO - 2023-09-22 16:51:40 --> Output Class Initialized
INFO - 2023-09-22 16:51:40 --> Security Class Initialized
DEBUG - 2023-09-22 16:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:51:40 --> Input Class Initialized
INFO - 2023-09-22 16:51:40 --> Language Class Initialized
INFO - 2023-09-22 16:51:40 --> Loader Class Initialized
INFO - 2023-09-22 16:51:40 --> Helper loaded: url_helper
INFO - 2023-09-22 16:51:40 --> Helper loaded: file_helper
INFO - 2023-09-22 16:51:40 --> Database Driver Class Initialized
INFO - 2023-09-22 16:51:40 --> Email Class Initialized
DEBUG - 2023-09-22 16:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:51:40 --> Controller Class Initialized
INFO - 2023-09-22 16:51:40 --> Model "Services_model" initialized
INFO - 2023-09-22 16:51:40 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:51:40 --> Helper loaded: form_helper
INFO - 2023-09-22 16:51:40 --> Form Validation Class Initialized
INFO - 2023-09-22 16:51:40 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 16:51:40 --> Final output sent to browser
DEBUG - 2023-09-22 16:51:40 --> Total execution time: 0.1129
INFO - 2023-09-22 16:51:42 --> Config Class Initialized
INFO - 2023-09-22 16:51:42 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:51:42 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:51:42 --> Utf8 Class Initialized
INFO - 2023-09-22 16:51:42 --> URI Class Initialized
INFO - 2023-09-22 16:51:42 --> Router Class Initialized
INFO - 2023-09-22 16:51:42 --> Output Class Initialized
INFO - 2023-09-22 16:51:42 --> Security Class Initialized
DEBUG - 2023-09-22 16:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:51:42 --> Input Class Initialized
INFO - 2023-09-22 16:51:42 --> Language Class Initialized
INFO - 2023-09-22 16:51:42 --> Loader Class Initialized
INFO - 2023-09-22 16:51:42 --> Helper loaded: url_helper
INFO - 2023-09-22 16:51:42 --> Helper loaded: file_helper
INFO - 2023-09-22 16:51:42 --> Database Driver Class Initialized
INFO - 2023-09-22 16:51:42 --> Email Class Initialized
DEBUG - 2023-09-22 16:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:51:42 --> Controller Class Initialized
INFO - 2023-09-22 16:51:42 --> Model "Services_model" initialized
INFO - 2023-09-22 16:51:42 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:51:42 --> Helper loaded: form_helper
INFO - 2023-09-22 16:51:42 --> Form Validation Class Initialized
INFO - 2023-09-22 16:51:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:51:42 --> Final output sent to browser
INFO - 2023-09-22 16:52:10 --> Config Class Initialized
INFO - 2023-09-22 16:52:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:52:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:52:10 --> Utf8 Class Initialized
INFO - 2023-09-22 16:52:10 --> URI Class Initialized
INFO - 2023-09-22 16:52:10 --> Router Class Initialized
INFO - 2023-09-22 16:52:10 --> Output Class Initialized
INFO - 2023-09-22 16:52:10 --> Security Class Initialized
DEBUG - 2023-09-22 16:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:52:10 --> Input Class Initialized
INFO - 2023-09-22 16:52:10 --> Language Class Initialized
INFO - 2023-09-22 16:52:10 --> Loader Class Initialized
INFO - 2023-09-22 16:52:10 --> Helper loaded: url_helper
INFO - 2023-09-22 16:52:10 --> Helper loaded: file_helper
INFO - 2023-09-22 16:52:10 --> Database Driver Class Initialized
INFO - 2023-09-22 16:52:10 --> Email Class Initialized
DEBUG - 2023-09-22 16:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:52:10 --> Controller Class Initialized
INFO - 2023-09-22 16:52:10 --> Model "Services_model" initialized
INFO - 2023-09-22 16:52:10 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:52:10 --> Helper loaded: form_helper
INFO - 2023-09-22 16:52:10 --> Form Validation Class Initialized
INFO - 2023-09-22 16:52:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 16:52:10 --> Config Class Initialized
INFO - 2023-09-22 16:52:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:52:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:52:10 --> Utf8 Class Initialized
INFO - 2023-09-22 16:52:10 --> URI Class Initialized
INFO - 2023-09-22 16:52:10 --> Router Class Initialized
INFO - 2023-09-22 16:52:10 --> Output Class Initialized
INFO - 2023-09-22 16:52:10 --> Security Class Initialized
DEBUG - 2023-09-22 16:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:52:10 --> Input Class Initialized
INFO - 2023-09-22 16:52:10 --> Language Class Initialized
INFO - 2023-09-22 16:52:10 --> Loader Class Initialized
INFO - 2023-09-22 16:52:10 --> Helper loaded: url_helper
INFO - 2023-09-22 16:52:10 --> Helper loaded: file_helper
INFO - 2023-09-22 16:52:10 --> Database Driver Class Initialized
INFO - 2023-09-22 16:52:10 --> Email Class Initialized
DEBUG - 2023-09-22 16:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:52:10 --> Controller Class Initialized
INFO - 2023-09-22 16:52:10 --> Model "Services_model" initialized
INFO - 2023-09-22 16:52:10 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:52:10 --> Helper loaded: form_helper
INFO - 2023-09-22 16:52:10 --> Form Validation Class Initialized
INFO - 2023-09-22 16:52:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 16:52:10 --> Final output sent to browser
DEBUG - 2023-09-22 16:52:10 --> Total execution time: 0.1241
INFO - 2023-09-22 16:52:12 --> Config Class Initialized
INFO - 2023-09-22 16:52:12 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:52:12 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:52:12 --> Utf8 Class Initialized
INFO - 2023-09-22 16:52:12 --> URI Class Initialized
INFO - 2023-09-22 16:52:12 --> Router Class Initialized
INFO - 2023-09-22 16:52:12 --> Output Class Initialized
INFO - 2023-09-22 16:52:12 --> Security Class Initialized
DEBUG - 2023-09-22 16:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:52:12 --> Input Class Initialized
INFO - 2023-09-22 16:52:12 --> Language Class Initialized
INFO - 2023-09-22 16:52:12 --> Loader Class Initialized
INFO - 2023-09-22 16:52:12 --> Helper loaded: url_helper
INFO - 2023-09-22 16:52:12 --> Helper loaded: file_helper
INFO - 2023-09-22 16:52:12 --> Database Driver Class Initialized
INFO - 2023-09-22 16:52:12 --> Email Class Initialized
DEBUG - 2023-09-22 16:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:52:12 --> Controller Class Initialized
INFO - 2023-09-22 16:52:12 --> Model "Services_model" initialized
INFO - 2023-09-22 16:52:12 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:52:12 --> Helper loaded: form_helper
INFO - 2023-09-22 16:52:12 --> Form Validation Class Initialized
INFO - 2023-09-22 16:52:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:52:12 --> Final output sent to browser
DEBUG - 2023-09-22 16:52:12 --> Total execution time: 0.2312
INFO - 2023-09-22 16:52:13 --> Config Class Initialized
INFO - 2023-09-22 16:52:13 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:52:13 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:52:13 --> Utf8 Class Initialized
INFO - 2023-09-22 16:52:13 --> URI Class Initialized
INFO - 2023-09-22 16:52:13 --> Router Class Initialized
INFO - 2023-09-22 16:52:13 --> Output Class Initialized
INFO - 2023-09-22 16:52:13 --> Security Class Initialized
DEBUG - 2023-09-22 16:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:52:13 --> Input Class Initialized
INFO - 2023-09-22 16:52:13 --> Language Class Initialized
INFO - 2023-09-22 16:52:13 --> Loader Class Initialized
INFO - 2023-09-22 16:52:13 --> Helper loaded: url_helper
INFO - 2023-09-22 16:52:13 --> Helper loaded: file_helper
INFO - 2023-09-22 16:52:13 --> Database Driver Class Initialized
INFO - 2023-09-22 16:52:13 --> Email Class Initialized
DEBUG - 2023-09-22 16:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:52:13 --> Controller Class Initialized
INFO - 2023-09-22 16:52:13 --> Model "Services_model" initialized
INFO - 2023-09-22 16:52:13 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:52:13 --> Helper loaded: form_helper
INFO - 2023-09-22 16:52:13 --> Form Validation Class Initialized
INFO - 2023-09-22 16:52:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 16:52:13 --> Final output sent to browser
DEBUG - 2023-09-22 16:52:13 --> Total execution time: 0.4021
INFO - 2023-09-22 16:52:39 --> Config Class Initialized
INFO - 2023-09-22 16:52:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:52:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:52:39 --> Utf8 Class Initialized
INFO - 2023-09-22 16:52:39 --> URI Class Initialized
INFO - 2023-09-22 16:52:39 --> Router Class Initialized
INFO - 2023-09-22 16:52:39 --> Output Class Initialized
INFO - 2023-09-22 16:52:39 --> Security Class Initialized
DEBUG - 2023-09-22 16:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:52:39 --> Input Class Initialized
INFO - 2023-09-22 16:52:39 --> Language Class Initialized
INFO - 2023-09-22 16:52:39 --> Loader Class Initialized
INFO - 2023-09-22 16:52:39 --> Helper loaded: url_helper
INFO - 2023-09-22 16:52:39 --> Helper loaded: file_helper
INFO - 2023-09-22 16:52:39 --> Database Driver Class Initialized
INFO - 2023-09-22 16:52:39 --> Email Class Initialized
DEBUG - 2023-09-22 16:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:52:39 --> Controller Class Initialized
INFO - 2023-09-22 16:52:39 --> Model "Services_model" initialized
INFO - 2023-09-22 16:52:39 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:52:39 --> Helper loaded: form_helper
INFO - 2023-09-22 16:52:39 --> Form Validation Class Initialized
INFO - 2023-09-22 16:52:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 16:52:40 --> Config Class Initialized
INFO - 2023-09-22 16:52:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:52:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:52:40 --> Utf8 Class Initialized
INFO - 2023-09-22 16:52:40 --> URI Class Initialized
INFO - 2023-09-22 16:52:40 --> Router Class Initialized
INFO - 2023-09-22 16:52:40 --> Output Class Initialized
INFO - 2023-09-22 16:52:40 --> Security Class Initialized
DEBUG - 2023-09-22 16:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:52:40 --> Input Class Initialized
INFO - 2023-09-22 16:52:40 --> Language Class Initialized
INFO - 2023-09-22 16:52:40 --> Loader Class Initialized
INFO - 2023-09-22 16:52:40 --> Helper loaded: url_helper
INFO - 2023-09-22 16:52:40 --> Helper loaded: file_helper
INFO - 2023-09-22 16:52:40 --> Database Driver Class Initialized
INFO - 2023-09-22 16:52:40 --> Email Class Initialized
DEBUG - 2023-09-22 16:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 16:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:52:40 --> Controller Class Initialized
INFO - 2023-09-22 16:52:40 --> Model "Services_model" initialized
INFO - 2023-09-22 16:52:40 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 16:52:40 --> Helper loaded: form_helper
INFO - 2023-09-22 16:52:40 --> Form Validation Class Initialized
INFO - 2023-09-22 16:52:40 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 16:52:40 --> Final output sent to browser
DEBUG - 2023-09-22 16:52:40 --> Total execution time: 0.1201
INFO - 2023-09-22 18:13:12 --> Config Class Initialized
INFO - 2023-09-22 18:13:12 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:13:12 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:13:12 --> Utf8 Class Initialized
INFO - 2023-09-22 18:13:12 --> URI Class Initialized
INFO - 2023-09-22 18:13:12 --> Router Class Initialized
INFO - 2023-09-22 18:13:12 --> Output Class Initialized
INFO - 2023-09-22 18:13:12 --> Security Class Initialized
DEBUG - 2023-09-22 18:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:13:12 --> Input Class Initialized
INFO - 2023-09-22 18:13:12 --> Language Class Initialized
INFO - 2023-09-22 18:13:12 --> Loader Class Initialized
INFO - 2023-09-22 18:13:12 --> Helper loaded: url_helper
INFO - 2023-09-22 18:13:13 --> Helper loaded: file_helper
INFO - 2023-09-22 18:13:13 --> Database Driver Class Initialized
INFO - 2023-09-22 18:13:13 --> Email Class Initialized
DEBUG - 2023-09-22 18:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:13:13 --> Controller Class Initialized
INFO - 2023-09-22 18:13:13 --> Model "Services_model" initialized
INFO - 2023-09-22 18:13:13 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:13:13 --> Helper loaded: form_helper
INFO - 2023-09-22 18:13:13 --> Form Validation Class Initialized
INFO - 2023-09-22 18:13:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:13:13 --> Final output sent to browser
DEBUG - 2023-09-22 18:13:13 --> Total execution time: 0.2181
INFO - 2023-09-22 18:13:17 --> Config Class Initialized
INFO - 2023-09-22 18:13:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:13:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:13:17 --> Utf8 Class Initialized
INFO - 2023-09-22 18:13:17 --> URI Class Initialized
INFO - 2023-09-22 18:13:17 --> Router Class Initialized
INFO - 2023-09-22 18:13:17 --> Output Class Initialized
INFO - 2023-09-22 18:13:17 --> Security Class Initialized
DEBUG - 2023-09-22 18:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:13:17 --> Input Class Initialized
INFO - 2023-09-22 18:13:17 --> Language Class Initialized
INFO - 2023-09-22 18:13:17 --> Loader Class Initialized
INFO - 2023-09-22 18:13:17 --> Helper loaded: url_helper
INFO - 2023-09-22 18:13:17 --> Helper loaded: file_helper
INFO - 2023-09-22 18:13:17 --> Database Driver Class Initialized
INFO - 2023-09-22 18:13:17 --> Email Class Initialized
DEBUG - 2023-09-22 18:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:13:17 --> Controller Class Initialized
INFO - 2023-09-22 18:13:17 --> Model "Services_model" initialized
INFO - 2023-09-22 18:13:17 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:13:17 --> Helper loaded: form_helper
INFO - 2023-09-22 18:13:17 --> Form Validation Class Initialized
INFO - 2023-09-22 18:13:17 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:13:17 --> Final output sent to browser
DEBUG - 2023-09-22 18:13:17 --> Total execution time: 0.4221
INFO - 2023-09-22 18:13:18 --> Config Class Initialized
INFO - 2023-09-22 18:13:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:13:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:13:18 --> Utf8 Class Initialized
INFO - 2023-09-22 18:13:18 --> URI Class Initialized
INFO - 2023-09-22 18:13:18 --> Router Class Initialized
INFO - 2023-09-22 18:13:18 --> Output Class Initialized
INFO - 2023-09-22 18:13:18 --> Security Class Initialized
DEBUG - 2023-09-22 18:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:13:18 --> Input Class Initialized
INFO - 2023-09-22 18:13:18 --> Language Class Initialized
INFO - 2023-09-22 18:13:18 --> Loader Class Initialized
INFO - 2023-09-22 18:13:18 --> Helper loaded: url_helper
INFO - 2023-09-22 18:13:18 --> Helper loaded: file_helper
INFO - 2023-09-22 18:13:18 --> Database Driver Class Initialized
INFO - 2023-09-22 18:13:18 --> Email Class Initialized
DEBUG - 2023-09-22 18:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:13:18 --> Controller Class Initialized
INFO - 2023-09-22 18:13:18 --> Model "Services_model" initialized
INFO - 2023-09-22 18:13:18 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:13:18 --> Helper loaded: form_helper
INFO - 2023-09-22 18:13:18 --> Form Validation Class Initialized
INFO - 2023-09-22 18:13:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:13:18 --> Final output sent to browser
DEBUG - 2023-09-22 18:13:19 --> Total execution time: 0.1328
INFO - 2023-09-22 18:13:37 --> Config Class Initialized
INFO - 2023-09-22 18:13:37 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:13:37 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:13:37 --> Utf8 Class Initialized
INFO - 2023-09-22 18:13:37 --> URI Class Initialized
INFO - 2023-09-22 18:13:37 --> Router Class Initialized
INFO - 2023-09-22 18:13:37 --> Output Class Initialized
INFO - 2023-09-22 18:13:37 --> Security Class Initialized
DEBUG - 2023-09-22 18:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:13:37 --> Input Class Initialized
INFO - 2023-09-22 18:13:37 --> Language Class Initialized
INFO - 2023-09-22 18:13:37 --> Loader Class Initialized
INFO - 2023-09-22 18:13:37 --> Helper loaded: url_helper
INFO - 2023-09-22 18:13:37 --> Helper loaded: file_helper
INFO - 2023-09-22 18:13:37 --> Database Driver Class Initialized
INFO - 2023-09-22 18:13:37 --> Email Class Initialized
DEBUG - 2023-09-22 18:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:13:37 --> Controller Class Initialized
INFO - 2023-09-22 18:13:37 --> Model "Services_model" initialized
INFO - 2023-09-22 18:13:37 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:13:37 --> Helper loaded: form_helper
INFO - 2023-09-22 18:13:37 --> Form Validation Class Initialized
INFO - 2023-09-22 18:13:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:13:37 --> Final output sent to browser
DEBUG - 2023-09-22 18:13:37 --> Total execution time: 0.1135
INFO - 2023-09-22 18:13:38 --> Config Class Initialized
INFO - 2023-09-22 18:13:38 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:13:38 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:13:38 --> Utf8 Class Initialized
INFO - 2023-09-22 18:13:38 --> URI Class Initialized
INFO - 2023-09-22 18:13:38 --> Router Class Initialized
INFO - 2023-09-22 18:13:38 --> Output Class Initialized
INFO - 2023-09-22 18:13:38 --> Security Class Initialized
DEBUG - 2023-09-22 18:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:13:38 --> Input Class Initialized
INFO - 2023-09-22 18:13:38 --> Language Class Initialized
INFO - 2023-09-22 18:13:38 --> Loader Class Initialized
INFO - 2023-09-22 18:13:38 --> Helper loaded: url_helper
INFO - 2023-09-22 18:13:38 --> Helper loaded: file_helper
INFO - 2023-09-22 18:13:38 --> Database Driver Class Initialized
INFO - 2023-09-22 18:13:38 --> Email Class Initialized
DEBUG - 2023-09-22 18:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:13:38 --> Controller Class Initialized
INFO - 2023-09-22 18:13:38 --> Model "Services_model" initialized
INFO - 2023-09-22 18:13:38 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:13:38 --> Helper loaded: form_helper
INFO - 2023-09-22 18:13:38 --> Form Validation Class Initialized
INFO - 2023-09-22 18:13:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:13:38 --> Final output sent to browser
DEBUG - 2023-09-22 18:13:38 --> Total execution time: 0.1351
INFO - 2023-09-22 18:14:00 --> Config Class Initialized
INFO - 2023-09-22 18:14:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:14:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:14:00 --> Utf8 Class Initialized
INFO - 2023-09-22 18:14:00 --> URI Class Initialized
INFO - 2023-09-22 18:14:00 --> Router Class Initialized
INFO - 2023-09-22 18:14:00 --> Output Class Initialized
INFO - 2023-09-22 18:14:00 --> Security Class Initialized
DEBUG - 2023-09-22 18:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:14:00 --> Input Class Initialized
INFO - 2023-09-22 18:14:00 --> Language Class Initialized
INFO - 2023-09-22 18:14:00 --> Loader Class Initialized
INFO - 2023-09-22 18:14:00 --> Helper loaded: url_helper
INFO - 2023-09-22 18:14:00 --> Helper loaded: file_helper
INFO - 2023-09-22 18:14:00 --> Database Driver Class Initialized
INFO - 2023-09-22 18:14:00 --> Email Class Initialized
DEBUG - 2023-09-22 18:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:14:00 --> Controller Class Initialized
INFO - 2023-09-22 18:14:00 --> Model "Services_model" initialized
INFO - 2023-09-22 18:14:00 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:14:00 --> Helper loaded: form_helper
INFO - 2023-09-22 18:14:00 --> Form Validation Class Initialized
INFO - 2023-09-22 18:14:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:14:00 --> Config Class Initialized
INFO - 2023-09-22 18:14:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:14:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:14:00 --> Utf8 Class Initialized
INFO - 2023-09-22 18:14:00 --> URI Class Initialized
INFO - 2023-09-22 18:14:00 --> Router Class Initialized
INFO - 2023-09-22 18:14:00 --> Output Class Initialized
INFO - 2023-09-22 18:14:00 --> Security Class Initialized
DEBUG - 2023-09-22 18:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:14:00 --> Input Class Initialized
INFO - 2023-09-22 18:14:00 --> Language Class Initialized
INFO - 2023-09-22 18:14:00 --> Loader Class Initialized
INFO - 2023-09-22 18:14:00 --> Helper loaded: url_helper
INFO - 2023-09-22 18:14:00 --> Helper loaded: file_helper
INFO - 2023-09-22 18:14:00 --> Database Driver Class Initialized
INFO - 2023-09-22 18:14:00 --> Email Class Initialized
DEBUG - 2023-09-22 18:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:14:00 --> Controller Class Initialized
INFO - 2023-09-22 18:14:00 --> Model "Services_model" initialized
INFO - 2023-09-22 18:14:00 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:14:00 --> Helper loaded: form_helper
INFO - 2023-09-22 18:14:00 --> Form Validation Class Initialized
INFO - 2023-09-22 18:14:00 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:14:00 --> Final output sent to browser
DEBUG - 2023-09-22 18:14:00 --> Total execution time: 0.1142
INFO - 2023-09-22 18:14:10 --> Config Class Initialized
INFO - 2023-09-22 18:14:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:14:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:14:10 --> Utf8 Class Initialized
INFO - 2023-09-22 18:14:10 --> URI Class Initialized
INFO - 2023-09-22 18:14:10 --> Router Class Initialized
INFO - 2023-09-22 18:14:10 --> Output Class Initialized
INFO - 2023-09-22 18:14:10 --> Security Class Initialized
DEBUG - 2023-09-22 18:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:14:10 --> Input Class Initialized
INFO - 2023-09-22 18:14:10 --> Language Class Initialized
INFO - 2023-09-22 18:14:10 --> Loader Class Initialized
INFO - 2023-09-22 18:14:10 --> Helper loaded: url_helper
INFO - 2023-09-22 18:14:10 --> Helper loaded: file_helper
INFO - 2023-09-22 18:14:10 --> Database Driver Class Initialized
INFO - 2023-09-22 18:14:10 --> Email Class Initialized
DEBUG - 2023-09-22 18:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:14:10 --> Controller Class Initialized
INFO - 2023-09-22 18:14:10 --> Model "Services_model" initialized
INFO - 2023-09-22 18:14:10 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:14:10 --> Helper loaded: form_helper
INFO - 2023-09-22 18:14:10 --> Form Validation Class Initialized
INFO - 2023-09-22 18:14:10 --> Config Class Initialized
INFO - 2023-09-22 18:14:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:14:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:14:10 --> Utf8 Class Initialized
INFO - 2023-09-22 18:14:10 --> URI Class Initialized
INFO - 2023-09-22 18:14:10 --> Router Class Initialized
INFO - 2023-09-22 18:14:10 --> Output Class Initialized
INFO - 2023-09-22 18:14:10 --> Security Class Initialized
DEBUG - 2023-09-22 18:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:14:10 --> Input Class Initialized
INFO - 2023-09-22 18:14:10 --> Language Class Initialized
INFO - 2023-09-22 18:14:10 --> Loader Class Initialized
INFO - 2023-09-22 18:14:10 --> Helper loaded: url_helper
INFO - 2023-09-22 18:14:10 --> Helper loaded: file_helper
INFO - 2023-09-22 18:14:10 --> Database Driver Class Initialized
INFO - 2023-09-22 18:14:10 --> Email Class Initialized
DEBUG - 2023-09-22 18:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:14:10 --> Controller Class Initialized
INFO - 2023-09-22 18:14:10 --> Model "Services_model" initialized
INFO - 2023-09-22 18:14:10 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:14:10 --> Helper loaded: form_helper
INFO - 2023-09-22 18:14:10 --> Form Validation Class Initialized
INFO - 2023-09-22 18:14:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:14:10 --> Final output sent to browser
DEBUG - 2023-09-22 18:14:10 --> Total execution time: 0.1220
INFO - 2023-09-22 18:14:23 --> Config Class Initialized
INFO - 2023-09-22 18:14:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:14:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:14:23 --> Utf8 Class Initialized
INFO - 2023-09-22 18:14:23 --> URI Class Initialized
INFO - 2023-09-22 18:14:23 --> Router Class Initialized
INFO - 2023-09-22 18:14:23 --> Output Class Initialized
INFO - 2023-09-22 18:14:23 --> Security Class Initialized
DEBUG - 2023-09-22 18:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:14:23 --> Input Class Initialized
INFO - 2023-09-22 18:14:23 --> Language Class Initialized
INFO - 2023-09-22 18:14:23 --> Loader Class Initialized
INFO - 2023-09-22 18:14:23 --> Helper loaded: url_helper
INFO - 2023-09-22 18:14:23 --> Helper loaded: file_helper
INFO - 2023-09-22 18:14:23 --> Database Driver Class Initialized
INFO - 2023-09-22 18:14:23 --> Email Class Initialized
DEBUG - 2023-09-22 18:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:14:23 --> Controller Class Initialized
INFO - 2023-09-22 18:14:23 --> Model "Services_model" initialized
INFO - 2023-09-22 18:14:23 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:14:23 --> Helper loaded: form_helper
INFO - 2023-09-22 18:14:23 --> Form Validation Class Initialized
INFO - 2023-09-22 18:14:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:14:23 --> Final output sent to browser
DEBUG - 2023-09-22 18:14:23 --> Total execution time: 0.1299
INFO - 2023-09-22 18:14:24 --> Config Class Initialized
INFO - 2023-09-22 18:14:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:14:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:14:24 --> Utf8 Class Initialized
INFO - 2023-09-22 18:14:24 --> URI Class Initialized
INFO - 2023-09-22 18:14:24 --> Router Class Initialized
INFO - 2023-09-22 18:14:24 --> Output Class Initialized
INFO - 2023-09-22 18:14:24 --> Security Class Initialized
DEBUG - 2023-09-22 18:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:14:24 --> Input Class Initialized
INFO - 2023-09-22 18:14:24 --> Language Class Initialized
INFO - 2023-09-22 18:14:24 --> Loader Class Initialized
INFO - 2023-09-22 18:14:24 --> Helper loaded: url_helper
INFO - 2023-09-22 18:14:24 --> Helper loaded: file_helper
INFO - 2023-09-22 18:14:24 --> Database Driver Class Initialized
INFO - 2023-09-22 18:14:24 --> Email Class Initialized
DEBUG - 2023-09-22 18:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:14:24 --> Controller Class Initialized
INFO - 2023-09-22 18:14:24 --> Model "Services_model" initialized
INFO - 2023-09-22 18:14:24 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:14:24 --> Helper loaded: form_helper
INFO - 2023-09-22 18:14:24 --> Form Validation Class Initialized
INFO - 2023-09-22 18:14:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:14:24 --> Final output sent to browser
DEBUG - 2023-09-22 18:14:24 --> Total execution time: 0.1111
INFO - 2023-09-22 18:14:44 --> Config Class Initialized
INFO - 2023-09-22 18:14:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:14:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:14:44 --> Utf8 Class Initialized
INFO - 2023-09-22 18:14:44 --> URI Class Initialized
INFO - 2023-09-22 18:14:44 --> Router Class Initialized
INFO - 2023-09-22 18:14:44 --> Output Class Initialized
INFO - 2023-09-22 18:14:44 --> Security Class Initialized
DEBUG - 2023-09-22 18:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:14:44 --> Input Class Initialized
INFO - 2023-09-22 18:14:44 --> Language Class Initialized
INFO - 2023-09-22 18:14:44 --> Loader Class Initialized
INFO - 2023-09-22 18:14:44 --> Helper loaded: url_helper
INFO - 2023-09-22 18:14:44 --> Helper loaded: file_helper
INFO - 2023-09-22 18:14:44 --> Database Driver Class Initialized
INFO - 2023-09-22 18:14:44 --> Email Class Initialized
DEBUG - 2023-09-22 18:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:14:44 --> Controller Class Initialized
INFO - 2023-09-22 18:14:44 --> Model "Services_model" initialized
INFO - 2023-09-22 18:14:44 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:14:44 --> Helper loaded: form_helper
INFO - 2023-09-22 18:14:44 --> Form Validation Class Initialized
INFO - 2023-09-22 18:14:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:14:44 --> Config Class Initialized
INFO - 2023-09-22 18:14:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:14:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:14:44 --> Utf8 Class Initialized
INFO - 2023-09-22 18:14:44 --> URI Class Initialized
INFO - 2023-09-22 18:14:44 --> Router Class Initialized
INFO - 2023-09-22 18:14:44 --> Output Class Initialized
INFO - 2023-09-22 18:14:44 --> Security Class Initialized
DEBUG - 2023-09-22 18:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:14:44 --> Input Class Initialized
INFO - 2023-09-22 18:14:44 --> Language Class Initialized
INFO - 2023-09-22 18:14:44 --> Loader Class Initialized
INFO - 2023-09-22 18:14:44 --> Helper loaded: url_helper
INFO - 2023-09-22 18:14:44 --> Helper loaded: file_helper
INFO - 2023-09-22 18:14:44 --> Database Driver Class Initialized
INFO - 2023-09-22 18:14:44 --> Email Class Initialized
DEBUG - 2023-09-22 18:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:14:44 --> Controller Class Initialized
INFO - 2023-09-22 18:14:44 --> Model "Services_model" initialized
INFO - 2023-09-22 18:14:44 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:14:44 --> Helper loaded: form_helper
INFO - 2023-09-22 18:14:44 --> Form Validation Class Initialized
INFO - 2023-09-22 18:14:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:14:44 --> Final output sent to browser
DEBUG - 2023-09-22 18:14:44 --> Total execution time: 0.1303
INFO - 2023-09-22 18:14:50 --> Config Class Initialized
INFO - 2023-09-22 18:14:50 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:14:50 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:14:50 --> Utf8 Class Initialized
INFO - 2023-09-22 18:14:50 --> URI Class Initialized
INFO - 2023-09-22 18:14:50 --> Router Class Initialized
INFO - 2023-09-22 18:14:50 --> Output Class Initialized
INFO - 2023-09-22 18:14:50 --> Security Class Initialized
DEBUG - 2023-09-22 18:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:14:50 --> Input Class Initialized
INFO - 2023-09-22 18:14:50 --> Language Class Initialized
INFO - 2023-09-22 18:14:50 --> Loader Class Initialized
INFO - 2023-09-22 18:14:50 --> Helper loaded: url_helper
INFO - 2023-09-22 18:14:50 --> Helper loaded: file_helper
INFO - 2023-09-22 18:14:50 --> Database Driver Class Initialized
INFO - 2023-09-22 18:14:50 --> Email Class Initialized
DEBUG - 2023-09-22 18:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:14:50 --> Controller Class Initialized
INFO - 2023-09-22 18:14:50 --> Model "Services_model" initialized
INFO - 2023-09-22 18:14:50 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:14:50 --> Helper loaded: form_helper
INFO - 2023-09-22 18:14:50 --> Form Validation Class Initialized
INFO - 2023-09-22 18:14:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:14:51 --> Final output sent to browser
DEBUG - 2023-09-22 18:14:51 --> Total execution time: 0.1119
INFO - 2023-09-22 18:14:51 --> Config Class Initialized
INFO - 2023-09-22 18:14:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:14:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:14:51 --> Utf8 Class Initialized
INFO - 2023-09-22 18:14:51 --> URI Class Initialized
INFO - 2023-09-22 18:14:51 --> Router Class Initialized
INFO - 2023-09-22 18:14:51 --> Output Class Initialized
INFO - 2023-09-22 18:14:51 --> Security Class Initialized
DEBUG - 2023-09-22 18:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:14:51 --> Input Class Initialized
INFO - 2023-09-22 18:14:51 --> Language Class Initialized
INFO - 2023-09-22 18:14:51 --> Loader Class Initialized
INFO - 2023-09-22 18:14:51 --> Helper loaded: url_helper
INFO - 2023-09-22 18:14:51 --> Helper loaded: file_helper
INFO - 2023-09-22 18:14:51 --> Database Driver Class Initialized
INFO - 2023-09-22 18:14:51 --> Email Class Initialized
DEBUG - 2023-09-22 18:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:14:51 --> Controller Class Initialized
INFO - 2023-09-22 18:14:51 --> Model "Services_model" initialized
INFO - 2023-09-22 18:14:51 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:14:51 --> Helper loaded: form_helper
INFO - 2023-09-22 18:14:51 --> Form Validation Class Initialized
INFO - 2023-09-22 18:14:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:14:51 --> Final output sent to browser
DEBUG - 2023-09-22 18:14:51 --> Total execution time: 0.1556
INFO - 2023-09-22 18:15:22 --> Config Class Initialized
INFO - 2023-09-22 18:15:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:15:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:15:22 --> Utf8 Class Initialized
INFO - 2023-09-22 18:15:22 --> URI Class Initialized
INFO - 2023-09-22 18:15:22 --> Router Class Initialized
INFO - 2023-09-22 18:15:22 --> Output Class Initialized
INFO - 2023-09-22 18:15:22 --> Security Class Initialized
DEBUG - 2023-09-22 18:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:15:22 --> Input Class Initialized
INFO - 2023-09-22 18:15:22 --> Language Class Initialized
INFO - 2023-09-22 18:15:22 --> Loader Class Initialized
INFO - 2023-09-22 18:15:22 --> Helper loaded: url_helper
INFO - 2023-09-22 18:15:22 --> Helper loaded: file_helper
INFO - 2023-09-22 18:15:22 --> Database Driver Class Initialized
INFO - 2023-09-22 18:15:22 --> Email Class Initialized
DEBUG - 2023-09-22 18:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:15:22 --> Controller Class Initialized
INFO - 2023-09-22 18:15:22 --> Model "Services_model" initialized
INFO - 2023-09-22 18:15:22 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:15:22 --> Helper loaded: form_helper
INFO - 2023-09-22 18:15:22 --> Form Validation Class Initialized
INFO - 2023-09-22 18:15:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:15:22 --> Config Class Initialized
INFO - 2023-09-22 18:15:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:15:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:15:22 --> Utf8 Class Initialized
INFO - 2023-09-22 18:15:22 --> URI Class Initialized
INFO - 2023-09-22 18:15:22 --> Router Class Initialized
INFO - 2023-09-22 18:15:22 --> Output Class Initialized
INFO - 2023-09-22 18:15:22 --> Security Class Initialized
DEBUG - 2023-09-22 18:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:15:22 --> Input Class Initialized
INFO - 2023-09-22 18:15:22 --> Language Class Initialized
INFO - 2023-09-22 18:15:22 --> Loader Class Initialized
INFO - 2023-09-22 18:15:22 --> Helper loaded: url_helper
INFO - 2023-09-22 18:15:22 --> Helper loaded: file_helper
INFO - 2023-09-22 18:15:23 --> Database Driver Class Initialized
INFO - 2023-09-22 18:15:23 --> Email Class Initialized
DEBUG - 2023-09-22 18:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:15:23 --> Controller Class Initialized
INFO - 2023-09-22 18:15:23 --> Model "Services_model" initialized
INFO - 2023-09-22 18:15:23 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:15:23 --> Helper loaded: form_helper
INFO - 2023-09-22 18:15:23 --> Form Validation Class Initialized
INFO - 2023-09-22 18:15:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:15:23 --> Final output sent to browser
DEBUG - 2023-09-22 18:15:23 --> Total execution time: 0.1208
INFO - 2023-09-22 18:15:24 --> Config Class Initialized
INFO - 2023-09-22 18:15:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:15:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:15:24 --> Utf8 Class Initialized
INFO - 2023-09-22 18:15:24 --> URI Class Initialized
INFO - 2023-09-22 18:15:24 --> Router Class Initialized
INFO - 2023-09-22 18:15:24 --> Output Class Initialized
INFO - 2023-09-22 18:15:24 --> Security Class Initialized
DEBUG - 2023-09-22 18:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:15:24 --> Input Class Initialized
INFO - 2023-09-22 18:15:24 --> Language Class Initialized
INFO - 2023-09-22 18:15:24 --> Loader Class Initialized
INFO - 2023-09-22 18:15:24 --> Helper loaded: url_helper
INFO - 2023-09-22 18:15:24 --> Helper loaded: file_helper
INFO - 2023-09-22 18:15:24 --> Database Driver Class Initialized
INFO - 2023-09-22 18:15:24 --> Email Class Initialized
DEBUG - 2023-09-22 18:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:15:24 --> Controller Class Initialized
INFO - 2023-09-22 18:15:24 --> Model "Services_model" initialized
INFO - 2023-09-22 18:15:24 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:15:24 --> Helper loaded: form_helper
INFO - 2023-09-22 18:15:24 --> Form Validation Class Initialized
INFO - 2023-09-22 18:15:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:15:24 --> Final output sent to browser
DEBUG - 2023-09-22 18:15:24 --> Total execution time: 0.1038
INFO - 2023-09-22 18:15:26 --> Config Class Initialized
INFO - 2023-09-22 18:15:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:15:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:15:26 --> Utf8 Class Initialized
INFO - 2023-09-22 18:15:26 --> URI Class Initialized
INFO - 2023-09-22 18:15:26 --> Router Class Initialized
INFO - 2023-09-22 18:15:26 --> Output Class Initialized
INFO - 2023-09-22 18:15:26 --> Security Class Initialized
DEBUG - 2023-09-22 18:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:15:26 --> Input Class Initialized
INFO - 2023-09-22 18:15:26 --> Language Class Initialized
INFO - 2023-09-22 18:15:26 --> Loader Class Initialized
INFO - 2023-09-22 18:15:26 --> Helper loaded: url_helper
INFO - 2023-09-22 18:15:26 --> Helper loaded: file_helper
INFO - 2023-09-22 18:15:26 --> Database Driver Class Initialized
INFO - 2023-09-22 18:15:26 --> Email Class Initialized
DEBUG - 2023-09-22 18:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:15:26 --> Controller Class Initialized
INFO - 2023-09-22 18:15:26 --> Model "Services_model" initialized
INFO - 2023-09-22 18:15:26 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:15:26 --> Helper loaded: form_helper
INFO - 2023-09-22 18:15:26 --> Form Validation Class Initialized
INFO - 2023-09-22 18:15:26 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:15:26 --> Final output sent to browser
DEBUG - 2023-09-22 18:15:26 --> Total execution time: 0.0957
INFO - 2023-09-22 18:15:44 --> Config Class Initialized
INFO - 2023-09-22 18:15:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:15:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:15:44 --> Utf8 Class Initialized
INFO - 2023-09-22 18:15:44 --> URI Class Initialized
INFO - 2023-09-22 18:15:44 --> Router Class Initialized
INFO - 2023-09-22 18:15:44 --> Output Class Initialized
INFO - 2023-09-22 18:15:44 --> Security Class Initialized
DEBUG - 2023-09-22 18:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:15:45 --> Input Class Initialized
INFO - 2023-09-22 18:15:45 --> Language Class Initialized
INFO - 2023-09-22 18:15:45 --> Loader Class Initialized
INFO - 2023-09-22 18:15:45 --> Helper loaded: url_helper
INFO - 2023-09-22 18:15:45 --> Helper loaded: file_helper
INFO - 2023-09-22 18:15:45 --> Database Driver Class Initialized
INFO - 2023-09-22 18:15:45 --> Email Class Initialized
DEBUG - 2023-09-22 18:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:15:45 --> Controller Class Initialized
INFO - 2023-09-22 18:15:45 --> Model "Services_model" initialized
INFO - 2023-09-22 18:15:45 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:15:45 --> Helper loaded: form_helper
INFO - 2023-09-22 18:15:45 --> Form Validation Class Initialized
INFO - 2023-09-22 18:15:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:15:45 --> Config Class Initialized
INFO - 2023-09-22 18:15:45 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:15:45 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:15:45 --> Utf8 Class Initialized
INFO - 2023-09-22 18:15:45 --> URI Class Initialized
INFO - 2023-09-22 18:15:45 --> Router Class Initialized
INFO - 2023-09-22 18:15:45 --> Output Class Initialized
INFO - 2023-09-22 18:15:45 --> Security Class Initialized
DEBUG - 2023-09-22 18:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:15:45 --> Input Class Initialized
INFO - 2023-09-22 18:15:45 --> Language Class Initialized
INFO - 2023-09-22 18:15:45 --> Loader Class Initialized
INFO - 2023-09-22 18:15:45 --> Helper loaded: url_helper
INFO - 2023-09-22 18:15:45 --> Helper loaded: file_helper
INFO - 2023-09-22 18:15:45 --> Database Driver Class Initialized
INFO - 2023-09-22 18:15:45 --> Email Class Initialized
DEBUG - 2023-09-22 18:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:15:45 --> Controller Class Initialized
INFO - 2023-09-22 18:15:45 --> Model "Services_model" initialized
INFO - 2023-09-22 18:15:45 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:15:45 --> Helper loaded: form_helper
INFO - 2023-09-22 18:15:45 --> Form Validation Class Initialized
INFO - 2023-09-22 18:15:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:15:45 --> Final output sent to browser
DEBUG - 2023-09-22 18:15:45 --> Total execution time: 0.1140
INFO - 2023-09-22 18:16:02 --> Config Class Initialized
INFO - 2023-09-22 18:16:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:16:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:16:02 --> Utf8 Class Initialized
INFO - 2023-09-22 18:16:02 --> URI Class Initialized
INFO - 2023-09-22 18:16:02 --> Router Class Initialized
INFO - 2023-09-22 18:16:02 --> Output Class Initialized
INFO - 2023-09-22 18:16:02 --> Security Class Initialized
DEBUG - 2023-09-22 18:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:16:02 --> Input Class Initialized
INFO - 2023-09-22 18:16:02 --> Language Class Initialized
INFO - 2023-09-22 18:16:02 --> Loader Class Initialized
INFO - 2023-09-22 18:16:02 --> Helper loaded: url_helper
INFO - 2023-09-22 18:16:02 --> Helper loaded: file_helper
INFO - 2023-09-22 18:16:02 --> Database Driver Class Initialized
INFO - 2023-09-22 18:16:02 --> Email Class Initialized
DEBUG - 2023-09-22 18:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:16:02 --> Controller Class Initialized
INFO - 2023-09-22 18:16:02 --> Model "Services_model" initialized
INFO - 2023-09-22 18:16:02 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:16:02 --> Helper loaded: form_helper
INFO - 2023-09-22 18:16:02 --> Form Validation Class Initialized
INFO - 2023-09-22 18:16:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:16:02 --> Final output sent to browser
DEBUG - 2023-09-22 18:16:02 --> Total execution time: 0.1040
INFO - 2023-09-22 18:16:03 --> Config Class Initialized
INFO - 2023-09-22 18:16:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:16:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:16:03 --> Utf8 Class Initialized
INFO - 2023-09-22 18:16:03 --> URI Class Initialized
INFO - 2023-09-22 18:16:03 --> Router Class Initialized
INFO - 2023-09-22 18:16:03 --> Output Class Initialized
INFO - 2023-09-22 18:16:03 --> Security Class Initialized
DEBUG - 2023-09-22 18:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:16:03 --> Input Class Initialized
INFO - 2023-09-22 18:16:03 --> Language Class Initialized
INFO - 2023-09-22 18:16:03 --> Loader Class Initialized
INFO - 2023-09-22 18:16:03 --> Helper loaded: url_helper
INFO - 2023-09-22 18:16:03 --> Helper loaded: file_helper
INFO - 2023-09-22 18:16:03 --> Database Driver Class Initialized
INFO - 2023-09-22 18:16:03 --> Email Class Initialized
DEBUG - 2023-09-22 18:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:16:03 --> Controller Class Initialized
INFO - 2023-09-22 18:16:03 --> Model "Services_model" initialized
INFO - 2023-09-22 18:16:03 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:16:03 --> Helper loaded: form_helper
INFO - 2023-09-22 18:16:03 --> Form Validation Class Initialized
INFO - 2023-09-22 18:16:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:16:03 --> Final output sent to browser
DEBUG - 2023-09-22 18:16:03 --> Total execution time: 0.1209
INFO - 2023-09-22 18:16:22 --> Config Class Initialized
INFO - 2023-09-22 18:16:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:16:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:16:22 --> Utf8 Class Initialized
INFO - 2023-09-22 18:16:22 --> URI Class Initialized
INFO - 2023-09-22 18:16:22 --> Router Class Initialized
INFO - 2023-09-22 18:16:22 --> Output Class Initialized
INFO - 2023-09-22 18:16:22 --> Security Class Initialized
DEBUG - 2023-09-22 18:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:16:22 --> Input Class Initialized
INFO - 2023-09-22 18:16:22 --> Language Class Initialized
INFO - 2023-09-22 18:16:22 --> Loader Class Initialized
INFO - 2023-09-22 18:16:22 --> Helper loaded: url_helper
INFO - 2023-09-22 18:16:22 --> Helper loaded: file_helper
INFO - 2023-09-22 18:16:22 --> Database Driver Class Initialized
INFO - 2023-09-22 18:16:22 --> Email Class Initialized
DEBUG - 2023-09-22 18:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:16:22 --> Controller Class Initialized
INFO - 2023-09-22 18:16:22 --> Model "Services_model" initialized
INFO - 2023-09-22 18:16:22 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:16:22 --> Helper loaded: form_helper
INFO - 2023-09-22 18:16:22 --> Form Validation Class Initialized
INFO - 2023-09-22 18:16:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:16:22 --> Config Class Initialized
INFO - 2023-09-22 18:16:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:16:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:16:22 --> Utf8 Class Initialized
INFO - 2023-09-22 18:16:22 --> URI Class Initialized
INFO - 2023-09-22 18:16:22 --> Router Class Initialized
INFO - 2023-09-22 18:16:22 --> Output Class Initialized
INFO - 2023-09-22 18:16:22 --> Security Class Initialized
DEBUG - 2023-09-22 18:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:16:22 --> Input Class Initialized
INFO - 2023-09-22 18:16:22 --> Language Class Initialized
INFO - 2023-09-22 18:16:22 --> Loader Class Initialized
INFO - 2023-09-22 18:16:22 --> Helper loaded: url_helper
INFO - 2023-09-22 18:16:22 --> Helper loaded: file_helper
INFO - 2023-09-22 18:16:22 --> Database Driver Class Initialized
INFO - 2023-09-22 18:16:22 --> Email Class Initialized
DEBUG - 2023-09-22 18:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:16:22 --> Controller Class Initialized
INFO - 2023-09-22 18:16:22 --> Model "Services_model" initialized
INFO - 2023-09-22 18:16:22 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:16:22 --> Helper loaded: form_helper
INFO - 2023-09-22 18:16:22 --> Form Validation Class Initialized
INFO - 2023-09-22 18:16:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:16:22 --> Final output sent to browser
DEBUG - 2023-09-22 18:16:22 --> Total execution time: 0.1158
INFO - 2023-09-22 18:16:29 --> Config Class Initialized
INFO - 2023-09-22 18:16:29 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:16:29 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:16:29 --> Utf8 Class Initialized
INFO - 2023-09-22 18:16:29 --> URI Class Initialized
INFO - 2023-09-22 18:16:29 --> Router Class Initialized
INFO - 2023-09-22 18:16:29 --> Output Class Initialized
INFO - 2023-09-22 18:16:29 --> Security Class Initialized
DEBUG - 2023-09-22 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:16:29 --> Input Class Initialized
INFO - 2023-09-22 18:16:29 --> Language Class Initialized
INFO - 2023-09-22 18:16:30 --> Loader Class Initialized
INFO - 2023-09-22 18:16:30 --> Helper loaded: url_helper
INFO - 2023-09-22 18:16:30 --> Helper loaded: file_helper
INFO - 2023-09-22 18:16:30 --> Database Driver Class Initialized
INFO - 2023-09-22 18:16:30 --> Email Class Initialized
DEBUG - 2023-09-22 18:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:16:30 --> Controller Class Initialized
INFO - 2023-09-22 18:16:30 --> Model "Services_model" initialized
INFO - 2023-09-22 18:16:30 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:16:30 --> Helper loaded: form_helper
INFO - 2023-09-22 18:16:30 --> Form Validation Class Initialized
INFO - 2023-09-22 18:16:30 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:16:30 --> Final output sent to browser
DEBUG - 2023-09-22 18:16:30 --> Total execution time: 0.1012
INFO - 2023-09-22 18:16:30 --> Config Class Initialized
INFO - 2023-09-22 18:16:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:16:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:16:30 --> Utf8 Class Initialized
INFO - 2023-09-22 18:16:30 --> URI Class Initialized
INFO - 2023-09-22 18:16:30 --> Router Class Initialized
INFO - 2023-09-22 18:16:30 --> Output Class Initialized
INFO - 2023-09-22 18:16:30 --> Security Class Initialized
DEBUG - 2023-09-22 18:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:16:30 --> Input Class Initialized
INFO - 2023-09-22 18:16:30 --> Language Class Initialized
INFO - 2023-09-22 18:16:30 --> Loader Class Initialized
INFO - 2023-09-22 18:16:30 --> Helper loaded: url_helper
INFO - 2023-09-22 18:16:30 --> Helper loaded: file_helper
INFO - 2023-09-22 18:16:30 --> Database Driver Class Initialized
INFO - 2023-09-22 18:16:30 --> Email Class Initialized
DEBUG - 2023-09-22 18:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:16:30 --> Controller Class Initialized
INFO - 2023-09-22 18:16:30 --> Model "Services_model" initialized
INFO - 2023-09-22 18:16:30 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:16:30 --> Helper loaded: form_helper
INFO - 2023-09-22 18:16:30 --> Form Validation Class Initialized
INFO - 2023-09-22 18:16:30 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:16:30 --> Final output sent to browser
DEBUG - 2023-09-22 18:16:30 --> Total execution time: 0.1227
INFO - 2023-09-22 18:16:50 --> Config Class Initialized
INFO - 2023-09-22 18:16:50 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:16:50 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:16:50 --> Utf8 Class Initialized
INFO - 2023-09-22 18:16:50 --> URI Class Initialized
INFO - 2023-09-22 18:16:50 --> Router Class Initialized
INFO - 2023-09-22 18:16:50 --> Output Class Initialized
INFO - 2023-09-22 18:16:50 --> Security Class Initialized
DEBUG - 2023-09-22 18:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:16:50 --> Input Class Initialized
INFO - 2023-09-22 18:16:50 --> Language Class Initialized
INFO - 2023-09-22 18:16:50 --> Loader Class Initialized
INFO - 2023-09-22 18:16:50 --> Helper loaded: url_helper
INFO - 2023-09-22 18:16:50 --> Helper loaded: file_helper
INFO - 2023-09-22 18:16:50 --> Database Driver Class Initialized
INFO - 2023-09-22 18:16:50 --> Email Class Initialized
DEBUG - 2023-09-22 18:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:16:50 --> Controller Class Initialized
INFO - 2023-09-22 18:16:50 --> Model "Services_model" initialized
INFO - 2023-09-22 18:16:50 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:16:50 --> Helper loaded: form_helper
INFO - 2023-09-22 18:16:50 --> Form Validation Class Initialized
INFO - 2023-09-22 18:16:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:16:50 --> Config Class Initialized
INFO - 2023-09-22 18:16:50 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:16:50 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:16:50 --> Utf8 Class Initialized
INFO - 2023-09-22 18:16:50 --> URI Class Initialized
INFO - 2023-09-22 18:16:50 --> Router Class Initialized
INFO - 2023-09-22 18:16:50 --> Output Class Initialized
INFO - 2023-09-22 18:16:50 --> Security Class Initialized
DEBUG - 2023-09-22 18:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:16:50 --> Input Class Initialized
INFO - 2023-09-22 18:16:50 --> Language Class Initialized
INFO - 2023-09-22 18:16:50 --> Loader Class Initialized
INFO - 2023-09-22 18:16:50 --> Helper loaded: url_helper
INFO - 2023-09-22 18:16:50 --> Helper loaded: file_helper
INFO - 2023-09-22 18:16:50 --> Database Driver Class Initialized
INFO - 2023-09-22 18:16:50 --> Email Class Initialized
DEBUG - 2023-09-22 18:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:16:50 --> Controller Class Initialized
INFO - 2023-09-22 18:16:50 --> Model "Services_model" initialized
INFO - 2023-09-22 18:16:50 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:16:50 --> Helper loaded: form_helper
INFO - 2023-09-22 18:16:50 --> Form Validation Class Initialized
INFO - 2023-09-22 18:16:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:16:50 --> Final output sent to browser
DEBUG - 2023-09-22 18:16:50 --> Total execution time: 0.1001
INFO - 2023-09-22 18:16:57 --> Config Class Initialized
INFO - 2023-09-22 18:16:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:16:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:16:57 --> Utf8 Class Initialized
INFO - 2023-09-22 18:16:57 --> URI Class Initialized
INFO - 2023-09-22 18:16:57 --> Router Class Initialized
INFO - 2023-09-22 18:16:57 --> Output Class Initialized
INFO - 2023-09-22 18:16:57 --> Security Class Initialized
DEBUG - 2023-09-22 18:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:16:57 --> Input Class Initialized
INFO - 2023-09-22 18:16:57 --> Language Class Initialized
INFO - 2023-09-22 18:16:57 --> Loader Class Initialized
INFO - 2023-09-22 18:16:57 --> Helper loaded: url_helper
INFO - 2023-09-22 18:16:57 --> Helper loaded: file_helper
INFO - 2023-09-22 18:16:57 --> Database Driver Class Initialized
INFO - 2023-09-22 18:16:57 --> Email Class Initialized
DEBUG - 2023-09-22 18:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:16:57 --> Controller Class Initialized
INFO - 2023-09-22 18:16:57 --> Model "Services_model" initialized
INFO - 2023-09-22 18:16:57 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:16:57 --> Helper loaded: form_helper
INFO - 2023-09-22 18:16:57 --> Form Validation Class Initialized
INFO - 2023-09-22 18:16:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:16:57 --> Final output sent to browser
DEBUG - 2023-09-22 18:16:57 --> Total execution time: 0.2462
INFO - 2023-09-22 18:16:58 --> Config Class Initialized
INFO - 2023-09-22 18:16:58 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:16:58 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:16:58 --> Utf8 Class Initialized
INFO - 2023-09-22 18:16:58 --> URI Class Initialized
INFO - 2023-09-22 18:16:58 --> Router Class Initialized
INFO - 2023-09-22 18:16:58 --> Output Class Initialized
INFO - 2023-09-22 18:16:58 --> Security Class Initialized
DEBUG - 2023-09-22 18:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:16:58 --> Input Class Initialized
INFO - 2023-09-22 18:16:58 --> Language Class Initialized
INFO - 2023-09-22 18:16:58 --> Loader Class Initialized
INFO - 2023-09-22 18:16:58 --> Helper loaded: url_helper
INFO - 2023-09-22 18:16:58 --> Helper loaded: file_helper
INFO - 2023-09-22 18:16:59 --> Database Driver Class Initialized
INFO - 2023-09-22 18:16:59 --> Email Class Initialized
DEBUG - 2023-09-22 18:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:16:59 --> Controller Class Initialized
INFO - 2023-09-22 18:16:59 --> Model "Services_model" initialized
INFO - 2023-09-22 18:16:59 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:16:59 --> Helper loaded: form_helper
INFO - 2023-09-22 18:16:59 --> Form Validation Class Initialized
INFO - 2023-09-22 18:16:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:16:59 --> Final output sent to browser
DEBUG - 2023-09-22 18:16:59 --> Total execution time: 0.1095
INFO - 2023-09-22 18:17:18 --> Config Class Initialized
INFO - 2023-09-22 18:17:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:17:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:17:18 --> Utf8 Class Initialized
INFO - 2023-09-22 18:17:18 --> URI Class Initialized
INFO - 2023-09-22 18:17:18 --> Router Class Initialized
INFO - 2023-09-22 18:17:18 --> Output Class Initialized
INFO - 2023-09-22 18:17:18 --> Security Class Initialized
DEBUG - 2023-09-22 18:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:17:18 --> Input Class Initialized
INFO - 2023-09-22 18:17:18 --> Language Class Initialized
INFO - 2023-09-22 18:17:18 --> Loader Class Initialized
INFO - 2023-09-22 18:17:18 --> Helper loaded: url_helper
INFO - 2023-09-22 18:17:18 --> Helper loaded: file_helper
INFO - 2023-09-22 18:17:18 --> Database Driver Class Initialized
INFO - 2023-09-22 18:17:18 --> Email Class Initialized
DEBUG - 2023-09-22 18:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:17:18 --> Controller Class Initialized
INFO - 2023-09-22 18:17:18 --> Model "Services_model" initialized
INFO - 2023-09-22 18:17:18 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:17:18 --> Helper loaded: form_helper
INFO - 2023-09-22 18:17:18 --> Form Validation Class Initialized
INFO - 2023-09-22 18:17:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:17:18 --> Config Class Initialized
INFO - 2023-09-22 18:17:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:17:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:17:18 --> Utf8 Class Initialized
INFO - 2023-09-22 18:17:18 --> URI Class Initialized
INFO - 2023-09-22 18:17:18 --> Router Class Initialized
INFO - 2023-09-22 18:17:18 --> Output Class Initialized
INFO - 2023-09-22 18:17:18 --> Security Class Initialized
DEBUG - 2023-09-22 18:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:17:18 --> Input Class Initialized
INFO - 2023-09-22 18:17:18 --> Language Class Initialized
INFO - 2023-09-22 18:17:18 --> Loader Class Initialized
INFO - 2023-09-22 18:17:18 --> Helper loaded: url_helper
INFO - 2023-09-22 18:17:18 --> Helper loaded: file_helper
INFO - 2023-09-22 18:17:18 --> Database Driver Class Initialized
INFO - 2023-09-22 18:17:18 --> Email Class Initialized
DEBUG - 2023-09-22 18:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:17:18 --> Controller Class Initialized
INFO - 2023-09-22 18:17:18 --> Model "Services_model" initialized
INFO - 2023-09-22 18:17:18 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:17:18 --> Helper loaded: form_helper
INFO - 2023-09-22 18:17:18 --> Form Validation Class Initialized
INFO - 2023-09-22 18:17:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:17:18 --> Final output sent to browser
DEBUG - 2023-09-22 18:17:18 --> Total execution time: 0.1061
INFO - 2023-09-22 18:17:32 --> Config Class Initialized
INFO - 2023-09-22 18:17:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:17:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:17:32 --> Utf8 Class Initialized
INFO - 2023-09-22 18:17:32 --> URI Class Initialized
DEBUG - 2023-09-22 18:17:32 --> No URI present. Default controller set.
INFO - 2023-09-22 18:17:32 --> Router Class Initialized
INFO - 2023-09-22 18:17:32 --> Output Class Initialized
INFO - 2023-09-22 18:17:32 --> Security Class Initialized
DEBUG - 2023-09-22 18:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:17:32 --> Input Class Initialized
INFO - 2023-09-22 18:17:32 --> Language Class Initialized
INFO - 2023-09-22 18:17:32 --> Loader Class Initialized
INFO - 2023-09-22 18:17:32 --> Helper loaded: url_helper
INFO - 2023-09-22 18:17:32 --> Helper loaded: file_helper
INFO - 2023-09-22 18:17:32 --> Database Driver Class Initialized
INFO - 2023-09-22 18:17:32 --> Email Class Initialized
DEBUG - 2023-09-22 18:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:17:32 --> Controller Class Initialized
INFO - 2023-09-22 18:17:32 --> Model "Contact_model" initialized
INFO - 2023-09-22 18:17:32 --> Model "Home_model" initialized
INFO - 2023-09-22 18:17:32 --> Helper loaded: download_helper
INFO - 2023-09-22 18:17:32 --> Helper loaded: form_helper
INFO - 2023-09-22 18:17:32 --> Form Validation Class Initialized
INFO - 2023-09-22 18:17:32 --> Helper loaded: custom_helper
INFO - 2023-09-22 18:17:32 --> Model "Social_media_model" initialized
INFO - 2023-09-22 18:17:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-22 18:17:32 --> Final output sent to browser
DEBUG - 2023-09-22 18:17:32 --> Total execution time: 0.1384
INFO - 2023-09-22 18:17:39 --> Config Class Initialized
INFO - 2023-09-22 18:17:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:17:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:17:39 --> Utf8 Class Initialized
INFO - 2023-09-22 18:17:39 --> URI Class Initialized
INFO - 2023-09-22 18:17:39 --> Router Class Initialized
INFO - 2023-09-22 18:17:39 --> Output Class Initialized
INFO - 2023-09-22 18:17:39 --> Security Class Initialized
DEBUG - 2023-09-22 18:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:17:39 --> Input Class Initialized
INFO - 2023-09-22 18:17:39 --> Language Class Initialized
INFO - 2023-09-22 18:17:39 --> Loader Class Initialized
INFO - 2023-09-22 18:17:39 --> Helper loaded: url_helper
INFO - 2023-09-22 18:17:39 --> Helper loaded: file_helper
INFO - 2023-09-22 18:17:39 --> Database Driver Class Initialized
INFO - 2023-09-22 18:17:39 --> Email Class Initialized
DEBUG - 2023-09-22 18:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:17:39 --> Controller Class Initialized
INFO - 2023-09-22 18:17:39 --> Model "Contact_model" initialized
INFO - 2023-09-22 18:17:39 --> Model "Home_model" initialized
INFO - 2023-09-22 18:17:39 --> Helper loaded: download_helper
INFO - 2023-09-22 18:17:39 --> Helper loaded: form_helper
INFO - 2023-09-22 18:17:39 --> Form Validation Class Initialized
INFO - 2023-09-22 18:17:39 --> Helper loaded: custom_helper
INFO - 2023-09-22 18:17:39 --> Model "Social_media_model" initialized
INFO - 2023-09-22 18:17:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 18:17:39 --> Final output sent to browser
DEBUG - 2023-09-22 18:17:39 --> Total execution time: 0.1151
INFO - 2023-09-22 18:18:29 --> Config Class Initialized
INFO - 2023-09-22 18:18:29 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:18:29 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:18:29 --> Utf8 Class Initialized
INFO - 2023-09-22 18:18:29 --> URI Class Initialized
INFO - 2023-09-22 18:18:29 --> Router Class Initialized
INFO - 2023-09-22 18:18:29 --> Output Class Initialized
INFO - 2023-09-22 18:18:29 --> Security Class Initialized
DEBUG - 2023-09-22 18:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:18:29 --> Input Class Initialized
INFO - 2023-09-22 18:18:29 --> Language Class Initialized
INFO - 2023-09-22 18:18:29 --> Loader Class Initialized
INFO - 2023-09-22 18:18:29 --> Helper loaded: url_helper
INFO - 2023-09-22 18:18:29 --> Helper loaded: file_helper
INFO - 2023-09-22 18:18:29 --> Database Driver Class Initialized
INFO - 2023-09-22 18:18:29 --> Email Class Initialized
DEBUG - 2023-09-22 18:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:18:29 --> Controller Class Initialized
INFO - 2023-09-22 18:18:29 --> Model "Services_model" initialized
INFO - 2023-09-22 18:18:29 --> Helper loaded: form_helper
INFO - 2023-09-22 18:18:29 --> Form Validation Class Initialized
INFO - 2023-09-22 18:18:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-22 18:18:30 --> Final output sent to browser
DEBUG - 2023-09-22 18:18:30 --> Total execution time: 0.0846
INFO - 2023-09-22 18:22:16 --> Config Class Initialized
INFO - 2023-09-22 18:22:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:22:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:22:16 --> Utf8 Class Initialized
INFO - 2023-09-22 18:22:16 --> URI Class Initialized
INFO - 2023-09-22 18:22:16 --> Router Class Initialized
INFO - 2023-09-22 18:22:16 --> Output Class Initialized
INFO - 2023-09-22 18:22:16 --> Security Class Initialized
DEBUG - 2023-09-22 18:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:22:16 --> Input Class Initialized
INFO - 2023-09-22 18:22:16 --> Language Class Initialized
INFO - 2023-09-22 18:22:16 --> Loader Class Initialized
INFO - 2023-09-22 18:22:17 --> Helper loaded: url_helper
INFO - 2023-09-22 18:22:17 --> Helper loaded: file_helper
INFO - 2023-09-22 18:22:17 --> Database Driver Class Initialized
INFO - 2023-09-22 18:22:17 --> Email Class Initialized
DEBUG - 2023-09-22 18:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:22:17 --> Controller Class Initialized
INFO - 2023-09-22 18:22:17 --> Model "Services_model" initialized
INFO - 2023-09-22 18:22:17 --> Helper loaded: form_helper
INFO - 2023-09-22 18:22:17 --> Form Validation Class Initialized
INFO - 2023-09-22 18:22:17 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-09-22 18:22:17 --> Final output sent to browser
DEBUG - 2023-09-22 18:22:17 --> Total execution time: 0.1220
INFO - 2023-09-22 18:25:14 --> Config Class Initialized
INFO - 2023-09-22 18:25:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:25:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:25:14 --> Utf8 Class Initialized
INFO - 2023-09-22 18:25:14 --> URI Class Initialized
INFO - 2023-09-22 18:25:14 --> Router Class Initialized
INFO - 2023-09-22 18:25:14 --> Output Class Initialized
INFO - 2023-09-22 18:25:14 --> Security Class Initialized
DEBUG - 2023-09-22 18:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:25:14 --> Input Class Initialized
INFO - 2023-09-22 18:25:14 --> Language Class Initialized
INFO - 2023-09-22 18:25:14 --> Loader Class Initialized
INFO - 2023-09-22 18:25:14 --> Helper loaded: url_helper
INFO - 2023-09-22 18:25:14 --> Helper loaded: file_helper
INFO - 2023-09-22 18:25:14 --> Database Driver Class Initialized
INFO - 2023-09-22 18:25:14 --> Email Class Initialized
DEBUG - 2023-09-22 18:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:25:14 --> Controller Class Initialized
INFO - 2023-09-22 18:25:14 --> Model "Services_model" initialized
INFO - 2023-09-22 18:25:14 --> Helper loaded: form_helper
INFO - 2023-09-22 18:25:14 --> Form Validation Class Initialized
INFO - 2023-09-22 18:25:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:25:15 --> Config Class Initialized
INFO - 2023-09-22 18:25:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:25:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:25:15 --> Utf8 Class Initialized
INFO - 2023-09-22 18:25:15 --> URI Class Initialized
INFO - 2023-09-22 18:25:15 --> Router Class Initialized
INFO - 2023-09-22 18:25:15 --> Output Class Initialized
INFO - 2023-09-22 18:25:15 --> Security Class Initialized
DEBUG - 2023-09-22 18:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:25:15 --> Input Class Initialized
INFO - 2023-09-22 18:25:15 --> Language Class Initialized
INFO - 2023-09-22 18:25:15 --> Loader Class Initialized
INFO - 2023-09-22 18:25:15 --> Helper loaded: url_helper
INFO - 2023-09-22 18:25:15 --> Helper loaded: file_helper
INFO - 2023-09-22 18:25:15 --> Database Driver Class Initialized
INFO - 2023-09-22 18:25:15 --> Email Class Initialized
DEBUG - 2023-09-22 18:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:25:15 --> Controller Class Initialized
INFO - 2023-09-22 18:25:15 --> Model "Services_model" initialized
INFO - 2023-09-22 18:25:15 --> Helper loaded: form_helper
INFO - 2023-09-22 18:25:15 --> Form Validation Class Initialized
INFO - 2023-09-22 18:25:15 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-22 18:25:15 --> Final output sent to browser
DEBUG - 2023-09-22 18:25:15 --> Total execution time: 0.0643
INFO - 2023-09-22 18:25:27 --> Config Class Initialized
INFO - 2023-09-22 18:25:27 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:25:27 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:25:27 --> Utf8 Class Initialized
INFO - 2023-09-22 18:25:27 --> URI Class Initialized
INFO - 2023-09-22 18:25:27 --> Router Class Initialized
INFO - 2023-09-22 18:25:27 --> Output Class Initialized
INFO - 2023-09-22 18:25:27 --> Security Class Initialized
DEBUG - 2023-09-22 18:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:25:27 --> Input Class Initialized
INFO - 2023-09-22 18:25:27 --> Language Class Initialized
INFO - 2023-09-22 18:25:27 --> Loader Class Initialized
INFO - 2023-09-22 18:25:27 --> Helper loaded: url_helper
INFO - 2023-09-22 18:25:27 --> Helper loaded: file_helper
INFO - 2023-09-22 18:25:27 --> Database Driver Class Initialized
INFO - 2023-09-22 18:25:27 --> Email Class Initialized
DEBUG - 2023-09-22 18:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:25:27 --> Controller Class Initialized
INFO - 2023-09-22 18:25:27 --> Model "Services_model" initialized
INFO - 2023-09-22 18:25:27 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:25:27 --> Helper loaded: form_helper
INFO - 2023-09-22 18:25:27 --> Form Validation Class Initialized
INFO - 2023-09-22 18:25:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:25:28 --> Final output sent to browser
DEBUG - 2023-09-22 18:25:28 --> Total execution time: 0.1076
INFO - 2023-09-22 18:25:41 --> Config Class Initialized
INFO - 2023-09-22 18:25:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:25:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:25:41 --> Utf8 Class Initialized
INFO - 2023-09-22 18:25:41 --> URI Class Initialized
INFO - 2023-09-22 18:25:41 --> Router Class Initialized
INFO - 2023-09-22 18:25:41 --> Output Class Initialized
INFO - 2023-09-22 18:25:41 --> Security Class Initialized
DEBUG - 2023-09-22 18:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:25:41 --> Input Class Initialized
INFO - 2023-09-22 18:25:41 --> Language Class Initialized
INFO - 2023-09-22 18:25:41 --> Loader Class Initialized
INFO - 2023-09-22 18:25:41 --> Helper loaded: url_helper
INFO - 2023-09-22 18:25:41 --> Helper loaded: file_helper
INFO - 2023-09-22 18:25:41 --> Database Driver Class Initialized
INFO - 2023-09-22 18:25:41 --> Email Class Initialized
DEBUG - 2023-09-22 18:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:25:41 --> Controller Class Initialized
INFO - 2023-09-22 18:25:41 --> Model "Services_model" initialized
INFO - 2023-09-22 18:25:41 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:25:41 --> Helper loaded: form_helper
INFO - 2023-09-22 18:25:41 --> Form Validation Class Initialized
INFO - 2023-09-22 18:25:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:25:41 --> Final output sent to browser
DEBUG - 2023-09-22 18:25:41 --> Total execution time: 0.0992
INFO - 2023-09-22 18:25:41 --> Config Class Initialized
INFO - 2023-09-22 18:25:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:25:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:25:41 --> Utf8 Class Initialized
INFO - 2023-09-22 18:25:41 --> URI Class Initialized
INFO - 2023-09-22 18:25:41 --> Router Class Initialized
INFO - 2023-09-22 18:25:41 --> Output Class Initialized
INFO - 2023-09-22 18:25:41 --> Security Class Initialized
DEBUG - 2023-09-22 18:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:25:41 --> Input Class Initialized
INFO - 2023-09-22 18:25:41 --> Language Class Initialized
INFO - 2023-09-22 18:25:41 --> Loader Class Initialized
INFO - 2023-09-22 18:25:41 --> Helper loaded: url_helper
INFO - 2023-09-22 18:25:41 --> Helper loaded: file_helper
INFO - 2023-09-22 18:25:41 --> Database Driver Class Initialized
INFO - 2023-09-22 18:25:41 --> Email Class Initialized
DEBUG - 2023-09-22 18:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:25:41 --> Controller Class Initialized
INFO - 2023-09-22 18:25:41 --> Model "Services_model" initialized
INFO - 2023-09-22 18:25:41 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:25:41 --> Helper loaded: form_helper
INFO - 2023-09-22 18:25:41 --> Form Validation Class Initialized
INFO - 2023-09-22 18:25:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:25:41 --> Final output sent to browser
DEBUG - 2023-09-22 18:25:41 --> Total execution time: 0.1034
INFO - 2023-09-22 18:25:59 --> Config Class Initialized
INFO - 2023-09-22 18:25:59 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:25:59 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:25:59 --> Utf8 Class Initialized
INFO - 2023-09-22 18:25:59 --> URI Class Initialized
INFO - 2023-09-22 18:25:59 --> Router Class Initialized
INFO - 2023-09-22 18:25:59 --> Output Class Initialized
INFO - 2023-09-22 18:25:59 --> Security Class Initialized
DEBUG - 2023-09-22 18:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:25:59 --> Input Class Initialized
INFO - 2023-09-22 18:25:59 --> Language Class Initialized
INFO - 2023-09-22 18:26:00 --> Loader Class Initialized
INFO - 2023-09-22 18:26:00 --> Helper loaded: url_helper
INFO - 2023-09-22 18:26:00 --> Helper loaded: file_helper
INFO - 2023-09-22 18:26:00 --> Database Driver Class Initialized
INFO - 2023-09-22 18:26:00 --> Email Class Initialized
DEBUG - 2023-09-22 18:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:26:00 --> Controller Class Initialized
INFO - 2023-09-22 18:26:00 --> Model "Services_model" initialized
INFO - 2023-09-22 18:26:00 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:26:00 --> Helper loaded: form_helper
INFO - 2023-09-22 18:26:00 --> Form Validation Class Initialized
INFO - 2023-09-22 18:26:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:26:00 --> Config Class Initialized
INFO - 2023-09-22 18:26:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:26:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:26:00 --> Utf8 Class Initialized
INFO - 2023-09-22 18:26:00 --> URI Class Initialized
INFO - 2023-09-22 18:26:00 --> Router Class Initialized
INFO - 2023-09-22 18:26:00 --> Output Class Initialized
INFO - 2023-09-22 18:26:00 --> Security Class Initialized
DEBUG - 2023-09-22 18:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:26:00 --> Input Class Initialized
INFO - 2023-09-22 18:26:00 --> Language Class Initialized
INFO - 2023-09-22 18:26:00 --> Loader Class Initialized
INFO - 2023-09-22 18:26:00 --> Helper loaded: url_helper
INFO - 2023-09-22 18:26:00 --> Helper loaded: file_helper
INFO - 2023-09-22 18:26:00 --> Database Driver Class Initialized
INFO - 2023-09-22 18:26:00 --> Email Class Initialized
DEBUG - 2023-09-22 18:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:26:00 --> Controller Class Initialized
INFO - 2023-09-22 18:26:00 --> Model "Services_model" initialized
INFO - 2023-09-22 18:26:00 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:26:00 --> Helper loaded: form_helper
INFO - 2023-09-22 18:26:00 --> Form Validation Class Initialized
INFO - 2023-09-22 18:26:00 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:26:00 --> Final output sent to browser
DEBUG - 2023-09-22 18:26:00 --> Total execution time: 0.1695
INFO - 2023-09-22 18:26:06 --> Config Class Initialized
INFO - 2023-09-22 18:26:06 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:26:06 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:26:06 --> Utf8 Class Initialized
INFO - 2023-09-22 18:26:06 --> URI Class Initialized
INFO - 2023-09-22 18:26:06 --> Router Class Initialized
INFO - 2023-09-22 18:26:06 --> Output Class Initialized
INFO - 2023-09-22 18:26:06 --> Security Class Initialized
DEBUG - 2023-09-22 18:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:26:06 --> Input Class Initialized
INFO - 2023-09-22 18:26:06 --> Language Class Initialized
INFO - 2023-09-22 18:26:06 --> Loader Class Initialized
INFO - 2023-09-22 18:26:06 --> Helper loaded: url_helper
INFO - 2023-09-22 18:26:06 --> Helper loaded: file_helper
INFO - 2023-09-22 18:26:06 --> Database Driver Class Initialized
INFO - 2023-09-22 18:26:06 --> Email Class Initialized
DEBUG - 2023-09-22 18:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:26:06 --> Controller Class Initialized
INFO - 2023-09-22 18:26:06 --> Model "Services_model" initialized
INFO - 2023-09-22 18:26:06 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:26:06 --> Helper loaded: form_helper
INFO - 2023-09-22 18:26:06 --> Form Validation Class Initialized
INFO - 2023-09-22 18:26:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:26:06 --> Final output sent to browser
DEBUG - 2023-09-22 18:26:06 --> Total execution time: 0.1011
INFO - 2023-09-22 18:26:07 --> Config Class Initialized
INFO - 2023-09-22 18:26:07 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:26:07 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:26:07 --> Utf8 Class Initialized
INFO - 2023-09-22 18:26:07 --> URI Class Initialized
INFO - 2023-09-22 18:26:07 --> Router Class Initialized
INFO - 2023-09-22 18:26:07 --> Output Class Initialized
INFO - 2023-09-22 18:26:07 --> Security Class Initialized
DEBUG - 2023-09-22 18:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:26:07 --> Input Class Initialized
INFO - 2023-09-22 18:26:07 --> Language Class Initialized
INFO - 2023-09-22 18:26:07 --> Loader Class Initialized
INFO - 2023-09-22 18:26:07 --> Helper loaded: url_helper
INFO - 2023-09-22 18:26:07 --> Helper loaded: file_helper
INFO - 2023-09-22 18:26:07 --> Database Driver Class Initialized
INFO - 2023-09-22 18:26:07 --> Email Class Initialized
DEBUG - 2023-09-22 18:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:26:07 --> Controller Class Initialized
INFO - 2023-09-22 18:26:07 --> Model "Services_model" initialized
INFO - 2023-09-22 18:26:07 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:26:07 --> Helper loaded: form_helper
INFO - 2023-09-22 18:26:07 --> Form Validation Class Initialized
INFO - 2023-09-22 18:26:07 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:26:07 --> Final output sent to browser
DEBUG - 2023-09-22 18:26:07 --> Total execution time: 0.0771
INFO - 2023-09-22 18:26:32 --> Config Class Initialized
INFO - 2023-09-22 18:26:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:26:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:26:32 --> Utf8 Class Initialized
INFO - 2023-09-22 18:26:32 --> URI Class Initialized
INFO - 2023-09-22 18:26:32 --> Router Class Initialized
INFO - 2023-09-22 18:26:32 --> Output Class Initialized
INFO - 2023-09-22 18:26:32 --> Security Class Initialized
DEBUG - 2023-09-22 18:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:26:32 --> Input Class Initialized
INFO - 2023-09-22 18:26:32 --> Language Class Initialized
INFO - 2023-09-22 18:26:32 --> Loader Class Initialized
INFO - 2023-09-22 18:26:32 --> Helper loaded: url_helper
INFO - 2023-09-22 18:26:32 --> Helper loaded: file_helper
INFO - 2023-09-22 18:26:32 --> Database Driver Class Initialized
INFO - 2023-09-22 18:26:32 --> Email Class Initialized
DEBUG - 2023-09-22 18:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:26:32 --> Controller Class Initialized
INFO - 2023-09-22 18:26:32 --> Model "Services_model" initialized
INFO - 2023-09-22 18:26:32 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:26:32 --> Helper loaded: form_helper
INFO - 2023-09-22 18:26:32 --> Form Validation Class Initialized
INFO - 2023-09-22 18:26:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:26:32 --> Config Class Initialized
INFO - 2023-09-22 18:26:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:26:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:26:33 --> Utf8 Class Initialized
INFO - 2023-09-22 18:26:33 --> URI Class Initialized
INFO - 2023-09-22 18:26:33 --> Router Class Initialized
INFO - 2023-09-22 18:26:33 --> Output Class Initialized
INFO - 2023-09-22 18:26:33 --> Security Class Initialized
DEBUG - 2023-09-22 18:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:26:33 --> Input Class Initialized
INFO - 2023-09-22 18:26:33 --> Language Class Initialized
INFO - 2023-09-22 18:26:33 --> Loader Class Initialized
INFO - 2023-09-22 18:26:33 --> Helper loaded: url_helper
INFO - 2023-09-22 18:26:33 --> Helper loaded: file_helper
INFO - 2023-09-22 18:26:33 --> Database Driver Class Initialized
INFO - 2023-09-22 18:26:33 --> Email Class Initialized
DEBUG - 2023-09-22 18:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:26:33 --> Controller Class Initialized
INFO - 2023-09-22 18:26:33 --> Model "Services_model" initialized
INFO - 2023-09-22 18:26:33 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:26:33 --> Helper loaded: form_helper
INFO - 2023-09-22 18:26:33 --> Form Validation Class Initialized
INFO - 2023-09-22 18:26:33 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:26:33 --> Final output sent to browser
DEBUG - 2023-09-22 18:26:33 --> Total execution time: 0.1248
INFO - 2023-09-22 18:26:41 --> Config Class Initialized
INFO - 2023-09-22 18:26:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:26:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:26:41 --> Utf8 Class Initialized
INFO - 2023-09-22 18:26:41 --> URI Class Initialized
INFO - 2023-09-22 18:26:41 --> Router Class Initialized
INFO - 2023-09-22 18:26:41 --> Output Class Initialized
INFO - 2023-09-22 18:26:41 --> Security Class Initialized
DEBUG - 2023-09-22 18:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:26:41 --> Input Class Initialized
INFO - 2023-09-22 18:26:41 --> Language Class Initialized
INFO - 2023-09-22 18:26:41 --> Loader Class Initialized
INFO - 2023-09-22 18:26:41 --> Helper loaded: url_helper
INFO - 2023-09-22 18:26:41 --> Helper loaded: file_helper
INFO - 2023-09-22 18:26:42 --> Database Driver Class Initialized
INFO - 2023-09-22 18:26:42 --> Email Class Initialized
DEBUG - 2023-09-22 18:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:26:42 --> Controller Class Initialized
INFO - 2023-09-22 18:26:42 --> Model "Services_model" initialized
INFO - 2023-09-22 18:26:42 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:26:42 --> Helper loaded: form_helper
INFO - 2023-09-22 18:26:42 --> Form Validation Class Initialized
INFO - 2023-09-22 18:26:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:26:42 --> Final output sent to browser
DEBUG - 2023-09-22 18:26:42 --> Total execution time: 0.1276
INFO - 2023-09-22 18:26:42 --> Config Class Initialized
INFO - 2023-09-22 18:26:42 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:26:42 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:26:42 --> Utf8 Class Initialized
INFO - 2023-09-22 18:26:42 --> URI Class Initialized
INFO - 2023-09-22 18:26:42 --> Router Class Initialized
INFO - 2023-09-22 18:26:42 --> Output Class Initialized
INFO - 2023-09-22 18:26:42 --> Security Class Initialized
DEBUG - 2023-09-22 18:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:26:42 --> Input Class Initialized
INFO - 2023-09-22 18:26:42 --> Language Class Initialized
INFO - 2023-09-22 18:26:42 --> Loader Class Initialized
INFO - 2023-09-22 18:26:42 --> Helper loaded: url_helper
INFO - 2023-09-22 18:26:42 --> Helper loaded: file_helper
INFO - 2023-09-22 18:26:42 --> Database Driver Class Initialized
INFO - 2023-09-22 18:26:43 --> Email Class Initialized
DEBUG - 2023-09-22 18:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:26:43 --> Controller Class Initialized
INFO - 2023-09-22 18:26:43 --> Model "Services_model" initialized
INFO - 2023-09-22 18:26:43 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:26:43 --> Helper loaded: form_helper
INFO - 2023-09-22 18:26:43 --> Form Validation Class Initialized
INFO - 2023-09-22 18:26:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:26:43 --> Final output sent to browser
DEBUG - 2023-09-22 18:26:43 --> Total execution time: 0.1367
INFO - 2023-09-22 18:27:02 --> Config Class Initialized
INFO - 2023-09-22 18:27:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:27:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:27:02 --> Utf8 Class Initialized
INFO - 2023-09-22 18:27:02 --> URI Class Initialized
INFO - 2023-09-22 18:27:02 --> Router Class Initialized
INFO - 2023-09-22 18:27:02 --> Output Class Initialized
INFO - 2023-09-22 18:27:02 --> Security Class Initialized
DEBUG - 2023-09-22 18:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:27:02 --> Input Class Initialized
INFO - 2023-09-22 18:27:02 --> Language Class Initialized
INFO - 2023-09-22 18:27:02 --> Loader Class Initialized
INFO - 2023-09-22 18:27:02 --> Helper loaded: url_helper
INFO - 2023-09-22 18:27:02 --> Helper loaded: file_helper
INFO - 2023-09-22 18:27:02 --> Database Driver Class Initialized
INFO - 2023-09-22 18:27:02 --> Email Class Initialized
DEBUG - 2023-09-22 18:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:27:02 --> Controller Class Initialized
INFO - 2023-09-22 18:27:02 --> Model "Services_model" initialized
INFO - 2023-09-22 18:27:02 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:27:02 --> Helper loaded: form_helper
INFO - 2023-09-22 18:27:02 --> Form Validation Class Initialized
INFO - 2023-09-22 18:27:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:27:02 --> Config Class Initialized
INFO - 2023-09-22 18:27:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:27:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:27:02 --> Utf8 Class Initialized
INFO - 2023-09-22 18:27:02 --> URI Class Initialized
INFO - 2023-09-22 18:27:02 --> Router Class Initialized
INFO - 2023-09-22 18:27:02 --> Output Class Initialized
INFO - 2023-09-22 18:27:02 --> Security Class Initialized
DEBUG - 2023-09-22 18:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:27:02 --> Input Class Initialized
INFO - 2023-09-22 18:27:02 --> Language Class Initialized
INFO - 2023-09-22 18:27:02 --> Loader Class Initialized
INFO - 2023-09-22 18:27:02 --> Helper loaded: url_helper
INFO - 2023-09-22 18:27:02 --> Helper loaded: file_helper
INFO - 2023-09-22 18:27:02 --> Database Driver Class Initialized
INFO - 2023-09-22 18:27:02 --> Email Class Initialized
DEBUG - 2023-09-22 18:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:27:02 --> Controller Class Initialized
INFO - 2023-09-22 18:27:02 --> Model "Services_model" initialized
INFO - 2023-09-22 18:27:02 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:27:02 --> Helper loaded: form_helper
INFO - 2023-09-22 18:27:02 --> Form Validation Class Initialized
INFO - 2023-09-22 18:27:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:27:02 --> Final output sent to browser
DEBUG - 2023-09-22 18:27:02 --> Total execution time: 0.1342
INFO - 2023-09-22 18:27:09 --> Config Class Initialized
INFO - 2023-09-22 18:27:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:27:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:27:09 --> Utf8 Class Initialized
INFO - 2023-09-22 18:27:09 --> URI Class Initialized
INFO - 2023-09-22 18:27:09 --> Router Class Initialized
INFO - 2023-09-22 18:27:09 --> Output Class Initialized
INFO - 2023-09-22 18:27:09 --> Security Class Initialized
DEBUG - 2023-09-22 18:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:27:09 --> Input Class Initialized
INFO - 2023-09-22 18:27:09 --> Language Class Initialized
INFO - 2023-09-22 18:27:09 --> Loader Class Initialized
INFO - 2023-09-22 18:27:09 --> Helper loaded: url_helper
INFO - 2023-09-22 18:27:09 --> Helper loaded: file_helper
INFO - 2023-09-22 18:27:09 --> Database Driver Class Initialized
INFO - 2023-09-22 18:27:10 --> Email Class Initialized
DEBUG - 2023-09-22 18:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:27:10 --> Controller Class Initialized
INFO - 2023-09-22 18:27:10 --> Model "Services_model" initialized
INFO - 2023-09-22 18:27:10 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:27:10 --> Helper loaded: form_helper
INFO - 2023-09-22 18:27:10 --> Form Validation Class Initialized
INFO - 2023-09-22 18:27:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:27:10 --> Final output sent to browser
DEBUG - 2023-09-22 18:27:10 --> Total execution time: 0.1010
INFO - 2023-09-22 18:27:10 --> Config Class Initialized
INFO - 2023-09-22 18:27:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:27:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:27:10 --> Utf8 Class Initialized
INFO - 2023-09-22 18:27:10 --> URI Class Initialized
INFO - 2023-09-22 18:27:10 --> Router Class Initialized
INFO - 2023-09-22 18:27:10 --> Output Class Initialized
INFO - 2023-09-22 18:27:10 --> Security Class Initialized
DEBUG - 2023-09-22 18:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:27:10 --> Input Class Initialized
INFO - 2023-09-22 18:27:10 --> Language Class Initialized
INFO - 2023-09-22 18:27:10 --> Loader Class Initialized
INFO - 2023-09-22 18:27:10 --> Helper loaded: url_helper
INFO - 2023-09-22 18:27:10 --> Helper loaded: file_helper
INFO - 2023-09-22 18:27:10 --> Database Driver Class Initialized
INFO - 2023-09-22 18:27:10 --> Email Class Initialized
DEBUG - 2023-09-22 18:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:27:10 --> Controller Class Initialized
INFO - 2023-09-22 18:27:10 --> Model "Services_model" initialized
INFO - 2023-09-22 18:27:10 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:27:10 --> Helper loaded: form_helper
INFO - 2023-09-22 18:27:10 --> Form Validation Class Initialized
INFO - 2023-09-22 18:27:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:27:10 --> Final output sent to browser
DEBUG - 2023-09-22 18:27:10 --> Total execution time: 0.1159
INFO - 2023-09-22 18:27:30 --> Config Class Initialized
INFO - 2023-09-22 18:27:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:27:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:27:30 --> Utf8 Class Initialized
INFO - 2023-09-22 18:27:30 --> URI Class Initialized
INFO - 2023-09-22 18:27:30 --> Router Class Initialized
INFO - 2023-09-22 18:27:30 --> Output Class Initialized
INFO - 2023-09-22 18:27:30 --> Security Class Initialized
DEBUG - 2023-09-22 18:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:27:30 --> Input Class Initialized
INFO - 2023-09-22 18:27:30 --> Language Class Initialized
INFO - 2023-09-22 18:27:30 --> Loader Class Initialized
INFO - 2023-09-22 18:27:30 --> Helper loaded: url_helper
INFO - 2023-09-22 18:27:30 --> Helper loaded: file_helper
INFO - 2023-09-22 18:27:30 --> Database Driver Class Initialized
INFO - 2023-09-22 18:27:30 --> Email Class Initialized
DEBUG - 2023-09-22 18:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:27:30 --> Controller Class Initialized
INFO - 2023-09-22 18:27:30 --> Model "Services_model" initialized
INFO - 2023-09-22 18:27:30 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:27:30 --> Helper loaded: form_helper
INFO - 2023-09-22 18:27:30 --> Form Validation Class Initialized
INFO - 2023-09-22 18:27:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:27:30 --> Config Class Initialized
INFO - 2023-09-22 18:27:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:27:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:27:30 --> Utf8 Class Initialized
INFO - 2023-09-22 18:27:30 --> URI Class Initialized
INFO - 2023-09-22 18:27:30 --> Router Class Initialized
INFO - 2023-09-22 18:27:30 --> Output Class Initialized
INFO - 2023-09-22 18:27:30 --> Security Class Initialized
DEBUG - 2023-09-22 18:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:27:30 --> Input Class Initialized
INFO - 2023-09-22 18:27:30 --> Language Class Initialized
INFO - 2023-09-22 18:27:30 --> Loader Class Initialized
INFO - 2023-09-22 18:27:30 --> Helper loaded: url_helper
INFO - 2023-09-22 18:27:30 --> Helper loaded: file_helper
INFO - 2023-09-22 18:27:30 --> Database Driver Class Initialized
INFO - 2023-09-22 18:27:30 --> Email Class Initialized
DEBUG - 2023-09-22 18:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:27:31 --> Controller Class Initialized
INFO - 2023-09-22 18:27:31 --> Model "Services_model" initialized
INFO - 2023-09-22 18:27:31 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:27:31 --> Helper loaded: form_helper
INFO - 2023-09-22 18:27:31 --> Form Validation Class Initialized
INFO - 2023-09-22 18:27:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:27:31 --> Final output sent to browser
DEBUG - 2023-09-22 18:27:31 --> Total execution time: 0.2717
INFO - 2023-09-22 18:27:41 --> Config Class Initialized
INFO - 2023-09-22 18:27:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:27:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:27:41 --> Utf8 Class Initialized
INFO - 2023-09-22 18:27:41 --> URI Class Initialized
INFO - 2023-09-22 18:27:41 --> Router Class Initialized
INFO - 2023-09-22 18:27:41 --> Output Class Initialized
INFO - 2023-09-22 18:27:41 --> Security Class Initialized
DEBUG - 2023-09-22 18:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:27:41 --> Input Class Initialized
INFO - 2023-09-22 18:27:41 --> Language Class Initialized
INFO - 2023-09-22 18:27:41 --> Loader Class Initialized
INFO - 2023-09-22 18:27:41 --> Helper loaded: url_helper
INFO - 2023-09-22 18:27:41 --> Helper loaded: file_helper
INFO - 2023-09-22 18:27:41 --> Database Driver Class Initialized
INFO - 2023-09-22 18:27:41 --> Email Class Initialized
DEBUG - 2023-09-22 18:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:27:41 --> Controller Class Initialized
INFO - 2023-09-22 18:27:41 --> Model "Services_model" initialized
INFO - 2023-09-22 18:27:41 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:27:41 --> Helper loaded: form_helper
INFO - 2023-09-22 18:27:41 --> Form Validation Class Initialized
INFO - 2023-09-22 18:27:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:27:41 --> Final output sent to browser
DEBUG - 2023-09-22 18:27:41 --> Total execution time: 0.1009
INFO - 2023-09-22 18:27:42 --> Config Class Initialized
INFO - 2023-09-22 18:27:42 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:27:42 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:27:42 --> Utf8 Class Initialized
INFO - 2023-09-22 18:27:42 --> URI Class Initialized
INFO - 2023-09-22 18:27:42 --> Router Class Initialized
INFO - 2023-09-22 18:27:42 --> Output Class Initialized
INFO - 2023-09-22 18:27:42 --> Security Class Initialized
DEBUG - 2023-09-22 18:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:27:42 --> Input Class Initialized
INFO - 2023-09-22 18:27:42 --> Language Class Initialized
INFO - 2023-09-22 18:27:42 --> Loader Class Initialized
INFO - 2023-09-22 18:27:42 --> Helper loaded: url_helper
INFO - 2023-09-22 18:27:42 --> Helper loaded: file_helper
INFO - 2023-09-22 18:27:42 --> Database Driver Class Initialized
INFO - 2023-09-22 18:27:42 --> Email Class Initialized
DEBUG - 2023-09-22 18:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:27:42 --> Controller Class Initialized
INFO - 2023-09-22 18:27:42 --> Model "Services_model" initialized
INFO - 2023-09-22 18:27:42 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:27:42 --> Helper loaded: form_helper
INFO - 2023-09-22 18:27:42 --> Form Validation Class Initialized
INFO - 2023-09-22 18:27:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:27:42 --> Final output sent to browser
DEBUG - 2023-09-22 18:27:42 --> Total execution time: 0.1326
INFO - 2023-09-22 18:28:05 --> Config Class Initialized
INFO - 2023-09-22 18:28:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:28:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:28:05 --> Utf8 Class Initialized
INFO - 2023-09-22 18:28:05 --> URI Class Initialized
INFO - 2023-09-22 18:28:05 --> Router Class Initialized
INFO - 2023-09-22 18:28:05 --> Output Class Initialized
INFO - 2023-09-22 18:28:05 --> Security Class Initialized
DEBUG - 2023-09-22 18:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:28:05 --> Input Class Initialized
INFO - 2023-09-22 18:28:05 --> Language Class Initialized
INFO - 2023-09-22 18:28:05 --> Loader Class Initialized
INFO - 2023-09-22 18:28:05 --> Helper loaded: url_helper
INFO - 2023-09-22 18:28:05 --> Helper loaded: file_helper
INFO - 2023-09-22 18:28:05 --> Database Driver Class Initialized
INFO - 2023-09-22 18:28:05 --> Email Class Initialized
DEBUG - 2023-09-22 18:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:28:05 --> Controller Class Initialized
INFO - 2023-09-22 18:28:05 --> Model "Services_model" initialized
INFO - 2023-09-22 18:28:05 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:28:05 --> Helper loaded: form_helper
INFO - 2023-09-22 18:28:05 --> Form Validation Class Initialized
INFO - 2023-09-22 18:28:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:28:05 --> Config Class Initialized
INFO - 2023-09-22 18:28:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:28:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:28:05 --> Utf8 Class Initialized
INFO - 2023-09-22 18:28:05 --> URI Class Initialized
INFO - 2023-09-22 18:28:05 --> Router Class Initialized
INFO - 2023-09-22 18:28:05 --> Output Class Initialized
INFO - 2023-09-22 18:28:05 --> Security Class Initialized
DEBUG - 2023-09-22 18:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:28:05 --> Input Class Initialized
INFO - 2023-09-22 18:28:05 --> Language Class Initialized
INFO - 2023-09-22 18:28:05 --> Loader Class Initialized
INFO - 2023-09-22 18:28:05 --> Helper loaded: url_helper
INFO - 2023-09-22 18:28:05 --> Helper loaded: file_helper
INFO - 2023-09-22 18:28:05 --> Database Driver Class Initialized
INFO - 2023-09-22 18:28:05 --> Email Class Initialized
DEBUG - 2023-09-22 18:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:28:05 --> Controller Class Initialized
INFO - 2023-09-22 18:28:05 --> Model "Services_model" initialized
INFO - 2023-09-22 18:28:05 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:28:05 --> Helper loaded: form_helper
INFO - 2023-09-22 18:28:05 --> Form Validation Class Initialized
INFO - 2023-09-22 18:28:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:28:05 --> Final output sent to browser
DEBUG - 2023-09-22 18:28:06 --> Total execution time: 0.1285
INFO - 2023-09-22 18:28:12 --> Config Class Initialized
INFO - 2023-09-22 18:28:12 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:28:12 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:28:12 --> Utf8 Class Initialized
INFO - 2023-09-22 18:28:12 --> URI Class Initialized
INFO - 2023-09-22 18:28:12 --> Router Class Initialized
INFO - 2023-09-22 18:28:13 --> Output Class Initialized
INFO - 2023-09-22 18:28:13 --> Security Class Initialized
DEBUG - 2023-09-22 18:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:28:13 --> Input Class Initialized
INFO - 2023-09-22 18:28:13 --> Language Class Initialized
INFO - 2023-09-22 18:28:13 --> Loader Class Initialized
INFO - 2023-09-22 18:28:13 --> Helper loaded: url_helper
INFO - 2023-09-22 18:28:13 --> Helper loaded: file_helper
INFO - 2023-09-22 18:28:13 --> Database Driver Class Initialized
INFO - 2023-09-22 18:28:13 --> Email Class Initialized
DEBUG - 2023-09-22 18:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:28:13 --> Controller Class Initialized
INFO - 2023-09-22 18:28:13 --> Model "Services_model" initialized
INFO - 2023-09-22 18:28:13 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:28:13 --> Helper loaded: form_helper
INFO - 2023-09-22 18:28:13 --> Form Validation Class Initialized
INFO - 2023-09-22 18:28:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:28:13 --> Final output sent to browser
DEBUG - 2023-09-22 18:28:13 --> Total execution time: 0.1188
INFO - 2023-09-22 18:28:14 --> Config Class Initialized
INFO - 2023-09-22 18:28:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:28:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:28:14 --> Utf8 Class Initialized
INFO - 2023-09-22 18:28:14 --> URI Class Initialized
INFO - 2023-09-22 18:28:14 --> Router Class Initialized
INFO - 2023-09-22 18:28:14 --> Output Class Initialized
INFO - 2023-09-22 18:28:14 --> Security Class Initialized
DEBUG - 2023-09-22 18:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:28:14 --> Input Class Initialized
INFO - 2023-09-22 18:28:14 --> Language Class Initialized
INFO - 2023-09-22 18:28:14 --> Loader Class Initialized
INFO - 2023-09-22 18:28:14 --> Helper loaded: url_helper
INFO - 2023-09-22 18:28:14 --> Helper loaded: file_helper
INFO - 2023-09-22 18:28:14 --> Database Driver Class Initialized
INFO - 2023-09-22 18:28:14 --> Email Class Initialized
DEBUG - 2023-09-22 18:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:28:14 --> Controller Class Initialized
INFO - 2023-09-22 18:28:14 --> Model "Services_model" initialized
INFO - 2023-09-22 18:28:14 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:28:14 --> Helper loaded: form_helper
INFO - 2023-09-22 18:28:14 --> Form Validation Class Initialized
INFO - 2023-09-22 18:28:14 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:28:14 --> Final output sent to browser
DEBUG - 2023-09-22 18:28:14 --> Total execution time: 0.1796
INFO - 2023-09-22 18:28:32 --> Config Class Initialized
INFO - 2023-09-22 18:28:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:28:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:28:32 --> Utf8 Class Initialized
INFO - 2023-09-22 18:28:32 --> URI Class Initialized
INFO - 2023-09-22 18:28:32 --> Router Class Initialized
INFO - 2023-09-22 18:28:32 --> Output Class Initialized
INFO - 2023-09-22 18:28:32 --> Security Class Initialized
DEBUG - 2023-09-22 18:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:28:32 --> Input Class Initialized
INFO - 2023-09-22 18:28:32 --> Language Class Initialized
INFO - 2023-09-22 18:28:32 --> Loader Class Initialized
INFO - 2023-09-22 18:28:32 --> Helper loaded: url_helper
INFO - 2023-09-22 18:28:32 --> Helper loaded: file_helper
INFO - 2023-09-22 18:28:32 --> Database Driver Class Initialized
INFO - 2023-09-22 18:28:32 --> Email Class Initialized
DEBUG - 2023-09-22 18:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:28:32 --> Controller Class Initialized
INFO - 2023-09-22 18:28:32 --> Model "Services_model" initialized
INFO - 2023-09-22 18:28:32 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:28:32 --> Helper loaded: form_helper
INFO - 2023-09-22 18:28:32 --> Form Validation Class Initialized
INFO - 2023-09-22 18:28:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:28:33 --> Config Class Initialized
INFO - 2023-09-22 18:28:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:28:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:28:33 --> Utf8 Class Initialized
INFO - 2023-09-22 18:28:33 --> URI Class Initialized
INFO - 2023-09-22 18:28:33 --> Router Class Initialized
INFO - 2023-09-22 18:28:33 --> Output Class Initialized
INFO - 2023-09-22 18:28:33 --> Security Class Initialized
DEBUG - 2023-09-22 18:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:28:33 --> Input Class Initialized
INFO - 2023-09-22 18:28:33 --> Language Class Initialized
INFO - 2023-09-22 18:28:33 --> Loader Class Initialized
INFO - 2023-09-22 18:28:33 --> Helper loaded: url_helper
INFO - 2023-09-22 18:28:33 --> Helper loaded: file_helper
INFO - 2023-09-22 18:28:33 --> Database Driver Class Initialized
INFO - 2023-09-22 18:28:33 --> Email Class Initialized
DEBUG - 2023-09-22 18:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:28:33 --> Controller Class Initialized
INFO - 2023-09-22 18:28:33 --> Model "Services_model" initialized
INFO - 2023-09-22 18:28:33 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:28:33 --> Helper loaded: form_helper
INFO - 2023-09-22 18:28:33 --> Form Validation Class Initialized
INFO - 2023-09-22 18:28:33 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:28:33 --> Final output sent to browser
DEBUG - 2023-09-22 18:28:33 --> Total execution time: 0.1238
INFO - 2023-09-22 18:29:00 --> Config Class Initialized
INFO - 2023-09-22 18:29:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:29:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:29:00 --> Utf8 Class Initialized
INFO - 2023-09-22 18:29:00 --> URI Class Initialized
INFO - 2023-09-22 18:29:00 --> Router Class Initialized
INFO - 2023-09-22 18:29:00 --> Output Class Initialized
INFO - 2023-09-22 18:29:00 --> Security Class Initialized
DEBUG - 2023-09-22 18:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:29:00 --> Input Class Initialized
INFO - 2023-09-22 18:29:00 --> Language Class Initialized
INFO - 2023-09-22 18:29:00 --> Loader Class Initialized
INFO - 2023-09-22 18:29:00 --> Helper loaded: url_helper
INFO - 2023-09-22 18:29:00 --> Helper loaded: file_helper
INFO - 2023-09-22 18:29:00 --> Database Driver Class Initialized
INFO - 2023-09-22 18:29:00 --> Email Class Initialized
DEBUG - 2023-09-22 18:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:29:00 --> Controller Class Initialized
INFO - 2023-09-22 18:29:00 --> Model "Services_model" initialized
INFO - 2023-09-22 18:29:00 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:29:00 --> Helper loaded: form_helper
INFO - 2023-09-22 18:29:00 --> Form Validation Class Initialized
INFO - 2023-09-22 18:29:00 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:29:00 --> Final output sent to browser
DEBUG - 2023-09-22 18:29:00 --> Total execution time: 0.1210
INFO - 2023-09-22 18:29:01 --> Config Class Initialized
INFO - 2023-09-22 18:29:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:29:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:29:01 --> Utf8 Class Initialized
INFO - 2023-09-22 18:29:01 --> URI Class Initialized
INFO - 2023-09-22 18:29:01 --> Router Class Initialized
INFO - 2023-09-22 18:29:01 --> Output Class Initialized
INFO - 2023-09-22 18:29:01 --> Security Class Initialized
DEBUG - 2023-09-22 18:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:29:01 --> Input Class Initialized
INFO - 2023-09-22 18:29:01 --> Language Class Initialized
INFO - 2023-09-22 18:29:01 --> Loader Class Initialized
INFO - 2023-09-22 18:29:01 --> Helper loaded: url_helper
INFO - 2023-09-22 18:29:01 --> Helper loaded: file_helper
INFO - 2023-09-22 18:29:01 --> Database Driver Class Initialized
INFO - 2023-09-22 18:29:01 --> Email Class Initialized
DEBUG - 2023-09-22 18:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:29:01 --> Controller Class Initialized
INFO - 2023-09-22 18:29:01 --> Model "Services_model" initialized
INFO - 2023-09-22 18:29:01 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:29:01 --> Helper loaded: form_helper
INFO - 2023-09-22 18:29:01 --> Form Validation Class Initialized
INFO - 2023-09-22 18:29:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:29:01 --> Final output sent to browser
DEBUG - 2023-09-22 18:29:01 --> Total execution time: 0.1353
INFO - 2023-09-22 18:29:24 --> Config Class Initialized
INFO - 2023-09-22 18:29:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:29:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:29:24 --> Utf8 Class Initialized
INFO - 2023-09-22 18:29:24 --> URI Class Initialized
INFO - 2023-09-22 18:29:24 --> Router Class Initialized
INFO - 2023-09-22 18:29:24 --> Output Class Initialized
INFO - 2023-09-22 18:29:24 --> Security Class Initialized
DEBUG - 2023-09-22 18:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:29:24 --> Input Class Initialized
INFO - 2023-09-22 18:29:24 --> Language Class Initialized
INFO - 2023-09-22 18:29:24 --> Loader Class Initialized
INFO - 2023-09-22 18:29:24 --> Helper loaded: url_helper
INFO - 2023-09-22 18:29:24 --> Helper loaded: file_helper
INFO - 2023-09-22 18:29:24 --> Database Driver Class Initialized
INFO - 2023-09-22 18:29:24 --> Email Class Initialized
DEBUG - 2023-09-22 18:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:29:24 --> Controller Class Initialized
INFO - 2023-09-22 18:29:24 --> Model "Services_model" initialized
INFO - 2023-09-22 18:29:24 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:29:24 --> Helper loaded: form_helper
INFO - 2023-09-22 18:29:24 --> Form Validation Class Initialized
INFO - 2023-09-22 18:29:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:29:24 --> Config Class Initialized
INFO - 2023-09-22 18:29:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:29:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:29:24 --> Utf8 Class Initialized
INFO - 2023-09-22 18:29:24 --> URI Class Initialized
INFO - 2023-09-22 18:29:24 --> Router Class Initialized
INFO - 2023-09-22 18:29:24 --> Output Class Initialized
INFO - 2023-09-22 18:29:24 --> Security Class Initialized
DEBUG - 2023-09-22 18:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:29:24 --> Input Class Initialized
INFO - 2023-09-22 18:29:24 --> Language Class Initialized
INFO - 2023-09-22 18:29:24 --> Loader Class Initialized
INFO - 2023-09-22 18:29:24 --> Helper loaded: url_helper
INFO - 2023-09-22 18:29:24 --> Helper loaded: file_helper
INFO - 2023-09-22 18:29:24 --> Database Driver Class Initialized
INFO - 2023-09-22 18:29:24 --> Email Class Initialized
DEBUG - 2023-09-22 18:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:29:24 --> Controller Class Initialized
INFO - 2023-09-22 18:29:24 --> Model "Services_model" initialized
INFO - 2023-09-22 18:29:24 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:29:24 --> Helper loaded: form_helper
INFO - 2023-09-22 18:29:24 --> Form Validation Class Initialized
INFO - 2023-09-22 18:29:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:29:24 --> Final output sent to browser
DEBUG - 2023-09-22 18:29:24 --> Total execution time: 0.1018
INFO - 2023-09-22 18:29:31 --> Config Class Initialized
INFO - 2023-09-22 18:29:31 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:29:31 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:29:31 --> Utf8 Class Initialized
INFO - 2023-09-22 18:29:31 --> URI Class Initialized
INFO - 2023-09-22 18:29:31 --> Router Class Initialized
INFO - 2023-09-22 18:29:31 --> Output Class Initialized
INFO - 2023-09-22 18:29:31 --> Security Class Initialized
DEBUG - 2023-09-22 18:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:29:31 --> Input Class Initialized
INFO - 2023-09-22 18:29:31 --> Language Class Initialized
INFO - 2023-09-22 18:29:31 --> Loader Class Initialized
INFO - 2023-09-22 18:29:31 --> Helper loaded: url_helper
INFO - 2023-09-22 18:29:31 --> Helper loaded: file_helper
INFO - 2023-09-22 18:29:31 --> Database Driver Class Initialized
INFO - 2023-09-22 18:29:31 --> Email Class Initialized
DEBUG - 2023-09-22 18:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:29:31 --> Controller Class Initialized
INFO - 2023-09-22 18:29:31 --> Model "Services_model" initialized
INFO - 2023-09-22 18:29:31 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:29:31 --> Helper loaded: form_helper
INFO - 2023-09-22 18:29:31 --> Form Validation Class Initialized
INFO - 2023-09-22 18:29:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:29:32 --> Final output sent to browser
DEBUG - 2023-09-22 18:29:32 --> Total execution time: 0.1323
INFO - 2023-09-22 18:29:32 --> Config Class Initialized
INFO - 2023-09-22 18:29:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:29:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:29:32 --> Utf8 Class Initialized
INFO - 2023-09-22 18:29:32 --> URI Class Initialized
INFO - 2023-09-22 18:29:32 --> Router Class Initialized
INFO - 2023-09-22 18:29:32 --> Output Class Initialized
INFO - 2023-09-22 18:29:32 --> Security Class Initialized
DEBUG - 2023-09-22 18:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:29:32 --> Input Class Initialized
INFO - 2023-09-22 18:29:32 --> Language Class Initialized
INFO - 2023-09-22 18:29:32 --> Loader Class Initialized
INFO - 2023-09-22 18:29:32 --> Helper loaded: url_helper
INFO - 2023-09-22 18:29:32 --> Helper loaded: file_helper
INFO - 2023-09-22 18:29:32 --> Database Driver Class Initialized
INFO - 2023-09-22 18:29:32 --> Email Class Initialized
DEBUG - 2023-09-22 18:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:29:32 --> Controller Class Initialized
INFO - 2023-09-22 18:29:32 --> Model "Services_model" initialized
INFO - 2023-09-22 18:29:32 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:29:32 --> Helper loaded: form_helper
INFO - 2023-09-22 18:29:32 --> Form Validation Class Initialized
INFO - 2023-09-22 18:29:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:29:32 --> Final output sent to browser
DEBUG - 2023-09-22 18:29:32 --> Total execution time: 0.1390
INFO - 2023-09-22 18:29:55 --> Config Class Initialized
INFO - 2023-09-22 18:29:55 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:29:55 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:29:55 --> Utf8 Class Initialized
INFO - 2023-09-22 18:29:55 --> URI Class Initialized
INFO - 2023-09-22 18:29:55 --> Router Class Initialized
INFO - 2023-09-22 18:29:55 --> Output Class Initialized
INFO - 2023-09-22 18:29:55 --> Security Class Initialized
DEBUG - 2023-09-22 18:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:29:55 --> Input Class Initialized
INFO - 2023-09-22 18:29:55 --> Language Class Initialized
INFO - 2023-09-22 18:29:55 --> Loader Class Initialized
INFO - 2023-09-22 18:29:55 --> Helper loaded: url_helper
INFO - 2023-09-22 18:29:55 --> Helper loaded: file_helper
INFO - 2023-09-22 18:29:55 --> Database Driver Class Initialized
INFO - 2023-09-22 18:29:55 --> Email Class Initialized
DEBUG - 2023-09-22 18:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:29:55 --> Controller Class Initialized
INFO - 2023-09-22 18:29:55 --> Model "Services_model" initialized
INFO - 2023-09-22 18:29:55 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:29:55 --> Helper loaded: form_helper
INFO - 2023-09-22 18:29:55 --> Form Validation Class Initialized
INFO - 2023-09-22 18:29:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:29:55 --> Config Class Initialized
INFO - 2023-09-22 18:29:55 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:29:55 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:29:55 --> Utf8 Class Initialized
INFO - 2023-09-22 18:29:55 --> URI Class Initialized
INFO - 2023-09-22 18:29:55 --> Router Class Initialized
INFO - 2023-09-22 18:29:55 --> Output Class Initialized
INFO - 2023-09-22 18:29:55 --> Security Class Initialized
DEBUG - 2023-09-22 18:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:29:55 --> Input Class Initialized
INFO - 2023-09-22 18:29:55 --> Language Class Initialized
INFO - 2023-09-22 18:29:55 --> Loader Class Initialized
INFO - 2023-09-22 18:29:55 --> Helper loaded: url_helper
INFO - 2023-09-22 18:29:55 --> Helper loaded: file_helper
INFO - 2023-09-22 18:29:55 --> Database Driver Class Initialized
INFO - 2023-09-22 18:29:55 --> Email Class Initialized
DEBUG - 2023-09-22 18:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:29:55 --> Controller Class Initialized
INFO - 2023-09-22 18:29:55 --> Model "Services_model" initialized
INFO - 2023-09-22 18:29:55 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:29:55 --> Helper loaded: form_helper
INFO - 2023-09-22 18:29:55 --> Form Validation Class Initialized
INFO - 2023-09-22 18:29:55 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:29:55 --> Final output sent to browser
DEBUG - 2023-09-22 18:29:55 --> Total execution time: 0.1388
INFO - 2023-09-22 18:30:02 --> Config Class Initialized
INFO - 2023-09-22 18:30:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:30:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:30:02 --> Utf8 Class Initialized
INFO - 2023-09-22 18:30:02 --> URI Class Initialized
INFO - 2023-09-22 18:30:02 --> Router Class Initialized
INFO - 2023-09-22 18:30:02 --> Output Class Initialized
INFO - 2023-09-22 18:30:02 --> Security Class Initialized
DEBUG - 2023-09-22 18:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:30:02 --> Input Class Initialized
INFO - 2023-09-22 18:30:02 --> Language Class Initialized
INFO - 2023-09-22 18:30:02 --> Loader Class Initialized
INFO - 2023-09-22 18:30:02 --> Helper loaded: url_helper
INFO - 2023-09-22 18:30:02 --> Helper loaded: file_helper
INFO - 2023-09-22 18:30:02 --> Database Driver Class Initialized
INFO - 2023-09-22 18:30:02 --> Email Class Initialized
DEBUG - 2023-09-22 18:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:30:02 --> Controller Class Initialized
INFO - 2023-09-22 18:30:02 --> Model "Services_model" initialized
INFO - 2023-09-22 18:30:02 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:30:02 --> Helper loaded: form_helper
INFO - 2023-09-22 18:30:02 --> Form Validation Class Initialized
INFO - 2023-09-22 18:30:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:30:02 --> Final output sent to browser
DEBUG - 2023-09-22 18:30:02 --> Total execution time: 0.1129
INFO - 2023-09-22 18:30:03 --> Config Class Initialized
INFO - 2023-09-22 18:30:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:30:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:30:03 --> Utf8 Class Initialized
INFO - 2023-09-22 18:30:03 --> URI Class Initialized
INFO - 2023-09-22 18:30:03 --> Router Class Initialized
INFO - 2023-09-22 18:30:03 --> Output Class Initialized
INFO - 2023-09-22 18:30:03 --> Security Class Initialized
DEBUG - 2023-09-22 18:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:30:03 --> Input Class Initialized
INFO - 2023-09-22 18:30:03 --> Language Class Initialized
INFO - 2023-09-22 18:30:03 --> Loader Class Initialized
INFO - 2023-09-22 18:30:03 --> Helper loaded: url_helper
INFO - 2023-09-22 18:30:03 --> Helper loaded: file_helper
INFO - 2023-09-22 18:30:03 --> Database Driver Class Initialized
INFO - 2023-09-22 18:30:03 --> Email Class Initialized
DEBUG - 2023-09-22 18:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:30:03 --> Controller Class Initialized
INFO - 2023-09-22 18:30:03 --> Model "Services_model" initialized
INFO - 2023-09-22 18:30:03 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:30:03 --> Helper loaded: form_helper
INFO - 2023-09-22 18:30:03 --> Form Validation Class Initialized
INFO - 2023-09-22 18:30:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:30:03 --> Final output sent to browser
DEBUG - 2023-09-22 18:30:03 --> Total execution time: 0.1138
INFO - 2023-09-22 18:44:48 --> Config Class Initialized
INFO - 2023-09-22 18:44:48 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:44:48 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:44:48 --> Utf8 Class Initialized
INFO - 2023-09-22 18:44:48 --> URI Class Initialized
INFO - 2023-09-22 18:44:48 --> Router Class Initialized
INFO - 2023-09-22 18:44:48 --> Output Class Initialized
INFO - 2023-09-22 18:44:48 --> Security Class Initialized
DEBUG - 2023-09-22 18:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:44:48 --> Input Class Initialized
INFO - 2023-09-22 18:44:48 --> Language Class Initialized
INFO - 2023-09-22 18:44:48 --> Loader Class Initialized
INFO - 2023-09-22 18:44:48 --> Helper loaded: url_helper
INFO - 2023-09-22 18:44:48 --> Helper loaded: file_helper
INFO - 2023-09-22 18:44:48 --> Database Driver Class Initialized
INFO - 2023-09-22 18:44:48 --> Email Class Initialized
DEBUG - 2023-09-22 18:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:44:48 --> Controller Class Initialized
INFO - 2023-09-22 18:44:48 --> Model "Services_model" initialized
INFO - 2023-09-22 18:44:48 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:44:48 --> Helper loaded: form_helper
INFO - 2023-09-22 18:44:48 --> Form Validation Class Initialized
INFO - 2023-09-22 18:44:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:44:48 --> Config Class Initialized
INFO - 2023-09-22 18:44:48 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:44:48 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:44:48 --> Utf8 Class Initialized
INFO - 2023-09-22 18:44:48 --> URI Class Initialized
INFO - 2023-09-22 18:44:48 --> Router Class Initialized
INFO - 2023-09-22 18:44:48 --> Output Class Initialized
INFO - 2023-09-22 18:44:48 --> Security Class Initialized
DEBUG - 2023-09-22 18:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:44:48 --> Input Class Initialized
INFO - 2023-09-22 18:44:48 --> Language Class Initialized
INFO - 2023-09-22 18:44:48 --> Loader Class Initialized
INFO - 2023-09-22 18:44:48 --> Helper loaded: url_helper
INFO - 2023-09-22 18:44:48 --> Helper loaded: file_helper
INFO - 2023-09-22 18:44:48 --> Database Driver Class Initialized
INFO - 2023-09-22 18:44:48 --> Email Class Initialized
DEBUG - 2023-09-22 18:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:44:48 --> Controller Class Initialized
INFO - 2023-09-22 18:44:48 --> Model "Services_model" initialized
INFO - 2023-09-22 18:44:48 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:44:48 --> Helper loaded: form_helper
INFO - 2023-09-22 18:44:48 --> Form Validation Class Initialized
INFO - 2023-09-22 18:44:48 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:44:48 --> Final output sent to browser
DEBUG - 2023-09-22 18:44:48 --> Total execution time: 0.1326
INFO - 2023-09-22 18:44:51 --> Config Class Initialized
INFO - 2023-09-22 18:44:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:44:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:44:51 --> Utf8 Class Initialized
INFO - 2023-09-22 18:44:51 --> URI Class Initialized
INFO - 2023-09-22 18:44:51 --> Router Class Initialized
INFO - 2023-09-22 18:44:51 --> Output Class Initialized
INFO - 2023-09-22 18:44:51 --> Security Class Initialized
DEBUG - 2023-09-22 18:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:44:51 --> Input Class Initialized
INFO - 2023-09-22 18:44:51 --> Language Class Initialized
INFO - 2023-09-22 18:44:51 --> Loader Class Initialized
INFO - 2023-09-22 18:44:51 --> Helper loaded: url_helper
INFO - 2023-09-22 18:44:51 --> Helper loaded: file_helper
INFO - 2023-09-22 18:44:51 --> Database Driver Class Initialized
INFO - 2023-09-22 18:44:51 --> Email Class Initialized
DEBUG - 2023-09-22 18:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:44:51 --> Controller Class Initialized
INFO - 2023-09-22 18:44:51 --> Model "Services_model" initialized
INFO - 2023-09-22 18:44:51 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:44:51 --> Helper loaded: form_helper
INFO - 2023-09-22 18:44:51 --> Form Validation Class Initialized
INFO - 2023-09-22 18:44:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:44:51 --> Final output sent to browser
DEBUG - 2023-09-22 18:44:51 --> Total execution time: 0.1551
INFO - 2023-09-22 18:44:52 --> Config Class Initialized
INFO - 2023-09-22 18:44:52 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:44:52 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:44:52 --> Utf8 Class Initialized
INFO - 2023-09-22 18:44:52 --> URI Class Initialized
INFO - 2023-09-22 18:44:52 --> Router Class Initialized
INFO - 2023-09-22 18:44:52 --> Output Class Initialized
INFO - 2023-09-22 18:44:52 --> Security Class Initialized
DEBUG - 2023-09-22 18:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:44:52 --> Input Class Initialized
INFO - 2023-09-22 18:44:52 --> Language Class Initialized
INFO - 2023-09-22 18:44:52 --> Loader Class Initialized
INFO - 2023-09-22 18:44:52 --> Helper loaded: url_helper
INFO - 2023-09-22 18:44:52 --> Helper loaded: file_helper
INFO - 2023-09-22 18:44:53 --> Database Driver Class Initialized
INFO - 2023-09-22 18:44:53 --> Email Class Initialized
DEBUG - 2023-09-22 18:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:44:53 --> Controller Class Initialized
INFO - 2023-09-22 18:44:53 --> Model "Services_model" initialized
INFO - 2023-09-22 18:44:53 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:44:53 --> Helper loaded: form_helper
INFO - 2023-09-22 18:44:53 --> Form Validation Class Initialized
INFO - 2023-09-22 18:44:53 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:44:53 --> Final output sent to browser
DEBUG - 2023-09-22 18:44:53 --> Total execution time: 1.0132
INFO - 2023-09-22 18:45:26 --> Config Class Initialized
INFO - 2023-09-22 18:45:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:45:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:45:26 --> Utf8 Class Initialized
INFO - 2023-09-22 18:45:26 --> URI Class Initialized
INFO - 2023-09-22 18:45:26 --> Router Class Initialized
INFO - 2023-09-22 18:45:26 --> Output Class Initialized
INFO - 2023-09-22 18:45:26 --> Security Class Initialized
DEBUG - 2023-09-22 18:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:45:26 --> Input Class Initialized
INFO - 2023-09-22 18:45:26 --> Language Class Initialized
INFO - 2023-09-22 18:45:26 --> Loader Class Initialized
INFO - 2023-09-22 18:45:26 --> Helper loaded: url_helper
INFO - 2023-09-22 18:45:26 --> Helper loaded: file_helper
INFO - 2023-09-22 18:45:26 --> Database Driver Class Initialized
INFO - 2023-09-22 18:45:26 --> Email Class Initialized
DEBUG - 2023-09-22 18:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:45:26 --> Controller Class Initialized
INFO - 2023-09-22 18:45:26 --> Model "Services_model" initialized
INFO - 2023-09-22 18:45:26 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:45:26 --> Helper loaded: form_helper
INFO - 2023-09-22 18:45:26 --> Form Validation Class Initialized
INFO - 2023-09-22 18:45:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:45:26 --> Config Class Initialized
INFO - 2023-09-22 18:45:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:45:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:45:26 --> Utf8 Class Initialized
INFO - 2023-09-22 18:45:26 --> URI Class Initialized
INFO - 2023-09-22 18:45:26 --> Router Class Initialized
INFO - 2023-09-22 18:45:26 --> Output Class Initialized
INFO - 2023-09-22 18:45:26 --> Security Class Initialized
DEBUG - 2023-09-22 18:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:45:26 --> Input Class Initialized
INFO - 2023-09-22 18:45:26 --> Language Class Initialized
INFO - 2023-09-22 18:45:26 --> Loader Class Initialized
INFO - 2023-09-22 18:45:26 --> Helper loaded: url_helper
INFO - 2023-09-22 18:45:26 --> Helper loaded: file_helper
INFO - 2023-09-22 18:45:26 --> Database Driver Class Initialized
INFO - 2023-09-22 18:45:26 --> Email Class Initialized
DEBUG - 2023-09-22 18:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:45:26 --> Controller Class Initialized
INFO - 2023-09-22 18:45:26 --> Model "Services_model" initialized
INFO - 2023-09-22 18:45:26 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:45:26 --> Helper loaded: form_helper
INFO - 2023-09-22 18:45:26 --> Form Validation Class Initialized
INFO - 2023-09-22 18:45:26 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:45:26 --> Final output sent to browser
DEBUG - 2023-09-22 18:45:26 --> Total execution time: 0.1210
INFO - 2023-09-22 18:45:33 --> Config Class Initialized
INFO - 2023-09-22 18:45:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:45:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:45:33 --> Utf8 Class Initialized
INFO - 2023-09-22 18:45:33 --> URI Class Initialized
INFO - 2023-09-22 18:45:33 --> Router Class Initialized
INFO - 2023-09-22 18:45:33 --> Output Class Initialized
INFO - 2023-09-22 18:45:33 --> Security Class Initialized
DEBUG - 2023-09-22 18:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:45:33 --> Input Class Initialized
INFO - 2023-09-22 18:45:33 --> Language Class Initialized
INFO - 2023-09-22 18:45:33 --> Loader Class Initialized
INFO - 2023-09-22 18:45:33 --> Helper loaded: url_helper
INFO - 2023-09-22 18:45:33 --> Helper loaded: file_helper
INFO - 2023-09-22 18:45:33 --> Database Driver Class Initialized
INFO - 2023-09-22 18:45:33 --> Email Class Initialized
DEBUG - 2023-09-22 18:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:45:33 --> Controller Class Initialized
INFO - 2023-09-22 18:45:33 --> Model "Services_model" initialized
INFO - 2023-09-22 18:45:33 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:45:33 --> Helper loaded: form_helper
INFO - 2023-09-22 18:45:33 --> Form Validation Class Initialized
INFO - 2023-09-22 18:45:33 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:45:33 --> Final output sent to browser
DEBUG - 2023-09-22 18:45:33 --> Total execution time: 0.1081
INFO - 2023-09-22 18:45:34 --> Config Class Initialized
INFO - 2023-09-22 18:45:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:45:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:45:34 --> Utf8 Class Initialized
INFO - 2023-09-22 18:45:34 --> URI Class Initialized
INFO - 2023-09-22 18:45:34 --> Router Class Initialized
INFO - 2023-09-22 18:45:34 --> Output Class Initialized
INFO - 2023-09-22 18:45:34 --> Security Class Initialized
DEBUG - 2023-09-22 18:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:45:34 --> Input Class Initialized
INFO - 2023-09-22 18:45:34 --> Language Class Initialized
INFO - 2023-09-22 18:45:34 --> Loader Class Initialized
INFO - 2023-09-22 18:45:34 --> Helper loaded: url_helper
INFO - 2023-09-22 18:45:34 --> Helper loaded: file_helper
INFO - 2023-09-22 18:45:34 --> Database Driver Class Initialized
INFO - 2023-09-22 18:45:34 --> Email Class Initialized
DEBUG - 2023-09-22 18:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:45:34 --> Controller Class Initialized
INFO - 2023-09-22 18:45:34 --> Model "Services_model" initialized
INFO - 2023-09-22 18:45:34 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:45:34 --> Helper loaded: form_helper
INFO - 2023-09-22 18:45:34 --> Form Validation Class Initialized
INFO - 2023-09-22 18:45:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:45:34 --> Final output sent to browser
DEBUG - 2023-09-22 18:45:34 --> Total execution time: 0.1392
INFO - 2023-09-22 18:45:57 --> Config Class Initialized
INFO - 2023-09-22 18:45:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:45:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:45:57 --> Utf8 Class Initialized
INFO - 2023-09-22 18:45:57 --> URI Class Initialized
INFO - 2023-09-22 18:45:57 --> Router Class Initialized
INFO - 2023-09-22 18:45:57 --> Output Class Initialized
INFO - 2023-09-22 18:45:57 --> Security Class Initialized
DEBUG - 2023-09-22 18:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:45:57 --> Input Class Initialized
INFO - 2023-09-22 18:45:57 --> Language Class Initialized
INFO - 2023-09-22 18:45:57 --> Loader Class Initialized
INFO - 2023-09-22 18:45:57 --> Helper loaded: url_helper
INFO - 2023-09-22 18:45:57 --> Helper loaded: file_helper
INFO - 2023-09-22 18:45:57 --> Database Driver Class Initialized
INFO - 2023-09-22 18:45:57 --> Email Class Initialized
DEBUG - 2023-09-22 18:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:45:57 --> Controller Class Initialized
INFO - 2023-09-22 18:45:57 --> Model "Services_model" initialized
INFO - 2023-09-22 18:45:57 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:45:57 --> Helper loaded: form_helper
INFO - 2023-09-22 18:45:57 --> Form Validation Class Initialized
INFO - 2023-09-22 18:45:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:45:57 --> Config Class Initialized
INFO - 2023-09-22 18:45:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:45:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:45:57 --> Utf8 Class Initialized
INFO - 2023-09-22 18:45:57 --> URI Class Initialized
INFO - 2023-09-22 18:45:57 --> Router Class Initialized
INFO - 2023-09-22 18:45:57 --> Output Class Initialized
INFO - 2023-09-22 18:45:57 --> Security Class Initialized
DEBUG - 2023-09-22 18:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:45:57 --> Input Class Initialized
INFO - 2023-09-22 18:45:57 --> Language Class Initialized
INFO - 2023-09-22 18:45:57 --> Loader Class Initialized
INFO - 2023-09-22 18:45:57 --> Helper loaded: url_helper
INFO - 2023-09-22 18:45:57 --> Helper loaded: file_helper
INFO - 2023-09-22 18:45:57 --> Database Driver Class Initialized
INFO - 2023-09-22 18:45:57 --> Email Class Initialized
DEBUG - 2023-09-22 18:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:45:57 --> Controller Class Initialized
INFO - 2023-09-22 18:45:57 --> Model "Services_model" initialized
INFO - 2023-09-22 18:45:57 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:45:57 --> Helper loaded: form_helper
INFO - 2023-09-22 18:45:57 --> Form Validation Class Initialized
INFO - 2023-09-22 18:45:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:45:57 --> Final output sent to browser
DEBUG - 2023-09-22 18:45:57 --> Total execution time: 0.1583
INFO - 2023-09-22 18:46:13 --> Config Class Initialized
INFO - 2023-09-22 18:46:13 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:46:13 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:46:13 --> Utf8 Class Initialized
INFO - 2023-09-22 18:46:13 --> URI Class Initialized
INFO - 2023-09-22 18:46:13 --> Router Class Initialized
INFO - 2023-09-22 18:46:13 --> Output Class Initialized
INFO - 2023-09-22 18:46:13 --> Security Class Initialized
DEBUG - 2023-09-22 18:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:46:13 --> Input Class Initialized
INFO - 2023-09-22 18:46:13 --> Language Class Initialized
INFO - 2023-09-22 18:46:13 --> Loader Class Initialized
INFO - 2023-09-22 18:46:13 --> Helper loaded: url_helper
INFO - 2023-09-22 18:46:13 --> Helper loaded: file_helper
INFO - 2023-09-22 18:46:13 --> Database Driver Class Initialized
INFO - 2023-09-22 18:46:13 --> Email Class Initialized
DEBUG - 2023-09-22 18:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:46:13 --> Controller Class Initialized
INFO - 2023-09-22 18:46:13 --> Model "Services_model" initialized
INFO - 2023-09-22 18:46:13 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:46:13 --> Helper loaded: form_helper
INFO - 2023-09-22 18:46:13 --> Form Validation Class Initialized
INFO - 2023-09-22 18:46:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:46:13 --> Final output sent to browser
DEBUG - 2023-09-22 18:46:14 --> Total execution time: 0.1007
INFO - 2023-09-22 18:46:14 --> Config Class Initialized
INFO - 2023-09-22 18:46:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:46:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:46:14 --> Utf8 Class Initialized
INFO - 2023-09-22 18:46:14 --> URI Class Initialized
INFO - 2023-09-22 18:46:14 --> Router Class Initialized
INFO - 2023-09-22 18:46:14 --> Output Class Initialized
INFO - 2023-09-22 18:46:14 --> Security Class Initialized
DEBUG - 2023-09-22 18:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:46:14 --> Input Class Initialized
INFO - 2023-09-22 18:46:14 --> Language Class Initialized
INFO - 2023-09-22 18:46:14 --> Loader Class Initialized
INFO - 2023-09-22 18:46:14 --> Helper loaded: url_helper
INFO - 2023-09-22 18:46:14 --> Helper loaded: file_helper
INFO - 2023-09-22 18:46:14 --> Database Driver Class Initialized
INFO - 2023-09-22 18:46:14 --> Email Class Initialized
DEBUG - 2023-09-22 18:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:46:14 --> Controller Class Initialized
INFO - 2023-09-22 18:46:14 --> Model "Services_model" initialized
INFO - 2023-09-22 18:46:14 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:46:14 --> Helper loaded: form_helper
INFO - 2023-09-22 18:46:14 --> Form Validation Class Initialized
INFO - 2023-09-22 18:46:14 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:46:14 --> Final output sent to browser
DEBUG - 2023-09-22 18:46:14 --> Total execution time: 0.1417
INFO - 2023-09-22 18:46:34 --> Config Class Initialized
INFO - 2023-09-22 18:46:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:46:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:46:34 --> Utf8 Class Initialized
INFO - 2023-09-22 18:46:34 --> URI Class Initialized
INFO - 2023-09-22 18:46:34 --> Router Class Initialized
INFO - 2023-09-22 18:46:34 --> Output Class Initialized
INFO - 2023-09-22 18:46:34 --> Security Class Initialized
DEBUG - 2023-09-22 18:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:46:34 --> Input Class Initialized
INFO - 2023-09-22 18:46:34 --> Language Class Initialized
INFO - 2023-09-22 18:46:34 --> Loader Class Initialized
INFO - 2023-09-22 18:46:34 --> Helper loaded: url_helper
INFO - 2023-09-22 18:46:34 --> Helper loaded: file_helper
INFO - 2023-09-22 18:46:34 --> Database Driver Class Initialized
INFO - 2023-09-22 18:46:34 --> Email Class Initialized
DEBUG - 2023-09-22 18:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:46:34 --> Controller Class Initialized
INFO - 2023-09-22 18:46:34 --> Model "Services_model" initialized
INFO - 2023-09-22 18:46:34 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:46:34 --> Helper loaded: form_helper
INFO - 2023-09-22 18:46:34 --> Form Validation Class Initialized
INFO - 2023-09-22 18:46:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:46:34 --> Config Class Initialized
INFO - 2023-09-22 18:46:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:46:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:46:34 --> Utf8 Class Initialized
INFO - 2023-09-22 18:46:34 --> URI Class Initialized
INFO - 2023-09-22 18:46:34 --> Router Class Initialized
INFO - 2023-09-22 18:46:34 --> Output Class Initialized
INFO - 2023-09-22 18:46:34 --> Security Class Initialized
DEBUG - 2023-09-22 18:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:46:34 --> Input Class Initialized
INFO - 2023-09-22 18:46:34 --> Language Class Initialized
INFO - 2023-09-22 18:46:34 --> Loader Class Initialized
INFO - 2023-09-22 18:46:34 --> Helper loaded: url_helper
INFO - 2023-09-22 18:46:34 --> Helper loaded: file_helper
INFO - 2023-09-22 18:46:34 --> Database Driver Class Initialized
INFO - 2023-09-22 18:46:34 --> Email Class Initialized
DEBUG - 2023-09-22 18:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:46:34 --> Controller Class Initialized
INFO - 2023-09-22 18:46:34 --> Model "Services_model" initialized
INFO - 2023-09-22 18:46:34 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:46:34 --> Helper loaded: form_helper
INFO - 2023-09-22 18:46:34 --> Form Validation Class Initialized
INFO - 2023-09-22 18:46:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:46:34 --> Final output sent to browser
DEBUG - 2023-09-22 18:46:34 --> Total execution time: 0.1106
INFO - 2023-09-22 18:46:56 --> Config Class Initialized
INFO - 2023-09-22 18:46:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:46:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:46:56 --> Utf8 Class Initialized
INFO - 2023-09-22 18:46:56 --> URI Class Initialized
INFO - 2023-09-22 18:46:56 --> Router Class Initialized
INFO - 2023-09-22 18:46:56 --> Output Class Initialized
INFO - 2023-09-22 18:46:56 --> Security Class Initialized
DEBUG - 2023-09-22 18:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:46:56 --> Input Class Initialized
INFO - 2023-09-22 18:46:56 --> Language Class Initialized
INFO - 2023-09-22 18:46:56 --> Loader Class Initialized
INFO - 2023-09-22 18:46:56 --> Helper loaded: url_helper
INFO - 2023-09-22 18:46:56 --> Helper loaded: file_helper
INFO - 2023-09-22 18:46:56 --> Database Driver Class Initialized
INFO - 2023-09-22 18:46:56 --> Email Class Initialized
DEBUG - 2023-09-22 18:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:46:56 --> Controller Class Initialized
INFO - 2023-09-22 18:46:56 --> Model "Services_model" initialized
INFO - 2023-09-22 18:46:56 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:46:56 --> Helper loaded: form_helper
INFO - 2023-09-22 18:46:56 --> Form Validation Class Initialized
INFO - 2023-09-22 18:46:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:46:56 --> Final output sent to browser
DEBUG - 2023-09-22 18:46:56 --> Total execution time: 0.1138
INFO - 2023-09-22 18:46:56 --> Config Class Initialized
INFO - 2023-09-22 18:46:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:46:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:46:56 --> Utf8 Class Initialized
INFO - 2023-09-22 18:46:56 --> URI Class Initialized
INFO - 2023-09-22 18:46:56 --> Router Class Initialized
INFO - 2023-09-22 18:46:56 --> Output Class Initialized
INFO - 2023-09-22 18:46:56 --> Security Class Initialized
DEBUG - 2023-09-22 18:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:46:56 --> Input Class Initialized
INFO - 2023-09-22 18:46:56 --> Language Class Initialized
INFO - 2023-09-22 18:46:56 --> Loader Class Initialized
INFO - 2023-09-22 18:46:56 --> Helper loaded: url_helper
INFO - 2023-09-22 18:46:56 --> Helper loaded: file_helper
INFO - 2023-09-22 18:46:57 --> Database Driver Class Initialized
INFO - 2023-09-22 18:46:57 --> Email Class Initialized
DEBUG - 2023-09-22 18:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:46:57 --> Controller Class Initialized
INFO - 2023-09-22 18:46:57 --> Model "Services_model" initialized
INFO - 2023-09-22 18:46:57 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:46:57 --> Helper loaded: form_helper
INFO - 2023-09-22 18:46:57 --> Form Validation Class Initialized
INFO - 2023-09-22 18:46:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:46:57 --> Final output sent to browser
DEBUG - 2023-09-22 18:46:57 --> Total execution time: 0.1051
INFO - 2023-09-22 18:47:17 --> Config Class Initialized
INFO - 2023-09-22 18:47:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:47:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:47:17 --> Utf8 Class Initialized
INFO - 2023-09-22 18:47:17 --> URI Class Initialized
INFO - 2023-09-22 18:47:18 --> Router Class Initialized
INFO - 2023-09-22 18:47:18 --> Output Class Initialized
INFO - 2023-09-22 18:47:18 --> Security Class Initialized
DEBUG - 2023-09-22 18:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:47:18 --> Input Class Initialized
INFO - 2023-09-22 18:47:18 --> Language Class Initialized
INFO - 2023-09-22 18:47:18 --> Loader Class Initialized
INFO - 2023-09-22 18:47:18 --> Helper loaded: url_helper
INFO - 2023-09-22 18:47:18 --> Helper loaded: file_helper
INFO - 2023-09-22 18:47:18 --> Database Driver Class Initialized
INFO - 2023-09-22 18:47:18 --> Email Class Initialized
DEBUG - 2023-09-22 18:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:47:18 --> Controller Class Initialized
INFO - 2023-09-22 18:47:18 --> Model "Services_model" initialized
INFO - 2023-09-22 18:47:18 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:47:18 --> Helper loaded: form_helper
INFO - 2023-09-22 18:47:18 --> Form Validation Class Initialized
INFO - 2023-09-22 18:47:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:47:18 --> Final output sent to browser
DEBUG - 2023-09-22 18:47:18 --> Total execution time: 0.7661
INFO - 2023-09-22 18:47:22 --> Config Class Initialized
INFO - 2023-09-22 18:47:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:47:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:47:22 --> Utf8 Class Initialized
INFO - 2023-09-22 18:47:22 --> URI Class Initialized
INFO - 2023-09-22 18:47:22 --> Router Class Initialized
INFO - 2023-09-22 18:47:22 --> Output Class Initialized
INFO - 2023-09-22 18:47:22 --> Security Class Initialized
DEBUG - 2023-09-22 18:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:47:22 --> Input Class Initialized
INFO - 2023-09-22 18:47:22 --> Language Class Initialized
INFO - 2023-09-22 18:47:22 --> Loader Class Initialized
INFO - 2023-09-22 18:47:22 --> Helper loaded: url_helper
INFO - 2023-09-22 18:47:22 --> Helper loaded: file_helper
INFO - 2023-09-22 18:47:22 --> Database Driver Class Initialized
INFO - 2023-09-22 18:47:22 --> Email Class Initialized
DEBUG - 2023-09-22 18:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:47:23 --> Controller Class Initialized
INFO - 2023-09-22 18:47:23 --> Model "Services_model" initialized
INFO - 2023-09-22 18:47:23 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:47:23 --> Helper loaded: form_helper
INFO - 2023-09-22 18:47:23 --> Form Validation Class Initialized
INFO - 2023-09-22 18:47:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:47:23 --> Config Class Initialized
INFO - 2023-09-22 18:47:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:47:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:47:23 --> Utf8 Class Initialized
INFO - 2023-09-22 18:47:23 --> URI Class Initialized
INFO - 2023-09-22 18:47:23 --> Router Class Initialized
INFO - 2023-09-22 18:47:23 --> Output Class Initialized
INFO - 2023-09-22 18:47:23 --> Security Class Initialized
DEBUG - 2023-09-22 18:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:47:23 --> Input Class Initialized
INFO - 2023-09-22 18:47:23 --> Language Class Initialized
INFO - 2023-09-22 18:47:23 --> Loader Class Initialized
INFO - 2023-09-22 18:47:23 --> Helper loaded: url_helper
INFO - 2023-09-22 18:47:23 --> Helper loaded: file_helper
INFO - 2023-09-22 18:47:23 --> Database Driver Class Initialized
INFO - 2023-09-22 18:47:23 --> Email Class Initialized
DEBUG - 2023-09-22 18:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:47:23 --> Controller Class Initialized
INFO - 2023-09-22 18:47:23 --> Model "Services_model" initialized
INFO - 2023-09-22 18:47:23 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:47:23 --> Helper loaded: form_helper
INFO - 2023-09-22 18:47:23 --> Form Validation Class Initialized
INFO - 2023-09-22 18:47:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:47:23 --> Final output sent to browser
DEBUG - 2023-09-22 18:47:23 --> Total execution time: 0.1211
INFO - 2023-09-22 18:47:26 --> Config Class Initialized
INFO - 2023-09-22 18:47:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:47:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:47:26 --> Utf8 Class Initialized
INFO - 2023-09-22 18:47:26 --> URI Class Initialized
INFO - 2023-09-22 18:47:26 --> Router Class Initialized
INFO - 2023-09-22 18:47:26 --> Output Class Initialized
INFO - 2023-09-22 18:47:26 --> Security Class Initialized
DEBUG - 2023-09-22 18:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:47:26 --> Input Class Initialized
INFO - 2023-09-22 18:47:26 --> Language Class Initialized
INFO - 2023-09-22 18:47:26 --> Loader Class Initialized
INFO - 2023-09-22 18:47:26 --> Helper loaded: url_helper
INFO - 2023-09-22 18:47:26 --> Helper loaded: file_helper
INFO - 2023-09-22 18:47:26 --> Database Driver Class Initialized
INFO - 2023-09-22 18:47:26 --> Email Class Initialized
DEBUG - 2023-09-22 18:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:47:26 --> Controller Class Initialized
INFO - 2023-09-22 18:47:26 --> Model "Services_model" initialized
INFO - 2023-09-22 18:47:26 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:47:26 --> Helper loaded: form_helper
INFO - 2023-09-22 18:47:26 --> Form Validation Class Initialized
INFO - 2023-09-22 18:47:26 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:47:26 --> Final output sent to browser
DEBUG - 2023-09-22 18:47:26 --> Total execution time: 0.1246
INFO - 2023-09-22 18:47:27 --> Config Class Initialized
INFO - 2023-09-22 18:47:27 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:47:27 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:47:27 --> Utf8 Class Initialized
INFO - 2023-09-22 18:47:27 --> URI Class Initialized
INFO - 2023-09-22 18:47:27 --> Router Class Initialized
INFO - 2023-09-22 18:47:27 --> Output Class Initialized
INFO - 2023-09-22 18:47:27 --> Security Class Initialized
DEBUG - 2023-09-22 18:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:47:27 --> Input Class Initialized
INFO - 2023-09-22 18:47:27 --> Language Class Initialized
INFO - 2023-09-22 18:47:27 --> Loader Class Initialized
INFO - 2023-09-22 18:47:27 --> Helper loaded: url_helper
INFO - 2023-09-22 18:47:27 --> Helper loaded: file_helper
INFO - 2023-09-22 18:47:27 --> Database Driver Class Initialized
INFO - 2023-09-22 18:47:27 --> Email Class Initialized
DEBUG - 2023-09-22 18:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:47:27 --> Controller Class Initialized
INFO - 2023-09-22 18:47:27 --> Model "Services_model" initialized
INFO - 2023-09-22 18:47:27 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:47:27 --> Helper loaded: form_helper
INFO - 2023-09-22 18:47:27 --> Form Validation Class Initialized
INFO - 2023-09-22 18:47:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:47:27 --> Final output sent to browser
DEBUG - 2023-09-22 18:47:27 --> Total execution time: 0.1309
INFO - 2023-09-22 18:47:50 --> Config Class Initialized
INFO - 2023-09-22 18:47:50 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:47:50 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:47:50 --> Utf8 Class Initialized
INFO - 2023-09-22 18:47:50 --> URI Class Initialized
INFO - 2023-09-22 18:47:50 --> Router Class Initialized
INFO - 2023-09-22 18:47:50 --> Output Class Initialized
INFO - 2023-09-22 18:47:50 --> Security Class Initialized
DEBUG - 2023-09-22 18:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:47:50 --> Input Class Initialized
INFO - 2023-09-22 18:47:50 --> Language Class Initialized
INFO - 2023-09-22 18:47:50 --> Loader Class Initialized
INFO - 2023-09-22 18:47:50 --> Helper loaded: url_helper
INFO - 2023-09-22 18:47:50 --> Helper loaded: file_helper
INFO - 2023-09-22 18:47:50 --> Database Driver Class Initialized
INFO - 2023-09-22 18:47:50 --> Email Class Initialized
DEBUG - 2023-09-22 18:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:47:50 --> Controller Class Initialized
INFO - 2023-09-22 18:47:50 --> Model "Services_model" initialized
INFO - 2023-09-22 18:47:50 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:47:50 --> Helper loaded: form_helper
INFO - 2023-09-22 18:47:50 --> Form Validation Class Initialized
INFO - 2023-09-22 18:47:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:47:51 --> Config Class Initialized
INFO - 2023-09-22 18:47:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:47:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:47:51 --> Utf8 Class Initialized
INFO - 2023-09-22 18:47:51 --> URI Class Initialized
INFO - 2023-09-22 18:47:51 --> Router Class Initialized
INFO - 2023-09-22 18:47:51 --> Output Class Initialized
INFO - 2023-09-22 18:47:51 --> Security Class Initialized
DEBUG - 2023-09-22 18:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:47:51 --> Input Class Initialized
INFO - 2023-09-22 18:47:51 --> Language Class Initialized
INFO - 2023-09-22 18:47:51 --> Loader Class Initialized
INFO - 2023-09-22 18:47:51 --> Helper loaded: url_helper
INFO - 2023-09-22 18:47:51 --> Helper loaded: file_helper
INFO - 2023-09-22 18:47:51 --> Database Driver Class Initialized
INFO - 2023-09-22 18:47:51 --> Email Class Initialized
DEBUG - 2023-09-22 18:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:47:51 --> Controller Class Initialized
INFO - 2023-09-22 18:47:51 --> Model "Services_model" initialized
INFO - 2023-09-22 18:47:51 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:47:51 --> Helper loaded: form_helper
INFO - 2023-09-22 18:47:51 --> Form Validation Class Initialized
INFO - 2023-09-22 18:47:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:47:51 --> Final output sent to browser
DEBUG - 2023-09-22 18:47:51 --> Total execution time: 1.1922
INFO - 2023-09-22 18:47:57 --> Config Class Initialized
INFO - 2023-09-22 18:47:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:47:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:47:57 --> Utf8 Class Initialized
INFO - 2023-09-22 18:47:57 --> URI Class Initialized
INFO - 2023-09-22 18:47:57 --> Router Class Initialized
INFO - 2023-09-22 18:47:57 --> Output Class Initialized
INFO - 2023-09-22 18:47:57 --> Security Class Initialized
DEBUG - 2023-09-22 18:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:47:57 --> Input Class Initialized
INFO - 2023-09-22 18:47:57 --> Language Class Initialized
INFO - 2023-09-22 18:47:57 --> Loader Class Initialized
INFO - 2023-09-22 18:47:57 --> Helper loaded: url_helper
INFO - 2023-09-22 18:47:57 --> Helper loaded: file_helper
INFO - 2023-09-22 18:47:57 --> Database Driver Class Initialized
INFO - 2023-09-22 18:47:57 --> Email Class Initialized
DEBUG - 2023-09-22 18:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:47:57 --> Controller Class Initialized
INFO - 2023-09-22 18:47:57 --> Model "Services_model" initialized
INFO - 2023-09-22 18:47:57 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:47:57 --> Helper loaded: form_helper
INFO - 2023-09-22 18:47:57 --> Form Validation Class Initialized
INFO - 2023-09-22 18:47:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:47:57 --> Final output sent to browser
DEBUG - 2023-09-22 18:47:57 --> Total execution time: 0.1080
INFO - 2023-09-22 18:47:57 --> Config Class Initialized
INFO - 2023-09-22 18:47:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:47:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:47:57 --> Utf8 Class Initialized
INFO - 2023-09-22 18:47:57 --> URI Class Initialized
INFO - 2023-09-22 18:47:57 --> Router Class Initialized
INFO - 2023-09-22 18:47:57 --> Output Class Initialized
INFO - 2023-09-22 18:47:57 --> Security Class Initialized
DEBUG - 2023-09-22 18:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:47:57 --> Input Class Initialized
INFO - 2023-09-22 18:47:57 --> Language Class Initialized
INFO - 2023-09-22 18:47:57 --> Loader Class Initialized
INFO - 2023-09-22 18:47:57 --> Helper loaded: url_helper
INFO - 2023-09-22 18:47:57 --> Helper loaded: file_helper
INFO - 2023-09-22 18:47:57 --> Database Driver Class Initialized
INFO - 2023-09-22 18:47:57 --> Email Class Initialized
DEBUG - 2023-09-22 18:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:47:57 --> Controller Class Initialized
INFO - 2023-09-22 18:47:57 --> Model "Services_model" initialized
INFO - 2023-09-22 18:47:57 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:47:57 --> Helper loaded: form_helper
INFO - 2023-09-22 18:47:57 --> Form Validation Class Initialized
INFO - 2023-09-22 18:47:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:47:57 --> Final output sent to browser
DEBUG - 2023-09-22 18:47:57 --> Total execution time: 0.1547
INFO - 2023-09-22 18:48:15 --> Config Class Initialized
INFO - 2023-09-22 18:48:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:48:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:48:15 --> Utf8 Class Initialized
INFO - 2023-09-22 18:48:15 --> URI Class Initialized
INFO - 2023-09-22 18:48:15 --> Router Class Initialized
INFO - 2023-09-22 18:48:15 --> Output Class Initialized
INFO - 2023-09-22 18:48:15 --> Security Class Initialized
DEBUG - 2023-09-22 18:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:48:15 --> Input Class Initialized
INFO - 2023-09-22 18:48:15 --> Language Class Initialized
INFO - 2023-09-22 18:48:15 --> Loader Class Initialized
INFO - 2023-09-22 18:48:15 --> Helper loaded: url_helper
INFO - 2023-09-22 18:48:15 --> Helper loaded: file_helper
INFO - 2023-09-22 18:48:15 --> Database Driver Class Initialized
INFO - 2023-09-22 18:48:15 --> Email Class Initialized
DEBUG - 2023-09-22 18:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:48:16 --> Controller Class Initialized
INFO - 2023-09-22 18:48:16 --> Model "Services_model" initialized
INFO - 2023-09-22 18:48:16 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:48:16 --> Helper loaded: form_helper
INFO - 2023-09-22 18:48:16 --> Form Validation Class Initialized
INFO - 2023-09-22 18:48:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:48:16 --> Final output sent to browser
DEBUG - 2023-09-22 18:48:16 --> Total execution time: 0.9442
INFO - 2023-09-22 18:48:22 --> Config Class Initialized
INFO - 2023-09-22 18:48:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:48:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:48:22 --> Utf8 Class Initialized
INFO - 2023-09-22 18:48:22 --> URI Class Initialized
INFO - 2023-09-22 18:48:22 --> Router Class Initialized
INFO - 2023-09-22 18:48:22 --> Output Class Initialized
INFO - 2023-09-22 18:48:22 --> Security Class Initialized
DEBUG - 2023-09-22 18:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:48:22 --> Input Class Initialized
INFO - 2023-09-22 18:48:22 --> Language Class Initialized
INFO - 2023-09-22 18:48:22 --> Loader Class Initialized
INFO - 2023-09-22 18:48:22 --> Helper loaded: url_helper
INFO - 2023-09-22 18:48:22 --> Helper loaded: file_helper
INFO - 2023-09-22 18:48:22 --> Database Driver Class Initialized
INFO - 2023-09-22 18:48:22 --> Email Class Initialized
DEBUG - 2023-09-22 18:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:48:22 --> Controller Class Initialized
INFO - 2023-09-22 18:48:22 --> Model "Services_model" initialized
INFO - 2023-09-22 18:48:22 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:48:22 --> Helper loaded: form_helper
INFO - 2023-09-22 18:48:22 --> Form Validation Class Initialized
INFO - 2023-09-22 18:48:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:48:23 --> Config Class Initialized
INFO - 2023-09-22 18:48:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:48:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:48:23 --> Utf8 Class Initialized
INFO - 2023-09-22 18:48:23 --> URI Class Initialized
INFO - 2023-09-22 18:48:23 --> Router Class Initialized
INFO - 2023-09-22 18:48:23 --> Output Class Initialized
INFO - 2023-09-22 18:48:23 --> Security Class Initialized
DEBUG - 2023-09-22 18:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:48:23 --> Input Class Initialized
INFO - 2023-09-22 18:48:23 --> Language Class Initialized
INFO - 2023-09-22 18:48:23 --> Loader Class Initialized
INFO - 2023-09-22 18:48:23 --> Helper loaded: url_helper
INFO - 2023-09-22 18:48:23 --> Helper loaded: file_helper
INFO - 2023-09-22 18:48:23 --> Database Driver Class Initialized
INFO - 2023-09-22 18:48:23 --> Email Class Initialized
DEBUG - 2023-09-22 18:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:48:23 --> Controller Class Initialized
INFO - 2023-09-22 18:48:23 --> Model "Services_model" initialized
INFO - 2023-09-22 18:48:23 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:48:23 --> Helper loaded: form_helper
INFO - 2023-09-22 18:48:23 --> Form Validation Class Initialized
INFO - 2023-09-22 18:48:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:48:23 --> Final output sent to browser
DEBUG - 2023-09-22 18:48:23 --> Total execution time: 0.1178
INFO - 2023-09-22 18:48:24 --> Config Class Initialized
INFO - 2023-09-22 18:48:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:48:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:48:24 --> Utf8 Class Initialized
INFO - 2023-09-22 18:48:24 --> URI Class Initialized
INFO - 2023-09-22 18:48:24 --> Router Class Initialized
INFO - 2023-09-22 18:48:24 --> Output Class Initialized
INFO - 2023-09-22 18:48:25 --> Security Class Initialized
DEBUG - 2023-09-22 18:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:48:25 --> Input Class Initialized
INFO - 2023-09-22 18:48:25 --> Language Class Initialized
INFO - 2023-09-22 18:48:25 --> Loader Class Initialized
INFO - 2023-09-22 18:48:25 --> Helper loaded: url_helper
INFO - 2023-09-22 18:48:25 --> Helper loaded: file_helper
INFO - 2023-09-22 18:48:25 --> Database Driver Class Initialized
INFO - 2023-09-22 18:48:25 --> Email Class Initialized
DEBUG - 2023-09-22 18:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:48:25 --> Controller Class Initialized
INFO - 2023-09-22 18:48:25 --> Model "Services_model" initialized
INFO - 2023-09-22 18:48:25 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:48:25 --> Helper loaded: form_helper
INFO - 2023-09-22 18:48:25 --> Form Validation Class Initialized
INFO - 2023-09-22 18:48:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:48:25 --> Final output sent to browser
DEBUG - 2023-09-22 18:48:25 --> Total execution time: 0.1593
INFO - 2023-09-22 18:48:25 --> Config Class Initialized
INFO - 2023-09-22 18:48:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:48:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:48:25 --> Utf8 Class Initialized
INFO - 2023-09-22 18:48:25 --> URI Class Initialized
INFO - 2023-09-22 18:48:25 --> Router Class Initialized
INFO - 2023-09-22 18:48:25 --> Output Class Initialized
INFO - 2023-09-22 18:48:25 --> Security Class Initialized
DEBUG - 2023-09-22 18:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:48:25 --> Input Class Initialized
INFO - 2023-09-22 18:48:25 --> Language Class Initialized
INFO - 2023-09-22 18:48:25 --> Loader Class Initialized
INFO - 2023-09-22 18:48:25 --> Helper loaded: url_helper
INFO - 2023-09-22 18:48:25 --> Helper loaded: file_helper
INFO - 2023-09-22 18:48:25 --> Database Driver Class Initialized
INFO - 2023-09-22 18:48:25 --> Email Class Initialized
DEBUG - 2023-09-22 18:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:48:25 --> Controller Class Initialized
INFO - 2023-09-22 18:48:25 --> Model "Services_model" initialized
INFO - 2023-09-22 18:48:25 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:48:25 --> Helper loaded: form_helper
INFO - 2023-09-22 18:48:25 --> Form Validation Class Initialized
INFO - 2023-09-22 18:48:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:48:25 --> Final output sent to browser
DEBUG - 2023-09-22 18:48:25 --> Total execution time: 0.1669
INFO - 2023-09-22 18:49:03 --> Config Class Initialized
INFO - 2023-09-22 18:49:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:49:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:49:03 --> Utf8 Class Initialized
INFO - 2023-09-22 18:49:03 --> URI Class Initialized
INFO - 2023-09-22 18:49:03 --> Router Class Initialized
INFO - 2023-09-22 18:49:03 --> Output Class Initialized
INFO - 2023-09-22 18:49:03 --> Security Class Initialized
DEBUG - 2023-09-22 18:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:49:03 --> Input Class Initialized
INFO - 2023-09-22 18:49:03 --> Language Class Initialized
INFO - 2023-09-22 18:49:03 --> Loader Class Initialized
INFO - 2023-09-22 18:49:03 --> Helper loaded: url_helper
INFO - 2023-09-22 18:49:03 --> Helper loaded: file_helper
INFO - 2023-09-22 18:49:03 --> Database Driver Class Initialized
INFO - 2023-09-22 18:49:03 --> Email Class Initialized
DEBUG - 2023-09-22 18:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:49:03 --> Controller Class Initialized
INFO - 2023-09-22 18:49:03 --> Model "Services_model" initialized
INFO - 2023-09-22 18:49:03 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:49:03 --> Helper loaded: form_helper
INFO - 2023-09-22 18:49:03 --> Form Validation Class Initialized
INFO - 2023-09-22 18:49:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:49:03 --> Config Class Initialized
INFO - 2023-09-22 18:49:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:49:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:49:03 --> Utf8 Class Initialized
INFO - 2023-09-22 18:49:03 --> URI Class Initialized
INFO - 2023-09-22 18:49:03 --> Router Class Initialized
INFO - 2023-09-22 18:49:03 --> Output Class Initialized
INFO - 2023-09-22 18:49:03 --> Security Class Initialized
DEBUG - 2023-09-22 18:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:49:03 --> Input Class Initialized
INFO - 2023-09-22 18:49:03 --> Language Class Initialized
INFO - 2023-09-22 18:49:03 --> Loader Class Initialized
INFO - 2023-09-22 18:49:03 --> Helper loaded: url_helper
INFO - 2023-09-22 18:49:03 --> Helper loaded: file_helper
INFO - 2023-09-22 18:49:03 --> Database Driver Class Initialized
INFO - 2023-09-22 18:49:03 --> Email Class Initialized
DEBUG - 2023-09-22 18:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:49:03 --> Controller Class Initialized
INFO - 2023-09-22 18:49:03 --> Model "Services_model" initialized
INFO - 2023-09-22 18:49:03 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:49:03 --> Helper loaded: form_helper
INFO - 2023-09-22 18:49:03 --> Form Validation Class Initialized
INFO - 2023-09-22 18:49:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:49:03 --> Final output sent to browser
DEBUG - 2023-09-22 18:49:03 --> Total execution time: 0.1157
INFO - 2023-09-22 18:49:17 --> Config Class Initialized
INFO - 2023-09-22 18:49:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:49:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:49:17 --> Utf8 Class Initialized
INFO - 2023-09-22 18:49:17 --> URI Class Initialized
INFO - 2023-09-22 18:49:17 --> Router Class Initialized
INFO - 2023-09-22 18:49:17 --> Output Class Initialized
INFO - 2023-09-22 18:49:17 --> Security Class Initialized
DEBUG - 2023-09-22 18:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:49:17 --> Input Class Initialized
INFO - 2023-09-22 18:49:17 --> Language Class Initialized
INFO - 2023-09-22 18:49:17 --> Loader Class Initialized
INFO - 2023-09-22 18:49:17 --> Helper loaded: url_helper
INFO - 2023-09-22 18:49:17 --> Helper loaded: file_helper
INFO - 2023-09-22 18:49:17 --> Database Driver Class Initialized
INFO - 2023-09-22 18:49:17 --> Email Class Initialized
DEBUG - 2023-09-22 18:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:49:17 --> Controller Class Initialized
INFO - 2023-09-22 18:49:17 --> Model "Services_model" initialized
INFO - 2023-09-22 18:49:17 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:49:17 --> Helper loaded: form_helper
INFO - 2023-09-22 18:49:17 --> Form Validation Class Initialized
INFO - 2023-09-22 18:49:17 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:49:17 --> Final output sent to browser
DEBUG - 2023-09-22 18:49:17 --> Total execution time: 0.1215
INFO - 2023-09-22 18:49:18 --> Config Class Initialized
INFO - 2023-09-22 18:49:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:49:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:49:18 --> Utf8 Class Initialized
INFO - 2023-09-22 18:49:18 --> URI Class Initialized
INFO - 2023-09-22 18:49:18 --> Router Class Initialized
INFO - 2023-09-22 18:49:18 --> Output Class Initialized
INFO - 2023-09-22 18:49:18 --> Security Class Initialized
DEBUG - 2023-09-22 18:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:49:18 --> Input Class Initialized
INFO - 2023-09-22 18:49:18 --> Language Class Initialized
INFO - 2023-09-22 18:49:18 --> Loader Class Initialized
INFO - 2023-09-22 18:49:18 --> Helper loaded: url_helper
INFO - 2023-09-22 18:49:18 --> Helper loaded: file_helper
INFO - 2023-09-22 18:49:18 --> Database Driver Class Initialized
INFO - 2023-09-22 18:49:18 --> Email Class Initialized
DEBUG - 2023-09-22 18:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:49:18 --> Controller Class Initialized
INFO - 2023-09-22 18:49:18 --> Model "Services_model" initialized
INFO - 2023-09-22 18:49:18 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:49:18 --> Helper loaded: form_helper
INFO - 2023-09-22 18:49:18 --> Form Validation Class Initialized
INFO - 2023-09-22 18:49:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:49:18 --> Final output sent to browser
DEBUG - 2023-09-22 18:49:18 --> Total execution time: 0.0847
INFO - 2023-09-22 18:49:39 --> Config Class Initialized
INFO - 2023-09-22 18:49:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:49:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:49:39 --> Utf8 Class Initialized
INFO - 2023-09-22 18:49:39 --> URI Class Initialized
INFO - 2023-09-22 18:49:39 --> Router Class Initialized
INFO - 2023-09-22 18:49:39 --> Output Class Initialized
INFO - 2023-09-22 18:49:39 --> Security Class Initialized
DEBUG - 2023-09-22 18:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:49:39 --> Input Class Initialized
INFO - 2023-09-22 18:49:39 --> Language Class Initialized
INFO - 2023-09-22 18:49:39 --> Loader Class Initialized
INFO - 2023-09-22 18:49:39 --> Helper loaded: url_helper
INFO - 2023-09-22 18:49:39 --> Helper loaded: file_helper
INFO - 2023-09-22 18:49:39 --> Database Driver Class Initialized
INFO - 2023-09-22 18:49:39 --> Email Class Initialized
DEBUG - 2023-09-22 18:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:49:39 --> Controller Class Initialized
INFO - 2023-09-22 18:49:39 --> Model "Services_model" initialized
INFO - 2023-09-22 18:49:39 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:49:39 --> Helper loaded: form_helper
INFO - 2023-09-22 18:49:39 --> Form Validation Class Initialized
INFO - 2023-09-22 18:49:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:49:39 --> Config Class Initialized
INFO - 2023-09-22 18:49:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:49:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:49:39 --> Utf8 Class Initialized
INFO - 2023-09-22 18:49:39 --> URI Class Initialized
INFO - 2023-09-22 18:49:39 --> Router Class Initialized
INFO - 2023-09-22 18:49:39 --> Output Class Initialized
INFO - 2023-09-22 18:49:39 --> Security Class Initialized
DEBUG - 2023-09-22 18:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:49:39 --> Input Class Initialized
INFO - 2023-09-22 18:49:39 --> Language Class Initialized
INFO - 2023-09-22 18:49:39 --> Loader Class Initialized
INFO - 2023-09-22 18:49:39 --> Helper loaded: url_helper
INFO - 2023-09-22 18:49:39 --> Helper loaded: file_helper
INFO - 2023-09-22 18:49:39 --> Database Driver Class Initialized
INFO - 2023-09-22 18:49:39 --> Email Class Initialized
DEBUG - 2023-09-22 18:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:49:39 --> Controller Class Initialized
INFO - 2023-09-22 18:49:39 --> Model "Services_model" initialized
INFO - 2023-09-22 18:49:39 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:49:39 --> Helper loaded: form_helper
INFO - 2023-09-22 18:49:39 --> Form Validation Class Initialized
INFO - 2023-09-22 18:49:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:49:39 --> Final output sent to browser
DEBUG - 2023-09-22 18:49:39 --> Total execution time: 0.1517
INFO - 2023-09-22 18:49:45 --> Config Class Initialized
INFO - 2023-09-22 18:49:45 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:49:45 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:49:45 --> Utf8 Class Initialized
INFO - 2023-09-22 18:49:45 --> URI Class Initialized
INFO - 2023-09-22 18:49:45 --> Router Class Initialized
INFO - 2023-09-22 18:49:45 --> Output Class Initialized
INFO - 2023-09-22 18:49:45 --> Security Class Initialized
DEBUG - 2023-09-22 18:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:49:45 --> Input Class Initialized
INFO - 2023-09-22 18:49:45 --> Language Class Initialized
INFO - 2023-09-22 18:49:45 --> Loader Class Initialized
INFO - 2023-09-22 18:49:45 --> Helper loaded: url_helper
INFO - 2023-09-22 18:49:45 --> Helper loaded: file_helper
INFO - 2023-09-22 18:49:45 --> Database Driver Class Initialized
INFO - 2023-09-22 18:49:45 --> Email Class Initialized
DEBUG - 2023-09-22 18:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:49:45 --> Controller Class Initialized
INFO - 2023-09-22 18:49:45 --> Model "Services_model" initialized
INFO - 2023-09-22 18:49:45 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:49:45 --> Helper loaded: form_helper
INFO - 2023-09-22 18:49:45 --> Form Validation Class Initialized
INFO - 2023-09-22 18:49:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:49:45 --> Final output sent to browser
DEBUG - 2023-09-22 18:49:45 --> Total execution time: 0.1010
INFO - 2023-09-22 18:49:46 --> Config Class Initialized
INFO - 2023-09-22 18:49:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:49:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:49:46 --> Utf8 Class Initialized
INFO - 2023-09-22 18:49:46 --> URI Class Initialized
INFO - 2023-09-22 18:49:46 --> Router Class Initialized
INFO - 2023-09-22 18:49:46 --> Output Class Initialized
INFO - 2023-09-22 18:49:46 --> Security Class Initialized
DEBUG - 2023-09-22 18:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:49:46 --> Input Class Initialized
INFO - 2023-09-22 18:49:46 --> Language Class Initialized
INFO - 2023-09-22 18:49:46 --> Loader Class Initialized
INFO - 2023-09-22 18:49:46 --> Helper loaded: url_helper
INFO - 2023-09-22 18:49:46 --> Helper loaded: file_helper
INFO - 2023-09-22 18:49:46 --> Database Driver Class Initialized
INFO - 2023-09-22 18:49:46 --> Email Class Initialized
DEBUG - 2023-09-22 18:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:49:46 --> Controller Class Initialized
INFO - 2023-09-22 18:49:46 --> Model "Services_model" initialized
INFO - 2023-09-22 18:49:46 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:49:46 --> Helper loaded: form_helper
INFO - 2023-09-22 18:49:46 --> Form Validation Class Initialized
INFO - 2023-09-22 18:49:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-22 18:49:46 --> Final output sent to browser
DEBUG - 2023-09-22 18:49:46 --> Total execution time: 0.1540
INFO - 2023-09-22 18:50:08 --> Config Class Initialized
INFO - 2023-09-22 18:50:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:50:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:50:08 --> Utf8 Class Initialized
INFO - 2023-09-22 18:50:08 --> URI Class Initialized
INFO - 2023-09-22 18:50:08 --> Router Class Initialized
INFO - 2023-09-22 18:50:08 --> Output Class Initialized
INFO - 2023-09-22 18:50:08 --> Security Class Initialized
DEBUG - 2023-09-22 18:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:50:08 --> Input Class Initialized
INFO - 2023-09-22 18:50:08 --> Language Class Initialized
INFO - 2023-09-22 18:50:08 --> Loader Class Initialized
INFO - 2023-09-22 18:50:08 --> Helper loaded: url_helper
INFO - 2023-09-22 18:50:08 --> Helper loaded: file_helper
INFO - 2023-09-22 18:50:08 --> Database Driver Class Initialized
INFO - 2023-09-22 18:50:08 --> Email Class Initialized
DEBUG - 2023-09-22 18:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:50:08 --> Controller Class Initialized
INFO - 2023-09-22 18:50:08 --> Model "Services_model" initialized
INFO - 2023-09-22 18:50:08 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:50:08 --> Helper loaded: form_helper
INFO - 2023-09-22 18:50:08 --> Form Validation Class Initialized
INFO - 2023-09-22 18:50:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-22 18:50:08 --> Config Class Initialized
INFO - 2023-09-22 18:50:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:50:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:50:08 --> Utf8 Class Initialized
INFO - 2023-09-22 18:50:08 --> URI Class Initialized
INFO - 2023-09-22 18:50:08 --> Router Class Initialized
INFO - 2023-09-22 18:50:08 --> Output Class Initialized
INFO - 2023-09-22 18:50:08 --> Security Class Initialized
DEBUG - 2023-09-22 18:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:50:08 --> Input Class Initialized
INFO - 2023-09-22 18:50:08 --> Language Class Initialized
INFO - 2023-09-22 18:50:08 --> Loader Class Initialized
INFO - 2023-09-22 18:50:08 --> Helper loaded: url_helper
INFO - 2023-09-22 18:50:08 --> Helper loaded: file_helper
INFO - 2023-09-22 18:50:08 --> Database Driver Class Initialized
INFO - 2023-09-22 18:50:08 --> Email Class Initialized
DEBUG - 2023-09-22 18:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:50:08 --> Controller Class Initialized
INFO - 2023-09-22 18:50:08 --> Model "Services_model" initialized
INFO - 2023-09-22 18:50:08 --> Model "Services_cards_model" initialized
INFO - 2023-09-22 18:50:08 --> Helper loaded: form_helper
INFO - 2023-09-22 18:50:08 --> Form Validation Class Initialized
INFO - 2023-09-22 18:50:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-22 18:50:09 --> Final output sent to browser
DEBUG - 2023-09-22 18:50:09 --> Total execution time: 0.1827
INFO - 2023-09-22 18:50:10 --> Config Class Initialized
INFO - 2023-09-22 18:50:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 18:50:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 18:50:10 --> Utf8 Class Initialized
INFO - 2023-09-22 18:50:10 --> URI Class Initialized
INFO - 2023-09-22 18:50:10 --> Router Class Initialized
INFO - 2023-09-22 18:50:10 --> Output Class Initialized
INFO - 2023-09-22 18:50:10 --> Security Class Initialized
DEBUG - 2023-09-22 18:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 18:50:10 --> Input Class Initialized
INFO - 2023-09-22 18:50:10 --> Language Class Initialized
INFO - 2023-09-22 18:50:10 --> Loader Class Initialized
INFO - 2023-09-22 18:50:10 --> Helper loaded: url_helper
INFO - 2023-09-22 18:50:10 --> Helper loaded: file_helper
INFO - 2023-09-22 18:50:10 --> Database Driver Class Initialized
INFO - 2023-09-22 18:50:10 --> Email Class Initialized
DEBUG - 2023-09-22 18:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 18:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 18:50:10 --> Controller Class Initialized
INFO - 2023-09-22 18:50:10 --> Model "Contact_model" initialized
INFO - 2023-09-22 18:50:10 --> Model "Home_model" initialized
INFO - 2023-09-22 18:50:10 --> Helper loaded: download_helper
INFO - 2023-09-22 18:50:10 --> Helper loaded: form_helper
INFO - 2023-09-22 18:50:10 --> Form Validation Class Initialized
INFO - 2023-09-22 18:50:10 --> Helper loaded: custom_helper
INFO - 2023-09-22 18:50:10 --> Model "Social_media_model" initialized
INFO - 2023-09-22 18:50:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 18:50:11 --> Final output sent to browser
DEBUG - 2023-09-22 18:50:11 --> Total execution time: 0.1153
INFO - 2023-09-22 19:01:57 --> Config Class Initialized
INFO - 2023-09-22 19:01:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:01:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:01:57 --> Utf8 Class Initialized
INFO - 2023-09-22 19:01:57 --> URI Class Initialized
INFO - 2023-09-22 19:01:57 --> Router Class Initialized
INFO - 2023-09-22 19:01:57 --> Output Class Initialized
INFO - 2023-09-22 19:01:57 --> Security Class Initialized
DEBUG - 2023-09-22 19:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:01:57 --> Input Class Initialized
INFO - 2023-09-22 19:01:57 --> Language Class Initialized
INFO - 2023-09-22 19:01:57 --> Loader Class Initialized
INFO - 2023-09-22 19:01:57 --> Helper loaded: url_helper
INFO - 2023-09-22 19:01:57 --> Helper loaded: file_helper
INFO - 2023-09-22 19:01:57 --> Database Driver Class Initialized
INFO - 2023-09-22 19:01:57 --> Email Class Initialized
DEBUG - 2023-09-22 19:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:01:57 --> Controller Class Initialized
INFO - 2023-09-22 19:01:57 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:01:57 --> Model "Home_model" initialized
INFO - 2023-09-22 19:01:57 --> Helper loaded: download_helper
INFO - 2023-09-22 19:01:57 --> Helper loaded: form_helper
INFO - 2023-09-22 19:01:57 --> Form Validation Class Initialized
INFO - 2023-09-22 19:01:57 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:01:57 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:01:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:01:57 --> Final output sent to browser
DEBUG - 2023-09-22 19:01:57 --> Total execution time: 0.1389
INFO - 2023-09-22 19:02:10 --> Config Class Initialized
INFO - 2023-09-22 19:02:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:02:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:02:10 --> Utf8 Class Initialized
INFO - 2023-09-22 19:02:10 --> URI Class Initialized
INFO - 2023-09-22 19:02:10 --> Router Class Initialized
INFO - 2023-09-22 19:02:10 --> Output Class Initialized
INFO - 2023-09-22 19:02:10 --> Security Class Initialized
DEBUG - 2023-09-22 19:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:02:10 --> Input Class Initialized
INFO - 2023-09-22 19:02:10 --> Language Class Initialized
INFO - 2023-09-22 19:02:10 --> Loader Class Initialized
INFO - 2023-09-22 19:02:10 --> Helper loaded: url_helper
INFO - 2023-09-22 19:02:10 --> Helper loaded: file_helper
INFO - 2023-09-22 19:02:10 --> Database Driver Class Initialized
INFO - 2023-09-22 19:02:10 --> Email Class Initialized
DEBUG - 2023-09-22 19:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:02:10 --> Controller Class Initialized
INFO - 2023-09-22 19:02:10 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:02:10 --> Model "Home_model" initialized
INFO - 2023-09-22 19:02:10 --> Helper loaded: download_helper
INFO - 2023-09-22 19:02:10 --> Helper loaded: form_helper
INFO - 2023-09-22 19:02:10 --> Form Validation Class Initialized
INFO - 2023-09-22 19:02:10 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:02:10 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:02:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:02:10 --> Final output sent to browser
DEBUG - 2023-09-22 19:02:10 --> Total execution time: 0.1196
INFO - 2023-09-22 19:09:44 --> Config Class Initialized
INFO - 2023-09-22 19:09:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:09:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:09:44 --> Utf8 Class Initialized
INFO - 2023-09-22 19:09:44 --> URI Class Initialized
INFO - 2023-09-22 19:09:44 --> Router Class Initialized
INFO - 2023-09-22 19:09:44 --> Output Class Initialized
INFO - 2023-09-22 19:09:44 --> Security Class Initialized
DEBUG - 2023-09-22 19:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:09:44 --> Input Class Initialized
INFO - 2023-09-22 19:09:44 --> Language Class Initialized
INFO - 2023-09-22 19:09:44 --> Loader Class Initialized
INFO - 2023-09-22 19:09:44 --> Helper loaded: url_helper
INFO - 2023-09-22 19:09:44 --> Helper loaded: file_helper
INFO - 2023-09-22 19:09:44 --> Database Driver Class Initialized
INFO - 2023-09-22 19:09:44 --> Email Class Initialized
DEBUG - 2023-09-22 19:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:09:44 --> Controller Class Initialized
INFO - 2023-09-22 19:09:44 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:09:44 --> Model "Home_model" initialized
INFO - 2023-09-22 19:09:44 --> Helper loaded: download_helper
INFO - 2023-09-22 19:09:44 --> Helper loaded: form_helper
INFO - 2023-09-22 19:09:44 --> Form Validation Class Initialized
INFO - 2023-09-22 19:09:44 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:09:44 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:09:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:09:44 --> Final output sent to browser
DEBUG - 2023-09-22 19:09:44 --> Total execution time: 0.1687
INFO - 2023-09-22 19:10:05 --> Config Class Initialized
INFO - 2023-09-22 19:10:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:10:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:10:05 --> Utf8 Class Initialized
INFO - 2023-09-22 19:10:05 --> URI Class Initialized
INFO - 2023-09-22 19:10:05 --> Router Class Initialized
INFO - 2023-09-22 19:10:05 --> Output Class Initialized
INFO - 2023-09-22 19:10:05 --> Security Class Initialized
DEBUG - 2023-09-22 19:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:10:05 --> Input Class Initialized
INFO - 2023-09-22 19:10:05 --> Language Class Initialized
INFO - 2023-09-22 19:10:05 --> Loader Class Initialized
INFO - 2023-09-22 19:10:05 --> Helper loaded: url_helper
INFO - 2023-09-22 19:10:05 --> Helper loaded: file_helper
INFO - 2023-09-22 19:10:05 --> Database Driver Class Initialized
INFO - 2023-09-22 19:10:05 --> Email Class Initialized
DEBUG - 2023-09-22 19:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:10:05 --> Controller Class Initialized
INFO - 2023-09-22 19:10:05 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:10:05 --> Model "Home_model" initialized
INFO - 2023-09-22 19:10:05 --> Helper loaded: download_helper
INFO - 2023-09-22 19:10:05 --> Helper loaded: form_helper
INFO - 2023-09-22 19:10:05 --> Form Validation Class Initialized
INFO - 2023-09-22 19:10:05 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:10:05 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:10:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:10:05 --> Final output sent to browser
DEBUG - 2023-09-22 19:10:05 --> Total execution time: 0.1380
INFO - 2023-09-22 19:10:28 --> Config Class Initialized
INFO - 2023-09-22 19:10:29 --> Config Class Initialized
INFO - 2023-09-22 19:10:29 --> Hooks Class Initialized
INFO - 2023-09-22 19:10:29 --> Config Class Initialized
INFO - 2023-09-22 19:10:29 --> Config Class Initialized
INFO - 2023-09-22 19:10:30 --> Hooks Class Initialized
INFO - 2023-09-22 19:10:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:10:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-22 19:10:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:10:30 --> Hooks Class Initialized
INFO - 2023-09-22 19:10:30 --> Utf8 Class Initialized
DEBUG - 2023-09-22 19:10:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-22 19:10:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:10:30 --> Utf8 Class Initialized
INFO - 2023-09-22 19:10:30 --> Utf8 Class Initialized
INFO - 2023-09-22 19:10:30 --> URI Class Initialized
INFO - 2023-09-22 19:10:30 --> Utf8 Class Initialized
INFO - 2023-09-22 19:10:30 --> URI Class Initialized
INFO - 2023-09-22 19:10:30 --> URI Class Initialized
INFO - 2023-09-22 19:10:30 --> Router Class Initialized
INFO - 2023-09-22 19:10:30 --> Router Class Initialized
INFO - 2023-09-22 19:10:30 --> URI Class Initialized
INFO - 2023-09-22 19:10:30 --> Output Class Initialized
INFO - 2023-09-22 19:10:30 --> Router Class Initialized
INFO - 2023-09-22 19:10:30 --> Output Class Initialized
INFO - 2023-09-22 19:10:30 --> Output Class Initialized
INFO - 2023-09-22 19:10:30 --> Router Class Initialized
INFO - 2023-09-22 19:10:30 --> Security Class Initialized
INFO - 2023-09-22 19:10:30 --> Output Class Initialized
INFO - 2023-09-22 19:10:30 --> Security Class Initialized
INFO - 2023-09-22 19:10:30 --> Security Class Initialized
INFO - 2023-09-22 19:10:30 --> Security Class Initialized
DEBUG - 2023-09-22 19:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-22 19:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-22 19:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:10:30 --> Config Class Initialized
DEBUG - 2023-09-22 19:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:10:30 --> Input Class Initialized
INFO - 2023-09-22 19:10:30 --> Input Class Initialized
INFO - 2023-09-22 19:10:30 --> Input Class Initialized
INFO - 2023-09-22 19:10:30 --> Input Class Initialized
INFO - 2023-09-22 19:10:30 --> Hooks Class Initialized
INFO - 2023-09-22 19:10:30 --> Language Class Initialized
INFO - 2023-09-22 19:10:30 --> Language Class Initialized
INFO - 2023-09-22 19:10:30 --> Config Class Initialized
ERROR - 2023-09-22 19:10:30 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-22 19:10:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:10:30 --> Language Class Initialized
INFO - 2023-09-22 19:10:30 --> Language Class Initialized
INFO - 2023-09-22 19:10:30 --> Hooks Class Initialized
ERROR - 2023-09-22 19:10:30 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-22 19:10:30 --> UTF-8 Support Enabled
ERROR - 2023-09-22 19:10:30 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-22 19:10:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:10:30 --> Utf8 Class Initialized
INFO - 2023-09-22 19:10:30 --> Config Class Initialized
INFO - 2023-09-22 19:10:30 --> URI Class Initialized
INFO - 2023-09-22 19:10:30 --> Utf8 Class Initialized
INFO - 2023-09-22 19:10:30 --> Hooks Class Initialized
INFO - 2023-09-22 19:10:31 --> Router Class Initialized
INFO - 2023-09-22 19:10:31 --> URI Class Initialized
DEBUG - 2023-09-22 19:10:31 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:10:31 --> Output Class Initialized
INFO - 2023-09-22 19:10:31 --> Router Class Initialized
INFO - 2023-09-22 19:10:31 --> Utf8 Class Initialized
INFO - 2023-09-22 19:10:31 --> Security Class Initialized
INFO - 2023-09-22 19:10:31 --> Output Class Initialized
INFO - 2023-09-22 19:10:31 --> URI Class Initialized
DEBUG - 2023-09-22 19:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:10:31 --> Security Class Initialized
INFO - 2023-09-22 19:10:31 --> Router Class Initialized
INFO - 2023-09-22 19:10:31 --> Input Class Initialized
DEBUG - 2023-09-22 19:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:10:31 --> Output Class Initialized
INFO - 2023-09-22 19:10:31 --> Language Class Initialized
INFO - 2023-09-22 19:10:31 --> Input Class Initialized
INFO - 2023-09-22 19:10:31 --> Security Class Initialized
ERROR - 2023-09-22 19:10:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:10:31 --> Language Class Initialized
ERROR - 2023-09-22 19:10:31 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-22 19:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:10:31 --> Input Class Initialized
INFO - 2023-09-22 19:10:31 --> Language Class Initialized
ERROR - 2023-09-22 19:10:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:11:38 --> Config Class Initialized
INFO - 2023-09-22 19:11:38 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:11:38 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:11:38 --> Utf8 Class Initialized
INFO - 2023-09-22 19:11:38 --> URI Class Initialized
INFO - 2023-09-22 19:11:38 --> Router Class Initialized
INFO - 2023-09-22 19:11:38 --> Output Class Initialized
INFO - 2023-09-22 19:11:38 --> Security Class Initialized
DEBUG - 2023-09-22 19:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:11:38 --> Input Class Initialized
INFO - 2023-09-22 19:11:38 --> Language Class Initialized
INFO - 2023-09-22 19:11:38 --> Loader Class Initialized
INFO - 2023-09-22 19:11:38 --> Helper loaded: url_helper
INFO - 2023-09-22 19:11:38 --> Helper loaded: file_helper
INFO - 2023-09-22 19:11:38 --> Database Driver Class Initialized
INFO - 2023-09-22 19:11:38 --> Email Class Initialized
DEBUG - 2023-09-22 19:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:11:38 --> Controller Class Initialized
INFO - 2023-09-22 19:11:38 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:11:38 --> Model "Home_model" initialized
INFO - 2023-09-22 19:11:38 --> Helper loaded: download_helper
INFO - 2023-09-22 19:11:38 --> Helper loaded: form_helper
INFO - 2023-09-22 19:11:38 --> Form Validation Class Initialized
INFO - 2023-09-22 19:11:38 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:11:38 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:11:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:11:38 --> Final output sent to browser
DEBUG - 2023-09-22 19:11:38 --> Total execution time: 0.1166
INFO - 2023-09-22 19:13:05 --> Config Class Initialized
INFO - 2023-09-22 19:13:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:13:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:13:05 --> Utf8 Class Initialized
INFO - 2023-09-22 19:13:05 --> URI Class Initialized
INFO - 2023-09-22 19:13:05 --> Router Class Initialized
INFO - 2023-09-22 19:13:05 --> Output Class Initialized
INFO - 2023-09-22 19:13:05 --> Security Class Initialized
DEBUG - 2023-09-22 19:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:13:05 --> Input Class Initialized
INFO - 2023-09-22 19:13:05 --> Language Class Initialized
INFO - 2023-09-22 19:13:05 --> Loader Class Initialized
INFO - 2023-09-22 19:13:05 --> Helper loaded: url_helper
INFO - 2023-09-22 19:13:05 --> Helper loaded: file_helper
INFO - 2023-09-22 19:13:05 --> Database Driver Class Initialized
INFO - 2023-09-22 19:13:05 --> Email Class Initialized
DEBUG - 2023-09-22 19:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:13:05 --> Controller Class Initialized
INFO - 2023-09-22 19:13:05 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:13:05 --> Model "Home_model" initialized
INFO - 2023-09-22 19:13:05 --> Helper loaded: download_helper
INFO - 2023-09-22 19:13:05 --> Helper loaded: form_helper
INFO - 2023-09-22 19:13:05 --> Form Validation Class Initialized
INFO - 2023-09-22 19:13:05 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:13:05 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:13:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:13:05 --> Final output sent to browser
DEBUG - 2023-09-22 19:13:05 --> Total execution time: 0.5728
INFO - 2023-09-22 19:13:08 --> Config Class Initialized
INFO - 2023-09-22 19:13:08 --> Hooks Class Initialized
INFO - 2023-09-22 19:13:08 --> Config Class Initialized
INFO - 2023-09-22 19:13:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:13:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:13:09 --> Utf8 Class Initialized
DEBUG - 2023-09-22 19:13:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:13:09 --> URI Class Initialized
INFO - 2023-09-22 19:13:10 --> Config Class Initialized
INFO - 2023-09-22 19:13:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:13:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:13:10 --> Utf8 Class Initialized
INFO - 2023-09-22 19:13:10 --> URI Class Initialized
INFO - 2023-09-22 19:13:10 --> Router Class Initialized
INFO - 2023-09-22 19:13:10 --> Output Class Initialized
INFO - 2023-09-22 19:13:10 --> Security Class Initialized
DEBUG - 2023-09-22 19:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:13:10 --> Input Class Initialized
INFO - 2023-09-22 19:13:10 --> Language Class Initialized
ERROR - 2023-09-22 19:13:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:13:10 --> Config Class Initialized
INFO - 2023-09-22 19:13:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:13:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:13:10 --> Utf8 Class Initialized
INFO - 2023-09-22 19:13:10 --> URI Class Initialized
INFO - 2023-09-22 19:13:10 --> Router Class Initialized
INFO - 2023-09-22 19:13:10 --> Output Class Initialized
INFO - 2023-09-22 19:13:10 --> Security Class Initialized
DEBUG - 2023-09-22 19:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:13:10 --> Input Class Initialized
INFO - 2023-09-22 19:13:10 --> Language Class Initialized
ERROR - 2023-09-22 19:13:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:13:10 --> Config Class Initialized
INFO - 2023-09-22 19:13:10 --> Config Class Initialized
INFO - 2023-09-22 19:13:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:13:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:13:10 --> Utf8 Class Initialized
INFO - 2023-09-22 19:13:10 --> URI Class Initialized
INFO - 2023-09-22 19:13:10 --> Router Class Initialized
INFO - 2023-09-22 19:13:10 --> Output Class Initialized
INFO - 2023-09-22 19:13:10 --> Security Class Initialized
DEBUG - 2023-09-22 19:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:13:10 --> Input Class Initialized
INFO - 2023-09-22 19:13:10 --> Language Class Initialized
ERROR - 2023-09-22 19:13:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:13:10 --> Hooks Class Initialized
INFO - 2023-09-22 19:13:11 --> Router Class Initialized
INFO - 2023-09-22 19:13:11 --> Utf8 Class Initialized
INFO - 2023-09-22 19:13:11 --> Config Class Initialized
DEBUG - 2023-09-22 19:13:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:13:12 --> Output Class Initialized
INFO - 2023-09-22 19:13:12 --> URI Class Initialized
INFO - 2023-09-22 19:13:12 --> Utf8 Class Initialized
INFO - 2023-09-22 19:13:12 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:13:12 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:13:12 --> Security Class Initialized
INFO - 2023-09-22 19:13:12 --> Router Class Initialized
INFO - 2023-09-22 19:13:13 --> URI Class Initialized
INFO - 2023-09-22 19:13:13 --> Output Class Initialized
DEBUG - 2023-09-22 19:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:13:13 --> Utf8 Class Initialized
INFO - 2023-09-22 19:13:13 --> Security Class Initialized
INFO - 2023-09-22 19:13:14 --> Router Class Initialized
INFO - 2023-09-22 19:13:14 --> Input Class Initialized
INFO - 2023-09-22 19:13:14 --> URI Class Initialized
INFO - 2023-09-22 19:13:14 --> Language Class Initialized
INFO - 2023-09-22 19:13:14 --> Output Class Initialized
DEBUG - 2023-09-22 19:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:13:14 --> Router Class Initialized
ERROR - 2023-09-22 19:13:14 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:13:15 --> Security Class Initialized
DEBUG - 2023-09-22 19:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:13:15 --> Input Class Initialized
INFO - 2023-09-22 19:13:15 --> Language Class Initialized
ERROR - 2023-09-22 19:13:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:13:15 --> Input Class Initialized
INFO - 2023-09-22 19:13:15 --> Output Class Initialized
INFO - 2023-09-22 19:13:15 --> Security Class Initialized
INFO - 2023-09-22 19:13:15 --> Language Class Initialized
DEBUG - 2023-09-22 19:13:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-22 19:13:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:13:15 --> Input Class Initialized
INFO - 2023-09-22 19:13:15 --> Language Class Initialized
ERROR - 2023-09-22 19:13:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:13:39 --> Config Class Initialized
INFO - 2023-09-22 19:13:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:13:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:13:39 --> Utf8 Class Initialized
INFO - 2023-09-22 19:13:39 --> URI Class Initialized
INFO - 2023-09-22 19:13:39 --> Router Class Initialized
INFO - 2023-09-22 19:13:39 --> Output Class Initialized
INFO - 2023-09-22 19:13:39 --> Security Class Initialized
DEBUG - 2023-09-22 19:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:13:39 --> Input Class Initialized
INFO - 2023-09-22 19:13:39 --> Language Class Initialized
INFO - 2023-09-22 19:13:39 --> Loader Class Initialized
INFO - 2023-09-22 19:13:39 --> Helper loaded: url_helper
INFO - 2023-09-22 19:13:39 --> Helper loaded: file_helper
INFO - 2023-09-22 19:13:39 --> Database Driver Class Initialized
INFO - 2023-09-22 19:13:39 --> Email Class Initialized
DEBUG - 2023-09-22 19:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:13:39 --> Controller Class Initialized
INFO - 2023-09-22 19:13:39 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:13:39 --> Model "Home_model" initialized
INFO - 2023-09-22 19:13:39 --> Helper loaded: download_helper
INFO - 2023-09-22 19:13:39 --> Helper loaded: form_helper
INFO - 2023-09-22 19:13:39 --> Form Validation Class Initialized
INFO - 2023-09-22 19:13:39 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:13:39 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:13:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:13:39 --> Final output sent to browser
DEBUG - 2023-09-22 19:13:39 --> Total execution time: 0.1606
INFO - 2023-09-22 19:13:50 --> Config Class Initialized
INFO - 2023-09-22 19:13:50 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:13:50 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:13:50 --> Utf8 Class Initialized
INFO - 2023-09-22 19:13:50 --> URI Class Initialized
INFO - 2023-09-22 19:13:50 --> Router Class Initialized
INFO - 2023-09-22 19:13:50 --> Output Class Initialized
INFO - 2023-09-22 19:13:50 --> Security Class Initialized
DEBUG - 2023-09-22 19:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:13:50 --> Input Class Initialized
INFO - 2023-09-22 19:13:50 --> Language Class Initialized
INFO - 2023-09-22 19:13:50 --> Loader Class Initialized
INFO - 2023-09-22 19:13:50 --> Helper loaded: url_helper
INFO - 2023-09-22 19:13:50 --> Helper loaded: file_helper
INFO - 2023-09-22 19:13:50 --> Database Driver Class Initialized
INFO - 2023-09-22 19:13:50 --> Email Class Initialized
DEBUG - 2023-09-22 19:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:13:50 --> Controller Class Initialized
INFO - 2023-09-22 19:13:50 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:13:50 --> Model "Home_model" initialized
INFO - 2023-09-22 19:13:50 --> Helper loaded: download_helper
INFO - 2023-09-22 19:13:50 --> Helper loaded: form_helper
INFO - 2023-09-22 19:13:50 --> Form Validation Class Initialized
INFO - 2023-09-22 19:13:50 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:13:50 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:13:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:13:51 --> Final output sent to browser
DEBUG - 2023-09-22 19:13:51 --> Total execution time: 0.1043
INFO - 2023-09-22 19:13:56 --> Config Class Initialized
INFO - 2023-09-22 19:13:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:13:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:13:56 --> Utf8 Class Initialized
INFO - 2023-09-22 19:13:56 --> URI Class Initialized
INFO - 2023-09-22 19:13:56 --> Router Class Initialized
INFO - 2023-09-22 19:13:56 --> Output Class Initialized
INFO - 2023-09-22 19:13:56 --> Security Class Initialized
DEBUG - 2023-09-22 19:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:13:56 --> Input Class Initialized
INFO - 2023-09-22 19:13:56 --> Language Class Initialized
INFO - 2023-09-22 19:13:56 --> Loader Class Initialized
INFO - 2023-09-22 19:13:56 --> Helper loaded: url_helper
INFO - 2023-09-22 19:13:56 --> Helper loaded: file_helper
INFO - 2023-09-22 19:13:56 --> Database Driver Class Initialized
INFO - 2023-09-22 19:13:56 --> Email Class Initialized
DEBUG - 2023-09-22 19:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:13:56 --> Controller Class Initialized
INFO - 2023-09-22 19:13:56 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:13:56 --> Model "Home_model" initialized
INFO - 2023-09-22 19:13:56 --> Helper loaded: download_helper
INFO - 2023-09-22 19:13:56 --> Helper loaded: form_helper
INFO - 2023-09-22 19:13:56 --> Form Validation Class Initialized
INFO - 2023-09-22 19:13:56 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:13:56 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:13:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:13:56 --> Final output sent to browser
DEBUG - 2023-09-22 19:13:56 --> Total execution time: 0.1473
INFO - 2023-09-22 19:14:20 --> Config Class Initialized
INFO - 2023-09-22 19:14:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:14:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:14:20 --> Utf8 Class Initialized
INFO - 2023-09-22 19:14:20 --> URI Class Initialized
INFO - 2023-09-22 19:14:20 --> Router Class Initialized
INFO - 2023-09-22 19:14:20 --> Output Class Initialized
INFO - 2023-09-22 19:14:20 --> Security Class Initialized
DEBUG - 2023-09-22 19:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:14:20 --> Input Class Initialized
INFO - 2023-09-22 19:14:20 --> Language Class Initialized
INFO - 2023-09-22 19:14:20 --> Loader Class Initialized
INFO - 2023-09-22 19:14:20 --> Helper loaded: url_helper
INFO - 2023-09-22 19:14:20 --> Helper loaded: file_helper
INFO - 2023-09-22 19:14:20 --> Database Driver Class Initialized
INFO - 2023-09-22 19:14:20 --> Email Class Initialized
DEBUG - 2023-09-22 19:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:14:20 --> Controller Class Initialized
INFO - 2023-09-22 19:14:20 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:14:20 --> Model "Home_model" initialized
INFO - 2023-09-22 19:14:20 --> Helper loaded: download_helper
INFO - 2023-09-22 19:14:20 --> Helper loaded: form_helper
INFO - 2023-09-22 19:14:20 --> Form Validation Class Initialized
INFO - 2023-09-22 19:14:20 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:14:20 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:14:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:14:20 --> Final output sent to browser
DEBUG - 2023-09-22 19:14:20 --> Total execution time: 0.1163
INFO - 2023-09-22 19:14:59 --> Config Class Initialized
INFO - 2023-09-22 19:14:59 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:14:59 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:14:59 --> Utf8 Class Initialized
INFO - 2023-09-22 19:14:59 --> URI Class Initialized
INFO - 2023-09-22 19:14:59 --> Router Class Initialized
INFO - 2023-09-22 19:14:59 --> Output Class Initialized
INFO - 2023-09-22 19:14:59 --> Security Class Initialized
DEBUG - 2023-09-22 19:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:14:59 --> Input Class Initialized
INFO - 2023-09-22 19:14:59 --> Language Class Initialized
INFO - 2023-09-22 19:14:59 --> Loader Class Initialized
INFO - 2023-09-22 19:14:59 --> Helper loaded: url_helper
INFO - 2023-09-22 19:14:59 --> Helper loaded: file_helper
INFO - 2023-09-22 19:14:59 --> Database Driver Class Initialized
INFO - 2023-09-22 19:14:59 --> Email Class Initialized
DEBUG - 2023-09-22 19:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:14:59 --> Controller Class Initialized
INFO - 2023-09-22 19:14:59 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:14:59 --> Model "Home_model" initialized
INFO - 2023-09-22 19:14:59 --> Helper loaded: download_helper
INFO - 2023-09-22 19:14:59 --> Helper loaded: form_helper
INFO - 2023-09-22 19:14:59 --> Form Validation Class Initialized
INFO - 2023-09-22 19:14:59 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:14:59 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:14:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-22 19:14:59 --> Final output sent to browser
DEBUG - 2023-09-22 19:14:59 --> Total execution time: 0.1115
INFO - 2023-09-22 19:15:05 --> Config Class Initialized
INFO - 2023-09-22 19:15:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:15:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:15:05 --> Utf8 Class Initialized
INFO - 2023-09-22 19:15:05 --> URI Class Initialized
INFO - 2023-09-22 19:15:05 --> Router Class Initialized
INFO - 2023-09-22 19:15:05 --> Output Class Initialized
INFO - 2023-09-22 19:15:05 --> Security Class Initialized
DEBUG - 2023-09-22 19:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:15:05 --> Input Class Initialized
INFO - 2023-09-22 19:15:05 --> Language Class Initialized
INFO - 2023-09-22 19:15:05 --> Loader Class Initialized
INFO - 2023-09-22 19:15:05 --> Helper loaded: url_helper
INFO - 2023-09-22 19:15:05 --> Helper loaded: file_helper
INFO - 2023-09-22 19:15:05 --> Database Driver Class Initialized
INFO - 2023-09-22 19:15:05 --> Email Class Initialized
DEBUG - 2023-09-22 19:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:15:05 --> Controller Class Initialized
INFO - 2023-09-22 19:15:05 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:15:05 --> Model "Home_model" initialized
INFO - 2023-09-22 19:15:05 --> Helper loaded: download_helper
INFO - 2023-09-22 19:15:05 --> Helper loaded: form_helper
INFO - 2023-09-22 19:15:05 --> Form Validation Class Initialized
INFO - 2023-09-22 19:15:05 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:15:05 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:15:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:15:05 --> Final output sent to browser
DEBUG - 2023-09-22 19:15:05 --> Total execution time: 0.1085
INFO - 2023-09-22 19:15:23 --> Config Class Initialized
INFO - 2023-09-22 19:15:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:15:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:15:23 --> Utf8 Class Initialized
INFO - 2023-09-22 19:15:23 --> URI Class Initialized
INFO - 2023-09-22 19:15:23 --> Router Class Initialized
INFO - 2023-09-22 19:15:23 --> Output Class Initialized
INFO - 2023-09-22 19:15:23 --> Security Class Initialized
DEBUG - 2023-09-22 19:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:15:23 --> Input Class Initialized
INFO - 2023-09-22 19:15:23 --> Language Class Initialized
INFO - 2023-09-22 19:15:23 --> Loader Class Initialized
INFO - 2023-09-22 19:15:23 --> Helper loaded: url_helper
INFO - 2023-09-22 19:15:23 --> Helper loaded: file_helper
INFO - 2023-09-22 19:15:23 --> Database Driver Class Initialized
INFO - 2023-09-22 19:15:23 --> Email Class Initialized
DEBUG - 2023-09-22 19:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:15:23 --> Controller Class Initialized
INFO - 2023-09-22 19:15:23 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:15:23 --> Model "Home_model" initialized
INFO - 2023-09-22 19:15:23 --> Helper loaded: download_helper
INFO - 2023-09-22 19:15:23 --> Helper loaded: form_helper
INFO - 2023-09-22 19:15:23 --> Form Validation Class Initialized
INFO - 2023-09-22 19:15:23 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:15:23 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:15:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:15:24 --> Final output sent to browser
DEBUG - 2023-09-22 19:15:24 --> Total execution time: 0.0973
INFO - 2023-09-22 19:15:56 --> Config Class Initialized
INFO - 2023-09-22 19:15:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:15:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:15:56 --> Utf8 Class Initialized
INFO - 2023-09-22 19:15:56 --> URI Class Initialized
INFO - 2023-09-22 19:15:57 --> Router Class Initialized
INFO - 2023-09-22 19:15:57 --> Output Class Initialized
INFO - 2023-09-22 19:15:57 --> Security Class Initialized
DEBUG - 2023-09-22 19:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:15:57 --> Input Class Initialized
INFO - 2023-09-22 19:15:57 --> Language Class Initialized
INFO - 2023-09-22 19:15:57 --> Loader Class Initialized
INFO - 2023-09-22 19:15:57 --> Helper loaded: url_helper
INFO - 2023-09-22 19:15:57 --> Helper loaded: file_helper
INFO - 2023-09-22 19:15:57 --> Database Driver Class Initialized
INFO - 2023-09-22 19:15:57 --> Email Class Initialized
DEBUG - 2023-09-22 19:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:15:57 --> Controller Class Initialized
INFO - 2023-09-22 19:15:57 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:15:57 --> Model "Home_model" initialized
INFO - 2023-09-22 19:15:57 --> Helper loaded: download_helper
INFO - 2023-09-22 19:15:57 --> Helper loaded: form_helper
INFO - 2023-09-22 19:15:57 --> Form Validation Class Initialized
INFO - 2023-09-22 19:15:57 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:15:57 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:15:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:15:57 --> Final output sent to browser
DEBUG - 2023-09-22 19:15:57 --> Total execution time: 0.2131
INFO - 2023-09-22 19:16:04 --> Config Class Initialized
INFO - 2023-09-22 19:16:04 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:16:04 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:16:04 --> Utf8 Class Initialized
INFO - 2023-09-22 19:16:04 --> URI Class Initialized
INFO - 2023-09-22 19:16:04 --> Router Class Initialized
INFO - 2023-09-22 19:16:04 --> Output Class Initialized
INFO - 2023-09-22 19:16:04 --> Security Class Initialized
DEBUG - 2023-09-22 19:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:16:04 --> Input Class Initialized
INFO - 2023-09-22 19:16:04 --> Language Class Initialized
INFO - 2023-09-22 19:16:04 --> Loader Class Initialized
INFO - 2023-09-22 19:16:04 --> Helper loaded: url_helper
INFO - 2023-09-22 19:16:04 --> Helper loaded: file_helper
INFO - 2023-09-22 19:16:04 --> Database Driver Class Initialized
INFO - 2023-09-22 19:16:04 --> Email Class Initialized
DEBUG - 2023-09-22 19:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:16:04 --> Controller Class Initialized
INFO - 2023-09-22 19:16:04 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:16:04 --> Model "Home_model" initialized
INFO - 2023-09-22 19:16:04 --> Helper loaded: download_helper
INFO - 2023-09-22 19:16:04 --> Helper loaded: form_helper
INFO - 2023-09-22 19:16:04 --> Form Validation Class Initialized
INFO - 2023-09-22 19:16:04 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:16:04 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:16:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:16:04 --> Final output sent to browser
DEBUG - 2023-09-22 19:16:04 --> Total execution time: 0.0661
INFO - 2023-09-22 19:16:22 --> Config Class Initialized
INFO - 2023-09-22 19:16:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:16:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:16:22 --> Utf8 Class Initialized
INFO - 2023-09-22 19:16:22 --> URI Class Initialized
INFO - 2023-09-22 19:16:22 --> Router Class Initialized
INFO - 2023-09-22 19:16:22 --> Output Class Initialized
INFO - 2023-09-22 19:16:22 --> Security Class Initialized
DEBUG - 2023-09-22 19:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:16:22 --> Input Class Initialized
INFO - 2023-09-22 19:16:22 --> Language Class Initialized
INFO - 2023-09-22 19:16:22 --> Loader Class Initialized
INFO - 2023-09-22 19:16:22 --> Helper loaded: url_helper
INFO - 2023-09-22 19:16:22 --> Helper loaded: file_helper
INFO - 2023-09-22 19:16:22 --> Database Driver Class Initialized
INFO - 2023-09-22 19:16:22 --> Email Class Initialized
DEBUG - 2023-09-22 19:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:16:22 --> Controller Class Initialized
INFO - 2023-09-22 19:16:22 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:16:22 --> Model "Home_model" initialized
INFO - 2023-09-22 19:16:22 --> Helper loaded: download_helper
INFO - 2023-09-22 19:16:22 --> Helper loaded: form_helper
INFO - 2023-09-22 19:16:22 --> Form Validation Class Initialized
INFO - 2023-09-22 19:16:22 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:16:22 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:16:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:16:22 --> Final output sent to browser
DEBUG - 2023-09-22 19:16:22 --> Total execution time: 0.1303
INFO - 2023-09-22 19:16:45 --> Config Class Initialized
INFO - 2023-09-22 19:16:45 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:16:45 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:16:45 --> Utf8 Class Initialized
INFO - 2023-09-22 19:16:45 --> URI Class Initialized
DEBUG - 2023-09-22 19:16:45 --> No URI present. Default controller set.
INFO - 2023-09-22 19:16:45 --> Router Class Initialized
INFO - 2023-09-22 19:16:45 --> Output Class Initialized
INFO - 2023-09-22 19:16:45 --> Security Class Initialized
DEBUG - 2023-09-22 19:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:16:45 --> Input Class Initialized
INFO - 2023-09-22 19:16:45 --> Language Class Initialized
INFO - 2023-09-22 19:16:45 --> Loader Class Initialized
INFO - 2023-09-22 19:16:45 --> Helper loaded: url_helper
INFO - 2023-09-22 19:16:45 --> Helper loaded: file_helper
INFO - 2023-09-22 19:16:45 --> Database Driver Class Initialized
INFO - 2023-09-22 19:16:45 --> Email Class Initialized
DEBUG - 2023-09-22 19:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:16:45 --> Controller Class Initialized
INFO - 2023-09-22 19:16:45 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:16:45 --> Model "Home_model" initialized
INFO - 2023-09-22 19:16:45 --> Helper loaded: download_helper
INFO - 2023-09-22 19:16:45 --> Helper loaded: form_helper
INFO - 2023-09-22 19:16:45 --> Form Validation Class Initialized
INFO - 2023-09-22 19:16:45 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:16:45 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:16:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-22 19:16:45 --> Final output sent to browser
DEBUG - 2023-09-22 19:16:45 --> Total execution time: 0.0998
INFO - 2023-09-22 19:21:25 --> Config Class Initialized
INFO - 2023-09-22 19:21:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:21:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:21:25 --> Utf8 Class Initialized
INFO - 2023-09-22 19:21:25 --> URI Class Initialized
DEBUG - 2023-09-22 19:21:25 --> No URI present. Default controller set.
INFO - 2023-09-22 19:21:25 --> Router Class Initialized
INFO - 2023-09-22 19:21:25 --> Output Class Initialized
INFO - 2023-09-22 19:21:25 --> Security Class Initialized
DEBUG - 2023-09-22 19:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:21:25 --> Input Class Initialized
INFO - 2023-09-22 19:21:25 --> Language Class Initialized
INFO - 2023-09-22 19:21:25 --> Loader Class Initialized
INFO - 2023-09-22 19:21:25 --> Helper loaded: url_helper
INFO - 2023-09-22 19:21:25 --> Helper loaded: file_helper
INFO - 2023-09-22 19:21:25 --> Database Driver Class Initialized
INFO - 2023-09-22 19:21:25 --> Email Class Initialized
DEBUG - 2023-09-22 19:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:21:25 --> Controller Class Initialized
INFO - 2023-09-22 19:21:25 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:21:25 --> Model "Home_model" initialized
INFO - 2023-09-22 19:21:25 --> Helper loaded: download_helper
INFO - 2023-09-22 19:21:25 --> Helper loaded: form_helper
INFO - 2023-09-22 19:21:25 --> Form Validation Class Initialized
INFO - 2023-09-22 19:21:26 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:21:26 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:21:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-22 19:21:26 --> Final output sent to browser
DEBUG - 2023-09-22 19:21:26 --> Total execution time: 0.2407
INFO - 2023-09-22 19:21:32 --> Config Class Initialized
INFO - 2023-09-22 19:21:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:21:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:21:32 --> Utf8 Class Initialized
INFO - 2023-09-22 19:21:32 --> URI Class Initialized
INFO - 2023-09-22 19:21:32 --> Router Class Initialized
INFO - 2023-09-22 19:21:32 --> Output Class Initialized
INFO - 2023-09-22 19:21:32 --> Security Class Initialized
DEBUG - 2023-09-22 19:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:21:32 --> Input Class Initialized
INFO - 2023-09-22 19:21:32 --> Language Class Initialized
INFO - 2023-09-22 19:21:32 --> Loader Class Initialized
INFO - 2023-09-22 19:21:32 --> Helper loaded: url_helper
INFO - 2023-09-22 19:21:32 --> Helper loaded: file_helper
INFO - 2023-09-22 19:21:32 --> Database Driver Class Initialized
INFO - 2023-09-22 19:21:32 --> Email Class Initialized
DEBUG - 2023-09-22 19:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:21:32 --> Controller Class Initialized
INFO - 2023-09-22 19:21:32 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:21:32 --> Model "Home_model" initialized
INFO - 2023-09-22 19:21:32 --> Helper loaded: download_helper
INFO - 2023-09-22 19:21:32 --> Helper loaded: form_helper
INFO - 2023-09-22 19:21:32 --> Form Validation Class Initialized
INFO - 2023-09-22 19:21:32 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:21:32 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:21:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-22 19:21:32 --> Final output sent to browser
DEBUG - 2023-09-22 19:21:32 --> Total execution time: 0.0571
INFO - 2023-09-22 19:21:35 --> Config Class Initialized
INFO - 2023-09-22 19:21:35 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:21:35 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:21:35 --> Utf8 Class Initialized
INFO - 2023-09-22 19:21:35 --> URI Class Initialized
DEBUG - 2023-09-22 19:21:35 --> No URI present. Default controller set.
INFO - 2023-09-22 19:21:35 --> Router Class Initialized
INFO - 2023-09-22 19:21:35 --> Output Class Initialized
INFO - 2023-09-22 19:21:35 --> Security Class Initialized
DEBUG - 2023-09-22 19:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:21:35 --> Input Class Initialized
INFO - 2023-09-22 19:21:35 --> Language Class Initialized
INFO - 2023-09-22 19:21:35 --> Loader Class Initialized
INFO - 2023-09-22 19:21:35 --> Helper loaded: url_helper
INFO - 2023-09-22 19:21:35 --> Helper loaded: file_helper
INFO - 2023-09-22 19:21:35 --> Database Driver Class Initialized
INFO - 2023-09-22 19:21:35 --> Email Class Initialized
DEBUG - 2023-09-22 19:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:21:35 --> Controller Class Initialized
INFO - 2023-09-22 19:21:35 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:21:35 --> Model "Home_model" initialized
INFO - 2023-09-22 19:21:35 --> Helper loaded: download_helper
INFO - 2023-09-22 19:21:35 --> Helper loaded: form_helper
INFO - 2023-09-22 19:21:35 --> Form Validation Class Initialized
INFO - 2023-09-22 19:21:35 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:21:35 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:21:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-22 19:21:35 --> Final output sent to browser
DEBUG - 2023-09-22 19:21:35 --> Total execution time: 0.0725
INFO - 2023-09-22 19:22:16 --> Config Class Initialized
INFO - 2023-09-22 19:22:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:22:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:22:16 --> Utf8 Class Initialized
INFO - 2023-09-22 19:22:16 --> URI Class Initialized
INFO - 2023-09-22 19:22:16 --> Router Class Initialized
INFO - 2023-09-22 19:22:16 --> Output Class Initialized
INFO - 2023-09-22 19:22:16 --> Security Class Initialized
DEBUG - 2023-09-22 19:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:22:16 --> Input Class Initialized
INFO - 2023-09-22 19:22:16 --> Language Class Initialized
INFO - 2023-09-22 19:22:16 --> Loader Class Initialized
INFO - 2023-09-22 19:22:16 --> Helper loaded: url_helper
INFO - 2023-09-22 19:22:16 --> Helper loaded: file_helper
INFO - 2023-09-22 19:22:16 --> Database Driver Class Initialized
INFO - 2023-09-22 19:22:16 --> Email Class Initialized
DEBUG - 2023-09-22 19:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:22:16 --> Controller Class Initialized
INFO - 2023-09-22 19:22:16 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:22:16 --> Model "Home_model" initialized
INFO - 2023-09-22 19:22:16 --> Helper loaded: download_helper
INFO - 2023-09-22 19:22:16 --> Helper loaded: form_helper
INFO - 2023-09-22 19:22:16 --> Form Validation Class Initialized
INFO - 2023-09-22 19:22:16 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:22:16 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:22:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:22:16 --> Final output sent to browser
DEBUG - 2023-09-22 19:22:16 --> Total execution time: 0.1143
INFO - 2023-09-22 19:22:35 --> Config Class Initialized
INFO - 2023-09-22 19:22:35 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:22:35 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:22:35 --> Utf8 Class Initialized
INFO - 2023-09-22 19:22:35 --> URI Class Initialized
DEBUG - 2023-09-22 19:22:35 --> No URI present. Default controller set.
INFO - 2023-09-22 19:22:35 --> Router Class Initialized
INFO - 2023-09-22 19:22:35 --> Output Class Initialized
INFO - 2023-09-22 19:22:35 --> Security Class Initialized
DEBUG - 2023-09-22 19:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:22:35 --> Input Class Initialized
INFO - 2023-09-22 19:22:35 --> Language Class Initialized
INFO - 2023-09-22 19:22:35 --> Loader Class Initialized
INFO - 2023-09-22 19:22:35 --> Helper loaded: url_helper
INFO - 2023-09-22 19:22:35 --> Helper loaded: file_helper
INFO - 2023-09-22 19:22:35 --> Database Driver Class Initialized
INFO - 2023-09-22 19:22:35 --> Email Class Initialized
DEBUG - 2023-09-22 19:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:22:35 --> Controller Class Initialized
INFO - 2023-09-22 19:22:35 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:22:35 --> Model "Home_model" initialized
INFO - 2023-09-22 19:22:35 --> Helper loaded: download_helper
INFO - 2023-09-22 19:22:35 --> Helper loaded: form_helper
INFO - 2023-09-22 19:22:35 --> Form Validation Class Initialized
INFO - 2023-09-22 19:22:35 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:22:35 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:22:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-22 19:22:35 --> Final output sent to browser
DEBUG - 2023-09-22 19:22:35 --> Total execution time: 0.1883
INFO - 2023-09-22 19:22:43 --> Config Class Initialized
INFO - 2023-09-22 19:22:43 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:22:43 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:22:43 --> Utf8 Class Initialized
INFO - 2023-09-22 19:22:43 --> URI Class Initialized
INFO - 2023-09-22 19:22:43 --> Router Class Initialized
INFO - 2023-09-22 19:22:43 --> Output Class Initialized
INFO - 2023-09-22 19:22:43 --> Security Class Initialized
DEBUG - 2023-09-22 19:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:22:43 --> Input Class Initialized
INFO - 2023-09-22 19:22:43 --> Language Class Initialized
INFO - 2023-09-22 19:22:43 --> Loader Class Initialized
INFO - 2023-09-22 19:22:43 --> Helper loaded: url_helper
INFO - 2023-09-22 19:22:43 --> Helper loaded: file_helper
INFO - 2023-09-22 19:22:43 --> Database Driver Class Initialized
INFO - 2023-09-22 19:22:43 --> Email Class Initialized
DEBUG - 2023-09-22 19:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:22:43 --> Controller Class Initialized
INFO - 2023-09-22 19:22:43 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:22:43 --> Model "Home_model" initialized
INFO - 2023-09-22 19:22:43 --> Helper loaded: download_helper
INFO - 2023-09-22 19:22:43 --> Helper loaded: form_helper
INFO - 2023-09-22 19:22:43 --> Form Validation Class Initialized
INFO - 2023-09-22 19:22:43 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:22:43 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:22:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:22:43 --> Final output sent to browser
DEBUG - 2023-09-22 19:22:43 --> Total execution time: 0.1250
INFO - 2023-09-22 19:23:38 --> Config Class Initialized
INFO - 2023-09-22 19:23:38 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:23:38 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:23:38 --> Utf8 Class Initialized
INFO - 2023-09-22 19:23:38 --> URI Class Initialized
INFO - 2023-09-22 19:23:38 --> Router Class Initialized
INFO - 2023-09-22 19:23:38 --> Output Class Initialized
INFO - 2023-09-22 19:23:38 --> Security Class Initialized
DEBUG - 2023-09-22 19:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:23:38 --> Input Class Initialized
INFO - 2023-09-22 19:23:38 --> Language Class Initialized
ERROR - 2023-09-22 19:23:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:23:39 --> Config Class Initialized
INFO - 2023-09-22 19:23:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:23:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:23:39 --> Utf8 Class Initialized
INFO - 2023-09-22 19:23:40 --> Config Class Initialized
INFO - 2023-09-22 19:23:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:23:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:23:40 --> Utf8 Class Initialized
INFO - 2023-09-22 19:23:40 --> URI Class Initialized
INFO - 2023-09-22 19:23:40 --> Router Class Initialized
INFO - 2023-09-22 19:23:40 --> Output Class Initialized
INFO - 2023-09-22 19:23:40 --> Security Class Initialized
DEBUG - 2023-09-22 19:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:23:40 --> URI Class Initialized
INFO - 2023-09-22 19:23:40 --> Input Class Initialized
INFO - 2023-09-22 19:23:40 --> Language Class Initialized
ERROR - 2023-09-22 19:23:40 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:23:40 --> Router Class Initialized
INFO - 2023-09-22 19:23:40 --> Output Class Initialized
INFO - 2023-09-22 19:23:40 --> Security Class Initialized
DEBUG - 2023-09-22 19:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:23:40 --> Input Class Initialized
INFO - 2023-09-22 19:23:40 --> Language Class Initialized
ERROR - 2023-09-22 19:23:40 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:23:41 --> Config Class Initialized
INFO - 2023-09-22 19:23:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:23:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:23:41 --> Utf8 Class Initialized
INFO - 2023-09-22 19:23:41 --> URI Class Initialized
INFO - 2023-09-22 19:23:42 --> Router Class Initialized
INFO - 2023-09-22 19:23:42 --> Output Class Initialized
INFO - 2023-09-22 19:23:42 --> Security Class Initialized
DEBUG - 2023-09-22 19:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:23:43 --> Input Class Initialized
INFO - 2023-09-22 19:23:43 --> Language Class Initialized
ERROR - 2023-09-22 19:23:43 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:23:43 --> Config Class Initialized
INFO - 2023-09-22 19:23:43 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:23:43 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:23:43 --> Utf8 Class Initialized
INFO - 2023-09-22 19:23:43 --> URI Class Initialized
INFO - 2023-09-22 19:23:43 --> Router Class Initialized
INFO - 2023-09-22 19:23:43 --> Output Class Initialized
INFO - 2023-09-22 19:23:43 --> Security Class Initialized
DEBUG - 2023-09-22 19:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:23:43 --> Input Class Initialized
INFO - 2023-09-22 19:23:43 --> Language Class Initialized
ERROR - 2023-09-22 19:23:43 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:23:44 --> Config Class Initialized
INFO - 2023-09-22 19:23:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:23:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:23:44 --> Utf8 Class Initialized
INFO - 2023-09-22 19:23:44 --> URI Class Initialized
INFO - 2023-09-22 19:23:44 --> Router Class Initialized
INFO - 2023-09-22 19:23:44 --> Output Class Initialized
INFO - 2023-09-22 19:23:44 --> Security Class Initialized
DEBUG - 2023-09-22 19:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:23:44 --> Input Class Initialized
INFO - 2023-09-22 19:23:44 --> Language Class Initialized
ERROR - 2023-09-22 19:23:44 --> 404 Page Not Found: Assets/home
INFO - 2023-09-22 19:27:47 --> Config Class Initialized
INFO - 2023-09-22 19:27:47 --> Hooks Class Initialized
DEBUG - 2023-09-22 19:27:47 --> UTF-8 Support Enabled
INFO - 2023-09-22 19:27:47 --> Utf8 Class Initialized
INFO - 2023-09-22 19:27:47 --> URI Class Initialized
INFO - 2023-09-22 19:27:47 --> Router Class Initialized
INFO - 2023-09-22 19:27:47 --> Output Class Initialized
INFO - 2023-09-22 19:27:47 --> Security Class Initialized
DEBUG - 2023-09-22 19:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 19:27:47 --> Input Class Initialized
INFO - 2023-09-22 19:27:47 --> Language Class Initialized
INFO - 2023-09-22 19:27:47 --> Loader Class Initialized
INFO - 2023-09-22 19:27:47 --> Helper loaded: url_helper
INFO - 2023-09-22 19:27:47 --> Helper loaded: file_helper
INFO - 2023-09-22 19:27:47 --> Database Driver Class Initialized
INFO - 2023-09-22 19:27:47 --> Email Class Initialized
DEBUG - 2023-09-22 19:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-22 19:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 19:27:47 --> Controller Class Initialized
INFO - 2023-09-22 19:27:47 --> Model "Contact_model" initialized
INFO - 2023-09-22 19:27:47 --> Model "Home_model" initialized
INFO - 2023-09-22 19:27:47 --> Helper loaded: download_helper
INFO - 2023-09-22 19:27:47 --> Helper loaded: form_helper
INFO - 2023-09-22 19:27:47 --> Form Validation Class Initialized
INFO - 2023-09-22 19:27:47 --> Helper loaded: custom_helper
INFO - 2023-09-22 19:27:47 --> Model "Social_media_model" initialized
INFO - 2023-09-22 19:27:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-22 19:27:47 --> Final output sent to browser
DEBUG - 2023-09-22 19:27:48 --> Total execution time: 0.1660
