<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-15 11:36:49 --> Config Class Initialized
INFO - 2023-08-15 11:36:49 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:36:49 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:36:49 --> Utf8 Class Initialized
INFO - 2023-08-15 11:36:49 --> URI Class Initialized
INFO - 2023-08-15 11:36:50 --> Router Class Initialized
INFO - 2023-08-15 11:36:50 --> Output Class Initialized
INFO - 2023-08-15 11:36:50 --> Security Class Initialized
DEBUG - 2023-08-15 11:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:36:50 --> Input Class Initialized
INFO - 2023-08-15 11:36:50 --> Language Class Initialized
ERROR - 2023-08-15 11:36:50 --> 404 Page Not Found: DW/admin
INFO - 2023-08-15 11:36:56 --> Config Class Initialized
INFO - 2023-08-15 11:36:56 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:36:56 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:36:56 --> Utf8 Class Initialized
INFO - 2023-08-15 11:36:56 --> URI Class Initialized
INFO - 2023-08-15 11:36:56 --> Router Class Initialized
INFO - 2023-08-15 11:36:56 --> Output Class Initialized
INFO - 2023-08-15 11:36:56 --> Security Class Initialized
DEBUG - 2023-08-15 11:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:36:56 --> Input Class Initialized
INFO - 2023-08-15 11:36:56 --> Language Class Initialized
ERROR - 2023-08-15 11:36:56 --> 404 Page Not Found: DW/admin
INFO - 2023-08-15 11:37:09 --> Config Class Initialized
INFO - 2023-08-15 11:37:09 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:37:09 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:37:09 --> Utf8 Class Initialized
INFO - 2023-08-15 11:37:09 --> URI Class Initialized
INFO - 2023-08-15 11:37:09 --> Router Class Initialized
INFO - 2023-08-15 11:37:09 --> Output Class Initialized
INFO - 2023-08-15 11:37:09 --> Security Class Initialized
DEBUG - 2023-08-15 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:37:09 --> Input Class Initialized
INFO - 2023-08-15 11:37:09 --> Language Class Initialized
ERROR - 2023-08-15 11:37:09 --> 404 Page Not Found: DW/admin
INFO - 2023-08-15 11:37:21 --> Config Class Initialized
INFO - 2023-08-15 11:37:21 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:37:21 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:37:21 --> Utf8 Class Initialized
INFO - 2023-08-15 11:37:21 --> URI Class Initialized
INFO - 2023-08-15 11:37:21 --> Router Class Initialized
INFO - 2023-08-15 11:37:21 --> Output Class Initialized
INFO - 2023-08-15 11:37:21 --> Security Class Initialized
DEBUG - 2023-08-15 11:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:37:21 --> Input Class Initialized
INFO - 2023-08-15 11:37:21 --> Language Class Initialized
INFO - 2023-08-15 11:37:22 --> Loader Class Initialized
INFO - 2023-08-15 11:37:22 --> Helper loaded: url_helper
INFO - 2023-08-15 11:37:22 --> Helper loaded: file_helper
INFO - 2023-08-15 11:37:22 --> Database Driver Class Initialized
INFO - 2023-08-15 11:37:22 --> Email Class Initialized
DEBUG - 2023-08-15 11:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:37:24 --> Controller Class Initialized
INFO - 2023-08-15 11:37:24 --> Model "Blog_model" initialized
INFO - 2023-08-15 11:37:25 --> Helper loaded: form_helper
INFO - 2023-08-15 11:37:25 --> Form Validation Class Initialized
INFO - 2023-08-15 11:37:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-15 11:37:25 --> Final output sent to browser
DEBUG - 2023-08-15 11:37:25 --> Total execution time: 4.0078
INFO - 2023-08-15 11:37:26 --> Config Class Initialized
INFO - 2023-08-15 11:37:26 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:37:26 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:37:26 --> Utf8 Class Initialized
INFO - 2023-08-15 11:37:26 --> URI Class Initialized
INFO - 2023-08-15 11:37:26 --> Router Class Initialized
INFO - 2023-08-15 11:37:26 --> Output Class Initialized
INFO - 2023-08-15 11:37:26 --> Security Class Initialized
DEBUG - 2023-08-15 11:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:37:26 --> Input Class Initialized
INFO - 2023-08-15 11:37:26 --> Language Class Initialized
ERROR - 2023-08-15 11:37:26 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-15 11:37:27 --> Config Class Initialized
INFO - 2023-08-15 11:37:27 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:37:27 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:37:27 --> Utf8 Class Initialized
INFO - 2023-08-15 11:37:27 --> URI Class Initialized
INFO - 2023-08-15 11:37:27 --> Router Class Initialized
INFO - 2023-08-15 11:37:27 --> Output Class Initialized
INFO - 2023-08-15 11:37:27 --> Security Class Initialized
DEBUG - 2023-08-15 11:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:37:27 --> Input Class Initialized
INFO - 2023-08-15 11:37:27 --> Language Class Initialized
ERROR - 2023-08-15 11:37:27 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-15 11:37:34 --> Config Class Initialized
INFO - 2023-08-15 11:37:34 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:37:34 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:37:34 --> Utf8 Class Initialized
INFO - 2023-08-15 11:37:34 --> URI Class Initialized
INFO - 2023-08-15 11:37:34 --> Router Class Initialized
INFO - 2023-08-15 11:37:34 --> Output Class Initialized
INFO - 2023-08-15 11:37:34 --> Security Class Initialized
DEBUG - 2023-08-15 11:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:37:34 --> Input Class Initialized
INFO - 2023-08-15 11:37:34 --> Language Class Initialized
INFO - 2023-08-15 11:37:34 --> Loader Class Initialized
INFO - 2023-08-15 11:37:34 --> Helper loaded: url_helper
INFO - 2023-08-15 11:37:34 --> Helper loaded: file_helper
INFO - 2023-08-15 11:37:34 --> Database Driver Class Initialized
INFO - 2023-08-15 11:37:34 --> Email Class Initialized
DEBUG - 2023-08-15 11:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:37:34 --> Controller Class Initialized
INFO - 2023-08-15 11:37:34 --> Config Class Initialized
INFO - 2023-08-15 11:37:34 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:37:34 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:37:34 --> Utf8 Class Initialized
INFO - 2023-08-15 11:37:34 --> URI Class Initialized
INFO - 2023-08-15 11:37:34 --> Router Class Initialized
INFO - 2023-08-15 11:37:34 --> Output Class Initialized
INFO - 2023-08-15 11:37:34 --> Security Class Initialized
DEBUG - 2023-08-15 11:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:37:34 --> Input Class Initialized
INFO - 2023-08-15 11:37:34 --> Language Class Initialized
INFO - 2023-08-15 11:37:34 --> Loader Class Initialized
INFO - 2023-08-15 11:37:34 --> Helper loaded: url_helper
INFO - 2023-08-15 11:37:34 --> Helper loaded: file_helper
INFO - 2023-08-15 11:37:34 --> Database Driver Class Initialized
INFO - 2023-08-15 11:37:34 --> Email Class Initialized
DEBUG - 2023-08-15 11:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:37:34 --> Controller Class Initialized
INFO - 2023-08-15 11:37:34 --> Model "User_model" initialized
INFO - 2023-08-15 11:37:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-15 11:37:34 --> Final output sent to browser
DEBUG - 2023-08-15 11:37:34 --> Total execution time: 0.2641
INFO - 2023-08-15 11:37:36 --> Config Class Initialized
INFO - 2023-08-15 11:37:36 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:37:36 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:37:36 --> Utf8 Class Initialized
INFO - 2023-08-15 11:37:36 --> URI Class Initialized
INFO - 2023-08-15 11:37:36 --> Router Class Initialized
INFO - 2023-08-15 11:37:36 --> Output Class Initialized
INFO - 2023-08-15 11:37:36 --> Security Class Initialized
DEBUG - 2023-08-15 11:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:37:36 --> Input Class Initialized
INFO - 2023-08-15 11:37:36 --> Language Class Initialized
INFO - 2023-08-15 11:37:36 --> Loader Class Initialized
INFO - 2023-08-15 11:37:36 --> Helper loaded: url_helper
INFO - 2023-08-15 11:37:36 --> Helper loaded: file_helper
INFO - 2023-08-15 11:37:36 --> Database Driver Class Initialized
INFO - 2023-08-15 11:37:36 --> Email Class Initialized
DEBUG - 2023-08-15 11:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:37:36 --> Controller Class Initialized
INFO - 2023-08-15 11:37:36 --> Model "User_model" initialized
INFO - 2023-08-15 11:37:37 --> Config Class Initialized
INFO - 2023-08-15 11:37:37 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:37:37 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:37:37 --> Utf8 Class Initialized
INFO - 2023-08-15 11:37:37 --> URI Class Initialized
INFO - 2023-08-15 11:37:37 --> Router Class Initialized
INFO - 2023-08-15 11:37:37 --> Output Class Initialized
INFO - 2023-08-15 11:37:37 --> Security Class Initialized
DEBUG - 2023-08-15 11:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:37:37 --> Input Class Initialized
INFO - 2023-08-15 11:37:37 --> Language Class Initialized
INFO - 2023-08-15 11:37:38 --> Loader Class Initialized
INFO - 2023-08-15 11:37:38 --> Helper loaded: url_helper
INFO - 2023-08-15 11:37:38 --> Helper loaded: file_helper
INFO - 2023-08-15 11:37:38 --> Database Driver Class Initialized
INFO - 2023-08-15 11:37:38 --> Email Class Initialized
DEBUG - 2023-08-15 11:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:37:38 --> Controller Class Initialized
INFO - 2023-08-15 11:37:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-15 11:37:38 --> Final output sent to browser
DEBUG - 2023-08-15 11:37:38 --> Total execution time: 0.7494
INFO - 2023-08-15 11:37:43 --> Config Class Initialized
INFO - 2023-08-15 11:37:43 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:37:43 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:37:43 --> Utf8 Class Initialized
INFO - 2023-08-15 11:37:43 --> URI Class Initialized
INFO - 2023-08-15 11:37:43 --> Router Class Initialized
INFO - 2023-08-15 11:37:43 --> Output Class Initialized
INFO - 2023-08-15 11:37:43 --> Security Class Initialized
DEBUG - 2023-08-15 11:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:37:43 --> Input Class Initialized
INFO - 2023-08-15 11:37:43 --> Language Class Initialized
INFO - 2023-08-15 11:37:43 --> Loader Class Initialized
INFO - 2023-08-15 11:37:43 --> Helper loaded: url_helper
INFO - 2023-08-15 11:37:43 --> Helper loaded: file_helper
INFO - 2023-08-15 11:37:43 --> Database Driver Class Initialized
INFO - 2023-08-15 11:37:43 --> Email Class Initialized
DEBUG - 2023-08-15 11:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:37:43 --> Controller Class Initialized
INFO - 2023-08-15 11:37:43 --> Model "Gallery_model" initialized
INFO - 2023-08-15 11:37:43 --> Helper loaded: form_helper
INFO - 2023-08-15 11:37:43 --> Form Validation Class Initialized
INFO - 2023-08-15 11:37:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/gallery_list.php
INFO - 2023-08-15 11:37:43 --> Final output sent to browser
DEBUG - 2023-08-15 11:37:43 --> Total execution time: 0.2207
INFO - 2023-08-15 11:37:45 --> Config Class Initialized
INFO - 2023-08-15 11:37:45 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:37:45 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:37:45 --> Utf8 Class Initialized
INFO - 2023-08-15 11:37:45 --> URI Class Initialized
INFO - 2023-08-15 11:37:45 --> Router Class Initialized
INFO - 2023-08-15 11:37:45 --> Output Class Initialized
INFO - 2023-08-15 11:37:45 --> Security Class Initialized
DEBUG - 2023-08-15 11:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:37:45 --> Input Class Initialized
INFO - 2023-08-15 11:37:45 --> Language Class Initialized
INFO - 2023-08-15 11:37:46 --> Loader Class Initialized
INFO - 2023-08-15 11:37:46 --> Helper loaded: url_helper
INFO - 2023-08-15 11:37:46 --> Helper loaded: file_helper
INFO - 2023-08-15 11:37:46 --> Database Driver Class Initialized
INFO - 2023-08-15 11:37:46 --> Email Class Initialized
DEBUG - 2023-08-15 11:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:37:46 --> Controller Class Initialized
INFO - 2023-08-15 11:37:46 --> Model "Services_model" initialized
INFO - 2023-08-15 11:37:46 --> Helper loaded: form_helper
INFO - 2023-08-15 11:37:46 --> Form Validation Class Initialized
INFO - 2023-08-15 11:37:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-15 11:37:46 --> Final output sent to browser
DEBUG - 2023-08-15 11:37:46 --> Total execution time: 0.2290
INFO - 2023-08-15 11:37:46 --> Config Class Initialized
INFO - 2023-08-15 11:37:46 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:37:46 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:37:46 --> Utf8 Class Initialized
INFO - 2023-08-15 11:37:46 --> URI Class Initialized
INFO - 2023-08-15 11:37:46 --> Router Class Initialized
INFO - 2023-08-15 11:37:46 --> Output Class Initialized
INFO - 2023-08-15 11:37:46 --> Security Class Initialized
DEBUG - 2023-08-15 11:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:37:46 --> Input Class Initialized
INFO - 2023-08-15 11:37:46 --> Language Class Initialized
ERROR - 2023-08-15 11:37:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 11:37:48 --> Config Class Initialized
INFO - 2023-08-15 11:37:48 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:37:48 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:37:48 --> Utf8 Class Initialized
INFO - 2023-08-15 11:37:48 --> URI Class Initialized
INFO - 2023-08-15 11:37:48 --> Router Class Initialized
INFO - 2023-08-15 11:37:48 --> Output Class Initialized
INFO - 2023-08-15 11:37:48 --> Security Class Initialized
DEBUG - 2023-08-15 11:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:37:48 --> Input Class Initialized
INFO - 2023-08-15 11:37:48 --> Language Class Initialized
INFO - 2023-08-15 11:37:48 --> Loader Class Initialized
INFO - 2023-08-15 11:37:48 --> Helper loaded: url_helper
INFO - 2023-08-15 11:37:48 --> Helper loaded: file_helper
INFO - 2023-08-15 11:37:48 --> Database Driver Class Initialized
INFO - 2023-08-15 11:37:48 --> Email Class Initialized
DEBUG - 2023-08-15 11:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:37:48 --> Controller Class Initialized
INFO - 2023-08-15 11:37:48 --> Model "Training_model" initialized
INFO - 2023-08-15 11:37:48 --> Helper loaded: form_helper
INFO - 2023-08-15 11:37:48 --> Form Validation Class Initialized
INFO - 2023-08-15 11:37:48 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-15 11:37:48 --> Final output sent to browser
DEBUG - 2023-08-15 11:37:48 --> Total execution time: 0.2346
INFO - 2023-08-15 11:38:09 --> Config Class Initialized
INFO - 2023-08-15 11:38:09 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:38:09 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:38:09 --> Utf8 Class Initialized
INFO - 2023-08-15 11:38:09 --> URI Class Initialized
INFO - 2023-08-15 11:38:09 --> Router Class Initialized
INFO - 2023-08-15 11:38:09 --> Output Class Initialized
INFO - 2023-08-15 11:38:09 --> Security Class Initialized
DEBUG - 2023-08-15 11:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:38:09 --> Input Class Initialized
INFO - 2023-08-15 11:38:09 --> Language Class Initialized
INFO - 2023-08-15 11:38:09 --> Loader Class Initialized
INFO - 2023-08-15 11:38:09 --> Helper loaded: url_helper
INFO - 2023-08-15 11:38:09 --> Helper loaded: file_helper
INFO - 2023-08-15 11:38:09 --> Database Driver Class Initialized
INFO - 2023-08-15 11:38:09 --> Email Class Initialized
DEBUG - 2023-08-15 11:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:38:09 --> Controller Class Initialized
INFO - 2023-08-15 11:38:09 --> Model "Training_model" initialized
INFO - 2023-08-15 11:38:09 --> Helper loaded: form_helper
INFO - 2023-08-15 11:38:09 --> Form Validation Class Initialized
INFO - 2023-08-15 11:38:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-15 11:38:09 --> Final output sent to browser
DEBUG - 2023-08-15 11:38:09 --> Total execution time: 0.2445
INFO - 2023-08-15 11:38:17 --> Config Class Initialized
INFO - 2023-08-15 11:38:17 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:38:17 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:38:17 --> Utf8 Class Initialized
INFO - 2023-08-15 11:38:17 --> URI Class Initialized
INFO - 2023-08-15 11:38:17 --> Router Class Initialized
INFO - 2023-08-15 11:38:17 --> Output Class Initialized
INFO - 2023-08-15 11:38:17 --> Security Class Initialized
DEBUG - 2023-08-15 11:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:38:17 --> Input Class Initialized
INFO - 2023-08-15 11:38:17 --> Language Class Initialized
INFO - 2023-08-15 11:38:18 --> Loader Class Initialized
INFO - 2023-08-15 11:38:18 --> Helper loaded: url_helper
INFO - 2023-08-15 11:38:18 --> Helper loaded: file_helper
INFO - 2023-08-15 11:38:18 --> Database Driver Class Initialized
INFO - 2023-08-15 11:38:18 --> Email Class Initialized
DEBUG - 2023-08-15 11:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:38:18 --> Controller Class Initialized
INFO - 2023-08-15 11:38:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 11:38:18 --> Final output sent to browser
DEBUG - 2023-08-15 11:38:18 --> Total execution time: 0.2059
INFO - 2023-08-15 11:38:20 --> Config Class Initialized
INFO - 2023-08-15 11:38:20 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:38:20 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:38:20 --> Utf8 Class Initialized
INFO - 2023-08-15 11:38:20 --> URI Class Initialized
INFO - 2023-08-15 11:38:20 --> Router Class Initialized
INFO - 2023-08-15 11:38:20 --> Output Class Initialized
INFO - 2023-08-15 11:38:20 --> Security Class Initialized
DEBUG - 2023-08-15 11:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:38:20 --> Input Class Initialized
INFO - 2023-08-15 11:38:20 --> Language Class Initialized
ERROR - 2023-08-15 11:38:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 11:38:20 --> Config Class Initialized
INFO - 2023-08-15 11:38:20 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:38:20 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:38:20 --> Utf8 Class Initialized
INFO - 2023-08-15 11:38:20 --> URI Class Initialized
INFO - 2023-08-15 11:38:20 --> Router Class Initialized
INFO - 2023-08-15 11:38:20 --> Output Class Initialized
INFO - 2023-08-15 11:38:20 --> Security Class Initialized
DEBUG - 2023-08-15 11:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:38:20 --> Input Class Initialized
INFO - 2023-08-15 11:38:20 --> Language Class Initialized
ERROR - 2023-08-15 11:38:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 11:38:20 --> Config Class Initialized
INFO - 2023-08-15 11:38:20 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:38:20 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:38:20 --> Utf8 Class Initialized
INFO - 2023-08-15 11:38:20 --> URI Class Initialized
INFO - 2023-08-15 11:38:20 --> Router Class Initialized
INFO - 2023-08-15 11:38:20 --> Output Class Initialized
INFO - 2023-08-15 11:38:20 --> Security Class Initialized
DEBUG - 2023-08-15 11:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:38:20 --> Input Class Initialized
INFO - 2023-08-15 11:38:20 --> Language Class Initialized
ERROR - 2023-08-15 11:38:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 11:38:20 --> Config Class Initialized
INFO - 2023-08-15 11:38:20 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:38:20 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:38:20 --> Utf8 Class Initialized
INFO - 2023-08-15 11:38:20 --> URI Class Initialized
INFO - 2023-08-15 11:38:20 --> Router Class Initialized
INFO - 2023-08-15 11:38:20 --> Output Class Initialized
INFO - 2023-08-15 11:38:20 --> Security Class Initialized
DEBUG - 2023-08-15 11:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:38:20 --> Input Class Initialized
INFO - 2023-08-15 11:38:20 --> Language Class Initialized
ERROR - 2023-08-15 11:38:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 11:38:20 --> Config Class Initialized
INFO - 2023-08-15 11:38:20 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:38:20 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:38:20 --> Utf8 Class Initialized
INFO - 2023-08-15 11:38:20 --> URI Class Initialized
INFO - 2023-08-15 11:38:20 --> Router Class Initialized
INFO - 2023-08-15 11:38:20 --> Output Class Initialized
INFO - 2023-08-15 11:38:20 --> Security Class Initialized
DEBUG - 2023-08-15 11:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:38:20 --> Input Class Initialized
INFO - 2023-08-15 11:38:20 --> Language Class Initialized
ERROR - 2023-08-15 11:38:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 11:38:21 --> Config Class Initialized
INFO - 2023-08-15 11:38:21 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:38:21 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:38:21 --> Utf8 Class Initialized
INFO - 2023-08-15 11:38:21 --> URI Class Initialized
INFO - 2023-08-15 11:38:21 --> Router Class Initialized
INFO - 2023-08-15 11:38:21 --> Output Class Initialized
INFO - 2023-08-15 11:38:21 --> Security Class Initialized
DEBUG - 2023-08-15 11:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:38:21 --> Input Class Initialized
INFO - 2023-08-15 11:38:21 --> Language Class Initialized
ERROR - 2023-08-15 11:38:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 11:55:29 --> Config Class Initialized
INFO - 2023-08-15 11:55:29 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:55:29 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:55:29 --> Utf8 Class Initialized
INFO - 2023-08-15 11:55:29 --> URI Class Initialized
INFO - 2023-08-15 11:55:29 --> Router Class Initialized
INFO - 2023-08-15 11:55:29 --> Output Class Initialized
INFO - 2023-08-15 11:55:29 --> Security Class Initialized
DEBUG - 2023-08-15 11:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:55:29 --> Input Class Initialized
INFO - 2023-08-15 11:55:29 --> Language Class Initialized
ERROR - 2023-08-15 11:55:29 --> 404 Page Not Found: DW/admin
INFO - 2023-08-15 11:55:45 --> Config Class Initialized
INFO - 2023-08-15 11:55:45 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:55:45 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:55:45 --> Utf8 Class Initialized
INFO - 2023-08-15 11:55:45 --> URI Class Initialized
INFO - 2023-08-15 11:55:45 --> Router Class Initialized
INFO - 2023-08-15 11:55:45 --> Output Class Initialized
INFO - 2023-08-15 11:55:45 --> Security Class Initialized
DEBUG - 2023-08-15 11:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:55:45 --> Input Class Initialized
INFO - 2023-08-15 11:55:45 --> Language Class Initialized
INFO - 2023-08-15 11:55:45 --> Loader Class Initialized
INFO - 2023-08-15 11:55:45 --> Helper loaded: url_helper
INFO - 2023-08-15 11:55:45 --> Helper loaded: file_helper
INFO - 2023-08-15 11:55:45 --> Database Driver Class Initialized
INFO - 2023-08-15 11:55:45 --> Email Class Initialized
DEBUG - 2023-08-15 11:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:55:45 --> Controller Class Initialized
INFO - 2023-08-15 11:55:45 --> Config Class Initialized
INFO - 2023-08-15 11:55:45 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:55:45 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:55:45 --> Utf8 Class Initialized
INFO - 2023-08-15 11:55:45 --> URI Class Initialized
INFO - 2023-08-15 11:55:45 --> Router Class Initialized
INFO - 2023-08-15 11:55:45 --> Output Class Initialized
INFO - 2023-08-15 11:55:45 --> Security Class Initialized
DEBUG - 2023-08-15 11:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:55:45 --> Input Class Initialized
INFO - 2023-08-15 11:55:45 --> Language Class Initialized
INFO - 2023-08-15 11:55:45 --> Loader Class Initialized
INFO - 2023-08-15 11:55:45 --> Helper loaded: url_helper
INFO - 2023-08-15 11:55:45 --> Helper loaded: file_helper
INFO - 2023-08-15 11:55:45 --> Database Driver Class Initialized
INFO - 2023-08-15 11:55:45 --> Email Class Initialized
DEBUG - 2023-08-15 11:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:55:45 --> Controller Class Initialized
INFO - 2023-08-15 11:55:45 --> Model "User_model" initialized
INFO - 2023-08-15 11:55:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-15 11:55:45 --> Final output sent to browser
DEBUG - 2023-08-15 11:55:45 --> Total execution time: 0.0793
INFO - 2023-08-15 11:55:47 --> Config Class Initialized
INFO - 2023-08-15 11:55:47 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:55:47 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:55:47 --> Utf8 Class Initialized
INFO - 2023-08-15 11:55:47 --> URI Class Initialized
INFO - 2023-08-15 11:55:47 --> Router Class Initialized
INFO - 2023-08-15 11:55:47 --> Output Class Initialized
INFO - 2023-08-15 11:55:47 --> Security Class Initialized
DEBUG - 2023-08-15 11:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:55:47 --> Input Class Initialized
INFO - 2023-08-15 11:55:47 --> Language Class Initialized
ERROR - 2023-08-15 11:55:47 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-15 11:55:55 --> Config Class Initialized
INFO - 2023-08-15 11:55:55 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:55:55 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:55:55 --> Utf8 Class Initialized
INFO - 2023-08-15 11:55:55 --> URI Class Initialized
INFO - 2023-08-15 11:55:55 --> Router Class Initialized
INFO - 2023-08-15 11:55:55 --> Output Class Initialized
INFO - 2023-08-15 11:55:55 --> Security Class Initialized
DEBUG - 2023-08-15 11:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:55:55 --> Input Class Initialized
INFO - 2023-08-15 11:55:55 --> Language Class Initialized
INFO - 2023-08-15 11:55:55 --> Loader Class Initialized
INFO - 2023-08-15 11:55:55 --> Helper loaded: url_helper
INFO - 2023-08-15 11:55:55 --> Helper loaded: file_helper
INFO - 2023-08-15 11:55:56 --> Database Driver Class Initialized
INFO - 2023-08-15 11:55:56 --> Email Class Initialized
DEBUG - 2023-08-15 11:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:55:56 --> Controller Class Initialized
INFO - 2023-08-15 11:55:56 --> Model "User_model" initialized
INFO - 2023-08-15 11:55:56 --> Config Class Initialized
INFO - 2023-08-15 11:55:56 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:55:56 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:55:56 --> Utf8 Class Initialized
INFO - 2023-08-15 11:55:56 --> URI Class Initialized
INFO - 2023-08-15 11:55:56 --> Router Class Initialized
INFO - 2023-08-15 11:55:56 --> Output Class Initialized
INFO - 2023-08-15 11:55:56 --> Security Class Initialized
DEBUG - 2023-08-15 11:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:55:56 --> Input Class Initialized
INFO - 2023-08-15 11:55:56 --> Language Class Initialized
INFO - 2023-08-15 11:55:56 --> Loader Class Initialized
INFO - 2023-08-15 11:55:56 --> Helper loaded: url_helper
INFO - 2023-08-15 11:55:56 --> Helper loaded: file_helper
INFO - 2023-08-15 11:55:56 --> Database Driver Class Initialized
INFO - 2023-08-15 11:55:56 --> Email Class Initialized
DEBUG - 2023-08-15 11:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:55:56 --> Controller Class Initialized
INFO - 2023-08-15 11:55:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-15 11:55:56 --> Final output sent to browser
DEBUG - 2023-08-15 11:55:56 --> Total execution time: 0.0291
INFO - 2023-08-15 11:56:03 --> Config Class Initialized
INFO - 2023-08-15 11:56:03 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:56:03 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:56:03 --> Utf8 Class Initialized
INFO - 2023-08-15 11:56:03 --> URI Class Initialized
INFO - 2023-08-15 11:56:03 --> Router Class Initialized
INFO - 2023-08-15 11:56:03 --> Output Class Initialized
INFO - 2023-08-15 11:56:03 --> Security Class Initialized
DEBUG - 2023-08-15 11:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:56:03 --> Input Class Initialized
INFO - 2023-08-15 11:56:03 --> Language Class Initialized
ERROR - 2023-08-15 11:56:03 --> 404 Page Not Found: admin/Indexhtml/index
INFO - 2023-08-15 11:56:05 --> Config Class Initialized
INFO - 2023-08-15 11:56:05 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:56:05 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:56:05 --> Utf8 Class Initialized
INFO - 2023-08-15 11:56:05 --> URI Class Initialized
INFO - 2023-08-15 11:56:05 --> Router Class Initialized
INFO - 2023-08-15 11:56:05 --> Output Class Initialized
INFO - 2023-08-15 11:56:05 --> Security Class Initialized
DEBUG - 2023-08-15 11:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:56:05 --> Input Class Initialized
INFO - 2023-08-15 11:56:05 --> Language Class Initialized
INFO - 2023-08-15 11:56:05 --> Loader Class Initialized
INFO - 2023-08-15 11:56:05 --> Helper loaded: url_helper
INFO - 2023-08-15 11:56:05 --> Helper loaded: file_helper
INFO - 2023-08-15 11:56:05 --> Database Driver Class Initialized
INFO - 2023-08-15 11:56:05 --> Email Class Initialized
DEBUG - 2023-08-15 11:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:56:05 --> Controller Class Initialized
INFO - 2023-08-15 11:56:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-15 11:56:05 --> Final output sent to browser
DEBUG - 2023-08-15 11:56:05 --> Total execution time: 0.0326
INFO - 2023-08-15 11:56:19 --> Config Class Initialized
INFO - 2023-08-15 11:56:19 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:56:19 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:56:19 --> Utf8 Class Initialized
INFO - 2023-08-15 11:56:19 --> URI Class Initialized
INFO - 2023-08-15 11:56:19 --> Router Class Initialized
INFO - 2023-08-15 11:56:19 --> Output Class Initialized
INFO - 2023-08-15 11:56:19 --> Security Class Initialized
DEBUG - 2023-08-15 11:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:56:19 --> Input Class Initialized
INFO - 2023-08-15 11:56:19 --> Language Class Initialized
INFO - 2023-08-15 11:56:19 --> Loader Class Initialized
INFO - 2023-08-15 11:56:19 --> Helper loaded: url_helper
INFO - 2023-08-15 11:56:19 --> Helper loaded: file_helper
INFO - 2023-08-15 11:56:19 --> Database Driver Class Initialized
INFO - 2023-08-15 11:56:19 --> Email Class Initialized
DEBUG - 2023-08-15 11:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:56:19 --> Controller Class Initialized
INFO - 2023-08-15 11:56:19 --> Model "Social_media_model" initialized
INFO - 2023-08-15 11:56:19 --> Helper loaded: form_helper
INFO - 2023-08-15 11:56:19 --> Form Validation Class Initialized
INFO - 2023-08-15 11:56:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-08-15 11:56:20 --> Final output sent to browser
DEBUG - 2023-08-15 11:56:20 --> Total execution time: 0.2429
INFO - 2023-08-15 11:56:20 --> Config Class Initialized
INFO - 2023-08-15 11:56:20 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:56:20 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:56:20 --> Utf8 Class Initialized
INFO - 2023-08-15 11:56:20 --> URI Class Initialized
INFO - 2023-08-15 11:56:20 --> Router Class Initialized
INFO - 2023-08-15 11:56:20 --> Output Class Initialized
INFO - 2023-08-15 11:56:20 --> Security Class Initialized
DEBUG - 2023-08-15 11:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:56:20 --> Input Class Initialized
INFO - 2023-08-15 11:56:20 --> Language Class Initialized
ERROR - 2023-08-15 11:56:20 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-08-15 11:56:23 --> Config Class Initialized
INFO - 2023-08-15 11:56:23 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:56:23 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:56:23 --> Utf8 Class Initialized
INFO - 2023-08-15 11:56:23 --> URI Class Initialized
INFO - 2023-08-15 11:56:23 --> Router Class Initialized
INFO - 2023-08-15 11:56:23 --> Output Class Initialized
INFO - 2023-08-15 11:56:23 --> Security Class Initialized
DEBUG - 2023-08-15 11:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:56:23 --> Input Class Initialized
INFO - 2023-08-15 11:56:23 --> Language Class Initialized
INFO - 2023-08-15 11:56:23 --> Loader Class Initialized
INFO - 2023-08-15 11:56:23 --> Helper loaded: url_helper
INFO - 2023-08-15 11:56:23 --> Helper loaded: file_helper
INFO - 2023-08-15 11:56:23 --> Database Driver Class Initialized
INFO - 2023-08-15 11:56:23 --> Email Class Initialized
DEBUG - 2023-08-15 11:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:56:23 --> Controller Class Initialized
INFO - 2023-08-15 11:56:23 --> Model "Social_media_model" initialized
INFO - 2023-08-15 11:56:23 --> Helper loaded: form_helper
INFO - 2023-08-15 11:56:23 --> Form Validation Class Initialized
INFO - 2023-08-15 11:56:23 --> Config Class Initialized
INFO - 2023-08-15 11:56:23 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:56:23 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:56:23 --> Utf8 Class Initialized
INFO - 2023-08-15 11:56:23 --> URI Class Initialized
INFO - 2023-08-15 11:56:23 --> Router Class Initialized
INFO - 2023-08-15 11:56:23 --> Output Class Initialized
INFO - 2023-08-15 11:56:23 --> Security Class Initialized
DEBUG - 2023-08-15 11:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:56:23 --> Input Class Initialized
INFO - 2023-08-15 11:56:23 --> Language Class Initialized
INFO - 2023-08-15 11:56:23 --> Loader Class Initialized
INFO - 2023-08-15 11:56:23 --> Helper loaded: url_helper
INFO - 2023-08-15 11:56:23 --> Helper loaded: file_helper
INFO - 2023-08-15 11:56:23 --> Database Driver Class Initialized
INFO - 2023-08-15 11:56:23 --> Email Class Initialized
DEBUG - 2023-08-15 11:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:56:23 --> Controller Class Initialized
INFO - 2023-08-15 11:56:23 --> Model "Social_media_model" initialized
INFO - 2023-08-15 11:56:23 --> Helper loaded: form_helper
INFO - 2023-08-15 11:56:23 --> Form Validation Class Initialized
INFO - 2023-08-15 11:56:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-08-15 11:56:23 --> Final output sent to browser
DEBUG - 2023-08-15 11:56:23 --> Total execution time: 0.0765
INFO - 2023-08-15 11:58:00 --> Config Class Initialized
INFO - 2023-08-15 11:58:00 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:58:00 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:58:00 --> Utf8 Class Initialized
INFO - 2023-08-15 11:58:00 --> URI Class Initialized
INFO - 2023-08-15 11:58:00 --> Router Class Initialized
INFO - 2023-08-15 11:58:00 --> Output Class Initialized
INFO - 2023-08-15 11:58:00 --> Security Class Initialized
DEBUG - 2023-08-15 11:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:58:00 --> Input Class Initialized
INFO - 2023-08-15 11:58:00 --> Language Class Initialized
INFO - 2023-08-15 11:58:00 --> Loader Class Initialized
INFO - 2023-08-15 11:58:00 --> Helper loaded: url_helper
INFO - 2023-08-15 11:58:00 --> Helper loaded: file_helper
INFO - 2023-08-15 11:58:00 --> Database Driver Class Initialized
INFO - 2023-08-15 11:58:00 --> Email Class Initialized
DEBUG - 2023-08-15 11:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 11:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 11:58:00 --> Controller Class Initialized
INFO - 2023-08-15 11:58:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 11:58:00 --> Final output sent to browser
DEBUG - 2023-08-15 11:58:00 --> Total execution time: 0.0686
INFO - 2023-08-15 11:58:01 --> Config Class Initialized
INFO - 2023-08-15 11:58:01 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:58:01 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:58:01 --> Utf8 Class Initialized
INFO - 2023-08-15 11:58:01 --> URI Class Initialized
INFO - 2023-08-15 11:58:01 --> Router Class Initialized
INFO - 2023-08-15 11:58:01 --> Output Class Initialized
INFO - 2023-08-15 11:58:01 --> Security Class Initialized
DEBUG - 2023-08-15 11:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:58:01 --> Input Class Initialized
INFO - 2023-08-15 11:58:01 --> Language Class Initialized
ERROR - 2023-08-15 11:58:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 11:58:01 --> Config Class Initialized
INFO - 2023-08-15 11:58:01 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:58:01 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:58:01 --> Utf8 Class Initialized
INFO - 2023-08-15 11:58:01 --> URI Class Initialized
INFO - 2023-08-15 11:58:01 --> Router Class Initialized
INFO - 2023-08-15 11:58:01 --> Output Class Initialized
INFO - 2023-08-15 11:58:01 --> Security Class Initialized
DEBUG - 2023-08-15 11:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:58:01 --> Input Class Initialized
INFO - 2023-08-15 11:58:01 --> Language Class Initialized
ERROR - 2023-08-15 11:58:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 11:58:01 --> Config Class Initialized
INFO - 2023-08-15 11:58:01 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:58:01 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:58:01 --> Utf8 Class Initialized
INFO - 2023-08-15 11:58:01 --> URI Class Initialized
INFO - 2023-08-15 11:58:01 --> Router Class Initialized
INFO - 2023-08-15 11:58:01 --> Output Class Initialized
INFO - 2023-08-15 11:58:01 --> Security Class Initialized
DEBUG - 2023-08-15 11:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:58:01 --> Input Class Initialized
INFO - 2023-08-15 11:58:01 --> Language Class Initialized
ERROR - 2023-08-15 11:58:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 11:58:01 --> Config Class Initialized
INFO - 2023-08-15 11:58:01 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:58:01 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:58:01 --> Utf8 Class Initialized
INFO - 2023-08-15 11:58:01 --> URI Class Initialized
INFO - 2023-08-15 11:58:01 --> Router Class Initialized
INFO - 2023-08-15 11:58:01 --> Output Class Initialized
INFO - 2023-08-15 11:58:01 --> Security Class Initialized
DEBUG - 2023-08-15 11:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:58:01 --> Input Class Initialized
INFO - 2023-08-15 11:58:01 --> Language Class Initialized
ERROR - 2023-08-15 11:58:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 11:58:02 --> Config Class Initialized
INFO - 2023-08-15 11:58:02 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:58:02 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:58:02 --> Utf8 Class Initialized
INFO - 2023-08-15 11:58:02 --> URI Class Initialized
INFO - 2023-08-15 11:58:02 --> Router Class Initialized
INFO - 2023-08-15 11:58:02 --> Output Class Initialized
INFO - 2023-08-15 11:58:02 --> Security Class Initialized
DEBUG - 2023-08-15 11:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:58:02 --> Input Class Initialized
INFO - 2023-08-15 11:58:02 --> Language Class Initialized
ERROR - 2023-08-15 11:58:02 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 11:58:02 --> Config Class Initialized
INFO - 2023-08-15 11:58:02 --> Hooks Class Initialized
DEBUG - 2023-08-15 11:58:02 --> UTF-8 Support Enabled
INFO - 2023-08-15 11:58:02 --> Utf8 Class Initialized
INFO - 2023-08-15 11:58:02 --> URI Class Initialized
INFO - 2023-08-15 11:58:02 --> Router Class Initialized
INFO - 2023-08-15 11:58:02 --> Output Class Initialized
INFO - 2023-08-15 11:58:02 --> Security Class Initialized
DEBUG - 2023-08-15 11:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 11:58:02 --> Input Class Initialized
INFO - 2023-08-15 11:58:02 --> Language Class Initialized
ERROR - 2023-08-15 11:58:02 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 12:08:42 --> Config Class Initialized
INFO - 2023-08-15 12:08:42 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:08:42 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:08:42 --> Utf8 Class Initialized
INFO - 2023-08-15 12:08:42 --> URI Class Initialized
INFO - 2023-08-15 12:08:42 --> Router Class Initialized
INFO - 2023-08-15 12:08:42 --> Output Class Initialized
INFO - 2023-08-15 12:08:42 --> Security Class Initialized
DEBUG - 2023-08-15 12:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:08:42 --> Input Class Initialized
INFO - 2023-08-15 12:08:42 --> Language Class Initialized
INFO - 2023-08-15 12:08:42 --> Loader Class Initialized
INFO - 2023-08-15 12:08:42 --> Helper loaded: url_helper
INFO - 2023-08-15 12:08:42 --> Helper loaded: file_helper
INFO - 2023-08-15 12:08:42 --> Database Driver Class Initialized
INFO - 2023-08-15 12:08:42 --> Email Class Initialized
DEBUG - 2023-08-15 12:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:08:42 --> Controller Class Initialized
INFO - 2023-08-15 12:08:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-15 12:08:42 --> Final output sent to browser
DEBUG - 2023-08-15 12:08:42 --> Total execution time: 0.1309
INFO - 2023-08-15 12:08:43 --> Config Class Initialized
INFO - 2023-08-15 12:08:43 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:08:43 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:08:43 --> Utf8 Class Initialized
INFO - 2023-08-15 12:08:43 --> URI Class Initialized
INFO - 2023-08-15 12:08:43 --> Router Class Initialized
INFO - 2023-08-15 12:08:43 --> Output Class Initialized
INFO - 2023-08-15 12:08:43 --> Security Class Initialized
DEBUG - 2023-08-15 12:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:08:43 --> Input Class Initialized
INFO - 2023-08-15 12:08:43 --> Language Class Initialized
ERROR - 2023-08-15 12:08:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:08:44 --> Config Class Initialized
INFO - 2023-08-15 12:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:08:44 --> Utf8 Class Initialized
INFO - 2023-08-15 12:08:44 --> URI Class Initialized
INFO - 2023-08-15 12:08:44 --> Router Class Initialized
INFO - 2023-08-15 12:08:44 --> Output Class Initialized
INFO - 2023-08-15 12:08:44 --> Security Class Initialized
DEBUG - 2023-08-15 12:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:08:44 --> Input Class Initialized
INFO - 2023-08-15 12:08:44 --> Language Class Initialized
ERROR - 2023-08-15 12:08:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:08:44 --> Config Class Initialized
INFO - 2023-08-15 12:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:08:44 --> Utf8 Class Initialized
INFO - 2023-08-15 12:08:44 --> URI Class Initialized
INFO - 2023-08-15 12:08:44 --> Router Class Initialized
INFO - 2023-08-15 12:08:44 --> Output Class Initialized
INFO - 2023-08-15 12:08:44 --> Security Class Initialized
DEBUG - 2023-08-15 12:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:08:44 --> Input Class Initialized
INFO - 2023-08-15 12:08:44 --> Language Class Initialized
ERROR - 2023-08-15 12:08:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:08:44 --> Config Class Initialized
INFO - 2023-08-15 12:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:08:44 --> Utf8 Class Initialized
INFO - 2023-08-15 12:08:44 --> URI Class Initialized
INFO - 2023-08-15 12:08:44 --> Router Class Initialized
INFO - 2023-08-15 12:08:44 --> Output Class Initialized
INFO - 2023-08-15 12:08:44 --> Security Class Initialized
DEBUG - 2023-08-15 12:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:08:44 --> Input Class Initialized
INFO - 2023-08-15 12:08:44 --> Language Class Initialized
ERROR - 2023-08-15 12:08:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:08:44 --> Config Class Initialized
INFO - 2023-08-15 12:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:08:44 --> Utf8 Class Initialized
INFO - 2023-08-15 12:08:44 --> URI Class Initialized
INFO - 2023-08-15 12:08:44 --> Router Class Initialized
INFO - 2023-08-15 12:08:44 --> Output Class Initialized
INFO - 2023-08-15 12:08:44 --> Security Class Initialized
DEBUG - 2023-08-15 12:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:08:44 --> Input Class Initialized
INFO - 2023-08-15 12:08:44 --> Language Class Initialized
ERROR - 2023-08-15 12:08:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:08:44 --> Config Class Initialized
INFO - 2023-08-15 12:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:08:44 --> Utf8 Class Initialized
INFO - 2023-08-15 12:08:44 --> URI Class Initialized
INFO - 2023-08-15 12:08:44 --> Router Class Initialized
INFO - 2023-08-15 12:08:44 --> Output Class Initialized
INFO - 2023-08-15 12:08:44 --> Security Class Initialized
DEBUG - 2023-08-15 12:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:08:44 --> Input Class Initialized
INFO - 2023-08-15 12:08:44 --> Language Class Initialized
ERROR - 2023-08-15 12:08:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:08:44 --> Config Class Initialized
INFO - 2023-08-15 12:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:08:44 --> Utf8 Class Initialized
INFO - 2023-08-15 12:08:44 --> URI Class Initialized
INFO - 2023-08-15 12:08:44 --> Router Class Initialized
INFO - 2023-08-15 12:08:44 --> Output Class Initialized
INFO - 2023-08-15 12:08:44 --> Security Class Initialized
DEBUG - 2023-08-15 12:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:08:44 --> Input Class Initialized
INFO - 2023-08-15 12:08:44 --> Language Class Initialized
ERROR - 2023-08-15 12:08:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:08:44 --> Config Class Initialized
INFO - 2023-08-15 12:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:08:44 --> Utf8 Class Initialized
INFO - 2023-08-15 12:08:44 --> URI Class Initialized
INFO - 2023-08-15 12:08:44 --> Router Class Initialized
INFO - 2023-08-15 12:08:44 --> Output Class Initialized
INFO - 2023-08-15 12:08:44 --> Security Class Initialized
DEBUG - 2023-08-15 12:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:08:44 --> Input Class Initialized
INFO - 2023-08-15 12:08:44 --> Language Class Initialized
ERROR - 2023-08-15 12:08:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:08:44 --> Config Class Initialized
INFO - 2023-08-15 12:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:08:44 --> Utf8 Class Initialized
INFO - 2023-08-15 12:08:44 --> URI Class Initialized
INFO - 2023-08-15 12:08:44 --> Router Class Initialized
INFO - 2023-08-15 12:08:44 --> Output Class Initialized
INFO - 2023-08-15 12:08:44 --> Security Class Initialized
DEBUG - 2023-08-15 12:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:08:44 --> Input Class Initialized
INFO - 2023-08-15 12:08:44 --> Language Class Initialized
ERROR - 2023-08-15 12:08:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:08:44 --> Config Class Initialized
INFO - 2023-08-15 12:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:08:44 --> Utf8 Class Initialized
INFO - 2023-08-15 12:08:44 --> URI Class Initialized
INFO - 2023-08-15 12:08:44 --> Router Class Initialized
INFO - 2023-08-15 12:08:44 --> Output Class Initialized
INFO - 2023-08-15 12:08:44 --> Security Class Initialized
DEBUG - 2023-08-15 12:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:08:44 --> Input Class Initialized
INFO - 2023-08-15 12:08:44 --> Language Class Initialized
ERROR - 2023-08-15 12:08:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:08:44 --> Config Class Initialized
INFO - 2023-08-15 12:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:08:44 --> Utf8 Class Initialized
INFO - 2023-08-15 12:08:44 --> URI Class Initialized
INFO - 2023-08-15 12:08:44 --> Router Class Initialized
INFO - 2023-08-15 12:08:44 --> Output Class Initialized
INFO - 2023-08-15 12:08:44 --> Security Class Initialized
DEBUG - 2023-08-15 12:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:08:44 --> Input Class Initialized
INFO - 2023-08-15 12:08:44 --> Language Class Initialized
ERROR - 2023-08-15 12:08:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:08:44 --> Config Class Initialized
INFO - 2023-08-15 12:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:08:44 --> Utf8 Class Initialized
INFO - 2023-08-15 12:08:44 --> URI Class Initialized
INFO - 2023-08-15 12:08:44 --> Router Class Initialized
INFO - 2023-08-15 12:08:44 --> Output Class Initialized
INFO - 2023-08-15 12:08:44 --> Security Class Initialized
DEBUG - 2023-08-15 12:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:08:44 --> Input Class Initialized
INFO - 2023-08-15 12:08:45 --> Language Class Initialized
ERROR - 2023-08-15 12:08:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:12:52 --> Config Class Initialized
INFO - 2023-08-15 12:12:52 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:12:52 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:12:52 --> Utf8 Class Initialized
INFO - 2023-08-15 12:12:52 --> URI Class Initialized
INFO - 2023-08-15 12:12:52 --> Router Class Initialized
INFO - 2023-08-15 12:12:52 --> Output Class Initialized
INFO - 2023-08-15 12:12:52 --> Security Class Initialized
DEBUG - 2023-08-15 12:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:12:52 --> Input Class Initialized
INFO - 2023-08-15 12:12:52 --> Language Class Initialized
INFO - 2023-08-15 12:12:52 --> Loader Class Initialized
INFO - 2023-08-15 12:12:52 --> Helper loaded: url_helper
INFO - 2023-08-15 12:12:52 --> Helper loaded: file_helper
INFO - 2023-08-15 12:12:52 --> Database Driver Class Initialized
INFO - 2023-08-15 12:12:52 --> Email Class Initialized
DEBUG - 2023-08-15 12:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:12:52 --> Controller Class Initialized
INFO - 2023-08-15 12:12:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-15 12:12:52 --> Final output sent to browser
DEBUG - 2023-08-15 12:12:52 --> Total execution time: 0.0915
INFO - 2023-08-15 12:12:53 --> Config Class Initialized
INFO - 2023-08-15 12:12:53 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:12:53 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:12:53 --> Utf8 Class Initialized
INFO - 2023-08-15 12:12:53 --> URI Class Initialized
INFO - 2023-08-15 12:12:53 --> Router Class Initialized
INFO - 2023-08-15 12:12:53 --> Output Class Initialized
INFO - 2023-08-15 12:12:53 --> Security Class Initialized
DEBUG - 2023-08-15 12:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:12:53 --> Input Class Initialized
INFO - 2023-08-15 12:12:53 --> Language Class Initialized
ERROR - 2023-08-15 12:12:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:12:53 --> Config Class Initialized
INFO - 2023-08-15 12:12:53 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:12:53 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:12:53 --> Utf8 Class Initialized
INFO - 2023-08-15 12:12:53 --> URI Class Initialized
INFO - 2023-08-15 12:12:53 --> Router Class Initialized
INFO - 2023-08-15 12:12:53 --> Output Class Initialized
INFO - 2023-08-15 12:12:53 --> Security Class Initialized
DEBUG - 2023-08-15 12:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:12:53 --> Input Class Initialized
INFO - 2023-08-15 12:12:53 --> Language Class Initialized
ERROR - 2023-08-15 12:12:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:15:28 --> Config Class Initialized
INFO - 2023-08-15 12:15:28 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:15:28 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:15:28 --> Utf8 Class Initialized
INFO - 2023-08-15 12:15:28 --> URI Class Initialized
INFO - 2023-08-15 12:15:28 --> Router Class Initialized
INFO - 2023-08-15 12:15:28 --> Output Class Initialized
INFO - 2023-08-15 12:15:28 --> Security Class Initialized
DEBUG - 2023-08-15 12:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:15:28 --> Input Class Initialized
INFO - 2023-08-15 12:15:28 --> Language Class Initialized
INFO - 2023-08-15 12:15:28 --> Loader Class Initialized
INFO - 2023-08-15 12:15:28 --> Helper loaded: url_helper
INFO - 2023-08-15 12:15:28 --> Helper loaded: file_helper
INFO - 2023-08-15 12:15:28 --> Database Driver Class Initialized
INFO - 2023-08-15 12:15:28 --> Email Class Initialized
DEBUG - 2023-08-15 12:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:15:28 --> Controller Class Initialized
INFO - 2023-08-15 12:15:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-15 12:15:28 --> Final output sent to browser
DEBUG - 2023-08-15 12:15:28 --> Total execution time: 0.0740
INFO - 2023-08-15 12:15:29 --> Config Class Initialized
INFO - 2023-08-15 12:15:29 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:15:29 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:15:29 --> Utf8 Class Initialized
INFO - 2023-08-15 12:15:29 --> URI Class Initialized
INFO - 2023-08-15 12:15:29 --> Router Class Initialized
INFO - 2023-08-15 12:15:29 --> Output Class Initialized
INFO - 2023-08-15 12:15:29 --> Security Class Initialized
DEBUG - 2023-08-15 12:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:15:29 --> Input Class Initialized
INFO - 2023-08-15 12:15:29 --> Language Class Initialized
ERROR - 2023-08-15 12:15:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:15:29 --> Config Class Initialized
INFO - 2023-08-15 12:15:29 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:15:29 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:15:29 --> Utf8 Class Initialized
INFO - 2023-08-15 12:15:29 --> URI Class Initialized
INFO - 2023-08-15 12:15:29 --> Router Class Initialized
INFO - 2023-08-15 12:15:29 --> Output Class Initialized
INFO - 2023-08-15 12:15:29 --> Security Class Initialized
DEBUG - 2023-08-15 12:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:15:29 --> Input Class Initialized
INFO - 2023-08-15 12:15:29 --> Language Class Initialized
ERROR - 2023-08-15 12:15:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:22:07 --> Config Class Initialized
INFO - 2023-08-15 12:22:07 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:22:07 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:22:07 --> Utf8 Class Initialized
INFO - 2023-08-15 12:22:07 --> URI Class Initialized
INFO - 2023-08-15 12:22:07 --> Router Class Initialized
INFO - 2023-08-15 12:22:07 --> Output Class Initialized
INFO - 2023-08-15 12:22:07 --> Security Class Initialized
DEBUG - 2023-08-15 12:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:22:07 --> Input Class Initialized
INFO - 2023-08-15 12:22:07 --> Language Class Initialized
ERROR - 2023-08-15 12:22:07 --> 404 Page Not Found: Indexhtml/index
INFO - 2023-08-15 12:22:08 --> Config Class Initialized
INFO - 2023-08-15 12:22:08 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:22:08 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:22:08 --> Utf8 Class Initialized
INFO - 2023-08-15 12:22:08 --> URI Class Initialized
INFO - 2023-08-15 12:22:08 --> Router Class Initialized
INFO - 2023-08-15 12:22:08 --> Output Class Initialized
INFO - 2023-08-15 12:22:08 --> Security Class Initialized
DEBUG - 2023-08-15 12:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:22:08 --> Input Class Initialized
INFO - 2023-08-15 12:22:08 --> Language Class Initialized
INFO - 2023-08-15 12:22:08 --> Loader Class Initialized
INFO - 2023-08-15 12:22:08 --> Helper loaded: url_helper
INFO - 2023-08-15 12:22:08 --> Helper loaded: file_helper
INFO - 2023-08-15 12:22:08 --> Database Driver Class Initialized
INFO - 2023-08-15 12:22:08 --> Email Class Initialized
DEBUG - 2023-08-15 12:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:22:08 --> Controller Class Initialized
INFO - 2023-08-15 12:22:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-15 12:22:08 --> Final output sent to browser
DEBUG - 2023-08-15 12:22:08 --> Total execution time: 0.0404
INFO - 2023-08-15 12:22:13 --> Config Class Initialized
INFO - 2023-08-15 12:22:13 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:22:13 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:22:13 --> Utf8 Class Initialized
INFO - 2023-08-15 12:22:13 --> URI Class Initialized
INFO - 2023-08-15 12:22:13 --> Router Class Initialized
INFO - 2023-08-15 12:22:13 --> Output Class Initialized
INFO - 2023-08-15 12:22:13 --> Security Class Initialized
DEBUG - 2023-08-15 12:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:22:13 --> Input Class Initialized
INFO - 2023-08-15 12:22:13 --> Language Class Initialized
INFO - 2023-08-15 12:22:13 --> Loader Class Initialized
INFO - 2023-08-15 12:22:13 --> Helper loaded: url_helper
INFO - 2023-08-15 12:22:13 --> Helper loaded: file_helper
INFO - 2023-08-15 12:22:13 --> Database Driver Class Initialized
INFO - 2023-08-15 12:22:13 --> Email Class Initialized
DEBUG - 2023-08-15 12:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:22:13 --> Controller Class Initialized
INFO - 2023-08-15 12:22:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-15 12:22:13 --> Final output sent to browser
DEBUG - 2023-08-15 12:22:13 --> Total execution time: 0.0527
INFO - 2023-08-15 12:22:14 --> Config Class Initialized
INFO - 2023-08-15 12:22:14 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:22:14 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:22:14 --> Utf8 Class Initialized
INFO - 2023-08-15 12:22:14 --> URI Class Initialized
INFO - 2023-08-15 12:22:14 --> Router Class Initialized
INFO - 2023-08-15 12:22:14 --> Output Class Initialized
INFO - 2023-08-15 12:22:14 --> Security Class Initialized
DEBUG - 2023-08-15 12:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:22:14 --> Input Class Initialized
INFO - 2023-08-15 12:22:14 --> Language Class Initialized
ERROR - 2023-08-15 12:22:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:22:14 --> Config Class Initialized
INFO - 2023-08-15 12:22:14 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:22:14 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:22:14 --> Utf8 Class Initialized
INFO - 2023-08-15 12:22:14 --> URI Class Initialized
INFO - 2023-08-15 12:22:14 --> Router Class Initialized
INFO - 2023-08-15 12:22:14 --> Output Class Initialized
INFO - 2023-08-15 12:22:14 --> Security Class Initialized
DEBUG - 2023-08-15 12:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:22:14 --> Input Class Initialized
INFO - 2023-08-15 12:22:14 --> Language Class Initialized
ERROR - 2023-08-15 12:22:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:22:39 --> Config Class Initialized
INFO - 2023-08-15 12:22:39 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:22:39 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:22:39 --> Utf8 Class Initialized
INFO - 2023-08-15 12:22:39 --> URI Class Initialized
INFO - 2023-08-15 12:22:39 --> Router Class Initialized
INFO - 2023-08-15 12:22:39 --> Output Class Initialized
INFO - 2023-08-15 12:22:39 --> Security Class Initialized
DEBUG - 2023-08-15 12:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:22:39 --> Input Class Initialized
INFO - 2023-08-15 12:22:39 --> Language Class Initialized
INFO - 2023-08-15 12:22:39 --> Loader Class Initialized
INFO - 2023-08-15 12:22:39 --> Helper loaded: url_helper
INFO - 2023-08-15 12:22:39 --> Helper loaded: file_helper
INFO - 2023-08-15 12:22:39 --> Database Driver Class Initialized
INFO - 2023-08-15 12:22:39 --> Email Class Initialized
DEBUG - 2023-08-15 12:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:22:39 --> Controller Class Initialized
INFO - 2023-08-15 12:22:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-15 12:22:40 --> Final output sent to browser
DEBUG - 2023-08-15 12:22:40 --> Total execution time: 0.0934
INFO - 2023-08-15 12:22:40 --> Config Class Initialized
INFO - 2023-08-15 12:22:40 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:22:40 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:22:40 --> Utf8 Class Initialized
INFO - 2023-08-15 12:22:40 --> URI Class Initialized
INFO - 2023-08-15 12:22:40 --> Router Class Initialized
INFO - 2023-08-15 12:22:40 --> Output Class Initialized
INFO - 2023-08-15 12:22:40 --> Security Class Initialized
DEBUG - 2023-08-15 12:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:22:40 --> Input Class Initialized
INFO - 2023-08-15 12:22:40 --> Language Class Initialized
ERROR - 2023-08-15 12:22:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:22:40 --> Config Class Initialized
INFO - 2023-08-15 12:22:40 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:22:40 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:22:40 --> Utf8 Class Initialized
INFO - 2023-08-15 12:22:40 --> URI Class Initialized
INFO - 2023-08-15 12:22:40 --> Router Class Initialized
INFO - 2023-08-15 12:22:40 --> Output Class Initialized
INFO - 2023-08-15 12:22:40 --> Security Class Initialized
DEBUG - 2023-08-15 12:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:22:40 --> Input Class Initialized
INFO - 2023-08-15 12:22:40 --> Language Class Initialized
ERROR - 2023-08-15 12:22:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:23:02 --> Config Class Initialized
INFO - 2023-08-15 12:23:02 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:23:02 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:23:02 --> Utf8 Class Initialized
INFO - 2023-08-15 12:23:02 --> URI Class Initialized
INFO - 2023-08-15 12:23:02 --> Router Class Initialized
INFO - 2023-08-15 12:23:02 --> Output Class Initialized
INFO - 2023-08-15 12:23:02 --> Security Class Initialized
DEBUG - 2023-08-15 12:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:23:02 --> Input Class Initialized
INFO - 2023-08-15 12:23:02 --> Language Class Initialized
INFO - 2023-08-15 12:23:02 --> Loader Class Initialized
INFO - 2023-08-15 12:23:02 --> Helper loaded: url_helper
INFO - 2023-08-15 12:23:02 --> Helper loaded: file_helper
INFO - 2023-08-15 12:23:02 --> Database Driver Class Initialized
INFO - 2023-08-15 12:23:02 --> Email Class Initialized
DEBUG - 2023-08-15 12:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:23:02 --> Controller Class Initialized
INFO - 2023-08-15 12:23:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-15 12:23:03 --> Final output sent to browser
DEBUG - 2023-08-15 12:23:03 --> Total execution time: 0.1234
INFO - 2023-08-15 12:23:03 --> Config Class Initialized
INFO - 2023-08-15 12:23:03 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:23:03 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:23:03 --> Utf8 Class Initialized
INFO - 2023-08-15 12:23:03 --> URI Class Initialized
INFO - 2023-08-15 12:23:03 --> Router Class Initialized
INFO - 2023-08-15 12:23:03 --> Output Class Initialized
INFO - 2023-08-15 12:23:03 --> Security Class Initialized
DEBUG - 2023-08-15 12:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:23:03 --> Input Class Initialized
INFO - 2023-08-15 12:23:03 --> Language Class Initialized
ERROR - 2023-08-15 12:23:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:23:03 --> Config Class Initialized
INFO - 2023-08-15 12:23:03 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:23:03 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:23:03 --> Utf8 Class Initialized
INFO - 2023-08-15 12:23:03 --> URI Class Initialized
INFO - 2023-08-15 12:23:03 --> Router Class Initialized
INFO - 2023-08-15 12:23:03 --> Output Class Initialized
INFO - 2023-08-15 12:23:03 --> Security Class Initialized
DEBUG - 2023-08-15 12:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:23:03 --> Input Class Initialized
INFO - 2023-08-15 12:23:03 --> Language Class Initialized
ERROR - 2023-08-15 12:23:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 12:53:13 --> Config Class Initialized
INFO - 2023-08-15 12:53:13 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:53:13 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:53:13 --> Utf8 Class Initialized
INFO - 2023-08-15 12:53:13 --> URI Class Initialized
INFO - 2023-08-15 12:53:13 --> Router Class Initialized
INFO - 2023-08-15 12:53:13 --> Output Class Initialized
INFO - 2023-08-15 12:53:13 --> Security Class Initialized
DEBUG - 2023-08-15 12:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:53:13 --> Input Class Initialized
INFO - 2023-08-15 12:53:13 --> Language Class Initialized
INFO - 2023-08-15 12:53:13 --> Loader Class Initialized
INFO - 2023-08-15 12:53:13 --> Helper loaded: url_helper
INFO - 2023-08-15 12:53:13 --> Helper loaded: file_helper
INFO - 2023-08-15 12:53:13 --> Database Driver Class Initialized
INFO - 2023-08-15 12:53:13 --> Email Class Initialized
DEBUG - 2023-08-15 12:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:53:13 --> Controller Class Initialized
INFO - 2023-08-15 12:53:13 --> Model "Banner_model" initialized
INFO - 2023-08-15 12:53:13 --> Helper loaded: form_helper
INFO - 2023-08-15 12:53:13 --> Form Validation Class Initialized
INFO - 2023-08-15 12:53:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-15 12:53:13 --> Final output sent to browser
DEBUG - 2023-08-15 12:53:13 --> Total execution time: 0.1169
INFO - 2023-08-15 12:53:15 --> Config Class Initialized
INFO - 2023-08-15 12:53:15 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:53:15 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:53:15 --> Utf8 Class Initialized
INFO - 2023-08-15 12:53:15 --> URI Class Initialized
INFO - 2023-08-15 12:53:15 --> Router Class Initialized
INFO - 2023-08-15 12:53:15 --> Output Class Initialized
INFO - 2023-08-15 12:53:15 --> Security Class Initialized
DEBUG - 2023-08-15 12:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:53:15 --> Input Class Initialized
INFO - 2023-08-15 12:53:15 --> Language Class Initialized
INFO - 2023-08-15 12:53:15 --> Loader Class Initialized
INFO - 2023-08-15 12:53:15 --> Helper loaded: url_helper
INFO - 2023-08-15 12:53:15 --> Helper loaded: file_helper
INFO - 2023-08-15 12:53:15 --> Database Driver Class Initialized
INFO - 2023-08-15 12:53:15 --> Email Class Initialized
DEBUG - 2023-08-15 12:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:53:15 --> Controller Class Initialized
INFO - 2023-08-15 12:53:15 --> Model "Banner_model" initialized
INFO - 2023-08-15 12:53:15 --> Helper loaded: form_helper
INFO - 2023-08-15 12:53:15 --> Form Validation Class Initialized
INFO - 2023-08-15 12:53:15 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-15 12:53:15 --> Final output sent to browser
DEBUG - 2023-08-15 12:53:15 --> Total execution time: 0.0762
INFO - 2023-08-15 12:53:19 --> Config Class Initialized
INFO - 2023-08-15 12:53:19 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:53:19 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:53:19 --> Utf8 Class Initialized
INFO - 2023-08-15 12:53:19 --> URI Class Initialized
INFO - 2023-08-15 12:53:19 --> Router Class Initialized
INFO - 2023-08-15 12:53:19 --> Output Class Initialized
INFO - 2023-08-15 12:53:19 --> Security Class Initialized
DEBUG - 2023-08-15 12:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:53:19 --> Input Class Initialized
INFO - 2023-08-15 12:53:19 --> Language Class Initialized
INFO - 2023-08-15 12:53:19 --> Loader Class Initialized
INFO - 2023-08-15 12:53:19 --> Helper loaded: url_helper
INFO - 2023-08-15 12:53:19 --> Helper loaded: file_helper
INFO - 2023-08-15 12:53:19 --> Database Driver Class Initialized
INFO - 2023-08-15 12:53:19 --> Email Class Initialized
DEBUG - 2023-08-15 12:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:53:19 --> Controller Class Initialized
INFO - 2023-08-15 12:53:19 --> Model "Banner_model" initialized
INFO - 2023-08-15 12:53:19 --> Helper loaded: form_helper
INFO - 2023-08-15 12:53:19 --> Form Validation Class Initialized
INFO - 2023-08-15 12:53:19 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_create.php
INFO - 2023-08-15 12:53:19 --> Final output sent to browser
DEBUG - 2023-08-15 12:53:19 --> Total execution time: 0.0976
INFO - 2023-08-15 12:53:19 --> Config Class Initialized
INFO - 2023-08-15 12:53:19 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:53:19 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:53:19 --> Utf8 Class Initialized
INFO - 2023-08-15 12:53:19 --> URI Class Initialized
INFO - 2023-08-15 12:53:19 --> Router Class Initialized
INFO - 2023-08-15 12:53:19 --> Output Class Initialized
INFO - 2023-08-15 12:53:19 --> Security Class Initialized
DEBUG - 2023-08-15 12:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:53:19 --> Input Class Initialized
INFO - 2023-08-15 12:53:19 --> Language Class Initialized
ERROR - 2023-08-15 12:53:19 --> 404 Page Not Found: admin/Banner/images
INFO - 2023-08-15 12:57:13 --> Config Class Initialized
INFO - 2023-08-15 12:57:13 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:57:13 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:57:13 --> Utf8 Class Initialized
INFO - 2023-08-15 12:57:13 --> URI Class Initialized
INFO - 2023-08-15 12:57:13 --> Router Class Initialized
INFO - 2023-08-15 12:57:13 --> Output Class Initialized
INFO - 2023-08-15 12:57:13 --> Security Class Initialized
DEBUG - 2023-08-15 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:57:13 --> Input Class Initialized
INFO - 2023-08-15 12:57:13 --> Language Class Initialized
INFO - 2023-08-15 12:57:13 --> Loader Class Initialized
INFO - 2023-08-15 12:57:13 --> Helper loaded: url_helper
INFO - 2023-08-15 12:57:13 --> Helper loaded: file_helper
INFO - 2023-08-15 12:57:13 --> Database Driver Class Initialized
INFO - 2023-08-15 12:57:13 --> Email Class Initialized
DEBUG - 2023-08-15 12:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:57:13 --> Controller Class Initialized
INFO - 2023-08-15 12:57:13 --> Model "Banner_model" initialized
INFO - 2023-08-15 12:57:13 --> Helper loaded: form_helper
INFO - 2023-08-15 12:57:13 --> Form Validation Class Initialized
INFO - 2023-08-15 12:57:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-15 12:57:13 --> Config Class Initialized
INFO - 2023-08-15 12:57:13 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:57:13 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:57:13 --> Utf8 Class Initialized
INFO - 2023-08-15 12:57:13 --> URI Class Initialized
INFO - 2023-08-15 12:57:13 --> Router Class Initialized
INFO - 2023-08-15 12:57:13 --> Output Class Initialized
INFO - 2023-08-15 12:57:13 --> Security Class Initialized
DEBUG - 2023-08-15 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:57:13 --> Input Class Initialized
INFO - 2023-08-15 12:57:13 --> Language Class Initialized
INFO - 2023-08-15 12:57:13 --> Loader Class Initialized
INFO - 2023-08-15 12:57:13 --> Helper loaded: url_helper
INFO - 2023-08-15 12:57:13 --> Helper loaded: file_helper
INFO - 2023-08-15 12:57:13 --> Database Driver Class Initialized
INFO - 2023-08-15 12:57:13 --> Email Class Initialized
DEBUG - 2023-08-15 12:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:57:13 --> Controller Class Initialized
INFO - 2023-08-15 12:57:13 --> Model "Banner_model" initialized
INFO - 2023-08-15 12:57:13 --> Helper loaded: form_helper
INFO - 2023-08-15 12:57:13 --> Form Validation Class Initialized
INFO - 2023-08-15 12:57:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-15 12:57:13 --> Final output sent to browser
DEBUG - 2023-08-15 12:57:13 --> Total execution time: 0.1786
INFO - 2023-08-15 12:57:20 --> Config Class Initialized
INFO - 2023-08-15 12:57:20 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:57:20 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:57:20 --> Utf8 Class Initialized
INFO - 2023-08-15 12:57:20 --> URI Class Initialized
INFO - 2023-08-15 12:57:20 --> Router Class Initialized
INFO - 2023-08-15 12:57:20 --> Output Class Initialized
INFO - 2023-08-15 12:57:20 --> Security Class Initialized
DEBUG - 2023-08-15 12:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:57:20 --> Input Class Initialized
INFO - 2023-08-15 12:57:20 --> Language Class Initialized
INFO - 2023-08-15 12:57:20 --> Loader Class Initialized
INFO - 2023-08-15 12:57:20 --> Helper loaded: url_helper
INFO - 2023-08-15 12:57:20 --> Helper loaded: file_helper
INFO - 2023-08-15 12:57:20 --> Database Driver Class Initialized
INFO - 2023-08-15 12:57:20 --> Email Class Initialized
DEBUG - 2023-08-15 12:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:57:20 --> Controller Class Initialized
INFO - 2023-08-15 12:57:20 --> Model "Banner_model" initialized
INFO - 2023-08-15 12:57:20 --> Helper loaded: form_helper
INFO - 2023-08-15 12:57:20 --> Form Validation Class Initialized
INFO - 2023-08-15 12:57:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_create.php
INFO - 2023-08-15 12:57:21 --> Final output sent to browser
DEBUG - 2023-08-15 12:57:21 --> Total execution time: 0.0536
INFO - 2023-08-15 12:57:35 --> Config Class Initialized
INFO - 2023-08-15 12:57:35 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:57:35 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:57:35 --> Utf8 Class Initialized
INFO - 2023-08-15 12:57:35 --> URI Class Initialized
INFO - 2023-08-15 12:57:35 --> Router Class Initialized
INFO - 2023-08-15 12:57:35 --> Output Class Initialized
INFO - 2023-08-15 12:57:35 --> Security Class Initialized
DEBUG - 2023-08-15 12:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:57:35 --> Input Class Initialized
INFO - 2023-08-15 12:57:35 --> Language Class Initialized
INFO - 2023-08-15 12:57:35 --> Loader Class Initialized
INFO - 2023-08-15 12:57:35 --> Helper loaded: url_helper
INFO - 2023-08-15 12:57:35 --> Helper loaded: file_helper
INFO - 2023-08-15 12:57:35 --> Database Driver Class Initialized
INFO - 2023-08-15 12:57:35 --> Email Class Initialized
DEBUG - 2023-08-15 12:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:57:35 --> Controller Class Initialized
INFO - 2023-08-15 12:57:35 --> Model "Banner_model" initialized
INFO - 2023-08-15 12:57:35 --> Helper loaded: form_helper
INFO - 2023-08-15 12:57:35 --> Form Validation Class Initialized
INFO - 2023-08-15 12:57:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-15 12:57:35 --> Config Class Initialized
INFO - 2023-08-15 12:57:35 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:57:35 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:57:35 --> Utf8 Class Initialized
INFO - 2023-08-15 12:57:35 --> URI Class Initialized
INFO - 2023-08-15 12:57:35 --> Router Class Initialized
INFO - 2023-08-15 12:57:35 --> Output Class Initialized
INFO - 2023-08-15 12:57:35 --> Security Class Initialized
DEBUG - 2023-08-15 12:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:57:35 --> Input Class Initialized
INFO - 2023-08-15 12:57:35 --> Language Class Initialized
INFO - 2023-08-15 12:57:35 --> Loader Class Initialized
INFO - 2023-08-15 12:57:35 --> Helper loaded: url_helper
INFO - 2023-08-15 12:57:35 --> Helper loaded: file_helper
INFO - 2023-08-15 12:57:35 --> Database Driver Class Initialized
INFO - 2023-08-15 12:57:35 --> Email Class Initialized
DEBUG - 2023-08-15 12:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:57:35 --> Controller Class Initialized
INFO - 2023-08-15 12:57:35 --> Model "Banner_model" initialized
INFO - 2023-08-15 12:57:35 --> Helper loaded: form_helper
INFO - 2023-08-15 12:57:35 --> Form Validation Class Initialized
INFO - 2023-08-15 12:57:35 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-15 12:57:35 --> Final output sent to browser
DEBUG - 2023-08-15 12:57:35 --> Total execution time: 0.1581
INFO - 2023-08-15 12:57:37 --> Config Class Initialized
INFO - 2023-08-15 12:57:37 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:57:37 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:57:37 --> Utf8 Class Initialized
INFO - 2023-08-15 12:57:37 --> URI Class Initialized
INFO - 2023-08-15 12:57:37 --> Router Class Initialized
INFO - 2023-08-15 12:57:37 --> Output Class Initialized
INFO - 2023-08-15 12:57:37 --> Security Class Initialized
DEBUG - 2023-08-15 12:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:57:37 --> Input Class Initialized
INFO - 2023-08-15 12:57:37 --> Language Class Initialized
INFO - 2023-08-15 12:57:37 --> Loader Class Initialized
INFO - 2023-08-15 12:57:37 --> Helper loaded: url_helper
INFO - 2023-08-15 12:57:37 --> Helper loaded: file_helper
INFO - 2023-08-15 12:57:37 --> Database Driver Class Initialized
INFO - 2023-08-15 12:57:37 --> Email Class Initialized
DEBUG - 2023-08-15 12:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:57:37 --> Controller Class Initialized
INFO - 2023-08-15 12:57:37 --> Model "Banner_model" initialized
INFO - 2023-08-15 12:57:37 --> Helper loaded: form_helper
INFO - 2023-08-15 12:57:37 --> Form Validation Class Initialized
INFO - 2023-08-15 12:57:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_create.php
INFO - 2023-08-15 12:57:37 --> Final output sent to browser
DEBUG - 2023-08-15 12:57:37 --> Total execution time: 0.0532
INFO - 2023-08-15 12:57:55 --> Config Class Initialized
INFO - 2023-08-15 12:57:55 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:57:55 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:57:55 --> Utf8 Class Initialized
INFO - 2023-08-15 12:57:55 --> URI Class Initialized
INFO - 2023-08-15 12:57:55 --> Router Class Initialized
INFO - 2023-08-15 12:57:55 --> Output Class Initialized
INFO - 2023-08-15 12:57:55 --> Security Class Initialized
DEBUG - 2023-08-15 12:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:57:55 --> Input Class Initialized
INFO - 2023-08-15 12:57:55 --> Language Class Initialized
INFO - 2023-08-15 12:57:55 --> Loader Class Initialized
INFO - 2023-08-15 12:57:55 --> Helper loaded: url_helper
INFO - 2023-08-15 12:57:55 --> Helper loaded: file_helper
INFO - 2023-08-15 12:57:55 --> Database Driver Class Initialized
INFO - 2023-08-15 12:57:55 --> Email Class Initialized
DEBUG - 2023-08-15 12:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:57:55 --> Controller Class Initialized
INFO - 2023-08-15 12:57:55 --> Model "Banner_model" initialized
INFO - 2023-08-15 12:57:55 --> Helper loaded: form_helper
INFO - 2023-08-15 12:57:55 --> Form Validation Class Initialized
INFO - 2023-08-15 12:57:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-15 12:57:55 --> Config Class Initialized
INFO - 2023-08-15 12:57:55 --> Hooks Class Initialized
DEBUG - 2023-08-15 12:57:55 --> UTF-8 Support Enabled
INFO - 2023-08-15 12:57:55 --> Utf8 Class Initialized
INFO - 2023-08-15 12:57:55 --> URI Class Initialized
INFO - 2023-08-15 12:57:55 --> Router Class Initialized
INFO - 2023-08-15 12:57:55 --> Output Class Initialized
INFO - 2023-08-15 12:57:55 --> Security Class Initialized
DEBUG - 2023-08-15 12:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 12:57:55 --> Input Class Initialized
INFO - 2023-08-15 12:57:55 --> Language Class Initialized
INFO - 2023-08-15 12:57:55 --> Loader Class Initialized
INFO - 2023-08-15 12:57:55 --> Helper loaded: url_helper
INFO - 2023-08-15 12:57:55 --> Helper loaded: file_helper
INFO - 2023-08-15 12:57:55 --> Database Driver Class Initialized
INFO - 2023-08-15 12:57:55 --> Email Class Initialized
DEBUG - 2023-08-15 12:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 12:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 12:57:55 --> Controller Class Initialized
INFO - 2023-08-15 12:57:55 --> Model "Banner_model" initialized
INFO - 2023-08-15 12:57:55 --> Helper loaded: form_helper
INFO - 2023-08-15 12:57:55 --> Form Validation Class Initialized
INFO - 2023-08-15 12:57:55 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-15 12:57:55 --> Final output sent to browser
DEBUG - 2023-08-15 12:57:55 --> Total execution time: 0.1078
INFO - 2023-08-15 13:10:07 --> Config Class Initialized
INFO - 2023-08-15 13:10:07 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:10:07 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:10:07 --> Utf8 Class Initialized
INFO - 2023-08-15 13:10:07 --> URI Class Initialized
INFO - 2023-08-15 13:10:07 --> Router Class Initialized
INFO - 2023-08-15 13:10:07 --> Output Class Initialized
INFO - 2023-08-15 13:10:07 --> Security Class Initialized
DEBUG - 2023-08-15 13:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:10:07 --> Input Class Initialized
INFO - 2023-08-15 13:10:07 --> Language Class Initialized
INFO - 2023-08-15 13:10:07 --> Loader Class Initialized
INFO - 2023-08-15 13:10:07 --> Helper loaded: url_helper
INFO - 2023-08-15 13:10:07 --> Helper loaded: file_helper
INFO - 2023-08-15 13:10:07 --> Database Driver Class Initialized
INFO - 2023-08-15 13:10:07 --> Email Class Initialized
DEBUG - 2023-08-15 13:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:10:08 --> Controller Class Initialized
INFO - 2023-08-15 13:10:08 --> Model "Home_model" initialized
INFO - 2023-08-15 13:10:08 --> Helper loaded: form_helper
INFO - 2023-08-15 13:10:08 --> Form Validation Class Initialized
INFO - 2023-08-15 13:10:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:10:08 --> Final output sent to browser
DEBUG - 2023-08-15 13:10:08 --> Total execution time: 0.6619
INFO - 2023-08-15 13:10:09 --> Config Class Initialized
INFO - 2023-08-15 13:10:09 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:10:10 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:10:10 --> Utf8 Class Initialized
INFO - 2023-08-15 13:10:10 --> URI Class Initialized
INFO - 2023-08-15 13:10:10 --> Router Class Initialized
INFO - 2023-08-15 13:10:10 --> Output Class Initialized
INFO - 2023-08-15 13:10:10 --> Security Class Initialized
DEBUG - 2023-08-15 13:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:10:10 --> Input Class Initialized
INFO - 2023-08-15 13:10:10 --> Language Class Initialized
ERROR - 2023-08-15 13:10:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:10:10 --> Config Class Initialized
INFO - 2023-08-15 13:10:10 --> Config Class Initialized
INFO - 2023-08-15 13:10:10 --> Hooks Class Initialized
INFO - 2023-08-15 13:10:10 --> Hooks Class Initialized
INFO - 2023-08-15 13:10:10 --> Config Class Initialized
DEBUG - 2023-08-15 13:10:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-15 13:10:10 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:10:10 --> Utf8 Class Initialized
INFO - 2023-08-15 13:10:10 --> URI Class Initialized
INFO - 2023-08-15 13:10:10 --> Utf8 Class Initialized
INFO - 2023-08-15 13:10:10 --> Router Class Initialized
INFO - 2023-08-15 13:10:10 --> URI Class Initialized
INFO - 2023-08-15 13:10:10 --> Output Class Initialized
INFO - 2023-08-15 13:10:10 --> Hooks Class Initialized
INFO - 2023-08-15 13:10:10 --> Security Class Initialized
DEBUG - 2023-08-15 13:10:10 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:10:10 --> Utf8 Class Initialized
DEBUG - 2023-08-15 13:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:10:10 --> URI Class Initialized
INFO - 2023-08-15 13:10:10 --> Router Class Initialized
INFO - 2023-08-15 13:10:10 --> Router Class Initialized
INFO - 2023-08-15 13:10:10 --> Input Class Initialized
INFO - 2023-08-15 13:10:10 --> Output Class Initialized
INFO - 2023-08-15 13:10:10 --> Language Class Initialized
ERROR - 2023-08-15 13:10:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:10:10 --> Output Class Initialized
INFO - 2023-08-15 13:10:10 --> Security Class Initialized
INFO - 2023-08-15 13:10:10 --> Security Class Initialized
DEBUG - 2023-08-15 13:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-15 13:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:10:10 --> Input Class Initialized
INFO - 2023-08-15 13:10:10 --> Input Class Initialized
INFO - 2023-08-15 13:10:10 --> Language Class Initialized
ERROR - 2023-08-15 13:10:10 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:10:10 --> Language Class Initialized
ERROR - 2023-08-15 13:10:10 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:10:53 --> Config Class Initialized
INFO - 2023-08-15 13:10:53 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:10:53 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:10:53 --> Utf8 Class Initialized
INFO - 2023-08-15 13:10:53 --> URI Class Initialized
INFO - 2023-08-15 13:10:53 --> Router Class Initialized
INFO - 2023-08-15 13:10:53 --> Output Class Initialized
INFO - 2023-08-15 13:10:53 --> Security Class Initialized
DEBUG - 2023-08-15 13:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:10:54 --> Input Class Initialized
INFO - 2023-08-15 13:10:54 --> Language Class Initialized
INFO - 2023-08-15 13:10:54 --> Loader Class Initialized
INFO - 2023-08-15 13:10:54 --> Helper loaded: url_helper
INFO - 2023-08-15 13:10:54 --> Helper loaded: file_helper
INFO - 2023-08-15 13:10:54 --> Database Driver Class Initialized
INFO - 2023-08-15 13:10:54 --> Email Class Initialized
DEBUG - 2023-08-15 13:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:10:54 --> Controller Class Initialized
INFO - 2023-08-15 13:10:54 --> Model "Home_model" initialized
INFO - 2023-08-15 13:10:54 --> Helper loaded: form_helper
INFO - 2023-08-15 13:10:54 --> Form Validation Class Initialized
INFO - 2023-08-15 13:11:17 --> Config Class Initialized
INFO - 2023-08-15 13:11:17 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:11:17 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:11:17 --> Utf8 Class Initialized
INFO - 2023-08-15 13:11:17 --> URI Class Initialized
INFO - 2023-08-15 13:11:18 --> Router Class Initialized
INFO - 2023-08-15 13:11:18 --> Output Class Initialized
INFO - 2023-08-15 13:11:18 --> Security Class Initialized
DEBUG - 2023-08-15 13:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:11:18 --> Input Class Initialized
INFO - 2023-08-15 13:11:18 --> Language Class Initialized
INFO - 2023-08-15 13:11:18 --> Loader Class Initialized
INFO - 2023-08-15 13:11:18 --> Helper loaded: url_helper
INFO - 2023-08-15 13:11:18 --> Helper loaded: file_helper
INFO - 2023-08-15 13:11:18 --> Database Driver Class Initialized
INFO - 2023-08-15 13:11:18 --> Email Class Initialized
DEBUG - 2023-08-15 13:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:11:18 --> Controller Class Initialized
INFO - 2023-08-15 13:11:18 --> Model "Home_model" initialized
INFO - 2023-08-15 13:11:18 --> Helper loaded: form_helper
INFO - 2023-08-15 13:11:18 --> Form Validation Class Initialized
INFO - 2023-08-15 13:18:32 --> Config Class Initialized
INFO - 2023-08-15 13:18:32 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:18:32 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:18:32 --> Utf8 Class Initialized
INFO - 2023-08-15 13:18:32 --> URI Class Initialized
INFO - 2023-08-15 13:18:32 --> Router Class Initialized
INFO - 2023-08-15 13:18:32 --> Output Class Initialized
INFO - 2023-08-15 13:18:32 --> Security Class Initialized
DEBUG - 2023-08-15 13:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:18:32 --> Input Class Initialized
INFO - 2023-08-15 13:18:32 --> Language Class Initialized
INFO - 2023-08-15 13:18:32 --> Loader Class Initialized
INFO - 2023-08-15 13:18:32 --> Helper loaded: url_helper
INFO - 2023-08-15 13:18:32 --> Helper loaded: file_helper
INFO - 2023-08-15 13:18:32 --> Database Driver Class Initialized
INFO - 2023-08-15 13:18:32 --> Email Class Initialized
DEBUG - 2023-08-15 13:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:18:32 --> Controller Class Initialized
INFO - 2023-08-15 13:18:32 --> Model "Home_model" initialized
INFO - 2023-08-15 13:18:32 --> Helper loaded: form_helper
INFO - 2023-08-15 13:18:32 --> Form Validation Class Initialized
INFO - 2023-08-15 13:18:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:18:32 --> Final output sent to browser
DEBUG - 2023-08-15 13:18:33 --> Total execution time: 0.3572
INFO - 2023-08-15 13:18:33 --> Config Class Initialized
INFO - 2023-08-15 13:18:33 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:18:33 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:18:33 --> Utf8 Class Initialized
INFO - 2023-08-15 13:18:33 --> URI Class Initialized
INFO - 2023-08-15 13:18:33 --> Router Class Initialized
INFO - 2023-08-15 13:18:33 --> Output Class Initialized
INFO - 2023-08-15 13:18:33 --> Security Class Initialized
DEBUG - 2023-08-15 13:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:18:33 --> Input Class Initialized
INFO - 2023-08-15 13:18:33 --> Language Class Initialized
ERROR - 2023-08-15 13:18:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:18:33 --> Config Class Initialized
INFO - 2023-08-15 13:18:33 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:18:33 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:18:33 --> Utf8 Class Initialized
INFO - 2023-08-15 13:18:33 --> URI Class Initialized
INFO - 2023-08-15 13:18:33 --> Router Class Initialized
INFO - 2023-08-15 13:18:33 --> Output Class Initialized
INFO - 2023-08-15 13:18:33 --> Security Class Initialized
DEBUG - 2023-08-15 13:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:18:33 --> Input Class Initialized
INFO - 2023-08-15 13:18:33 --> Language Class Initialized
ERROR - 2023-08-15 13:18:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:18:34 --> Config Class Initialized
INFO - 2023-08-15 13:18:34 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:18:34 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:18:34 --> Utf8 Class Initialized
INFO - 2023-08-15 13:18:34 --> URI Class Initialized
INFO - 2023-08-15 13:18:34 --> Router Class Initialized
INFO - 2023-08-15 13:18:34 --> Output Class Initialized
INFO - 2023-08-15 13:18:34 --> Security Class Initialized
DEBUG - 2023-08-15 13:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:18:34 --> Input Class Initialized
INFO - 2023-08-15 13:18:34 --> Config Class Initialized
INFO - 2023-08-15 13:18:34 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:18:34 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:18:34 --> Utf8 Class Initialized
INFO - 2023-08-15 13:18:34 --> URI Class Initialized
INFO - 2023-08-15 13:18:34 --> Router Class Initialized
INFO - 2023-08-15 13:18:34 --> Output Class Initialized
INFO - 2023-08-15 13:18:34 --> Security Class Initialized
DEBUG - 2023-08-15 13:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:18:34 --> Input Class Initialized
INFO - 2023-08-15 13:18:34 --> Language Class Initialized
ERROR - 2023-08-15 13:18:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:18:34 --> Language Class Initialized
ERROR - 2023-08-15 13:18:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:23:33 --> Config Class Initialized
INFO - 2023-08-15 13:23:33 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:23:33 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:23:33 --> Utf8 Class Initialized
INFO - 2023-08-15 13:23:33 --> URI Class Initialized
INFO - 2023-08-15 13:23:33 --> Router Class Initialized
INFO - 2023-08-15 13:23:33 --> Output Class Initialized
INFO - 2023-08-15 13:23:33 --> Security Class Initialized
DEBUG - 2023-08-15 13:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:23:33 --> Input Class Initialized
INFO - 2023-08-15 13:23:33 --> Language Class Initialized
INFO - 2023-08-15 13:23:33 --> Loader Class Initialized
INFO - 2023-08-15 13:23:33 --> Helper loaded: url_helper
INFO - 2023-08-15 13:23:33 --> Helper loaded: file_helper
INFO - 2023-08-15 13:23:33 --> Database Driver Class Initialized
INFO - 2023-08-15 13:23:33 --> Email Class Initialized
DEBUG - 2023-08-15 13:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:23:33 --> Controller Class Initialized
INFO - 2023-08-15 13:23:33 --> Model "Home_model" initialized
INFO - 2023-08-15 13:23:33 --> Helper loaded: form_helper
INFO - 2023-08-15 13:23:33 --> Form Validation Class Initialized
INFO - 2023-08-15 13:23:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:23:33 --> Final output sent to browser
DEBUG - 2023-08-15 13:23:33 --> Total execution time: 0.3821
INFO - 2023-08-15 13:23:33 --> Config Class Initialized
INFO - 2023-08-15 13:23:33 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:23:33 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:23:33 --> Utf8 Class Initialized
INFO - 2023-08-15 13:23:33 --> URI Class Initialized
INFO - 2023-08-15 13:23:33 --> Router Class Initialized
INFO - 2023-08-15 13:23:33 --> Output Class Initialized
INFO - 2023-08-15 13:23:33 --> Security Class Initialized
DEBUG - 2023-08-15 13:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:23:33 --> Input Class Initialized
INFO - 2023-08-15 13:23:33 --> Language Class Initialized
ERROR - 2023-08-15 13:23:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:23:33 --> Config Class Initialized
INFO - 2023-08-15 13:23:33 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:23:33 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:23:33 --> Utf8 Class Initialized
INFO - 2023-08-15 13:23:33 --> URI Class Initialized
INFO - 2023-08-15 13:23:33 --> Router Class Initialized
INFO - 2023-08-15 13:23:33 --> Output Class Initialized
INFO - 2023-08-15 13:23:33 --> Security Class Initialized
DEBUG - 2023-08-15 13:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:23:33 --> Input Class Initialized
INFO - 2023-08-15 13:23:33 --> Language Class Initialized
ERROR - 2023-08-15 13:23:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:23:33 --> Config Class Initialized
INFO - 2023-08-15 13:23:33 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:23:33 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:23:33 --> Utf8 Class Initialized
INFO - 2023-08-15 13:23:33 --> URI Class Initialized
INFO - 2023-08-15 13:23:33 --> Router Class Initialized
INFO - 2023-08-15 13:23:33 --> Output Class Initialized
INFO - 2023-08-15 13:23:33 --> Security Class Initialized
DEBUG - 2023-08-15 13:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:23:33 --> Input Class Initialized
INFO - 2023-08-15 13:23:33 --> Language Class Initialized
ERROR - 2023-08-15 13:23:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:23:33 --> Config Class Initialized
INFO - 2023-08-15 13:23:33 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:23:33 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:23:33 --> Utf8 Class Initialized
INFO - 2023-08-15 13:23:33 --> URI Class Initialized
INFO - 2023-08-15 13:23:33 --> Router Class Initialized
INFO - 2023-08-15 13:23:33 --> Output Class Initialized
INFO - 2023-08-15 13:23:33 --> Security Class Initialized
DEBUG - 2023-08-15 13:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:23:34 --> Input Class Initialized
INFO - 2023-08-15 13:23:34 --> Language Class Initialized
ERROR - 2023-08-15 13:23:34 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:23:34 --> Config Class Initialized
INFO - 2023-08-15 13:23:34 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:23:34 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:23:34 --> Utf8 Class Initialized
INFO - 2023-08-15 13:23:34 --> URI Class Initialized
INFO - 2023-08-15 13:23:34 --> Router Class Initialized
INFO - 2023-08-15 13:23:34 --> Output Class Initialized
INFO - 2023-08-15 13:23:34 --> Security Class Initialized
DEBUG - 2023-08-15 13:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:23:34 --> Input Class Initialized
INFO - 2023-08-15 13:23:34 --> Language Class Initialized
ERROR - 2023-08-15 13:23:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:23:34 --> Config Class Initialized
INFO - 2023-08-15 13:23:34 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:23:34 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:23:34 --> Utf8 Class Initialized
INFO - 2023-08-15 13:23:34 --> URI Class Initialized
INFO - 2023-08-15 13:23:34 --> Router Class Initialized
INFO - 2023-08-15 13:23:34 --> Output Class Initialized
INFO - 2023-08-15 13:23:34 --> Security Class Initialized
DEBUG - 2023-08-15 13:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:23:34 --> Input Class Initialized
INFO - 2023-08-15 13:23:34 --> Language Class Initialized
ERROR - 2023-08-15 13:23:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:24:28 --> Config Class Initialized
INFO - 2023-08-15 13:24:28 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:24:28 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:24:28 --> Utf8 Class Initialized
INFO - 2023-08-15 13:24:28 --> URI Class Initialized
INFO - 2023-08-15 13:24:28 --> Router Class Initialized
INFO - 2023-08-15 13:24:29 --> Output Class Initialized
INFO - 2023-08-15 13:24:29 --> Security Class Initialized
DEBUG - 2023-08-15 13:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:24:29 --> Input Class Initialized
INFO - 2023-08-15 13:24:29 --> Language Class Initialized
INFO - 2023-08-15 13:24:29 --> Loader Class Initialized
INFO - 2023-08-15 13:24:29 --> Helper loaded: url_helper
INFO - 2023-08-15 13:24:29 --> Helper loaded: file_helper
INFO - 2023-08-15 13:24:29 --> Database Driver Class Initialized
INFO - 2023-08-15 13:24:29 --> Email Class Initialized
DEBUG - 2023-08-15 13:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:24:29 --> Controller Class Initialized
INFO - 2023-08-15 13:24:29 --> Model "Home_model" initialized
INFO - 2023-08-15 13:24:29 --> Helper loaded: form_helper
INFO - 2023-08-15 13:24:29 --> Form Validation Class Initialized
INFO - 2023-08-15 13:24:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:24:29 --> Final output sent to browser
DEBUG - 2023-08-15 13:24:29 --> Total execution time: 0.8822
INFO - 2023-08-15 13:24:30 --> Config Class Initialized
INFO - 2023-08-15 13:24:30 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:24:30 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:24:30 --> Utf8 Class Initialized
INFO - 2023-08-15 13:24:30 --> URI Class Initialized
INFO - 2023-08-15 13:24:30 --> Config Class Initialized
INFO - 2023-08-15 13:24:30 --> Config Class Initialized
INFO - 2023-08-15 13:24:30 --> Config Class Initialized
INFO - 2023-08-15 13:24:30 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:24:30 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:24:30 --> Hooks Class Initialized
INFO - 2023-08-15 13:24:30 --> Hooks Class Initialized
INFO - 2023-08-15 13:24:30 --> Router Class Initialized
DEBUG - 2023-08-15 13:24:30 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:24:30 --> Utf8 Class Initialized
DEBUG - 2023-08-15 13:24:30 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:24:30 --> URI Class Initialized
INFO - 2023-08-15 13:24:30 --> Output Class Initialized
INFO - 2023-08-15 13:24:30 --> Utf8 Class Initialized
INFO - 2023-08-15 13:24:30 --> URI Class Initialized
INFO - 2023-08-15 13:24:30 --> Router Class Initialized
INFO - 2023-08-15 13:24:30 --> Security Class Initialized
DEBUG - 2023-08-15 13:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:24:30 --> Input Class Initialized
INFO - 2023-08-15 13:24:30 --> Language Class Initialized
ERROR - 2023-08-15 13:24:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:24:30 --> Router Class Initialized
INFO - 2023-08-15 13:24:30 --> Output Class Initialized
INFO - 2023-08-15 13:24:30 --> Utf8 Class Initialized
INFO - 2023-08-15 13:24:30 --> Security Class Initialized
INFO - 2023-08-15 13:24:30 --> Output Class Initialized
DEBUG - 2023-08-15 13:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:24:30 --> Security Class Initialized
INFO - 2023-08-15 13:24:30 --> URI Class Initialized
DEBUG - 2023-08-15 13:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:24:30 --> Router Class Initialized
INFO - 2023-08-15 13:24:30 --> Output Class Initialized
INFO - 2023-08-15 13:24:30 --> Input Class Initialized
INFO - 2023-08-15 13:24:30 --> Input Class Initialized
INFO - 2023-08-15 13:24:31 --> Language Class Initialized
INFO - 2023-08-15 13:24:31 --> Security Class Initialized
ERROR - 2023-08-15 13:24:31 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-15 13:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:24:31 --> Input Class Initialized
INFO - 2023-08-15 13:24:31 --> Language Class Initialized
INFO - 2023-08-15 13:24:31 --> Language Class Initialized
ERROR - 2023-08-15 13:24:31 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-15 13:24:31 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:24:51 --> Config Class Initialized
INFO - 2023-08-15 13:24:51 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:24:51 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:24:51 --> Utf8 Class Initialized
INFO - 2023-08-15 13:24:51 --> URI Class Initialized
INFO - 2023-08-15 13:24:51 --> Router Class Initialized
INFO - 2023-08-15 13:24:51 --> Output Class Initialized
INFO - 2023-08-15 13:24:51 --> Security Class Initialized
DEBUG - 2023-08-15 13:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:24:51 --> Input Class Initialized
INFO - 2023-08-15 13:24:51 --> Language Class Initialized
INFO - 2023-08-15 13:24:51 --> Loader Class Initialized
INFO - 2023-08-15 13:24:51 --> Helper loaded: url_helper
INFO - 2023-08-15 13:24:51 --> Helper loaded: file_helper
INFO - 2023-08-15 13:24:51 --> Database Driver Class Initialized
INFO - 2023-08-15 13:24:51 --> Email Class Initialized
DEBUG - 2023-08-15 13:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:24:51 --> Controller Class Initialized
INFO - 2023-08-15 13:24:51 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:24:51 --> Helper loaded: form_helper
INFO - 2023-08-15 13:24:51 --> Form Validation Class Initialized
INFO - 2023-08-15 13:24:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-15 13:24:52 --> Final output sent to browser
DEBUG - 2023-08-15 13:24:52 --> Total execution time: 0.3948
INFO - 2023-08-15 13:24:54 --> Config Class Initialized
INFO - 2023-08-15 13:24:54 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:24:54 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:24:54 --> Utf8 Class Initialized
INFO - 2023-08-15 13:24:54 --> URI Class Initialized
INFO - 2023-08-15 13:24:54 --> Router Class Initialized
INFO - 2023-08-15 13:24:54 --> Output Class Initialized
INFO - 2023-08-15 13:24:54 --> Security Class Initialized
DEBUG - 2023-08-15 13:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:24:54 --> Input Class Initialized
INFO - 2023-08-15 13:24:54 --> Language Class Initialized
INFO - 2023-08-15 13:24:54 --> Loader Class Initialized
INFO - 2023-08-15 13:24:54 --> Helper loaded: url_helper
INFO - 2023-08-15 13:24:54 --> Helper loaded: file_helper
INFO - 2023-08-15 13:24:54 --> Database Driver Class Initialized
INFO - 2023-08-15 13:24:54 --> Email Class Initialized
DEBUG - 2023-08-15 13:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:24:55 --> Controller Class Initialized
INFO - 2023-08-15 13:24:55 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:24:55 --> Helper loaded: form_helper
INFO - 2023-08-15 13:24:55 --> Form Validation Class Initialized
INFO - 2023-08-15 13:24:55 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-15 13:24:55 --> Final output sent to browser
DEBUG - 2023-08-15 13:24:55 --> Total execution time: 0.6658
INFO - 2023-08-15 13:24:55 --> Config Class Initialized
INFO - 2023-08-15 13:24:55 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:24:55 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:24:55 --> Utf8 Class Initialized
INFO - 2023-08-15 13:24:55 --> URI Class Initialized
INFO - 2023-08-15 13:24:55 --> Router Class Initialized
INFO - 2023-08-15 13:24:55 --> Output Class Initialized
INFO - 2023-08-15 13:24:55 --> Security Class Initialized
DEBUG - 2023-08-15 13:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:24:55 --> Input Class Initialized
INFO - 2023-08-15 13:24:55 --> Language Class Initialized
INFO - 2023-08-15 13:24:55 --> Loader Class Initialized
INFO - 2023-08-15 13:24:55 --> Helper loaded: url_helper
INFO - 2023-08-15 13:24:55 --> Helper loaded: file_helper
INFO - 2023-08-15 13:24:55 --> Database Driver Class Initialized
INFO - 2023-08-15 13:24:55 --> Email Class Initialized
DEBUG - 2023-08-15 13:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:24:55 --> Controller Class Initialized
INFO - 2023-08-15 13:24:55 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:24:55 --> Helper loaded: form_helper
INFO - 2023-08-15 13:24:55 --> Form Validation Class Initialized
ERROR - 2023-08-15 13:24:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-08-15 13:24:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-08-15 13:24:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-08-15 13:24:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-08-15 13:24:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-08-15 13:24:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-08-15 13:24:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-08-15 13:24:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-08-15 13:24:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-08-15 13:24:55 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-15 13:24:55 --> Final output sent to browser
DEBUG - 2023-08-15 13:24:56 --> Total execution time: 0.4348
INFO - 2023-08-15 13:24:59 --> Config Class Initialized
INFO - 2023-08-15 13:24:59 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:24:59 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:24:59 --> Utf8 Class Initialized
INFO - 2023-08-15 13:24:59 --> URI Class Initialized
INFO - 2023-08-15 13:24:59 --> Router Class Initialized
INFO - 2023-08-15 13:24:59 --> Output Class Initialized
INFO - 2023-08-15 13:24:59 --> Security Class Initialized
DEBUG - 2023-08-15 13:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:24:59 --> Input Class Initialized
INFO - 2023-08-15 13:24:59 --> Language Class Initialized
INFO - 2023-08-15 13:24:59 --> Loader Class Initialized
INFO - 2023-08-15 13:24:59 --> Helper loaded: url_helper
INFO - 2023-08-15 13:24:59 --> Helper loaded: file_helper
INFO - 2023-08-15 13:24:59 --> Database Driver Class Initialized
INFO - 2023-08-15 13:24:59 --> Email Class Initialized
DEBUG - 2023-08-15 13:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:24:59 --> Controller Class Initialized
INFO - 2023-08-15 13:24:59 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:24:59 --> Helper loaded: form_helper
INFO - 2023-08-15 13:24:59 --> Form Validation Class Initialized
INFO - 2023-08-15 13:24:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-15 13:24:59 --> Final output sent to browser
DEBUG - 2023-08-15 13:24:59 --> Total execution time: 0.3029
INFO - 2023-08-15 13:25:01 --> Config Class Initialized
INFO - 2023-08-15 13:25:01 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:25:01 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:25:01 --> Utf8 Class Initialized
INFO - 2023-08-15 13:25:01 --> URI Class Initialized
INFO - 2023-08-15 13:25:01 --> Router Class Initialized
INFO - 2023-08-15 13:25:01 --> Output Class Initialized
INFO - 2023-08-15 13:25:01 --> Security Class Initialized
DEBUG - 2023-08-15 13:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:25:01 --> Input Class Initialized
INFO - 2023-08-15 13:25:01 --> Language Class Initialized
INFO - 2023-08-15 13:25:01 --> Loader Class Initialized
INFO - 2023-08-15 13:25:01 --> Helper loaded: url_helper
INFO - 2023-08-15 13:25:01 --> Helper loaded: file_helper
INFO - 2023-08-15 13:25:01 --> Database Driver Class Initialized
INFO - 2023-08-15 13:25:01 --> Email Class Initialized
DEBUG - 2023-08-15 13:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:25:01 --> Controller Class Initialized
INFO - 2023-08-15 13:25:01 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:25:01 --> Helper loaded: form_helper
INFO - 2023-08-15 13:25:01 --> Form Validation Class Initialized
INFO - 2023-08-15 13:25:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-15 13:25:02 --> Final output sent to browser
DEBUG - 2023-08-15 13:25:02 --> Total execution time: 0.2736
INFO - 2023-08-15 13:25:04 --> Config Class Initialized
INFO - 2023-08-15 13:25:04 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:25:04 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:25:04 --> Utf8 Class Initialized
INFO - 2023-08-15 13:25:04 --> URI Class Initialized
INFO - 2023-08-15 13:25:04 --> Router Class Initialized
INFO - 2023-08-15 13:25:04 --> Output Class Initialized
INFO - 2023-08-15 13:25:04 --> Security Class Initialized
DEBUG - 2023-08-15 13:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:25:04 --> Input Class Initialized
INFO - 2023-08-15 13:25:04 --> Language Class Initialized
INFO - 2023-08-15 13:25:04 --> Loader Class Initialized
INFO - 2023-08-15 13:25:04 --> Helper loaded: url_helper
INFO - 2023-08-15 13:25:04 --> Helper loaded: file_helper
INFO - 2023-08-15 13:25:04 --> Database Driver Class Initialized
INFO - 2023-08-15 13:25:04 --> Email Class Initialized
DEBUG - 2023-08-15 13:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:25:04 --> Controller Class Initialized
INFO - 2023-08-15 13:25:04 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:25:04 --> Helper loaded: form_helper
INFO - 2023-08-15 13:25:04 --> Form Validation Class Initialized
INFO - 2023-08-15 13:25:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-15 13:25:04 --> Final output sent to browser
DEBUG - 2023-08-15 13:25:04 --> Total execution time: 0.3256
INFO - 2023-08-15 13:25:05 --> Config Class Initialized
INFO - 2023-08-15 13:25:05 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:25:05 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:25:05 --> Utf8 Class Initialized
INFO - 2023-08-15 13:25:05 --> URI Class Initialized
INFO - 2023-08-15 13:25:05 --> Router Class Initialized
INFO - 2023-08-15 13:25:05 --> Output Class Initialized
INFO - 2023-08-15 13:25:05 --> Security Class Initialized
DEBUG - 2023-08-15 13:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:25:05 --> Input Class Initialized
INFO - 2023-08-15 13:25:05 --> Language Class Initialized
INFO - 2023-08-15 13:25:05 --> Loader Class Initialized
INFO - 2023-08-15 13:25:05 --> Helper loaded: url_helper
INFO - 2023-08-15 13:25:05 --> Helper loaded: file_helper
INFO - 2023-08-15 13:25:05 --> Database Driver Class Initialized
INFO - 2023-08-15 13:25:05 --> Email Class Initialized
DEBUG - 2023-08-15 13:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:25:05 --> Controller Class Initialized
INFO - 2023-08-15 13:25:05 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:25:05 --> Helper loaded: form_helper
INFO - 2023-08-15 13:25:05 --> Form Validation Class Initialized
ERROR - 2023-08-15 13:25:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-08-15 13:25:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-08-15 13:25:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-08-15 13:25:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-08-15 13:25:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-08-15 13:25:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-08-15 13:25:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-08-15 13:25:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-08-15 13:25:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-08-15 13:25:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-15 13:25:05 --> Final output sent to browser
DEBUG - 2023-08-15 13:25:05 --> Total execution time: 0.4653
INFO - 2023-08-15 13:25:14 --> Config Class Initialized
INFO - 2023-08-15 13:25:14 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:25:14 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:25:14 --> Utf8 Class Initialized
INFO - 2023-08-15 13:25:14 --> URI Class Initialized
INFO - 2023-08-15 13:25:14 --> Router Class Initialized
INFO - 2023-08-15 13:25:14 --> Output Class Initialized
INFO - 2023-08-15 13:25:15 --> Security Class Initialized
DEBUG - 2023-08-15 13:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:25:15 --> Input Class Initialized
INFO - 2023-08-15 13:25:15 --> Language Class Initialized
INFO - 2023-08-15 13:25:15 --> Loader Class Initialized
INFO - 2023-08-15 13:25:15 --> Helper loaded: url_helper
INFO - 2023-08-15 13:25:15 --> Helper loaded: file_helper
INFO - 2023-08-15 13:25:15 --> Database Driver Class Initialized
INFO - 2023-08-15 13:25:15 --> Email Class Initialized
DEBUG - 2023-08-15 13:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:25:15 --> Controller Class Initialized
INFO - 2023-08-15 13:25:15 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:25:15 --> Helper loaded: form_helper
INFO - 2023-08-15 13:25:15 --> Form Validation Class Initialized
INFO - 2023-08-15 13:25:15 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-15 13:25:15 --> Final output sent to browser
DEBUG - 2023-08-15 13:25:15 --> Total execution time: 0.3789
INFO - 2023-08-15 13:25:27 --> Config Class Initialized
INFO - 2023-08-15 13:25:27 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:25:27 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:25:27 --> Utf8 Class Initialized
INFO - 2023-08-15 13:25:27 --> URI Class Initialized
INFO - 2023-08-15 13:25:27 --> Router Class Initialized
INFO - 2023-08-15 13:25:27 --> Output Class Initialized
INFO - 2023-08-15 13:25:27 --> Security Class Initialized
DEBUG - 2023-08-15 13:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:25:27 --> Input Class Initialized
INFO - 2023-08-15 13:25:27 --> Language Class Initialized
INFO - 2023-08-15 13:25:27 --> Loader Class Initialized
INFO - 2023-08-15 13:25:27 --> Helper loaded: url_helper
INFO - 2023-08-15 13:25:27 --> Helper loaded: file_helper
INFO - 2023-08-15 13:25:27 --> Database Driver Class Initialized
INFO - 2023-08-15 13:25:27 --> Email Class Initialized
DEBUG - 2023-08-15 13:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:25:27 --> Controller Class Initialized
INFO - 2023-08-15 13:25:27 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:25:27 --> Helper loaded: form_helper
INFO - 2023-08-15 13:25:27 --> Form Validation Class Initialized
INFO - 2023-08-15 13:25:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-15 13:25:27 --> Final output sent to browser
DEBUG - 2023-08-15 13:25:27 --> Total execution time: 0.4568
INFO - 2023-08-15 13:25:28 --> Config Class Initialized
INFO - 2023-08-15 13:25:28 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:25:28 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:25:28 --> Utf8 Class Initialized
INFO - 2023-08-15 13:25:28 --> URI Class Initialized
INFO - 2023-08-15 13:25:28 --> Router Class Initialized
INFO - 2023-08-15 13:25:28 --> Output Class Initialized
INFO - 2023-08-15 13:25:28 --> Security Class Initialized
DEBUG - 2023-08-15 13:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:25:28 --> Input Class Initialized
INFO - 2023-08-15 13:25:28 --> Language Class Initialized
INFO - 2023-08-15 13:25:28 --> Loader Class Initialized
INFO - 2023-08-15 13:25:28 --> Helper loaded: url_helper
INFO - 2023-08-15 13:25:28 --> Helper loaded: file_helper
INFO - 2023-08-15 13:25:28 --> Database Driver Class Initialized
INFO - 2023-08-15 13:25:28 --> Email Class Initialized
DEBUG - 2023-08-15 13:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:25:28 --> Controller Class Initialized
INFO - 2023-08-15 13:25:28 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:25:28 --> Helper loaded: form_helper
INFO - 2023-08-15 13:25:28 --> Form Validation Class Initialized
ERROR - 2023-08-15 13:25:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-08-15 13:25:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-08-15 13:25:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-08-15 13:25:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-08-15 13:25:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-08-15 13:25:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-08-15 13:25:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-08-15 13:25:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-08-15 13:25:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-08-15 13:25:28 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-15 13:25:28 --> Final output sent to browser
DEBUG - 2023-08-15 13:25:28 --> Total execution time: 0.6628
INFO - 2023-08-15 13:25:42 --> Config Class Initialized
INFO - 2023-08-15 13:25:42 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:25:42 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:25:42 --> Utf8 Class Initialized
INFO - 2023-08-15 13:25:42 --> URI Class Initialized
INFO - 2023-08-15 13:25:42 --> Router Class Initialized
INFO - 2023-08-15 13:25:42 --> Output Class Initialized
INFO - 2023-08-15 13:25:42 --> Security Class Initialized
DEBUG - 2023-08-15 13:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:25:42 --> Input Class Initialized
INFO - 2023-08-15 13:25:42 --> Language Class Initialized
INFO - 2023-08-15 13:25:42 --> Loader Class Initialized
INFO - 2023-08-15 13:25:42 --> Helper loaded: url_helper
INFO - 2023-08-15 13:25:42 --> Helper loaded: file_helper
INFO - 2023-08-15 13:25:42 --> Database Driver Class Initialized
INFO - 2023-08-15 13:25:42 --> Email Class Initialized
DEBUG - 2023-08-15 13:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:25:42 --> Controller Class Initialized
INFO - 2023-08-15 13:25:42 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:25:42 --> Helper loaded: form_helper
INFO - 2023-08-15 13:25:42 --> Form Validation Class Initialized
INFO - 2023-08-15 13:25:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-15 13:25:42 --> Final output sent to browser
DEBUG - 2023-08-15 13:25:42 --> Total execution time: 0.3487
INFO - 2023-08-15 13:25:44 --> Config Class Initialized
INFO - 2023-08-15 13:25:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:25:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:25:44 --> Utf8 Class Initialized
INFO - 2023-08-15 13:25:44 --> URI Class Initialized
INFO - 2023-08-15 13:25:44 --> Router Class Initialized
INFO - 2023-08-15 13:25:44 --> Output Class Initialized
INFO - 2023-08-15 13:25:44 --> Security Class Initialized
DEBUG - 2023-08-15 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:25:44 --> Input Class Initialized
INFO - 2023-08-15 13:25:44 --> Language Class Initialized
INFO - 2023-08-15 13:25:44 --> Loader Class Initialized
INFO - 2023-08-15 13:25:44 --> Helper loaded: url_helper
INFO - 2023-08-15 13:25:44 --> Helper loaded: file_helper
INFO - 2023-08-15 13:25:44 --> Database Driver Class Initialized
INFO - 2023-08-15 13:25:44 --> Email Class Initialized
DEBUG - 2023-08-15 13:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:25:44 --> Controller Class Initialized
INFO - 2023-08-15 13:25:44 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:25:44 --> Helper loaded: form_helper
INFO - 2023-08-15 13:25:44 --> Form Validation Class Initialized
ERROR - 2023-08-15 13:25:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-08-15 13:25:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-08-15 13:25:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-08-15 13:25:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-08-15 13:25:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-08-15 13:25:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-08-15 13:25:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-08-15 13:25:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-08-15 13:25:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-08-15 13:25:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-15 13:25:44 --> Final output sent to browser
DEBUG - 2023-08-15 13:25:45 --> Total execution time: 0.6905
INFO - 2023-08-15 13:25:45 --> Config Class Initialized
INFO - 2023-08-15 13:25:45 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:25:45 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:25:45 --> Utf8 Class Initialized
INFO - 2023-08-15 13:25:45 --> URI Class Initialized
INFO - 2023-08-15 13:25:45 --> Router Class Initialized
INFO - 2023-08-15 13:25:45 --> Output Class Initialized
INFO - 2023-08-15 13:25:45 --> Security Class Initialized
DEBUG - 2023-08-15 13:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:25:45 --> Input Class Initialized
INFO - 2023-08-15 13:25:45 --> Language Class Initialized
INFO - 2023-08-15 13:25:45 --> Loader Class Initialized
INFO - 2023-08-15 13:25:45 --> Helper loaded: url_helper
INFO - 2023-08-15 13:25:45 --> Helper loaded: file_helper
INFO - 2023-08-15 13:25:45 --> Database Driver Class Initialized
INFO - 2023-08-15 13:25:45 --> Email Class Initialized
DEBUG - 2023-08-15 13:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:25:45 --> Controller Class Initialized
INFO - 2023-08-15 13:25:45 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:25:45 --> Helper loaded: form_helper
INFO - 2023-08-15 13:25:46 --> Form Validation Class Initialized
INFO - 2023-08-15 13:25:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-15 13:25:46 --> Final output sent to browser
DEBUG - 2023-08-15 13:25:46 --> Total execution time: 0.3515
INFO - 2023-08-15 13:25:52 --> Config Class Initialized
INFO - 2023-08-15 13:25:52 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:25:52 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:25:52 --> Utf8 Class Initialized
INFO - 2023-08-15 13:25:52 --> URI Class Initialized
INFO - 2023-08-15 13:25:52 --> Router Class Initialized
INFO - 2023-08-15 13:25:52 --> Output Class Initialized
INFO - 2023-08-15 13:25:52 --> Security Class Initialized
DEBUG - 2023-08-15 13:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:25:52 --> Input Class Initialized
INFO - 2023-08-15 13:25:52 --> Language Class Initialized
INFO - 2023-08-15 13:25:52 --> Loader Class Initialized
INFO - 2023-08-15 13:25:52 --> Helper loaded: url_helper
INFO - 2023-08-15 13:25:52 --> Helper loaded: file_helper
INFO - 2023-08-15 13:25:52 --> Database Driver Class Initialized
INFO - 2023-08-15 13:25:52 --> Email Class Initialized
DEBUG - 2023-08-15 13:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:25:52 --> Controller Class Initialized
INFO - 2023-08-15 13:25:52 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:25:52 --> Helper loaded: form_helper
INFO - 2023-08-15 13:25:52 --> Form Validation Class Initialized
INFO - 2023-08-15 13:25:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-15 13:25:53 --> Final output sent to browser
DEBUG - 2023-08-15 13:25:53 --> Total execution time: 0.3619
INFO - 2023-08-15 13:25:55 --> Config Class Initialized
INFO - 2023-08-15 13:25:55 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:25:55 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:25:55 --> Utf8 Class Initialized
INFO - 2023-08-15 13:25:55 --> URI Class Initialized
INFO - 2023-08-15 13:25:55 --> Router Class Initialized
INFO - 2023-08-15 13:25:55 --> Output Class Initialized
INFO - 2023-08-15 13:25:55 --> Security Class Initialized
DEBUG - 2023-08-15 13:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:25:55 --> Input Class Initialized
INFO - 2023-08-15 13:25:55 --> Language Class Initialized
INFO - 2023-08-15 13:25:55 --> Loader Class Initialized
INFO - 2023-08-15 13:25:55 --> Helper loaded: url_helper
INFO - 2023-08-15 13:25:55 --> Helper loaded: file_helper
INFO - 2023-08-15 13:25:55 --> Database Driver Class Initialized
INFO - 2023-08-15 13:25:55 --> Email Class Initialized
DEBUG - 2023-08-15 13:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:25:55 --> Controller Class Initialized
INFO - 2023-08-15 13:25:55 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:25:55 --> Helper loaded: form_helper
INFO - 2023-08-15 13:25:55 --> Form Validation Class Initialized
INFO - 2023-08-15 13:25:55 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-15 13:25:55 --> Final output sent to browser
DEBUG - 2023-08-15 13:25:55 --> Total execution time: 0.2158
INFO - 2023-08-15 13:25:56 --> Config Class Initialized
INFO - 2023-08-15 13:25:56 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:25:56 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:25:56 --> Utf8 Class Initialized
INFO - 2023-08-15 13:25:56 --> URI Class Initialized
INFO - 2023-08-15 13:25:56 --> Router Class Initialized
INFO - 2023-08-15 13:25:56 --> Output Class Initialized
INFO - 2023-08-15 13:25:56 --> Security Class Initialized
DEBUG - 2023-08-15 13:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:25:56 --> Input Class Initialized
INFO - 2023-08-15 13:25:56 --> Language Class Initialized
INFO - 2023-08-15 13:25:56 --> Loader Class Initialized
INFO - 2023-08-15 13:25:56 --> Helper loaded: url_helper
INFO - 2023-08-15 13:25:56 --> Helper loaded: file_helper
INFO - 2023-08-15 13:25:56 --> Database Driver Class Initialized
INFO - 2023-08-15 13:25:56 --> Email Class Initialized
DEBUG - 2023-08-15 13:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:25:56 --> Controller Class Initialized
INFO - 2023-08-15 13:25:56 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:25:56 --> Helper loaded: form_helper
INFO - 2023-08-15 13:25:56 --> Form Validation Class Initialized
ERROR - 2023-08-15 13:25:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-08-15 13:25:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-08-15 13:25:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-08-15 13:25:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-08-15 13:25:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-08-15 13:25:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-08-15 13:25:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-08-15 13:25:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-08-15 13:25:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-08-15 13:25:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-15 13:25:56 --> Final output sent to browser
DEBUG - 2023-08-15 13:25:56 --> Total execution time: 0.3912
INFO - 2023-08-15 13:26:17 --> Config Class Initialized
INFO - 2023-08-15 13:26:17 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:26:17 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:26:17 --> Utf8 Class Initialized
INFO - 2023-08-15 13:26:17 --> URI Class Initialized
INFO - 2023-08-15 13:26:17 --> Router Class Initialized
INFO - 2023-08-15 13:26:17 --> Output Class Initialized
INFO - 2023-08-15 13:26:17 --> Security Class Initialized
DEBUG - 2023-08-15 13:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:26:17 --> Input Class Initialized
INFO - 2023-08-15 13:26:17 --> Language Class Initialized
INFO - 2023-08-15 13:26:17 --> Loader Class Initialized
INFO - 2023-08-15 13:26:17 --> Helper loaded: url_helper
INFO - 2023-08-15 13:26:17 --> Helper loaded: file_helper
INFO - 2023-08-15 13:26:17 --> Database Driver Class Initialized
INFO - 2023-08-15 13:26:17 --> Email Class Initialized
DEBUG - 2023-08-15 13:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:26:17 --> Controller Class Initialized
INFO - 2023-08-15 13:26:17 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:26:17 --> Helper loaded: form_helper
INFO - 2023-08-15 13:26:17 --> Form Validation Class Initialized
INFO - 2023-08-15 13:26:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-15 13:26:17 --> Config Class Initialized
INFO - 2023-08-15 13:26:17 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:26:17 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:26:18 --> Utf8 Class Initialized
INFO - 2023-08-15 13:26:18 --> URI Class Initialized
INFO - 2023-08-15 13:26:18 --> Router Class Initialized
INFO - 2023-08-15 13:26:18 --> Output Class Initialized
INFO - 2023-08-15 13:26:18 --> Security Class Initialized
DEBUG - 2023-08-15 13:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:26:18 --> Input Class Initialized
INFO - 2023-08-15 13:26:18 --> Language Class Initialized
INFO - 2023-08-15 13:26:18 --> Loader Class Initialized
INFO - 2023-08-15 13:26:18 --> Helper loaded: url_helper
INFO - 2023-08-15 13:26:18 --> Helper loaded: file_helper
INFO - 2023-08-15 13:26:18 --> Database Driver Class Initialized
INFO - 2023-08-15 13:26:18 --> Email Class Initialized
DEBUG - 2023-08-15 13:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:26:18 --> Controller Class Initialized
INFO - 2023-08-15 13:26:18 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:26:18 --> Helper loaded: form_helper
INFO - 2023-08-15 13:26:18 --> Form Validation Class Initialized
INFO - 2023-08-15 13:26:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-15 13:26:18 --> Final output sent to browser
DEBUG - 2023-08-15 13:26:18 --> Total execution time: 0.3290
INFO - 2023-08-15 13:26:20 --> Config Class Initialized
INFO - 2023-08-15 13:26:20 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:26:20 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:26:20 --> Utf8 Class Initialized
INFO - 2023-08-15 13:26:20 --> URI Class Initialized
INFO - 2023-08-15 13:26:20 --> Router Class Initialized
INFO - 2023-08-15 13:26:20 --> Output Class Initialized
INFO - 2023-08-15 13:26:20 --> Security Class Initialized
DEBUG - 2023-08-15 13:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:26:20 --> Input Class Initialized
INFO - 2023-08-15 13:26:20 --> Language Class Initialized
INFO - 2023-08-15 13:26:20 --> Loader Class Initialized
INFO - 2023-08-15 13:26:20 --> Helper loaded: url_helper
INFO - 2023-08-15 13:26:20 --> Helper loaded: file_helper
INFO - 2023-08-15 13:26:20 --> Database Driver Class Initialized
INFO - 2023-08-15 13:26:20 --> Email Class Initialized
DEBUG - 2023-08-15 13:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:26:20 --> Controller Class Initialized
INFO - 2023-08-15 13:26:20 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:26:20 --> Helper loaded: form_helper
INFO - 2023-08-15 13:26:20 --> Form Validation Class Initialized
INFO - 2023-08-15 13:26:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-15 13:26:21 --> Final output sent to browser
DEBUG - 2023-08-15 13:26:21 --> Total execution time: 0.2476
INFO - 2023-08-15 13:26:21 --> Config Class Initialized
INFO - 2023-08-15 13:26:21 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:26:21 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:26:21 --> Utf8 Class Initialized
INFO - 2023-08-15 13:26:21 --> URI Class Initialized
INFO - 2023-08-15 13:26:21 --> Router Class Initialized
INFO - 2023-08-15 13:26:21 --> Output Class Initialized
INFO - 2023-08-15 13:26:21 --> Security Class Initialized
DEBUG - 2023-08-15 13:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:26:21 --> Input Class Initialized
INFO - 2023-08-15 13:26:21 --> Language Class Initialized
INFO - 2023-08-15 13:26:21 --> Loader Class Initialized
INFO - 2023-08-15 13:26:21 --> Helper loaded: url_helper
INFO - 2023-08-15 13:26:21 --> Helper loaded: file_helper
INFO - 2023-08-15 13:26:21 --> Database Driver Class Initialized
INFO - 2023-08-15 13:26:21 --> Email Class Initialized
DEBUG - 2023-08-15 13:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:26:21 --> Controller Class Initialized
INFO - 2023-08-15 13:26:21 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:26:21 --> Helper loaded: form_helper
INFO - 2023-08-15 13:26:21 --> Form Validation Class Initialized
ERROR - 2023-08-15 13:26:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-08-15 13:26:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-08-15 13:26:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-08-15 13:26:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-08-15 13:26:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-08-15 13:26:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-08-15 13:26:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-08-15 13:26:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-08-15 13:26:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-08-15 13:26:21 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-15 13:26:21 --> Final output sent to browser
DEBUG - 2023-08-15 13:26:21 --> Total execution time: 0.5126
INFO - 2023-08-15 13:26:43 --> Config Class Initialized
INFO - 2023-08-15 13:26:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:26:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:26:44 --> Utf8 Class Initialized
INFO - 2023-08-15 13:26:44 --> URI Class Initialized
INFO - 2023-08-15 13:26:44 --> Router Class Initialized
INFO - 2023-08-15 13:26:44 --> Output Class Initialized
INFO - 2023-08-15 13:26:44 --> Security Class Initialized
DEBUG - 2023-08-15 13:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:26:44 --> Input Class Initialized
INFO - 2023-08-15 13:26:44 --> Language Class Initialized
INFO - 2023-08-15 13:26:44 --> Loader Class Initialized
INFO - 2023-08-15 13:26:44 --> Helper loaded: url_helper
INFO - 2023-08-15 13:26:44 --> Helper loaded: file_helper
INFO - 2023-08-15 13:26:44 --> Database Driver Class Initialized
INFO - 2023-08-15 13:26:44 --> Email Class Initialized
DEBUG - 2023-08-15 13:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:26:44 --> Controller Class Initialized
INFO - 2023-08-15 13:26:44 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:26:44 --> Helper loaded: form_helper
INFO - 2023-08-15 13:26:44 --> Form Validation Class Initialized
INFO - 2023-08-15 13:26:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-15 13:26:44 --> Config Class Initialized
INFO - 2023-08-15 13:26:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:26:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:26:44 --> Utf8 Class Initialized
INFO - 2023-08-15 13:26:44 --> URI Class Initialized
INFO - 2023-08-15 13:26:44 --> Router Class Initialized
INFO - 2023-08-15 13:26:44 --> Output Class Initialized
INFO - 2023-08-15 13:26:44 --> Security Class Initialized
DEBUG - 2023-08-15 13:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:26:44 --> Input Class Initialized
INFO - 2023-08-15 13:26:44 --> Language Class Initialized
INFO - 2023-08-15 13:26:44 --> Loader Class Initialized
INFO - 2023-08-15 13:26:44 --> Helper loaded: url_helper
INFO - 2023-08-15 13:26:44 --> Helper loaded: file_helper
INFO - 2023-08-15 13:26:44 --> Database Driver Class Initialized
INFO - 2023-08-15 13:26:44 --> Email Class Initialized
DEBUG - 2023-08-15 13:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:26:44 --> Controller Class Initialized
INFO - 2023-08-15 13:26:44 --> Model "Banner_model" initialized
INFO - 2023-08-15 13:26:44 --> Helper loaded: form_helper
INFO - 2023-08-15 13:26:44 --> Form Validation Class Initialized
INFO - 2023-08-15 13:26:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-15 13:26:45 --> Final output sent to browser
DEBUG - 2023-08-15 13:26:45 --> Total execution time: 0.4457
INFO - 2023-08-15 13:27:00 --> Config Class Initialized
INFO - 2023-08-15 13:27:00 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:27:00 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:27:00 --> Utf8 Class Initialized
INFO - 2023-08-15 13:27:00 --> URI Class Initialized
INFO - 2023-08-15 13:27:00 --> Router Class Initialized
INFO - 2023-08-15 13:27:00 --> Output Class Initialized
INFO - 2023-08-15 13:27:00 --> Security Class Initialized
DEBUG - 2023-08-15 13:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:27:00 --> Input Class Initialized
INFO - 2023-08-15 13:27:00 --> Language Class Initialized
INFO - 2023-08-15 13:27:00 --> Loader Class Initialized
INFO - 2023-08-15 13:27:00 --> Helper loaded: url_helper
INFO - 2023-08-15 13:27:00 --> Helper loaded: file_helper
INFO - 2023-08-15 13:27:00 --> Database Driver Class Initialized
INFO - 2023-08-15 13:27:00 --> Email Class Initialized
DEBUG - 2023-08-15 13:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:27:00 --> Controller Class Initialized
INFO - 2023-08-15 13:27:00 --> Model "Home_model" initialized
INFO - 2023-08-15 13:27:00 --> Helper loaded: form_helper
INFO - 2023-08-15 13:27:00 --> Form Validation Class Initialized
INFO - 2023-08-15 13:27:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:27:00 --> Final output sent to browser
DEBUG - 2023-08-15 13:27:00 --> Total execution time: 0.2492
INFO - 2023-08-15 13:27:00 --> Config Class Initialized
INFO - 2023-08-15 13:27:00 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:27:00 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:27:00 --> Utf8 Class Initialized
INFO - 2023-08-15 13:27:00 --> URI Class Initialized
INFO - 2023-08-15 13:27:00 --> Router Class Initialized
INFO - 2023-08-15 13:27:00 --> Output Class Initialized
INFO - 2023-08-15 13:27:00 --> Security Class Initialized
DEBUG - 2023-08-15 13:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:27:00 --> Input Class Initialized
INFO - 2023-08-15 13:27:00 --> Language Class Initialized
ERROR - 2023-08-15 13:27:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:27:01 --> Config Class Initialized
INFO - 2023-08-15 13:27:01 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:27:01 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:27:01 --> Utf8 Class Initialized
INFO - 2023-08-15 13:27:01 --> URI Class Initialized
INFO - 2023-08-15 13:27:01 --> Router Class Initialized
INFO - 2023-08-15 13:27:01 --> Output Class Initialized
INFO - 2023-08-15 13:27:01 --> Security Class Initialized
DEBUG - 2023-08-15 13:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:27:01 --> Input Class Initialized
INFO - 2023-08-15 13:27:01 --> Language Class Initialized
ERROR - 2023-08-15 13:27:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:27:01 --> Config Class Initialized
INFO - 2023-08-15 13:27:01 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:27:01 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:27:01 --> Utf8 Class Initialized
INFO - 2023-08-15 13:27:01 --> URI Class Initialized
INFO - 2023-08-15 13:27:01 --> Router Class Initialized
INFO - 2023-08-15 13:27:01 --> Output Class Initialized
INFO - 2023-08-15 13:27:01 --> Security Class Initialized
DEBUG - 2023-08-15 13:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:27:01 --> Input Class Initialized
INFO - 2023-08-15 13:27:01 --> Language Class Initialized
ERROR - 2023-08-15 13:27:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:27:01 --> Config Class Initialized
INFO - 2023-08-15 13:27:01 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:27:01 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:27:01 --> Utf8 Class Initialized
INFO - 2023-08-15 13:27:01 --> URI Class Initialized
INFO - 2023-08-15 13:27:01 --> Router Class Initialized
INFO - 2023-08-15 13:27:01 --> Output Class Initialized
INFO - 2023-08-15 13:27:01 --> Security Class Initialized
DEBUG - 2023-08-15 13:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:27:01 --> Input Class Initialized
INFO - 2023-08-15 13:27:01 --> Language Class Initialized
ERROR - 2023-08-15 13:27:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:29:27 --> Config Class Initialized
INFO - 2023-08-15 13:29:27 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:29:27 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:29:27 --> Utf8 Class Initialized
INFO - 2023-08-15 13:29:27 --> URI Class Initialized
INFO - 2023-08-15 13:29:27 --> Router Class Initialized
INFO - 2023-08-15 13:29:27 --> Output Class Initialized
INFO - 2023-08-15 13:29:27 --> Security Class Initialized
DEBUG - 2023-08-15 13:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:29:27 --> Input Class Initialized
INFO - 2023-08-15 13:29:27 --> Language Class Initialized
ERROR - 2023-08-15 13:29:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:29:27 --> Config Class Initialized
INFO - 2023-08-15 13:29:28 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:29:28 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:29:28 --> Config Class Initialized
INFO - 2023-08-15 13:29:29 --> Config Class Initialized
INFO - 2023-08-15 13:29:29 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:29:29 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:29:29 --> Utf8 Class Initialized
INFO - 2023-08-15 13:29:29 --> URI Class Initialized
INFO - 2023-08-15 13:29:29 --> Router Class Initialized
INFO - 2023-08-15 13:29:29 --> Output Class Initialized
INFO - 2023-08-15 13:29:29 --> Security Class Initialized
DEBUG - 2023-08-15 13:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:29:29 --> Input Class Initialized
INFO - 2023-08-15 13:29:29 --> Language Class Initialized
ERROR - 2023-08-15 13:29:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:29:29 --> Config Class Initialized
INFO - 2023-08-15 13:29:29 --> Hooks Class Initialized
INFO - 2023-08-15 13:29:29 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:29:29 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:29:29 --> Config Class Initialized
INFO - 2023-08-15 13:29:29 --> Config Class Initialized
DEBUG - 2023-08-15 13:29:29 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:29:29 --> Hooks Class Initialized
INFO - 2023-08-15 13:29:30 --> Utf8 Class Initialized
INFO - 2023-08-15 13:29:30 --> Hooks Class Initialized
INFO - 2023-08-15 13:29:30 --> URI Class Initialized
INFO - 2023-08-15 13:29:30 --> Utf8 Class Initialized
DEBUG - 2023-08-15 13:29:30 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:29:30 --> URI Class Initialized
DEBUG - 2023-08-15 13:29:30 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:29:30 --> Router Class Initialized
INFO - 2023-08-15 13:29:30 --> Utf8 Class Initialized
INFO - 2023-08-15 13:29:31 --> Utf8 Class Initialized
INFO - 2023-08-15 13:29:31 --> Output Class Initialized
INFO - 2023-08-15 13:29:31 --> Router Class Initialized
INFO - 2023-08-15 13:29:31 --> URI Class Initialized
INFO - 2023-08-15 13:29:31 --> Router Class Initialized
INFO - 2023-08-15 13:29:31 --> Output Class Initialized
INFO - 2023-08-15 13:29:31 --> Security Class Initialized
DEBUG - 2023-08-15 13:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:29:31 --> Input Class Initialized
INFO - 2023-08-15 13:29:31 --> Language Class Initialized
ERROR - 2023-08-15 13:29:31 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:29:31 --> Utf8 Class Initialized
INFO - 2023-08-15 13:29:31 --> Output Class Initialized
INFO - 2023-08-15 13:29:31 --> Security Class Initialized
INFO - 2023-08-15 13:29:31 --> URI Class Initialized
INFO - 2023-08-15 13:29:31 --> URI Class Initialized
DEBUG - 2023-08-15 13:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:29:32 --> Security Class Initialized
INFO - 2023-08-15 13:29:32 --> Router Class Initialized
INFO - 2023-08-15 13:29:32 --> Router Class Initialized
INFO - 2023-08-15 13:29:32 --> Output Class Initialized
DEBUG - 2023-08-15 13:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:29:32 --> Input Class Initialized
INFO - 2023-08-15 13:29:32 --> Output Class Initialized
INFO - 2023-08-15 13:29:32 --> Security Class Initialized
DEBUG - 2023-08-15 13:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:29:32 --> Input Class Initialized
INFO - 2023-08-15 13:29:32 --> Language Class Initialized
INFO - 2023-08-15 13:29:32 --> Input Class Initialized
INFO - 2023-08-15 13:29:32 --> Security Class Initialized
INFO - 2023-08-15 13:29:32 --> Language Class Initialized
INFO - 2023-08-15 13:29:33 --> Language Class Initialized
ERROR - 2023-08-15 13:29:33 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-15 13:29:33 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-15 13:29:33 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-15 13:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:29:33 --> Input Class Initialized
INFO - 2023-08-15 13:29:33 --> Language Class Initialized
ERROR - 2023-08-15 13:29:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:31:14 --> Config Class Initialized
INFO - 2023-08-15 13:31:14 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:31:14 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:31:14 --> Utf8 Class Initialized
INFO - 2023-08-15 13:31:14 --> URI Class Initialized
INFO - 2023-08-15 13:31:14 --> Router Class Initialized
INFO - 2023-08-15 13:31:14 --> Output Class Initialized
INFO - 2023-08-15 13:31:14 --> Security Class Initialized
DEBUG - 2023-08-15 13:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:31:14 --> Input Class Initialized
INFO - 2023-08-15 13:31:14 --> Language Class Initialized
INFO - 2023-08-15 13:31:14 --> Loader Class Initialized
INFO - 2023-08-15 13:31:14 --> Helper loaded: url_helper
INFO - 2023-08-15 13:31:14 --> Helper loaded: file_helper
INFO - 2023-08-15 13:31:14 --> Database Driver Class Initialized
INFO - 2023-08-15 13:31:14 --> Email Class Initialized
DEBUG - 2023-08-15 13:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:31:14 --> Controller Class Initialized
INFO - 2023-08-15 13:31:14 --> Model "Home_model" initialized
INFO - 2023-08-15 13:31:14 --> Helper loaded: form_helper
INFO - 2023-08-15 13:31:14 --> Form Validation Class Initialized
INFO - 2023-08-15 13:31:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:31:14 --> Final output sent to browser
DEBUG - 2023-08-15 13:31:14 --> Total execution time: 0.5433
INFO - 2023-08-15 13:31:17 --> Config Class Initialized
INFO - 2023-08-15 13:31:17 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:31:17 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:31:17 --> Utf8 Class Initialized
INFO - 2023-08-15 13:31:17 --> URI Class Initialized
INFO - 2023-08-15 13:31:17 --> Router Class Initialized
INFO - 2023-08-15 13:31:17 --> Output Class Initialized
INFO - 2023-08-15 13:31:17 --> Security Class Initialized
DEBUG - 2023-08-15 13:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:31:17 --> Input Class Initialized
INFO - 2023-08-15 13:31:17 --> Language Class Initialized
ERROR - 2023-08-15 13:31:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:31:17 --> Config Class Initialized
INFO - 2023-08-15 13:31:17 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:31:17 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:31:17 --> Utf8 Class Initialized
INFO - 2023-08-15 13:31:17 --> URI Class Initialized
INFO - 2023-08-15 13:31:17 --> Router Class Initialized
INFO - 2023-08-15 13:31:17 --> Output Class Initialized
INFO - 2023-08-15 13:31:17 --> Security Class Initialized
DEBUG - 2023-08-15 13:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:31:17 --> Input Class Initialized
INFO - 2023-08-15 13:31:17 --> Language Class Initialized
ERROR - 2023-08-15 13:31:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:31:17 --> Config Class Initialized
INFO - 2023-08-15 13:31:17 --> Config Class Initialized
INFO - 2023-08-15 13:31:17 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:31:17 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:31:17 --> Utf8 Class Initialized
INFO - 2023-08-15 13:31:17 --> URI Class Initialized
INFO - 2023-08-15 13:31:17 --> Router Class Initialized
INFO - 2023-08-15 13:31:17 --> Output Class Initialized
INFO - 2023-08-15 13:31:17 --> Security Class Initialized
DEBUG - 2023-08-15 13:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:31:17 --> Input Class Initialized
INFO - 2023-08-15 13:31:17 --> Language Class Initialized
ERROR - 2023-08-15 13:31:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:31:18 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:31:18 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:31:18 --> Utf8 Class Initialized
INFO - 2023-08-15 13:31:18 --> URI Class Initialized
INFO - 2023-08-15 13:31:18 --> Router Class Initialized
INFO - 2023-08-15 13:31:18 --> Output Class Initialized
INFO - 2023-08-15 13:31:18 --> Security Class Initialized
DEBUG - 2023-08-15 13:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:31:18 --> Input Class Initialized
INFO - 2023-08-15 13:31:18 --> Language Class Initialized
ERROR - 2023-08-15 13:31:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:31:18 --> Config Class Initialized
INFO - 2023-08-15 13:31:18 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:31:18 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:31:18 --> Utf8 Class Initialized
INFO - 2023-08-15 13:31:18 --> URI Class Initialized
INFO - 2023-08-15 13:31:18 --> Router Class Initialized
INFO - 2023-08-15 13:31:18 --> Output Class Initialized
INFO - 2023-08-15 13:31:18 --> Security Class Initialized
DEBUG - 2023-08-15 13:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:31:18 --> Input Class Initialized
INFO - 2023-08-15 13:31:18 --> Language Class Initialized
ERROR - 2023-08-15 13:31:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:31:18 --> Config Class Initialized
INFO - 2023-08-15 13:31:18 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:31:18 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:31:18 --> Config Class Initialized
INFO - 2023-08-15 13:31:18 --> Config Class Initialized
INFO - 2023-08-15 13:31:18 --> Utf8 Class Initialized
INFO - 2023-08-15 13:31:19 --> Hooks Class Initialized
INFO - 2023-08-15 13:31:19 --> URI Class Initialized
DEBUG - 2023-08-15 13:31:19 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:31:19 --> Router Class Initialized
INFO - 2023-08-15 13:31:19 --> Config Class Initialized
INFO - 2023-08-15 13:31:19 --> Hooks Class Initialized
INFO - 2023-08-15 13:31:20 --> Config Class Initialized
INFO - 2023-08-15 13:31:20 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:31:20 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:31:20 --> Output Class Initialized
INFO - 2023-08-15 13:31:20 --> Utf8 Class Initialized
INFO - 2023-08-15 13:31:20 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:31:20 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:31:20 --> URI Class Initialized
INFO - 2023-08-15 13:31:20 --> Utf8 Class Initialized
INFO - 2023-08-15 13:31:20 --> URI Class Initialized
INFO - 2023-08-15 13:31:20 --> Utf8 Class Initialized
INFO - 2023-08-15 13:31:20 --> Security Class Initialized
INFO - 2023-08-15 13:31:20 --> URI Class Initialized
DEBUG - 2023-08-15 13:31:20 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:31:20 --> Router Class Initialized
INFO - 2023-08-15 13:31:20 --> Utf8 Class Initialized
INFO - 2023-08-15 13:31:20 --> Router Class Initialized
DEBUG - 2023-08-15 13:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:31:20 --> Router Class Initialized
INFO - 2023-08-15 13:31:20 --> Output Class Initialized
INFO - 2023-08-15 13:31:20 --> Output Class Initialized
INFO - 2023-08-15 13:31:20 --> URI Class Initialized
INFO - 2023-08-15 13:31:20 --> Output Class Initialized
INFO - 2023-08-15 13:31:20 --> Input Class Initialized
INFO - 2023-08-15 13:31:20 --> Security Class Initialized
INFO - 2023-08-15 13:31:20 --> Router Class Initialized
INFO - 2023-08-15 13:31:20 --> Security Class Initialized
INFO - 2023-08-15 13:31:20 --> Language Class Initialized
INFO - 2023-08-15 13:31:20 --> Security Class Initialized
ERROR - 2023-08-15 13:31:20 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-15 13:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:31:20 --> Input Class Initialized
INFO - 2023-08-15 13:31:20 --> Language Class Initialized
INFO - 2023-08-15 13:31:20 --> Output Class Initialized
DEBUG - 2023-08-15 13:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:31:20 --> Security Class Initialized
INFO - 2023-08-15 13:31:20 --> Config Class Initialized
ERROR - 2023-08-15 13:31:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:31:20 --> Input Class Initialized
DEBUG - 2023-08-15 13:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-15 13:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:31:20 --> Hooks Class Initialized
INFO - 2023-08-15 13:31:20 --> Language Class Initialized
DEBUG - 2023-08-15 13:31:20 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:31:20 --> Utf8 Class Initialized
INFO - 2023-08-15 13:31:20 --> Input Class Initialized
INFO - 2023-08-15 13:31:20 --> URI Class Initialized
ERROR - 2023-08-15 13:31:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:31:20 --> Router Class Initialized
INFO - 2023-08-15 13:31:20 --> Input Class Initialized
INFO - 2023-08-15 13:31:20 --> Output Class Initialized
INFO - 2023-08-15 13:31:20 --> Language Class Initialized
INFO - 2023-08-15 13:31:20 --> Language Class Initialized
ERROR - 2023-08-15 13:31:20 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-15 13:31:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:31:20 --> Security Class Initialized
DEBUG - 2023-08-15 13:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:31:20 --> Input Class Initialized
INFO - 2023-08-15 13:31:20 --> Language Class Initialized
ERROR - 2023-08-15 13:31:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:33:02 --> Config Class Initialized
INFO - 2023-08-15 13:33:02 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:33:02 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:02 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:02 --> URI Class Initialized
INFO - 2023-08-15 13:33:02 --> Router Class Initialized
INFO - 2023-08-15 13:33:02 --> Output Class Initialized
INFO - 2023-08-15 13:33:02 --> Security Class Initialized
DEBUG - 2023-08-15 13:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:02 --> Input Class Initialized
INFO - 2023-08-15 13:33:02 --> Language Class Initialized
INFO - 2023-08-15 13:33:02 --> Loader Class Initialized
INFO - 2023-08-15 13:33:02 --> Helper loaded: url_helper
INFO - 2023-08-15 13:33:02 --> Helper loaded: file_helper
INFO - 2023-08-15 13:33:02 --> Database Driver Class Initialized
INFO - 2023-08-15 13:33:02 --> Email Class Initialized
DEBUG - 2023-08-15 13:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:33:03 --> Controller Class Initialized
INFO - 2023-08-15 13:33:03 --> Model "Home_model" initialized
INFO - 2023-08-15 13:33:03 --> Helper loaded: form_helper
INFO - 2023-08-15 13:33:03 --> Form Validation Class Initialized
INFO - 2023-08-15 13:33:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:33:03 --> Final output sent to browser
DEBUG - 2023-08-15 13:33:03 --> Total execution time: 0.7667
INFO - 2023-08-15 13:33:03 --> Config Class Initialized
INFO - 2023-08-15 13:33:03 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:33:03 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:03 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:03 --> URI Class Initialized
INFO - 2023-08-15 13:33:03 --> Router Class Initialized
INFO - 2023-08-15 13:33:03 --> Output Class Initialized
INFO - 2023-08-15 13:33:03 --> Security Class Initialized
DEBUG - 2023-08-15 13:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:03 --> Input Class Initialized
INFO - 2023-08-15 13:33:03 --> Language Class Initialized
ERROR - 2023-08-15 13:33:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:33:03 --> Config Class Initialized
INFO - 2023-08-15 13:33:03 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:33:03 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:03 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:03 --> URI Class Initialized
INFO - 2023-08-15 13:33:03 --> Router Class Initialized
INFO - 2023-08-15 13:33:03 --> Output Class Initialized
INFO - 2023-08-15 13:33:03 --> Security Class Initialized
DEBUG - 2023-08-15 13:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:03 --> Input Class Initialized
INFO - 2023-08-15 13:33:03 --> Language Class Initialized
ERROR - 2023-08-15 13:33:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:33:04 --> Config Class Initialized
INFO - 2023-08-15 13:33:05 --> Hooks Class Initialized
INFO - 2023-08-15 13:33:05 --> Config Class Initialized
INFO - 2023-08-15 13:33:05 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:33:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-15 13:33:05 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:05 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:05 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:05 --> Config Class Initialized
INFO - 2023-08-15 13:33:05 --> URI Class Initialized
INFO - 2023-08-15 13:33:05 --> Config Class Initialized
INFO - 2023-08-15 13:33:05 --> URI Class Initialized
INFO - 2023-08-15 13:33:06 --> Router Class Initialized
INFO - 2023-08-15 13:33:06 --> Output Class Initialized
INFO - 2023-08-15 13:33:06 --> Router Class Initialized
INFO - 2023-08-15 13:33:06 --> Hooks Class Initialized
INFO - 2023-08-15 13:33:06 --> Output Class Initialized
INFO - 2023-08-15 13:33:06 --> Security Class Initialized
INFO - 2023-08-15 13:33:06 --> Security Class Initialized
INFO - 2023-08-15 13:33:06 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-15 13:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-15 13:33:06 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:06 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:06 --> Input Class Initialized
DEBUG - 2023-08-15 13:33:06 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:06 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:06 --> Language Class Initialized
INFO - 2023-08-15 13:33:06 --> URI Class Initialized
INFO - 2023-08-15 13:33:06 --> Input Class Initialized
INFO - 2023-08-15 13:33:06 --> Router Class Initialized
INFO - 2023-08-15 13:33:06 --> Language Class Initialized
INFO - 2023-08-15 13:33:06 --> URI Class Initialized
ERROR - 2023-08-15 13:33:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:33:06 --> Router Class Initialized
INFO - 2023-08-15 13:33:06 --> Output Class Initialized
INFO - 2023-08-15 13:33:06 --> Output Class Initialized
INFO - 2023-08-15 13:33:06 --> Security Class Initialized
ERROR - 2023-08-15 13:33:06 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-15 13:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:06 --> Input Class Initialized
INFO - 2023-08-15 13:33:06 --> Security Class Initialized
DEBUG - 2023-08-15 13:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:06 --> Config Class Initialized
INFO - 2023-08-15 13:33:06 --> Input Class Initialized
INFO - 2023-08-15 13:33:06 --> Language Class Initialized
INFO - 2023-08-15 13:33:06 --> Hooks Class Initialized
ERROR - 2023-08-15 13:33:06 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:33:06 --> Config Class Initialized
INFO - 2023-08-15 13:33:07 --> Config Class Initialized
DEBUG - 2023-08-15 13:33:07 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:07 --> Hooks Class Initialized
INFO - 2023-08-15 13:33:07 --> Hooks Class Initialized
INFO - 2023-08-15 13:33:07 --> Language Class Initialized
INFO - 2023-08-15 13:33:07 --> Utf8 Class Initialized
ERROR - 2023-08-15 13:33:07 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-15 13:33:07 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:07 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:07 --> URI Class Initialized
DEBUG - 2023-08-15 13:33:07 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:07 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:07 --> URI Class Initialized
INFO - 2023-08-15 13:33:07 --> URI Class Initialized
INFO - 2023-08-15 13:33:07 --> Router Class Initialized
INFO - 2023-08-15 13:33:07 --> Config Class Initialized
INFO - 2023-08-15 13:33:07 --> Router Class Initialized
INFO - 2023-08-15 13:33:07 --> Hooks Class Initialized
INFO - 2023-08-15 13:33:07 --> Router Class Initialized
INFO - 2023-08-15 13:33:07 --> Output Class Initialized
INFO - 2023-08-15 13:33:07 --> Output Class Initialized
INFO - 2023-08-15 13:33:07 --> Output Class Initialized
DEBUG - 2023-08-15 13:33:07 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:07 --> Security Class Initialized
INFO - 2023-08-15 13:33:07 --> Utf8 Class Initialized
DEBUG - 2023-08-15 13:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:07 --> URI Class Initialized
INFO - 2023-08-15 13:33:07 --> Security Class Initialized
INFO - 2023-08-15 13:33:07 --> Security Class Initialized
DEBUG - 2023-08-15 13:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-15 13:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:07 --> Input Class Initialized
INFO - 2023-08-15 13:33:07 --> Router Class Initialized
INFO - 2023-08-15 13:33:07 --> Input Class Initialized
INFO - 2023-08-15 13:33:07 --> Output Class Initialized
INFO - 2023-08-15 13:33:07 --> Input Class Initialized
INFO - 2023-08-15 13:33:07 --> Language Class Initialized
INFO - 2023-08-15 13:33:07 --> Language Class Initialized
INFO - 2023-08-15 13:33:08 --> Language Class Initialized
ERROR - 2023-08-15 13:33:08 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-15 13:33:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:33:08 --> Config Class Initialized
INFO - 2023-08-15 13:33:08 --> Hooks Class Initialized
INFO - 2023-08-15 13:33:08 --> Loader Class Initialized
INFO - 2023-08-15 13:33:08 --> Security Class Initialized
INFO - 2023-08-15 13:33:08 --> Helper loaded: url_helper
INFO - 2023-08-15 13:33:08 --> Helper loaded: file_helper
INFO - 2023-08-15 13:33:08 --> Database Driver Class Initialized
INFO - 2023-08-15 13:33:08 --> Email Class Initialized
DEBUG - 2023-08-15 13:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:33:08 --> Controller Class Initialized
INFO - 2023-08-15 13:33:08 --> Model "Home_model" initialized
INFO - 2023-08-15 13:33:08 --> Helper loaded: form_helper
INFO - 2023-08-15 13:33:08 --> Form Validation Class Initialized
INFO - 2023-08-15 13:33:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:33:08 --> Final output sent to browser
DEBUG - 2023-08-15 13:33:08 --> Total execution time: 2.1258
INFO - 2023-08-15 13:33:08 --> Config Class Initialized
INFO - 2023-08-15 13:33:08 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:33:08 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:08 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:08 --> URI Class Initialized
INFO - 2023-08-15 13:33:08 --> Router Class Initialized
INFO - 2023-08-15 13:33:08 --> Output Class Initialized
INFO - 2023-08-15 13:33:08 --> Security Class Initialized
DEBUG - 2023-08-15 13:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:08 --> Input Class Initialized
INFO - 2023-08-15 13:33:08 --> Language Class Initialized
ERROR - 2023-08-15 13:33:08 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-15 13:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:09 --> Config Class Initialized
INFO - 2023-08-15 13:33:09 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:33:09 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:10 --> Input Class Initialized
INFO - 2023-08-15 13:33:10 --> Language Class Initialized
ERROR - 2023-08-15 13:33:10 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:33:10 --> Config Class Initialized
INFO - 2023-08-15 13:33:10 --> Config Class Initialized
DEBUG - 2023-08-15 13:33:10 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:11 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:11 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:11 --> Hooks Class Initialized
INFO - 2023-08-15 13:33:12 --> Config Class Initialized
INFO - 2023-08-15 13:33:12 --> URI Class Initialized
INFO - 2023-08-15 13:33:12 --> URI Class Initialized
INFO - 2023-08-15 13:33:12 --> Config Class Initialized
INFO - 2023-08-15 13:33:12 --> Hooks Class Initialized
INFO - 2023-08-15 13:33:12 --> Hooks Class Initialized
INFO - 2023-08-15 13:33:12 --> Router Class Initialized
INFO - 2023-08-15 13:33:12 --> Hooks Class Initialized
INFO - 2023-08-15 13:33:13 --> Router Class Initialized
INFO - 2023-08-15 13:33:13 --> Output Class Initialized
INFO - 2023-08-15 13:33:13 --> Security Class Initialized
DEBUG - 2023-08-15 13:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:13 --> Input Class Initialized
INFO - 2023-08-15 13:33:13 --> Language Class Initialized
ERROR - 2023-08-15 13:33:13 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-15 13:33:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-15 13:33:13 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:13 --> Output Class Initialized
DEBUG - 2023-08-15 13:33:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-15 13:33:13 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:14 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:14 --> Security Class Initialized
INFO - 2023-08-15 13:33:14 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:14 --> Config Class Initialized
INFO - 2023-08-15 13:33:14 --> Hooks Class Initialized
INFO - 2023-08-15 13:33:14 --> URI Class Initialized
INFO - 2023-08-15 13:33:14 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:15 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:15 --> URI Class Initialized
DEBUG - 2023-08-15 13:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:15 --> Router Class Initialized
DEBUG - 2023-08-15 13:33:15 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:15 --> URI Class Initialized
INFO - 2023-08-15 13:33:15 --> URI Class Initialized
INFO - 2023-08-15 13:33:15 --> Router Class Initialized
INFO - 2023-08-15 13:33:15 --> Input Class Initialized
INFO - 2023-08-15 13:33:15 --> Output Class Initialized
INFO - 2023-08-15 13:33:15 --> Router Class Initialized
INFO - 2023-08-15 13:33:15 --> Output Class Initialized
INFO - 2023-08-15 13:33:15 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:15 --> URI Class Initialized
INFO - 2023-08-15 13:33:15 --> Router Class Initialized
INFO - 2023-08-15 13:33:15 --> Output Class Initialized
INFO - 2023-08-15 13:33:15 --> Security Class Initialized
DEBUG - 2023-08-15 13:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:15 --> Input Class Initialized
INFO - 2023-08-15 13:33:15 --> Language Class Initialized
ERROR - 2023-08-15 13:33:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:33:15 --> Security Class Initialized
INFO - 2023-08-15 13:33:15 --> Router Class Initialized
INFO - 2023-08-15 13:33:15 --> Output Class Initialized
INFO - 2023-08-15 13:33:15 --> Security Class Initialized
DEBUG - 2023-08-15 13:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:15 --> Input Class Initialized
INFO - 2023-08-15 13:33:15 --> Language Class Initialized
ERROR - 2023-08-15 13:33:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:33:15 --> Config Class Initialized
DEBUG - 2023-08-15 13:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:15 --> Input Class Initialized
INFO - 2023-08-15 13:33:15 --> Language Class Initialized
ERROR - 2023-08-15 13:33:15 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:33:15 --> Language Class Initialized
ERROR - 2023-08-15 13:33:15 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:33:15 --> Config Class Initialized
INFO - 2023-08-15 13:33:15 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:33:15 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:15 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:15 --> URI Class Initialized
INFO - 2023-08-15 13:33:15 --> Router Class Initialized
INFO - 2023-08-15 13:33:15 --> Output Class Initialized
INFO - 2023-08-15 13:33:15 --> Security Class Initialized
DEBUG - 2023-08-15 13:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:15 --> Input Class Initialized
INFO - 2023-08-15 13:33:15 --> Language Class Initialized
ERROR - 2023-08-15 13:33:15 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:33:15 --> Config Class Initialized
INFO - 2023-08-15 13:33:15 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:33:15 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:15 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:15 --> URI Class Initialized
INFO - 2023-08-15 13:33:15 --> Router Class Initialized
INFO - 2023-08-15 13:33:15 --> Output Class Initialized
INFO - 2023-08-15 13:33:15 --> Security Class Initialized
DEBUG - 2023-08-15 13:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:15 --> Input Class Initialized
INFO - 2023-08-15 13:33:15 --> Language Class Initialized
ERROR - 2023-08-15 13:33:15 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:33:15 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:33:15 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:15 --> Output Class Initialized
INFO - 2023-08-15 13:33:15 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:15 --> Config Class Initialized
INFO - 2023-08-15 13:33:15 --> Config Class Initialized
INFO - 2023-08-15 13:33:15 --> Config Class Initialized
INFO - 2023-08-15 13:33:15 --> Hooks Class Initialized
INFO - 2023-08-15 13:33:15 --> URI Class Initialized
INFO - 2023-08-15 13:33:15 --> Security Class Initialized
INFO - 2023-08-15 13:33:15 --> Security Class Initialized
INFO - 2023-08-15 13:33:16 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-15 13:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-15 13:33:16 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:16 --> Router Class Initialized
DEBUG - 2023-08-15 13:33:16 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:16 --> Output Class Initialized
INFO - 2023-08-15 13:33:16 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:16 --> Security Class Initialized
INFO - 2023-08-15 13:33:16 --> URI Class Initialized
DEBUG - 2023-08-15 13:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:16 --> Router Class Initialized
INFO - 2023-08-15 13:33:16 --> Input Class Initialized
INFO - 2023-08-15 13:33:16 --> Output Class Initialized
INFO - 2023-08-15 13:33:16 --> Language Class Initialized
INFO - 2023-08-15 13:33:16 --> Security Class Initialized
ERROR - 2023-08-15 13:33:16 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-15 13:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:16 --> Input Class Initialized
INFO - 2023-08-15 13:33:16 --> Language Class Initialized
ERROR - 2023-08-15 13:33:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:33:16 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:33:16 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:16 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:16 --> URI Class Initialized
INFO - 2023-08-15 13:33:16 --> Router Class Initialized
INFO - 2023-08-15 13:33:16 --> Output Class Initialized
INFO - 2023-08-15 13:33:16 --> Security Class Initialized
DEBUG - 2023-08-15 13:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:16 --> Input Class Initialized
INFO - 2023-08-15 13:33:16 --> Language Class Initialized
ERROR - 2023-08-15 13:33:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:33:16 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:16 --> Config Class Initialized
INFO - 2023-08-15 13:33:16 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:33:16 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:33:16 --> Utf8 Class Initialized
INFO - 2023-08-15 13:33:16 --> URI Class Initialized
INFO - 2023-08-15 13:33:16 --> Router Class Initialized
INFO - 2023-08-15 13:33:16 --> Output Class Initialized
INFO - 2023-08-15 13:33:16 --> Security Class Initialized
DEBUG - 2023-08-15 13:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:16 --> Input Class Initialized
INFO - 2023-08-15 13:33:16 --> Language Class Initialized
ERROR - 2023-08-15 13:33:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:33:16 --> Input Class Initialized
INFO - 2023-08-15 13:33:16 --> Input Class Initialized
INFO - 2023-08-15 13:33:16 --> Language Class Initialized
ERROR - 2023-08-15 13:33:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:33:16 --> URI Class Initialized
INFO - 2023-08-15 13:33:16 --> Router Class Initialized
INFO - 2023-08-15 13:33:16 --> Language Class Initialized
ERROR - 2023-08-15 13:33:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:33:16 --> Output Class Initialized
INFO - 2023-08-15 13:33:17 --> Security Class Initialized
DEBUG - 2023-08-15 13:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:33:17 --> Input Class Initialized
INFO - 2023-08-15 13:33:18 --> Language Class Initialized
ERROR - 2023-08-15 13:33:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:35:46 --> Config Class Initialized
INFO - 2023-08-15 13:35:46 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:35:46 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:35:46 --> Utf8 Class Initialized
INFO - 2023-08-15 13:35:46 --> URI Class Initialized
INFO - 2023-08-15 13:35:46 --> Router Class Initialized
INFO - 2023-08-15 13:35:46 --> Output Class Initialized
INFO - 2023-08-15 13:35:47 --> Security Class Initialized
DEBUG - 2023-08-15 13:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:35:47 --> Input Class Initialized
INFO - 2023-08-15 13:35:47 --> Language Class Initialized
INFO - 2023-08-15 13:35:47 --> Loader Class Initialized
INFO - 2023-08-15 13:35:47 --> Helper loaded: url_helper
INFO - 2023-08-15 13:35:47 --> Helper loaded: file_helper
INFO - 2023-08-15 13:35:47 --> Database Driver Class Initialized
INFO - 2023-08-15 13:35:47 --> Email Class Initialized
DEBUG - 2023-08-15 13:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:35:47 --> Controller Class Initialized
INFO - 2023-08-15 13:35:47 --> Model "Home_model" initialized
INFO - 2023-08-15 13:35:47 --> Helper loaded: form_helper
INFO - 2023-08-15 13:35:47 --> Form Validation Class Initialized
INFO - 2023-08-15 13:35:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:35:47 --> Final output sent to browser
DEBUG - 2023-08-15 13:35:48 --> Total execution time: 0.7557
INFO - 2023-08-15 13:35:48 --> Config Class Initialized
INFO - 2023-08-15 13:35:48 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:35:48 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:35:48 --> Utf8 Class Initialized
INFO - 2023-08-15 13:35:48 --> URI Class Initialized
INFO - 2023-08-15 13:35:48 --> Router Class Initialized
INFO - 2023-08-15 13:35:48 --> Output Class Initialized
INFO - 2023-08-15 13:35:48 --> Security Class Initialized
DEBUG - 2023-08-15 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:35:48 --> Input Class Initialized
INFO - 2023-08-15 13:35:48 --> Language Class Initialized
ERROR - 2023-08-15 13:35:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:35:48 --> Config Class Initialized
INFO - 2023-08-15 13:35:48 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:35:48 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:35:48 --> Utf8 Class Initialized
INFO - 2023-08-15 13:35:48 --> URI Class Initialized
INFO - 2023-08-15 13:35:48 --> Router Class Initialized
INFO - 2023-08-15 13:35:48 --> Output Class Initialized
INFO - 2023-08-15 13:35:48 --> Security Class Initialized
DEBUG - 2023-08-15 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:35:48 --> Input Class Initialized
INFO - 2023-08-15 13:35:48 --> Language Class Initialized
ERROR - 2023-08-15 13:35:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:35:48 --> Config Class Initialized
INFO - 2023-08-15 13:35:48 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:35:48 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:35:48 --> Utf8 Class Initialized
INFO - 2023-08-15 13:35:48 --> URI Class Initialized
INFO - 2023-08-15 13:35:48 --> Router Class Initialized
INFO - 2023-08-15 13:35:48 --> Output Class Initialized
INFO - 2023-08-15 13:35:48 --> Security Class Initialized
DEBUG - 2023-08-15 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:35:48 --> Input Class Initialized
INFO - 2023-08-15 13:35:48 --> Language Class Initialized
ERROR - 2023-08-15 13:35:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:35:48 --> Config Class Initialized
INFO - 2023-08-15 13:35:48 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:35:48 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:35:48 --> Utf8 Class Initialized
INFO - 2023-08-15 13:35:48 --> URI Class Initialized
INFO - 2023-08-15 13:35:48 --> Router Class Initialized
INFO - 2023-08-15 13:35:48 --> Output Class Initialized
INFO - 2023-08-15 13:35:48 --> Security Class Initialized
DEBUG - 2023-08-15 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:35:48 --> Input Class Initialized
INFO - 2023-08-15 13:35:48 --> Language Class Initialized
ERROR - 2023-08-15 13:35:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:35:49 --> Config Class Initialized
INFO - 2023-08-15 13:35:49 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:35:49 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:35:49 --> Utf8 Class Initialized
INFO - 2023-08-15 13:35:49 --> URI Class Initialized
INFO - 2023-08-15 13:35:49 --> Router Class Initialized
INFO - 2023-08-15 13:35:49 --> Output Class Initialized
INFO - 2023-08-15 13:35:49 --> Security Class Initialized
DEBUG - 2023-08-15 13:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:35:49 --> Input Class Initialized
INFO - 2023-08-15 13:35:49 --> Language Class Initialized
ERROR - 2023-08-15 13:35:49 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:35:49 --> Config Class Initialized
INFO - 2023-08-15 13:35:49 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:35:49 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:35:49 --> Utf8 Class Initialized
INFO - 2023-08-15 13:35:49 --> URI Class Initialized
INFO - 2023-08-15 13:35:49 --> Router Class Initialized
INFO - 2023-08-15 13:35:49 --> Output Class Initialized
INFO - 2023-08-15 13:35:49 --> Security Class Initialized
DEBUG - 2023-08-15 13:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:35:49 --> Input Class Initialized
INFO - 2023-08-15 13:35:49 --> Language Class Initialized
ERROR - 2023-08-15 13:35:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:35:49 --> Config Class Initialized
INFO - 2023-08-15 13:35:49 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:35:49 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:35:49 --> Utf8 Class Initialized
INFO - 2023-08-15 13:35:49 --> URI Class Initialized
INFO - 2023-08-15 13:35:49 --> Router Class Initialized
INFO - 2023-08-15 13:35:49 --> Output Class Initialized
INFO - 2023-08-15 13:35:49 --> Security Class Initialized
DEBUG - 2023-08-15 13:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:35:49 --> Input Class Initialized
INFO - 2023-08-15 13:35:50 --> Config Class Initialized
INFO - 2023-08-15 13:35:50 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:35:50 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:35:50 --> Utf8 Class Initialized
INFO - 2023-08-15 13:35:50 --> URI Class Initialized
INFO - 2023-08-15 13:35:50 --> Router Class Initialized
INFO - 2023-08-15 13:35:50 --> Output Class Initialized
INFO - 2023-08-15 13:35:50 --> Security Class Initialized
DEBUG - 2023-08-15 13:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:35:50 --> Input Class Initialized
INFO - 2023-08-15 13:35:50 --> Language Class Initialized
INFO - 2023-08-15 13:35:50 --> Language Class Initialized
ERROR - 2023-08-15 13:35:50 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:35:50 --> Config Class Initialized
INFO - 2023-08-15 13:35:50 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:35:50 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:35:50 --> Utf8 Class Initialized
INFO - 2023-08-15 13:35:50 --> URI Class Initialized
INFO - 2023-08-15 13:35:50 --> Router Class Initialized
INFO - 2023-08-15 13:35:50 --> Output Class Initialized
INFO - 2023-08-15 13:35:50 --> Security Class Initialized
DEBUG - 2023-08-15 13:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:35:50 --> Input Class Initialized
INFO - 2023-08-15 13:35:50 --> Language Class Initialized
ERROR - 2023-08-15 13:35:50 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-15 13:35:50 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:35:50 --> Config Class Initialized
INFO - 2023-08-15 13:35:50 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:35:50 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:35:50 --> Utf8 Class Initialized
INFO - 2023-08-15 13:35:50 --> URI Class Initialized
INFO - 2023-08-15 13:35:50 --> Router Class Initialized
INFO - 2023-08-15 13:35:50 --> Output Class Initialized
INFO - 2023-08-15 13:35:50 --> Security Class Initialized
DEBUG - 2023-08-15 13:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:35:50 --> Input Class Initialized
INFO - 2023-08-15 13:35:50 --> Language Class Initialized
ERROR - 2023-08-15 13:35:50 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:35:51 --> Config Class Initialized
INFO - 2023-08-15 13:35:51 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:35:51 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:35:51 --> Utf8 Class Initialized
INFO - 2023-08-15 13:35:51 --> URI Class Initialized
INFO - 2023-08-15 13:35:51 --> Router Class Initialized
INFO - 2023-08-15 13:35:51 --> Output Class Initialized
INFO - 2023-08-15 13:35:51 --> Security Class Initialized
DEBUG - 2023-08-15 13:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:35:51 --> Input Class Initialized
INFO - 2023-08-15 13:35:51 --> Language Class Initialized
ERROR - 2023-08-15 13:35:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:35:52 --> Config Class Initialized
INFO - 2023-08-15 13:35:52 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:35:52 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:35:52 --> Utf8 Class Initialized
INFO - 2023-08-15 13:35:52 --> URI Class Initialized
INFO - 2023-08-15 13:35:52 --> Router Class Initialized
INFO - 2023-08-15 13:35:52 --> Output Class Initialized
INFO - 2023-08-15 13:35:52 --> Security Class Initialized
DEBUG - 2023-08-15 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:35:52 --> Input Class Initialized
INFO - 2023-08-15 13:35:52 --> Language Class Initialized
ERROR - 2023-08-15 13:35:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:35:52 --> Config Class Initialized
INFO - 2023-08-15 13:35:52 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:35:52 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:35:52 --> Utf8 Class Initialized
INFO - 2023-08-15 13:35:52 --> URI Class Initialized
INFO - 2023-08-15 13:35:52 --> Router Class Initialized
INFO - 2023-08-15 13:35:52 --> Output Class Initialized
INFO - 2023-08-15 13:35:52 --> Security Class Initialized
DEBUG - 2023-08-15 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:35:52 --> Input Class Initialized
INFO - 2023-08-15 13:35:52 --> Language Class Initialized
ERROR - 2023-08-15 13:35:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:37:40 --> Config Class Initialized
INFO - 2023-08-15 13:37:40 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:37:40 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:37:40 --> Utf8 Class Initialized
INFO - 2023-08-15 13:37:40 --> URI Class Initialized
INFO - 2023-08-15 13:37:40 --> Router Class Initialized
INFO - 2023-08-15 13:37:40 --> Output Class Initialized
INFO - 2023-08-15 13:37:40 --> Security Class Initialized
DEBUG - 2023-08-15 13:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:37:41 --> Input Class Initialized
INFO - 2023-08-15 13:37:41 --> Language Class Initialized
INFO - 2023-08-15 13:37:41 --> Loader Class Initialized
INFO - 2023-08-15 13:37:41 --> Helper loaded: url_helper
INFO - 2023-08-15 13:37:41 --> Helper loaded: file_helper
INFO - 2023-08-15 13:37:41 --> Database Driver Class Initialized
INFO - 2023-08-15 13:37:41 --> Email Class Initialized
DEBUG - 2023-08-15 13:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:37:41 --> Controller Class Initialized
INFO - 2023-08-15 13:37:41 --> Model "Home_model" initialized
INFO - 2023-08-15 13:37:41 --> Helper loaded: form_helper
INFO - 2023-08-15 13:37:41 --> Form Validation Class Initialized
INFO - 2023-08-15 13:37:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:37:41 --> Final output sent to browser
DEBUG - 2023-08-15 13:37:41 --> Total execution time: 0.6046
INFO - 2023-08-15 13:37:43 --> Config Class Initialized
INFO - 2023-08-15 13:37:43 --> Hooks Class Initialized
INFO - 2023-08-15 13:37:44 --> Config Class Initialized
INFO - 2023-08-15 13:37:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:37:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:37:44 --> Utf8 Class Initialized
INFO - 2023-08-15 13:37:44 --> URI Class Initialized
INFO - 2023-08-15 13:37:44 --> Router Class Initialized
INFO - 2023-08-15 13:37:44 --> Output Class Initialized
INFO - 2023-08-15 13:37:44 --> Security Class Initialized
DEBUG - 2023-08-15 13:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:37:44 --> Input Class Initialized
INFO - 2023-08-15 13:37:44 --> Language Class Initialized
ERROR - 2023-08-15 13:37:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:37:44 --> Config Class Initialized
INFO - 2023-08-15 13:37:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:37:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:37:44 --> Utf8 Class Initialized
INFO - 2023-08-15 13:37:44 --> URI Class Initialized
INFO - 2023-08-15 13:37:44 --> Router Class Initialized
INFO - 2023-08-15 13:37:44 --> Output Class Initialized
INFO - 2023-08-15 13:37:44 --> Security Class Initialized
DEBUG - 2023-08-15 13:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:37:44 --> Input Class Initialized
INFO - 2023-08-15 13:37:44 --> Language Class Initialized
ERROR - 2023-08-15 13:37:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:37:44 --> Config Class Initialized
INFO - 2023-08-15 13:37:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:37:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:37:44 --> Config Class Initialized
DEBUG - 2023-08-15 13:37:45 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:37:45 --> Hooks Class Initialized
INFO - 2023-08-15 13:37:45 --> Utf8 Class Initialized
DEBUG - 2023-08-15 13:37:45 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:37:45 --> Utf8 Class Initialized
INFO - 2023-08-15 13:37:45 --> Utf8 Class Initialized
INFO - 2023-08-15 13:37:45 --> URI Class Initialized
INFO - 2023-08-15 13:37:45 --> URI Class Initialized
INFO - 2023-08-15 13:37:45 --> URI Class Initialized
INFO - 2023-08-15 13:37:46 --> Config Class Initialized
INFO - 2023-08-15 13:37:46 --> Router Class Initialized
INFO - 2023-08-15 13:37:46 --> Output Class Initialized
INFO - 2023-08-15 13:37:46 --> Hooks Class Initialized
INFO - 2023-08-15 13:37:47 --> Router Class Initialized
DEBUG - 2023-08-15 13:37:47 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:37:47 --> Security Class Initialized
INFO - 2023-08-15 13:37:47 --> Router Class Initialized
INFO - 2023-08-15 13:37:47 --> Utf8 Class Initialized
INFO - 2023-08-15 13:37:47 --> Output Class Initialized
INFO - 2023-08-15 13:37:47 --> URI Class Initialized
INFO - 2023-08-15 13:37:47 --> Security Class Initialized
INFO - 2023-08-15 13:37:47 --> Router Class Initialized
DEBUG - 2023-08-15 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:37:48 --> Input Class Initialized
INFO - 2023-08-15 13:37:48 --> Output Class Initialized
INFO - 2023-08-15 13:37:48 --> Output Class Initialized
INFO - 2023-08-15 13:37:48 --> Security Class Initialized
INFO - 2023-08-15 13:37:48 --> Security Class Initialized
DEBUG - 2023-08-15 13:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-15 13:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-15 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:37:48 --> Input Class Initialized
INFO - 2023-08-15 13:37:48 --> Input Class Initialized
INFO - 2023-08-15 13:37:48 --> Language Class Initialized
INFO - 2023-08-15 13:37:48 --> Config Class Initialized
INFO - 2023-08-15 13:37:48 --> Language Class Initialized
INFO - 2023-08-15 13:37:48 --> Language Class Initialized
ERROR - 2023-08-15 13:37:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:37:48 --> Hooks Class Initialized
INFO - 2023-08-15 13:37:48 --> Input Class Initialized
ERROR - 2023-08-15 13:37:48 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-15 13:37:48 --> UTF-8 Support Enabled
ERROR - 2023-08-15 13:37:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:37:48 --> Utf8 Class Initialized
INFO - 2023-08-15 13:37:48 --> Language Class Initialized
INFO - 2023-08-15 13:37:48 --> URI Class Initialized
ERROR - 2023-08-15 13:37:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:37:48 --> Config Class Initialized
INFO - 2023-08-15 13:37:48 --> Hooks Class Initialized
INFO - 2023-08-15 13:37:48 --> Router Class Initialized
DEBUG - 2023-08-15 13:37:48 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:37:48 --> Output Class Initialized
INFO - 2023-08-15 13:37:48 --> Security Class Initialized
INFO - 2023-08-15 13:37:48 --> Utf8 Class Initialized
DEBUG - 2023-08-15 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:37:48 --> Input Class Initialized
INFO - 2023-08-15 13:37:48 --> URI Class Initialized
INFO - 2023-08-15 13:37:48 --> Language Class Initialized
ERROR - 2023-08-15 13:37:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:37:48 --> Router Class Initialized
INFO - 2023-08-15 13:37:48 --> Output Class Initialized
INFO - 2023-08-15 13:37:48 --> Security Class Initialized
DEBUG - 2023-08-15 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:37:48 --> Input Class Initialized
INFO - 2023-08-15 13:37:48 --> Language Class Initialized
ERROR - 2023-08-15 13:37:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:37:52 --> Config Class Initialized
INFO - 2023-08-15 13:37:52 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:37:52 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:37:52 --> Utf8 Class Initialized
INFO - 2023-08-15 13:37:52 --> URI Class Initialized
INFO - 2023-08-15 13:37:52 --> Router Class Initialized
INFO - 2023-08-15 13:37:52 --> Output Class Initialized
INFO - 2023-08-15 13:37:52 --> Security Class Initialized
DEBUG - 2023-08-15 13:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:37:52 --> Input Class Initialized
INFO - 2023-08-15 13:37:52 --> Language Class Initialized
INFO - 2023-08-15 13:37:52 --> Loader Class Initialized
INFO - 2023-08-15 13:37:52 --> Helper loaded: url_helper
INFO - 2023-08-15 13:37:52 --> Helper loaded: file_helper
INFO - 2023-08-15 13:37:52 --> Database Driver Class Initialized
INFO - 2023-08-15 13:37:52 --> Email Class Initialized
DEBUG - 2023-08-15 13:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:37:52 --> Controller Class Initialized
INFO - 2023-08-15 13:37:52 --> Model "Home_model" initialized
INFO - 2023-08-15 13:37:52 --> Helper loaded: form_helper
INFO - 2023-08-15 13:37:52 --> Form Validation Class Initialized
INFO - 2023-08-15 13:37:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:37:52 --> Final output sent to browser
DEBUG - 2023-08-15 13:37:53 --> Total execution time: 0.4778
INFO - 2023-08-15 13:37:54 --> Config Class Initialized
INFO - 2023-08-15 13:37:54 --> Config Class Initialized
INFO - 2023-08-15 13:37:54 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:37:54 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:37:54 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:37:54 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:37:54 --> Config Class Initialized
INFO - 2023-08-15 13:37:54 --> Config Class Initialized
INFO - 2023-08-15 13:37:54 --> Hooks Class Initialized
INFO - 2023-08-15 13:37:54 --> Hooks Class Initialized
INFO - 2023-08-15 13:37:54 --> Utf8 Class Initialized
INFO - 2023-08-15 13:37:54 --> Utf8 Class Initialized
INFO - 2023-08-15 13:37:54 --> URI Class Initialized
DEBUG - 2023-08-15 13:37:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-15 13:37:54 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:37:54 --> Utf8 Class Initialized
INFO - 2023-08-15 13:37:54 --> Router Class Initialized
INFO - 2023-08-15 13:37:54 --> URI Class Initialized
INFO - 2023-08-15 13:37:54 --> URI Class Initialized
INFO - 2023-08-15 13:37:54 --> Router Class Initialized
INFO - 2023-08-15 13:37:54 --> Output Class Initialized
INFO - 2023-08-15 13:37:54 --> Output Class Initialized
INFO - 2023-08-15 13:37:54 --> Utf8 Class Initialized
INFO - 2023-08-15 13:37:54 --> Security Class Initialized
INFO - 2023-08-15 13:37:54 --> Router Class Initialized
DEBUG - 2023-08-15 13:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:37:54 --> Security Class Initialized
INFO - 2023-08-15 13:37:54 --> Output Class Initialized
INFO - 2023-08-15 13:37:54 --> URI Class Initialized
DEBUG - 2023-08-15 13:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:37:54 --> Input Class Initialized
INFO - 2023-08-15 13:37:54 --> Security Class Initialized
INFO - 2023-08-15 13:37:54 --> Router Class Initialized
INFO - 2023-08-15 13:37:54 --> Language Class Initialized
INFO - 2023-08-15 13:37:54 --> Input Class Initialized
DEBUG - 2023-08-15 13:37:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-15 13:37:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:37:54 --> Output Class Initialized
INFO - 2023-08-15 13:37:54 --> Language Class Initialized
INFO - 2023-08-15 13:37:54 --> Security Class Initialized
ERROR - 2023-08-15 13:37:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:37:54 --> Input Class Initialized
DEBUG - 2023-08-15 13:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:37:54 --> Language Class Initialized
INFO - 2023-08-15 13:37:55 --> Input Class Initialized
ERROR - 2023-08-15 13:37:55 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:37:55 --> Language Class Initialized
ERROR - 2023-08-15 13:37:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:38:13 --> Config Class Initialized
INFO - 2023-08-15 13:38:13 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:38:13 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:38:13 --> Utf8 Class Initialized
INFO - 2023-08-15 13:38:13 --> URI Class Initialized
INFO - 2023-08-15 13:38:13 --> Router Class Initialized
INFO - 2023-08-15 13:38:13 --> Output Class Initialized
INFO - 2023-08-15 13:38:13 --> Security Class Initialized
DEBUG - 2023-08-15 13:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:38:13 --> Input Class Initialized
INFO - 2023-08-15 13:38:13 --> Language Class Initialized
INFO - 2023-08-15 13:38:13 --> Loader Class Initialized
INFO - 2023-08-15 13:38:13 --> Helper loaded: url_helper
INFO - 2023-08-15 13:38:13 --> Helper loaded: file_helper
INFO - 2023-08-15 13:38:13 --> Database Driver Class Initialized
INFO - 2023-08-15 13:38:13 --> Email Class Initialized
DEBUG - 2023-08-15 13:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:38:13 --> Controller Class Initialized
INFO - 2023-08-15 13:38:13 --> Model "Home_model" initialized
INFO - 2023-08-15 13:38:13 --> Helper loaded: form_helper
INFO - 2023-08-15 13:38:13 --> Form Validation Class Initialized
INFO - 2023-08-15 13:38:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:38:13 --> Final output sent to browser
DEBUG - 2023-08-15 13:38:13 --> Total execution time: 0.4625
INFO - 2023-08-15 13:38:14 --> Config Class Initialized
INFO - 2023-08-15 13:38:14 --> Hooks Class Initialized
INFO - 2023-08-15 13:38:14 --> Config Class Initialized
INFO - 2023-08-15 13:38:14 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:38:14 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:38:14 --> Config Class Initialized
DEBUG - 2023-08-15 13:38:14 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:38:14 --> Utf8 Class Initialized
INFO - 2023-08-15 13:38:14 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:38:14 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:38:14 --> Utf8 Class Initialized
INFO - 2023-08-15 13:38:14 --> URI Class Initialized
INFO - 2023-08-15 13:38:14 --> URI Class Initialized
INFO - 2023-08-15 13:38:14 --> Router Class Initialized
INFO - 2023-08-15 13:38:14 --> Config Class Initialized
INFO - 2023-08-15 13:38:14 --> Router Class Initialized
INFO - 2023-08-15 13:38:14 --> Utf8 Class Initialized
INFO - 2023-08-15 13:38:14 --> Output Class Initialized
INFO - 2023-08-15 13:38:14 --> Hooks Class Initialized
INFO - 2023-08-15 13:38:14 --> Output Class Initialized
DEBUG - 2023-08-15 13:38:14 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:38:14 --> Security Class Initialized
INFO - 2023-08-15 13:38:14 --> Utf8 Class Initialized
INFO - 2023-08-15 13:38:14 --> URI Class Initialized
INFO - 2023-08-15 13:38:14 --> Security Class Initialized
INFO - 2023-08-15 13:38:14 --> Router Class Initialized
DEBUG - 2023-08-15 13:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-15 13:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:38:14 --> Input Class Initialized
INFO - 2023-08-15 13:38:14 --> Input Class Initialized
INFO - 2023-08-15 13:38:14 --> Language Class Initialized
ERROR - 2023-08-15 13:38:14 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:38:14 --> Output Class Initialized
INFO - 2023-08-15 13:38:14 --> Language Class Initialized
INFO - 2023-08-15 13:38:14 --> Security Class Initialized
DEBUG - 2023-08-15 13:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:38:14 --> URI Class Initialized
ERROR - 2023-08-15 13:38:14 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:38:14 --> Router Class Initialized
INFO - 2023-08-15 13:38:14 --> Input Class Initialized
INFO - 2023-08-15 13:38:14 --> Output Class Initialized
INFO - 2023-08-15 13:38:14 --> Language Class Initialized
ERROR - 2023-08-15 13:38:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:38:15 --> Security Class Initialized
DEBUG - 2023-08-15 13:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:38:15 --> Input Class Initialized
INFO - 2023-08-15 13:38:15 --> Language Class Initialized
ERROR - 2023-08-15 13:38:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:38:32 --> Config Class Initialized
INFO - 2023-08-15 13:38:32 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:38:32 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:38:32 --> Utf8 Class Initialized
INFO - 2023-08-15 13:38:32 --> URI Class Initialized
INFO - 2023-08-15 13:38:32 --> Router Class Initialized
INFO - 2023-08-15 13:38:32 --> Output Class Initialized
INFO - 2023-08-15 13:38:32 --> Security Class Initialized
DEBUG - 2023-08-15 13:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:38:32 --> Input Class Initialized
INFO - 2023-08-15 13:38:32 --> Language Class Initialized
ERROR - 2023-08-15 13:38:32 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:38:33 --> Config Class Initialized
INFO - 2023-08-15 13:38:33 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:38:33 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:38:33 --> Utf8 Class Initialized
INFO - 2023-08-15 13:38:33 --> URI Class Initialized
INFO - 2023-08-15 13:38:33 --> Router Class Initialized
INFO - 2023-08-15 13:38:33 --> Output Class Initialized
INFO - 2023-08-15 13:38:33 --> Security Class Initialized
DEBUG - 2023-08-15 13:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:38:33 --> Input Class Initialized
INFO - 2023-08-15 13:38:33 --> Language Class Initialized
ERROR - 2023-08-15 13:38:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:38:34 --> Config Class Initialized
INFO - 2023-08-15 13:38:34 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:38:34 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:38:34 --> Utf8 Class Initialized
INFO - 2023-08-15 13:38:34 --> URI Class Initialized
INFO - 2023-08-15 13:38:34 --> Router Class Initialized
INFO - 2023-08-15 13:38:34 --> Output Class Initialized
INFO - 2023-08-15 13:38:34 --> Security Class Initialized
DEBUG - 2023-08-15 13:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:38:34 --> Input Class Initialized
INFO - 2023-08-15 13:38:34 --> Language Class Initialized
ERROR - 2023-08-15 13:38:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:38:34 --> Config Class Initialized
INFO - 2023-08-15 13:38:34 --> Config Class Initialized
INFO - 2023-08-15 13:38:34 --> Hooks Class Initialized
INFO - 2023-08-15 13:38:34 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-15 13:38:34 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:38:34 --> Config Class Initialized
INFO - 2023-08-15 13:38:35 --> Config Class Initialized
INFO - 2023-08-15 13:38:35 --> Utf8 Class Initialized
INFO - 2023-08-15 13:38:35 --> URI Class Initialized
INFO - 2023-08-15 13:38:35 --> Hooks Class Initialized
INFO - 2023-08-15 13:38:35 --> Utf8 Class Initialized
INFO - 2023-08-15 13:38:35 --> URI Class Initialized
DEBUG - 2023-08-15 13:38:35 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:38:35 --> Hooks Class Initialized
INFO - 2023-08-15 13:38:35 --> Router Class Initialized
INFO - 2023-08-15 13:38:35 --> Output Class Initialized
INFO - 2023-08-15 13:38:35 --> Utf8 Class Initialized
INFO - 2023-08-15 13:38:35 --> Router Class Initialized
DEBUG - 2023-08-15 13:38:35 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:38:35 --> Security Class Initialized
INFO - 2023-08-15 13:38:35 --> Output Class Initialized
INFO - 2023-08-15 13:38:35 --> URI Class Initialized
DEBUG - 2023-08-15 13:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:38:35 --> Router Class Initialized
INFO - 2023-08-15 13:38:35 --> Utf8 Class Initialized
INFO - 2023-08-15 13:38:35 --> Security Class Initialized
INFO - 2023-08-15 13:38:35 --> Output Class Initialized
INFO - 2023-08-15 13:38:35 --> Input Class Initialized
DEBUG - 2023-08-15 13:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:38:35 --> URI Class Initialized
INFO - 2023-08-15 13:38:35 --> Input Class Initialized
INFO - 2023-08-15 13:38:35 --> Language Class Initialized
ERROR - 2023-08-15 13:38:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:38:35 --> Security Class Initialized
INFO - 2023-08-15 13:38:35 --> Language Class Initialized
ERROR - 2023-08-15 13:38:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:38:35 --> Router Class Initialized
INFO - 2023-08-15 13:38:35 --> Output Class Initialized
DEBUG - 2023-08-15 13:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:38:35 --> Input Class Initialized
INFO - 2023-08-15 13:38:35 --> Language Class Initialized
INFO - 2023-08-15 13:38:35 --> Security Class Initialized
ERROR - 2023-08-15 13:38:35 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-15 13:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:38:35 --> Input Class Initialized
INFO - 2023-08-15 13:38:35 --> Language Class Initialized
ERROR - 2023-08-15 13:38:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:36 --> Config Class Initialized
INFO - 2023-08-15 13:39:36 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:36 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:36 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:36 --> URI Class Initialized
INFO - 2023-08-15 13:39:36 --> Router Class Initialized
INFO - 2023-08-15 13:39:36 --> Output Class Initialized
INFO - 2023-08-15 13:39:36 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:36 --> Input Class Initialized
INFO - 2023-08-15 13:39:36 --> Language Class Initialized
INFO - 2023-08-15 13:39:36 --> Loader Class Initialized
INFO - 2023-08-15 13:39:36 --> Helper loaded: url_helper
INFO - 2023-08-15 13:39:36 --> Helper loaded: file_helper
INFO - 2023-08-15 13:39:37 --> Database Driver Class Initialized
INFO - 2023-08-15 13:39:37 --> Email Class Initialized
DEBUG - 2023-08-15 13:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:39:37 --> Controller Class Initialized
INFO - 2023-08-15 13:39:37 --> Model "Home_model" initialized
INFO - 2023-08-15 13:39:37 --> Helper loaded: form_helper
INFO - 2023-08-15 13:39:37 --> Form Validation Class Initialized
INFO - 2023-08-15 13:39:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:39:37 --> Final output sent to browser
DEBUG - 2023-08-15 13:39:37 --> Total execution time: 0.8554
INFO - 2023-08-15 13:39:38 --> Config Class Initialized
INFO - 2023-08-15 13:39:40 --> Hooks Class Initialized
INFO - 2023-08-15 13:39:40 --> Config Class Initialized
INFO - 2023-08-15 13:39:40 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:40 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:40 --> Utf8 Class Initialized
DEBUG - 2023-08-15 13:39:40 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:40 --> URI Class Initialized
INFO - 2023-08-15 13:39:40 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:40 --> Router Class Initialized
INFO - 2023-08-15 13:39:40 --> Output Class Initialized
INFO - 2023-08-15 13:39:41 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:41 --> Input Class Initialized
INFO - 2023-08-15 13:39:41 --> Config Class Initialized
INFO - 2023-08-15 13:39:41 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:41 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:41 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:41 --> URI Class Initialized
INFO - 2023-08-15 13:39:41 --> Router Class Initialized
INFO - 2023-08-15 13:39:41 --> Output Class Initialized
INFO - 2023-08-15 13:39:41 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:41 --> Input Class Initialized
INFO - 2023-08-15 13:39:41 --> Language Class Initialized
ERROR - 2023-08-15 13:39:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:39:41 --> Config Class Initialized
INFO - 2023-08-15 13:39:41 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:41 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:41 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:41 --> URI Class Initialized
INFO - 2023-08-15 13:39:41 --> Router Class Initialized
INFO - 2023-08-15 13:39:41 --> Output Class Initialized
INFO - 2023-08-15 13:39:41 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:41 --> Input Class Initialized
INFO - 2023-08-15 13:39:41 --> Language Class Initialized
ERROR - 2023-08-15 13:39:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:41 --> URI Class Initialized
INFO - 2023-08-15 13:39:41 --> Config Class Initialized
INFO - 2023-08-15 13:39:41 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:41 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:41 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:41 --> URI Class Initialized
INFO - 2023-08-15 13:39:41 --> Router Class Initialized
INFO - 2023-08-15 13:39:41 --> Output Class Initialized
INFO - 2023-08-15 13:39:41 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:41 --> Input Class Initialized
INFO - 2023-08-15 13:39:41 --> Language Class Initialized
ERROR - 2023-08-15 13:39:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:41 --> Config Class Initialized
INFO - 2023-08-15 13:39:42 --> Language Class Initialized
INFO - 2023-08-15 13:39:42 --> Router Class Initialized
INFO - 2023-08-15 13:39:42 --> Output Class Initialized
INFO - 2023-08-15 13:39:42 --> Security Class Initialized
INFO - 2023-08-15 13:39:42 --> Config Class Initialized
DEBUG - 2023-08-15 13:39:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-15 13:39:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:42 --> Config Class Initialized
INFO - 2023-08-15 13:39:42 --> Input Class Initialized
INFO - 2023-08-15 13:39:42 --> Hooks Class Initialized
INFO - 2023-08-15 13:39:42 --> Hooks Class Initialized
INFO - 2023-08-15 13:39:42 --> Hooks Class Initialized
INFO - 2023-08-15 13:39:42 --> Config Class Initialized
INFO - 2023-08-15 13:39:42 --> Language Class Initialized
DEBUG - 2023-08-15 13:39:42 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:42 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:42 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:42 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:42 --> URI Class Initialized
INFO - 2023-08-15 13:39:42 --> Router Class Initialized
INFO - 2023-08-15 13:39:42 --> Output Class Initialized
INFO - 2023-08-15 13:39:42 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:42 --> Input Class Initialized
INFO - 2023-08-15 13:39:42 --> Language Class Initialized
ERROR - 2023-08-15 13:39:42 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-15 13:39:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:39:42 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:42 --> URI Class Initialized
INFO - 2023-08-15 13:39:42 --> Config Class Initialized
DEBUG - 2023-08-15 13:39:42 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:42 --> Utf8 Class Initialized
DEBUG - 2023-08-15 13:39:42 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:42 --> Hooks Class Initialized
INFO - 2023-08-15 13:39:42 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:42 --> Router Class Initialized
INFO - 2023-08-15 13:39:42 --> Config Class Initialized
INFO - 2023-08-15 13:39:42 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:42 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:42 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:42 --> URI Class Initialized
INFO - 2023-08-15 13:39:42 --> Router Class Initialized
INFO - 2023-08-15 13:39:42 --> Output Class Initialized
INFO - 2023-08-15 13:39:42 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:42 --> Output Class Initialized
INFO - 2023-08-15 13:39:42 --> URI Class Initialized
INFO - 2023-08-15 13:39:42 --> Input Class Initialized
INFO - 2023-08-15 13:39:42 --> URI Class Initialized
INFO - 2023-08-15 13:39:42 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:42 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:42 --> Router Class Initialized
INFO - 2023-08-15 13:39:42 --> Router Class Initialized
INFO - 2023-08-15 13:39:42 --> Output Class Initialized
INFO - 2023-08-15 13:39:42 --> Language Class Initialized
ERROR - 2023-08-15 13:39:42 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-15 13:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:42 --> Output Class Initialized
INFO - 2023-08-15 13:39:42 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:42 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:42 --> Input Class Initialized
INFO - 2023-08-15 13:39:42 --> Security Class Initialized
INFO - 2023-08-15 13:39:42 --> Input Class Initialized
INFO - 2023-08-15 13:39:42 --> Language Class Initialized
DEBUG - 2023-08-15 13:39:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-15 13:39:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:42 --> Language Class Initialized
INFO - 2023-08-15 13:39:42 --> Input Class Initialized
ERROR - 2023-08-15 13:39:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:43 --> URI Class Initialized
INFO - 2023-08-15 13:39:43 --> Language Class Initialized
ERROR - 2023-08-15 13:39:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:43 --> Router Class Initialized
INFO - 2023-08-15 13:39:43 --> Output Class Initialized
INFO - 2023-08-15 13:39:43 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:44 --> Input Class Initialized
INFO - 2023-08-15 13:39:44 --> Language Class Initialized
ERROR - 2023-08-15 13:39:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:48 --> Config Class Initialized
INFO - 2023-08-15 13:39:48 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:48 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:48 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:48 --> URI Class Initialized
INFO - 2023-08-15 13:39:48 --> Router Class Initialized
INFO - 2023-08-15 13:39:48 --> Output Class Initialized
INFO - 2023-08-15 13:39:48 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:48 --> Input Class Initialized
INFO - 2023-08-15 13:39:48 --> Language Class Initialized
INFO - 2023-08-15 13:39:48 --> Loader Class Initialized
INFO - 2023-08-15 13:39:48 --> Helper loaded: url_helper
INFO - 2023-08-15 13:39:48 --> Helper loaded: file_helper
INFO - 2023-08-15 13:39:48 --> Database Driver Class Initialized
INFO - 2023-08-15 13:39:48 --> Email Class Initialized
DEBUG - 2023-08-15 13:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:39:48 --> Controller Class Initialized
INFO - 2023-08-15 13:39:48 --> Model "Home_model" initialized
INFO - 2023-08-15 13:39:48 --> Helper loaded: form_helper
INFO - 2023-08-15 13:39:48 --> Form Validation Class Initialized
INFO - 2023-08-15 13:39:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:39:48 --> Final output sent to browser
DEBUG - 2023-08-15 13:39:48 --> Total execution time: 0.5643
INFO - 2023-08-15 13:39:51 --> Config Class Initialized
INFO - 2023-08-15 13:39:51 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:51 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:51 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:51 --> URI Class Initialized
INFO - 2023-08-15 13:39:51 --> Router Class Initialized
INFO - 2023-08-15 13:39:51 --> Output Class Initialized
INFO - 2023-08-15 13:39:51 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:51 --> Input Class Initialized
INFO - 2023-08-15 13:39:51 --> Language Class Initialized
ERROR - 2023-08-15 13:39:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:52 --> Config Class Initialized
INFO - 2023-08-15 13:39:52 --> Config Class Initialized
INFO - 2023-08-15 13:39:52 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:52 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:52 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:52 --> URI Class Initialized
INFO - 2023-08-15 13:39:52 --> Router Class Initialized
INFO - 2023-08-15 13:39:52 --> Output Class Initialized
INFO - 2023-08-15 13:39:52 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:52 --> Input Class Initialized
INFO - 2023-08-15 13:39:52 --> Language Class Initialized
ERROR - 2023-08-15 13:39:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:52 --> Hooks Class Initialized
INFO - 2023-08-15 13:39:52 --> Config Class Initialized
INFO - 2023-08-15 13:39:52 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:52 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:52 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:52 --> URI Class Initialized
INFO - 2023-08-15 13:39:52 --> Router Class Initialized
INFO - 2023-08-15 13:39:52 --> Output Class Initialized
INFO - 2023-08-15 13:39:52 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:52 --> Input Class Initialized
INFO - 2023-08-15 13:39:52 --> Language Class Initialized
ERROR - 2023-08-15 13:39:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:39:52 --> Config Class Initialized
INFO - 2023-08-15 13:39:52 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:52 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:52 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:52 --> URI Class Initialized
INFO - 2023-08-15 13:39:52 --> Router Class Initialized
INFO - 2023-08-15 13:39:52 --> Output Class Initialized
INFO - 2023-08-15 13:39:52 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:52 --> Input Class Initialized
INFO - 2023-08-15 13:39:52 --> Language Class Initialized
ERROR - 2023-08-15 13:39:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:39:53 --> Config Class Initialized
DEBUG - 2023-08-15 13:39:54 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:54 --> Config Class Initialized
INFO - 2023-08-15 13:39:54 --> Config Class Initialized
INFO - 2023-08-15 13:39:54 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:54 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:54 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:54 --> URI Class Initialized
INFO - 2023-08-15 13:39:54 --> Router Class Initialized
INFO - 2023-08-15 13:39:54 --> Output Class Initialized
INFO - 2023-08-15 13:39:54 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:54 --> Input Class Initialized
INFO - 2023-08-15 13:39:54 --> Language Class Initialized
ERROR - 2023-08-15 13:39:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:54 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:54 --> URI Class Initialized
INFO - 2023-08-15 13:39:54 --> Router Class Initialized
INFO - 2023-08-15 13:39:54 --> Output Class Initialized
INFO - 2023-08-15 13:39:54 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:54 --> Input Class Initialized
INFO - 2023-08-15 13:39:54 --> Language Class Initialized
ERROR - 2023-08-15 13:39:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:54 --> Config Class Initialized
INFO - 2023-08-15 13:39:54 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:54 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:54 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:54 --> URI Class Initialized
INFO - 2023-08-15 13:39:54 --> Router Class Initialized
INFO - 2023-08-15 13:39:54 --> Output Class Initialized
INFO - 2023-08-15 13:39:54 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:54 --> Input Class Initialized
INFO - 2023-08-15 13:39:54 --> Language Class Initialized
ERROR - 2023-08-15 13:39:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:55 --> Hooks Class Initialized
INFO - 2023-08-15 13:39:55 --> Config Class Initialized
INFO - 2023-08-15 13:39:55 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:55 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:55 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:55 --> URI Class Initialized
INFO - 2023-08-15 13:39:55 --> Router Class Initialized
INFO - 2023-08-15 13:39:55 --> Output Class Initialized
INFO - 2023-08-15 13:39:55 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:55 --> Input Class Initialized
INFO - 2023-08-15 13:39:55 --> Language Class Initialized
ERROR - 2023-08-15 13:39:55 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:55 --> Config Class Initialized
DEBUG - 2023-08-15 13:39:55 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:55 --> Hooks Class Initialized
INFO - 2023-08-15 13:39:56 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:39:56 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:56 --> Config Class Initialized
INFO - 2023-08-15 13:39:56 --> Utf8 Class Initialized
DEBUG - 2023-08-15 13:39:56 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:56 --> Hooks Class Initialized
INFO - 2023-08-15 13:39:56 --> URI Class Initialized
INFO - 2023-08-15 13:39:56 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:56 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:56 --> URI Class Initialized
DEBUG - 2023-08-15 13:39:57 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:39:57 --> Router Class Initialized
INFO - 2023-08-15 13:39:57 --> URI Class Initialized
INFO - 2023-08-15 13:39:57 --> Router Class Initialized
INFO - 2023-08-15 13:39:57 --> Output Class Initialized
INFO - 2023-08-15 13:39:57 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:57 --> Input Class Initialized
INFO - 2023-08-15 13:39:57 --> Language Class Initialized
ERROR - 2023-08-15 13:39:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:57 --> Router Class Initialized
INFO - 2023-08-15 13:39:57 --> Utf8 Class Initialized
INFO - 2023-08-15 13:39:57 --> URI Class Initialized
INFO - 2023-08-15 13:39:57 --> Router Class Initialized
INFO - 2023-08-15 13:39:57 --> Output Class Initialized
INFO - 2023-08-15 13:39:57 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:57 --> Input Class Initialized
INFO - 2023-08-15 13:39:57 --> Language Class Initialized
ERROR - 2023-08-15 13:39:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:57 --> Output Class Initialized
INFO - 2023-08-15 13:39:58 --> Output Class Initialized
INFO - 2023-08-15 13:39:58 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:58 --> Input Class Initialized
INFO - 2023-08-15 13:39:58 --> Language Class Initialized
ERROR - 2023-08-15 13:39:58 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:39:58 --> Security Class Initialized
DEBUG - 2023-08-15 13:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:39:58 --> Input Class Initialized
INFO - 2023-08-15 13:39:58 --> Language Class Initialized
ERROR - 2023-08-15 13:39:59 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:40:44 --> Config Class Initialized
INFO - 2023-08-15 13:40:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:40:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:40:44 --> Utf8 Class Initialized
INFO - 2023-08-15 13:40:44 --> URI Class Initialized
INFO - 2023-08-15 13:40:44 --> Router Class Initialized
INFO - 2023-08-15 13:40:44 --> Output Class Initialized
INFO - 2023-08-15 13:40:44 --> Security Class Initialized
DEBUG - 2023-08-15 13:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:40:44 --> Input Class Initialized
INFO - 2023-08-15 13:40:44 --> Language Class Initialized
INFO - 2023-08-15 13:40:44 --> Loader Class Initialized
INFO - 2023-08-15 13:40:44 --> Helper loaded: url_helper
INFO - 2023-08-15 13:40:44 --> Helper loaded: file_helper
INFO - 2023-08-15 13:40:44 --> Database Driver Class Initialized
INFO - 2023-08-15 13:40:44 --> Email Class Initialized
DEBUG - 2023-08-15 13:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:40:44 --> Controller Class Initialized
INFO - 2023-08-15 13:40:44 --> Model "Training_model" initialized
INFO - 2023-08-15 13:40:44 --> Helper loaded: form_helper
INFO - 2023-08-15 13:40:44 --> Form Validation Class Initialized
INFO - 2023-08-15 13:40:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-15 13:40:44 --> Final output sent to browser
DEBUG - 2023-08-15 13:40:44 --> Total execution time: 0.0486
INFO - 2023-08-15 13:40:49 --> Config Class Initialized
INFO - 2023-08-15 13:40:49 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:40:49 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:40:49 --> Utf8 Class Initialized
INFO - 2023-08-15 13:40:49 --> URI Class Initialized
INFO - 2023-08-15 13:40:49 --> Router Class Initialized
INFO - 2023-08-15 13:40:49 --> Output Class Initialized
INFO - 2023-08-15 13:40:49 --> Security Class Initialized
DEBUG - 2023-08-15 13:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:40:49 --> Input Class Initialized
INFO - 2023-08-15 13:40:49 --> Language Class Initialized
INFO - 2023-08-15 13:40:49 --> Loader Class Initialized
INFO - 2023-08-15 13:40:49 --> Helper loaded: url_helper
INFO - 2023-08-15 13:40:49 --> Helper loaded: file_helper
INFO - 2023-08-15 13:40:49 --> Database Driver Class Initialized
INFO - 2023-08-15 13:40:49 --> Email Class Initialized
DEBUG - 2023-08-15 13:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:40:49 --> Controller Class Initialized
INFO - 2023-08-15 13:40:49 --> Model "Training_model" initialized
INFO - 2023-08-15 13:40:49 --> Helper loaded: form_helper
INFO - 2023-08-15 13:40:49 --> Form Validation Class Initialized
INFO - 2023-08-15 13:40:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-15 13:40:49 --> Final output sent to browser
DEBUG - 2023-08-15 13:40:49 --> Total execution time: 0.0647
INFO - 2023-08-15 13:40:50 --> Config Class Initialized
INFO - 2023-08-15 13:40:50 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:40:50 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:40:50 --> Utf8 Class Initialized
INFO - 2023-08-15 13:40:50 --> URI Class Initialized
INFO - 2023-08-15 13:40:50 --> Router Class Initialized
INFO - 2023-08-15 13:40:50 --> Output Class Initialized
INFO - 2023-08-15 13:40:50 --> Security Class Initialized
DEBUG - 2023-08-15 13:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:40:50 --> Input Class Initialized
INFO - 2023-08-15 13:40:50 --> Language Class Initialized
INFO - 2023-08-15 13:40:50 --> Loader Class Initialized
INFO - 2023-08-15 13:40:50 --> Helper loaded: url_helper
INFO - 2023-08-15 13:40:50 --> Helper loaded: file_helper
INFO - 2023-08-15 13:40:50 --> Database Driver Class Initialized
INFO - 2023-08-15 13:40:50 --> Email Class Initialized
DEBUG - 2023-08-15 13:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:40:50 --> Controller Class Initialized
INFO - 2023-08-15 13:40:50 --> Model "Training_model" initialized
INFO - 2023-08-15 13:40:50 --> Helper loaded: form_helper
INFO - 2023-08-15 13:40:50 --> Form Validation Class Initialized
INFO - 2023-08-15 13:40:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-15 13:40:50 --> Final output sent to browser
DEBUG - 2023-08-15 13:40:50 --> Total execution time: 0.0418
INFO - 2023-08-15 13:41:15 --> Config Class Initialized
INFO - 2023-08-15 13:41:15 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:41:15 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:41:15 --> Utf8 Class Initialized
INFO - 2023-08-15 13:41:15 --> URI Class Initialized
INFO - 2023-08-15 13:41:15 --> Router Class Initialized
INFO - 2023-08-15 13:41:15 --> Output Class Initialized
INFO - 2023-08-15 13:41:15 --> Security Class Initialized
DEBUG - 2023-08-15 13:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:41:15 --> Input Class Initialized
INFO - 2023-08-15 13:41:15 --> Language Class Initialized
INFO - 2023-08-15 13:41:15 --> Loader Class Initialized
INFO - 2023-08-15 13:41:15 --> Helper loaded: url_helper
INFO - 2023-08-15 13:41:15 --> Helper loaded: file_helper
INFO - 2023-08-15 13:41:16 --> Database Driver Class Initialized
INFO - 2023-08-15 13:41:16 --> Email Class Initialized
DEBUG - 2023-08-15 13:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:41:16 --> Controller Class Initialized
INFO - 2023-08-15 13:41:16 --> Model "Home_model" initialized
INFO - 2023-08-15 13:41:16 --> Helper loaded: form_helper
INFO - 2023-08-15 13:41:16 --> Form Validation Class Initialized
INFO - 2023-08-15 13:41:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:41:16 --> Final output sent to browser
DEBUG - 2023-08-15 13:41:16 --> Total execution time: 0.3989
INFO - 2023-08-15 13:41:16 --> Config Class Initialized
INFO - 2023-08-15 13:41:16 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:41:16 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:41:16 --> Utf8 Class Initialized
INFO - 2023-08-15 13:41:16 --> URI Class Initialized
INFO - 2023-08-15 13:41:16 --> Router Class Initialized
INFO - 2023-08-15 13:41:16 --> Output Class Initialized
INFO - 2023-08-15 13:41:16 --> Security Class Initialized
DEBUG - 2023-08-15 13:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:41:16 --> Input Class Initialized
INFO - 2023-08-15 13:41:16 --> Language Class Initialized
ERROR - 2023-08-15 13:41:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:41:16 --> Config Class Initialized
INFO - 2023-08-15 13:41:16 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:41:16 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:41:16 --> Utf8 Class Initialized
INFO - 2023-08-15 13:41:16 --> URI Class Initialized
INFO - 2023-08-15 13:41:16 --> Router Class Initialized
INFO - 2023-08-15 13:41:16 --> Output Class Initialized
INFO - 2023-08-15 13:41:16 --> Security Class Initialized
DEBUG - 2023-08-15 13:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:41:16 --> Input Class Initialized
INFO - 2023-08-15 13:41:16 --> Language Class Initialized
ERROR - 2023-08-15 13:41:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:41:16 --> Config Class Initialized
INFO - 2023-08-15 13:41:16 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:41:16 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:41:16 --> Utf8 Class Initialized
INFO - 2023-08-15 13:41:16 --> URI Class Initialized
INFO - 2023-08-15 13:41:16 --> Router Class Initialized
INFO - 2023-08-15 13:41:16 --> Output Class Initialized
INFO - 2023-08-15 13:41:16 --> Security Class Initialized
DEBUG - 2023-08-15 13:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:41:16 --> Input Class Initialized
INFO - 2023-08-15 13:41:16 --> Language Class Initialized
ERROR - 2023-08-15 13:41:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:41:17 --> Config Class Initialized
INFO - 2023-08-15 13:41:17 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:41:17 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:41:17 --> Utf8 Class Initialized
INFO - 2023-08-15 13:41:17 --> URI Class Initialized
INFO - 2023-08-15 13:41:17 --> Router Class Initialized
INFO - 2023-08-15 13:41:17 --> Output Class Initialized
INFO - 2023-08-15 13:41:17 --> Security Class Initialized
DEBUG - 2023-08-15 13:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:41:17 --> Input Class Initialized
INFO - 2023-08-15 13:41:17 --> Config Class Initialized
INFO - 2023-08-15 13:41:17 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:41:17 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:41:17 --> Utf8 Class Initialized
INFO - 2023-08-15 13:41:17 --> URI Class Initialized
INFO - 2023-08-15 13:41:17 --> Router Class Initialized
INFO - 2023-08-15 13:41:17 --> Output Class Initialized
INFO - 2023-08-15 13:41:17 --> Security Class Initialized
DEBUG - 2023-08-15 13:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:41:17 --> Input Class Initialized
INFO - 2023-08-15 13:41:17 --> Language Class Initialized
ERROR - 2023-08-15 13:41:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:41:17 --> Language Class Initialized
ERROR - 2023-08-15 13:41:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:43:43 --> Config Class Initialized
INFO - 2023-08-15 13:43:43 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:43:43 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:43:43 --> Utf8 Class Initialized
INFO - 2023-08-15 13:43:43 --> URI Class Initialized
INFO - 2023-08-15 13:43:43 --> Router Class Initialized
INFO - 2023-08-15 13:43:43 --> Output Class Initialized
INFO - 2023-08-15 13:43:43 --> Security Class Initialized
DEBUG - 2023-08-15 13:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:43:43 --> Input Class Initialized
INFO - 2023-08-15 13:43:43 --> Language Class Initialized
INFO - 2023-08-15 13:43:43 --> Loader Class Initialized
INFO - 2023-08-15 13:43:43 --> Helper loaded: url_helper
INFO - 2023-08-15 13:43:43 --> Helper loaded: file_helper
INFO - 2023-08-15 13:43:43 --> Database Driver Class Initialized
INFO - 2023-08-15 13:43:43 --> Email Class Initialized
DEBUG - 2023-08-15 13:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:43:43 --> Controller Class Initialized
INFO - 2023-08-15 13:43:43 --> Model "Home_model" initialized
INFO - 2023-08-15 13:43:43 --> Helper loaded: form_helper
INFO - 2023-08-15 13:43:43 --> Form Validation Class Initialized
INFO - 2023-08-15 13:43:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-15 13:43:43 --> Final output sent to browser
DEBUG - 2023-08-15 13:43:43 --> Total execution time: 0.0435
INFO - 2023-08-15 13:43:44 --> Config Class Initialized
INFO - 2023-08-15 13:43:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:43:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:43:44 --> Utf8 Class Initialized
INFO - 2023-08-15 13:43:44 --> URI Class Initialized
INFO - 2023-08-15 13:43:44 --> Router Class Initialized
INFO - 2023-08-15 13:43:44 --> Output Class Initialized
INFO - 2023-08-15 13:43:44 --> Security Class Initialized
DEBUG - 2023-08-15 13:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:43:44 --> Input Class Initialized
INFO - 2023-08-15 13:43:44 --> Language Class Initialized
ERROR - 2023-08-15 13:43:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:43:44 --> Config Class Initialized
INFO - 2023-08-15 13:43:44 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:43:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:43:44 --> Utf8 Class Initialized
INFO - 2023-08-15 13:43:44 --> URI Class Initialized
INFO - 2023-08-15 13:43:44 --> Router Class Initialized
INFO - 2023-08-15 13:43:44 --> Output Class Initialized
INFO - 2023-08-15 13:43:44 --> Security Class Initialized
DEBUG - 2023-08-15 13:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:43:44 --> Input Class Initialized
INFO - 2023-08-15 13:43:44 --> Language Class Initialized
ERROR - 2023-08-15 13:43:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:44:31 --> Config Class Initialized
INFO - 2023-08-15 13:44:31 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:44:31 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:44:31 --> Utf8 Class Initialized
INFO - 2023-08-15 13:44:31 --> URI Class Initialized
INFO - 2023-08-15 13:44:31 --> Router Class Initialized
INFO - 2023-08-15 13:44:31 --> Output Class Initialized
INFO - 2023-08-15 13:44:31 --> Security Class Initialized
DEBUG - 2023-08-15 13:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:44:31 --> Input Class Initialized
INFO - 2023-08-15 13:44:31 --> Language Class Initialized
INFO - 2023-08-15 13:44:31 --> Loader Class Initialized
INFO - 2023-08-15 13:44:31 --> Helper loaded: url_helper
INFO - 2023-08-15 13:44:31 --> Helper loaded: file_helper
INFO - 2023-08-15 13:44:31 --> Database Driver Class Initialized
INFO - 2023-08-15 13:44:31 --> Email Class Initialized
DEBUG - 2023-08-15 13:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:44:31 --> Controller Class Initialized
INFO - 2023-08-15 13:44:31 --> Model "Home_model" initialized
INFO - 2023-08-15 13:44:31 --> Helper loaded: form_helper
INFO - 2023-08-15 13:44:31 --> Form Validation Class Initialized
INFO - 2023-08-15 13:44:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-15 13:44:31 --> Final output sent to browser
DEBUG - 2023-08-15 13:44:32 --> Total execution time: 0.5758
INFO - 2023-08-15 13:44:32 --> Config Class Initialized
INFO - 2023-08-15 13:44:32 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:44:32 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:44:32 --> Utf8 Class Initialized
INFO - 2023-08-15 13:44:32 --> URI Class Initialized
INFO - 2023-08-15 13:44:32 --> Router Class Initialized
INFO - 2023-08-15 13:44:32 --> Output Class Initialized
INFO - 2023-08-15 13:44:32 --> Security Class Initialized
DEBUG - 2023-08-15 13:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:44:32 --> Input Class Initialized
INFO - 2023-08-15 13:44:32 --> Language Class Initialized
ERROR - 2023-08-15 13:44:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:44:32 --> Config Class Initialized
INFO - 2023-08-15 13:44:32 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:44:32 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:44:32 --> Utf8 Class Initialized
INFO - 2023-08-15 13:44:32 --> URI Class Initialized
INFO - 2023-08-15 13:44:32 --> Router Class Initialized
INFO - 2023-08-15 13:44:32 --> Output Class Initialized
INFO - 2023-08-15 13:44:32 --> Security Class Initialized
DEBUG - 2023-08-15 13:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:44:33 --> Input Class Initialized
INFO - 2023-08-15 13:44:33 --> Language Class Initialized
ERROR - 2023-08-15 13:44:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:44:33 --> Config Class Initialized
INFO - 2023-08-15 13:44:33 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:44:33 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:44:33 --> Utf8 Class Initialized
INFO - 2023-08-15 13:44:33 --> URI Class Initialized
INFO - 2023-08-15 13:44:33 --> Router Class Initialized
INFO - 2023-08-15 13:44:33 --> Output Class Initialized
INFO - 2023-08-15 13:44:33 --> Security Class Initialized
DEBUG - 2023-08-15 13:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:44:33 --> Input Class Initialized
INFO - 2023-08-15 13:44:33 --> Language Class Initialized
ERROR - 2023-08-15 13:44:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 13:44:33 --> Config Class Initialized
INFO - 2023-08-15 13:44:33 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:44:33 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:44:33 --> Utf8 Class Initialized
INFO - 2023-08-15 13:44:33 --> URI Class Initialized
INFO - 2023-08-15 13:44:33 --> Router Class Initialized
INFO - 2023-08-15 13:44:33 --> Output Class Initialized
INFO - 2023-08-15 13:44:33 --> Security Class Initialized
DEBUG - 2023-08-15 13:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:44:33 --> Input Class Initialized
INFO - 2023-08-15 13:44:33 --> Language Class Initialized
ERROR - 2023-08-15 13:44:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-15 13:44:53 --> Config Class Initialized
INFO - 2023-08-15 13:44:53 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:44:53 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:44:53 --> Utf8 Class Initialized
INFO - 2023-08-15 13:44:53 --> URI Class Initialized
INFO - 2023-08-15 13:44:53 --> Router Class Initialized
INFO - 2023-08-15 13:44:53 --> Output Class Initialized
INFO - 2023-08-15 13:44:53 --> Security Class Initialized
DEBUG - 2023-08-15 13:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:44:53 --> Input Class Initialized
INFO - 2023-08-15 13:44:53 --> Language Class Initialized
INFO - 2023-08-15 13:44:53 --> Loader Class Initialized
INFO - 2023-08-15 13:44:53 --> Helper loaded: url_helper
INFO - 2023-08-15 13:44:53 --> Helper loaded: file_helper
INFO - 2023-08-15 13:44:53 --> Database Driver Class Initialized
INFO - 2023-08-15 13:44:53 --> Email Class Initialized
DEBUG - 2023-08-15 13:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:44:53 --> Controller Class Initialized
INFO - 2023-08-15 13:44:53 --> Model "Home_model" initialized
INFO - 2023-08-15 13:44:53 --> Helper loaded: form_helper
INFO - 2023-08-15 13:44:53 --> Form Validation Class Initialized
INFO - 2023-08-15 13:44:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-15 13:44:54 --> Final output sent to browser
DEBUG - 2023-08-15 13:44:54 --> Total execution time: 0.7590
INFO - 2023-08-15 13:48:42 --> Config Class Initialized
INFO - 2023-08-15 13:48:42 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:48:42 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:48:42 --> Utf8 Class Initialized
INFO - 2023-08-15 13:48:42 --> URI Class Initialized
INFO - 2023-08-15 13:48:42 --> Router Class Initialized
INFO - 2023-08-15 13:48:42 --> Output Class Initialized
INFO - 2023-08-15 13:48:42 --> Security Class Initialized
DEBUG - 2023-08-15 13:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:48:42 --> Input Class Initialized
INFO - 2023-08-15 13:48:42 --> Language Class Initialized
INFO - 2023-08-15 13:48:42 --> Loader Class Initialized
INFO - 2023-08-15 13:48:42 --> Helper loaded: url_helper
INFO - 2023-08-15 13:48:42 --> Helper loaded: file_helper
INFO - 2023-08-15 13:48:42 --> Database Driver Class Initialized
INFO - 2023-08-15 13:48:42 --> Email Class Initialized
DEBUG - 2023-08-15 13:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:48:42 --> Controller Class Initialized
INFO - 2023-08-15 13:48:42 --> Model "Training_model" initialized
INFO - 2023-08-15 13:48:42 --> Helper loaded: form_helper
INFO - 2023-08-15 13:48:42 --> Form Validation Class Initialized
INFO - 2023-08-15 13:48:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-15 13:48:43 --> Config Class Initialized
INFO - 2023-08-15 13:48:43 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:48:43 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:48:43 --> Utf8 Class Initialized
INFO - 2023-08-15 13:48:43 --> URI Class Initialized
INFO - 2023-08-15 13:48:43 --> Router Class Initialized
INFO - 2023-08-15 13:48:43 --> Output Class Initialized
INFO - 2023-08-15 13:48:43 --> Security Class Initialized
DEBUG - 2023-08-15 13:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:48:43 --> Input Class Initialized
INFO - 2023-08-15 13:48:43 --> Language Class Initialized
INFO - 2023-08-15 13:48:43 --> Loader Class Initialized
INFO - 2023-08-15 13:48:43 --> Helper loaded: url_helper
INFO - 2023-08-15 13:48:43 --> Helper loaded: file_helper
INFO - 2023-08-15 13:48:43 --> Database Driver Class Initialized
INFO - 2023-08-15 13:48:43 --> Email Class Initialized
DEBUG - 2023-08-15 13:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:48:43 --> Controller Class Initialized
INFO - 2023-08-15 13:48:43 --> Model "Training_model" initialized
INFO - 2023-08-15 13:48:43 --> Helper loaded: form_helper
INFO - 2023-08-15 13:48:43 --> Form Validation Class Initialized
INFO - 2023-08-15 13:48:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-15 13:48:43 --> Final output sent to browser
DEBUG - 2023-08-15 13:48:43 --> Total execution time: 0.2874
INFO - 2023-08-15 13:49:36 --> Config Class Initialized
INFO - 2023-08-15 13:49:36 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:49:36 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:49:36 --> Utf8 Class Initialized
INFO - 2023-08-15 13:49:36 --> URI Class Initialized
INFO - 2023-08-15 13:49:36 --> Router Class Initialized
INFO - 2023-08-15 13:49:36 --> Output Class Initialized
INFO - 2023-08-15 13:49:36 --> Security Class Initialized
DEBUG - 2023-08-15 13:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:49:36 --> Input Class Initialized
INFO - 2023-08-15 13:49:36 --> Language Class Initialized
INFO - 2023-08-15 13:49:36 --> Loader Class Initialized
INFO - 2023-08-15 13:49:36 --> Helper loaded: url_helper
INFO - 2023-08-15 13:49:36 --> Helper loaded: file_helper
INFO - 2023-08-15 13:49:36 --> Database Driver Class Initialized
INFO - 2023-08-15 13:49:36 --> Email Class Initialized
DEBUG - 2023-08-15 13:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:49:36 --> Controller Class Initialized
INFO - 2023-08-15 13:49:36 --> Model "Training_model" initialized
INFO - 2023-08-15 13:49:36 --> Helper loaded: form_helper
INFO - 2023-08-15 13:49:36 --> Form Validation Class Initialized
INFO - 2023-08-15 13:49:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-15 13:49:36 --> Final output sent to browser
DEBUG - 2023-08-15 13:49:36 --> Total execution time: 0.3078
INFO - 2023-08-15 13:49:43 --> Config Class Initialized
INFO - 2023-08-15 13:49:43 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:49:43 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:49:43 --> Utf8 Class Initialized
INFO - 2023-08-15 13:49:43 --> URI Class Initialized
INFO - 2023-08-15 13:49:43 --> Router Class Initialized
INFO - 2023-08-15 13:49:43 --> Output Class Initialized
INFO - 2023-08-15 13:49:43 --> Security Class Initialized
DEBUG - 2023-08-15 13:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:49:43 --> Input Class Initialized
INFO - 2023-08-15 13:49:43 --> Language Class Initialized
INFO - 2023-08-15 13:49:43 --> Loader Class Initialized
INFO - 2023-08-15 13:49:43 --> Helper loaded: url_helper
INFO - 2023-08-15 13:49:43 --> Helper loaded: file_helper
INFO - 2023-08-15 13:49:43 --> Database Driver Class Initialized
INFO - 2023-08-15 13:49:43 --> Email Class Initialized
DEBUG - 2023-08-15 13:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:49:43 --> Controller Class Initialized
INFO - 2023-08-15 13:49:43 --> Model "Training_model" initialized
INFO - 2023-08-15 13:49:43 --> Helper loaded: form_helper
INFO - 2023-08-15 13:49:43 --> Form Validation Class Initialized
INFO - 2023-08-15 13:49:43 --> Config Class Initialized
INFO - 2023-08-15 13:49:43 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:49:44 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:49:44 --> Utf8 Class Initialized
INFO - 2023-08-15 13:49:44 --> URI Class Initialized
INFO - 2023-08-15 13:49:44 --> Router Class Initialized
INFO - 2023-08-15 13:49:44 --> Output Class Initialized
INFO - 2023-08-15 13:49:44 --> Security Class Initialized
DEBUG - 2023-08-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:49:44 --> Input Class Initialized
INFO - 2023-08-15 13:49:44 --> Language Class Initialized
INFO - 2023-08-15 13:49:44 --> Loader Class Initialized
INFO - 2023-08-15 13:49:44 --> Helper loaded: url_helper
INFO - 2023-08-15 13:49:44 --> Helper loaded: file_helper
INFO - 2023-08-15 13:49:44 --> Database Driver Class Initialized
INFO - 2023-08-15 13:49:44 --> Email Class Initialized
DEBUG - 2023-08-15 13:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:49:44 --> Controller Class Initialized
INFO - 2023-08-15 13:49:44 --> Model "Training_model" initialized
INFO - 2023-08-15 13:49:44 --> Helper loaded: form_helper
INFO - 2023-08-15 13:49:44 --> Form Validation Class Initialized
INFO - 2023-08-15 13:49:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-15 13:49:44 --> Final output sent to browser
DEBUG - 2023-08-15 13:49:44 --> Total execution time: 0.0712
INFO - 2023-08-15 13:49:46 --> Config Class Initialized
INFO - 2023-08-15 13:49:46 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:49:46 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:49:46 --> Utf8 Class Initialized
INFO - 2023-08-15 13:49:46 --> URI Class Initialized
INFO - 2023-08-15 13:49:46 --> Router Class Initialized
INFO - 2023-08-15 13:49:46 --> Output Class Initialized
INFO - 2023-08-15 13:49:46 --> Security Class Initialized
DEBUG - 2023-08-15 13:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:49:46 --> Input Class Initialized
INFO - 2023-08-15 13:49:46 --> Language Class Initialized
INFO - 2023-08-15 13:49:46 --> Loader Class Initialized
INFO - 2023-08-15 13:49:46 --> Helper loaded: url_helper
INFO - 2023-08-15 13:49:46 --> Helper loaded: file_helper
INFO - 2023-08-15 13:49:46 --> Database Driver Class Initialized
INFO - 2023-08-15 13:49:46 --> Email Class Initialized
DEBUG - 2023-08-15 13:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:49:46 --> Controller Class Initialized
INFO - 2023-08-15 13:49:46 --> Model "Training_model" initialized
INFO - 2023-08-15 13:49:46 --> Helper loaded: form_helper
INFO - 2023-08-15 13:49:46 --> Form Validation Class Initialized
INFO - 2023-08-15 13:49:46 --> Config Class Initialized
INFO - 2023-08-15 13:49:46 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:49:46 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:49:46 --> Utf8 Class Initialized
INFO - 2023-08-15 13:49:46 --> URI Class Initialized
INFO - 2023-08-15 13:49:46 --> Router Class Initialized
INFO - 2023-08-15 13:49:46 --> Output Class Initialized
INFO - 2023-08-15 13:49:46 --> Security Class Initialized
DEBUG - 2023-08-15 13:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:49:46 --> Input Class Initialized
INFO - 2023-08-15 13:49:46 --> Language Class Initialized
INFO - 2023-08-15 13:49:46 --> Loader Class Initialized
INFO - 2023-08-15 13:49:46 --> Helper loaded: url_helper
INFO - 2023-08-15 13:49:46 --> Helper loaded: file_helper
INFO - 2023-08-15 13:49:46 --> Database Driver Class Initialized
INFO - 2023-08-15 13:49:46 --> Email Class Initialized
DEBUG - 2023-08-15 13:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:49:46 --> Controller Class Initialized
INFO - 2023-08-15 13:49:46 --> Model "Training_model" initialized
INFO - 2023-08-15 13:49:46 --> Helper loaded: form_helper
INFO - 2023-08-15 13:49:46 --> Form Validation Class Initialized
INFO - 2023-08-15 13:49:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-15 13:49:46 --> Final output sent to browser
DEBUG - 2023-08-15 13:49:46 --> Total execution time: 0.0621
INFO - 2023-08-15 13:50:09 --> Config Class Initialized
INFO - 2023-08-15 13:50:09 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:50:09 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:50:09 --> Utf8 Class Initialized
INFO - 2023-08-15 13:50:09 --> URI Class Initialized
INFO - 2023-08-15 13:50:09 --> Router Class Initialized
INFO - 2023-08-15 13:50:09 --> Output Class Initialized
INFO - 2023-08-15 13:50:09 --> Security Class Initialized
DEBUG - 2023-08-15 13:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:50:09 --> Input Class Initialized
INFO - 2023-08-15 13:50:09 --> Language Class Initialized
INFO - 2023-08-15 13:50:09 --> Loader Class Initialized
INFO - 2023-08-15 13:50:09 --> Helper loaded: url_helper
INFO - 2023-08-15 13:50:09 --> Helper loaded: file_helper
INFO - 2023-08-15 13:50:09 --> Database Driver Class Initialized
INFO - 2023-08-15 13:50:09 --> Email Class Initialized
DEBUG - 2023-08-15 13:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:50:09 --> Controller Class Initialized
INFO - 2023-08-15 13:50:09 --> Model "Training_model" initialized
INFO - 2023-08-15 13:50:09 --> Helper loaded: form_helper
INFO - 2023-08-15 13:50:09 --> Form Validation Class Initialized
INFO - 2023-08-15 13:50:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-15 13:50:09 --> Final output sent to browser
DEBUG - 2023-08-15 13:50:09 --> Total execution time: 0.0566
INFO - 2023-08-15 13:50:09 --> Config Class Initialized
INFO - 2023-08-15 13:50:09 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:50:09 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:50:09 --> Utf8 Class Initialized
INFO - 2023-08-15 13:50:09 --> URI Class Initialized
INFO - 2023-08-15 13:50:09 --> Router Class Initialized
INFO - 2023-08-15 13:50:09 --> Output Class Initialized
INFO - 2023-08-15 13:50:09 --> Security Class Initialized
DEBUG - 2023-08-15 13:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:50:09 --> Input Class Initialized
INFO - 2023-08-15 13:50:09 --> Language Class Initialized
INFO - 2023-08-15 13:50:09 --> Loader Class Initialized
INFO - 2023-08-15 13:50:10 --> Helper loaded: url_helper
INFO - 2023-08-15 13:50:10 --> Helper loaded: file_helper
INFO - 2023-08-15 13:50:10 --> Database Driver Class Initialized
INFO - 2023-08-15 13:50:10 --> Email Class Initialized
DEBUG - 2023-08-15 13:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:50:10 --> Controller Class Initialized
INFO - 2023-08-15 13:50:10 --> Model "Training_model" initialized
INFO - 2023-08-15 13:50:10 --> Helper loaded: form_helper
INFO - 2023-08-15 13:50:10 --> Form Validation Class Initialized
INFO - 2023-08-15 13:50:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-15 13:50:10 --> Final output sent to browser
DEBUG - 2023-08-15 13:50:10 --> Total execution time: 0.1565
INFO - 2023-08-15 13:51:03 --> Config Class Initialized
INFO - 2023-08-15 13:51:03 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:51:03 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:51:03 --> Utf8 Class Initialized
INFO - 2023-08-15 13:51:03 --> URI Class Initialized
INFO - 2023-08-15 13:51:03 --> Router Class Initialized
INFO - 2023-08-15 13:51:03 --> Output Class Initialized
INFO - 2023-08-15 13:51:03 --> Security Class Initialized
DEBUG - 2023-08-15 13:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:51:03 --> Input Class Initialized
INFO - 2023-08-15 13:51:03 --> Language Class Initialized
INFO - 2023-08-15 13:51:03 --> Loader Class Initialized
INFO - 2023-08-15 13:51:03 --> Helper loaded: url_helper
INFO - 2023-08-15 13:51:03 --> Helper loaded: file_helper
INFO - 2023-08-15 13:51:03 --> Database Driver Class Initialized
INFO - 2023-08-15 13:51:03 --> Email Class Initialized
DEBUG - 2023-08-15 13:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:51:03 --> Controller Class Initialized
INFO - 2023-08-15 13:51:03 --> Model "Training_model" initialized
INFO - 2023-08-15 13:51:03 --> Helper loaded: form_helper
INFO - 2023-08-15 13:51:03 --> Form Validation Class Initialized
INFO - 2023-08-15 13:51:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-15 13:51:03 --> Config Class Initialized
INFO - 2023-08-15 13:51:03 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:51:03 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:51:03 --> Utf8 Class Initialized
INFO - 2023-08-15 13:51:03 --> URI Class Initialized
INFO - 2023-08-15 13:51:03 --> Router Class Initialized
INFO - 2023-08-15 13:51:03 --> Output Class Initialized
INFO - 2023-08-15 13:51:03 --> Security Class Initialized
DEBUG - 2023-08-15 13:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:51:03 --> Input Class Initialized
INFO - 2023-08-15 13:51:03 --> Language Class Initialized
INFO - 2023-08-15 13:51:03 --> Loader Class Initialized
INFO - 2023-08-15 13:51:03 --> Helper loaded: url_helper
INFO - 2023-08-15 13:51:03 --> Helper loaded: file_helper
INFO - 2023-08-15 13:51:03 --> Database Driver Class Initialized
INFO - 2023-08-15 13:51:03 --> Email Class Initialized
DEBUG - 2023-08-15 13:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:51:03 --> Controller Class Initialized
INFO - 2023-08-15 13:51:03 --> Model "Training_model" initialized
INFO - 2023-08-15 13:51:03 --> Helper loaded: form_helper
INFO - 2023-08-15 13:51:03 --> Form Validation Class Initialized
INFO - 2023-08-15 13:51:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-15 13:51:03 --> Final output sent to browser
DEBUG - 2023-08-15 13:51:03 --> Total execution time: 0.1838
INFO - 2023-08-15 13:51:28 --> Config Class Initialized
INFO - 2023-08-15 13:51:28 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:51:28 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:51:28 --> Utf8 Class Initialized
INFO - 2023-08-15 13:51:28 --> URI Class Initialized
INFO - 2023-08-15 13:51:28 --> Router Class Initialized
INFO - 2023-08-15 13:51:28 --> Output Class Initialized
INFO - 2023-08-15 13:51:28 --> Security Class Initialized
DEBUG - 2023-08-15 13:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:51:28 --> Input Class Initialized
INFO - 2023-08-15 13:51:28 --> Language Class Initialized
INFO - 2023-08-15 13:51:28 --> Loader Class Initialized
INFO - 2023-08-15 13:51:28 --> Helper loaded: url_helper
INFO - 2023-08-15 13:51:28 --> Helper loaded: file_helper
INFO - 2023-08-15 13:51:28 --> Database Driver Class Initialized
INFO - 2023-08-15 13:51:28 --> Email Class Initialized
DEBUG - 2023-08-15 13:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:51:28 --> Controller Class Initialized
INFO - 2023-08-15 13:51:28 --> Model "Training_model" initialized
INFO - 2023-08-15 13:51:28 --> Helper loaded: form_helper
INFO - 2023-08-15 13:51:28 --> Form Validation Class Initialized
INFO - 2023-08-15 13:51:28 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-15 13:51:28 --> Final output sent to browser
DEBUG - 2023-08-15 13:51:28 --> Total execution time: 0.5079
INFO - 2023-08-15 13:51:29 --> Config Class Initialized
INFO - 2023-08-15 13:51:29 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:51:29 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:51:29 --> Utf8 Class Initialized
INFO - 2023-08-15 13:51:29 --> URI Class Initialized
INFO - 2023-08-15 13:51:29 --> Router Class Initialized
INFO - 2023-08-15 13:51:29 --> Output Class Initialized
INFO - 2023-08-15 13:51:29 --> Security Class Initialized
DEBUG - 2023-08-15 13:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:51:29 --> Input Class Initialized
INFO - 2023-08-15 13:51:29 --> Language Class Initialized
INFO - 2023-08-15 13:51:29 --> Loader Class Initialized
INFO - 2023-08-15 13:51:29 --> Helper loaded: url_helper
INFO - 2023-08-15 13:51:29 --> Helper loaded: file_helper
INFO - 2023-08-15 13:51:30 --> Database Driver Class Initialized
INFO - 2023-08-15 13:51:30 --> Email Class Initialized
DEBUG - 2023-08-15 13:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:51:30 --> Controller Class Initialized
INFO - 2023-08-15 13:51:30 --> Model "Training_model" initialized
INFO - 2023-08-15 13:51:30 --> Helper loaded: form_helper
INFO - 2023-08-15 13:51:30 --> Form Validation Class Initialized
INFO - 2023-08-15 13:51:30 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-15 13:51:30 --> Final output sent to browser
DEBUG - 2023-08-15 13:51:30 --> Total execution time: 0.8054
INFO - 2023-08-15 13:52:21 --> Config Class Initialized
INFO - 2023-08-15 13:52:21 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:52:21 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:52:21 --> Utf8 Class Initialized
INFO - 2023-08-15 13:52:22 --> URI Class Initialized
INFO - 2023-08-15 13:52:22 --> Router Class Initialized
INFO - 2023-08-15 13:52:22 --> Output Class Initialized
INFO - 2023-08-15 13:52:22 --> Security Class Initialized
DEBUG - 2023-08-15 13:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:52:22 --> Input Class Initialized
INFO - 2023-08-15 13:52:22 --> Language Class Initialized
INFO - 2023-08-15 13:52:22 --> Loader Class Initialized
INFO - 2023-08-15 13:52:22 --> Helper loaded: url_helper
INFO - 2023-08-15 13:52:22 --> Helper loaded: file_helper
INFO - 2023-08-15 13:52:22 --> Database Driver Class Initialized
INFO - 2023-08-15 13:52:22 --> Email Class Initialized
DEBUG - 2023-08-15 13:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:52:22 --> Controller Class Initialized
INFO - 2023-08-15 13:52:22 --> Model "Training_model" initialized
INFO - 2023-08-15 13:52:22 --> Helper loaded: form_helper
INFO - 2023-08-15 13:52:22 --> Form Validation Class Initialized
INFO - 2023-08-15 13:52:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-15 13:52:22 --> Config Class Initialized
INFO - 2023-08-15 13:52:22 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:52:22 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:52:22 --> Utf8 Class Initialized
INFO - 2023-08-15 13:52:22 --> URI Class Initialized
INFO - 2023-08-15 13:52:22 --> Router Class Initialized
INFO - 2023-08-15 13:52:22 --> Output Class Initialized
INFO - 2023-08-15 13:52:22 --> Security Class Initialized
DEBUG - 2023-08-15 13:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:52:22 --> Input Class Initialized
INFO - 2023-08-15 13:52:22 --> Language Class Initialized
INFO - 2023-08-15 13:52:22 --> Loader Class Initialized
INFO - 2023-08-15 13:52:22 --> Helper loaded: url_helper
INFO - 2023-08-15 13:52:22 --> Helper loaded: file_helper
INFO - 2023-08-15 13:52:22 --> Database Driver Class Initialized
INFO - 2023-08-15 13:52:22 --> Email Class Initialized
DEBUG - 2023-08-15 13:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:52:22 --> Controller Class Initialized
INFO - 2023-08-15 13:52:22 --> Model "Training_model" initialized
INFO - 2023-08-15 13:52:22 --> Helper loaded: form_helper
INFO - 2023-08-15 13:52:22 --> Form Validation Class Initialized
INFO - 2023-08-15 13:52:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-15 13:52:22 --> Final output sent to browser
DEBUG - 2023-08-15 13:52:22 --> Total execution time: 0.4010
INFO - 2023-08-15 13:58:56 --> Config Class Initialized
INFO - 2023-08-15 13:58:56 --> Hooks Class Initialized
DEBUG - 2023-08-15 13:58:56 --> UTF-8 Support Enabled
INFO - 2023-08-15 13:58:56 --> Utf8 Class Initialized
INFO - 2023-08-15 13:58:56 --> URI Class Initialized
INFO - 2023-08-15 13:58:56 --> Router Class Initialized
INFO - 2023-08-15 13:58:56 --> Output Class Initialized
INFO - 2023-08-15 13:58:56 --> Security Class Initialized
DEBUG - 2023-08-15 13:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 13:58:56 --> Input Class Initialized
INFO - 2023-08-15 13:58:56 --> Language Class Initialized
INFO - 2023-08-15 13:58:56 --> Loader Class Initialized
INFO - 2023-08-15 13:58:56 --> Helper loaded: url_helper
INFO - 2023-08-15 13:58:56 --> Helper loaded: file_helper
INFO - 2023-08-15 13:58:56 --> Database Driver Class Initialized
INFO - 2023-08-15 13:58:56 --> Email Class Initialized
DEBUG - 2023-08-15 13:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 13:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 13:58:56 --> Controller Class Initialized
INFO - 2023-08-15 13:58:56 --> Model "Home_model" initialized
INFO - 2023-08-15 13:58:56 --> Helper loaded: form_helper
INFO - 2023-08-15 13:58:56 --> Form Validation Class Initialized
INFO - 2023-08-15 14:04:11 --> Config Class Initialized
INFO - 2023-08-15 14:04:11 --> Hooks Class Initialized
DEBUG - 2023-08-15 14:04:11 --> UTF-8 Support Enabled
INFO - 2023-08-15 14:04:11 --> Utf8 Class Initialized
INFO - 2023-08-15 14:04:11 --> URI Class Initialized
INFO - 2023-08-15 14:04:11 --> Router Class Initialized
INFO - 2023-08-15 14:04:11 --> Output Class Initialized
INFO - 2023-08-15 14:04:11 --> Security Class Initialized
DEBUG - 2023-08-15 14:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 14:04:11 --> Input Class Initialized
INFO - 2023-08-15 14:04:11 --> Language Class Initialized
INFO - 2023-08-15 14:04:11 --> Loader Class Initialized
INFO - 2023-08-15 14:04:11 --> Helper loaded: url_helper
INFO - 2023-08-15 14:04:11 --> Helper loaded: file_helper
INFO - 2023-08-15 14:04:11 --> Database Driver Class Initialized
INFO - 2023-08-15 14:04:11 --> Email Class Initialized
DEBUG - 2023-08-15 14:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 14:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 14:04:11 --> Controller Class Initialized
INFO - 2023-08-15 14:04:11 --> Model "Home_model" initialized
INFO - 2023-08-15 14:04:11 --> Helper loaded: form_helper
INFO - 2023-08-15 14:04:11 --> Form Validation Class Initialized
ERROR - 2023-08-15 14:04:11 --> Severity: Warning --> Undefined variable $trainings C:\xampp\htdocs\dw\application\views\home\training.php 65
ERROR - 2023-08-15 14:04:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\training.php 65
INFO - 2023-08-15 14:04:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-15 14:04:11 --> Final output sent to browser
DEBUG - 2023-08-15 14:04:11 --> Total execution time: 0.3305
INFO - 2023-08-15 14:04:12 --> Config Class Initialized
INFO - 2023-08-15 14:04:12 --> Hooks Class Initialized
DEBUG - 2023-08-15 14:04:12 --> UTF-8 Support Enabled
INFO - 2023-08-15 14:04:12 --> Utf8 Class Initialized
INFO - 2023-08-15 14:04:12 --> URI Class Initialized
INFO - 2023-08-15 14:04:12 --> Router Class Initialized
INFO - 2023-08-15 14:04:12 --> Output Class Initialized
INFO - 2023-08-15 14:04:12 --> Security Class Initialized
DEBUG - 2023-08-15 14:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 14:04:12 --> Input Class Initialized
INFO - 2023-08-15 14:04:12 --> Language Class Initialized
ERROR - 2023-08-15 14:04:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 14:04:12 --> Config Class Initialized
INFO - 2023-08-15 14:04:12 --> Hooks Class Initialized
DEBUG - 2023-08-15 14:04:12 --> UTF-8 Support Enabled
INFO - 2023-08-15 14:04:12 --> Utf8 Class Initialized
INFO - 2023-08-15 14:04:12 --> URI Class Initialized
INFO - 2023-08-15 14:04:12 --> Router Class Initialized
INFO - 2023-08-15 14:04:12 --> Output Class Initialized
INFO - 2023-08-15 14:04:12 --> Security Class Initialized
DEBUG - 2023-08-15 14:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 14:04:12 --> Input Class Initialized
INFO - 2023-08-15 14:04:12 --> Language Class Initialized
ERROR - 2023-08-15 14:04:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 14:04:37 --> Config Class Initialized
INFO - 2023-08-15 14:04:38 --> Hooks Class Initialized
DEBUG - 2023-08-15 14:04:38 --> UTF-8 Support Enabled
INFO - 2023-08-15 14:04:38 --> Utf8 Class Initialized
INFO - 2023-08-15 14:04:38 --> URI Class Initialized
INFO - 2023-08-15 14:04:38 --> Router Class Initialized
INFO - 2023-08-15 14:04:38 --> Output Class Initialized
INFO - 2023-08-15 14:04:38 --> Security Class Initialized
DEBUG - 2023-08-15 14:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 14:04:38 --> Input Class Initialized
INFO - 2023-08-15 14:04:38 --> Language Class Initialized
INFO - 2023-08-15 14:04:38 --> Loader Class Initialized
INFO - 2023-08-15 14:04:38 --> Helper loaded: url_helper
INFO - 2023-08-15 14:04:38 --> Helper loaded: file_helper
INFO - 2023-08-15 14:04:38 --> Database Driver Class Initialized
INFO - 2023-08-15 14:04:38 --> Email Class Initialized
DEBUG - 2023-08-15 14:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-15 14:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-15 14:04:38 --> Controller Class Initialized
INFO - 2023-08-15 14:04:38 --> Model "Home_model" initialized
INFO - 2023-08-15 14:04:38 --> Helper loaded: form_helper
INFO - 2023-08-15 14:04:38 --> Form Validation Class Initialized
INFO - 2023-08-15 14:04:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-15 14:04:38 --> Final output sent to browser
DEBUG - 2023-08-15 14:04:38 --> Total execution time: 0.4156
INFO - 2023-08-15 14:04:39 --> Config Class Initialized
INFO - 2023-08-15 14:04:39 --> Hooks Class Initialized
DEBUG - 2023-08-15 14:04:39 --> UTF-8 Support Enabled
INFO - 2023-08-15 14:04:39 --> Utf8 Class Initialized
INFO - 2023-08-15 14:04:39 --> URI Class Initialized
INFO - 2023-08-15 14:04:39 --> Router Class Initialized
INFO - 2023-08-15 14:04:39 --> Output Class Initialized
INFO - 2023-08-15 14:04:39 --> Security Class Initialized
DEBUG - 2023-08-15 14:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 14:04:39 --> Input Class Initialized
INFO - 2023-08-15 14:04:39 --> Language Class Initialized
ERROR - 2023-08-15 14:04:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-15 14:04:39 --> Config Class Initialized
INFO - 2023-08-15 14:04:39 --> Hooks Class Initialized
DEBUG - 2023-08-15 14:04:39 --> UTF-8 Support Enabled
INFO - 2023-08-15 14:04:39 --> Utf8 Class Initialized
INFO - 2023-08-15 14:04:39 --> URI Class Initialized
INFO - 2023-08-15 14:04:39 --> Router Class Initialized
INFO - 2023-08-15 14:04:39 --> Output Class Initialized
INFO - 2023-08-15 14:04:39 --> Security Class Initialized
DEBUG - 2023-08-15 14:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-15 14:04:39 --> Input Class Initialized
INFO - 2023-08-15 14:04:39 --> Language Class Initialized
ERROR - 2023-08-15 14:04:39 --> 404 Page Not Found: Assets/images
