<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-31 07:12:06 --> Config Class Initialized
INFO - 2023-08-31 07:12:06 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:12:06 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:12:06 --> Utf8 Class Initialized
INFO - 2023-08-31 07:12:06 --> URI Class Initialized
DEBUG - 2023-08-31 07:12:06 --> No URI present. Default controller set.
INFO - 2023-08-31 07:12:06 --> Router Class Initialized
INFO - 2023-08-31 07:12:06 --> Output Class Initialized
INFO - 2023-08-31 07:12:06 --> Security Class Initialized
DEBUG - 2023-08-31 07:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:12:06 --> Input Class Initialized
INFO - 2023-08-31 07:12:06 --> Language Class Initialized
INFO - 2023-08-31 07:12:06 --> Loader Class Initialized
INFO - 2023-08-31 07:12:06 --> Helper loaded: url_helper
INFO - 2023-08-31 07:12:06 --> Helper loaded: file_helper
INFO - 2023-08-31 07:12:06 --> Database Driver Class Initialized
INFO - 2023-08-31 07:12:07 --> Email Class Initialized
DEBUG - 2023-08-31 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:12:07 --> Controller Class Initialized
INFO - 2023-08-31 07:12:07 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:12:07 --> Model "Home_model" initialized
INFO - 2023-08-31 07:12:07 --> Helper loaded: download_helper
INFO - 2023-08-31 07:12:07 --> Helper loaded: form_helper
INFO - 2023-08-31 07:12:07 --> Form Validation Class Initialized
INFO - 2023-08-31 07:12:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 07:12:07 --> Final output sent to browser
DEBUG - 2023-08-31 07:12:07 --> Total execution time: 0.9038
INFO - 2023-08-31 07:12:08 --> Config Class Initialized
INFO - 2023-08-31 07:12:08 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:12:08 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:12:08 --> Utf8 Class Initialized
INFO - 2023-08-31 07:12:08 --> URI Class Initialized
INFO - 2023-08-31 07:12:08 --> Router Class Initialized
INFO - 2023-08-31 07:12:08 --> Output Class Initialized
INFO - 2023-08-31 07:12:08 --> Security Class Initialized
DEBUG - 2023-08-31 07:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:12:08 --> Input Class Initialized
INFO - 2023-08-31 07:12:08 --> Language Class Initialized
ERROR - 2023-08-31 07:12:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:12:09 --> Config Class Initialized
INFO - 2023-08-31 07:12:09 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:12:09 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:12:09 --> Utf8 Class Initialized
INFO - 2023-08-31 07:12:09 --> URI Class Initialized
INFO - 2023-08-31 07:12:09 --> Router Class Initialized
INFO - 2023-08-31 07:12:09 --> Output Class Initialized
INFO - 2023-08-31 07:12:09 --> Security Class Initialized
DEBUG - 2023-08-31 07:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:12:09 --> Input Class Initialized
INFO - 2023-08-31 07:12:09 --> Language Class Initialized
ERROR - 2023-08-31 07:12:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:13:47 --> Config Class Initialized
INFO - 2023-08-31 07:13:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:13:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:13:47 --> Utf8 Class Initialized
INFO - 2023-08-31 07:13:47 --> URI Class Initialized
INFO - 2023-08-31 07:13:47 --> Router Class Initialized
INFO - 2023-08-31 07:13:47 --> Output Class Initialized
INFO - 2023-08-31 07:13:47 --> Security Class Initialized
DEBUG - 2023-08-31 07:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:13:47 --> Input Class Initialized
INFO - 2023-08-31 07:13:47 --> Language Class Initialized
INFO - 2023-08-31 07:13:47 --> Loader Class Initialized
INFO - 2023-08-31 07:13:47 --> Helper loaded: url_helper
INFO - 2023-08-31 07:13:47 --> Helper loaded: file_helper
INFO - 2023-08-31 07:13:47 --> Database Driver Class Initialized
INFO - 2023-08-31 07:13:47 --> Email Class Initialized
DEBUG - 2023-08-31 07:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:13:47 --> Controller Class Initialized
INFO - 2023-08-31 07:13:47 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:13:47 --> Model "Home_model" initialized
INFO - 2023-08-31 07:13:47 --> Helper loaded: download_helper
INFO - 2023-08-31 07:13:47 --> Helper loaded: form_helper
INFO - 2023-08-31 07:13:47 --> Form Validation Class Initialized
INFO - 2023-08-31 07:13:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-31 07:13:47 --> Final output sent to browser
DEBUG - 2023-08-31 07:13:47 --> Total execution time: 0.1204
INFO - 2023-08-31 07:13:48 --> Config Class Initialized
INFO - 2023-08-31 07:13:48 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:13:48 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:13:48 --> Utf8 Class Initialized
INFO - 2023-08-31 07:13:48 --> URI Class Initialized
INFO - 2023-08-31 07:13:48 --> Router Class Initialized
INFO - 2023-08-31 07:13:48 --> Output Class Initialized
INFO - 2023-08-31 07:13:48 --> Security Class Initialized
DEBUG - 2023-08-31 07:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:13:48 --> Input Class Initialized
INFO - 2023-08-31 07:13:48 --> Language Class Initialized
ERROR - 2023-08-31 07:13:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:13:48 --> Config Class Initialized
INFO - 2023-08-31 07:13:48 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:13:48 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:13:48 --> Utf8 Class Initialized
INFO - 2023-08-31 07:13:48 --> URI Class Initialized
INFO - 2023-08-31 07:13:48 --> Router Class Initialized
INFO - 2023-08-31 07:13:48 --> Output Class Initialized
INFO - 2023-08-31 07:13:48 --> Security Class Initialized
DEBUG - 2023-08-31 07:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:13:48 --> Input Class Initialized
INFO - 2023-08-31 07:13:48 --> Language Class Initialized
ERROR - 2023-08-31 07:13:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:13:56 --> Config Class Initialized
INFO - 2023-08-31 07:13:56 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:13:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:13:56 --> Utf8 Class Initialized
INFO - 2023-08-31 07:13:56 --> URI Class Initialized
INFO - 2023-08-31 07:13:56 --> Router Class Initialized
INFO - 2023-08-31 07:13:56 --> Output Class Initialized
INFO - 2023-08-31 07:13:56 --> Security Class Initialized
DEBUG - 2023-08-31 07:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:13:56 --> Input Class Initialized
INFO - 2023-08-31 07:13:56 --> Language Class Initialized
INFO - 2023-08-31 07:13:56 --> Loader Class Initialized
INFO - 2023-08-31 07:13:56 --> Helper loaded: url_helper
INFO - 2023-08-31 07:13:56 --> Helper loaded: file_helper
INFO - 2023-08-31 07:13:56 --> Database Driver Class Initialized
INFO - 2023-08-31 07:13:56 --> Email Class Initialized
DEBUG - 2023-08-31 07:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:13:56 --> Controller Class Initialized
INFO - 2023-08-31 07:13:56 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:13:57 --> Model "Home_model" initialized
INFO - 2023-08-31 07:13:57 --> Helper loaded: download_helper
INFO - 2023-08-31 07:13:57 --> Helper loaded: form_helper
INFO - 2023-08-31 07:13:57 --> Form Validation Class Initialized
INFO - 2023-08-31 07:13:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-08-31 07:13:57 --> Final output sent to browser
DEBUG - 2023-08-31 07:13:57 --> Total execution time: 0.1136
INFO - 2023-08-31 07:13:57 --> Config Class Initialized
INFO - 2023-08-31 07:13:57 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:13:57 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:13:57 --> Utf8 Class Initialized
INFO - 2023-08-31 07:13:57 --> URI Class Initialized
INFO - 2023-08-31 07:13:57 --> Router Class Initialized
INFO - 2023-08-31 07:13:57 --> Output Class Initialized
INFO - 2023-08-31 07:13:57 --> Security Class Initialized
DEBUG - 2023-08-31 07:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:13:57 --> Input Class Initialized
INFO - 2023-08-31 07:13:57 --> Language Class Initialized
ERROR - 2023-08-31 07:13:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:13:57 --> Config Class Initialized
INFO - 2023-08-31 07:13:57 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:13:57 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:13:57 --> Utf8 Class Initialized
INFO - 2023-08-31 07:13:57 --> URI Class Initialized
INFO - 2023-08-31 07:13:57 --> Router Class Initialized
INFO - 2023-08-31 07:13:57 --> Output Class Initialized
INFO - 2023-08-31 07:13:57 --> Security Class Initialized
DEBUG - 2023-08-31 07:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:13:57 --> Input Class Initialized
INFO - 2023-08-31 07:13:57 --> Language Class Initialized
ERROR - 2023-08-31 07:13:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:24:06 --> Config Class Initialized
INFO - 2023-08-31 07:24:06 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:24:06 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:24:06 --> Utf8 Class Initialized
INFO - 2023-08-31 07:24:06 --> URI Class Initialized
INFO - 2023-08-31 07:24:06 --> Router Class Initialized
INFO - 2023-08-31 07:24:06 --> Output Class Initialized
INFO - 2023-08-31 07:24:06 --> Security Class Initialized
DEBUG - 2023-08-31 07:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:24:06 --> Input Class Initialized
INFO - 2023-08-31 07:24:06 --> Language Class Initialized
INFO - 2023-08-31 07:24:06 --> Loader Class Initialized
INFO - 2023-08-31 07:24:06 --> Helper loaded: url_helper
INFO - 2023-08-31 07:24:06 --> Helper loaded: file_helper
INFO - 2023-08-31 07:24:06 --> Database Driver Class Initialized
INFO - 2023-08-31 07:24:06 --> Email Class Initialized
DEBUG - 2023-08-31 07:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:24:06 --> Controller Class Initialized
INFO - 2023-08-31 07:24:06 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:24:06 --> Model "Home_model" initialized
INFO - 2023-08-31 07:24:06 --> Helper loaded: download_helper
INFO - 2023-08-31 07:24:06 --> Helper loaded: form_helper
INFO - 2023-08-31 07:24:06 --> Form Validation Class Initialized
ERROR - 2023-08-31 07:24:06 --> Severity: error --> Exception: Call to undefined method Home_model::getActiveServiceNames() C:\xampp\htdocs\dw\application\views\home\includes\header.php 2
INFO - 2023-08-31 07:24:19 --> Config Class Initialized
INFO - 2023-08-31 07:24:19 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:24:19 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:24:19 --> Utf8 Class Initialized
INFO - 2023-08-31 07:24:19 --> URI Class Initialized
DEBUG - 2023-08-31 07:24:19 --> No URI present. Default controller set.
INFO - 2023-08-31 07:24:19 --> Router Class Initialized
INFO - 2023-08-31 07:24:19 --> Output Class Initialized
INFO - 2023-08-31 07:24:19 --> Security Class Initialized
DEBUG - 2023-08-31 07:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:24:19 --> Input Class Initialized
INFO - 2023-08-31 07:24:19 --> Language Class Initialized
INFO - 2023-08-31 07:24:19 --> Loader Class Initialized
INFO - 2023-08-31 07:24:19 --> Helper loaded: url_helper
INFO - 2023-08-31 07:24:19 --> Helper loaded: file_helper
INFO - 2023-08-31 07:24:19 --> Database Driver Class Initialized
INFO - 2023-08-31 07:24:19 --> Email Class Initialized
DEBUG - 2023-08-31 07:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:24:19 --> Controller Class Initialized
INFO - 2023-08-31 07:24:19 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:24:19 --> Model "Home_model" initialized
INFO - 2023-08-31 07:24:19 --> Helper loaded: download_helper
INFO - 2023-08-31 07:24:19 --> Helper loaded: form_helper
INFO - 2023-08-31 07:24:19 --> Form Validation Class Initialized
ERROR - 2023-08-31 07:24:19 --> Severity: error --> Exception: Call to undefined method Home_model::getActiveServiceNames() C:\xampp\htdocs\dw\application\views\home\includes\header.php 2
INFO - 2023-08-31 07:24:29 --> Config Class Initialized
INFO - 2023-08-31 07:24:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:24:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:24:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:24:29 --> URI Class Initialized
INFO - 2023-08-31 07:24:29 --> Router Class Initialized
INFO - 2023-08-31 07:24:29 --> Output Class Initialized
INFO - 2023-08-31 07:24:29 --> Security Class Initialized
DEBUG - 2023-08-31 07:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:24:29 --> Input Class Initialized
INFO - 2023-08-31 07:24:29 --> Language Class Initialized
ERROR - 2023-08-31 07:24:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 07:24:29 --> Config Class Initialized
INFO - 2023-08-31 07:24:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:24:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:24:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:24:29 --> URI Class Initialized
INFO - 2023-08-31 07:24:29 --> Router Class Initialized
INFO - 2023-08-31 07:24:29 --> Output Class Initialized
INFO - 2023-08-31 07:24:29 --> Security Class Initialized
DEBUG - 2023-08-31 07:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:24:29 --> Input Class Initialized
INFO - 2023-08-31 07:24:29 --> Language Class Initialized
ERROR - 2023-08-31 07:24:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 07:25:25 --> Config Class Initialized
INFO - 2023-08-31 07:25:25 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:25:25 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:25:25 --> Utf8 Class Initialized
INFO - 2023-08-31 07:25:25 --> URI Class Initialized
DEBUG - 2023-08-31 07:25:25 --> No URI present. Default controller set.
INFO - 2023-08-31 07:25:25 --> Router Class Initialized
INFO - 2023-08-31 07:25:25 --> Output Class Initialized
INFO - 2023-08-31 07:25:25 --> Security Class Initialized
DEBUG - 2023-08-31 07:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:25:25 --> Input Class Initialized
INFO - 2023-08-31 07:25:25 --> Language Class Initialized
INFO - 2023-08-31 07:25:25 --> Loader Class Initialized
INFO - 2023-08-31 07:25:25 --> Helper loaded: url_helper
INFO - 2023-08-31 07:25:25 --> Helper loaded: file_helper
INFO - 2023-08-31 07:25:25 --> Database Driver Class Initialized
INFO - 2023-08-31 07:25:25 --> Email Class Initialized
DEBUG - 2023-08-31 07:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:25:25 --> Controller Class Initialized
INFO - 2023-08-31 07:25:25 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:25:25 --> Model "Home_model" initialized
INFO - 2023-08-31 07:25:25 --> Helper loaded: download_helper
INFO - 2023-08-31 07:25:25 --> Helper loaded: form_helper
INFO - 2023-08-31 07:25:25 --> Form Validation Class Initialized
INFO - 2023-08-31 07:25:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 07:25:25 --> Final output sent to browser
DEBUG - 2023-08-31 07:25:25 --> Total execution time: 0.2739
INFO - 2023-08-31 07:25:26 --> Config Class Initialized
INFO - 2023-08-31 07:25:26 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:25:26 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:25:26 --> Utf8 Class Initialized
INFO - 2023-08-31 07:25:26 --> URI Class Initialized
INFO - 2023-08-31 07:25:26 --> Router Class Initialized
INFO - 2023-08-31 07:25:26 --> Output Class Initialized
INFO - 2023-08-31 07:25:26 --> Security Class Initialized
DEBUG - 2023-08-31 07:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:25:26 --> Input Class Initialized
INFO - 2023-08-31 07:25:26 --> Language Class Initialized
ERROR - 2023-08-31 07:25:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 07:25:28 --> Config Class Initialized
INFO - 2023-08-31 07:25:28 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:25:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:25:28 --> Utf8 Class Initialized
INFO - 2023-08-31 07:25:28 --> URI Class Initialized
INFO - 2023-08-31 07:25:29 --> Config Class Initialized
INFO - 2023-08-31 07:25:29 --> Hooks Class Initialized
INFO - 2023-08-31 07:25:29 --> Config Class Initialized
INFO - 2023-08-31 07:25:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:25:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:25:29 --> Router Class Initialized
INFO - 2023-08-31 07:25:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:25:29 --> Output Class Initialized
INFO - 2023-08-31 07:25:29 --> URI Class Initialized
DEBUG - 2023-08-31 07:25:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:25:29 --> Router Class Initialized
INFO - 2023-08-31 07:25:29 --> Security Class Initialized
INFO - 2023-08-31 07:25:29 --> Output Class Initialized
INFO - 2023-08-31 07:25:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:25:29 --> Security Class Initialized
INFO - 2023-08-31 07:25:30 --> URI Class Initialized
DEBUG - 2023-08-31 07:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:25:30 --> Router Class Initialized
INFO - 2023-08-31 07:25:30 --> Input Class Initialized
INFO - 2023-08-31 07:25:30 --> Output Class Initialized
INFO - 2023-08-31 07:25:30 --> Security Class Initialized
DEBUG - 2023-08-31 07:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 07:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:25:30 --> Input Class Initialized
INFO - 2023-08-31 07:25:30 --> Language Class Initialized
INFO - 2023-08-31 07:25:30 --> Language Class Initialized
ERROR - 2023-08-31 07:25:30 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-31 07:25:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:25:30 --> Input Class Initialized
INFO - 2023-08-31 07:25:30 --> Config Class Initialized
INFO - 2023-08-31 07:25:30 --> Hooks Class Initialized
INFO - 2023-08-31 07:25:30 --> Language Class Initialized
INFO - 2023-08-31 07:25:30 --> Config Class Initialized
DEBUG - 2023-08-31 07:25:30 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:25:30 --> Hooks Class Initialized
INFO - 2023-08-31 07:25:30 --> Utf8 Class Initialized
ERROR - 2023-08-31 07:25:30 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 07:25:30 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:25:30 --> URI Class Initialized
INFO - 2023-08-31 07:25:30 --> Utf8 Class Initialized
INFO - 2023-08-31 07:25:30 --> Router Class Initialized
INFO - 2023-08-31 07:25:31 --> Output Class Initialized
INFO - 2023-08-31 07:25:31 --> URI Class Initialized
INFO - 2023-08-31 07:25:31 --> Security Class Initialized
INFO - 2023-08-31 07:25:31 --> Router Class Initialized
INFO - 2023-08-31 07:25:31 --> Output Class Initialized
DEBUG - 2023-08-31 07:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:25:32 --> Security Class Initialized
DEBUG - 2023-08-31 07:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:25:32 --> Input Class Initialized
INFO - 2023-08-31 07:25:32 --> Input Class Initialized
INFO - 2023-08-31 07:25:32 --> Language Class Initialized
ERROR - 2023-08-31 07:25:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 07:25:33 --> Language Class Initialized
ERROR - 2023-08-31 07:25:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 07:25:33 --> Config Class Initialized
INFO - 2023-08-31 07:25:33 --> Hooks Class Initialized
INFO - 2023-08-31 07:25:33 --> Config Class Initialized
DEBUG - 2023-08-31 07:25:33 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:25:33 --> Config Class Initialized
INFO - 2023-08-31 07:25:33 --> Hooks Class Initialized
INFO - 2023-08-31 07:25:33 --> Utf8 Class Initialized
INFO - 2023-08-31 07:25:33 --> Hooks Class Initialized
INFO - 2023-08-31 07:25:33 --> URI Class Initialized
DEBUG - 2023-08-31 07:25:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:25:33 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:25:33 --> Utf8 Class Initialized
INFO - 2023-08-31 07:25:33 --> Router Class Initialized
INFO - 2023-08-31 07:25:33 --> URI Class Initialized
INFO - 2023-08-31 07:25:33 --> Output Class Initialized
INFO - 2023-08-31 07:25:33 --> Security Class Initialized
INFO - 2023-08-31 07:25:33 --> Utf8 Class Initialized
INFO - 2023-08-31 07:25:33 --> Router Class Initialized
INFO - 2023-08-31 07:25:33 --> URI Class Initialized
INFO - 2023-08-31 07:25:33 --> Output Class Initialized
INFO - 2023-08-31 07:25:33 --> Router Class Initialized
INFO - 2023-08-31 07:25:33 --> Security Class Initialized
INFO - 2023-08-31 07:25:33 --> Output Class Initialized
DEBUG - 2023-08-31 07:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:25:33 --> Input Class Initialized
DEBUG - 2023-08-31 07:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:25:34 --> Security Class Initialized
INFO - 2023-08-31 07:25:34 --> Input Class Initialized
DEBUG - 2023-08-31 07:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:25:34 --> Input Class Initialized
INFO - 2023-08-31 07:25:34 --> Language Class Initialized
INFO - 2023-08-31 07:25:34 --> Language Class Initialized
INFO - 2023-08-31 07:25:34 --> Language Class Initialized
ERROR - 2023-08-31 07:25:34 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-31 07:25:34 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-31 07:25:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 07:26:08 --> Config Class Initialized
INFO - 2023-08-31 07:26:08 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:26:08 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:26:08 --> Utf8 Class Initialized
INFO - 2023-08-31 07:26:08 --> URI Class Initialized
INFO - 2023-08-31 07:26:08 --> Router Class Initialized
INFO - 2023-08-31 07:26:08 --> Output Class Initialized
INFO - 2023-08-31 07:26:08 --> Security Class Initialized
DEBUG - 2023-08-31 07:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:26:08 --> Input Class Initialized
INFO - 2023-08-31 07:26:08 --> Language Class Initialized
INFO - 2023-08-31 07:26:08 --> Loader Class Initialized
INFO - 2023-08-31 07:26:08 --> Helper loaded: url_helper
INFO - 2023-08-31 07:26:08 --> Helper loaded: file_helper
INFO - 2023-08-31 07:26:08 --> Database Driver Class Initialized
INFO - 2023-08-31 07:26:08 --> Email Class Initialized
DEBUG - 2023-08-31 07:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:26:08 --> Controller Class Initialized
INFO - 2023-08-31 07:26:08 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:26:08 --> Model "Home_model" initialized
INFO - 2023-08-31 07:26:08 --> Helper loaded: download_helper
INFO - 2023-08-31 07:26:08 --> Helper loaded: form_helper
INFO - 2023-08-31 07:26:08 --> Form Validation Class Initialized
INFO - 2023-08-31 07:26:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-31 07:26:09 --> Final output sent to browser
DEBUG - 2023-08-31 07:26:09 --> Total execution time: 0.8131
INFO - 2023-08-31 07:26:09 --> Config Class Initialized
INFO - 2023-08-31 07:26:09 --> Config Class Initialized
INFO - 2023-08-31 07:26:09 --> Config Class Initialized
INFO - 2023-08-31 07:26:09 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:26:09 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:26:09 --> Utf8 Class Initialized
INFO - 2023-08-31 07:26:09 --> URI Class Initialized
INFO - 2023-08-31 07:26:09 --> Router Class Initialized
INFO - 2023-08-31 07:26:09 --> Output Class Initialized
INFO - 2023-08-31 07:26:09 --> Security Class Initialized
DEBUG - 2023-08-31 07:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:26:09 --> Input Class Initialized
INFO - 2023-08-31 07:26:09 --> Language Class Initialized
ERROR - 2023-08-31 07:26:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:26:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:26:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:26:10 --> Hooks Class Initialized
INFO - 2023-08-31 07:26:10 --> Utf8 Class Initialized
DEBUG - 2023-08-31 07:26:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:26:10 --> URI Class Initialized
INFO - 2023-08-31 07:26:10 --> Router Class Initialized
INFO - 2023-08-31 07:26:10 --> Utf8 Class Initialized
INFO - 2023-08-31 07:26:10 --> Output Class Initialized
INFO - 2023-08-31 07:26:10 --> URI Class Initialized
INFO - 2023-08-31 07:26:10 --> Security Class Initialized
INFO - 2023-08-31 07:26:10 --> Router Class Initialized
DEBUG - 2023-08-31 07:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:26:10 --> Output Class Initialized
INFO - 2023-08-31 07:26:10 --> Input Class Initialized
INFO - 2023-08-31 07:26:10 --> Security Class Initialized
INFO - 2023-08-31 07:26:10 --> Language Class Initialized
DEBUG - 2023-08-31 07:26:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-31 07:26:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:26:10 --> Input Class Initialized
INFO - 2023-08-31 07:26:10 --> Language Class Initialized
ERROR - 2023-08-31 07:26:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:30:36 --> Config Class Initialized
INFO - 2023-08-31 07:30:36 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:30:36 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:30:36 --> Utf8 Class Initialized
INFO - 2023-08-31 07:30:36 --> URI Class Initialized
INFO - 2023-08-31 07:30:36 --> Router Class Initialized
INFO - 2023-08-31 07:30:36 --> Output Class Initialized
INFO - 2023-08-31 07:30:36 --> Security Class Initialized
DEBUG - 2023-08-31 07:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:30:36 --> Input Class Initialized
INFO - 2023-08-31 07:30:36 --> Language Class Initialized
INFO - 2023-08-31 07:30:36 --> Loader Class Initialized
INFO - 2023-08-31 07:30:36 --> Helper loaded: url_helper
INFO - 2023-08-31 07:30:36 --> Helper loaded: file_helper
INFO - 2023-08-31 07:30:36 --> Database Driver Class Initialized
INFO - 2023-08-31 07:30:36 --> Email Class Initialized
DEBUG - 2023-08-31 07:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:30:36 --> Controller Class Initialized
INFO - 2023-08-31 07:30:36 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:30:36 --> Model "Home_model" initialized
INFO - 2023-08-31 07:30:36 --> Helper loaded: download_helper
INFO - 2023-08-31 07:30:36 --> Helper loaded: form_helper
INFO - 2023-08-31 07:30:37 --> Form Validation Class Initialized
INFO - 2023-08-31 07:30:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-31 07:30:37 --> Final output sent to browser
DEBUG - 2023-08-31 07:30:37 --> Total execution time: 0.8162
INFO - 2023-08-31 07:30:38 --> Config Class Initialized
INFO - 2023-08-31 07:30:38 --> Config Class Initialized
INFO - 2023-08-31 07:30:38 --> Config Class Initialized
INFO - 2023-08-31 07:30:38 --> Config Class Initialized
INFO - 2023-08-31 07:30:38 --> Hooks Class Initialized
INFO - 2023-08-31 07:30:38 --> Hooks Class Initialized
INFO - 2023-08-31 07:30:38 --> Config Class Initialized
INFO - 2023-08-31 07:30:38 --> Hooks Class Initialized
INFO - 2023-08-31 07:30:38 --> Hooks Class Initialized
INFO - 2023-08-31 07:30:38 --> Config Class Initialized
INFO - 2023-08-31 07:30:38 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:30:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:30:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:30:38 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:30:38 --> Hooks Class Initialized
INFO - 2023-08-31 07:30:38 --> Utf8 Class Initialized
INFO - 2023-08-31 07:30:38 --> URI Class Initialized
INFO - 2023-08-31 07:30:38 --> Router Class Initialized
INFO - 2023-08-31 07:30:38 --> Output Class Initialized
INFO - 2023-08-31 07:30:38 --> Security Class Initialized
DEBUG - 2023-08-31 07:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:30:38 --> Input Class Initialized
INFO - 2023-08-31 07:30:38 --> Language Class Initialized
ERROR - 2023-08-31 07:30:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:30:38 --> Config Class Initialized
INFO - 2023-08-31 07:30:38 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:30:38 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:30:38 --> Utf8 Class Initialized
INFO - 2023-08-31 07:30:38 --> URI Class Initialized
INFO - 2023-08-31 07:30:38 --> Router Class Initialized
INFO - 2023-08-31 07:30:38 --> Output Class Initialized
INFO - 2023-08-31 07:30:38 --> Security Class Initialized
DEBUG - 2023-08-31 07:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:30:38 --> Input Class Initialized
INFO - 2023-08-31 07:30:38 --> Language Class Initialized
ERROR - 2023-08-31 07:30:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:30:38 --> Utf8 Class Initialized
DEBUG - 2023-08-31 07:30:38 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:30:38 --> Config Class Initialized
DEBUG - 2023-08-31 07:30:38 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:30:38 --> Utf8 Class Initialized
INFO - 2023-08-31 07:30:38 --> URI Class Initialized
DEBUG - 2023-08-31 07:30:38 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:30:38 --> Utf8 Class Initialized
INFO - 2023-08-31 07:30:38 --> Utf8 Class Initialized
INFO - 2023-08-31 07:30:38 --> Hooks Class Initialized
INFO - 2023-08-31 07:30:38 --> URI Class Initialized
INFO - 2023-08-31 07:30:38 --> Router Class Initialized
INFO - 2023-08-31 07:30:38 --> Output Class Initialized
INFO - 2023-08-31 07:30:38 --> Router Class Initialized
INFO - 2023-08-31 07:30:38 --> Output Class Initialized
INFO - 2023-08-31 07:30:39 --> Utf8 Class Initialized
INFO - 2023-08-31 07:30:39 --> URI Class Initialized
DEBUG - 2023-08-31 07:30:39 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:30:39 --> Security Class Initialized
INFO - 2023-08-31 07:30:39 --> URI Class Initialized
INFO - 2023-08-31 07:30:39 --> URI Class Initialized
INFO - 2023-08-31 07:30:39 --> Security Class Initialized
INFO - 2023-08-31 07:30:39 --> Router Class Initialized
INFO - 2023-08-31 07:30:39 --> Utf8 Class Initialized
INFO - 2023-08-31 07:30:39 --> Output Class Initialized
INFO - 2023-08-31 07:30:39 --> Router Class Initialized
INFO - 2023-08-31 07:30:39 --> URI Class Initialized
DEBUG - 2023-08-31 07:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:30:39 --> Router Class Initialized
INFO - 2023-08-31 07:30:39 --> Router Class Initialized
INFO - 2023-08-31 07:30:39 --> Output Class Initialized
INFO - 2023-08-31 07:30:39 --> Security Class Initialized
INFO - 2023-08-31 07:30:39 --> Output Class Initialized
INFO - 2023-08-31 07:30:39 --> Security Class Initialized
INFO - 2023-08-31 07:30:39 --> Input Class Initialized
INFO - 2023-08-31 07:30:39 --> Output Class Initialized
DEBUG - 2023-08-31 07:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 07:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:30:39 --> Security Class Initialized
DEBUG - 2023-08-31 07:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:30:39 --> Input Class Initialized
INFO - 2023-08-31 07:30:39 --> Language Class Initialized
ERROR - 2023-08-31 07:30:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:30:39 --> Security Class Initialized
INFO - 2023-08-31 07:30:39 --> Language Class Initialized
DEBUG - 2023-08-31 07:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 07:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:30:39 --> Input Class Initialized
INFO - 2023-08-31 07:30:39 --> Input Class Initialized
INFO - 2023-08-31 07:30:39 --> Language Class Initialized
ERROR - 2023-08-31 07:30:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:30:39 --> Input Class Initialized
INFO - 2023-08-31 07:30:39 --> Language Class Initialized
INFO - 2023-08-31 07:30:39 --> Language Class Initialized
ERROR - 2023-08-31 07:30:39 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-31 07:30:39 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-31 07:30:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:30:39 --> Input Class Initialized
INFO - 2023-08-31 07:30:39 --> Language Class Initialized
ERROR - 2023-08-31 07:30:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:30:45 --> Config Class Initialized
INFO - 2023-08-31 07:30:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:30:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:30:45 --> Utf8 Class Initialized
INFO - 2023-08-31 07:30:45 --> URI Class Initialized
INFO - 2023-08-31 07:30:45 --> Router Class Initialized
INFO - 2023-08-31 07:30:45 --> Output Class Initialized
INFO - 2023-08-31 07:30:45 --> Security Class Initialized
DEBUG - 2023-08-31 07:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:30:45 --> Input Class Initialized
INFO - 2023-08-31 07:30:45 --> Language Class Initialized
INFO - 2023-08-31 07:30:45 --> Loader Class Initialized
INFO - 2023-08-31 07:30:45 --> Helper loaded: url_helper
INFO - 2023-08-31 07:30:45 --> Helper loaded: file_helper
INFO - 2023-08-31 07:30:45 --> Database Driver Class Initialized
INFO - 2023-08-31 07:30:45 --> Email Class Initialized
DEBUG - 2023-08-31 07:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:30:45 --> Controller Class Initialized
INFO - 2023-08-31 07:30:45 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:30:45 --> Model "Home_model" initialized
INFO - 2023-08-31 07:30:45 --> Helper loaded: download_helper
INFO - 2023-08-31 07:30:45 --> Helper loaded: form_helper
INFO - 2023-08-31 07:30:45 --> Form Validation Class Initialized
ERROR - 2023-08-31 07:30:45 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 07:30:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 07:30:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 07:30:45 --> Final output sent to browser
DEBUG - 2023-08-31 07:30:46 --> Total execution time: 0.5302
INFO - 2023-08-31 07:30:47 --> Config Class Initialized
INFO - 2023-08-31 07:30:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:30:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:30:47 --> Utf8 Class Initialized
INFO - 2023-08-31 07:30:47 --> URI Class Initialized
INFO - 2023-08-31 07:30:47 --> Router Class Initialized
INFO - 2023-08-31 07:30:47 --> Output Class Initialized
INFO - 2023-08-31 07:30:47 --> Security Class Initialized
DEBUG - 2023-08-31 07:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:30:48 --> Input Class Initialized
INFO - 2023-08-31 07:30:48 --> Language Class Initialized
ERROR - 2023-08-31 07:30:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:30:48 --> Config Class Initialized
INFO - 2023-08-31 07:30:48 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:30:48 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:30:48 --> Utf8 Class Initialized
INFO - 2023-08-31 07:30:48 --> URI Class Initialized
INFO - 2023-08-31 07:30:49 --> Router Class Initialized
INFO - 2023-08-31 07:30:49 --> Output Class Initialized
INFO - 2023-08-31 07:30:49 --> Security Class Initialized
DEBUG - 2023-08-31 07:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:30:49 --> Input Class Initialized
INFO - 2023-08-31 07:30:49 --> Language Class Initialized
ERROR - 2023-08-31 07:30:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:30:49 --> Config Class Initialized
INFO - 2023-08-31 07:30:49 --> Hooks Class Initialized
INFO - 2023-08-31 07:30:50 --> Config Class Initialized
DEBUG - 2023-08-31 07:30:50 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:30:50 --> Hooks Class Initialized
INFO - 2023-08-31 07:30:50 --> Utf8 Class Initialized
INFO - 2023-08-31 07:30:50 --> Config Class Initialized
INFO - 2023-08-31 07:30:50 --> Hooks Class Initialized
INFO - 2023-08-31 07:30:50 --> URI Class Initialized
DEBUG - 2023-08-31 07:30:50 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:30:50 --> Utf8 Class Initialized
DEBUG - 2023-08-31 07:30:50 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:30:50 --> URI Class Initialized
INFO - 2023-08-31 07:30:50 --> Utf8 Class Initialized
INFO - 2023-08-31 07:30:50 --> Router Class Initialized
INFO - 2023-08-31 07:30:50 --> Output Class Initialized
INFO - 2023-08-31 07:30:50 --> Router Class Initialized
INFO - 2023-08-31 07:30:50 --> Security Class Initialized
DEBUG - 2023-08-31 07:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:30:50 --> Output Class Initialized
INFO - 2023-08-31 07:30:50 --> Security Class Initialized
DEBUG - 2023-08-31 07:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:30:50 --> URI Class Initialized
INFO - 2023-08-31 07:30:50 --> Input Class Initialized
INFO - 2023-08-31 07:30:50 --> Language Class Initialized
ERROR - 2023-08-31 07:30:50 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 07:30:51 --> Input Class Initialized
INFO - 2023-08-31 07:30:51 --> Language Class Initialized
INFO - 2023-08-31 07:30:51 --> Router Class Initialized
INFO - 2023-08-31 07:30:51 --> Output Class Initialized
INFO - 2023-08-31 07:30:51 --> Security Class Initialized
ERROR - 2023-08-31 07:30:51 --> 404 Page Not Found: Service-detail/assets
DEBUG - 2023-08-31 07:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:30:51 --> Input Class Initialized
INFO - 2023-08-31 07:30:51 --> Language Class Initialized
ERROR - 2023-08-31 07:30:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:36:47 --> Config Class Initialized
INFO - 2023-08-31 07:36:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:36:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:36:47 --> Utf8 Class Initialized
INFO - 2023-08-31 07:36:47 --> URI Class Initialized
INFO - 2023-08-31 07:36:47 --> Router Class Initialized
INFO - 2023-08-31 07:36:47 --> Output Class Initialized
INFO - 2023-08-31 07:36:47 --> Security Class Initialized
DEBUG - 2023-08-31 07:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:36:47 --> Input Class Initialized
INFO - 2023-08-31 07:36:47 --> Language Class Initialized
INFO - 2023-08-31 07:36:47 --> Loader Class Initialized
INFO - 2023-08-31 07:36:47 --> Helper loaded: url_helper
INFO - 2023-08-31 07:36:47 --> Helper loaded: file_helper
INFO - 2023-08-31 07:36:47 --> Database Driver Class Initialized
INFO - 2023-08-31 07:36:47 --> Email Class Initialized
DEBUG - 2023-08-31 07:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:36:47 --> Controller Class Initialized
INFO - 2023-08-31 07:36:47 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:36:47 --> Model "Home_model" initialized
INFO - 2023-08-31 07:36:47 --> Helper loaded: download_helper
INFO - 2023-08-31 07:36:47 --> Helper loaded: form_helper
INFO - 2023-08-31 07:36:47 --> Form Validation Class Initialized
ERROR - 2023-08-31 07:36:47 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 07:36:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 07:36:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 07:36:47 --> Final output sent to browser
DEBUG - 2023-08-31 07:36:47 --> Total execution time: 0.3842
INFO - 2023-08-31 07:36:47 --> Config Class Initialized
INFO - 2023-08-31 07:36:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:36:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:36:47 --> Utf8 Class Initialized
INFO - 2023-08-31 07:36:47 --> URI Class Initialized
INFO - 2023-08-31 07:36:47 --> Router Class Initialized
INFO - 2023-08-31 07:36:47 --> Output Class Initialized
INFO - 2023-08-31 07:36:47 --> Security Class Initialized
DEBUG - 2023-08-31 07:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:36:47 --> Input Class Initialized
INFO - 2023-08-31 07:36:47 --> Language Class Initialized
ERROR - 2023-08-31 07:36:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:36:48 --> Config Class Initialized
INFO - 2023-08-31 07:36:48 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:36:48 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:36:48 --> Utf8 Class Initialized
INFO - 2023-08-31 07:36:48 --> URI Class Initialized
INFO - 2023-08-31 07:36:48 --> Router Class Initialized
INFO - 2023-08-31 07:36:48 --> Output Class Initialized
INFO - 2023-08-31 07:36:48 --> Security Class Initialized
DEBUG - 2023-08-31 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:36:48 --> Input Class Initialized
INFO - 2023-08-31 07:36:48 --> Language Class Initialized
ERROR - 2023-08-31 07:36:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:36:48 --> Config Class Initialized
INFO - 2023-08-31 07:36:48 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:36:48 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:36:48 --> Utf8 Class Initialized
INFO - 2023-08-31 07:36:48 --> URI Class Initialized
INFO - 2023-08-31 07:36:48 --> Router Class Initialized
INFO - 2023-08-31 07:36:48 --> Output Class Initialized
INFO - 2023-08-31 07:36:48 --> Security Class Initialized
DEBUG - 2023-08-31 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:36:48 --> Input Class Initialized
INFO - 2023-08-31 07:36:49 --> Language Class Initialized
ERROR - 2023-08-31 07:36:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:36:49 --> Config Class Initialized
INFO - 2023-08-31 07:36:49 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:36:49 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:36:49 --> Utf8 Class Initialized
INFO - 2023-08-31 07:36:49 --> URI Class Initialized
INFO - 2023-08-31 07:36:49 --> Router Class Initialized
INFO - 2023-08-31 07:36:49 --> Output Class Initialized
INFO - 2023-08-31 07:36:49 --> Security Class Initialized
DEBUG - 2023-08-31 07:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:36:49 --> Input Class Initialized
INFO - 2023-08-31 07:36:49 --> Language Class Initialized
ERROR - 2023-08-31 07:36:49 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 07:36:49 --> Config Class Initialized
INFO - 2023-08-31 07:36:49 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:36:49 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:36:49 --> Utf8 Class Initialized
INFO - 2023-08-31 07:36:49 --> URI Class Initialized
INFO - 2023-08-31 07:36:49 --> Router Class Initialized
INFO - 2023-08-31 07:36:49 --> Output Class Initialized
INFO - 2023-08-31 07:36:49 --> Security Class Initialized
DEBUG - 2023-08-31 07:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:36:49 --> Input Class Initialized
INFO - 2023-08-31 07:36:49 --> Language Class Initialized
ERROR - 2023-08-31 07:36:49 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 07:38:22 --> Config Class Initialized
INFO - 2023-08-31 07:38:22 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:38:22 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:38:22 --> Utf8 Class Initialized
INFO - 2023-08-31 07:38:23 --> URI Class Initialized
INFO - 2023-08-31 07:38:23 --> Router Class Initialized
INFO - 2023-08-31 07:38:23 --> Output Class Initialized
INFO - 2023-08-31 07:38:23 --> Security Class Initialized
DEBUG - 2023-08-31 07:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:38:23 --> Input Class Initialized
INFO - 2023-08-31 07:38:23 --> Language Class Initialized
INFO - 2023-08-31 07:38:23 --> Loader Class Initialized
INFO - 2023-08-31 07:38:23 --> Helper loaded: url_helper
INFO - 2023-08-31 07:38:23 --> Helper loaded: file_helper
INFO - 2023-08-31 07:38:23 --> Database Driver Class Initialized
INFO - 2023-08-31 07:38:23 --> Email Class Initialized
DEBUG - 2023-08-31 07:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:38:23 --> Controller Class Initialized
INFO - 2023-08-31 07:38:23 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:38:23 --> Model "Home_model" initialized
INFO - 2023-08-31 07:38:23 --> Helper loaded: download_helper
INFO - 2023-08-31 07:38:23 --> Helper loaded: form_helper
INFO - 2023-08-31 07:38:23 --> Form Validation Class Initialized
ERROR - 2023-08-31 07:38:23 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 07:38:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 07:38:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 07:38:23 --> Final output sent to browser
DEBUG - 2023-08-31 07:38:23 --> Total execution time: 0.4873
INFO - 2023-08-31 07:38:23 --> Config Class Initialized
INFO - 2023-08-31 07:38:23 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:38:23 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:38:23 --> Utf8 Class Initialized
INFO - 2023-08-31 07:38:23 --> URI Class Initialized
INFO - 2023-08-31 07:38:23 --> Router Class Initialized
INFO - 2023-08-31 07:38:23 --> Output Class Initialized
INFO - 2023-08-31 07:38:23 --> Security Class Initialized
DEBUG - 2023-08-31 07:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:38:23 --> Input Class Initialized
INFO - 2023-08-31 07:38:23 --> Language Class Initialized
ERROR - 2023-08-31 07:38:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:38:23 --> Config Class Initialized
INFO - 2023-08-31 07:38:23 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:38:23 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:38:23 --> Utf8 Class Initialized
INFO - 2023-08-31 07:38:23 --> URI Class Initialized
INFO - 2023-08-31 07:38:23 --> Router Class Initialized
INFO - 2023-08-31 07:38:23 --> Output Class Initialized
INFO - 2023-08-31 07:38:23 --> Security Class Initialized
DEBUG - 2023-08-31 07:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:38:23 --> Input Class Initialized
INFO - 2023-08-31 07:38:23 --> Language Class Initialized
ERROR - 2023-08-31 07:38:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:38:23 --> Config Class Initialized
INFO - 2023-08-31 07:38:23 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:38:23 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:38:23 --> Utf8 Class Initialized
INFO - 2023-08-31 07:38:23 --> URI Class Initialized
INFO - 2023-08-31 07:38:23 --> Router Class Initialized
INFO - 2023-08-31 07:38:23 --> Output Class Initialized
INFO - 2023-08-31 07:38:23 --> Security Class Initialized
DEBUG - 2023-08-31 07:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:38:23 --> Input Class Initialized
INFO - 2023-08-31 07:38:23 --> Language Class Initialized
ERROR - 2023-08-31 07:38:23 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 07:38:24 --> Config Class Initialized
INFO - 2023-08-31 07:38:24 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:38:24 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:38:24 --> Utf8 Class Initialized
INFO - 2023-08-31 07:38:24 --> URI Class Initialized
INFO - 2023-08-31 07:38:24 --> Router Class Initialized
INFO - 2023-08-31 07:38:24 --> Output Class Initialized
INFO - 2023-08-31 07:38:24 --> Security Class Initialized
DEBUG - 2023-08-31 07:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:38:24 --> Input Class Initialized
INFO - 2023-08-31 07:38:24 --> Language Class Initialized
ERROR - 2023-08-31 07:38:24 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:38:24 --> Config Class Initialized
INFO - 2023-08-31 07:38:24 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:38:24 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:38:24 --> Utf8 Class Initialized
INFO - 2023-08-31 07:38:24 --> URI Class Initialized
INFO - 2023-08-31 07:38:24 --> Router Class Initialized
INFO - 2023-08-31 07:38:24 --> Output Class Initialized
INFO - 2023-08-31 07:38:24 --> Security Class Initialized
DEBUG - 2023-08-31 07:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:38:24 --> Input Class Initialized
INFO - 2023-08-31 07:38:24 --> Language Class Initialized
ERROR - 2023-08-31 07:38:24 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 07:41:45 --> Config Class Initialized
INFO - 2023-08-31 07:41:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:41:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:41:45 --> Utf8 Class Initialized
INFO - 2023-08-31 07:41:45 --> URI Class Initialized
INFO - 2023-08-31 07:41:45 --> Router Class Initialized
INFO - 2023-08-31 07:41:45 --> Output Class Initialized
INFO - 2023-08-31 07:41:45 --> Security Class Initialized
DEBUG - 2023-08-31 07:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:41:45 --> Input Class Initialized
INFO - 2023-08-31 07:41:45 --> Language Class Initialized
INFO - 2023-08-31 07:41:45 --> Loader Class Initialized
INFO - 2023-08-31 07:41:45 --> Helper loaded: url_helper
INFO - 2023-08-31 07:41:45 --> Helper loaded: file_helper
INFO - 2023-08-31 07:41:45 --> Database Driver Class Initialized
INFO - 2023-08-31 07:41:45 --> Email Class Initialized
DEBUG - 2023-08-31 07:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:41:45 --> Controller Class Initialized
INFO - 2023-08-31 07:41:45 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:41:45 --> Model "Home_model" initialized
INFO - 2023-08-31 07:41:45 --> Helper loaded: download_helper
INFO - 2023-08-31 07:41:45 --> Helper loaded: form_helper
INFO - 2023-08-31 07:41:45 --> Form Validation Class Initialized
ERROR - 2023-08-31 07:41:45 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 07:41:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 07:41:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 07:41:45 --> Final output sent to browser
DEBUG - 2023-08-31 07:41:46 --> Total execution time: 0.2839
INFO - 2023-08-31 07:41:47 --> Config Class Initialized
INFO - 2023-08-31 07:41:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:41:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:41:47 --> Utf8 Class Initialized
INFO - 2023-08-31 07:41:47 --> URI Class Initialized
INFO - 2023-08-31 07:41:47 --> Router Class Initialized
INFO - 2023-08-31 07:41:47 --> Output Class Initialized
INFO - 2023-08-31 07:41:47 --> Security Class Initialized
DEBUG - 2023-08-31 07:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:41:47 --> Input Class Initialized
INFO - 2023-08-31 07:41:47 --> Language Class Initialized
ERROR - 2023-08-31 07:41:47 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 07:41:47 --> Config Class Initialized
INFO - 2023-08-31 07:41:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:41:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:41:47 --> Utf8 Class Initialized
INFO - 2023-08-31 07:41:47 --> URI Class Initialized
INFO - 2023-08-31 07:41:47 --> Router Class Initialized
INFO - 2023-08-31 07:41:47 --> Output Class Initialized
INFO - 2023-08-31 07:41:47 --> Security Class Initialized
DEBUG - 2023-08-31 07:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:41:47 --> Input Class Initialized
INFO - 2023-08-31 07:41:47 --> Language Class Initialized
ERROR - 2023-08-31 07:41:48 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 07:42:17 --> Config Class Initialized
INFO - 2023-08-31 07:42:17 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:42:17 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:17 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:17 --> URI Class Initialized
INFO - 2023-08-31 07:42:17 --> Router Class Initialized
INFO - 2023-08-31 07:42:17 --> Output Class Initialized
INFO - 2023-08-31 07:42:17 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:17 --> Input Class Initialized
INFO - 2023-08-31 07:42:17 --> Language Class Initialized
INFO - 2023-08-31 07:42:17 --> Loader Class Initialized
INFO - 2023-08-31 07:42:17 --> Helper loaded: url_helper
INFO - 2023-08-31 07:42:17 --> Helper loaded: file_helper
INFO - 2023-08-31 07:42:17 --> Database Driver Class Initialized
INFO - 2023-08-31 07:42:17 --> Email Class Initialized
DEBUG - 2023-08-31 07:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:42:17 --> Controller Class Initialized
INFO - 2023-08-31 07:42:17 --> Model "User_model" initialized
INFO - 2023-08-31 07:42:17 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-31 07:42:17 --> Final output sent to browser
DEBUG - 2023-08-31 07:42:17 --> Total execution time: 0.3466
INFO - 2023-08-31 07:42:21 --> Config Class Initialized
INFO - 2023-08-31 07:42:21 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:42:21 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:21 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:21 --> URI Class Initialized
INFO - 2023-08-31 07:42:21 --> Router Class Initialized
INFO - 2023-08-31 07:42:21 --> Output Class Initialized
INFO - 2023-08-31 07:42:21 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:21 --> Input Class Initialized
INFO - 2023-08-31 07:42:21 --> Language Class Initialized
ERROR - 2023-08-31 07:42:21 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-31 07:42:27 --> Config Class Initialized
INFO - 2023-08-31 07:42:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:42:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:27 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:27 --> URI Class Initialized
INFO - 2023-08-31 07:42:27 --> Router Class Initialized
INFO - 2023-08-31 07:42:27 --> Output Class Initialized
INFO - 2023-08-31 07:42:27 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:27 --> Input Class Initialized
INFO - 2023-08-31 07:42:27 --> Language Class Initialized
INFO - 2023-08-31 07:42:27 --> Loader Class Initialized
INFO - 2023-08-31 07:42:27 --> Helper loaded: url_helper
INFO - 2023-08-31 07:42:27 --> Helper loaded: file_helper
INFO - 2023-08-31 07:42:27 --> Database Driver Class Initialized
INFO - 2023-08-31 07:42:27 --> Email Class Initialized
DEBUG - 2023-08-31 07:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:42:27 --> Controller Class Initialized
INFO - 2023-08-31 07:42:27 --> Model "User_model" initialized
INFO - 2023-08-31 07:42:28 --> Config Class Initialized
INFO - 2023-08-31 07:42:28 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:42:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:28 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:28 --> URI Class Initialized
INFO - 2023-08-31 07:42:28 --> Router Class Initialized
INFO - 2023-08-31 07:42:28 --> Output Class Initialized
INFO - 2023-08-31 07:42:28 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:28 --> Input Class Initialized
INFO - 2023-08-31 07:42:28 --> Language Class Initialized
INFO - 2023-08-31 07:42:28 --> Loader Class Initialized
INFO - 2023-08-31 07:42:28 --> Helper loaded: url_helper
INFO - 2023-08-31 07:42:28 --> Helper loaded: file_helper
INFO - 2023-08-31 07:42:28 --> Database Driver Class Initialized
INFO - 2023-08-31 07:42:28 --> Email Class Initialized
DEBUG - 2023-08-31 07:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:42:28 --> Controller Class Initialized
INFO - 2023-08-31 07:42:28 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-31 07:42:28 --> Final output sent to browser
DEBUG - 2023-08-31 07:42:28 --> Total execution time: 0.2501
INFO - 2023-08-31 07:42:32 --> Config Class Initialized
INFO - 2023-08-31 07:42:32 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:42:32 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:32 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:32 --> URI Class Initialized
INFO - 2023-08-31 07:42:32 --> Router Class Initialized
INFO - 2023-08-31 07:42:32 --> Output Class Initialized
INFO - 2023-08-31 07:42:32 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:32 --> Input Class Initialized
INFO - 2023-08-31 07:42:32 --> Language Class Initialized
INFO - 2023-08-31 07:42:32 --> Loader Class Initialized
INFO - 2023-08-31 07:42:32 --> Helper loaded: url_helper
INFO - 2023-08-31 07:42:32 --> Helper loaded: file_helper
INFO - 2023-08-31 07:42:32 --> Database Driver Class Initialized
INFO - 2023-08-31 07:42:32 --> Email Class Initialized
DEBUG - 2023-08-31 07:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:42:32 --> Controller Class Initialized
INFO - 2023-08-31 07:42:32 --> Model "Services_model" initialized
INFO - 2023-08-31 07:42:32 --> Helper loaded: form_helper
INFO - 2023-08-31 07:42:32 --> Form Validation Class Initialized
INFO - 2023-08-31 07:42:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 07:42:32 --> Final output sent to browser
DEBUG - 2023-08-31 07:42:32 --> Total execution time: 0.3547
INFO - 2023-08-31 07:42:47 --> Config Class Initialized
INFO - 2023-08-31 07:42:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:42:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:47 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:47 --> URI Class Initialized
INFO - 2023-08-31 07:42:47 --> Router Class Initialized
INFO - 2023-08-31 07:42:47 --> Output Class Initialized
INFO - 2023-08-31 07:42:47 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:47 --> Input Class Initialized
INFO - 2023-08-31 07:42:47 --> Language Class Initialized
INFO - 2023-08-31 07:42:47 --> Loader Class Initialized
INFO - 2023-08-31 07:42:47 --> Helper loaded: url_helper
INFO - 2023-08-31 07:42:47 --> Helper loaded: file_helper
INFO - 2023-08-31 07:42:47 --> Database Driver Class Initialized
INFO - 2023-08-31 07:42:47 --> Email Class Initialized
DEBUG - 2023-08-31 07:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:42:47 --> Controller Class Initialized
INFO - 2023-08-31 07:42:47 --> Model "Services_model" initialized
INFO - 2023-08-31 07:42:47 --> Helper loaded: form_helper
INFO - 2023-08-31 07:42:47 --> Form Validation Class Initialized
INFO - 2023-08-31 07:42:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 07:42:47 --> Final output sent to browser
DEBUG - 2023-08-31 07:42:47 --> Total execution time: 0.3991
INFO - 2023-08-31 07:42:48 --> Config Class Initialized
INFO - 2023-08-31 07:42:48 --> Config Class Initialized
INFO - 2023-08-31 07:42:48 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:42:48 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:48 --> Hooks Class Initialized
INFO - 2023-08-31 07:42:48 --> Utf8 Class Initialized
DEBUG - 2023-08-31 07:42:48 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:48 --> URI Class Initialized
INFO - 2023-08-31 07:42:48 --> Router Class Initialized
INFO - 2023-08-31 07:42:48 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:48 --> Output Class Initialized
INFO - 2023-08-31 07:42:48 --> Security Class Initialized
INFO - 2023-08-31 07:42:48 --> URI Class Initialized
DEBUG - 2023-08-31 07:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:48 --> Input Class Initialized
INFO - 2023-08-31 07:42:48 --> Router Class Initialized
INFO - 2023-08-31 07:42:48 --> Output Class Initialized
INFO - 2023-08-31 07:42:48 --> Language Class Initialized
INFO - 2023-08-31 07:42:48 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-31 07:42:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:42:48 --> Input Class Initialized
INFO - 2023-08-31 07:42:48 --> Language Class Initialized
ERROR - 2023-08-31 07:42:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:42:48 --> Config Class Initialized
INFO - 2023-08-31 07:42:48 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:42:48 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:48 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:48 --> URI Class Initialized
INFO - 2023-08-31 07:42:48 --> Router Class Initialized
INFO - 2023-08-31 07:42:48 --> Output Class Initialized
INFO - 2023-08-31 07:42:48 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:48 --> Input Class Initialized
INFO - 2023-08-31 07:42:48 --> Language Class Initialized
INFO - 2023-08-31 07:42:48 --> Loader Class Initialized
INFO - 2023-08-31 07:42:48 --> Helper loaded: url_helper
INFO - 2023-08-31 07:42:48 --> Helper loaded: file_helper
INFO - 2023-08-31 07:42:48 --> Database Driver Class Initialized
INFO - 2023-08-31 07:42:48 --> Email Class Initialized
DEBUG - 2023-08-31 07:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:42:48 --> Controller Class Initialized
INFO - 2023-08-31 07:42:48 --> Model "Services_model" initialized
INFO - 2023-08-31 07:42:48 --> Helper loaded: form_helper
INFO - 2023-08-31 07:42:48 --> Form Validation Class Initialized
ERROR - 2023-08-31 07:42:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-31 07:42:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-31 07:42:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-31 07:42:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-31 07:42:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-31 07:42:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-31 07:42:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-31 07:42:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-31 07:42:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-31 07:42:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-31 07:42:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 140
ERROR - 2023-08-31 07:42:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 142
ERROR - 2023-08-31 07:42:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 144
INFO - 2023-08-31 07:42:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 07:42:49 --> Final output sent to browser
DEBUG - 2023-08-31 07:42:49 --> Total execution time: 0.6606
INFO - 2023-08-31 07:42:52 --> Config Class Initialized
INFO - 2023-08-31 07:42:52 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:42:52 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:52 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:52 --> URI Class Initialized
INFO - 2023-08-31 07:42:52 --> Router Class Initialized
INFO - 2023-08-31 07:42:52 --> Output Class Initialized
INFO - 2023-08-31 07:42:52 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:52 --> Input Class Initialized
INFO - 2023-08-31 07:42:52 --> Language Class Initialized
INFO - 2023-08-31 07:42:52 --> Loader Class Initialized
INFO - 2023-08-31 07:42:52 --> Helper loaded: url_helper
INFO - 2023-08-31 07:42:52 --> Helper loaded: file_helper
INFO - 2023-08-31 07:42:52 --> Database Driver Class Initialized
INFO - 2023-08-31 07:42:52 --> Email Class Initialized
DEBUG - 2023-08-31 07:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:42:52 --> Controller Class Initialized
INFO - 2023-08-31 07:42:52 --> Model "Services_model" initialized
INFO - 2023-08-31 07:42:52 --> Helper loaded: form_helper
INFO - 2023-08-31 07:42:52 --> Form Validation Class Initialized
INFO - 2023-08-31 07:42:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 07:42:52 --> Final output sent to browser
DEBUG - 2023-08-31 07:42:53 --> Total execution time: 0.9657
INFO - 2023-08-31 07:42:57 --> Config Class Initialized
INFO - 2023-08-31 07:42:57 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:42:57 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:57 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:57 --> URI Class Initialized
INFO - 2023-08-31 07:42:57 --> Router Class Initialized
INFO - 2023-08-31 07:42:57 --> Output Class Initialized
INFO - 2023-08-31 07:42:57 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:57 --> Input Class Initialized
INFO - 2023-08-31 07:42:57 --> Language Class Initialized
INFO - 2023-08-31 07:42:57 --> Loader Class Initialized
INFO - 2023-08-31 07:42:57 --> Helper loaded: url_helper
INFO - 2023-08-31 07:42:57 --> Helper loaded: file_helper
INFO - 2023-08-31 07:42:57 --> Database Driver Class Initialized
INFO - 2023-08-31 07:42:57 --> Email Class Initialized
DEBUG - 2023-08-31 07:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:42:58 --> Controller Class Initialized
INFO - 2023-08-31 07:42:58 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:42:58 --> Helper loaded: form_helper
INFO - 2023-08-31 07:42:58 --> Form Validation Class Initialized
INFO - 2023-08-31 07:42:58 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-31 07:42:58 --> Final output sent to browser
DEBUG - 2023-08-31 07:42:58 --> Total execution time: 1.3547
INFO - 2023-08-31 07:42:59 --> Config Class Initialized
INFO - 2023-08-31 07:42:59 --> Hooks Class Initialized
INFO - 2023-08-31 07:42:59 --> Config Class Initialized
INFO - 2023-08-31 07:42:59 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:42:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:59 --> Config Class Initialized
INFO - 2023-08-31 07:42:59 --> Config Class Initialized
INFO - 2023-08-31 07:42:59 --> Config Class Initialized
DEBUG - 2023-08-31 07:42:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:59 --> Hooks Class Initialized
INFO - 2023-08-31 07:42:59 --> Hooks Class Initialized
INFO - 2023-08-31 07:42:59 --> Hooks Class Initialized
INFO - 2023-08-31 07:42:59 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:59 --> Config Class Initialized
INFO - 2023-08-31 07:42:59 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:42:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:42:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:42:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:59 --> URI Class Initialized
INFO - 2023-08-31 07:42:59 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:59 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:59 --> URI Class Initialized
INFO - 2023-08-31 07:42:59 --> Utf8 Class Initialized
DEBUG - 2023-08-31 07:42:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:59 --> Router Class Initialized
INFO - 2023-08-31 07:42:59 --> Router Class Initialized
INFO - 2023-08-31 07:42:59 --> URI Class Initialized
INFO - 2023-08-31 07:42:59 --> Output Class Initialized
INFO - 2023-08-31 07:42:59 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:59 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:59 --> Output Class Initialized
INFO - 2023-08-31 07:42:59 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:59 --> Input Class Initialized
INFO - 2023-08-31 07:42:59 --> Language Class Initialized
INFO - 2023-08-31 07:42:59 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:59 --> Router Class Initialized
INFO - 2023-08-31 07:42:59 --> URI Class Initialized
ERROR - 2023-08-31 07:42:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:42:59 --> URI Class Initialized
INFO - 2023-08-31 07:42:59 --> Router Class Initialized
INFO - 2023-08-31 07:42:59 --> URI Class Initialized
INFO - 2023-08-31 07:42:59 --> Router Class Initialized
INFO - 2023-08-31 07:42:59 --> Router Class Initialized
INFO - 2023-08-31 07:42:59 --> Input Class Initialized
INFO - 2023-08-31 07:42:59 --> Output Class Initialized
INFO - 2023-08-31 07:42:59 --> Output Class Initialized
INFO - 2023-08-31 07:42:59 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:59 --> Input Class Initialized
INFO - 2023-08-31 07:42:59 --> Language Class Initialized
ERROR - 2023-08-31 07:42:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:42:59 --> Output Class Initialized
INFO - 2023-08-31 07:42:59 --> Output Class Initialized
INFO - 2023-08-31 07:42:59 --> Config Class Initialized
INFO - 2023-08-31 07:42:59 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:42:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:42:59 --> Utf8 Class Initialized
INFO - 2023-08-31 07:42:59 --> URI Class Initialized
INFO - 2023-08-31 07:42:59 --> Router Class Initialized
INFO - 2023-08-31 07:42:59 --> Output Class Initialized
INFO - 2023-08-31 07:42:59 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:59 --> Input Class Initialized
INFO - 2023-08-31 07:42:59 --> Language Class Initialized
ERROR - 2023-08-31 07:42:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:42:59 --> Language Class Initialized
INFO - 2023-08-31 07:42:59 --> Security Class Initialized
INFO - 2023-08-31 07:42:59 --> Config Class Initialized
INFO - 2023-08-31 07:42:59 --> Security Class Initialized
INFO - 2023-08-31 07:42:59 --> Security Class Initialized
DEBUG - 2023-08-31 07:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:59 --> Config Class Initialized
ERROR - 2023-08-31 07:42:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:42:59 --> Input Class Initialized
INFO - 2023-08-31 07:42:59 --> Language Class Initialized
ERROR - 2023-08-31 07:42:59 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 07:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:42:59 --> Hooks Class Initialized
INFO - 2023-08-31 07:43:00 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:00 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:00 --> Input Class Initialized
DEBUG - 2023-08-31 07:43:00 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:00 --> Config Class Initialized
INFO - 2023-08-31 07:43:00 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:00 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:00 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:00 --> URI Class Initialized
INFO - 2023-08-31 07:43:00 --> Router Class Initialized
INFO - 2023-08-31 07:43:00 --> Output Class Initialized
INFO - 2023-08-31 07:43:00 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:00 --> Input Class Initialized
INFO - 2023-08-31 07:43:00 --> Language Class Initialized
ERROR - 2023-08-31 07:43:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:00 --> Language Class Initialized
INFO - 2023-08-31 07:43:00 --> Utf8 Class Initialized
DEBUG - 2023-08-31 07:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:00 --> URI Class Initialized
ERROR - 2023-08-31 07:43:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:00 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:00 --> Input Class Initialized
INFO - 2023-08-31 07:43:00 --> Router Class Initialized
INFO - 2023-08-31 07:43:00 --> Output Class Initialized
INFO - 2023-08-31 07:43:00 --> Config Class Initialized
INFO - 2023-08-31 07:43:00 --> Hooks Class Initialized
INFO - 2023-08-31 07:43:00 --> Security Class Initialized
INFO - 2023-08-31 07:43:00 --> URI Class Initialized
DEBUG - 2023-08-31 07:43:00 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:00 --> Router Class Initialized
INFO - 2023-08-31 07:43:00 --> Config Class Initialized
INFO - 2023-08-31 07:43:00 --> Input Class Initialized
INFO - 2023-08-31 07:43:00 --> Language Class Initialized
ERROR - 2023-08-31 07:43:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:00 --> Config Class Initialized
INFO - 2023-08-31 07:43:00 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:00 --> Output Class Initialized
INFO - 2023-08-31 07:43:00 --> Language Class Initialized
INFO - 2023-08-31 07:43:00 --> Hooks Class Initialized
INFO - 2023-08-31 07:43:00 --> Hooks Class Initialized
INFO - 2023-08-31 07:43:00 --> Config Class Initialized
INFO - 2023-08-31 07:43:00 --> Security Class Initialized
INFO - 2023-08-31 07:43:00 --> URI Class Initialized
ERROR - 2023-08-31 07:43:00 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 07:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:00 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:00 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:00 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:00 --> URI Class Initialized
INFO - 2023-08-31 07:43:00 --> Router Class Initialized
INFO - 2023-08-31 07:43:00 --> Output Class Initialized
INFO - 2023-08-31 07:43:00 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:00 --> Input Class Initialized
INFO - 2023-08-31 07:43:00 --> Language Class Initialized
ERROR - 2023-08-31 07:43:00 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 07:43:00 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:00 --> Router Class Initialized
DEBUG - 2023-08-31 07:43:00 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:00 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:00 --> Output Class Initialized
INFO - 2023-08-31 07:43:00 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:00 --> Input Class Initialized
INFO - 2023-08-31 07:43:00 --> Language Class Initialized
ERROR - 2023-08-31 07:43:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:00 --> Input Class Initialized
INFO - 2023-08-31 07:43:00 --> Language Class Initialized
ERROR - 2023-08-31 07:43:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:00 --> URI Class Initialized
INFO - 2023-08-31 07:43:00 --> Router Class Initialized
INFO - 2023-08-31 07:43:00 --> Output Class Initialized
INFO - 2023-08-31 07:43:00 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:00 --> Input Class Initialized
INFO - 2023-08-31 07:43:00 --> Language Class Initialized
ERROR - 2023-08-31 07:43:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:00 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:00 --> URI Class Initialized
INFO - 2023-08-31 07:43:00 --> Router Class Initialized
INFO - 2023-08-31 07:43:00 --> Config Class Initialized
INFO - 2023-08-31 07:43:00 --> Config Class Initialized
INFO - 2023-08-31 07:43:01 --> Hooks Class Initialized
INFO - 2023-08-31 07:43:01 --> Config Class Initialized
INFO - 2023-08-31 07:43:01 --> Output Class Initialized
INFO - 2023-08-31 07:43:01 --> Hooks Class Initialized
INFO - 2023-08-31 07:43:01 --> Config Class Initialized
DEBUG - 2023-08-31 07:43:01 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:01 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:01 --> Hooks Class Initialized
INFO - 2023-08-31 07:43:01 --> Security Class Initialized
INFO - 2023-08-31 07:43:01 --> URI Class Initialized
INFO - 2023-08-31 07:43:01 --> Config Class Initialized
DEBUG - 2023-08-31 07:43:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:01 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:01 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:01 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:01 --> URI Class Initialized
INFO - 2023-08-31 07:43:01 --> Router Class Initialized
INFO - 2023-08-31 07:43:01 --> Output Class Initialized
INFO - 2023-08-31 07:43:01 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:01 --> Input Class Initialized
INFO - 2023-08-31 07:43:01 --> Language Class Initialized
ERROR - 2023-08-31 07:43:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:01 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:01 --> URI Class Initialized
INFO - 2023-08-31 07:43:01 --> Router Class Initialized
INFO - 2023-08-31 07:43:01 --> Input Class Initialized
DEBUG - 2023-08-31 07:43:01 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:01 --> Router Class Initialized
INFO - 2023-08-31 07:43:01 --> Output Class Initialized
INFO - 2023-08-31 07:43:01 --> Output Class Initialized
INFO - 2023-08-31 07:43:01 --> Hooks Class Initialized
INFO - 2023-08-31 07:43:01 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:01 --> URI Class Initialized
INFO - 2023-08-31 07:43:01 --> Config Class Initialized
INFO - 2023-08-31 07:43:01 --> Language Class Initialized
INFO - 2023-08-31 07:43:01 --> Security Class Initialized
INFO - 2023-08-31 07:43:01 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:01 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:01 --> Hooks Class Initialized
ERROR - 2023-08-31 07:43:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:01 --> Router Class Initialized
DEBUG - 2023-08-31 07:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:01 --> Input Class Initialized
DEBUG - 2023-08-31 07:43:01 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:01 --> Language Class Initialized
INFO - 2023-08-31 07:43:01 --> Config Class Initialized
INFO - 2023-08-31 07:43:01 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:01 --> Input Class Initialized
ERROR - 2023-08-31 07:43:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:01 --> Output Class Initialized
INFO - 2023-08-31 07:43:01 --> Security Class Initialized
INFO - 2023-08-31 07:43:01 --> Language Class Initialized
INFO - 2023-08-31 07:43:01 --> Hooks Class Initialized
INFO - 2023-08-31 07:43:01 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:01 --> URI Class Initialized
DEBUG - 2023-08-31 07:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:01 --> Config Class Initialized
DEBUG - 2023-08-31 07:43:01 --> UTF-8 Support Enabled
ERROR - 2023-08-31 07:43:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:01 --> Router Class Initialized
INFO - 2023-08-31 07:43:01 --> URI Class Initialized
INFO - 2023-08-31 07:43:01 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:01 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:01 --> Router Class Initialized
INFO - 2023-08-31 07:43:01 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:01 --> URI Class Initialized
INFO - 2023-08-31 07:43:01 --> Input Class Initialized
INFO - 2023-08-31 07:43:01 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:01 --> Output Class Initialized
INFO - 2023-08-31 07:43:01 --> Language Class Initialized
INFO - 2023-08-31 07:43:01 --> Output Class Initialized
INFO - 2023-08-31 07:43:01 --> Router Class Initialized
INFO - 2023-08-31 07:43:01 --> Output Class Initialized
ERROR - 2023-08-31 07:43:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:01 --> Config Class Initialized
INFO - 2023-08-31 07:43:01 --> Security Class Initialized
INFO - 2023-08-31 07:43:01 --> Security Class Initialized
INFO - 2023-08-31 07:43:01 --> URI Class Initialized
DEBUG - 2023-08-31 07:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:01 --> Hooks Class Initialized
INFO - 2023-08-31 07:43:01 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:01 --> Input Class Initialized
DEBUG - 2023-08-31 07:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 07:43:01 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:01 --> Input Class Initialized
INFO - 2023-08-31 07:43:02 --> Language Class Initialized
INFO - 2023-08-31 07:43:02 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:02 --> Router Class Initialized
INFO - 2023-08-31 07:43:02 --> Config Class Initialized
INFO - 2023-08-31 07:43:02 --> Input Class Initialized
INFO - 2023-08-31 07:43:02 --> Hooks Class Initialized
INFO - 2023-08-31 07:43:02 --> URI Class Initialized
ERROR - 2023-08-31 07:43:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:02 --> Language Class Initialized
INFO - 2023-08-31 07:43:02 --> Language Class Initialized
INFO - 2023-08-31 07:43:02 --> Output Class Initialized
DEBUG - 2023-08-31 07:43:02 --> UTF-8 Support Enabled
ERROR - 2023-08-31 07:43:02 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-31 07:43:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:02 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:02 --> Security Class Initialized
INFO - 2023-08-31 07:43:02 --> Config Class Initialized
INFO - 2023-08-31 07:43:02 --> Router Class Initialized
INFO - 2023-08-31 07:43:02 --> Config Class Initialized
INFO - 2023-08-31 07:43:02 --> Output Class Initialized
INFO - 2023-08-31 07:43:02 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:02 --> URI Class Initialized
INFO - 2023-08-31 07:43:02 --> Security Class Initialized
INFO - 2023-08-31 07:43:02 --> Hooks Class Initialized
INFO - 2023-08-31 07:43:02 --> Config Class Initialized
DEBUG - 2023-08-31 07:43:02 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:02 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:02 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:43:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:02 --> Input Class Initialized
INFO - 2023-08-31 07:43:02 --> Router Class Initialized
INFO - 2023-08-31 07:43:02 --> Output Class Initialized
INFO - 2023-08-31 07:43:02 --> Language Class Initialized
INFO - 2023-08-31 07:43:02 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:02 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:02 --> URI Class Initialized
INFO - 2023-08-31 07:43:02 --> Router Class Initialized
INFO - 2023-08-31 07:43:02 --> Output Class Initialized
INFO - 2023-08-31 07:43:02 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:02 --> Input Class Initialized
INFO - 2023-08-31 07:43:02 --> Language Class Initialized
ERROR - 2023-08-31 07:43:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:02 --> Input Class Initialized
ERROR - 2023-08-31 07:43:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:02 --> URI Class Initialized
INFO - 2023-08-31 07:43:02 --> Language Class Initialized
INFO - 2023-08-31 07:43:02 --> URI Class Initialized
INFO - 2023-08-31 07:43:02 --> Router Class Initialized
ERROR - 2023-08-31 07:43:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:02 --> Security Class Initialized
INFO - 2023-08-31 07:43:02 --> Output Class Initialized
DEBUG - 2023-08-31 07:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:02 --> Security Class Initialized
INFO - 2023-08-31 07:43:02 --> Input Class Initialized
DEBUG - 2023-08-31 07:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:02 --> Language Class Initialized
INFO - 2023-08-31 07:43:02 --> Input Class Initialized
ERROR - 2023-08-31 07:43:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:02 --> Language Class Initialized
ERROR - 2023-08-31 07:43:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:02 --> Config Class Initialized
INFO - 2023-08-31 07:43:02 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:02 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:02 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:02 --> URI Class Initialized
INFO - 2023-08-31 07:43:02 --> Router Class Initialized
INFO - 2023-08-31 07:43:02 --> Output Class Initialized
INFO - 2023-08-31 07:43:02 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:02 --> Input Class Initialized
INFO - 2023-08-31 07:43:02 --> Language Class Initialized
ERROR - 2023-08-31 07:43:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:02 --> Router Class Initialized
INFO - 2023-08-31 07:43:02 --> Output Class Initialized
INFO - 2023-08-31 07:43:02 --> Security Class Initialized
INFO - 2023-08-31 07:43:03 --> Config Class Initialized
INFO - 2023-08-31 07:43:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:03 --> URI Class Initialized
INFO - 2023-08-31 07:43:03 --> Router Class Initialized
INFO - 2023-08-31 07:43:03 --> Output Class Initialized
INFO - 2023-08-31 07:43:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:03 --> Input Class Initialized
INFO - 2023-08-31 07:43:03 --> Language Class Initialized
ERROR - 2023-08-31 07:43:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:03 --> Config Class Initialized
INFO - 2023-08-31 07:43:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:03 --> URI Class Initialized
INFO - 2023-08-31 07:43:03 --> Router Class Initialized
INFO - 2023-08-31 07:43:03 --> Output Class Initialized
INFO - 2023-08-31 07:43:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:03 --> Input Class Initialized
INFO - 2023-08-31 07:43:03 --> Language Class Initialized
ERROR - 2023-08-31 07:43:03 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:03 --> Input Class Initialized
INFO - 2023-08-31 07:43:03 --> Config Class Initialized
INFO - 2023-08-31 07:43:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:03 --> URI Class Initialized
INFO - 2023-08-31 07:43:03 --> Config Class Initialized
INFO - 2023-08-31 07:43:03 --> Config Class Initialized
INFO - 2023-08-31 07:43:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:03 --> URI Class Initialized
INFO - 2023-08-31 07:43:03 --> Router Class Initialized
INFO - 2023-08-31 07:43:03 --> Output Class Initialized
INFO - 2023-08-31 07:43:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:03 --> Input Class Initialized
INFO - 2023-08-31 07:43:03 --> Language Class Initialized
ERROR - 2023-08-31 07:43:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:03 --> Language Class Initialized
INFO - 2023-08-31 07:43:03 --> Config Class Initialized
INFO - 2023-08-31 07:43:03 --> Router Class Initialized
INFO - 2023-08-31 07:43:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:03 --> URI Class Initialized
INFO - 2023-08-31 07:43:03 --> Router Class Initialized
INFO - 2023-08-31 07:43:03 --> Output Class Initialized
INFO - 2023-08-31 07:43:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:03 --> Input Class Initialized
INFO - 2023-08-31 07:43:03 --> Language Class Initialized
ERROR - 2023-08-31 07:43:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:03 --> Output Class Initialized
INFO - 2023-08-31 07:43:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:03 --> Input Class Initialized
INFO - 2023-08-31 07:43:03 --> Language Class Initialized
ERROR - 2023-08-31 07:43:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:03 --> Config Class Initialized
ERROR - 2023-08-31 07:43:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:03 --> URI Class Initialized
INFO - 2023-08-31 07:43:03 --> Router Class Initialized
INFO - 2023-08-31 07:43:03 --> Output Class Initialized
INFO - 2023-08-31 07:43:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:03 --> Input Class Initialized
INFO - 2023-08-31 07:43:03 --> Language Class Initialized
ERROR - 2023-08-31 07:43:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:03 --> Hooks Class Initialized
INFO - 2023-08-31 07:43:03 --> Config Class Initialized
INFO - 2023-08-31 07:43:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:03 --> URI Class Initialized
INFO - 2023-08-31 07:43:03 --> Router Class Initialized
INFO - 2023-08-31 07:43:03 --> Output Class Initialized
INFO - 2023-08-31 07:43:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:03 --> Input Class Initialized
INFO - 2023-08-31 07:43:03 --> Language Class Initialized
ERROR - 2023-08-31 07:43:03 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 07:43:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:03 --> URI Class Initialized
INFO - 2023-08-31 07:43:03 --> Config Class Initialized
INFO - 2023-08-31 07:43:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:03 --> URI Class Initialized
INFO - 2023-08-31 07:43:03 --> Router Class Initialized
INFO - 2023-08-31 07:43:03 --> Output Class Initialized
INFO - 2023-08-31 07:43:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:03 --> Input Class Initialized
INFO - 2023-08-31 07:43:03 --> Language Class Initialized
ERROR - 2023-08-31 07:43:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:03 --> Config Class Initialized
INFO - 2023-08-31 07:43:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:03 --> URI Class Initialized
INFO - 2023-08-31 07:43:03 --> Router Class Initialized
INFO - 2023-08-31 07:43:03 --> Output Class Initialized
INFO - 2023-08-31 07:43:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:03 --> Input Class Initialized
INFO - 2023-08-31 07:43:03 --> Language Class Initialized
ERROR - 2023-08-31 07:43:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:03 --> Router Class Initialized
INFO - 2023-08-31 07:43:03 --> Output Class Initialized
INFO - 2023-08-31 07:43:03 --> Config Class Initialized
INFO - 2023-08-31 07:43:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:03 --> URI Class Initialized
INFO - 2023-08-31 07:43:03 --> Router Class Initialized
INFO - 2023-08-31 07:43:03 --> Output Class Initialized
INFO - 2023-08-31 07:43:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:03 --> Input Class Initialized
INFO - 2023-08-31 07:43:03 --> Language Class Initialized
ERROR - 2023-08-31 07:43:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:03 --> Input Class Initialized
INFO - 2023-08-31 07:43:03 --> Language Class Initialized
ERROR - 2023-08-31 07:43:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:43:04 --> Config Class Initialized
INFO - 2023-08-31 07:43:04 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:43:04 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:43:04 --> Utf8 Class Initialized
INFO - 2023-08-31 07:43:04 --> URI Class Initialized
INFO - 2023-08-31 07:43:04 --> Router Class Initialized
INFO - 2023-08-31 07:43:04 --> Output Class Initialized
INFO - 2023-08-31 07:43:04 --> Security Class Initialized
DEBUG - 2023-08-31 07:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:43:04 --> Input Class Initialized
INFO - 2023-08-31 07:43:04 --> Language Class Initialized
ERROR - 2023-08-31 07:43:04 --> 404 Page Not Found: admin/Services_cards/images
INFO - 2023-08-31 07:45:26 --> Config Class Initialized
INFO - 2023-08-31 07:45:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:45:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:27 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:27 --> URI Class Initialized
INFO - 2023-08-31 07:45:27 --> Router Class Initialized
INFO - 2023-08-31 07:45:27 --> Output Class Initialized
INFO - 2023-08-31 07:45:27 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:27 --> Input Class Initialized
INFO - 2023-08-31 07:45:27 --> Language Class Initialized
INFO - 2023-08-31 07:45:27 --> Loader Class Initialized
INFO - 2023-08-31 07:45:27 --> Helper loaded: url_helper
INFO - 2023-08-31 07:45:27 --> Helper loaded: file_helper
INFO - 2023-08-31 07:45:27 --> Database Driver Class Initialized
INFO - 2023-08-31 07:45:27 --> Email Class Initialized
DEBUG - 2023-08-31 07:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:45:27 --> Controller Class Initialized
INFO - 2023-08-31 07:45:27 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:45:27 --> Helper loaded: form_helper
INFO - 2023-08-31 07:45:27 --> Form Validation Class Initialized
INFO - 2023-08-31 07:45:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-31 07:45:27 --> Final output sent to browser
DEBUG - 2023-08-31 07:45:27 --> Total execution time: 0.5799
INFO - 2023-08-31 07:45:27 --> Config Class Initialized
INFO - 2023-08-31 07:45:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:45:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:28 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:28 --> URI Class Initialized
INFO - 2023-08-31 07:45:28 --> Router Class Initialized
INFO - 2023-08-31 07:45:28 --> Output Class Initialized
INFO - 2023-08-31 07:45:28 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:28 --> Input Class Initialized
INFO - 2023-08-31 07:45:28 --> Language Class Initialized
ERROR - 2023-08-31 07:45:28 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:45:28 --> Config Class Initialized
INFO - 2023-08-31 07:45:28 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:45:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:28 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:28 --> URI Class Initialized
INFO - 2023-08-31 07:45:28 --> Router Class Initialized
INFO - 2023-08-31 07:45:28 --> Output Class Initialized
INFO - 2023-08-31 07:45:28 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:28 --> Input Class Initialized
INFO - 2023-08-31 07:45:28 --> Language Class Initialized
ERROR - 2023-08-31 07:45:28 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:45:28 --> Config Class Initialized
INFO - 2023-08-31 07:45:28 --> Hooks Class Initialized
INFO - 2023-08-31 07:45:28 --> Config Class Initialized
INFO - 2023-08-31 07:45:28 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:45:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:28 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:28 --> URI Class Initialized
INFO - 2023-08-31 07:45:28 --> Router Class Initialized
INFO - 2023-08-31 07:45:28 --> Output Class Initialized
INFO - 2023-08-31 07:45:28 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:28 --> Input Class Initialized
INFO - 2023-08-31 07:45:28 --> Language Class Initialized
ERROR - 2023-08-31 07:45:28 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 07:45:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:28 --> Config Class Initialized
INFO - 2023-08-31 07:45:28 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:45:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:28 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:28 --> URI Class Initialized
INFO - 2023-08-31 07:45:28 --> Router Class Initialized
INFO - 2023-08-31 07:45:28 --> Output Class Initialized
INFO - 2023-08-31 07:45:28 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:28 --> Input Class Initialized
INFO - 2023-08-31 07:45:28 --> Language Class Initialized
ERROR - 2023-08-31 07:45:28 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:45:28 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:28 --> URI Class Initialized
INFO - 2023-08-31 07:45:28 --> Router Class Initialized
INFO - 2023-08-31 07:45:29 --> Output Class Initialized
INFO - 2023-08-31 07:45:29 --> Security Class Initialized
INFO - 2023-08-31 07:45:29 --> Config Class Initialized
INFO - 2023-08-31 07:45:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:45:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:29 --> URI Class Initialized
INFO - 2023-08-31 07:45:29 --> Router Class Initialized
INFO - 2023-08-31 07:45:29 --> Output Class Initialized
INFO - 2023-08-31 07:45:29 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:29 --> Input Class Initialized
INFO - 2023-08-31 07:45:29 --> Language Class Initialized
ERROR - 2023-08-31 07:45:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:45:29 --> Config Class Initialized
INFO - 2023-08-31 07:45:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:45:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:29 --> URI Class Initialized
INFO - 2023-08-31 07:45:29 --> Router Class Initialized
INFO - 2023-08-31 07:45:29 --> Output Class Initialized
INFO - 2023-08-31 07:45:29 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:29 --> Input Class Initialized
INFO - 2023-08-31 07:45:29 --> Language Class Initialized
ERROR - 2023-08-31 07:45:29 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:29 --> Input Class Initialized
INFO - 2023-08-31 07:45:29 --> Config Class Initialized
INFO - 2023-08-31 07:45:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:45:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:29 --> URI Class Initialized
INFO - 2023-08-31 07:45:29 --> Router Class Initialized
INFO - 2023-08-31 07:45:29 --> Output Class Initialized
INFO - 2023-08-31 07:45:29 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:29 --> Input Class Initialized
INFO - 2023-08-31 07:45:29 --> Language Class Initialized
ERROR - 2023-08-31 07:45:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:45:29 --> Config Class Initialized
INFO - 2023-08-31 07:45:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:45:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:29 --> URI Class Initialized
INFO - 2023-08-31 07:45:29 --> Router Class Initialized
INFO - 2023-08-31 07:45:29 --> Output Class Initialized
INFO - 2023-08-31 07:45:29 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:29 --> Input Class Initialized
INFO - 2023-08-31 07:45:29 --> Language Class Initialized
ERROR - 2023-08-31 07:45:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:45:29 --> Language Class Initialized
ERROR - 2023-08-31 07:45:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:45:29 --> Config Class Initialized
INFO - 2023-08-31 07:45:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:45:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:29 --> URI Class Initialized
INFO - 2023-08-31 07:45:29 --> Router Class Initialized
INFO - 2023-08-31 07:45:29 --> Output Class Initialized
INFO - 2023-08-31 07:45:29 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:29 --> Input Class Initialized
INFO - 2023-08-31 07:45:29 --> Language Class Initialized
ERROR - 2023-08-31 07:45:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:45:29 --> Config Class Initialized
INFO - 2023-08-31 07:45:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:45:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:29 --> URI Class Initialized
INFO - 2023-08-31 07:45:29 --> Router Class Initialized
INFO - 2023-08-31 07:45:29 --> Output Class Initialized
INFO - 2023-08-31 07:45:29 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:29 --> Input Class Initialized
INFO - 2023-08-31 07:45:29 --> Language Class Initialized
ERROR - 2023-08-31 07:45:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:45:29 --> Config Class Initialized
INFO - 2023-08-31 07:45:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:45:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:29 --> URI Class Initialized
INFO - 2023-08-31 07:45:29 --> Router Class Initialized
INFO - 2023-08-31 07:45:29 --> Output Class Initialized
INFO - 2023-08-31 07:45:29 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:29 --> Input Class Initialized
INFO - 2023-08-31 07:45:29 --> Language Class Initialized
ERROR - 2023-08-31 07:45:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:45:29 --> Config Class Initialized
INFO - 2023-08-31 07:45:29 --> Config Class Initialized
INFO - 2023-08-31 07:45:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:45:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:29 --> Hooks Class Initialized
INFO - 2023-08-31 07:45:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:29 --> URI Class Initialized
INFO - 2023-08-31 07:45:29 --> Router Class Initialized
INFO - 2023-08-31 07:45:29 --> Output Class Initialized
INFO - 2023-08-31 07:45:29 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:29 --> Input Class Initialized
INFO - 2023-08-31 07:45:29 --> Language Class Initialized
ERROR - 2023-08-31 07:45:29 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 07:45:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:29 --> URI Class Initialized
INFO - 2023-08-31 07:45:30 --> Router Class Initialized
INFO - 2023-08-31 07:45:30 --> Output Class Initialized
INFO - 2023-08-31 07:45:30 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:30 --> Input Class Initialized
INFO - 2023-08-31 07:45:30 --> Language Class Initialized
ERROR - 2023-08-31 07:45:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:45:30 --> Config Class Initialized
INFO - 2023-08-31 07:45:30 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:45:30 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:45:30 --> Utf8 Class Initialized
INFO - 2023-08-31 07:45:30 --> URI Class Initialized
INFO - 2023-08-31 07:45:30 --> Router Class Initialized
INFO - 2023-08-31 07:45:30 --> Output Class Initialized
INFO - 2023-08-31 07:45:30 --> Security Class Initialized
DEBUG - 2023-08-31 07:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:45:30 --> Input Class Initialized
INFO - 2023-08-31 07:45:30 --> Language Class Initialized
ERROR - 2023-08-31 07:45:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:42 --> Config Class Initialized
INFO - 2023-08-31 07:48:42 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:42 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:42 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:42 --> URI Class Initialized
INFO - 2023-08-31 07:48:43 --> Router Class Initialized
INFO - 2023-08-31 07:48:43 --> Output Class Initialized
INFO - 2023-08-31 07:48:43 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:43 --> Input Class Initialized
INFO - 2023-08-31 07:48:43 --> Language Class Initialized
INFO - 2023-08-31 07:48:43 --> Loader Class Initialized
INFO - 2023-08-31 07:48:43 --> Helper loaded: url_helper
INFO - 2023-08-31 07:48:43 --> Helper loaded: file_helper
INFO - 2023-08-31 07:48:43 --> Database Driver Class Initialized
INFO - 2023-08-31 07:48:43 --> Email Class Initialized
DEBUG - 2023-08-31 07:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:48:43 --> Controller Class Initialized
INFO - 2023-08-31 07:48:43 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:48:43 --> Helper loaded: form_helper
INFO - 2023-08-31 07:48:43 --> Form Validation Class Initialized
INFO - 2023-08-31 07:48:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-31 07:48:43 --> Final output sent to browser
DEBUG - 2023-08-31 07:48:43 --> Total execution time: 0.7833
INFO - 2023-08-31 07:48:44 --> Config Class Initialized
INFO - 2023-08-31 07:48:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:44 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:44 --> URI Class Initialized
INFO - 2023-08-31 07:48:44 --> Router Class Initialized
INFO - 2023-08-31 07:48:44 --> Output Class Initialized
INFO - 2023-08-31 07:48:44 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:44 --> Input Class Initialized
INFO - 2023-08-31 07:48:44 --> Language Class Initialized
ERROR - 2023-08-31 07:48:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:44 --> Config Class Initialized
INFO - 2023-08-31 07:48:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:44 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:44 --> URI Class Initialized
INFO - 2023-08-31 07:48:44 --> Router Class Initialized
INFO - 2023-08-31 07:48:44 --> Output Class Initialized
INFO - 2023-08-31 07:48:44 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:44 --> Input Class Initialized
INFO - 2023-08-31 07:48:44 --> Language Class Initialized
ERROR - 2023-08-31 07:48:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:44 --> Config Class Initialized
INFO - 2023-08-31 07:48:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:44 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:44 --> URI Class Initialized
INFO - 2023-08-31 07:48:44 --> Router Class Initialized
INFO - 2023-08-31 07:48:44 --> Output Class Initialized
INFO - 2023-08-31 07:48:44 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:44 --> Input Class Initialized
INFO - 2023-08-31 07:48:44 --> Language Class Initialized
ERROR - 2023-08-31 07:48:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:44 --> Config Class Initialized
INFO - 2023-08-31 07:48:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:44 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:44 --> URI Class Initialized
INFO - 2023-08-31 07:48:44 --> Router Class Initialized
INFO - 2023-08-31 07:48:44 --> Output Class Initialized
INFO - 2023-08-31 07:48:44 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:44 --> Input Class Initialized
INFO - 2023-08-31 07:48:44 --> Language Class Initialized
ERROR - 2023-08-31 07:48:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:44 --> Config Class Initialized
INFO - 2023-08-31 07:48:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:44 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:44 --> URI Class Initialized
INFO - 2023-08-31 07:48:44 --> Router Class Initialized
INFO - 2023-08-31 07:48:44 --> Output Class Initialized
INFO - 2023-08-31 07:48:44 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:44 --> Input Class Initialized
INFO - 2023-08-31 07:48:44 --> Language Class Initialized
ERROR - 2023-08-31 07:48:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:44 --> Config Class Initialized
INFO - 2023-08-31 07:48:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:44 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:44 --> URI Class Initialized
INFO - 2023-08-31 07:48:44 --> Router Class Initialized
INFO - 2023-08-31 07:48:44 --> Output Class Initialized
INFO - 2023-08-31 07:48:44 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:44 --> Input Class Initialized
INFO - 2023-08-31 07:48:44 --> Language Class Initialized
ERROR - 2023-08-31 07:48:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:44 --> Config Class Initialized
INFO - 2023-08-31 07:48:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:44 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:44 --> URI Class Initialized
INFO - 2023-08-31 07:48:44 --> Router Class Initialized
INFO - 2023-08-31 07:48:44 --> Output Class Initialized
INFO - 2023-08-31 07:48:44 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:44 --> Input Class Initialized
INFO - 2023-08-31 07:48:44 --> Language Class Initialized
ERROR - 2023-08-31 07:48:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:44 --> Config Class Initialized
INFO - 2023-08-31 07:48:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:44 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:44 --> URI Class Initialized
INFO - 2023-08-31 07:48:44 --> Router Class Initialized
INFO - 2023-08-31 07:48:44 --> Output Class Initialized
INFO - 2023-08-31 07:48:44 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:44 --> Input Class Initialized
INFO - 2023-08-31 07:48:44 --> Language Class Initialized
ERROR - 2023-08-31 07:48:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:44 --> Config Class Initialized
INFO - 2023-08-31 07:48:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:44 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:44 --> URI Class Initialized
INFO - 2023-08-31 07:48:44 --> Router Class Initialized
INFO - 2023-08-31 07:48:44 --> Output Class Initialized
INFO - 2023-08-31 07:48:44 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:44 --> Input Class Initialized
INFO - 2023-08-31 07:48:44 --> Language Class Initialized
ERROR - 2023-08-31 07:48:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:45 --> Config Class Initialized
INFO - 2023-08-31 07:48:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:45 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:45 --> URI Class Initialized
INFO - 2023-08-31 07:48:45 --> Router Class Initialized
INFO - 2023-08-31 07:48:45 --> Output Class Initialized
INFO - 2023-08-31 07:48:45 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:45 --> Input Class Initialized
INFO - 2023-08-31 07:48:45 --> Language Class Initialized
ERROR - 2023-08-31 07:48:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:45 --> Config Class Initialized
INFO - 2023-08-31 07:48:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:45 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:45 --> URI Class Initialized
INFO - 2023-08-31 07:48:45 --> Router Class Initialized
INFO - 2023-08-31 07:48:45 --> Output Class Initialized
INFO - 2023-08-31 07:48:45 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:45 --> Input Class Initialized
INFO - 2023-08-31 07:48:45 --> Language Class Initialized
ERROR - 2023-08-31 07:48:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:45 --> Config Class Initialized
INFO - 2023-08-31 07:48:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:45 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:45 --> URI Class Initialized
INFO - 2023-08-31 07:48:45 --> Router Class Initialized
INFO - 2023-08-31 07:48:45 --> Output Class Initialized
INFO - 2023-08-31 07:48:45 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:45 --> Input Class Initialized
INFO - 2023-08-31 07:48:45 --> Language Class Initialized
ERROR - 2023-08-31 07:48:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:45 --> Config Class Initialized
INFO - 2023-08-31 07:48:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:45 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:45 --> URI Class Initialized
INFO - 2023-08-31 07:48:45 --> Router Class Initialized
INFO - 2023-08-31 07:48:45 --> Output Class Initialized
INFO - 2023-08-31 07:48:45 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:45 --> Input Class Initialized
INFO - 2023-08-31 07:48:45 --> Language Class Initialized
ERROR - 2023-08-31 07:48:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:45 --> Config Class Initialized
INFO - 2023-08-31 07:48:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:45 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:45 --> URI Class Initialized
INFO - 2023-08-31 07:48:45 --> Router Class Initialized
INFO - 2023-08-31 07:48:45 --> Output Class Initialized
INFO - 2023-08-31 07:48:45 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:45 --> Input Class Initialized
INFO - 2023-08-31 07:48:45 --> Language Class Initialized
ERROR - 2023-08-31 07:48:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:45 --> Config Class Initialized
INFO - 2023-08-31 07:48:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:45 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:45 --> URI Class Initialized
INFO - 2023-08-31 07:48:45 --> Router Class Initialized
INFO - 2023-08-31 07:48:45 --> Output Class Initialized
INFO - 2023-08-31 07:48:45 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:45 --> Input Class Initialized
INFO - 2023-08-31 07:48:45 --> Language Class Initialized
ERROR - 2023-08-31 07:48:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:48:53 --> Config Class Initialized
INFO - 2023-08-31 07:48:53 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:53 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:53 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:53 --> URI Class Initialized
INFO - 2023-08-31 07:48:53 --> Router Class Initialized
INFO - 2023-08-31 07:48:53 --> Output Class Initialized
INFO - 2023-08-31 07:48:53 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:54 --> Input Class Initialized
INFO - 2023-08-31 07:48:54 --> Language Class Initialized
INFO - 2023-08-31 07:48:54 --> Loader Class Initialized
INFO - 2023-08-31 07:48:54 --> Helper loaded: url_helper
INFO - 2023-08-31 07:48:54 --> Helper loaded: file_helper
INFO - 2023-08-31 07:48:54 --> Database Driver Class Initialized
INFO - 2023-08-31 07:48:54 --> Email Class Initialized
DEBUG - 2023-08-31 07:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:48:54 --> Controller Class Initialized
INFO - 2023-08-31 07:48:54 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:48:54 --> Helper loaded: form_helper
INFO - 2023-08-31 07:48:54 --> Form Validation Class Initialized
INFO - 2023-08-31 07:48:54 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-31 07:48:54 --> Final output sent to browser
DEBUG - 2023-08-31 07:48:54 --> Total execution time: 0.7649
INFO - 2023-08-31 07:48:56 --> Config Class Initialized
INFO - 2023-08-31 07:48:56 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:48:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:48:56 --> Utf8 Class Initialized
INFO - 2023-08-31 07:48:56 --> URI Class Initialized
INFO - 2023-08-31 07:48:56 --> Router Class Initialized
INFO - 2023-08-31 07:48:56 --> Output Class Initialized
INFO - 2023-08-31 07:48:56 --> Security Class Initialized
DEBUG - 2023-08-31 07:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:48:56 --> Input Class Initialized
INFO - 2023-08-31 07:48:56 --> Language Class Initialized
INFO - 2023-08-31 07:48:56 --> Loader Class Initialized
INFO - 2023-08-31 07:48:56 --> Helper loaded: url_helper
INFO - 2023-08-31 07:48:56 --> Helper loaded: file_helper
INFO - 2023-08-31 07:48:56 --> Database Driver Class Initialized
INFO - 2023-08-31 07:48:56 --> Email Class Initialized
DEBUG - 2023-08-31 07:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:48:56 --> Controller Class Initialized
INFO - 2023-08-31 07:48:56 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:48:56 --> Helper loaded: form_helper
INFO - 2023-08-31 07:48:56 --> Form Validation Class Initialized
INFO - 2023-08-31 07:48:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-31 07:48:56 --> Final output sent to browser
DEBUG - 2023-08-31 07:48:56 --> Total execution time: 0.0458
INFO - 2023-08-31 07:49:01 --> Config Class Initialized
INFO - 2023-08-31 07:49:01 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:01 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:01 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:01 --> URI Class Initialized
INFO - 2023-08-31 07:49:01 --> Router Class Initialized
INFO - 2023-08-31 07:49:01 --> Output Class Initialized
INFO - 2023-08-31 07:49:01 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:01 --> Input Class Initialized
INFO - 2023-08-31 07:49:01 --> Language Class Initialized
INFO - 2023-08-31 07:49:01 --> Loader Class Initialized
INFO - 2023-08-31 07:49:01 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:01 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:01 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:01 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:01 --> Controller Class Initialized
INFO - 2023-08-31 07:49:01 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:01 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:01 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-31 07:49:01 --> Config Class Initialized
INFO - 2023-08-31 07:49:01 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:01 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:01 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:01 --> URI Class Initialized
INFO - 2023-08-31 07:49:01 --> Router Class Initialized
INFO - 2023-08-31 07:49:01 --> Output Class Initialized
INFO - 2023-08-31 07:49:01 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:01 --> Input Class Initialized
INFO - 2023-08-31 07:49:01 --> Language Class Initialized
INFO - 2023-08-31 07:49:01 --> Loader Class Initialized
INFO - 2023-08-31 07:49:01 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:01 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:01 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:01 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:01 --> Controller Class Initialized
INFO - 2023-08-31 07:49:01 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:01 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:01 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-31 07:49:01 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:01 --> Total execution time: 0.0832
INFO - 2023-08-31 07:49:01 --> Config Class Initialized
INFO - 2023-08-31 07:49:01 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:01 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:01 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:01 --> URI Class Initialized
INFO - 2023-08-31 07:49:01 --> Router Class Initialized
INFO - 2023-08-31 07:49:01 --> Output Class Initialized
INFO - 2023-08-31 07:49:01 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:01 --> Input Class Initialized
INFO - 2023-08-31 07:49:01 --> Language Class Initialized
ERROR - 2023-08-31 07:49:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:02 --> Config Class Initialized
INFO - 2023-08-31 07:49:02 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:02 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:02 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:02 --> URI Class Initialized
INFO - 2023-08-31 07:49:02 --> Router Class Initialized
INFO - 2023-08-31 07:49:02 --> Output Class Initialized
INFO - 2023-08-31 07:49:02 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:02 --> Input Class Initialized
INFO - 2023-08-31 07:49:02 --> Language Class Initialized
ERROR - 2023-08-31 07:49:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:02 --> Config Class Initialized
INFO - 2023-08-31 07:49:02 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:02 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:02 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:02 --> URI Class Initialized
INFO - 2023-08-31 07:49:02 --> Router Class Initialized
INFO - 2023-08-31 07:49:02 --> Output Class Initialized
INFO - 2023-08-31 07:49:02 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:02 --> Input Class Initialized
INFO - 2023-08-31 07:49:02 --> Language Class Initialized
ERROR - 2023-08-31 07:49:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:03 --> Config Class Initialized
INFO - 2023-08-31 07:49:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:03 --> URI Class Initialized
INFO - 2023-08-31 07:49:03 --> Router Class Initialized
INFO - 2023-08-31 07:49:03 --> Output Class Initialized
INFO - 2023-08-31 07:49:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:03 --> Input Class Initialized
INFO - 2023-08-31 07:49:03 --> Language Class Initialized
ERROR - 2023-08-31 07:49:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:03 --> Config Class Initialized
INFO - 2023-08-31 07:49:03 --> Config Class Initialized
INFO - 2023-08-31 07:49:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:03 --> URI Class Initialized
INFO - 2023-08-31 07:49:03 --> Router Class Initialized
INFO - 2023-08-31 07:49:03 --> Output Class Initialized
INFO - 2023-08-31 07:49:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:03 --> Input Class Initialized
INFO - 2023-08-31 07:49:03 --> Language Class Initialized
ERROR - 2023-08-31 07:49:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:03 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:03 --> Config Class Initialized
INFO - 2023-08-31 07:49:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:03 --> URI Class Initialized
INFO - 2023-08-31 07:49:03 --> Router Class Initialized
INFO - 2023-08-31 07:49:03 --> Output Class Initialized
INFO - 2023-08-31 07:49:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:03 --> Input Class Initialized
INFO - 2023-08-31 07:49:03 --> Language Class Initialized
ERROR - 2023-08-31 07:49:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:03 --> Config Class Initialized
INFO - 2023-08-31 07:49:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:03 --> URI Class Initialized
INFO - 2023-08-31 07:49:03 --> Router Class Initialized
INFO - 2023-08-31 07:49:03 --> Output Class Initialized
INFO - 2023-08-31 07:49:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:03 --> Input Class Initialized
INFO - 2023-08-31 07:49:03 --> Language Class Initialized
ERROR - 2023-08-31 07:49:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:03 --> Config Class Initialized
INFO - 2023-08-31 07:49:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:03 --> URI Class Initialized
INFO - 2023-08-31 07:49:03 --> Router Class Initialized
INFO - 2023-08-31 07:49:03 --> Output Class Initialized
INFO - 2023-08-31 07:49:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:03 --> Input Class Initialized
INFO - 2023-08-31 07:49:03 --> Language Class Initialized
ERROR - 2023-08-31 07:49:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:03 --> Config Class Initialized
INFO - 2023-08-31 07:49:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:03 --> URI Class Initialized
INFO - 2023-08-31 07:49:03 --> Router Class Initialized
INFO - 2023-08-31 07:49:03 --> Output Class Initialized
INFO - 2023-08-31 07:49:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:03 --> Input Class Initialized
INFO - 2023-08-31 07:49:03 --> Language Class Initialized
ERROR - 2023-08-31 07:49:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:03 --> Config Class Initialized
INFO - 2023-08-31 07:49:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:03 --> URI Class Initialized
INFO - 2023-08-31 07:49:03 --> Router Class Initialized
INFO - 2023-08-31 07:49:03 --> Output Class Initialized
INFO - 2023-08-31 07:49:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:03 --> Input Class Initialized
INFO - 2023-08-31 07:49:03 --> Language Class Initialized
ERROR - 2023-08-31 07:49:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:03 --> Config Class Initialized
INFO - 2023-08-31 07:49:03 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:03 --> Config Class Initialized
INFO - 2023-08-31 07:49:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:03 --> URI Class Initialized
INFO - 2023-08-31 07:49:03 --> Router Class Initialized
INFO - 2023-08-31 07:49:03 --> Output Class Initialized
INFO - 2023-08-31 07:49:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:03 --> Input Class Initialized
INFO - 2023-08-31 07:49:03 --> Language Class Initialized
ERROR - 2023-08-31 07:49:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:03 --> Config Class Initialized
INFO - 2023-08-31 07:49:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:03 --> URI Class Initialized
INFO - 2023-08-31 07:49:03 --> Router Class Initialized
INFO - 2023-08-31 07:49:03 --> Output Class Initialized
INFO - 2023-08-31 07:49:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:03 --> Input Class Initialized
INFO - 2023-08-31 07:49:03 --> Language Class Initialized
ERROR - 2023-08-31 07:49:03 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 07:49:03 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:49:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:03 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:03 --> URI Class Initialized
INFO - 2023-08-31 07:49:03 --> URI Class Initialized
INFO - 2023-08-31 07:49:03 --> Router Class Initialized
INFO - 2023-08-31 07:49:03 --> Output Class Initialized
INFO - 2023-08-31 07:49:03 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:03 --> Input Class Initialized
INFO - 2023-08-31 07:49:03 --> Language Class Initialized
ERROR - 2023-08-31 07:49:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:03 --> Router Class Initialized
INFO - 2023-08-31 07:49:04 --> Output Class Initialized
INFO - 2023-08-31 07:49:04 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:04 --> Input Class Initialized
INFO - 2023-08-31 07:49:04 --> Language Class Initialized
ERROR - 2023-08-31 07:49:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:04 --> Config Class Initialized
INFO - 2023-08-31 07:49:04 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:04 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:04 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:04 --> URI Class Initialized
INFO - 2023-08-31 07:49:04 --> Router Class Initialized
INFO - 2023-08-31 07:49:04 --> Output Class Initialized
INFO - 2023-08-31 07:49:04 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:04 --> Input Class Initialized
INFO - 2023-08-31 07:49:04 --> Language Class Initialized
ERROR - 2023-08-31 07:49:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:05 --> Config Class Initialized
INFO - 2023-08-31 07:49:05 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:05 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:05 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:05 --> URI Class Initialized
INFO - 2023-08-31 07:49:05 --> Router Class Initialized
INFO - 2023-08-31 07:49:05 --> Output Class Initialized
INFO - 2023-08-31 07:49:05 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:05 --> Input Class Initialized
INFO - 2023-08-31 07:49:05 --> Language Class Initialized
INFO - 2023-08-31 07:49:05 --> Loader Class Initialized
INFO - 2023-08-31 07:49:05 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:05 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:05 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:05 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:05 --> Controller Class Initialized
INFO - 2023-08-31 07:49:05 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:05 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:05 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-31 07:49:05 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:05 --> Total execution time: 0.0480
INFO - 2023-08-31 07:49:06 --> Config Class Initialized
INFO - 2023-08-31 07:49:06 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:06 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:06 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:06 --> URI Class Initialized
INFO - 2023-08-31 07:49:06 --> Router Class Initialized
INFO - 2023-08-31 07:49:06 --> Output Class Initialized
INFO - 2023-08-31 07:49:06 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:06 --> Input Class Initialized
INFO - 2023-08-31 07:49:06 --> Language Class Initialized
INFO - 2023-08-31 07:49:06 --> Loader Class Initialized
INFO - 2023-08-31 07:49:06 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:06 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:06 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:06 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:06 --> Controller Class Initialized
INFO - 2023-08-31 07:49:06 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:06 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:06 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-31 07:49:06 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:06 --> Total execution time: 0.0423
INFO - 2023-08-31 07:49:10 --> Config Class Initialized
INFO - 2023-08-31 07:49:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:10 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:10 --> URI Class Initialized
INFO - 2023-08-31 07:49:10 --> Router Class Initialized
INFO - 2023-08-31 07:49:10 --> Output Class Initialized
INFO - 2023-08-31 07:49:10 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:10 --> Input Class Initialized
INFO - 2023-08-31 07:49:11 --> Language Class Initialized
INFO - 2023-08-31 07:49:11 --> Loader Class Initialized
INFO - 2023-08-31 07:49:11 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:11 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:11 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:11 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:11 --> Controller Class Initialized
INFO - 2023-08-31 07:49:11 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:11 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:11 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-31 07:49:11 --> Config Class Initialized
INFO - 2023-08-31 07:49:11 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:11 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:11 --> URI Class Initialized
INFO - 2023-08-31 07:49:11 --> Router Class Initialized
INFO - 2023-08-31 07:49:11 --> Output Class Initialized
INFO - 2023-08-31 07:49:11 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:11 --> Input Class Initialized
INFO - 2023-08-31 07:49:11 --> Language Class Initialized
INFO - 2023-08-31 07:49:11 --> Loader Class Initialized
INFO - 2023-08-31 07:49:11 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:11 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:11 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:11 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:11 --> Controller Class Initialized
INFO - 2023-08-31 07:49:11 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:11 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:11 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-31 07:49:11 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:11 --> Total execution time: 0.0448
INFO - 2023-08-31 07:49:11 --> Config Class Initialized
INFO - 2023-08-31 07:49:11 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:11 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:11 --> URI Class Initialized
INFO - 2023-08-31 07:49:11 --> Router Class Initialized
INFO - 2023-08-31 07:49:11 --> Output Class Initialized
INFO - 2023-08-31 07:49:11 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:11 --> Input Class Initialized
INFO - 2023-08-31 07:49:11 --> Language Class Initialized
ERROR - 2023-08-31 07:49:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:11 --> Config Class Initialized
INFO - 2023-08-31 07:49:11 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:11 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:11 --> URI Class Initialized
INFO - 2023-08-31 07:49:11 --> Router Class Initialized
INFO - 2023-08-31 07:49:11 --> Output Class Initialized
INFO - 2023-08-31 07:49:11 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:11 --> Input Class Initialized
INFO - 2023-08-31 07:49:11 --> Language Class Initialized
ERROR - 2023-08-31 07:49:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:11 --> Config Class Initialized
INFO - 2023-08-31 07:49:11 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:11 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:11 --> URI Class Initialized
INFO - 2023-08-31 07:49:11 --> Router Class Initialized
INFO - 2023-08-31 07:49:11 --> Output Class Initialized
INFO - 2023-08-31 07:49:11 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:11 --> Input Class Initialized
INFO - 2023-08-31 07:49:11 --> Language Class Initialized
ERROR - 2023-08-31 07:49:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:11 --> Config Class Initialized
INFO - 2023-08-31 07:49:11 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:11 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:11 --> URI Class Initialized
INFO - 2023-08-31 07:49:11 --> Router Class Initialized
INFO - 2023-08-31 07:49:11 --> Output Class Initialized
INFO - 2023-08-31 07:49:11 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:11 --> Input Class Initialized
INFO - 2023-08-31 07:49:11 --> Language Class Initialized
ERROR - 2023-08-31 07:49:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:11 --> Config Class Initialized
INFO - 2023-08-31 07:49:11 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:11 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:11 --> URI Class Initialized
INFO - 2023-08-31 07:49:11 --> Router Class Initialized
INFO - 2023-08-31 07:49:11 --> Output Class Initialized
INFO - 2023-08-31 07:49:11 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:11 --> Input Class Initialized
INFO - 2023-08-31 07:49:11 --> Language Class Initialized
ERROR - 2023-08-31 07:49:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:11 --> Config Class Initialized
INFO - 2023-08-31 07:49:11 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:11 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:11 --> URI Class Initialized
INFO - 2023-08-31 07:49:11 --> Router Class Initialized
INFO - 2023-08-31 07:49:11 --> Output Class Initialized
INFO - 2023-08-31 07:49:11 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:11 --> Input Class Initialized
INFO - 2023-08-31 07:49:11 --> Language Class Initialized
ERROR - 2023-08-31 07:49:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:12 --> Config Class Initialized
INFO - 2023-08-31 07:49:12 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:12 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:12 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:12 --> URI Class Initialized
INFO - 2023-08-31 07:49:12 --> Router Class Initialized
INFO - 2023-08-31 07:49:12 --> Output Class Initialized
INFO - 2023-08-31 07:49:12 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:12 --> Input Class Initialized
INFO - 2023-08-31 07:49:12 --> Language Class Initialized
ERROR - 2023-08-31 07:49:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:12 --> Config Class Initialized
INFO - 2023-08-31 07:49:12 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:12 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:12 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:12 --> URI Class Initialized
INFO - 2023-08-31 07:49:12 --> Router Class Initialized
INFO - 2023-08-31 07:49:12 --> Output Class Initialized
INFO - 2023-08-31 07:49:12 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:12 --> Input Class Initialized
INFO - 2023-08-31 07:49:12 --> Language Class Initialized
ERROR - 2023-08-31 07:49:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:12 --> Config Class Initialized
INFO - 2023-08-31 07:49:12 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:12 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:12 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:12 --> URI Class Initialized
INFO - 2023-08-31 07:49:12 --> Router Class Initialized
INFO - 2023-08-31 07:49:12 --> Output Class Initialized
INFO - 2023-08-31 07:49:12 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:12 --> Input Class Initialized
INFO - 2023-08-31 07:49:12 --> Language Class Initialized
INFO - 2023-08-31 07:49:12 --> Config Class Initialized
INFO - 2023-08-31 07:49:12 --> Config Class Initialized
ERROR - 2023-08-31 07:49:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:12 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:12 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:49:12 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:12 --> Config Class Initialized
INFO - 2023-08-31 07:49:12 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:12 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:12 --> URI Class Initialized
INFO - 2023-08-31 07:49:12 --> Router Class Initialized
INFO - 2023-08-31 07:49:12 --> Output Class Initialized
INFO - 2023-08-31 07:49:12 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:12 --> Input Class Initialized
INFO - 2023-08-31 07:49:12 --> Language Class Initialized
ERROR - 2023-08-31 07:49:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:12 --> Utf8 Class Initialized
DEBUG - 2023-08-31 07:49:12 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:13 --> URI Class Initialized
INFO - 2023-08-31 07:49:13 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:13 --> Router Class Initialized
INFO - 2023-08-31 07:49:13 --> Config Class Initialized
INFO - 2023-08-31 07:49:13 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:13 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:13 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:13 --> URI Class Initialized
INFO - 2023-08-31 07:49:13 --> Router Class Initialized
INFO - 2023-08-31 07:49:13 --> Output Class Initialized
INFO - 2023-08-31 07:49:13 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:13 --> Input Class Initialized
INFO - 2023-08-31 07:49:13 --> Language Class Initialized
ERROR - 2023-08-31 07:49:13 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:13 --> Output Class Initialized
INFO - 2023-08-31 07:49:13 --> Config Class Initialized
INFO - 2023-08-31 07:49:13 --> Security Class Initialized
INFO - 2023-08-31 07:49:13 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:13 --> URI Class Initialized
INFO - 2023-08-31 07:49:13 --> Input Class Initialized
INFO - 2023-08-31 07:49:13 --> Config Class Initialized
DEBUG - 2023-08-31 07:49:13 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:13 --> Language Class Initialized
INFO - 2023-08-31 07:49:13 --> Router Class Initialized
INFO - 2023-08-31 07:49:13 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:13 --> Output Class Initialized
INFO - 2023-08-31 07:49:13 --> Security Class Initialized
INFO - 2023-08-31 07:49:13 --> Hooks Class Initialized
ERROR - 2023-08-31 07:49:13 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 07:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:13 --> URI Class Initialized
INFO - 2023-08-31 07:49:13 --> Router Class Initialized
INFO - 2023-08-31 07:49:13 --> Output Class Initialized
INFO - 2023-08-31 07:49:13 --> Input Class Initialized
INFO - 2023-08-31 07:49:13 --> Language Class Initialized
DEBUG - 2023-08-31 07:49:13 --> UTF-8 Support Enabled
ERROR - 2023-08-31 07:49:13 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:13 --> Security Class Initialized
INFO - 2023-08-31 07:49:13 --> Utf8 Class Initialized
DEBUG - 2023-08-31 07:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:13 --> URI Class Initialized
INFO - 2023-08-31 07:49:13 --> Input Class Initialized
INFO - 2023-08-31 07:49:13 --> Router Class Initialized
INFO - 2023-08-31 07:49:14 --> Language Class Initialized
ERROR - 2023-08-31 07:49:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:14 --> Output Class Initialized
INFO - 2023-08-31 07:49:14 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:14 --> Input Class Initialized
INFO - 2023-08-31 07:49:14 --> Language Class Initialized
ERROR - 2023-08-31 07:49:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:14 --> Config Class Initialized
INFO - 2023-08-31 07:49:14 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:14 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:14 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:15 --> URI Class Initialized
INFO - 2023-08-31 07:49:15 --> Router Class Initialized
INFO - 2023-08-31 07:49:15 --> Output Class Initialized
INFO - 2023-08-31 07:49:15 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:15 --> Input Class Initialized
INFO - 2023-08-31 07:49:15 --> Language Class Initialized
INFO - 2023-08-31 07:49:15 --> Loader Class Initialized
INFO - 2023-08-31 07:49:15 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:15 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:15 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:15 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:15 --> Controller Class Initialized
INFO - 2023-08-31 07:49:15 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:15 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:15 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:15 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-31 07:49:15 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:15 --> Total execution time: 0.7419
INFO - 2023-08-31 07:49:18 --> Config Class Initialized
INFO - 2023-08-31 07:49:18 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:18 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:18 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:18 --> URI Class Initialized
INFO - 2023-08-31 07:49:18 --> Router Class Initialized
INFO - 2023-08-31 07:49:18 --> Output Class Initialized
INFO - 2023-08-31 07:49:18 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:18 --> Input Class Initialized
INFO - 2023-08-31 07:49:18 --> Language Class Initialized
INFO - 2023-08-31 07:49:18 --> Loader Class Initialized
INFO - 2023-08-31 07:49:18 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:18 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:18 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:18 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:19 --> Controller Class Initialized
INFO - 2023-08-31 07:49:19 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:19 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:19 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:19 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-31 07:49:19 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:19 --> Total execution time: 0.9882
INFO - 2023-08-31 07:49:23 --> Config Class Initialized
INFO - 2023-08-31 07:49:23 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:23 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:23 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:23 --> URI Class Initialized
INFO - 2023-08-31 07:49:23 --> Router Class Initialized
INFO - 2023-08-31 07:49:23 --> Output Class Initialized
INFO - 2023-08-31 07:49:23 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:23 --> Input Class Initialized
INFO - 2023-08-31 07:49:23 --> Language Class Initialized
INFO - 2023-08-31 07:49:23 --> Loader Class Initialized
INFO - 2023-08-31 07:49:23 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:23 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:23 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:23 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:23 --> Controller Class Initialized
INFO - 2023-08-31 07:49:23 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:23 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:23 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-31 07:49:24 --> Config Class Initialized
INFO - 2023-08-31 07:49:24 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:24 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:24 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:24 --> URI Class Initialized
INFO - 2023-08-31 07:49:24 --> Router Class Initialized
INFO - 2023-08-31 07:49:24 --> Output Class Initialized
INFO - 2023-08-31 07:49:24 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:24 --> Input Class Initialized
INFO - 2023-08-31 07:49:24 --> Language Class Initialized
INFO - 2023-08-31 07:49:24 --> Loader Class Initialized
INFO - 2023-08-31 07:49:24 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:24 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:24 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:24 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:24 --> Controller Class Initialized
INFO - 2023-08-31 07:49:24 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:24 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:24 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-31 07:49:24 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:24 --> Total execution time: 0.7293
INFO - 2023-08-31 07:49:25 --> Config Class Initialized
INFO - 2023-08-31 07:49:25 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:25 --> Config Class Initialized
INFO - 2023-08-31 07:49:25 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:25 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:25 --> Config Class Initialized
INFO - 2023-08-31 07:49:25 --> Config Class Initialized
DEBUG - 2023-08-31 07:49:25 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:25 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:25 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:25 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:25 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:25 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:25 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:25 --> URI Class Initialized
INFO - 2023-08-31 07:49:25 --> URI Class Initialized
DEBUG - 2023-08-31 07:49:25 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:25 --> Router Class Initialized
INFO - 2023-08-31 07:49:25 --> Router Class Initialized
INFO - 2023-08-31 07:49:25 --> Output Class Initialized
INFO - 2023-08-31 07:49:25 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:25 --> URI Class Initialized
INFO - 2023-08-31 07:49:25 --> Output Class Initialized
INFO - 2023-08-31 07:49:25 --> Router Class Initialized
INFO - 2023-08-31 07:49:25 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:25 --> URI Class Initialized
INFO - 2023-08-31 07:49:26 --> Input Class Initialized
INFO - 2023-08-31 07:49:26 --> Security Class Initialized
INFO - 2023-08-31 07:49:26 --> Output Class Initialized
INFO - 2023-08-31 07:49:26 --> Security Class Initialized
INFO - 2023-08-31 07:49:26 --> Language Class Initialized
INFO - 2023-08-31 07:49:26 --> Router Class Initialized
DEBUG - 2023-08-31 07:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:26 --> Output Class Initialized
INFO - 2023-08-31 07:49:26 --> Input Class Initialized
DEBUG - 2023-08-31 07:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-31 07:49:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:26 --> Security Class Initialized
INFO - 2023-08-31 07:49:26 --> Input Class Initialized
INFO - 2023-08-31 07:49:26 --> Language Class Initialized
DEBUG - 2023-08-31 07:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:26 --> Language Class Initialized
ERROR - 2023-08-31 07:49:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:26 --> Input Class Initialized
INFO - 2023-08-31 07:49:26 --> Config Class Initialized
INFO - 2023-08-31 07:49:26 --> Language Class Initialized
ERROR - 2023-08-31 07:49:26 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-31 07:49:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:26 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:26 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:26 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:26 --> URI Class Initialized
INFO - 2023-08-31 07:49:26 --> Config Class Initialized
INFO - 2023-08-31 07:49:26 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:26 --> Config Class Initialized
INFO - 2023-08-31 07:49:26 --> Router Class Initialized
INFO - 2023-08-31 07:49:26 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:26 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:26 --> Output Class Initialized
INFO - 2023-08-31 07:49:26 --> Utf8 Class Initialized
DEBUG - 2023-08-31 07:49:26 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:26 --> URI Class Initialized
INFO - 2023-08-31 07:49:26 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:26 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:26 --> URI Class Initialized
INFO - 2023-08-31 07:49:26 --> Router Class Initialized
INFO - 2023-08-31 07:49:27 --> Output Class Initialized
INFO - 2023-08-31 07:49:27 --> Security Class Initialized
INFO - 2023-08-31 07:49:27 --> Input Class Initialized
INFO - 2023-08-31 07:49:27 --> Language Class Initialized
DEBUG - 2023-08-31 07:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:27 --> Router Class Initialized
INFO - 2023-08-31 07:49:27 --> Output Class Initialized
ERROR - 2023-08-31 07:49:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:27 --> Input Class Initialized
INFO - 2023-08-31 07:49:27 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:27 --> Language Class Initialized
INFO - 2023-08-31 07:49:27 --> Input Class Initialized
ERROR - 2023-08-31 07:49:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:27 --> Language Class Initialized
ERROR - 2023-08-31 07:49:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:27 --> Config Class Initialized
INFO - 2023-08-31 07:49:27 --> Config Class Initialized
INFO - 2023-08-31 07:49:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:27 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:27 --> URI Class Initialized
INFO - 2023-08-31 07:49:27 --> Router Class Initialized
INFO - 2023-08-31 07:49:27 --> Output Class Initialized
INFO - 2023-08-31 07:49:27 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:27 --> Input Class Initialized
INFO - 2023-08-31 07:49:27 --> Language Class Initialized
ERROR - 2023-08-31 07:49:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:27 --> Config Class Initialized
INFO - 2023-08-31 07:49:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:27 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:27 --> URI Class Initialized
INFO - 2023-08-31 07:49:27 --> Router Class Initialized
INFO - 2023-08-31 07:49:27 --> Output Class Initialized
INFO - 2023-08-31 07:49:27 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:27 --> Input Class Initialized
INFO - 2023-08-31 07:49:27 --> Language Class Initialized
ERROR - 2023-08-31 07:49:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:27 --> Config Class Initialized
INFO - 2023-08-31 07:49:27 --> Config Class Initialized
INFO - 2023-08-31 07:49:27 --> Config Class Initialized
INFO - 2023-08-31 07:49:27 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:27 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:49:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:27 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:27 --> Config Class Initialized
INFO - 2023-08-31 07:49:27 --> Config Class Initialized
INFO - 2023-08-31 07:49:27 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:27 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:27 --> URI Class Initialized
DEBUG - 2023-08-31 07:49:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:27 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:27 --> URI Class Initialized
INFO - 2023-08-31 07:49:27 --> Router Class Initialized
INFO - 2023-08-31 07:49:27 --> Output Class Initialized
INFO - 2023-08-31 07:49:27 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:27 --> Input Class Initialized
INFO - 2023-08-31 07:49:27 --> Language Class Initialized
ERROR - 2023-08-31 07:49:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:27 --> Router Class Initialized
INFO - 2023-08-31 07:49:27 --> URI Class Initialized
INFO - 2023-08-31 07:49:27 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:27 --> Output Class Initialized
INFO - 2023-08-31 07:49:28 --> Security Class Initialized
INFO - 2023-08-31 07:49:28 --> URI Class Initialized
INFO - 2023-08-31 07:49:28 --> Config Class Initialized
INFO - 2023-08-31 07:49:28 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:28 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:28 --> URI Class Initialized
DEBUG - 2023-08-31 07:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 07:49:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:28 --> Router Class Initialized
INFO - 2023-08-31 07:49:28 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:28 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:28 --> Input Class Initialized
INFO - 2023-08-31 07:49:28 --> Router Class Initialized
INFO - 2023-08-31 07:49:28 --> Router Class Initialized
INFO - 2023-08-31 07:49:28 --> Language Class Initialized
INFO - 2023-08-31 07:49:28 --> Output Class Initialized
INFO - 2023-08-31 07:49:28 --> Security Class Initialized
INFO - 2023-08-31 07:49:28 --> URI Class Initialized
INFO - 2023-08-31 07:49:28 --> Router Class Initialized
DEBUG - 2023-08-31 07:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-31 07:49:28 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:28 --> URI Class Initialized
INFO - 2023-08-31 07:49:28 --> Output Class Initialized
INFO - 2023-08-31 07:49:28 --> Output Class Initialized
INFO - 2023-08-31 07:49:28 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:28 --> Input Class Initialized
INFO - 2023-08-31 07:49:28 --> Language Class Initialized
ERROR - 2023-08-31 07:49:28 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:28 --> Input Class Initialized
INFO - 2023-08-31 07:49:28 --> Security Class Initialized
INFO - 2023-08-31 07:49:28 --> Output Class Initialized
INFO - 2023-08-31 07:49:28 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 07:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:28 --> Language Class Initialized
INFO - 2023-08-31 07:49:28 --> Router Class Initialized
INFO - 2023-08-31 07:49:28 --> Input Class Initialized
INFO - 2023-08-31 07:49:28 --> Output Class Initialized
INFO - 2023-08-31 07:49:28 --> Input Class Initialized
ERROR - 2023-08-31 07:49:28 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:28 --> Language Class Initialized
INFO - 2023-08-31 07:49:28 --> Security Class Initialized
INFO - 2023-08-31 07:49:28 --> Language Class Initialized
INFO - 2023-08-31 07:49:28 --> Loader Class Initialized
ERROR - 2023-08-31 07:49:28 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 07:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:28 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:28 --> Input Class Initialized
INFO - 2023-08-31 07:49:28 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:28 --> Language Class Initialized
INFO - 2023-08-31 07:49:28 --> Database Driver Class Initialized
ERROR - 2023-08-31 07:49:28 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:28 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:28 --> Controller Class Initialized
INFO - 2023-08-31 07:49:28 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:28 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:28 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:28 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-31 07:49:28 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:29 --> Total execution time: 0.8288
INFO - 2023-08-31 07:49:29 --> Config Class Initialized
INFO - 2023-08-31 07:49:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:29 --> URI Class Initialized
INFO - 2023-08-31 07:49:29 --> Router Class Initialized
INFO - 2023-08-31 07:49:29 --> Output Class Initialized
INFO - 2023-08-31 07:49:29 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:29 --> Input Class Initialized
INFO - 2023-08-31 07:49:30 --> Language Class Initialized
INFO - 2023-08-31 07:49:30 --> Loader Class Initialized
INFO - 2023-08-31 07:49:30 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:30 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:30 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:30 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:30 --> Controller Class Initialized
INFO - 2023-08-31 07:49:30 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:31 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:31 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-31 07:49:31 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:31 --> Total execution time: 1.5192
INFO - 2023-08-31 07:49:33 --> Config Class Initialized
INFO - 2023-08-31 07:49:33 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:33 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:33 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:33 --> URI Class Initialized
INFO - 2023-08-31 07:49:33 --> Router Class Initialized
INFO - 2023-08-31 07:49:33 --> Output Class Initialized
INFO - 2023-08-31 07:49:33 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:34 --> Input Class Initialized
INFO - 2023-08-31 07:49:34 --> Language Class Initialized
INFO - 2023-08-31 07:49:34 --> Loader Class Initialized
INFO - 2023-08-31 07:49:34 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:34 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:34 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:34 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:34 --> Controller Class Initialized
INFO - 2023-08-31 07:49:34 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:34 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:34 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-31 07:49:34 --> Config Class Initialized
INFO - 2023-08-31 07:49:34 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:34 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:34 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:34 --> URI Class Initialized
INFO - 2023-08-31 07:49:34 --> Router Class Initialized
INFO - 2023-08-31 07:49:34 --> Output Class Initialized
INFO - 2023-08-31 07:49:34 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:34 --> Input Class Initialized
INFO - 2023-08-31 07:49:34 --> Language Class Initialized
INFO - 2023-08-31 07:49:34 --> Loader Class Initialized
INFO - 2023-08-31 07:49:34 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:34 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:34 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:35 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:35 --> Controller Class Initialized
INFO - 2023-08-31 07:49:35 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:35 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:35 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:35 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-31 07:49:35 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:35 --> Total execution time: 0.7675
INFO - 2023-08-31 07:49:35 --> Config Class Initialized
INFO - 2023-08-31 07:49:35 --> Config Class Initialized
INFO - 2023-08-31 07:49:35 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:35 --> Config Class Initialized
INFO - 2023-08-31 07:49:35 --> Config Class Initialized
INFO - 2023-08-31 07:49:36 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:49:36 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:36 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:36 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 07:49:36 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:36 --> Config Class Initialized
INFO - 2023-08-31 07:49:36 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:36 --> URI Class Initialized
INFO - 2023-08-31 07:49:36 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:36 --> Config Class Initialized
INFO - 2023-08-31 07:49:36 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:36 --> Router Class Initialized
DEBUG - 2023-08-31 07:49:36 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:36 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:36 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:36 --> Output Class Initialized
INFO - 2023-08-31 07:49:36 --> URI Class Initialized
INFO - 2023-08-31 07:49:36 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:36 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:36 --> URI Class Initialized
INFO - 2023-08-31 07:49:36 --> Router Class Initialized
DEBUG - 2023-08-31 07:49:36 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:36 --> Output Class Initialized
INFO - 2023-08-31 07:49:36 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:36 --> Input Class Initialized
INFO - 2023-08-31 07:49:36 --> Language Class Initialized
ERROR - 2023-08-31 07:49:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:36 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:36 --> URI Class Initialized
INFO - 2023-08-31 07:49:36 --> Router Class Initialized
INFO - 2023-08-31 07:49:36 --> Router Class Initialized
INFO - 2023-08-31 07:49:36 --> Output Class Initialized
INFO - 2023-08-31 07:49:36 --> URI Class Initialized
INFO - 2023-08-31 07:49:36 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:36 --> Input Class Initialized
INFO - 2023-08-31 07:49:36 --> Language Class Initialized
ERROR - 2023-08-31 07:49:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:36 --> Output Class Initialized
INFO - 2023-08-31 07:49:36 --> Router Class Initialized
INFO - 2023-08-31 07:49:36 --> Security Class Initialized
INFO - 2023-08-31 07:49:36 --> URI Class Initialized
INFO - 2023-08-31 07:49:36 --> Security Class Initialized
INFO - 2023-08-31 07:49:36 --> Router Class Initialized
INFO - 2023-08-31 07:49:36 --> Output Class Initialized
INFO - 2023-08-31 07:49:36 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:36 --> Input Class Initialized
INFO - 2023-08-31 07:49:36 --> Language Class Initialized
ERROR - 2023-08-31 07:49:36 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 07:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 07:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:36 --> Output Class Initialized
INFO - 2023-08-31 07:49:36 --> Input Class Initialized
INFO - 2023-08-31 07:49:36 --> Input Class Initialized
INFO - 2023-08-31 07:49:36 --> Language Class Initialized
INFO - 2023-08-31 07:49:36 --> Language Class Initialized
ERROR - 2023-08-31 07:49:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:36 --> Security Class Initialized
ERROR - 2023-08-31 07:49:36 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 07:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:36 --> Input Class Initialized
INFO - 2023-08-31 07:49:36 --> Language Class Initialized
ERROR - 2023-08-31 07:49:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:36 --> Config Class Initialized
INFO - 2023-08-31 07:49:37 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:37 --> Config Class Initialized
DEBUG - 2023-08-31 07:49:37 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:37 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:37 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:37 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:37 --> URI Class Initialized
INFO - 2023-08-31 07:49:37 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:37 --> Router Class Initialized
INFO - 2023-08-31 07:49:37 --> URI Class Initialized
INFO - 2023-08-31 07:49:37 --> Output Class Initialized
INFO - 2023-08-31 07:49:37 --> Router Class Initialized
INFO - 2023-08-31 07:49:37 --> Security Class Initialized
INFO - 2023-08-31 07:49:37 --> Output Class Initialized
INFO - 2023-08-31 07:49:37 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 07:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:37 --> Input Class Initialized
INFO - 2023-08-31 07:49:37 --> Input Class Initialized
INFO - 2023-08-31 07:49:37 --> Language Class Initialized
INFO - 2023-08-31 07:49:37 --> Language Class Initialized
ERROR - 2023-08-31 07:49:37 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-31 07:49:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:37 --> Config Class Initialized
INFO - 2023-08-31 07:49:37 --> Config Class Initialized
INFO - 2023-08-31 07:49:37 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:37 --> Config Class Initialized
INFO - 2023-08-31 07:49:37 --> Config Class Initialized
DEBUG - 2023-08-31 07:49:37 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:37 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:37 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:37 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:37 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:37 --> Utf8 Class Initialized
DEBUG - 2023-08-31 07:49:37 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:37 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:37 --> URI Class Initialized
INFO - 2023-08-31 07:49:37 --> URI Class Initialized
INFO - 2023-08-31 07:49:37 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:37 --> Router Class Initialized
DEBUG - 2023-08-31 07:49:37 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:37 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:37 --> URI Class Initialized
INFO - 2023-08-31 07:49:37 --> Router Class Initialized
INFO - 2023-08-31 07:49:37 --> Output Class Initialized
INFO - 2023-08-31 07:49:37 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:37 --> Input Class Initialized
INFO - 2023-08-31 07:49:37 --> Language Class Initialized
ERROR - 2023-08-31 07:49:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:37 --> URI Class Initialized
INFO - 2023-08-31 07:49:37 --> Router Class Initialized
INFO - 2023-08-31 07:49:37 --> Router Class Initialized
INFO - 2023-08-31 07:49:37 --> Output Class Initialized
INFO - 2023-08-31 07:49:37 --> Security Class Initialized
INFO - 2023-08-31 07:49:37 --> Output Class Initialized
INFO - 2023-08-31 07:49:37 --> Output Class Initialized
DEBUG - 2023-08-31 07:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:37 --> Security Class Initialized
INFO - 2023-08-31 07:49:37 --> Input Class Initialized
INFO - 2023-08-31 07:49:37 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 07:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:37 --> Input Class Initialized
INFO - 2023-08-31 07:49:37 --> Input Class Initialized
INFO - 2023-08-31 07:49:38 --> Language Class Initialized
ERROR - 2023-08-31 07:49:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:38 --> Language Class Initialized
INFO - 2023-08-31 07:49:38 --> Language Class Initialized
ERROR - 2023-08-31 07:49:38 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-31 07:49:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:38 --> Config Class Initialized
INFO - 2023-08-31 07:49:38 --> Config Class Initialized
INFO - 2023-08-31 07:49:38 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:38 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:38 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:38 --> Config Class Initialized
INFO - 2023-08-31 07:49:38 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:38 --> Utf8 Class Initialized
DEBUG - 2023-08-31 07:49:38 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:38 --> URI Class Initialized
INFO - 2023-08-31 07:49:38 --> Utf8 Class Initialized
DEBUG - 2023-08-31 07:49:38 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:38 --> URI Class Initialized
INFO - 2023-08-31 07:49:38 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:38 --> Router Class Initialized
INFO - 2023-08-31 07:49:38 --> Output Class Initialized
INFO - 2023-08-31 07:49:38 --> Router Class Initialized
INFO - 2023-08-31 07:49:38 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:38 --> URI Class Initialized
INFO - 2023-08-31 07:49:38 --> Output Class Initialized
INFO - 2023-08-31 07:49:38 --> Router Class Initialized
INFO - 2023-08-31 07:49:38 --> Output Class Initialized
INFO - 2023-08-31 07:49:38 --> Security Class Initialized
INFO - 2023-08-31 07:49:38 --> Input Class Initialized
DEBUG - 2023-08-31 07:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:38 --> Language Class Initialized
INFO - 2023-08-31 07:49:38 --> Security Class Initialized
INFO - 2023-08-31 07:49:38 --> Input Class Initialized
DEBUG - 2023-08-31 07:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:38 --> Language Class Initialized
ERROR - 2023-08-31 07:49:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:38 --> Input Class Initialized
ERROR - 2023-08-31 07:49:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:38 --> Language Class Initialized
ERROR - 2023-08-31 07:49:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:39 --> Config Class Initialized
INFO - 2023-08-31 07:49:39 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:39 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:39 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:39 --> URI Class Initialized
INFO - 2023-08-31 07:49:39 --> Router Class Initialized
INFO - 2023-08-31 07:49:39 --> Output Class Initialized
INFO - 2023-08-31 07:49:39 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:39 --> Input Class Initialized
INFO - 2023-08-31 07:49:39 --> Language Class Initialized
INFO - 2023-08-31 07:49:39 --> Loader Class Initialized
INFO - 2023-08-31 07:49:39 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:39 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:39 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:39 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:39 --> Controller Class Initialized
INFO - 2023-08-31 07:49:39 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:39 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:39 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-31 07:49:39 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:39 --> Total execution time: 0.4234
INFO - 2023-08-31 07:49:41 --> Config Class Initialized
INFO - 2023-08-31 07:49:41 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:41 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:41 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:41 --> URI Class Initialized
INFO - 2023-08-31 07:49:41 --> Router Class Initialized
INFO - 2023-08-31 07:49:41 --> Output Class Initialized
INFO - 2023-08-31 07:49:41 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:41 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:41 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-31 07:49:41 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:41 --> Total execution time: 0.7599
INFO - 2023-08-31 07:49:44 --> Config Class Initialized
INFO - 2023-08-31 07:49:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:44 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:44 --> URI Class Initialized
INFO - 2023-08-31 07:49:44 --> Router Class Initialized
INFO - 2023-08-31 07:49:44 --> Output Class Initialized
INFO - 2023-08-31 07:49:44 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:44 --> Input Class Initialized
INFO - 2023-08-31 07:49:44 --> Language Class Initialized
INFO - 2023-08-31 07:49:44 --> Loader Class Initialized
INFO - 2023-08-31 07:49:44 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:44 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:44 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:44 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:44 --> Controller Class Initialized
INFO - 2023-08-31 07:49:44 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:44 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:44 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-31 07:49:45 --> Config Class Initialized
INFO - 2023-08-31 07:49:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:45 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:45 --> URI Class Initialized
INFO - 2023-08-31 07:49:45 --> Router Class Initialized
INFO - 2023-08-31 07:49:45 --> Output Class Initialized
INFO - 2023-08-31 07:49:45 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:45 --> Input Class Initialized
INFO - 2023-08-31 07:49:45 --> Language Class Initialized
INFO - 2023-08-31 07:49:45 --> Loader Class Initialized
INFO - 2023-08-31 07:49:45 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:45 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:45 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:45 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:45 --> Controller Class Initialized
INFO - 2023-08-31 07:49:45 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:45 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:45 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-31 07:49:45 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:45 --> Total execution time: 0.4076
INFO - 2023-08-31 07:49:46 --> Config Class Initialized
INFO - 2023-08-31 07:49:46 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:46 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:46 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:46 --> URI Class Initialized
INFO - 2023-08-31 07:49:46 --> Config Class Initialized
INFO - 2023-08-31 07:49:46 --> Hooks Class Initialized
INFO - 2023-08-31 07:49:46 --> Router Class Initialized
INFO - 2023-08-31 07:49:46 --> Output Class Initialized
INFO - 2023-08-31 07:49:46 --> Config Class Initialized
INFO - 2023-08-31 07:49:46 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:46 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:46 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:46 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:46 --> URI Class Initialized
INFO - 2023-08-31 07:49:46 --> Input Class Initialized
DEBUG - 2023-08-31 07:49:46 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:46 --> Router Class Initialized
INFO - 2023-08-31 07:49:46 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:46 --> Language Class Initialized
INFO - 2023-08-31 07:49:46 --> URI Class Initialized
ERROR - 2023-08-31 07:49:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:46 --> Output Class Initialized
INFO - 2023-08-31 07:49:46 --> Security Class Initialized
INFO - 2023-08-31 07:49:46 --> Router Class Initialized
DEBUG - 2023-08-31 07:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:46 --> Output Class Initialized
INFO - 2023-08-31 07:49:46 --> Input Class Initialized
INFO - 2023-08-31 07:49:46 --> Security Class Initialized
INFO - 2023-08-31 07:49:46 --> Language Class Initialized
DEBUG - 2023-08-31 07:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-31 07:49:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:46 --> Input Class Initialized
INFO - 2023-08-31 07:49:46 --> Language Class Initialized
ERROR - 2023-08-31 07:49:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:46 --> Config Class Initialized
INFO - 2023-08-31 07:49:46 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:46 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:46 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:46 --> URI Class Initialized
INFO - 2023-08-31 07:49:46 --> Router Class Initialized
INFO - 2023-08-31 07:49:46 --> Output Class Initialized
INFO - 2023-08-31 07:49:46 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:46 --> Input Class Initialized
INFO - 2023-08-31 07:49:46 --> Language Class Initialized
ERROR - 2023-08-31 07:49:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:46 --> Config Class Initialized
INFO - 2023-08-31 07:49:46 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:46 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:46 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:46 --> URI Class Initialized
INFO - 2023-08-31 07:49:46 --> Router Class Initialized
INFO - 2023-08-31 07:49:46 --> Output Class Initialized
INFO - 2023-08-31 07:49:46 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:46 --> Input Class Initialized
INFO - 2023-08-31 07:49:46 --> Language Class Initialized
ERROR - 2023-08-31 07:49:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:46 --> Config Class Initialized
INFO - 2023-08-31 07:49:46 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:46 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:46 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:46 --> URI Class Initialized
INFO - 2023-08-31 07:49:46 --> Router Class Initialized
INFO - 2023-08-31 07:49:46 --> Output Class Initialized
INFO - 2023-08-31 07:49:46 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:46 --> Input Class Initialized
INFO - 2023-08-31 07:49:46 --> Language Class Initialized
ERROR - 2023-08-31 07:49:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:46 --> Config Class Initialized
INFO - 2023-08-31 07:49:46 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:46 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:46 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:46 --> URI Class Initialized
INFO - 2023-08-31 07:49:46 --> Router Class Initialized
INFO - 2023-08-31 07:49:46 --> Output Class Initialized
INFO - 2023-08-31 07:49:46 --> Security Class Initialized
INFO - 2023-08-31 07:49:46 --> Config Class Initialized
INFO - 2023-08-31 07:49:46 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:46 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:46 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:46 --> URI Class Initialized
INFO - 2023-08-31 07:49:46 --> Config Class Initialized
INFO - 2023-08-31 07:49:46 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:46 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:46 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:46 --> Router Class Initialized
INFO - 2023-08-31 07:49:46 --> Output Class Initialized
INFO - 2023-08-31 07:49:46 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:46 --> Input Class Initialized
INFO - 2023-08-31 07:49:46 --> Language Class Initialized
ERROR - 2023-08-31 07:49:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:46 --> URI Class Initialized
INFO - 2023-08-31 07:49:47 --> Router Class Initialized
DEBUG - 2023-08-31 07:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:47 --> Output Class Initialized
INFO - 2023-08-31 07:49:47 --> Input Class Initialized
INFO - 2023-08-31 07:49:47 --> Language Class Initialized
ERROR - 2023-08-31 07:49:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:47 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:47 --> Config Class Initialized
INFO - 2023-08-31 07:49:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:47 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:47 --> URI Class Initialized
INFO - 2023-08-31 07:49:47 --> Router Class Initialized
INFO - 2023-08-31 07:49:47 --> Output Class Initialized
INFO - 2023-08-31 07:49:47 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:47 --> Input Class Initialized
INFO - 2023-08-31 07:49:47 --> Language Class Initialized
ERROR - 2023-08-31 07:49:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:47 --> Config Class Initialized
INFO - 2023-08-31 07:49:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:47 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:47 --> URI Class Initialized
INFO - 2023-08-31 07:49:47 --> Router Class Initialized
INFO - 2023-08-31 07:49:47 --> Output Class Initialized
INFO - 2023-08-31 07:49:47 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:47 --> Input Class Initialized
INFO - 2023-08-31 07:49:47 --> Language Class Initialized
ERROR - 2023-08-31 07:49:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:47 --> Config Class Initialized
INFO - 2023-08-31 07:49:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:47 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:47 --> URI Class Initialized
INFO - 2023-08-31 07:49:47 --> Router Class Initialized
INFO - 2023-08-31 07:49:47 --> Output Class Initialized
INFO - 2023-08-31 07:49:47 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:47 --> Input Class Initialized
INFO - 2023-08-31 07:49:47 --> Language Class Initialized
ERROR - 2023-08-31 07:49:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:47 --> Config Class Initialized
INFO - 2023-08-31 07:49:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:47 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:47 --> URI Class Initialized
INFO - 2023-08-31 07:49:47 --> Router Class Initialized
INFO - 2023-08-31 07:49:47 --> Output Class Initialized
INFO - 2023-08-31 07:49:47 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:47 --> Input Class Initialized
INFO - 2023-08-31 07:49:47 --> Language Class Initialized
ERROR - 2023-08-31 07:49:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:47 --> Config Class Initialized
INFO - 2023-08-31 07:49:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:47 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:47 --> URI Class Initialized
INFO - 2023-08-31 07:49:47 --> Router Class Initialized
INFO - 2023-08-31 07:49:47 --> Output Class Initialized
INFO - 2023-08-31 07:49:47 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:47 --> Input Class Initialized
INFO - 2023-08-31 07:49:47 --> Language Class Initialized
ERROR - 2023-08-31 07:49:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:47 --> Input Class Initialized
INFO - 2023-08-31 07:49:47 --> Config Class Initialized
INFO - 2023-08-31 07:49:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:47 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:47 --> URI Class Initialized
INFO - 2023-08-31 07:49:47 --> Router Class Initialized
INFO - 2023-08-31 07:49:47 --> Output Class Initialized
INFO - 2023-08-31 07:49:47 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:47 --> Input Class Initialized
INFO - 2023-08-31 07:49:47 --> Language Class Initialized
ERROR - 2023-08-31 07:49:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:47 --> Language Class Initialized
ERROR - 2023-08-31 07:49:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:49 --> Config Class Initialized
INFO - 2023-08-31 07:49:49 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:49 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:49 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:49 --> URI Class Initialized
INFO - 2023-08-31 07:49:49 --> Router Class Initialized
INFO - 2023-08-31 07:49:49 --> Output Class Initialized
INFO - 2023-08-31 07:49:49 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:49 --> Input Class Initialized
INFO - 2023-08-31 07:49:49 --> Language Class Initialized
INFO - 2023-08-31 07:49:49 --> Loader Class Initialized
INFO - 2023-08-31 07:49:49 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:49 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:49 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:49 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:49 --> Controller Class Initialized
INFO - 2023-08-31 07:49:49 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:49 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:49 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-31 07:49:49 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:49 --> Total execution time: 0.0474
INFO - 2023-08-31 07:49:51 --> Config Class Initialized
INFO - 2023-08-31 07:49:51 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:51 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:51 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:51 --> URI Class Initialized
INFO - 2023-08-31 07:49:51 --> Router Class Initialized
INFO - 2023-08-31 07:49:51 --> Output Class Initialized
INFO - 2023-08-31 07:49:51 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:51 --> Input Class Initialized
INFO - 2023-08-31 07:49:51 --> Language Class Initialized
INFO - 2023-08-31 07:49:51 --> Loader Class Initialized
INFO - 2023-08-31 07:49:51 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:51 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:51 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:51 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:51 --> Controller Class Initialized
INFO - 2023-08-31 07:49:51 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:51 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:51 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-31 07:49:51 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:51 --> Total execution time: 0.0441
INFO - 2023-08-31 07:49:56 --> Config Class Initialized
INFO - 2023-08-31 07:49:56 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:56 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:56 --> URI Class Initialized
INFO - 2023-08-31 07:49:56 --> Router Class Initialized
INFO - 2023-08-31 07:49:56 --> Output Class Initialized
INFO - 2023-08-31 07:49:56 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:56 --> Input Class Initialized
INFO - 2023-08-31 07:49:56 --> Language Class Initialized
INFO - 2023-08-31 07:49:56 --> Loader Class Initialized
INFO - 2023-08-31 07:49:56 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:56 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:56 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:56 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:56 --> Controller Class Initialized
INFO - 2023-08-31 07:49:56 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:56 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:56 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-31 07:49:56 --> Config Class Initialized
INFO - 2023-08-31 07:49:56 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:56 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:56 --> URI Class Initialized
INFO - 2023-08-31 07:49:56 --> Router Class Initialized
INFO - 2023-08-31 07:49:56 --> Output Class Initialized
INFO - 2023-08-31 07:49:56 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:56 --> Input Class Initialized
INFO - 2023-08-31 07:49:56 --> Language Class Initialized
INFO - 2023-08-31 07:49:56 --> Loader Class Initialized
INFO - 2023-08-31 07:49:56 --> Helper loaded: url_helper
INFO - 2023-08-31 07:49:56 --> Helper loaded: file_helper
INFO - 2023-08-31 07:49:56 --> Database Driver Class Initialized
INFO - 2023-08-31 07:49:56 --> Email Class Initialized
DEBUG - 2023-08-31 07:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:49:56 --> Controller Class Initialized
INFO - 2023-08-31 07:49:56 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:49:56 --> Helper loaded: form_helper
INFO - 2023-08-31 07:49:56 --> Form Validation Class Initialized
INFO - 2023-08-31 07:49:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-31 07:49:56 --> Final output sent to browser
DEBUG - 2023-08-31 07:49:56 --> Total execution time: 0.0492
INFO - 2023-08-31 07:49:56 --> Config Class Initialized
INFO - 2023-08-31 07:49:56 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:56 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:56 --> URI Class Initialized
INFO - 2023-08-31 07:49:56 --> Router Class Initialized
INFO - 2023-08-31 07:49:56 --> Output Class Initialized
INFO - 2023-08-31 07:49:56 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:56 --> Input Class Initialized
INFO - 2023-08-31 07:49:56 --> Language Class Initialized
ERROR - 2023-08-31 07:49:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:56 --> Config Class Initialized
INFO - 2023-08-31 07:49:56 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:56 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:56 --> URI Class Initialized
INFO - 2023-08-31 07:49:56 --> Router Class Initialized
INFO - 2023-08-31 07:49:56 --> Output Class Initialized
INFO - 2023-08-31 07:49:56 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:56 --> Input Class Initialized
INFO - 2023-08-31 07:49:56 --> Language Class Initialized
ERROR - 2023-08-31 07:49:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:56 --> Config Class Initialized
INFO - 2023-08-31 07:49:56 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:56 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:56 --> URI Class Initialized
INFO - 2023-08-31 07:49:56 --> Router Class Initialized
INFO - 2023-08-31 07:49:56 --> Output Class Initialized
INFO - 2023-08-31 07:49:56 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:56 --> Input Class Initialized
INFO - 2023-08-31 07:49:56 --> Language Class Initialized
ERROR - 2023-08-31 07:49:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:56 --> Config Class Initialized
INFO - 2023-08-31 07:49:56 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:56 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:56 --> URI Class Initialized
INFO - 2023-08-31 07:49:56 --> Router Class Initialized
INFO - 2023-08-31 07:49:56 --> Output Class Initialized
INFO - 2023-08-31 07:49:56 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:56 --> Input Class Initialized
INFO - 2023-08-31 07:49:56 --> Language Class Initialized
ERROR - 2023-08-31 07:49:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:56 --> Config Class Initialized
INFO - 2023-08-31 07:49:56 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:56 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:56 --> URI Class Initialized
INFO - 2023-08-31 07:49:56 --> Router Class Initialized
INFO - 2023-08-31 07:49:56 --> Output Class Initialized
INFO - 2023-08-31 07:49:56 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:56 --> Input Class Initialized
INFO - 2023-08-31 07:49:56 --> Language Class Initialized
ERROR - 2023-08-31 07:49:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:56 --> Config Class Initialized
INFO - 2023-08-31 07:49:56 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:56 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:56 --> URI Class Initialized
INFO - 2023-08-31 07:49:56 --> Router Class Initialized
INFO - 2023-08-31 07:49:56 --> Output Class Initialized
INFO - 2023-08-31 07:49:56 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:56 --> Input Class Initialized
INFO - 2023-08-31 07:49:56 --> Language Class Initialized
ERROR - 2023-08-31 07:49:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:56 --> Config Class Initialized
INFO - 2023-08-31 07:49:56 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:56 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:56 --> URI Class Initialized
INFO - 2023-08-31 07:49:56 --> Router Class Initialized
INFO - 2023-08-31 07:49:56 --> Output Class Initialized
INFO - 2023-08-31 07:49:56 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:56 --> Input Class Initialized
INFO - 2023-08-31 07:49:56 --> Language Class Initialized
ERROR - 2023-08-31 07:49:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:57 --> Config Class Initialized
INFO - 2023-08-31 07:49:57 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:57 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:57 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:57 --> URI Class Initialized
INFO - 2023-08-31 07:49:57 --> Router Class Initialized
INFO - 2023-08-31 07:49:57 --> Output Class Initialized
INFO - 2023-08-31 07:49:57 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:57 --> Input Class Initialized
INFO - 2023-08-31 07:49:57 --> Language Class Initialized
ERROR - 2023-08-31 07:49:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:57 --> Config Class Initialized
INFO - 2023-08-31 07:49:57 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:57 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:57 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:57 --> URI Class Initialized
INFO - 2023-08-31 07:49:57 --> Router Class Initialized
INFO - 2023-08-31 07:49:57 --> Output Class Initialized
INFO - 2023-08-31 07:49:57 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:57 --> Input Class Initialized
INFO - 2023-08-31 07:49:57 --> Language Class Initialized
ERROR - 2023-08-31 07:49:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:57 --> Config Class Initialized
INFO - 2023-08-31 07:49:57 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:57 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:57 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:57 --> URI Class Initialized
INFO - 2023-08-31 07:49:57 --> Router Class Initialized
INFO - 2023-08-31 07:49:57 --> Output Class Initialized
INFO - 2023-08-31 07:49:57 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:57 --> Input Class Initialized
INFO - 2023-08-31 07:49:57 --> Language Class Initialized
ERROR - 2023-08-31 07:49:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:57 --> Config Class Initialized
INFO - 2023-08-31 07:49:57 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:57 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:57 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:58 --> URI Class Initialized
INFO - 2023-08-31 07:49:58 --> Router Class Initialized
INFO - 2023-08-31 07:49:58 --> Output Class Initialized
INFO - 2023-08-31 07:49:58 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:58 --> Input Class Initialized
INFO - 2023-08-31 07:49:58 --> Language Class Initialized
ERROR - 2023-08-31 07:49:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:58 --> Config Class Initialized
INFO - 2023-08-31 07:49:58 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:58 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:58 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:58 --> URI Class Initialized
INFO - 2023-08-31 07:49:58 --> Router Class Initialized
INFO - 2023-08-31 07:49:58 --> Output Class Initialized
INFO - 2023-08-31 07:49:58 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:58 --> Input Class Initialized
INFO - 2023-08-31 07:49:58 --> Language Class Initialized
ERROR - 2023-08-31 07:49:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:58 --> Config Class Initialized
INFO - 2023-08-31 07:49:58 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:58 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:58 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:58 --> URI Class Initialized
INFO - 2023-08-31 07:49:58 --> Router Class Initialized
INFO - 2023-08-31 07:49:58 --> Output Class Initialized
INFO - 2023-08-31 07:49:58 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:58 --> Input Class Initialized
INFO - 2023-08-31 07:49:58 --> Language Class Initialized
ERROR - 2023-08-31 07:49:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:58 --> Config Class Initialized
INFO - 2023-08-31 07:49:58 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:58 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:58 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:58 --> URI Class Initialized
INFO - 2023-08-31 07:49:58 --> Router Class Initialized
INFO - 2023-08-31 07:49:58 --> Output Class Initialized
INFO - 2023-08-31 07:49:58 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:58 --> Input Class Initialized
INFO - 2023-08-31 07:49:58 --> Language Class Initialized
ERROR - 2023-08-31 07:49:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:49:59 --> Config Class Initialized
INFO - 2023-08-31 07:49:59 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:49:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:49:59 --> Utf8 Class Initialized
INFO - 2023-08-31 07:49:59 --> URI Class Initialized
INFO - 2023-08-31 07:49:59 --> Router Class Initialized
INFO - 2023-08-31 07:49:59 --> Output Class Initialized
INFO - 2023-08-31 07:49:59 --> Security Class Initialized
DEBUG - 2023-08-31 07:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:49:59 --> Input Class Initialized
INFO - 2023-08-31 07:49:59 --> Language Class Initialized
ERROR - 2023-08-31 07:49:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:04 --> Config Class Initialized
INFO - 2023-08-31 07:50:04 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:04 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:04 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:04 --> URI Class Initialized
INFO - 2023-08-31 07:50:04 --> Router Class Initialized
INFO - 2023-08-31 07:50:04 --> Output Class Initialized
INFO - 2023-08-31 07:50:04 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:04 --> Input Class Initialized
INFO - 2023-08-31 07:50:04 --> Language Class Initialized
INFO - 2023-08-31 07:50:04 --> Loader Class Initialized
INFO - 2023-08-31 07:50:04 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:04 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:04 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:04 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:04 --> Controller Class Initialized
INFO - 2023-08-31 07:50:04 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:50:04 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:04 --> Form Validation Class Initialized
INFO - 2023-08-31 07:50:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-31 07:50:04 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:04 --> Total execution time: 0.0752
INFO - 2023-08-31 07:50:07 --> Config Class Initialized
INFO - 2023-08-31 07:50:07 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:07 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:07 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:07 --> URI Class Initialized
INFO - 2023-08-31 07:50:07 --> Router Class Initialized
INFO - 2023-08-31 07:50:07 --> Output Class Initialized
INFO - 2023-08-31 07:50:07 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:07 --> Input Class Initialized
INFO - 2023-08-31 07:50:07 --> Language Class Initialized
INFO - 2023-08-31 07:50:07 --> Loader Class Initialized
INFO - 2023-08-31 07:50:07 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:07 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:07 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:07 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:07 --> Controller Class Initialized
INFO - 2023-08-31 07:50:07 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:50:07 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:07 --> Form Validation Class Initialized
INFO - 2023-08-31 07:50:07 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-31 07:50:07 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:07 --> Total execution time: 0.0517
INFO - 2023-08-31 07:50:07 --> Config Class Initialized
INFO - 2023-08-31 07:50:07 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:07 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:07 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:07 --> URI Class Initialized
INFO - 2023-08-31 07:50:07 --> Router Class Initialized
INFO - 2023-08-31 07:50:07 --> Output Class Initialized
INFO - 2023-08-31 07:50:07 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:07 --> Input Class Initialized
INFO - 2023-08-31 07:50:07 --> Language Class Initialized
INFO - 2023-08-31 07:50:07 --> Loader Class Initialized
INFO - 2023-08-31 07:50:07 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:07 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:07 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:08 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:08 --> Controller Class Initialized
INFO - 2023-08-31 07:50:08 --> Model "Services_model" initialized
INFO - 2023-08-31 07:50:08 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:08 --> Form Validation Class Initialized
INFO - 2023-08-31 07:50:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 07:50:08 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:08 --> Total execution time: 0.2145
INFO - 2023-08-31 07:50:14 --> Config Class Initialized
INFO - 2023-08-31 07:50:14 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:14 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:14 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:14 --> URI Class Initialized
INFO - 2023-08-31 07:50:14 --> Router Class Initialized
INFO - 2023-08-31 07:50:14 --> Output Class Initialized
INFO - 2023-08-31 07:50:14 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:14 --> Input Class Initialized
INFO - 2023-08-31 07:50:14 --> Language Class Initialized
INFO - 2023-08-31 07:50:14 --> Loader Class Initialized
INFO - 2023-08-31 07:50:14 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:14 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:14 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:14 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:14 --> Controller Class Initialized
INFO - 2023-08-31 07:50:14 --> Model "Services_model" initialized
INFO - 2023-08-31 07:50:14 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:14 --> Form Validation Class Initialized
INFO - 2023-08-31 07:50:14 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 07:50:14 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:14 --> Total execution time: 0.0505
INFO - 2023-08-31 07:50:15 --> Config Class Initialized
INFO - 2023-08-31 07:50:15 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:15 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:15 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:15 --> URI Class Initialized
INFO - 2023-08-31 07:50:15 --> Router Class Initialized
INFO - 2023-08-31 07:50:15 --> Output Class Initialized
INFO - 2023-08-31 07:50:15 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:15 --> Input Class Initialized
INFO - 2023-08-31 07:50:15 --> Language Class Initialized
ERROR - 2023-08-31 07:50:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:15 --> Config Class Initialized
INFO - 2023-08-31 07:50:15 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:15 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:15 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:15 --> URI Class Initialized
INFO - 2023-08-31 07:50:15 --> Router Class Initialized
INFO - 2023-08-31 07:50:15 --> Output Class Initialized
INFO - 2023-08-31 07:50:15 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:15 --> Input Class Initialized
INFO - 2023-08-31 07:50:15 --> Language Class Initialized
ERROR - 2023-08-31 07:50:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:16 --> Config Class Initialized
INFO - 2023-08-31 07:50:16 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:16 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:16 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:16 --> URI Class Initialized
INFO - 2023-08-31 07:50:16 --> Router Class Initialized
INFO - 2023-08-31 07:50:16 --> Output Class Initialized
INFO - 2023-08-31 07:50:16 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:16 --> Input Class Initialized
INFO - 2023-08-31 07:50:16 --> Language Class Initialized
INFO - 2023-08-31 07:50:16 --> Loader Class Initialized
INFO - 2023-08-31 07:50:16 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:16 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:16 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:16 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:16 --> Controller Class Initialized
INFO - 2023-08-31 07:50:16 --> Model "Services_model" initialized
INFO - 2023-08-31 07:50:16 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:16 --> Form Validation Class Initialized
ERROR - 2023-08-31 07:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-31 07:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-31 07:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-31 07:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-31 07:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-31 07:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-31 07:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-31 07:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-31 07:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-31 07:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-31 07:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 140
ERROR - 2023-08-31 07:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 142
ERROR - 2023-08-31 07:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 144
INFO - 2023-08-31 07:50:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 07:50:16 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:16 --> Total execution time: 0.0651
INFO - 2023-08-31 07:50:16 --> Config Class Initialized
INFO - 2023-08-31 07:50:16 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:16 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:16 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:16 --> URI Class Initialized
INFO - 2023-08-31 07:50:16 --> Router Class Initialized
INFO - 2023-08-31 07:50:16 --> Output Class Initialized
INFO - 2023-08-31 07:50:16 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:16 --> Input Class Initialized
INFO - 2023-08-31 07:50:16 --> Language Class Initialized
INFO - 2023-08-31 07:50:16 --> Loader Class Initialized
INFO - 2023-08-31 07:50:16 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:16 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:16 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:16 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:16 --> Controller Class Initialized
INFO - 2023-08-31 07:50:16 --> Model "Services_model" initialized
INFO - 2023-08-31 07:50:16 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:16 --> Form Validation Class Initialized
INFO - 2023-08-31 07:50:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 07:50:16 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:16 --> Total execution time: 0.0551
INFO - 2023-08-31 07:50:20 --> Config Class Initialized
INFO - 2023-08-31 07:50:20 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:20 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:20 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:20 --> URI Class Initialized
INFO - 2023-08-31 07:50:20 --> Router Class Initialized
INFO - 2023-08-31 07:50:20 --> Output Class Initialized
INFO - 2023-08-31 07:50:20 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:20 --> Input Class Initialized
INFO - 2023-08-31 07:50:20 --> Language Class Initialized
INFO - 2023-08-31 07:50:20 --> Loader Class Initialized
INFO - 2023-08-31 07:50:20 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:20 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:20 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:20 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:20 --> Controller Class Initialized
INFO - 2023-08-31 07:50:20 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:50:20 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:20 --> Form Validation Class Initialized
INFO - 2023-08-31 07:50:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-31 07:50:20 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:20 --> Total execution time: 0.0493
INFO - 2023-08-31 07:50:23 --> Config Class Initialized
INFO - 2023-08-31 07:50:23 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:23 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:23 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:23 --> URI Class Initialized
INFO - 2023-08-31 07:50:23 --> Router Class Initialized
INFO - 2023-08-31 07:50:23 --> Output Class Initialized
INFO - 2023-08-31 07:50:23 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:24 --> Input Class Initialized
INFO - 2023-08-31 07:50:24 --> Language Class Initialized
INFO - 2023-08-31 07:50:24 --> Loader Class Initialized
INFO - 2023-08-31 07:50:24 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:24 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:24 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:24 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:24 --> Controller Class Initialized
INFO - 2023-08-31 07:50:24 --> Model "Services_model" initialized
INFO - 2023-08-31 07:50:24 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:24 --> Form Validation Class Initialized
INFO - 2023-08-31 07:50:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 07:50:24 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:24 --> Total execution time: 0.0538
INFO - 2023-08-31 07:50:29 --> Config Class Initialized
INFO - 2023-08-31 07:50:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:29 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:29 --> URI Class Initialized
INFO - 2023-08-31 07:50:29 --> Router Class Initialized
INFO - 2023-08-31 07:50:29 --> Output Class Initialized
INFO - 2023-08-31 07:50:29 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:29 --> Input Class Initialized
INFO - 2023-08-31 07:50:29 --> Language Class Initialized
INFO - 2023-08-31 07:50:29 --> Loader Class Initialized
INFO - 2023-08-31 07:50:29 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:29 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:29 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:29 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:29 --> Controller Class Initialized
INFO - 2023-08-31 07:50:29 --> Model "Services_model" initialized
INFO - 2023-08-31 07:50:29 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:29 --> Form Validation Class Initialized
INFO - 2023-08-31 07:50:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 07:50:29 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:29 --> Total execution time: 0.0542
INFO - 2023-08-31 07:50:30 --> Config Class Initialized
INFO - 2023-08-31 07:50:30 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:30 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:30 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:30 --> URI Class Initialized
INFO - 2023-08-31 07:50:30 --> Router Class Initialized
INFO - 2023-08-31 07:50:30 --> Output Class Initialized
INFO - 2023-08-31 07:50:30 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:30 --> Input Class Initialized
INFO - 2023-08-31 07:50:30 --> Language Class Initialized
ERROR - 2023-08-31 07:50:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:30 --> Config Class Initialized
INFO - 2023-08-31 07:50:30 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:30 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:30 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:30 --> URI Class Initialized
INFO - 2023-08-31 07:50:30 --> Router Class Initialized
INFO - 2023-08-31 07:50:30 --> Output Class Initialized
INFO - 2023-08-31 07:50:30 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:30 --> Input Class Initialized
INFO - 2023-08-31 07:50:30 --> Language Class Initialized
ERROR - 2023-08-31 07:50:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:31 --> Config Class Initialized
INFO - 2023-08-31 07:50:31 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:31 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:31 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:31 --> URI Class Initialized
INFO - 2023-08-31 07:50:31 --> Router Class Initialized
INFO - 2023-08-31 07:50:31 --> Output Class Initialized
INFO - 2023-08-31 07:50:31 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:31 --> Input Class Initialized
INFO - 2023-08-31 07:50:31 --> Language Class Initialized
INFO - 2023-08-31 07:50:31 --> Loader Class Initialized
INFO - 2023-08-31 07:50:31 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:32 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:32 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:32 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:32 --> Controller Class Initialized
INFO - 2023-08-31 07:50:32 --> Model "Services_model" initialized
INFO - 2023-08-31 07:50:32 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:32 --> Form Validation Class Initialized
ERROR - 2023-08-31 07:50:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-31 07:50:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-31 07:50:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-31 07:50:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-31 07:50:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-31 07:50:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-31 07:50:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-31 07:50:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-31 07:50:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-31 07:50:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-31 07:50:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 140
ERROR - 2023-08-31 07:50:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 142
ERROR - 2023-08-31 07:50:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 144
INFO - 2023-08-31 07:50:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 07:50:32 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:32 --> Total execution time: 0.0694
INFO - 2023-08-31 07:50:34 --> Config Class Initialized
INFO - 2023-08-31 07:50:34 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:34 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:34 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:34 --> URI Class Initialized
INFO - 2023-08-31 07:50:34 --> Router Class Initialized
INFO - 2023-08-31 07:50:34 --> Output Class Initialized
INFO - 2023-08-31 07:50:34 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:34 --> Input Class Initialized
INFO - 2023-08-31 07:50:34 --> Language Class Initialized
INFO - 2023-08-31 07:50:34 --> Loader Class Initialized
INFO - 2023-08-31 07:50:34 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:34 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:34 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:34 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:34 --> Controller Class Initialized
INFO - 2023-08-31 07:50:34 --> Model "Services_model" initialized
INFO - 2023-08-31 07:50:34 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:34 --> Form Validation Class Initialized
INFO - 2023-08-31 07:50:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 07:50:34 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:34 --> Total execution time: 0.0601
INFO - 2023-08-31 07:50:38 --> Config Class Initialized
INFO - 2023-08-31 07:50:38 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:38 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:38 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:38 --> URI Class Initialized
INFO - 2023-08-31 07:50:38 --> Router Class Initialized
INFO - 2023-08-31 07:50:38 --> Output Class Initialized
INFO - 2023-08-31 07:50:38 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:38 --> Input Class Initialized
INFO - 2023-08-31 07:50:38 --> Language Class Initialized
INFO - 2023-08-31 07:50:38 --> Loader Class Initialized
INFO - 2023-08-31 07:50:38 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:38 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:38 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:38 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:38 --> Controller Class Initialized
INFO - 2023-08-31 07:50:38 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:50:38 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:38 --> Form Validation Class Initialized
INFO - 2023-08-31 07:50:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-31 07:50:38 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:38 --> Total execution time: 0.0745
INFO - 2023-08-31 07:50:45 --> Config Class Initialized
INFO - 2023-08-31 07:50:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:45 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:45 --> URI Class Initialized
INFO - 2023-08-31 07:50:45 --> Router Class Initialized
INFO - 2023-08-31 07:50:45 --> Output Class Initialized
INFO - 2023-08-31 07:50:45 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:45 --> Input Class Initialized
INFO - 2023-08-31 07:50:45 --> Language Class Initialized
INFO - 2023-08-31 07:50:45 --> Loader Class Initialized
INFO - 2023-08-31 07:50:45 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:45 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:45 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:45 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:45 --> Controller Class Initialized
INFO - 2023-08-31 07:50:45 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:50:45 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:45 --> Form Validation Class Initialized
INFO - 2023-08-31 07:50:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-31 07:50:45 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:45 --> Total execution time: 0.0485
INFO - 2023-08-31 07:50:51 --> Config Class Initialized
INFO - 2023-08-31 07:50:51 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:51 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:51 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:51 --> URI Class Initialized
INFO - 2023-08-31 07:50:51 --> Router Class Initialized
INFO - 2023-08-31 07:50:51 --> Output Class Initialized
INFO - 2023-08-31 07:50:51 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:51 --> Input Class Initialized
INFO - 2023-08-31 07:50:51 --> Language Class Initialized
ERROR - 2023-08-31 07:50:51 --> 404 Page Not Found: admin/Services_cards/images
INFO - 2023-08-31 07:50:53 --> Config Class Initialized
INFO - 2023-08-31 07:50:53 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:53 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:53 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:53 --> URI Class Initialized
INFO - 2023-08-31 07:50:53 --> Router Class Initialized
INFO - 2023-08-31 07:50:53 --> Output Class Initialized
INFO - 2023-08-31 07:50:53 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:53 --> Input Class Initialized
INFO - 2023-08-31 07:50:53 --> Language Class Initialized
INFO - 2023-08-31 07:50:53 --> Loader Class Initialized
INFO - 2023-08-31 07:50:53 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:53 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:53 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:53 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:53 --> Controller Class Initialized
INFO - 2023-08-31 07:50:53 --> Model "Services_model" initialized
INFO - 2023-08-31 07:50:53 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:53 --> Form Validation Class Initialized
INFO - 2023-08-31 07:50:53 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 07:50:53 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:53 --> Total execution time: 0.0601
INFO - 2023-08-31 07:50:54 --> Config Class Initialized
INFO - 2023-08-31 07:50:54 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:54 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:54 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:54 --> URI Class Initialized
INFO - 2023-08-31 07:50:54 --> Router Class Initialized
INFO - 2023-08-31 07:50:54 --> Output Class Initialized
INFO - 2023-08-31 07:50:54 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:54 --> Input Class Initialized
INFO - 2023-08-31 07:50:54 --> Language Class Initialized
ERROR - 2023-08-31 07:50:54 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-31 07:50:58 --> Config Class Initialized
INFO - 2023-08-31 07:50:58 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:58 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:58 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:58 --> URI Class Initialized
INFO - 2023-08-31 07:50:58 --> Router Class Initialized
INFO - 2023-08-31 07:50:58 --> Output Class Initialized
INFO - 2023-08-31 07:50:58 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:58 --> Input Class Initialized
INFO - 2023-08-31 07:50:58 --> Language Class Initialized
INFO - 2023-08-31 07:50:58 --> Loader Class Initialized
INFO - 2023-08-31 07:50:58 --> Helper loaded: url_helper
INFO - 2023-08-31 07:50:58 --> Helper loaded: file_helper
INFO - 2023-08-31 07:50:58 --> Database Driver Class Initialized
INFO - 2023-08-31 07:50:58 --> Email Class Initialized
DEBUG - 2023-08-31 07:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:50:58 --> Controller Class Initialized
INFO - 2023-08-31 07:50:58 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:50:58 --> Helper loaded: form_helper
INFO - 2023-08-31 07:50:58 --> Form Validation Class Initialized
INFO - 2023-08-31 07:50:58 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-31 07:50:58 --> Final output sent to browser
DEBUG - 2023-08-31 07:50:58 --> Total execution time: 0.0504
INFO - 2023-08-31 07:50:58 --> Config Class Initialized
INFO - 2023-08-31 07:50:58 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:58 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:58 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:58 --> URI Class Initialized
INFO - 2023-08-31 07:50:58 --> Router Class Initialized
INFO - 2023-08-31 07:50:58 --> Output Class Initialized
INFO - 2023-08-31 07:50:58 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:58 --> Input Class Initialized
INFO - 2023-08-31 07:50:58 --> Language Class Initialized
ERROR - 2023-08-31 07:50:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:58 --> Config Class Initialized
INFO - 2023-08-31 07:50:58 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:58 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:58 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:58 --> URI Class Initialized
INFO - 2023-08-31 07:50:58 --> Router Class Initialized
INFO - 2023-08-31 07:50:58 --> Output Class Initialized
INFO - 2023-08-31 07:50:58 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:58 --> Input Class Initialized
INFO - 2023-08-31 07:50:58 --> Language Class Initialized
ERROR - 2023-08-31 07:50:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:58 --> Config Class Initialized
INFO - 2023-08-31 07:50:58 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:58 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:58 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:58 --> URI Class Initialized
INFO - 2023-08-31 07:50:58 --> Router Class Initialized
INFO - 2023-08-31 07:50:58 --> Output Class Initialized
INFO - 2023-08-31 07:50:58 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:58 --> Input Class Initialized
INFO - 2023-08-31 07:50:58 --> Language Class Initialized
ERROR - 2023-08-31 07:50:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:58 --> Config Class Initialized
INFO - 2023-08-31 07:50:58 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:58 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:58 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:58 --> URI Class Initialized
INFO - 2023-08-31 07:50:58 --> Router Class Initialized
INFO - 2023-08-31 07:50:58 --> Output Class Initialized
INFO - 2023-08-31 07:50:58 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:58 --> Input Class Initialized
INFO - 2023-08-31 07:50:58 --> Language Class Initialized
ERROR - 2023-08-31 07:50:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:58 --> Config Class Initialized
INFO - 2023-08-31 07:50:58 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:58 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:58 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:58 --> URI Class Initialized
INFO - 2023-08-31 07:50:58 --> Router Class Initialized
INFO - 2023-08-31 07:50:58 --> Output Class Initialized
INFO - 2023-08-31 07:50:58 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:58 --> Input Class Initialized
INFO - 2023-08-31 07:50:58 --> Language Class Initialized
ERROR - 2023-08-31 07:50:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:58 --> Config Class Initialized
INFO - 2023-08-31 07:50:58 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:58 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:58 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:58 --> URI Class Initialized
INFO - 2023-08-31 07:50:58 --> Router Class Initialized
INFO - 2023-08-31 07:50:58 --> Output Class Initialized
INFO - 2023-08-31 07:50:58 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:58 --> Input Class Initialized
INFO - 2023-08-31 07:50:58 --> Language Class Initialized
ERROR - 2023-08-31 07:50:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:58 --> Config Class Initialized
INFO - 2023-08-31 07:50:58 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:58 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:58 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:58 --> URI Class Initialized
INFO - 2023-08-31 07:50:58 --> Router Class Initialized
INFO - 2023-08-31 07:50:58 --> Output Class Initialized
INFO - 2023-08-31 07:50:58 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:58 --> Input Class Initialized
INFO - 2023-08-31 07:50:58 --> Language Class Initialized
ERROR - 2023-08-31 07:50:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:59 --> Config Class Initialized
INFO - 2023-08-31 07:50:59 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:59 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:59 --> URI Class Initialized
INFO - 2023-08-31 07:50:59 --> Router Class Initialized
INFO - 2023-08-31 07:50:59 --> Output Class Initialized
INFO - 2023-08-31 07:50:59 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:59 --> Input Class Initialized
INFO - 2023-08-31 07:50:59 --> Language Class Initialized
ERROR - 2023-08-31 07:50:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:59 --> Config Class Initialized
INFO - 2023-08-31 07:50:59 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:59 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:59 --> URI Class Initialized
INFO - 2023-08-31 07:50:59 --> Router Class Initialized
INFO - 2023-08-31 07:50:59 --> Output Class Initialized
INFO - 2023-08-31 07:50:59 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:59 --> Input Class Initialized
INFO - 2023-08-31 07:50:59 --> Language Class Initialized
ERROR - 2023-08-31 07:50:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:59 --> Config Class Initialized
INFO - 2023-08-31 07:50:59 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:59 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:59 --> URI Class Initialized
INFO - 2023-08-31 07:50:59 --> Router Class Initialized
INFO - 2023-08-31 07:50:59 --> Output Class Initialized
INFO - 2023-08-31 07:50:59 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:59 --> Input Class Initialized
INFO - 2023-08-31 07:50:59 --> Language Class Initialized
ERROR - 2023-08-31 07:50:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:59 --> Config Class Initialized
INFO - 2023-08-31 07:50:59 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:59 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:59 --> URI Class Initialized
INFO - 2023-08-31 07:50:59 --> Router Class Initialized
INFO - 2023-08-31 07:50:59 --> Output Class Initialized
INFO - 2023-08-31 07:50:59 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:59 --> Input Class Initialized
INFO - 2023-08-31 07:50:59 --> Language Class Initialized
ERROR - 2023-08-31 07:50:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:50:59 --> Config Class Initialized
INFO - 2023-08-31 07:50:59 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:50:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:50:59 --> Utf8 Class Initialized
INFO - 2023-08-31 07:50:59 --> URI Class Initialized
INFO - 2023-08-31 07:50:59 --> Router Class Initialized
INFO - 2023-08-31 07:50:59 --> Output Class Initialized
INFO - 2023-08-31 07:50:59 --> Security Class Initialized
DEBUG - 2023-08-31 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:50:59 --> Input Class Initialized
INFO - 2023-08-31 07:50:59 --> Language Class Initialized
ERROR - 2023-08-31 07:50:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:51:04 --> Config Class Initialized
INFO - 2023-08-31 07:51:04 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:04 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:04 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:04 --> URI Class Initialized
INFO - 2023-08-31 07:51:04 --> Router Class Initialized
INFO - 2023-08-31 07:51:04 --> Output Class Initialized
INFO - 2023-08-31 07:51:04 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:04 --> Input Class Initialized
INFO - 2023-08-31 07:51:04 --> Language Class Initialized
INFO - 2023-08-31 07:51:04 --> Loader Class Initialized
INFO - 2023-08-31 07:51:04 --> Helper loaded: url_helper
INFO - 2023-08-31 07:51:04 --> Helper loaded: file_helper
INFO - 2023-08-31 07:51:04 --> Database Driver Class Initialized
INFO - 2023-08-31 07:51:04 --> Email Class Initialized
DEBUG - 2023-08-31 07:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:51:04 --> Controller Class Initialized
INFO - 2023-08-31 07:51:04 --> Model "Services_model" initialized
INFO - 2023-08-31 07:51:04 --> Helper loaded: form_helper
INFO - 2023-08-31 07:51:04 --> Form Validation Class Initialized
INFO - 2023-08-31 07:51:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 07:51:04 --> Final output sent to browser
DEBUG - 2023-08-31 07:51:04 --> Total execution time: 0.0559
INFO - 2023-08-31 07:51:09 --> Config Class Initialized
INFO - 2023-08-31 07:51:09 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:09 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:09 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:09 --> URI Class Initialized
INFO - 2023-08-31 07:51:09 --> Router Class Initialized
INFO - 2023-08-31 07:51:09 --> Output Class Initialized
INFO - 2023-08-31 07:51:09 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:09 --> Input Class Initialized
INFO - 2023-08-31 07:51:09 --> Language Class Initialized
INFO - 2023-08-31 07:51:09 --> Loader Class Initialized
INFO - 2023-08-31 07:51:09 --> Helper loaded: url_helper
INFO - 2023-08-31 07:51:09 --> Helper loaded: file_helper
INFO - 2023-08-31 07:51:09 --> Database Driver Class Initialized
INFO - 2023-08-31 07:51:09 --> Email Class Initialized
DEBUG - 2023-08-31 07:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:51:09 --> Controller Class Initialized
INFO - 2023-08-31 07:51:09 --> Model "Services_cards_model" initialized
INFO - 2023-08-31 07:51:09 --> Helper loaded: form_helper
INFO - 2023-08-31 07:51:09 --> Form Validation Class Initialized
INFO - 2023-08-31 07:51:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-31 07:51:09 --> Final output sent to browser
DEBUG - 2023-08-31 07:51:09 --> Total execution time: 0.0574
INFO - 2023-08-31 07:51:10 --> Config Class Initialized
INFO - 2023-08-31 07:51:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:10 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:10 --> URI Class Initialized
INFO - 2023-08-31 07:51:10 --> Router Class Initialized
INFO - 2023-08-31 07:51:10 --> Output Class Initialized
INFO - 2023-08-31 07:51:10 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:10 --> Input Class Initialized
INFO - 2023-08-31 07:51:10 --> Language Class Initialized
ERROR - 2023-08-31 07:51:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:51:10 --> Config Class Initialized
INFO - 2023-08-31 07:51:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:10 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:10 --> URI Class Initialized
INFO - 2023-08-31 07:51:10 --> Router Class Initialized
INFO - 2023-08-31 07:51:10 --> Output Class Initialized
INFO - 2023-08-31 07:51:10 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:10 --> Input Class Initialized
INFO - 2023-08-31 07:51:10 --> Language Class Initialized
ERROR - 2023-08-31 07:51:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:51:10 --> Config Class Initialized
INFO - 2023-08-31 07:51:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:10 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:10 --> URI Class Initialized
INFO - 2023-08-31 07:51:10 --> Router Class Initialized
INFO - 2023-08-31 07:51:10 --> Output Class Initialized
INFO - 2023-08-31 07:51:10 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:10 --> Input Class Initialized
INFO - 2023-08-31 07:51:10 --> Language Class Initialized
ERROR - 2023-08-31 07:51:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:51:10 --> Config Class Initialized
INFO - 2023-08-31 07:51:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:10 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:10 --> URI Class Initialized
INFO - 2023-08-31 07:51:10 --> Router Class Initialized
INFO - 2023-08-31 07:51:10 --> Output Class Initialized
INFO - 2023-08-31 07:51:10 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:10 --> Input Class Initialized
INFO - 2023-08-31 07:51:10 --> Language Class Initialized
ERROR - 2023-08-31 07:51:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:51:10 --> Config Class Initialized
INFO - 2023-08-31 07:51:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:10 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:10 --> URI Class Initialized
INFO - 2023-08-31 07:51:10 --> Router Class Initialized
INFO - 2023-08-31 07:51:10 --> Output Class Initialized
INFO - 2023-08-31 07:51:10 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:10 --> Input Class Initialized
INFO - 2023-08-31 07:51:10 --> Language Class Initialized
ERROR - 2023-08-31 07:51:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:51:10 --> Config Class Initialized
INFO - 2023-08-31 07:51:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:10 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:10 --> URI Class Initialized
INFO - 2023-08-31 07:51:10 --> Router Class Initialized
INFO - 2023-08-31 07:51:10 --> Output Class Initialized
INFO - 2023-08-31 07:51:10 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:10 --> Input Class Initialized
INFO - 2023-08-31 07:51:10 --> Language Class Initialized
ERROR - 2023-08-31 07:51:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:51:10 --> Config Class Initialized
INFO - 2023-08-31 07:51:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:10 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:10 --> URI Class Initialized
INFO - 2023-08-31 07:51:10 --> Router Class Initialized
INFO - 2023-08-31 07:51:10 --> Output Class Initialized
INFO - 2023-08-31 07:51:10 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:10 --> Input Class Initialized
INFO - 2023-08-31 07:51:10 --> Language Class Initialized
ERROR - 2023-08-31 07:51:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:51:10 --> Config Class Initialized
INFO - 2023-08-31 07:51:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:10 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:10 --> URI Class Initialized
INFO - 2023-08-31 07:51:10 --> Router Class Initialized
INFO - 2023-08-31 07:51:10 --> Output Class Initialized
INFO - 2023-08-31 07:51:10 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:10 --> Input Class Initialized
INFO - 2023-08-31 07:51:10 --> Language Class Initialized
ERROR - 2023-08-31 07:51:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:51:10 --> Config Class Initialized
INFO - 2023-08-31 07:51:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:10 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:10 --> URI Class Initialized
INFO - 2023-08-31 07:51:10 --> Router Class Initialized
INFO - 2023-08-31 07:51:10 --> Output Class Initialized
INFO - 2023-08-31 07:51:10 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:10 --> Input Class Initialized
INFO - 2023-08-31 07:51:10 --> Language Class Initialized
ERROR - 2023-08-31 07:51:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:51:10 --> Config Class Initialized
INFO - 2023-08-31 07:51:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:10 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:10 --> URI Class Initialized
INFO - 2023-08-31 07:51:10 --> Router Class Initialized
INFO - 2023-08-31 07:51:10 --> Output Class Initialized
INFO - 2023-08-31 07:51:10 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:10 --> Input Class Initialized
INFO - 2023-08-31 07:51:10 --> Language Class Initialized
ERROR - 2023-08-31 07:51:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:51:10 --> Config Class Initialized
INFO - 2023-08-31 07:51:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:10 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:10 --> URI Class Initialized
INFO - 2023-08-31 07:51:10 --> Router Class Initialized
INFO - 2023-08-31 07:51:10 --> Output Class Initialized
INFO - 2023-08-31 07:51:10 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:10 --> Input Class Initialized
INFO - 2023-08-31 07:51:10 --> Language Class Initialized
ERROR - 2023-08-31 07:51:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:51:10 --> Config Class Initialized
INFO - 2023-08-31 07:51:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:10 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:10 --> URI Class Initialized
INFO - 2023-08-31 07:51:10 --> Router Class Initialized
INFO - 2023-08-31 07:51:10 --> Output Class Initialized
INFO - 2023-08-31 07:51:10 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:10 --> Input Class Initialized
INFO - 2023-08-31 07:51:10 --> Language Class Initialized
ERROR - 2023-08-31 07:51:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 07:51:14 --> Config Class Initialized
INFO - 2023-08-31 07:51:14 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:14 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:14 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:14 --> URI Class Initialized
INFO - 2023-08-31 07:51:14 --> Router Class Initialized
INFO - 2023-08-31 07:51:14 --> Output Class Initialized
INFO - 2023-08-31 07:51:14 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:14 --> Input Class Initialized
INFO - 2023-08-31 07:51:14 --> Language Class Initialized
INFO - 2023-08-31 07:51:14 --> Loader Class Initialized
INFO - 2023-08-31 07:51:14 --> Helper loaded: url_helper
INFO - 2023-08-31 07:51:14 --> Helper loaded: file_helper
INFO - 2023-08-31 07:51:14 --> Database Driver Class Initialized
INFO - 2023-08-31 07:51:14 --> Email Class Initialized
DEBUG - 2023-08-31 07:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:51:14 --> Controller Class Initialized
INFO - 2023-08-31 07:51:14 --> Model "Services_model" initialized
INFO - 2023-08-31 07:51:14 --> Helper loaded: form_helper
INFO - 2023-08-31 07:51:14 --> Form Validation Class Initialized
INFO - 2023-08-31 07:51:14 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 07:51:14 --> Final output sent to browser
DEBUG - 2023-08-31 07:51:14 --> Total execution time: 0.0602
INFO - 2023-08-31 07:51:39 --> Config Class Initialized
INFO - 2023-08-31 07:51:39 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:39 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:39 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:39 --> URI Class Initialized
INFO - 2023-08-31 07:51:39 --> Router Class Initialized
INFO - 2023-08-31 07:51:39 --> Output Class Initialized
INFO - 2023-08-31 07:51:39 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:39 --> Input Class Initialized
INFO - 2023-08-31 07:51:39 --> Language Class Initialized
INFO - 2023-08-31 07:51:39 --> Loader Class Initialized
INFO - 2023-08-31 07:51:39 --> Helper loaded: url_helper
INFO - 2023-08-31 07:51:39 --> Helper loaded: file_helper
INFO - 2023-08-31 07:51:39 --> Database Driver Class Initialized
INFO - 2023-08-31 07:51:39 --> Email Class Initialized
DEBUG - 2023-08-31 07:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:51:39 --> Controller Class Initialized
INFO - 2023-08-31 07:51:39 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:51:39 --> Model "Home_model" initialized
INFO - 2023-08-31 07:51:40 --> Helper loaded: download_helper
INFO - 2023-08-31 07:51:40 --> Helper loaded: form_helper
INFO - 2023-08-31 07:51:40 --> Form Validation Class Initialized
ERROR - 2023-08-31 07:51:40 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 07:51:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 07:51:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 07:51:40 --> Final output sent to browser
DEBUG - 2023-08-31 07:51:40 --> Total execution time: 0.8195
INFO - 2023-08-31 07:51:40 --> Config Class Initialized
INFO - 2023-08-31 07:51:40 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:40 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:40 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:40 --> URI Class Initialized
INFO - 2023-08-31 07:51:40 --> Router Class Initialized
INFO - 2023-08-31 07:51:40 --> Output Class Initialized
INFO - 2023-08-31 07:51:40 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:40 --> Input Class Initialized
INFO - 2023-08-31 07:51:40 --> Language Class Initialized
ERROR - 2023-08-31 07:51:40 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 07:51:40 --> Config Class Initialized
INFO - 2023-08-31 07:51:40 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:51:40 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:51:40 --> Utf8 Class Initialized
INFO - 2023-08-31 07:51:40 --> URI Class Initialized
INFO - 2023-08-31 07:51:40 --> Router Class Initialized
INFO - 2023-08-31 07:51:40 --> Output Class Initialized
INFO - 2023-08-31 07:51:40 --> Security Class Initialized
DEBUG - 2023-08-31 07:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:51:40 --> Input Class Initialized
INFO - 2023-08-31 07:51:40 --> Language Class Initialized
ERROR - 2023-08-31 07:51:40 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 07:52:43 --> Config Class Initialized
INFO - 2023-08-31 07:52:43 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:52:43 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:52:43 --> Utf8 Class Initialized
INFO - 2023-08-31 07:52:43 --> URI Class Initialized
INFO - 2023-08-31 07:52:43 --> Router Class Initialized
INFO - 2023-08-31 07:52:43 --> Output Class Initialized
INFO - 2023-08-31 07:52:43 --> Security Class Initialized
DEBUG - 2023-08-31 07:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:52:43 --> Input Class Initialized
INFO - 2023-08-31 07:52:43 --> Language Class Initialized
INFO - 2023-08-31 07:52:43 --> Loader Class Initialized
INFO - 2023-08-31 07:52:43 --> Helper loaded: url_helper
INFO - 2023-08-31 07:52:43 --> Helper loaded: file_helper
INFO - 2023-08-31 07:52:43 --> Database Driver Class Initialized
INFO - 2023-08-31 07:52:43 --> Email Class Initialized
DEBUG - 2023-08-31 07:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:52:44 --> Controller Class Initialized
INFO - 2023-08-31 07:52:44 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:52:44 --> Model "Home_model" initialized
INFO - 2023-08-31 07:52:44 --> Helper loaded: download_helper
INFO - 2023-08-31 07:52:44 --> Helper loaded: form_helper
INFO - 2023-08-31 07:52:44 --> Form Validation Class Initialized
ERROR - 2023-08-31 07:52:44 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 07:52:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 07:52:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 07:52:44 --> Final output sent to browser
DEBUG - 2023-08-31 07:52:44 --> Total execution time: 0.9486
INFO - 2023-08-31 07:52:45 --> Config Class Initialized
INFO - 2023-08-31 07:52:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:52:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:52:45 --> Utf8 Class Initialized
INFO - 2023-08-31 07:52:45 --> URI Class Initialized
INFO - 2023-08-31 07:52:45 --> Router Class Initialized
INFO - 2023-08-31 07:52:45 --> Output Class Initialized
INFO - 2023-08-31 07:52:45 --> Security Class Initialized
DEBUG - 2023-08-31 07:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:52:45 --> Input Class Initialized
INFO - 2023-08-31 07:52:45 --> Language Class Initialized
ERROR - 2023-08-31 07:52:45 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 07:52:45 --> Config Class Initialized
INFO - 2023-08-31 07:52:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:52:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:52:45 --> Utf8 Class Initialized
INFO - 2023-08-31 07:52:46 --> URI Class Initialized
INFO - 2023-08-31 07:52:46 --> Router Class Initialized
INFO - 2023-08-31 07:52:46 --> Output Class Initialized
INFO - 2023-08-31 07:52:46 --> Security Class Initialized
DEBUG - 2023-08-31 07:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:52:46 --> Input Class Initialized
INFO - 2023-08-31 07:52:46 --> Language Class Initialized
ERROR - 2023-08-31 07:52:46 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 07:53:04 --> Config Class Initialized
INFO - 2023-08-31 07:53:04 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:53:04 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:53:04 --> Utf8 Class Initialized
INFO - 2023-08-31 07:53:04 --> URI Class Initialized
INFO - 2023-08-31 07:53:04 --> Router Class Initialized
INFO - 2023-08-31 07:53:04 --> Output Class Initialized
INFO - 2023-08-31 07:53:04 --> Security Class Initialized
DEBUG - 2023-08-31 07:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:53:04 --> Input Class Initialized
INFO - 2023-08-31 07:53:04 --> Language Class Initialized
INFO - 2023-08-31 07:53:05 --> Loader Class Initialized
INFO - 2023-08-31 07:53:05 --> Helper loaded: url_helper
INFO - 2023-08-31 07:53:05 --> Helper loaded: file_helper
INFO - 2023-08-31 07:53:05 --> Database Driver Class Initialized
INFO - 2023-08-31 07:53:05 --> Email Class Initialized
DEBUG - 2023-08-31 07:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:53:05 --> Controller Class Initialized
INFO - 2023-08-31 07:53:05 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:53:05 --> Model "Home_model" initialized
INFO - 2023-08-31 07:53:05 --> Helper loaded: download_helper
INFO - 2023-08-31 07:53:05 --> Helper loaded: form_helper
INFO - 2023-08-31 07:53:05 --> Form Validation Class Initialized
ERROR - 2023-08-31 07:53:05 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 07:53:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 07:53:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 07:53:05 --> Final output sent to browser
DEBUG - 2023-08-31 07:53:05 --> Total execution time: 0.9074
INFO - 2023-08-31 07:53:05 --> Config Class Initialized
INFO - 2023-08-31 07:53:05 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:53:05 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:53:05 --> Utf8 Class Initialized
INFO - 2023-08-31 07:53:05 --> URI Class Initialized
INFO - 2023-08-31 07:53:05 --> Router Class Initialized
INFO - 2023-08-31 07:53:05 --> Output Class Initialized
INFO - 2023-08-31 07:53:05 --> Security Class Initialized
DEBUG - 2023-08-31 07:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:53:05 --> Input Class Initialized
INFO - 2023-08-31 07:53:05 --> Language Class Initialized
ERROR - 2023-08-31 07:53:05 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 07:53:06 --> Config Class Initialized
INFO - 2023-08-31 07:53:06 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:53:06 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:53:06 --> Utf8 Class Initialized
INFO - 2023-08-31 07:53:06 --> URI Class Initialized
INFO - 2023-08-31 07:53:06 --> Router Class Initialized
INFO - 2023-08-31 07:53:06 --> Output Class Initialized
INFO - 2023-08-31 07:53:06 --> Security Class Initialized
DEBUG - 2023-08-31 07:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:53:07 --> Input Class Initialized
INFO - 2023-08-31 07:53:07 --> Language Class Initialized
ERROR - 2023-08-31 07:53:07 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 07:54:37 --> Config Class Initialized
INFO - 2023-08-31 07:54:37 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:54:37 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:54:37 --> Utf8 Class Initialized
INFO - 2023-08-31 07:54:37 --> URI Class Initialized
INFO - 2023-08-31 07:54:37 --> Router Class Initialized
INFO - 2023-08-31 07:54:37 --> Output Class Initialized
INFO - 2023-08-31 07:54:37 --> Security Class Initialized
DEBUG - 2023-08-31 07:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:54:37 --> Input Class Initialized
INFO - 2023-08-31 07:54:37 --> Language Class Initialized
INFO - 2023-08-31 07:54:37 --> Loader Class Initialized
INFO - 2023-08-31 07:54:37 --> Helper loaded: url_helper
INFO - 2023-08-31 07:54:37 --> Helper loaded: file_helper
INFO - 2023-08-31 07:54:37 --> Database Driver Class Initialized
INFO - 2023-08-31 07:54:37 --> Email Class Initialized
DEBUG - 2023-08-31 07:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 07:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 07:54:37 --> Controller Class Initialized
INFO - 2023-08-31 07:54:37 --> Model "Contact_model" initialized
INFO - 2023-08-31 07:54:37 --> Model "Home_model" initialized
INFO - 2023-08-31 07:54:37 --> Helper loaded: download_helper
INFO - 2023-08-31 07:54:37 --> Helper loaded: form_helper
INFO - 2023-08-31 07:54:37 --> Form Validation Class Initialized
ERROR - 2023-08-31 07:54:37 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 07:54:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 07:54:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 07:54:37 --> Final output sent to browser
DEBUG - 2023-08-31 07:54:37 --> Total execution time: 0.8223
INFO - 2023-08-31 07:54:38 --> Config Class Initialized
INFO - 2023-08-31 07:54:38 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:54:38 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:54:38 --> Utf8 Class Initialized
INFO - 2023-08-31 07:54:38 --> URI Class Initialized
INFO - 2023-08-31 07:54:38 --> Router Class Initialized
INFO - 2023-08-31 07:54:38 --> Output Class Initialized
INFO - 2023-08-31 07:54:38 --> Security Class Initialized
DEBUG - 2023-08-31 07:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:54:38 --> Input Class Initialized
INFO - 2023-08-31 07:54:38 --> Language Class Initialized
ERROR - 2023-08-31 07:54:38 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 07:54:39 --> Config Class Initialized
INFO - 2023-08-31 07:54:39 --> Hooks Class Initialized
DEBUG - 2023-08-31 07:54:39 --> UTF-8 Support Enabled
INFO - 2023-08-31 07:54:39 --> Utf8 Class Initialized
INFO - 2023-08-31 07:54:39 --> URI Class Initialized
INFO - 2023-08-31 07:54:39 --> Router Class Initialized
INFO - 2023-08-31 07:54:39 --> Output Class Initialized
INFO - 2023-08-31 07:54:39 --> Security Class Initialized
DEBUG - 2023-08-31 07:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 07:54:39 --> Input Class Initialized
INFO - 2023-08-31 07:54:39 --> Language Class Initialized
ERROR - 2023-08-31 07:54:39 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:02:14 --> Config Class Initialized
INFO - 2023-08-31 08:02:14 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:02:14 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:02:14 --> Utf8 Class Initialized
INFO - 2023-08-31 08:02:14 --> URI Class Initialized
INFO - 2023-08-31 08:02:14 --> Router Class Initialized
INFO - 2023-08-31 08:02:14 --> Output Class Initialized
INFO - 2023-08-31 08:02:14 --> Security Class Initialized
DEBUG - 2023-08-31 08:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:02:14 --> Input Class Initialized
INFO - 2023-08-31 08:02:14 --> Language Class Initialized
ERROR - 2023-08-31 08:02:14 --> 404 Page Not Found: Service-detail/project-details.html
INFO - 2023-08-31 08:02:17 --> Config Class Initialized
INFO - 2023-08-31 08:02:17 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:02:17 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:02:17 --> Utf8 Class Initialized
INFO - 2023-08-31 08:02:17 --> URI Class Initialized
INFO - 2023-08-31 08:02:17 --> Router Class Initialized
INFO - 2023-08-31 08:02:17 --> Output Class Initialized
INFO - 2023-08-31 08:02:17 --> Security Class Initialized
DEBUG - 2023-08-31 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:02:17 --> Input Class Initialized
INFO - 2023-08-31 08:02:17 --> Language Class Initialized
INFO - 2023-08-31 08:02:17 --> Loader Class Initialized
INFO - 2023-08-31 08:02:17 --> Helper loaded: url_helper
INFO - 2023-08-31 08:02:17 --> Helper loaded: file_helper
INFO - 2023-08-31 08:02:17 --> Database Driver Class Initialized
INFO - 2023-08-31 08:02:17 --> Email Class Initialized
DEBUG - 2023-08-31 08:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 08:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 08:02:17 --> Controller Class Initialized
INFO - 2023-08-31 08:02:17 --> Model "Contact_model" initialized
INFO - 2023-08-31 08:02:17 --> Model "Home_model" initialized
INFO - 2023-08-31 08:02:17 --> Helper loaded: download_helper
INFO - 2023-08-31 08:02:17 --> Helper loaded: form_helper
INFO - 2023-08-31 08:02:17 --> Form Validation Class Initialized
ERROR - 2023-08-31 08:02:17 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 08:02:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 08:02:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 08:02:17 --> Final output sent to browser
DEBUG - 2023-08-31 08:02:17 --> Total execution time: 0.5033
INFO - 2023-08-31 08:02:21 --> Config Class Initialized
INFO - 2023-08-31 08:02:21 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:02:21 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:02:21 --> Utf8 Class Initialized
INFO - 2023-08-31 08:02:21 --> URI Class Initialized
INFO - 2023-08-31 08:02:21 --> Router Class Initialized
INFO - 2023-08-31 08:02:21 --> Output Class Initialized
INFO - 2023-08-31 08:02:21 --> Security Class Initialized
DEBUG - 2023-08-31 08:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:02:21 --> Input Class Initialized
INFO - 2023-08-31 08:02:21 --> Language Class Initialized
INFO - 2023-08-31 08:02:22 --> Loader Class Initialized
INFO - 2023-08-31 08:02:22 --> Helper loaded: url_helper
INFO - 2023-08-31 08:02:22 --> Helper loaded: file_helper
INFO - 2023-08-31 08:02:22 --> Database Driver Class Initialized
INFO - 2023-08-31 08:02:22 --> Email Class Initialized
DEBUG - 2023-08-31 08:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 08:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 08:02:22 --> Controller Class Initialized
INFO - 2023-08-31 08:02:22 --> Model "Contact_model" initialized
INFO - 2023-08-31 08:02:22 --> Model "Home_model" initialized
INFO - 2023-08-31 08:02:22 --> Helper loaded: download_helper
INFO - 2023-08-31 08:02:22 --> Helper loaded: form_helper
INFO - 2023-08-31 08:02:22 --> Form Validation Class Initialized
ERROR - 2023-08-31 08:02:22 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 08:02:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 08:02:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 08:02:22 --> Final output sent to browser
DEBUG - 2023-08-31 08:02:22 --> Total execution time: 0.7746
INFO - 2023-08-31 08:02:23 --> Config Class Initialized
INFO - 2023-08-31 08:02:23 --> Config Class Initialized
INFO - 2023-08-31 08:02:23 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:02:23 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:02:23 --> Utf8 Class Initialized
INFO - 2023-08-31 08:02:23 --> URI Class Initialized
INFO - 2023-08-31 08:02:23 --> Router Class Initialized
INFO - 2023-08-31 08:02:23 --> Output Class Initialized
INFO - 2023-08-31 08:02:23 --> Security Class Initialized
DEBUG - 2023-08-31 08:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:02:23 --> Input Class Initialized
INFO - 2023-08-31 08:02:23 --> Language Class Initialized
ERROR - 2023-08-31 08:02:23 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:02:23 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:02:23 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:02:23 --> Utf8 Class Initialized
INFO - 2023-08-31 08:02:23 --> URI Class Initialized
INFO - 2023-08-31 08:02:23 --> Router Class Initialized
INFO - 2023-08-31 08:02:23 --> Output Class Initialized
INFO - 2023-08-31 08:02:23 --> Security Class Initialized
DEBUG - 2023-08-31 08:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:02:23 --> Input Class Initialized
INFO - 2023-08-31 08:02:23 --> Language Class Initialized
ERROR - 2023-08-31 08:02:23 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:02:26 --> Config Class Initialized
INFO - 2023-08-31 08:02:26 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:02:26 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:02:26 --> Utf8 Class Initialized
INFO - 2023-08-31 08:02:26 --> URI Class Initialized
INFO - 2023-08-31 08:02:26 --> Router Class Initialized
INFO - 2023-08-31 08:02:26 --> Output Class Initialized
INFO - 2023-08-31 08:02:26 --> Security Class Initialized
DEBUG - 2023-08-31 08:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:02:26 --> Input Class Initialized
INFO - 2023-08-31 08:02:26 --> Language Class Initialized
INFO - 2023-08-31 08:02:26 --> Loader Class Initialized
INFO - 2023-08-31 08:02:27 --> Helper loaded: url_helper
INFO - 2023-08-31 08:02:27 --> Helper loaded: file_helper
INFO - 2023-08-31 08:02:27 --> Database Driver Class Initialized
INFO - 2023-08-31 08:02:27 --> Email Class Initialized
DEBUG - 2023-08-31 08:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 08:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 08:02:27 --> Controller Class Initialized
INFO - 2023-08-31 08:02:27 --> Model "Contact_model" initialized
INFO - 2023-08-31 08:02:27 --> Model "Home_model" initialized
INFO - 2023-08-31 08:02:27 --> Helper loaded: download_helper
INFO - 2023-08-31 08:02:27 --> Helper loaded: form_helper
INFO - 2023-08-31 08:02:27 --> Form Validation Class Initialized
ERROR - 2023-08-31 08:02:27 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 08:02:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 08:02:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 08:02:27 --> Final output sent to browser
DEBUG - 2023-08-31 08:02:27 --> Total execution time: 0.8845
INFO - 2023-08-31 08:02:28 --> Config Class Initialized
INFO - 2023-08-31 08:02:28 --> Config Class Initialized
INFO - 2023-08-31 08:02:28 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:02:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:02:28 --> Hooks Class Initialized
INFO - 2023-08-31 08:02:28 --> Utf8 Class Initialized
INFO - 2023-08-31 08:02:28 --> URI Class Initialized
DEBUG - 2023-08-31 08:02:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:02:28 --> Router Class Initialized
INFO - 2023-08-31 08:02:28 --> Utf8 Class Initialized
INFO - 2023-08-31 08:02:28 --> Output Class Initialized
INFO - 2023-08-31 08:02:28 --> URI Class Initialized
INFO - 2023-08-31 08:02:28 --> Security Class Initialized
INFO - 2023-08-31 08:02:28 --> Router Class Initialized
DEBUG - 2023-08-31 08:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:02:28 --> Output Class Initialized
INFO - 2023-08-31 08:02:28 --> Input Class Initialized
INFO - 2023-08-31 08:02:28 --> Security Class Initialized
INFO - 2023-08-31 08:02:28 --> Language Class Initialized
ERROR - 2023-08-31 08:02:28 --> 404 Page Not Found: Service-detail/assets
DEBUG - 2023-08-31 08:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:02:28 --> Input Class Initialized
INFO - 2023-08-31 08:02:28 --> Language Class Initialized
ERROR - 2023-08-31 08:02:28 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:02:32 --> Config Class Initialized
INFO - 2023-08-31 08:02:32 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:02:32 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:02:32 --> Utf8 Class Initialized
INFO - 2023-08-31 08:02:32 --> URI Class Initialized
INFO - 2023-08-31 08:02:32 --> Router Class Initialized
INFO - 2023-08-31 08:02:32 --> Output Class Initialized
INFO - 2023-08-31 08:02:32 --> Security Class Initialized
DEBUG - 2023-08-31 08:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:02:32 --> Input Class Initialized
INFO - 2023-08-31 08:02:32 --> Language Class Initialized
INFO - 2023-08-31 08:02:32 --> Loader Class Initialized
INFO - 2023-08-31 08:02:32 --> Helper loaded: url_helper
INFO - 2023-08-31 08:02:32 --> Helper loaded: file_helper
INFO - 2023-08-31 08:02:32 --> Database Driver Class Initialized
INFO - 2023-08-31 08:02:32 --> Email Class Initialized
DEBUG - 2023-08-31 08:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 08:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 08:02:32 --> Controller Class Initialized
INFO - 2023-08-31 08:02:32 --> Model "Contact_model" initialized
INFO - 2023-08-31 08:02:32 --> Model "Home_model" initialized
INFO - 2023-08-31 08:02:32 --> Helper loaded: download_helper
INFO - 2023-08-31 08:02:32 --> Helper loaded: form_helper
INFO - 2023-08-31 08:02:32 --> Form Validation Class Initialized
ERROR - 2023-08-31 08:02:32 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 08:02:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 08:02:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 08:02:33 --> Final output sent to browser
DEBUG - 2023-08-31 08:02:33 --> Total execution time: 0.9197
INFO - 2023-08-31 08:02:33 --> Config Class Initialized
INFO - 2023-08-31 08:02:33 --> Hooks Class Initialized
INFO - 2023-08-31 08:02:33 --> Config Class Initialized
DEBUG - 2023-08-31 08:02:33 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:02:34 --> Utf8 Class Initialized
INFO - 2023-08-31 08:02:34 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:02:34 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:02:34 --> Utf8 Class Initialized
INFO - 2023-08-31 08:02:34 --> URI Class Initialized
INFO - 2023-08-31 08:02:34 --> URI Class Initialized
INFO - 2023-08-31 08:02:34 --> Router Class Initialized
INFO - 2023-08-31 08:02:34 --> Router Class Initialized
INFO - 2023-08-31 08:02:34 --> Output Class Initialized
INFO - 2023-08-31 08:02:34 --> Output Class Initialized
INFO - 2023-08-31 08:02:34 --> Security Class Initialized
DEBUG - 2023-08-31 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:02:34 --> Security Class Initialized
INFO - 2023-08-31 08:02:34 --> Input Class Initialized
DEBUG - 2023-08-31 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:02:34 --> Language Class Initialized
INFO - 2023-08-31 08:02:34 --> Input Class Initialized
ERROR - 2023-08-31 08:02:34 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:02:34 --> Language Class Initialized
ERROR - 2023-08-31 08:02:34 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:04:11 --> Config Class Initialized
INFO - 2023-08-31 08:04:11 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:04:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:11 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:11 --> URI Class Initialized
INFO - 2023-08-31 08:04:11 --> Router Class Initialized
INFO - 2023-08-31 08:04:11 --> Output Class Initialized
INFO - 2023-08-31 08:04:11 --> Security Class Initialized
DEBUG - 2023-08-31 08:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:11 --> Input Class Initialized
INFO - 2023-08-31 08:04:11 --> Language Class Initialized
INFO - 2023-08-31 08:04:11 --> Loader Class Initialized
INFO - 2023-08-31 08:04:11 --> Helper loaded: url_helper
INFO - 2023-08-31 08:04:12 --> Helper loaded: file_helper
INFO - 2023-08-31 08:04:12 --> Database Driver Class Initialized
INFO - 2023-08-31 08:04:12 --> Email Class Initialized
DEBUG - 2023-08-31 08:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 08:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 08:04:12 --> Controller Class Initialized
INFO - 2023-08-31 08:04:12 --> Model "Contact_model" initialized
INFO - 2023-08-31 08:04:12 --> Model "Home_model" initialized
INFO - 2023-08-31 08:04:12 --> Helper loaded: download_helper
INFO - 2023-08-31 08:04:12 --> Helper loaded: form_helper
INFO - 2023-08-31 08:04:12 --> Form Validation Class Initialized
ERROR - 2023-08-31 08:04:12 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 08:04:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 08:04:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 08:04:12 --> Final output sent to browser
DEBUG - 2023-08-31 08:04:12 --> Total execution time: 0.8795
INFO - 2023-08-31 08:04:13 --> Config Class Initialized
INFO - 2023-08-31 08:04:13 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:04:13 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:13 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:13 --> URI Class Initialized
INFO - 2023-08-31 08:04:13 --> Router Class Initialized
INFO - 2023-08-31 08:04:13 --> Output Class Initialized
INFO - 2023-08-31 08:04:13 --> Security Class Initialized
DEBUG - 2023-08-31 08:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:13 --> Input Class Initialized
INFO - 2023-08-31 08:04:13 --> Language Class Initialized
ERROR - 2023-08-31 08:04:13 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:04:13 --> Config Class Initialized
INFO - 2023-08-31 08:04:13 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:04:13 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:13 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:13 --> URI Class Initialized
INFO - 2023-08-31 08:04:13 --> Router Class Initialized
INFO - 2023-08-31 08:04:13 --> Output Class Initialized
INFO - 2023-08-31 08:04:13 --> Security Class Initialized
DEBUG - 2023-08-31 08:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:13 --> Input Class Initialized
INFO - 2023-08-31 08:04:13 --> Language Class Initialized
ERROR - 2023-08-31 08:04:13 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:04:17 --> Config Class Initialized
INFO - 2023-08-31 08:04:17 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:04:17 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:17 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:17 --> URI Class Initialized
INFO - 2023-08-31 08:04:17 --> Router Class Initialized
INFO - 2023-08-31 08:04:17 --> Output Class Initialized
INFO - 2023-08-31 08:04:17 --> Security Class Initialized
DEBUG - 2023-08-31 08:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:17 --> Input Class Initialized
INFO - 2023-08-31 08:04:17 --> Language Class Initialized
ERROR - 2023-08-31 08:04:17 --> 404 Page Not Found: Services-details/3
INFO - 2023-08-31 08:04:21 --> Config Class Initialized
INFO - 2023-08-31 08:04:21 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:04:21 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:21 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:21 --> URI Class Initialized
INFO - 2023-08-31 08:04:21 --> Router Class Initialized
INFO - 2023-08-31 08:04:21 --> Output Class Initialized
INFO - 2023-08-31 08:04:21 --> Security Class Initialized
DEBUG - 2023-08-31 08:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:21 --> Input Class Initialized
INFO - 2023-08-31 08:04:21 --> Language Class Initialized
INFO - 2023-08-31 08:04:21 --> Loader Class Initialized
INFO - 2023-08-31 08:04:21 --> Helper loaded: url_helper
INFO - 2023-08-31 08:04:21 --> Helper loaded: file_helper
INFO - 2023-08-31 08:04:21 --> Database Driver Class Initialized
INFO - 2023-08-31 08:04:21 --> Email Class Initialized
DEBUG - 2023-08-31 08:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 08:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 08:04:21 --> Controller Class Initialized
INFO - 2023-08-31 08:04:21 --> Model "Contact_model" initialized
INFO - 2023-08-31 08:04:21 --> Model "Home_model" initialized
INFO - 2023-08-31 08:04:21 --> Helper loaded: download_helper
INFO - 2023-08-31 08:04:21 --> Helper loaded: form_helper
INFO - 2023-08-31 08:04:21 --> Form Validation Class Initialized
ERROR - 2023-08-31 08:04:21 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 08:04:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 08:04:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 08:04:21 --> Final output sent to browser
DEBUG - 2023-08-31 08:04:21 --> Total execution time: 0.0553
INFO - 2023-08-31 08:04:29 --> Config Class Initialized
INFO - 2023-08-31 08:04:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:04:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:29 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:29 --> URI Class Initialized
INFO - 2023-08-31 08:04:29 --> Router Class Initialized
INFO - 2023-08-31 08:04:29 --> Output Class Initialized
INFO - 2023-08-31 08:04:29 --> Security Class Initialized
DEBUG - 2023-08-31 08:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:29 --> Input Class Initialized
INFO - 2023-08-31 08:04:29 --> Language Class Initialized
INFO - 2023-08-31 08:04:30 --> Loader Class Initialized
INFO - 2023-08-31 08:04:30 --> Helper loaded: url_helper
INFO - 2023-08-31 08:04:30 --> Helper loaded: file_helper
INFO - 2023-08-31 08:04:30 --> Database Driver Class Initialized
INFO - 2023-08-31 08:04:30 --> Email Class Initialized
DEBUG - 2023-08-31 08:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 08:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 08:04:30 --> Controller Class Initialized
INFO - 2023-08-31 08:04:30 --> Model "Contact_model" initialized
INFO - 2023-08-31 08:04:30 --> Model "Home_model" initialized
INFO - 2023-08-31 08:04:30 --> Helper loaded: download_helper
INFO - 2023-08-31 08:04:30 --> Helper loaded: form_helper
INFO - 2023-08-31 08:04:30 --> Form Validation Class Initialized
ERROR - 2023-08-31 08:04:30 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 08:04:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 08:04:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 08:04:30 --> Final output sent to browser
DEBUG - 2023-08-31 08:04:30 --> Total execution time: 0.8749
INFO - 2023-08-31 08:04:31 --> Config Class Initialized
INFO - 2023-08-31 08:04:31 --> Hooks Class Initialized
INFO - 2023-08-31 08:04:31 --> Config Class Initialized
DEBUG - 2023-08-31 08:04:31 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:31 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:31 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:04:31 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:31 --> URI Class Initialized
INFO - 2023-08-31 08:04:31 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:31 --> Router Class Initialized
INFO - 2023-08-31 08:04:31 --> Output Class Initialized
INFO - 2023-08-31 08:04:31 --> URI Class Initialized
INFO - 2023-08-31 08:04:31 --> Security Class Initialized
INFO - 2023-08-31 08:04:31 --> Router Class Initialized
DEBUG - 2023-08-31 08:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:31 --> Input Class Initialized
INFO - 2023-08-31 08:04:31 --> Output Class Initialized
INFO - 2023-08-31 08:04:31 --> Language Class Initialized
INFO - 2023-08-31 08:04:31 --> Security Class Initialized
ERROR - 2023-08-31 08:04:31 --> 404 Page Not Found: Service-detail/assets
DEBUG - 2023-08-31 08:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:31 --> Input Class Initialized
INFO - 2023-08-31 08:04:31 --> Language Class Initialized
ERROR - 2023-08-31 08:04:31 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:04:34 --> Config Class Initialized
INFO - 2023-08-31 08:04:34 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:04:34 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:34 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:34 --> URI Class Initialized
INFO - 2023-08-31 08:04:34 --> Router Class Initialized
INFO - 2023-08-31 08:04:34 --> Output Class Initialized
INFO - 2023-08-31 08:04:34 --> Security Class Initialized
DEBUG - 2023-08-31 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:34 --> Input Class Initialized
INFO - 2023-08-31 08:04:34 --> Language Class Initialized
ERROR - 2023-08-31 08:04:34 --> 404 Page Not Found: Service-details/4
INFO - 2023-08-31 08:04:37 --> Config Class Initialized
INFO - 2023-08-31 08:04:37 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:04:37 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:37 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:37 --> URI Class Initialized
INFO - 2023-08-31 08:04:37 --> Router Class Initialized
INFO - 2023-08-31 08:04:37 --> Output Class Initialized
INFO - 2023-08-31 08:04:37 --> Security Class Initialized
DEBUG - 2023-08-31 08:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:37 --> Input Class Initialized
INFO - 2023-08-31 08:04:37 --> Language Class Initialized
INFO - 2023-08-31 08:04:37 --> Loader Class Initialized
INFO - 2023-08-31 08:04:37 --> Helper loaded: url_helper
INFO - 2023-08-31 08:04:37 --> Helper loaded: file_helper
INFO - 2023-08-31 08:04:37 --> Database Driver Class Initialized
INFO - 2023-08-31 08:04:37 --> Email Class Initialized
DEBUG - 2023-08-31 08:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 08:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 08:04:37 --> Controller Class Initialized
INFO - 2023-08-31 08:04:37 --> Model "Contact_model" initialized
INFO - 2023-08-31 08:04:37 --> Model "Home_model" initialized
INFO - 2023-08-31 08:04:37 --> Helper loaded: download_helper
INFO - 2023-08-31 08:04:37 --> Helper loaded: form_helper
INFO - 2023-08-31 08:04:37 --> Form Validation Class Initialized
ERROR - 2023-08-31 08:04:37 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 08:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 08:04:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 08:04:38 --> Final output sent to browser
DEBUG - 2023-08-31 08:04:38 --> Total execution time: 0.9309
INFO - 2023-08-31 08:04:40 --> Config Class Initialized
INFO - 2023-08-31 08:04:40 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:04:40 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:40 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:40 --> URI Class Initialized
INFO - 2023-08-31 08:04:41 --> Router Class Initialized
INFO - 2023-08-31 08:04:41 --> Output Class Initialized
INFO - 2023-08-31 08:04:41 --> Security Class Initialized
DEBUG - 2023-08-31 08:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:41 --> Input Class Initialized
INFO - 2023-08-31 08:04:41 --> Language Class Initialized
INFO - 2023-08-31 08:04:41 --> Loader Class Initialized
INFO - 2023-08-31 08:04:41 --> Helper loaded: url_helper
INFO - 2023-08-31 08:04:41 --> Helper loaded: file_helper
INFO - 2023-08-31 08:04:41 --> Database Driver Class Initialized
INFO - 2023-08-31 08:04:41 --> Email Class Initialized
DEBUG - 2023-08-31 08:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 08:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 08:04:41 --> Controller Class Initialized
INFO - 2023-08-31 08:04:41 --> Model "Contact_model" initialized
INFO - 2023-08-31 08:04:41 --> Model "Home_model" initialized
INFO - 2023-08-31 08:04:41 --> Helper loaded: download_helper
INFO - 2023-08-31 08:04:41 --> Helper loaded: form_helper
INFO - 2023-08-31 08:04:41 --> Form Validation Class Initialized
ERROR - 2023-08-31 08:04:41 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 08:04:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 08:04:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 08:04:41 --> Final output sent to browser
DEBUG - 2023-08-31 08:04:41 --> Total execution time: 0.8681
INFO - 2023-08-31 08:04:42 --> Config Class Initialized
INFO - 2023-08-31 08:04:42 --> Config Class Initialized
INFO - 2023-08-31 08:04:42 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:04:42 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:42 --> Hooks Class Initialized
INFO - 2023-08-31 08:04:42 --> Utf8 Class Initialized
DEBUG - 2023-08-31 08:04:42 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:42 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:42 --> URI Class Initialized
INFO - 2023-08-31 08:04:42 --> URI Class Initialized
INFO - 2023-08-31 08:04:42 --> Router Class Initialized
INFO - 2023-08-31 08:04:42 --> Router Class Initialized
INFO - 2023-08-31 08:04:42 --> Output Class Initialized
INFO - 2023-08-31 08:04:42 --> Output Class Initialized
INFO - 2023-08-31 08:04:43 --> Security Class Initialized
DEBUG - 2023-08-31 08:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:43 --> Security Class Initialized
INFO - 2023-08-31 08:04:43 --> Input Class Initialized
DEBUG - 2023-08-31 08:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:43 --> Language Class Initialized
ERROR - 2023-08-31 08:04:43 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:04:43 --> Input Class Initialized
INFO - 2023-08-31 08:04:43 --> Language Class Initialized
ERROR - 2023-08-31 08:04:43 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:04:47 --> Config Class Initialized
INFO - 2023-08-31 08:04:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:04:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:47 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:47 --> URI Class Initialized
INFO - 2023-08-31 08:04:47 --> Router Class Initialized
INFO - 2023-08-31 08:04:47 --> Output Class Initialized
INFO - 2023-08-31 08:04:47 --> Security Class Initialized
DEBUG - 2023-08-31 08:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:47 --> Input Class Initialized
INFO - 2023-08-31 08:04:47 --> Language Class Initialized
ERROR - 2023-08-31 08:04:47 --> 404 Page Not Found: Service-details/4
INFO - 2023-08-31 08:04:51 --> Config Class Initialized
INFO - 2023-08-31 08:04:51 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:04:51 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:51 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:51 --> URI Class Initialized
INFO - 2023-08-31 08:04:51 --> Router Class Initialized
INFO - 2023-08-31 08:04:51 --> Output Class Initialized
INFO - 2023-08-31 08:04:51 --> Security Class Initialized
DEBUG - 2023-08-31 08:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:51 --> Input Class Initialized
INFO - 2023-08-31 08:04:51 --> Language Class Initialized
INFO - 2023-08-31 08:04:51 --> Loader Class Initialized
INFO - 2023-08-31 08:04:51 --> Helper loaded: url_helper
INFO - 2023-08-31 08:04:51 --> Helper loaded: file_helper
INFO - 2023-08-31 08:04:51 --> Database Driver Class Initialized
INFO - 2023-08-31 08:04:51 --> Email Class Initialized
DEBUG - 2023-08-31 08:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 08:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 08:04:51 --> Controller Class Initialized
INFO - 2023-08-31 08:04:51 --> Model "Contact_model" initialized
INFO - 2023-08-31 08:04:51 --> Model "Home_model" initialized
INFO - 2023-08-31 08:04:51 --> Helper loaded: download_helper
INFO - 2023-08-31 08:04:51 --> Helper loaded: form_helper
INFO - 2023-08-31 08:04:51 --> Form Validation Class Initialized
ERROR - 2023-08-31 08:04:51 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 08:04:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 08:04:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 08:04:51 --> Final output sent to browser
DEBUG - 2023-08-31 08:04:52 --> Total execution time: 0.8094
INFO - 2023-08-31 08:04:59 --> Config Class Initialized
INFO - 2023-08-31 08:04:59 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:04:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:04:59 --> Utf8 Class Initialized
INFO - 2023-08-31 08:04:59 --> URI Class Initialized
INFO - 2023-08-31 08:04:59 --> Router Class Initialized
INFO - 2023-08-31 08:04:59 --> Output Class Initialized
INFO - 2023-08-31 08:04:59 --> Security Class Initialized
DEBUG - 2023-08-31 08:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:04:59 --> Input Class Initialized
INFO - 2023-08-31 08:04:59 --> Language Class Initialized
INFO - 2023-08-31 08:04:59 --> Loader Class Initialized
INFO - 2023-08-31 08:04:59 --> Helper loaded: url_helper
INFO - 2023-08-31 08:04:59 --> Helper loaded: file_helper
INFO - 2023-08-31 08:04:59 --> Database Driver Class Initialized
INFO - 2023-08-31 08:04:59 --> Email Class Initialized
DEBUG - 2023-08-31 08:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 08:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 08:04:59 --> Controller Class Initialized
INFO - 2023-08-31 08:04:59 --> Model "Contact_model" initialized
INFO - 2023-08-31 08:04:59 --> Model "Home_model" initialized
INFO - 2023-08-31 08:04:59 --> Helper loaded: download_helper
INFO - 2023-08-31 08:04:59 --> Helper loaded: form_helper
INFO - 2023-08-31 08:04:59 --> Form Validation Class Initialized
ERROR - 2023-08-31 08:05:00 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 08:05:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 08:05:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 08:05:00 --> Final output sent to browser
DEBUG - 2023-08-31 08:05:00 --> Total execution time: 0.9371
INFO - 2023-08-31 08:05:00 --> Config Class Initialized
INFO - 2023-08-31 08:05:00 --> Hooks Class Initialized
INFO - 2023-08-31 08:05:01 --> Config Class Initialized
DEBUG - 2023-08-31 08:05:01 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:05:01 --> Utf8 Class Initialized
INFO - 2023-08-31 08:05:01 --> Hooks Class Initialized
INFO - 2023-08-31 08:05:01 --> URI Class Initialized
DEBUG - 2023-08-31 08:05:01 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:05:01 --> Router Class Initialized
INFO - 2023-08-31 08:05:01 --> Utf8 Class Initialized
INFO - 2023-08-31 08:05:01 --> Output Class Initialized
INFO - 2023-08-31 08:05:01 --> Security Class Initialized
INFO - 2023-08-31 08:05:01 --> URI Class Initialized
DEBUG - 2023-08-31 08:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:05:01 --> Router Class Initialized
INFO - 2023-08-31 08:05:01 --> Output Class Initialized
INFO - 2023-08-31 08:05:01 --> Input Class Initialized
INFO - 2023-08-31 08:05:01 --> Security Class Initialized
INFO - 2023-08-31 08:05:01 --> Language Class Initialized
DEBUG - 2023-08-31 08:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:05:01 --> Input Class Initialized
ERROR - 2023-08-31 08:05:01 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:05:01 --> Language Class Initialized
ERROR - 2023-08-31 08:05:01 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:05:04 --> Config Class Initialized
INFO - 2023-08-31 08:05:04 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:05:04 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:05:04 --> Utf8 Class Initialized
INFO - 2023-08-31 08:05:04 --> URI Class Initialized
INFO - 2023-08-31 08:05:04 --> Router Class Initialized
INFO - 2023-08-31 08:05:05 --> Output Class Initialized
INFO - 2023-08-31 08:05:05 --> Security Class Initialized
DEBUG - 2023-08-31 08:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:05:05 --> Input Class Initialized
INFO - 2023-08-31 08:05:05 --> Language Class Initialized
INFO - 2023-08-31 08:05:05 --> Loader Class Initialized
INFO - 2023-08-31 08:05:05 --> Helper loaded: url_helper
INFO - 2023-08-31 08:05:05 --> Helper loaded: file_helper
INFO - 2023-08-31 08:05:05 --> Database Driver Class Initialized
INFO - 2023-08-31 08:05:05 --> Email Class Initialized
DEBUG - 2023-08-31 08:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 08:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 08:05:05 --> Controller Class Initialized
INFO - 2023-08-31 08:05:05 --> Model "Contact_model" initialized
INFO - 2023-08-31 08:05:05 --> Model "Home_model" initialized
INFO - 2023-08-31 08:05:05 --> Helper loaded: download_helper
INFO - 2023-08-31 08:05:05 --> Helper loaded: form_helper
INFO - 2023-08-31 08:05:05 --> Form Validation Class Initialized
ERROR - 2023-08-31 08:05:05 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 08:05:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 08:05:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 08:05:05 --> Final output sent to browser
DEBUG - 2023-08-31 08:05:05 --> Total execution time: 0.8556
INFO - 2023-08-31 08:05:06 --> Config Class Initialized
INFO - 2023-08-31 08:05:06 --> Config Class Initialized
INFO - 2023-08-31 08:05:06 --> Hooks Class Initialized
INFO - 2023-08-31 08:05:06 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:05:06 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:05:06 --> Utf8 Class Initialized
DEBUG - 2023-08-31 08:05:06 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:05:06 --> Utf8 Class Initialized
INFO - 2023-08-31 08:05:06 --> URI Class Initialized
INFO - 2023-08-31 08:05:06 --> URI Class Initialized
INFO - 2023-08-31 08:05:06 --> Router Class Initialized
INFO - 2023-08-31 08:05:06 --> Output Class Initialized
INFO - 2023-08-31 08:05:06 --> Router Class Initialized
INFO - 2023-08-31 08:05:06 --> Security Class Initialized
INFO - 2023-08-31 08:05:06 --> Output Class Initialized
DEBUG - 2023-08-31 08:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:05:06 --> Input Class Initialized
INFO - 2023-08-31 08:05:07 --> Security Class Initialized
DEBUG - 2023-08-31 08:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:05:07 --> Language Class Initialized
INFO - 2023-08-31 08:05:07 --> Input Class Initialized
ERROR - 2023-08-31 08:05:07 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:05:07 --> Language Class Initialized
ERROR - 2023-08-31 08:05:07 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 08:05:36 --> Config Class Initialized
INFO - 2023-08-31 08:05:36 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:05:36 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:05:36 --> Utf8 Class Initialized
INFO - 2023-08-31 08:05:36 --> URI Class Initialized
INFO - 2023-08-31 08:05:36 --> Router Class Initialized
INFO - 2023-08-31 08:05:36 --> Output Class Initialized
INFO - 2023-08-31 08:05:36 --> Security Class Initialized
DEBUG - 2023-08-31 08:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:05:36 --> Input Class Initialized
INFO - 2023-08-31 08:05:36 --> Language Class Initialized
INFO - 2023-08-31 08:05:37 --> Loader Class Initialized
INFO - 2023-08-31 08:05:37 --> Helper loaded: url_helper
INFO - 2023-08-31 08:05:37 --> Helper loaded: file_helper
INFO - 2023-08-31 08:05:37 --> Database Driver Class Initialized
INFO - 2023-08-31 08:05:37 --> Email Class Initialized
DEBUG - 2023-08-31 08:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 08:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 08:05:37 --> Controller Class Initialized
INFO - 2023-08-31 08:05:37 --> Model "Contact_model" initialized
INFO - 2023-08-31 08:05:37 --> Model "Home_model" initialized
INFO - 2023-08-31 08:05:37 --> Helper loaded: download_helper
INFO - 2023-08-31 08:05:37 --> Helper loaded: form_helper
INFO - 2023-08-31 08:05:37 --> Form Validation Class Initialized
INFO - 2023-08-31 08:05:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-31 08:05:37 --> Final output sent to browser
DEBUG - 2023-08-31 08:05:37 --> Total execution time: 0.5459
INFO - 2023-08-31 08:05:37 --> Config Class Initialized
INFO - 2023-08-31 08:05:37 --> Hooks Class Initialized
INFO - 2023-08-31 08:05:37 --> Config Class Initialized
DEBUG - 2023-08-31 08:05:37 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:05:37 --> Utf8 Class Initialized
INFO - 2023-08-31 08:05:37 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:05:37 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:05:37 --> URI Class Initialized
INFO - 2023-08-31 08:05:37 --> Utf8 Class Initialized
INFO - 2023-08-31 08:05:37 --> URI Class Initialized
INFO - 2023-08-31 08:05:38 --> Router Class Initialized
INFO - 2023-08-31 08:05:38 --> Router Class Initialized
INFO - 2023-08-31 08:05:38 --> Output Class Initialized
INFO - 2023-08-31 08:05:38 --> Output Class Initialized
INFO - 2023-08-31 08:05:38 --> Security Class Initialized
INFO - 2023-08-31 08:05:38 --> Security Class Initialized
DEBUG - 2023-08-31 08:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 08:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:05:38 --> Input Class Initialized
INFO - 2023-08-31 08:05:38 --> Input Class Initialized
INFO - 2023-08-31 08:05:38 --> Language Class Initialized
INFO - 2023-08-31 08:05:38 --> Language Class Initialized
ERROR - 2023-08-31 08:05:38 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-31 08:05:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 08:05:55 --> Config Class Initialized
INFO - 2023-08-31 08:05:55 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:05:55 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:05:55 --> Utf8 Class Initialized
INFO - 2023-08-31 08:05:55 --> URI Class Initialized
INFO - 2023-08-31 08:05:55 --> Router Class Initialized
INFO - 2023-08-31 08:05:55 --> Output Class Initialized
INFO - 2023-08-31 08:05:55 --> Security Class Initialized
DEBUG - 2023-08-31 08:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:05:55 --> Input Class Initialized
INFO - 2023-08-31 08:05:55 --> Language Class Initialized
ERROR - 2023-08-31 08:05:55 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 08:05:56 --> Config Class Initialized
INFO - 2023-08-31 08:05:56 --> Config Class Initialized
INFO - 2023-08-31 08:05:57 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:05:57 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:05:57 --> Utf8 Class Initialized
INFO - 2023-08-31 08:05:57 --> URI Class Initialized
INFO - 2023-08-31 08:05:57 --> Router Class Initialized
INFO - 2023-08-31 08:05:57 --> Output Class Initialized
INFO - 2023-08-31 08:05:57 --> Security Class Initialized
DEBUG - 2023-08-31 08:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:05:57 --> Input Class Initialized
INFO - 2023-08-31 08:05:57 --> Language Class Initialized
ERROR - 2023-08-31 08:05:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 08:05:57 --> Config Class Initialized
INFO - 2023-08-31 08:05:57 --> Hooks Class Initialized
INFO - 2023-08-31 08:05:57 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:05:57 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:05:57 --> Config Class Initialized
INFO - 2023-08-31 08:05:57 --> Utf8 Class Initialized
INFO - 2023-08-31 08:05:57 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:05:57 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:05:57 --> Config Class Initialized
INFO - 2023-08-31 08:05:57 --> Config Class Initialized
INFO - 2023-08-31 08:05:58 --> URI Class Initialized
INFO - 2023-08-31 08:05:58 --> Hooks Class Initialized
INFO - 2023-08-31 08:05:58 --> Utf8 Class Initialized
INFO - 2023-08-31 08:05:58 --> Hooks Class Initialized
INFO - 2023-08-31 08:05:59 --> Router Class Initialized
DEBUG - 2023-08-31 08:05:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 08:05:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:05:59 --> URI Class Initialized
DEBUG - 2023-08-31 08:05:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:05:59 --> Output Class Initialized
INFO - 2023-08-31 08:05:59 --> Utf8 Class Initialized
INFO - 2023-08-31 08:05:59 --> URI Class Initialized
INFO - 2023-08-31 08:05:59 --> Router Class Initialized
INFO - 2023-08-31 08:05:59 --> Output Class Initialized
INFO - 2023-08-31 08:05:59 --> Security Class Initialized
DEBUG - 2023-08-31 08:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:05:59 --> Input Class Initialized
INFO - 2023-08-31 08:05:59 --> Language Class Initialized
ERROR - 2023-08-31 08:05:59 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 08:05:59 --> Router Class Initialized
INFO - 2023-08-31 08:05:59 --> Utf8 Class Initialized
INFO - 2023-08-31 08:05:59 --> Output Class Initialized
INFO - 2023-08-31 08:05:59 --> Utf8 Class Initialized
INFO - 2023-08-31 08:05:59 --> Security Class Initialized
INFO - 2023-08-31 08:05:59 --> URI Class Initialized
DEBUG - 2023-08-31 08:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:05:59 --> Security Class Initialized
INFO - 2023-08-31 08:05:59 --> URI Class Initialized
DEBUG - 2023-08-31 08:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:05:59 --> Router Class Initialized
INFO - 2023-08-31 08:05:59 --> Input Class Initialized
INFO - 2023-08-31 08:05:59 --> Input Class Initialized
INFO - 2023-08-31 08:05:59 --> Output Class Initialized
INFO - 2023-08-31 08:05:59 --> Language Class Initialized
INFO - 2023-08-31 08:05:59 --> Router Class Initialized
INFO - 2023-08-31 08:05:59 --> Output Class Initialized
INFO - 2023-08-31 08:05:59 --> Security Class Initialized
INFO - 2023-08-31 08:05:59 --> Language Class Initialized
INFO - 2023-08-31 08:05:59 --> Security Class Initialized
ERROR - 2023-08-31 08:05:59 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-31 08:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 08:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-31 08:05:59 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 08:05:59 --> Input Class Initialized
INFO - 2023-08-31 08:05:59 --> Input Class Initialized
INFO - 2023-08-31 08:05:59 --> Language Class Initialized
INFO - 2023-08-31 08:05:59 --> Language Class Initialized
ERROR - 2023-08-31 08:05:59 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-31 08:05:59 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 08:06:35 --> Config Class Initialized
INFO - 2023-08-31 08:06:35 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:06:35 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:06:35 --> Utf8 Class Initialized
INFO - 2023-08-31 08:06:35 --> URI Class Initialized
DEBUG - 2023-08-31 08:06:35 --> No URI present. Default controller set.
INFO - 2023-08-31 08:06:35 --> Router Class Initialized
INFO - 2023-08-31 08:06:35 --> Output Class Initialized
INFO - 2023-08-31 08:06:35 --> Security Class Initialized
DEBUG - 2023-08-31 08:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:06:35 --> Input Class Initialized
INFO - 2023-08-31 08:06:35 --> Language Class Initialized
INFO - 2023-08-31 08:06:36 --> Loader Class Initialized
INFO - 2023-08-31 08:06:36 --> Helper loaded: url_helper
INFO - 2023-08-31 08:06:36 --> Helper loaded: file_helper
INFO - 2023-08-31 08:06:36 --> Database Driver Class Initialized
INFO - 2023-08-31 08:06:36 --> Email Class Initialized
DEBUG - 2023-08-31 08:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 08:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 08:06:36 --> Controller Class Initialized
INFO - 2023-08-31 08:06:36 --> Model "Contact_model" initialized
INFO - 2023-08-31 08:06:36 --> Model "Home_model" initialized
INFO - 2023-08-31 08:06:36 --> Helper loaded: download_helper
INFO - 2023-08-31 08:06:36 --> Helper loaded: form_helper
INFO - 2023-08-31 08:06:36 --> Form Validation Class Initialized
INFO - 2023-08-31 08:06:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 08:06:36 --> Final output sent to browser
DEBUG - 2023-08-31 08:06:36 --> Total execution time: 0.5962
INFO - 2023-08-31 08:06:38 --> Config Class Initialized
INFO - 2023-08-31 08:06:38 --> Hooks Class Initialized
INFO - 2023-08-31 08:06:39 --> Config Class Initialized
INFO - 2023-08-31 08:06:39 --> Hooks Class Initialized
DEBUG - 2023-08-31 08:06:39 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:06:39 --> Utf8 Class Initialized
INFO - 2023-08-31 08:06:39 --> URI Class Initialized
INFO - 2023-08-31 08:06:39 --> Router Class Initialized
INFO - 2023-08-31 08:06:39 --> Output Class Initialized
INFO - 2023-08-31 08:06:39 --> Security Class Initialized
DEBUG - 2023-08-31 08:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:06:39 --> Input Class Initialized
INFO - 2023-08-31 08:06:39 --> Language Class Initialized
ERROR - 2023-08-31 08:06:39 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 08:06:39 --> Config Class Initialized
DEBUG - 2023-08-31 08:06:39 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:06:39 --> Config Class Initialized
INFO - 2023-08-31 08:06:39 --> Hooks Class Initialized
INFO - 2023-08-31 08:06:39 --> Config Class Initialized
INFO - 2023-08-31 08:06:40 --> Config Class Initialized
INFO - 2023-08-31 08:06:40 --> Hooks Class Initialized
INFO - 2023-08-31 08:06:40 --> Hooks Class Initialized
INFO - 2023-08-31 08:06:40 --> Utf8 Class Initialized
DEBUG - 2023-08-31 08:06:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 08:06:40 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:06:40 --> URI Class Initialized
DEBUG - 2023-08-31 08:06:40 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:06:40 --> Hooks Class Initialized
INFO - 2023-08-31 08:06:40 --> Utf8 Class Initialized
DEBUG - 2023-08-31 08:06:40 --> UTF-8 Support Enabled
INFO - 2023-08-31 08:06:40 --> Utf8 Class Initialized
INFO - 2023-08-31 08:06:40 --> URI Class Initialized
INFO - 2023-08-31 08:06:40 --> Utf8 Class Initialized
INFO - 2023-08-31 08:06:40 --> Router Class Initialized
INFO - 2023-08-31 08:06:40 --> Router Class Initialized
INFO - 2023-08-31 08:06:40 --> URI Class Initialized
INFO - 2023-08-31 08:06:40 --> Utf8 Class Initialized
INFO - 2023-08-31 08:06:40 --> Router Class Initialized
INFO - 2023-08-31 08:06:40 --> Output Class Initialized
INFO - 2023-08-31 08:06:40 --> URI Class Initialized
INFO - 2023-08-31 08:06:40 --> URI Class Initialized
INFO - 2023-08-31 08:06:40 --> Security Class Initialized
INFO - 2023-08-31 08:06:40 --> Output Class Initialized
INFO - 2023-08-31 08:06:40 --> Router Class Initialized
INFO - 2023-08-31 08:06:40 --> Output Class Initialized
INFO - 2023-08-31 08:06:40 --> Router Class Initialized
INFO - 2023-08-31 08:06:40 --> Output Class Initialized
INFO - 2023-08-31 08:06:40 --> Security Class Initialized
INFO - 2023-08-31 08:06:40 --> Security Class Initialized
INFO - 2023-08-31 08:06:40 --> Security Class Initialized
DEBUG - 2023-08-31 08:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 08:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:06:40 --> Input Class Initialized
INFO - 2023-08-31 08:06:40 --> Output Class Initialized
DEBUG - 2023-08-31 08:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:06:40 --> Input Class Initialized
INFO - 2023-08-31 08:06:40 --> Security Class Initialized
INFO - 2023-08-31 08:06:40 --> Language Class Initialized
DEBUG - 2023-08-31 08:06:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-31 08:06:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 08:06:40 --> Language Class Initialized
ERROR - 2023-08-31 08:06:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 08:06:40 --> Input Class Initialized
DEBUG - 2023-08-31 08:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 08:06:40 --> Input Class Initialized
INFO - 2023-08-31 08:06:40 --> Input Class Initialized
INFO - 2023-08-31 08:06:40 --> Language Class Initialized
ERROR - 2023-08-31 08:06:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 08:06:40 --> Language Class Initialized
INFO - 2023-08-31 08:06:40 --> Language Class Initialized
ERROR - 2023-08-31 08:06:40 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-31 08:06:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:07:54 --> Config Class Initialized
INFO - 2023-08-31 09:07:54 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:07:54 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:07:54 --> Utf8 Class Initialized
INFO - 2023-08-31 09:07:54 --> URI Class Initialized
INFO - 2023-08-31 09:07:54 --> Router Class Initialized
INFO - 2023-08-31 09:07:54 --> Output Class Initialized
INFO - 2023-08-31 09:07:54 --> Security Class Initialized
DEBUG - 2023-08-31 09:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:07:54 --> Input Class Initialized
INFO - 2023-08-31 09:07:54 --> Language Class Initialized
INFO - 2023-08-31 09:07:54 --> Loader Class Initialized
INFO - 2023-08-31 09:07:54 --> Helper loaded: url_helper
INFO - 2023-08-31 09:07:54 --> Helper loaded: file_helper
INFO - 2023-08-31 09:07:54 --> Database Driver Class Initialized
INFO - 2023-08-31 09:07:54 --> Email Class Initialized
DEBUG - 2023-08-31 09:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:07:54 --> Controller Class Initialized
INFO - 2023-08-31 09:07:54 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:07:54 --> Model "Home_model" initialized
INFO - 2023-08-31 09:07:54 --> Helper loaded: download_helper
INFO - 2023-08-31 09:07:54 --> Helper loaded: form_helper
INFO - 2023-08-31 09:07:54 --> Form Validation Class Initialized
INFO - 2023-08-31 09:07:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-08-31 09:07:54 --> Final output sent to browser
DEBUG - 2023-08-31 09:07:54 --> Total execution time: 0.5133
INFO - 2023-08-31 09:07:55 --> Config Class Initialized
INFO - 2023-08-31 09:07:56 --> Hooks Class Initialized
INFO - 2023-08-31 09:07:56 --> Config Class Initialized
DEBUG - 2023-08-31 09:07:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:07:56 --> Utf8 Class Initialized
INFO - 2023-08-31 09:07:56 --> Hooks Class Initialized
INFO - 2023-08-31 09:07:56 --> URI Class Initialized
DEBUG - 2023-08-31 09:07:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:07:56 --> Router Class Initialized
INFO - 2023-08-31 09:07:56 --> Utf8 Class Initialized
INFO - 2023-08-31 09:07:56 --> Output Class Initialized
INFO - 2023-08-31 09:07:56 --> URI Class Initialized
INFO - 2023-08-31 09:07:56 --> Security Class Initialized
DEBUG - 2023-08-31 09:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:07:56 --> Router Class Initialized
INFO - 2023-08-31 09:07:56 --> Input Class Initialized
INFO - 2023-08-31 09:07:56 --> Output Class Initialized
INFO - 2023-08-31 09:07:56 --> Language Class Initialized
INFO - 2023-08-31 09:07:56 --> Security Class Initialized
ERROR - 2023-08-31 09:07:56 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 09:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:07:56 --> Input Class Initialized
INFO - 2023-08-31 09:07:56 --> Language Class Initialized
ERROR - 2023-08-31 09:07:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:08:20 --> Config Class Initialized
INFO - 2023-08-31 09:08:20 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:08:20 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:08:20 --> Utf8 Class Initialized
INFO - 2023-08-31 09:08:20 --> URI Class Initialized
INFO - 2023-08-31 09:08:20 --> Router Class Initialized
INFO - 2023-08-31 09:08:20 --> Output Class Initialized
INFO - 2023-08-31 09:08:20 --> Security Class Initialized
DEBUG - 2023-08-31 09:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:08:20 --> Input Class Initialized
INFO - 2023-08-31 09:08:20 --> Language Class Initialized
INFO - 2023-08-31 09:08:20 --> Loader Class Initialized
INFO - 2023-08-31 09:08:20 --> Helper loaded: url_helper
INFO - 2023-08-31 09:08:20 --> Helper loaded: file_helper
INFO - 2023-08-31 09:08:20 --> Database Driver Class Initialized
INFO - 2023-08-31 09:08:20 --> Email Class Initialized
DEBUG - 2023-08-31 09:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:08:20 --> Controller Class Initialized
INFO - 2023-08-31 09:08:20 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:08:20 --> Model "Home_model" initialized
INFO - 2023-08-31 09:08:20 --> Helper loaded: download_helper
INFO - 2023-08-31 09:08:20 --> Helper loaded: form_helper
INFO - 2023-08-31 09:08:20 --> Form Validation Class Initialized
INFO - 2023-08-31 09:08:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-31 09:08:20 --> Final output sent to browser
DEBUG - 2023-08-31 09:08:21 --> Total execution time: 0.6358
INFO - 2023-08-31 09:08:21 --> Config Class Initialized
INFO - 2023-08-31 09:08:21 --> Config Class Initialized
INFO - 2023-08-31 09:08:21 --> Hooks Class Initialized
INFO - 2023-08-31 09:08:21 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:08:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 09:08:22 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:08:22 --> Utf8 Class Initialized
INFO - 2023-08-31 09:08:22 --> Utf8 Class Initialized
INFO - 2023-08-31 09:08:22 --> URI Class Initialized
INFO - 2023-08-31 09:08:22 --> URI Class Initialized
INFO - 2023-08-31 09:08:22 --> Router Class Initialized
INFO - 2023-08-31 09:08:22 --> Router Class Initialized
INFO - 2023-08-31 09:08:22 --> Output Class Initialized
INFO - 2023-08-31 09:08:22 --> Output Class Initialized
INFO - 2023-08-31 09:08:22 --> Security Class Initialized
DEBUG - 2023-08-31 09:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:08:22 --> Security Class Initialized
INFO - 2023-08-31 09:08:22 --> Input Class Initialized
DEBUG - 2023-08-31 09:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:08:22 --> Language Class Initialized
INFO - 2023-08-31 09:08:22 --> Input Class Initialized
ERROR - 2023-08-31 09:08:22 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:08:22 --> Language Class Initialized
ERROR - 2023-08-31 09:08:22 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:08:28 --> Config Class Initialized
INFO - 2023-08-31 09:08:28 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:08:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:08:28 --> Utf8 Class Initialized
INFO - 2023-08-31 09:08:28 --> URI Class Initialized
INFO - 2023-08-31 09:08:28 --> Router Class Initialized
INFO - 2023-08-31 09:08:28 --> Output Class Initialized
INFO - 2023-08-31 09:08:28 --> Security Class Initialized
DEBUG - 2023-08-31 09:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:08:28 --> Input Class Initialized
INFO - 2023-08-31 09:08:28 --> Language Class Initialized
INFO - 2023-08-31 09:08:28 --> Loader Class Initialized
INFO - 2023-08-31 09:08:28 --> Helper loaded: url_helper
INFO - 2023-08-31 09:08:28 --> Helper loaded: file_helper
INFO - 2023-08-31 09:08:28 --> Database Driver Class Initialized
INFO - 2023-08-31 09:08:28 --> Email Class Initialized
DEBUG - 2023-08-31 09:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:08:28 --> Controller Class Initialized
INFO - 2023-08-31 09:08:28 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:08:28 --> Model "Home_model" initialized
INFO - 2023-08-31 09:08:28 --> Helper loaded: download_helper
INFO - 2023-08-31 09:08:28 --> Helper loaded: form_helper
INFO - 2023-08-31 09:08:28 --> Form Validation Class Initialized
ERROR - 2023-08-31 09:08:28 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 09:08:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 09:08:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 09:08:28 --> Final output sent to browser
DEBUG - 2023-08-31 09:08:29 --> Total execution time: 0.5290
INFO - 2023-08-31 09:08:29 --> Config Class Initialized
INFO - 2023-08-31 09:08:29 --> Config Class Initialized
INFO - 2023-08-31 09:08:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:08:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:08:29 --> Hooks Class Initialized
INFO - 2023-08-31 09:08:29 --> Utf8 Class Initialized
INFO - 2023-08-31 09:08:30 --> URI Class Initialized
DEBUG - 2023-08-31 09:08:30 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:08:30 --> Router Class Initialized
INFO - 2023-08-31 09:08:30 --> Utf8 Class Initialized
INFO - 2023-08-31 09:08:30 --> Output Class Initialized
INFO - 2023-08-31 09:08:30 --> URI Class Initialized
INFO - 2023-08-31 09:08:30 --> Security Class Initialized
INFO - 2023-08-31 09:08:30 --> Router Class Initialized
DEBUG - 2023-08-31 09:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:08:30 --> Output Class Initialized
INFO - 2023-08-31 09:08:30 --> Input Class Initialized
INFO - 2023-08-31 09:08:30 --> Language Class Initialized
INFO - 2023-08-31 09:08:30 --> Security Class Initialized
ERROR - 2023-08-31 09:08:30 --> 404 Page Not Found: Service-detail/assets
DEBUG - 2023-08-31 09:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:08:30 --> Input Class Initialized
INFO - 2023-08-31 09:08:30 --> Language Class Initialized
ERROR - 2023-08-31 09:08:30 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 09:09:31 --> Config Class Initialized
INFO - 2023-08-31 09:09:31 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:09:31 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:09:31 --> Utf8 Class Initialized
INFO - 2023-08-31 09:09:31 --> URI Class Initialized
INFO - 2023-08-31 09:09:31 --> Router Class Initialized
INFO - 2023-08-31 09:09:31 --> Output Class Initialized
INFO - 2023-08-31 09:09:31 --> Security Class Initialized
DEBUG - 2023-08-31 09:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:09:31 --> Input Class Initialized
INFO - 2023-08-31 09:09:31 --> Language Class Initialized
INFO - 2023-08-31 09:09:31 --> Loader Class Initialized
INFO - 2023-08-31 09:09:31 --> Helper loaded: url_helper
INFO - 2023-08-31 09:09:32 --> Helper loaded: file_helper
INFO - 2023-08-31 09:09:32 --> Database Driver Class Initialized
INFO - 2023-08-31 09:09:32 --> Email Class Initialized
DEBUG - 2023-08-31 09:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:09:32 --> Controller Class Initialized
INFO - 2023-08-31 09:09:32 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:09:32 --> Model "Home_model" initialized
INFO - 2023-08-31 09:09:32 --> Helper loaded: download_helper
INFO - 2023-08-31 09:09:32 --> Helper loaded: form_helper
INFO - 2023-08-31 09:09:32 --> Form Validation Class Initialized
ERROR - 2023-08-31 09:09:32 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 09:09:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 09:09:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 09:09:32 --> Final output sent to browser
DEBUG - 2023-08-31 09:09:32 --> Total execution time: 0.8093
INFO - 2023-08-31 09:09:32 --> Config Class Initialized
INFO - 2023-08-31 09:09:32 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:09:32 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:09:32 --> Utf8 Class Initialized
INFO - 2023-08-31 09:09:32 --> URI Class Initialized
INFO - 2023-08-31 09:09:32 --> Router Class Initialized
INFO - 2023-08-31 09:09:32 --> Output Class Initialized
INFO - 2023-08-31 09:09:32 --> Security Class Initialized
DEBUG - 2023-08-31 09:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:09:32 --> Input Class Initialized
INFO - 2023-08-31 09:09:32 --> Language Class Initialized
ERROR - 2023-08-31 09:09:32 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 09:09:33 --> Config Class Initialized
INFO - 2023-08-31 09:09:33 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:09:33 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:09:33 --> Utf8 Class Initialized
INFO - 2023-08-31 09:09:33 --> URI Class Initialized
INFO - 2023-08-31 09:09:33 --> Router Class Initialized
INFO - 2023-08-31 09:09:33 --> Output Class Initialized
INFO - 2023-08-31 09:09:33 --> Security Class Initialized
DEBUG - 2023-08-31 09:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:09:33 --> Input Class Initialized
INFO - 2023-08-31 09:09:33 --> Language Class Initialized
ERROR - 2023-08-31 09:09:33 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 09:11:27 --> Config Class Initialized
INFO - 2023-08-31 09:11:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:11:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:11:27 --> Utf8 Class Initialized
INFO - 2023-08-31 09:11:27 --> URI Class Initialized
INFO - 2023-08-31 09:11:27 --> Router Class Initialized
INFO - 2023-08-31 09:11:27 --> Output Class Initialized
INFO - 2023-08-31 09:11:27 --> Security Class Initialized
DEBUG - 2023-08-31 09:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:11:27 --> Input Class Initialized
INFO - 2023-08-31 09:11:27 --> Language Class Initialized
ERROR - 2023-08-31 09:11:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:11:27 --> Config Class Initialized
INFO - 2023-08-31 09:11:27 --> Hooks Class Initialized
INFO - 2023-08-31 09:11:27 --> Config Class Initialized
INFO - 2023-08-31 09:11:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:11:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:11:27 --> Utf8 Class Initialized
INFO - 2023-08-31 09:11:27 --> URI Class Initialized
INFO - 2023-08-31 09:11:27 --> Router Class Initialized
INFO - 2023-08-31 09:11:27 --> Output Class Initialized
INFO - 2023-08-31 09:11:27 --> Security Class Initialized
DEBUG - 2023-08-31 09:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:11:27 --> Input Class Initialized
INFO - 2023-08-31 09:11:27 --> Language Class Initialized
ERROR - 2023-08-31 09:11:27 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-31 09:11:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:11:27 --> Utf8 Class Initialized
INFO - 2023-08-31 09:11:27 --> URI Class Initialized
INFO - 2023-08-31 09:11:28 --> Router Class Initialized
INFO - 2023-08-31 09:11:28 --> Config Class Initialized
INFO - 2023-08-31 09:11:28 --> Output Class Initialized
INFO - 2023-08-31 09:11:28 --> Hooks Class Initialized
INFO - 2023-08-31 09:11:28 --> Config Class Initialized
DEBUG - 2023-08-31 09:11:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:11:28 --> Config Class Initialized
INFO - 2023-08-31 09:11:28 --> Utf8 Class Initialized
INFO - 2023-08-31 09:11:28 --> Security Class Initialized
INFO - 2023-08-31 09:11:28 --> Config Class Initialized
INFO - 2023-08-31 09:11:28 --> URI Class Initialized
INFO - 2023-08-31 09:11:28 --> Hooks Class Initialized
INFO - 2023-08-31 09:11:28 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:11:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:11:28 --> Utf8 Class Initialized
INFO - 2023-08-31 09:11:28 --> URI Class Initialized
INFO - 2023-08-31 09:11:28 --> Router Class Initialized
INFO - 2023-08-31 09:11:28 --> Output Class Initialized
INFO - 2023-08-31 09:11:28 --> Security Class Initialized
DEBUG - 2023-08-31 09:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:11:28 --> Input Class Initialized
INFO - 2023-08-31 09:11:28 --> Language Class Initialized
ERROR - 2023-08-31 09:11:28 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-31 09:11:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:11:28 --> Router Class Initialized
DEBUG - 2023-08-31 09:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:11:28 --> Output Class Initialized
INFO - 2023-08-31 09:11:28 --> Security Class Initialized
DEBUG - 2023-08-31 09:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:11:28 --> Input Class Initialized
INFO - 2023-08-31 09:11:28 --> Language Class Initialized
ERROR - 2023-08-31 09:11:28 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:11:28 --> Input Class Initialized
INFO - 2023-08-31 09:11:28 --> Utf8 Class Initialized
INFO - 2023-08-31 09:11:28 --> Language Class Initialized
INFO - 2023-08-31 09:11:28 --> Hooks Class Initialized
ERROR - 2023-08-31 09:11:28 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-31 09:11:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:11:28 --> URI Class Initialized
INFO - 2023-08-31 09:11:28 --> Router Class Initialized
INFO - 2023-08-31 09:11:28 --> Utf8 Class Initialized
INFO - 2023-08-31 09:11:28 --> Output Class Initialized
INFO - 2023-08-31 09:11:28 --> Security Class Initialized
INFO - 2023-08-31 09:11:28 --> URI Class Initialized
DEBUG - 2023-08-31 09:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:11:28 --> Router Class Initialized
INFO - 2023-08-31 09:11:28 --> Input Class Initialized
INFO - 2023-08-31 09:11:28 --> Output Class Initialized
INFO - 2023-08-31 09:11:28 --> Language Class Initialized
INFO - 2023-08-31 09:11:28 --> Security Class Initialized
ERROR - 2023-08-31 09:11:28 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-31 09:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:11:29 --> Input Class Initialized
INFO - 2023-08-31 09:11:29 --> Language Class Initialized
ERROR - 2023-08-31 09:11:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:13:38 --> Config Class Initialized
INFO - 2023-08-31 09:13:38 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:13:38 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:13:38 --> Utf8 Class Initialized
INFO - 2023-08-31 09:13:38 --> URI Class Initialized
INFO - 2023-08-31 09:13:38 --> Router Class Initialized
INFO - 2023-08-31 09:13:38 --> Output Class Initialized
INFO - 2023-08-31 09:13:38 --> Security Class Initialized
DEBUG - 2023-08-31 09:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:13:38 --> Input Class Initialized
INFO - 2023-08-31 09:13:38 --> Language Class Initialized
INFO - 2023-08-31 09:13:38 --> Loader Class Initialized
INFO - 2023-08-31 09:13:38 --> Helper loaded: url_helper
INFO - 2023-08-31 09:13:38 --> Helper loaded: file_helper
INFO - 2023-08-31 09:13:38 --> Database Driver Class Initialized
INFO - 2023-08-31 09:13:38 --> Email Class Initialized
DEBUG - 2023-08-31 09:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:13:38 --> Controller Class Initialized
INFO - 2023-08-31 09:13:38 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:13:38 --> Model "Home_model" initialized
INFO - 2023-08-31 09:13:38 --> Helper loaded: download_helper
INFO - 2023-08-31 09:13:38 --> Helper loaded: form_helper
INFO - 2023-08-31 09:13:38 --> Form Validation Class Initialized
ERROR - 2023-08-31 09:13:38 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 09:13:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 09:13:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 09:13:38 --> Final output sent to browser
DEBUG - 2023-08-31 09:13:39 --> Total execution time: 0.4953
INFO - 2023-08-31 09:13:39 --> Config Class Initialized
INFO - 2023-08-31 09:13:39 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:13:39 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:13:39 --> Utf8 Class Initialized
INFO - 2023-08-31 09:13:39 --> URI Class Initialized
INFO - 2023-08-31 09:13:39 --> Router Class Initialized
INFO - 2023-08-31 09:13:39 --> Output Class Initialized
INFO - 2023-08-31 09:13:39 --> Security Class Initialized
DEBUG - 2023-08-31 09:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:13:39 --> Input Class Initialized
INFO - 2023-08-31 09:13:39 --> Language Class Initialized
ERROR - 2023-08-31 09:13:39 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 09:13:39 --> Config Class Initialized
INFO - 2023-08-31 09:13:39 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:13:39 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:13:39 --> Utf8 Class Initialized
INFO - 2023-08-31 09:13:39 --> URI Class Initialized
INFO - 2023-08-31 09:13:39 --> Router Class Initialized
INFO - 2023-08-31 09:13:39 --> Output Class Initialized
INFO - 2023-08-31 09:13:39 --> Security Class Initialized
DEBUG - 2023-08-31 09:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:13:39 --> Input Class Initialized
INFO - 2023-08-31 09:13:39 --> Language Class Initialized
ERROR - 2023-08-31 09:13:39 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 09:32:53 --> Config Class Initialized
INFO - 2023-08-31 09:32:53 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:32:54 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:32:54 --> Utf8 Class Initialized
INFO - 2023-08-31 09:32:54 --> URI Class Initialized
DEBUG - 2023-08-31 09:32:54 --> No URI present. Default controller set.
INFO - 2023-08-31 09:32:54 --> Router Class Initialized
INFO - 2023-08-31 09:32:54 --> Output Class Initialized
INFO - 2023-08-31 09:32:54 --> Security Class Initialized
DEBUG - 2023-08-31 09:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:32:54 --> Input Class Initialized
INFO - 2023-08-31 09:32:54 --> Language Class Initialized
INFO - 2023-08-31 09:32:54 --> Loader Class Initialized
INFO - 2023-08-31 09:32:54 --> Helper loaded: url_helper
INFO - 2023-08-31 09:32:54 --> Helper loaded: file_helper
INFO - 2023-08-31 09:32:54 --> Database Driver Class Initialized
INFO - 2023-08-31 09:32:54 --> Email Class Initialized
DEBUG - 2023-08-31 09:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:32:54 --> Controller Class Initialized
INFO - 2023-08-31 09:32:54 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:32:55 --> Model "Home_model" initialized
INFO - 2023-08-31 09:32:55 --> Helper loaded: download_helper
INFO - 2023-08-31 09:32:55 --> Helper loaded: form_helper
INFO - 2023-08-31 09:32:55 --> Form Validation Class Initialized
INFO - 2023-08-31 09:32:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 09:32:55 --> Final output sent to browser
DEBUG - 2023-08-31 09:32:55 --> Total execution time: 1.2304
INFO - 2023-08-31 09:32:56 --> Config Class Initialized
INFO - 2023-08-31 09:32:56 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:32:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:32:56 --> Utf8 Class Initialized
INFO - 2023-08-31 09:32:56 --> URI Class Initialized
INFO - 2023-08-31 09:32:56 --> Router Class Initialized
INFO - 2023-08-31 09:32:56 --> Output Class Initialized
INFO - 2023-08-31 09:32:56 --> Security Class Initialized
DEBUG - 2023-08-31 09:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:32:56 --> Input Class Initialized
INFO - 2023-08-31 09:32:56 --> Language Class Initialized
ERROR - 2023-08-31 09:32:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:32:56 --> Config Class Initialized
INFO - 2023-08-31 09:32:56 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:32:56 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:32:56 --> Utf8 Class Initialized
INFO - 2023-08-31 09:32:56 --> URI Class Initialized
INFO - 2023-08-31 09:32:56 --> Router Class Initialized
INFO - 2023-08-31 09:32:56 --> Output Class Initialized
INFO - 2023-08-31 09:32:56 --> Security Class Initialized
DEBUG - 2023-08-31 09:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:32:56 --> Input Class Initialized
INFO - 2023-08-31 09:32:56 --> Language Class Initialized
ERROR - 2023-08-31 09:32:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:39:29 --> Config Class Initialized
INFO - 2023-08-31 09:39:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:39:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:39:29 --> Utf8 Class Initialized
INFO - 2023-08-31 09:39:29 --> URI Class Initialized
DEBUG - 2023-08-31 09:39:29 --> No URI present. Default controller set.
INFO - 2023-08-31 09:39:29 --> Router Class Initialized
INFO - 2023-08-31 09:39:29 --> Output Class Initialized
INFO - 2023-08-31 09:39:29 --> Security Class Initialized
DEBUG - 2023-08-31 09:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:39:30 --> Input Class Initialized
INFO - 2023-08-31 09:39:30 --> Language Class Initialized
INFO - 2023-08-31 09:39:30 --> Loader Class Initialized
INFO - 2023-08-31 09:39:30 --> Helper loaded: url_helper
INFO - 2023-08-31 09:39:30 --> Helper loaded: file_helper
INFO - 2023-08-31 09:39:30 --> Database Driver Class Initialized
INFO - 2023-08-31 09:39:30 --> Email Class Initialized
DEBUG - 2023-08-31 09:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:39:30 --> Controller Class Initialized
INFO - 2023-08-31 09:39:30 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:39:30 --> Model "Home_model" initialized
INFO - 2023-08-31 09:39:30 --> Helper loaded: download_helper
INFO - 2023-08-31 09:39:30 --> Helper loaded: form_helper
INFO - 2023-08-31 09:39:30 --> Form Validation Class Initialized
INFO - 2023-08-31 09:39:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 09:39:30 --> Final output sent to browser
DEBUG - 2023-08-31 09:39:31 --> Total execution time: 0.9869
INFO - 2023-08-31 09:39:32 --> Config Class Initialized
INFO - 2023-08-31 09:39:32 --> Config Class Initialized
INFO - 2023-08-31 09:39:32 --> Config Class Initialized
INFO - 2023-08-31 09:39:32 --> Hooks Class Initialized
INFO - 2023-08-31 09:39:32 --> Hooks Class Initialized
INFO - 2023-08-31 09:39:32 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:39:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 09:39:32 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:39:32 --> Utf8 Class Initialized
DEBUG - 2023-08-31 09:39:32 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:39:32 --> URI Class Initialized
INFO - 2023-08-31 09:39:32 --> Utf8 Class Initialized
INFO - 2023-08-31 09:39:32 --> URI Class Initialized
INFO - 2023-08-31 09:39:32 --> Router Class Initialized
INFO - 2023-08-31 09:39:32 --> Router Class Initialized
INFO - 2023-08-31 09:39:32 --> Utf8 Class Initialized
INFO - 2023-08-31 09:39:32 --> Output Class Initialized
INFO - 2023-08-31 09:39:32 --> Output Class Initialized
INFO - 2023-08-31 09:39:32 --> Security Class Initialized
INFO - 2023-08-31 09:39:32 --> URI Class Initialized
DEBUG - 2023-08-31 09:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:39:33 --> Router Class Initialized
INFO - 2023-08-31 09:39:33 --> Security Class Initialized
DEBUG - 2023-08-31 09:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:39:33 --> Input Class Initialized
INFO - 2023-08-31 09:39:33 --> Output Class Initialized
INFO - 2023-08-31 09:39:33 --> Language Class Initialized
INFO - 2023-08-31 09:39:33 --> Input Class Initialized
ERROR - 2023-08-31 09:39:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:39:33 --> Language Class Initialized
INFO - 2023-08-31 09:39:33 --> Security Class Initialized
ERROR - 2023-08-31 09:39:33 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 09:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:39:33 --> Input Class Initialized
INFO - 2023-08-31 09:39:33 --> Language Class Initialized
ERROR - 2023-08-31 09:39:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:40:40 --> Config Class Initialized
INFO - 2023-08-31 09:40:41 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:40:41 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:40:41 --> Utf8 Class Initialized
INFO - 2023-08-31 09:40:41 --> URI Class Initialized
DEBUG - 2023-08-31 09:40:41 --> No URI present. Default controller set.
INFO - 2023-08-31 09:40:41 --> Router Class Initialized
INFO - 2023-08-31 09:40:41 --> Output Class Initialized
INFO - 2023-08-31 09:40:41 --> Security Class Initialized
DEBUG - 2023-08-31 09:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:40:41 --> Input Class Initialized
INFO - 2023-08-31 09:40:41 --> Language Class Initialized
INFO - 2023-08-31 09:40:41 --> Loader Class Initialized
INFO - 2023-08-31 09:40:41 --> Helper loaded: url_helper
INFO - 2023-08-31 09:40:41 --> Helper loaded: file_helper
INFO - 2023-08-31 09:40:41 --> Database Driver Class Initialized
INFO - 2023-08-31 09:40:41 --> Email Class Initialized
DEBUG - 2023-08-31 09:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:40:41 --> Controller Class Initialized
INFO - 2023-08-31 09:40:41 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:40:41 --> Model "Home_model" initialized
INFO - 2023-08-31 09:40:41 --> Helper loaded: download_helper
INFO - 2023-08-31 09:40:41 --> Helper loaded: form_helper
INFO - 2023-08-31 09:40:41 --> Form Validation Class Initialized
INFO - 2023-08-31 09:40:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 09:40:41 --> Final output sent to browser
DEBUG - 2023-08-31 09:40:42 --> Total execution time: 0.7108
INFO - 2023-08-31 09:40:43 --> Config Class Initialized
INFO - 2023-08-31 09:40:43 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:40:43 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:40:43 --> Utf8 Class Initialized
INFO - 2023-08-31 09:40:43 --> URI Class Initialized
INFO - 2023-08-31 09:40:43 --> Router Class Initialized
INFO - 2023-08-31 09:40:43 --> Output Class Initialized
INFO - 2023-08-31 09:40:43 --> Security Class Initialized
DEBUG - 2023-08-31 09:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:40:43 --> Input Class Initialized
INFO - 2023-08-31 09:40:43 --> Language Class Initialized
ERROR - 2023-08-31 09:40:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:40:43 --> Config Class Initialized
INFO - 2023-08-31 09:40:43 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:40:43 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:40:44 --> Utf8 Class Initialized
INFO - 2023-08-31 09:40:44 --> URI Class Initialized
INFO - 2023-08-31 09:40:44 --> Router Class Initialized
INFO - 2023-08-31 09:40:44 --> Output Class Initialized
INFO - 2023-08-31 09:40:44 --> Security Class Initialized
DEBUG - 2023-08-31 09:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:40:44 --> Input Class Initialized
INFO - 2023-08-31 09:40:44 --> Language Class Initialized
ERROR - 2023-08-31 09:40:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:41:33 --> Config Class Initialized
INFO - 2023-08-31 09:41:33 --> Config Class Initialized
INFO - 2023-08-31 09:41:33 --> Hooks Class Initialized
INFO - 2023-08-31 09:41:33 --> Config Class Initialized
INFO - 2023-08-31 09:41:33 --> Hooks Class Initialized
INFO - 2023-08-31 09:41:33 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:41:33 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:41:34 --> Config Class Initialized
DEBUG - 2023-08-31 09:41:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 09:41:34 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:41:34 --> Hooks Class Initialized
INFO - 2023-08-31 09:41:34 --> Config Class Initialized
DEBUG - 2023-08-31 09:41:34 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:41:34 --> Utf8 Class Initialized
INFO - 2023-08-31 09:41:34 --> Utf8 Class Initialized
INFO - 2023-08-31 09:41:34 --> Utf8 Class Initialized
INFO - 2023-08-31 09:41:34 --> Utf8 Class Initialized
INFO - 2023-08-31 09:41:34 --> URI Class Initialized
INFO - 2023-08-31 09:41:34 --> Hooks Class Initialized
INFO - 2023-08-31 09:41:34 --> URI Class Initialized
INFO - 2023-08-31 09:41:34 --> URI Class Initialized
INFO - 2023-08-31 09:41:34 --> Router Class Initialized
INFO - 2023-08-31 09:41:34 --> Router Class Initialized
INFO - 2023-08-31 09:41:34 --> URI Class Initialized
INFO - 2023-08-31 09:41:34 --> Router Class Initialized
INFO - 2023-08-31 09:41:34 --> Router Class Initialized
DEBUG - 2023-08-31 09:41:34 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:41:34 --> Output Class Initialized
INFO - 2023-08-31 09:41:34 --> Utf8 Class Initialized
INFO - 2023-08-31 09:41:34 --> Output Class Initialized
INFO - 2023-08-31 09:41:34 --> Security Class Initialized
DEBUG - 2023-08-31 09:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:41:34 --> Input Class Initialized
INFO - 2023-08-31 09:41:34 --> Language Class Initialized
ERROR - 2023-08-31 09:41:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:41:34 --> URI Class Initialized
INFO - 2023-08-31 09:41:34 --> Router Class Initialized
INFO - 2023-08-31 09:41:34 --> Output Class Initialized
INFO - 2023-08-31 09:41:34 --> Output Class Initialized
INFO - 2023-08-31 09:41:34 --> Security Class Initialized
DEBUG - 2023-08-31 09:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:41:34 --> Security Class Initialized
INFO - 2023-08-31 09:41:34 --> Config Class Initialized
INFO - 2023-08-31 09:41:34 --> Output Class Initialized
INFO - 2023-08-31 09:41:34 --> Security Class Initialized
INFO - 2023-08-31 09:41:34 --> Config Class Initialized
DEBUG - 2023-08-31 09:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 09:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:41:34 --> Hooks Class Initialized
INFO - 2023-08-31 09:41:34 --> Input Class Initialized
INFO - 2023-08-31 09:41:34 --> Security Class Initialized
INFO - 2023-08-31 09:41:34 --> Hooks Class Initialized
INFO - 2023-08-31 09:41:34 --> Input Class Initialized
INFO - 2023-08-31 09:41:34 --> Language Class Initialized
ERROR - 2023-08-31 09:41:34 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-31 09:41:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 09:41:34 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:41:34 --> Utf8 Class Initialized
INFO - 2023-08-31 09:41:34 --> Input Class Initialized
INFO - 2023-08-31 09:41:34 --> Language Class Initialized
DEBUG - 2023-08-31 09:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:41:34 --> Utf8 Class Initialized
INFO - 2023-08-31 09:41:34 --> Input Class Initialized
INFO - 2023-08-31 09:41:34 --> URI Class Initialized
INFO - 2023-08-31 09:41:34 --> Language Class Initialized
INFO - 2023-08-31 09:41:34 --> Router Class Initialized
ERROR - 2023-08-31 09:41:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:41:34 --> Language Class Initialized
ERROR - 2023-08-31 09:41:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:41:34 --> URI Class Initialized
INFO - 2023-08-31 09:41:35 --> Output Class Initialized
INFO - 2023-08-31 09:41:35 --> Router Class Initialized
ERROR - 2023-08-31 09:41:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:41:35 --> Security Class Initialized
INFO - 2023-08-31 09:41:35 --> Output Class Initialized
DEBUG - 2023-08-31 09:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:41:35 --> Security Class Initialized
INFO - 2023-08-31 09:41:35 --> Input Class Initialized
DEBUG - 2023-08-31 09:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:41:35 --> Language Class Initialized
ERROR - 2023-08-31 09:41:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:41:35 --> Input Class Initialized
INFO - 2023-08-31 09:41:35 --> Language Class Initialized
ERROR - 2023-08-31 09:41:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:42:20 --> Config Class Initialized
INFO - 2023-08-31 09:42:20 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:42:20 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:20 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:20 --> URI Class Initialized
DEBUG - 2023-08-31 09:42:20 --> No URI present. Default controller set.
INFO - 2023-08-31 09:42:20 --> Router Class Initialized
INFO - 2023-08-31 09:42:20 --> Output Class Initialized
INFO - 2023-08-31 09:42:20 --> Security Class Initialized
DEBUG - 2023-08-31 09:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:20 --> Input Class Initialized
INFO - 2023-08-31 09:42:20 --> Language Class Initialized
INFO - 2023-08-31 09:42:20 --> Loader Class Initialized
INFO - 2023-08-31 09:42:20 --> Helper loaded: url_helper
INFO - 2023-08-31 09:42:20 --> Helper loaded: file_helper
INFO - 2023-08-31 09:42:20 --> Database Driver Class Initialized
INFO - 2023-08-31 09:42:20 --> Email Class Initialized
DEBUG - 2023-08-31 09:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:42:20 --> Controller Class Initialized
INFO - 2023-08-31 09:42:20 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:42:20 --> Model "Home_model" initialized
INFO - 2023-08-31 09:42:20 --> Helper loaded: download_helper
INFO - 2023-08-31 09:42:21 --> Helper loaded: form_helper
INFO - 2023-08-31 09:42:21 --> Form Validation Class Initialized
INFO - 2023-08-31 09:42:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 09:42:21 --> Final output sent to browser
DEBUG - 2023-08-31 09:42:21 --> Total execution time: 0.5390
INFO - 2023-08-31 09:42:23 --> Config Class Initialized
INFO - 2023-08-31 09:42:23 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:42:23 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:23 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:23 --> URI Class Initialized
INFO - 2023-08-31 09:42:23 --> Router Class Initialized
INFO - 2023-08-31 09:42:23 --> Output Class Initialized
INFO - 2023-08-31 09:42:23 --> Security Class Initialized
DEBUG - 2023-08-31 09:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:23 --> Input Class Initialized
INFO - 2023-08-31 09:42:23 --> Language Class Initialized
ERROR - 2023-08-31 09:42:23 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:42:25 --> Config Class Initialized
INFO - 2023-08-31 09:42:25 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:42:25 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:25 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:25 --> URI Class Initialized
INFO - 2023-08-31 09:42:25 --> Router Class Initialized
INFO - 2023-08-31 09:42:25 --> Output Class Initialized
INFO - 2023-08-31 09:42:25 --> Security Class Initialized
DEBUG - 2023-08-31 09:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:25 --> Input Class Initialized
INFO - 2023-08-31 09:42:25 --> Language Class Initialized
ERROR - 2023-08-31 09:42:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:42:26 --> Config Class Initialized
INFO - 2023-08-31 09:42:26 --> Config Class Initialized
INFO - 2023-08-31 09:42:26 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:42:26 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:26 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:26 --> URI Class Initialized
INFO - 2023-08-31 09:42:26 --> Router Class Initialized
INFO - 2023-08-31 09:42:26 --> Output Class Initialized
INFO - 2023-08-31 09:42:26 --> Security Class Initialized
DEBUG - 2023-08-31 09:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:26 --> Input Class Initialized
INFO - 2023-08-31 09:42:26 --> Language Class Initialized
ERROR - 2023-08-31 09:42:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:42:26 --> Config Class Initialized
INFO - 2023-08-31 09:42:26 --> Hooks Class Initialized
INFO - 2023-08-31 09:42:26 --> Config Class Initialized
INFO - 2023-08-31 09:42:26 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:42:26 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:26 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:26 --> URI Class Initialized
INFO - 2023-08-31 09:42:26 --> Router Class Initialized
INFO - 2023-08-31 09:42:26 --> Output Class Initialized
INFO - 2023-08-31 09:42:26 --> Security Class Initialized
DEBUG - 2023-08-31 09:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:26 --> Input Class Initialized
INFO - 2023-08-31 09:42:26 --> Language Class Initialized
ERROR - 2023-08-31 09:42:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:42:27 --> Config Class Initialized
INFO - 2023-08-31 09:42:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:42:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:27 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:27 --> URI Class Initialized
INFO - 2023-08-31 09:42:27 --> Router Class Initialized
INFO - 2023-08-31 09:42:27 --> Output Class Initialized
INFO - 2023-08-31 09:42:27 --> Security Class Initialized
DEBUG - 2023-08-31 09:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:27 --> Input Class Initialized
INFO - 2023-08-31 09:42:27 --> Language Class Initialized
ERROR - 2023-08-31 09:42:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:42:27 --> Hooks Class Initialized
INFO - 2023-08-31 09:42:27 --> Config Class Initialized
DEBUG - 2023-08-31 09:42:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:27 --> Hooks Class Initialized
INFO - 2023-08-31 09:42:27 --> Config Class Initialized
DEBUG - 2023-08-31 09:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 09:42:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:28 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:28 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:28 --> URI Class Initialized
INFO - 2023-08-31 09:42:28 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:28 --> Hooks Class Initialized
INFO - 2023-08-31 09:42:29 --> URI Class Initialized
INFO - 2023-08-31 09:42:29 --> URI Class Initialized
INFO - 2023-08-31 09:42:29 --> Router Class Initialized
INFO - 2023-08-31 09:42:29 --> Router Class Initialized
DEBUG - 2023-08-31 09:42:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:29 --> Output Class Initialized
INFO - 2023-08-31 09:42:29 --> Router Class Initialized
INFO - 2023-08-31 09:42:29 --> Security Class Initialized
INFO - 2023-08-31 09:42:29 --> Output Class Initialized
INFO - 2023-08-31 09:42:29 --> Output Class Initialized
INFO - 2023-08-31 09:42:29 --> Security Class Initialized
DEBUG - 2023-08-31 09:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:29 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:29 --> Security Class Initialized
INFO - 2023-08-31 09:42:29 --> URI Class Initialized
INFO - 2023-08-31 09:42:29 --> Router Class Initialized
DEBUG - 2023-08-31 09:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 09:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:29 --> Input Class Initialized
INFO - 2023-08-31 09:42:29 --> Output Class Initialized
INFO - 2023-08-31 09:42:29 --> Language Class Initialized
INFO - 2023-08-31 09:42:29 --> Input Class Initialized
ERROR - 2023-08-31 09:42:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:42:29 --> Security Class Initialized
INFO - 2023-08-31 09:42:29 --> Input Class Initialized
DEBUG - 2023-08-31 09:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:29 --> Language Class Initialized
INFO - 2023-08-31 09:42:29 --> Input Class Initialized
ERROR - 2023-08-31 09:42:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:42:29 --> Language Class Initialized
INFO - 2023-08-31 09:42:29 --> Language Class Initialized
ERROR - 2023-08-31 09:42:29 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-31 09:42:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:42:46 --> Config Class Initialized
INFO - 2023-08-31 09:42:46 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:42:46 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:46 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:46 --> URI Class Initialized
DEBUG - 2023-08-31 09:42:46 --> No URI present. Default controller set.
INFO - 2023-08-31 09:42:46 --> Router Class Initialized
INFO - 2023-08-31 09:42:46 --> Output Class Initialized
INFO - 2023-08-31 09:42:46 --> Security Class Initialized
DEBUG - 2023-08-31 09:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:46 --> Input Class Initialized
INFO - 2023-08-31 09:42:46 --> Language Class Initialized
INFO - 2023-08-31 09:42:46 --> Loader Class Initialized
INFO - 2023-08-31 09:42:46 --> Helper loaded: url_helper
INFO - 2023-08-31 09:42:46 --> Helper loaded: file_helper
INFO - 2023-08-31 09:42:46 --> Database Driver Class Initialized
INFO - 2023-08-31 09:42:46 --> Email Class Initialized
DEBUG - 2023-08-31 09:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:42:46 --> Controller Class Initialized
INFO - 2023-08-31 09:42:46 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:42:46 --> Model "Home_model" initialized
INFO - 2023-08-31 09:42:46 --> Helper loaded: download_helper
INFO - 2023-08-31 09:42:46 --> Helper loaded: form_helper
INFO - 2023-08-31 09:42:46 --> Form Validation Class Initialized
INFO - 2023-08-31 09:42:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 09:42:46 --> Final output sent to browser
DEBUG - 2023-08-31 09:42:46 --> Total execution time: 0.7595
INFO - 2023-08-31 09:42:47 --> Config Class Initialized
INFO - 2023-08-31 09:42:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:42:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:47 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:47 --> URI Class Initialized
INFO - 2023-08-31 09:42:47 --> Router Class Initialized
INFO - 2023-08-31 09:42:47 --> Output Class Initialized
INFO - 2023-08-31 09:42:47 --> Security Class Initialized
DEBUG - 2023-08-31 09:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:47 --> Input Class Initialized
INFO - 2023-08-31 09:42:47 --> Language Class Initialized
ERROR - 2023-08-31 09:42:47 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:42:48 --> Config Class Initialized
INFO - 2023-08-31 09:42:48 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:42:48 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:48 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:48 --> URI Class Initialized
INFO - 2023-08-31 09:42:48 --> Router Class Initialized
INFO - 2023-08-31 09:42:48 --> Output Class Initialized
INFO - 2023-08-31 09:42:48 --> Security Class Initialized
DEBUG - 2023-08-31 09:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:49 --> Config Class Initialized
INFO - 2023-08-31 09:42:49 --> Input Class Initialized
INFO - 2023-08-31 09:42:49 --> Hooks Class Initialized
INFO - 2023-08-31 09:42:49 --> Language Class Initialized
ERROR - 2023-08-31 09:42:49 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-31 09:42:49 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:49 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:51 --> Config Class Initialized
INFO - 2023-08-31 09:42:51 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:42:51 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:51 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:51 --> URI Class Initialized
INFO - 2023-08-31 09:42:51 --> Router Class Initialized
INFO - 2023-08-31 09:42:51 --> Output Class Initialized
INFO - 2023-08-31 09:42:51 --> Security Class Initialized
DEBUG - 2023-08-31 09:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:51 --> Input Class Initialized
INFO - 2023-08-31 09:42:51 --> Language Class Initialized
ERROR - 2023-08-31 09:42:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:42:51 --> Config Class Initialized
INFO - 2023-08-31 09:42:51 --> Config Class Initialized
INFO - 2023-08-31 09:42:52 --> Hooks Class Initialized
INFO - 2023-08-31 09:42:52 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:42:52 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:52 --> Config Class Initialized
INFO - 2023-08-31 09:42:52 --> Config Class Initialized
INFO - 2023-08-31 09:42:52 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:52 --> Hooks Class Initialized
INFO - 2023-08-31 09:42:52 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:42:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 09:42:53 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:53 --> URI Class Initialized
DEBUG - 2023-08-31 09:42:53 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:42:53 --> Router Class Initialized
INFO - 2023-08-31 09:42:53 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:53 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:53 --> URI Class Initialized
INFO - 2023-08-31 09:42:53 --> URI Class Initialized
INFO - 2023-08-31 09:42:53 --> Utf8 Class Initialized
INFO - 2023-08-31 09:42:53 --> Router Class Initialized
INFO - 2023-08-31 09:42:53 --> Output Class Initialized
INFO - 2023-08-31 09:42:53 --> URI Class Initialized
INFO - 2023-08-31 09:42:53 --> Output Class Initialized
INFO - 2023-08-31 09:42:53 --> Security Class Initialized
DEBUG - 2023-08-31 09:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:53 --> Input Class Initialized
INFO - 2023-08-31 09:42:53 --> Language Class Initialized
ERROR - 2023-08-31 09:42:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:42:53 --> Router Class Initialized
INFO - 2023-08-31 09:42:53 --> Router Class Initialized
INFO - 2023-08-31 09:42:53 --> Output Class Initialized
INFO - 2023-08-31 09:42:53 --> Output Class Initialized
INFO - 2023-08-31 09:42:53 --> Security Class Initialized
INFO - 2023-08-31 09:42:53 --> Security Class Initialized
INFO - 2023-08-31 09:42:53 --> Security Class Initialized
DEBUG - 2023-08-31 09:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 09:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:53 --> Input Class Initialized
DEBUG - 2023-08-31 09:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:42:53 --> Language Class Initialized
INFO - 2023-08-31 09:42:53 --> Input Class Initialized
INFO - 2023-08-31 09:42:53 --> Input Class Initialized
INFO - 2023-08-31 09:42:53 --> Language Class Initialized
ERROR - 2023-08-31 09:42:53 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-31 09:42:53 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:42:53 --> Language Class Initialized
ERROR - 2023-08-31 09:42:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:44:48 --> Config Class Initialized
INFO - 2023-08-31 09:44:48 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:44:48 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:44:48 --> Utf8 Class Initialized
INFO - 2023-08-31 09:44:48 --> URI Class Initialized
DEBUG - 2023-08-31 09:44:48 --> No URI present. Default controller set.
INFO - 2023-08-31 09:44:48 --> Router Class Initialized
INFO - 2023-08-31 09:44:48 --> Output Class Initialized
INFO - 2023-08-31 09:44:48 --> Security Class Initialized
DEBUG - 2023-08-31 09:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:44:48 --> Input Class Initialized
INFO - 2023-08-31 09:44:48 --> Language Class Initialized
INFO - 2023-08-31 09:44:48 --> Loader Class Initialized
INFO - 2023-08-31 09:44:48 --> Helper loaded: url_helper
INFO - 2023-08-31 09:44:48 --> Helper loaded: file_helper
INFO - 2023-08-31 09:44:48 --> Database Driver Class Initialized
INFO - 2023-08-31 09:44:48 --> Email Class Initialized
DEBUG - 2023-08-31 09:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:44:49 --> Controller Class Initialized
INFO - 2023-08-31 09:44:49 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:44:49 --> Model "Home_model" initialized
INFO - 2023-08-31 09:44:49 --> Helper loaded: download_helper
INFO - 2023-08-31 09:44:49 --> Helper loaded: form_helper
INFO - 2023-08-31 09:44:49 --> Form Validation Class Initialized
INFO - 2023-08-31 09:44:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 09:44:49 --> Final output sent to browser
DEBUG - 2023-08-31 09:44:49 --> Total execution time: 0.5332
INFO - 2023-08-31 09:44:49 --> Config Class Initialized
INFO - 2023-08-31 09:44:49 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:44:49 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:44:49 --> Utf8 Class Initialized
INFO - 2023-08-31 09:44:49 --> URI Class Initialized
INFO - 2023-08-31 09:44:49 --> Router Class Initialized
INFO - 2023-08-31 09:44:49 --> Output Class Initialized
INFO - 2023-08-31 09:44:49 --> Security Class Initialized
DEBUG - 2023-08-31 09:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:44:49 --> Input Class Initialized
INFO - 2023-08-31 09:44:49 --> Language Class Initialized
ERROR - 2023-08-31 09:44:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:44:50 --> Config Class Initialized
INFO - 2023-08-31 09:44:50 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:44:50 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:44:50 --> Utf8 Class Initialized
INFO - 2023-08-31 09:44:50 --> URI Class Initialized
INFO - 2023-08-31 09:44:50 --> Router Class Initialized
INFO - 2023-08-31 09:44:50 --> Output Class Initialized
INFO - 2023-08-31 09:44:50 --> Security Class Initialized
DEBUG - 2023-08-31 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:44:50 --> Input Class Initialized
INFO - 2023-08-31 09:44:50 --> Language Class Initialized
ERROR - 2023-08-31 09:44:50 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:44:50 --> Config Class Initialized
INFO - 2023-08-31 09:44:50 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:44:50 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:44:50 --> Utf8 Class Initialized
INFO - 2023-08-31 09:44:50 --> URI Class Initialized
INFO - 2023-08-31 09:44:50 --> Router Class Initialized
INFO - 2023-08-31 09:44:50 --> Output Class Initialized
INFO - 2023-08-31 09:44:50 --> Security Class Initialized
DEBUG - 2023-08-31 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:44:50 --> Input Class Initialized
INFO - 2023-08-31 09:44:50 --> Language Class Initialized
ERROR - 2023-08-31 09:44:50 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:44:50 --> Config Class Initialized
INFO - 2023-08-31 09:44:50 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:44:50 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:44:50 --> Utf8 Class Initialized
INFO - 2023-08-31 09:44:50 --> URI Class Initialized
INFO - 2023-08-31 09:44:50 --> Router Class Initialized
INFO - 2023-08-31 09:44:50 --> Output Class Initialized
INFO - 2023-08-31 09:44:50 --> Security Class Initialized
DEBUG - 2023-08-31 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:44:50 --> Input Class Initialized
INFO - 2023-08-31 09:44:50 --> Language Class Initialized
ERROR - 2023-08-31 09:44:50 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 09:46:06 --> Config Class Initialized
INFO - 2023-08-31 09:46:06 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:46:06 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:46:06 --> Utf8 Class Initialized
INFO - 2023-08-31 09:46:06 --> URI Class Initialized
DEBUG - 2023-08-31 09:46:06 --> No URI present. Default controller set.
INFO - 2023-08-31 09:46:06 --> Router Class Initialized
INFO - 2023-08-31 09:46:06 --> Output Class Initialized
INFO - 2023-08-31 09:46:06 --> Security Class Initialized
DEBUG - 2023-08-31 09:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:46:06 --> Input Class Initialized
INFO - 2023-08-31 09:46:06 --> Language Class Initialized
INFO - 2023-08-31 09:46:06 --> Loader Class Initialized
INFO - 2023-08-31 09:46:07 --> Helper loaded: url_helper
INFO - 2023-08-31 09:46:07 --> Helper loaded: file_helper
INFO - 2023-08-31 09:46:07 --> Database Driver Class Initialized
INFO - 2023-08-31 09:46:07 --> Email Class Initialized
DEBUG - 2023-08-31 09:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:46:07 --> Controller Class Initialized
INFO - 2023-08-31 09:46:07 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:46:07 --> Model "Home_model" initialized
INFO - 2023-08-31 09:46:07 --> Helper loaded: download_helper
INFO - 2023-08-31 09:46:07 --> Helper loaded: form_helper
INFO - 2023-08-31 09:46:07 --> Form Validation Class Initialized
INFO - 2023-08-31 09:46:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 09:46:07 --> Final output sent to browser
DEBUG - 2023-08-31 09:46:07 --> Total execution time: 0.8832
INFO - 2023-08-31 09:46:09 --> Config Class Initialized
INFO - 2023-08-31 09:46:09 --> Hooks Class Initialized
INFO - 2023-08-31 09:46:09 --> Config Class Initialized
DEBUG - 2023-08-31 09:46:09 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:46:09 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:46:09 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:46:09 --> Utf8 Class Initialized
INFO - 2023-08-31 09:46:09 --> Utf8 Class Initialized
INFO - 2023-08-31 09:46:09 --> URI Class Initialized
INFO - 2023-08-31 09:46:09 --> URI Class Initialized
INFO - 2023-08-31 09:46:09 --> Router Class Initialized
INFO - 2023-08-31 09:46:09 --> Router Class Initialized
INFO - 2023-08-31 09:46:09 --> Output Class Initialized
INFO - 2023-08-31 09:46:09 --> Output Class Initialized
INFO - 2023-08-31 09:46:09 --> Security Class Initialized
INFO - 2023-08-31 09:46:09 --> Security Class Initialized
DEBUG - 2023-08-31 09:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 09:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:46:09 --> Input Class Initialized
INFO - 2023-08-31 09:46:09 --> Input Class Initialized
INFO - 2023-08-31 09:46:09 --> Language Class Initialized
INFO - 2023-08-31 09:46:09 --> Language Class Initialized
ERROR - 2023-08-31 09:46:09 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-31 09:46:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:46:24 --> Config Class Initialized
INFO - 2023-08-31 09:46:24 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:46:24 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:46:24 --> Utf8 Class Initialized
INFO - 2023-08-31 09:46:24 --> URI Class Initialized
DEBUG - 2023-08-31 09:46:24 --> No URI present. Default controller set.
INFO - 2023-08-31 09:46:24 --> Router Class Initialized
INFO - 2023-08-31 09:46:24 --> Output Class Initialized
INFO - 2023-08-31 09:46:24 --> Security Class Initialized
DEBUG - 2023-08-31 09:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:46:24 --> Input Class Initialized
INFO - 2023-08-31 09:46:24 --> Language Class Initialized
INFO - 2023-08-31 09:46:24 --> Loader Class Initialized
INFO - 2023-08-31 09:46:24 --> Helper loaded: url_helper
INFO - 2023-08-31 09:46:24 --> Helper loaded: file_helper
INFO - 2023-08-31 09:46:24 --> Database Driver Class Initialized
INFO - 2023-08-31 09:46:24 --> Email Class Initialized
DEBUG - 2023-08-31 09:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:46:25 --> Controller Class Initialized
INFO - 2023-08-31 09:46:25 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:46:25 --> Model "Home_model" initialized
INFO - 2023-08-31 09:46:25 --> Helper loaded: download_helper
INFO - 2023-08-31 09:46:25 --> Helper loaded: form_helper
INFO - 2023-08-31 09:46:25 --> Form Validation Class Initialized
INFO - 2023-08-31 09:46:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 09:46:25 --> Final output sent to browser
DEBUG - 2023-08-31 09:46:25 --> Total execution time: 1.2435
INFO - 2023-08-31 09:46:26 --> Config Class Initialized
INFO - 2023-08-31 09:46:26 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:46:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:46:27 --> Utf8 Class Initialized
INFO - 2023-08-31 09:46:27 --> URI Class Initialized
INFO - 2023-08-31 09:46:27 --> Router Class Initialized
INFO - 2023-08-31 09:46:27 --> Output Class Initialized
INFO - 2023-08-31 09:46:27 --> Security Class Initialized
DEBUG - 2023-08-31 09:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:46:27 --> Input Class Initialized
INFO - 2023-08-31 09:46:27 --> Language Class Initialized
ERROR - 2023-08-31 09:46:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:46:27 --> Config Class Initialized
INFO - 2023-08-31 09:46:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:46:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:46:27 --> Utf8 Class Initialized
INFO - 2023-08-31 09:46:27 --> URI Class Initialized
INFO - 2023-08-31 09:46:27 --> Router Class Initialized
INFO - 2023-08-31 09:46:27 --> Output Class Initialized
INFO - 2023-08-31 09:46:27 --> Security Class Initialized
DEBUG - 2023-08-31 09:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:46:27 --> Input Class Initialized
INFO - 2023-08-31 09:46:28 --> Language Class Initialized
ERROR - 2023-08-31 09:46:28 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:47:32 --> Config Class Initialized
INFO - 2023-08-31 09:47:32 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:47:32 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:47:32 --> Utf8 Class Initialized
INFO - 2023-08-31 09:47:32 --> URI Class Initialized
DEBUG - 2023-08-31 09:47:32 --> No URI present. Default controller set.
INFO - 2023-08-31 09:47:32 --> Router Class Initialized
INFO - 2023-08-31 09:47:32 --> Output Class Initialized
INFO - 2023-08-31 09:47:32 --> Security Class Initialized
DEBUG - 2023-08-31 09:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:47:32 --> Input Class Initialized
INFO - 2023-08-31 09:47:32 --> Language Class Initialized
INFO - 2023-08-31 09:47:33 --> Loader Class Initialized
INFO - 2023-08-31 09:47:33 --> Helper loaded: url_helper
INFO - 2023-08-31 09:47:33 --> Helper loaded: file_helper
INFO - 2023-08-31 09:47:33 --> Database Driver Class Initialized
INFO - 2023-08-31 09:47:33 --> Email Class Initialized
DEBUG - 2023-08-31 09:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:47:33 --> Controller Class Initialized
INFO - 2023-08-31 09:47:33 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:47:33 --> Model "Home_model" initialized
INFO - 2023-08-31 09:47:33 --> Helper loaded: download_helper
INFO - 2023-08-31 09:47:33 --> Helper loaded: form_helper
INFO - 2023-08-31 09:47:33 --> Form Validation Class Initialized
INFO - 2023-08-31 09:47:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 09:47:33 --> Final output sent to browser
DEBUG - 2023-08-31 09:47:34 --> Total execution time: 1.4871
INFO - 2023-08-31 09:47:34 --> Config Class Initialized
INFO - 2023-08-31 09:47:34 --> Config Class Initialized
INFO - 2023-08-31 09:47:34 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:47:35 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:47:35 --> Hooks Class Initialized
INFO - 2023-08-31 09:47:35 --> Utf8 Class Initialized
DEBUG - 2023-08-31 09:47:35 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:47:35 --> URI Class Initialized
INFO - 2023-08-31 09:47:35 --> Router Class Initialized
INFO - 2023-08-31 09:47:35 --> Utf8 Class Initialized
INFO - 2023-08-31 09:47:35 --> Output Class Initialized
INFO - 2023-08-31 09:47:35 --> URI Class Initialized
INFO - 2023-08-31 09:47:35 --> Router Class Initialized
INFO - 2023-08-31 09:47:35 --> Security Class Initialized
INFO - 2023-08-31 09:47:35 --> Output Class Initialized
DEBUG - 2023-08-31 09:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:47:35 --> Security Class Initialized
DEBUG - 2023-08-31 09:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:47:35 --> Input Class Initialized
INFO - 2023-08-31 09:47:35 --> Input Class Initialized
INFO - 2023-08-31 09:47:35 --> Language Class Initialized
INFO - 2023-08-31 09:47:35 --> Language Class Initialized
ERROR - 2023-08-31 09:47:35 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-31 09:47:35 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:47:38 --> Config Class Initialized
INFO - 2023-08-31 09:47:38 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:47:38 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:47:38 --> Utf8 Class Initialized
INFO - 2023-08-31 09:47:38 --> URI Class Initialized
INFO - 2023-08-31 09:47:38 --> Router Class Initialized
INFO - 2023-08-31 09:47:38 --> Output Class Initialized
INFO - 2023-08-31 09:47:38 --> Security Class Initialized
DEBUG - 2023-08-31 09:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:47:38 --> Input Class Initialized
INFO - 2023-08-31 09:47:38 --> Language Class Initialized
INFO - 2023-08-31 09:47:38 --> Loader Class Initialized
INFO - 2023-08-31 09:47:38 --> Helper loaded: url_helper
INFO - 2023-08-31 09:47:38 --> Helper loaded: file_helper
INFO - 2023-08-31 09:47:38 --> Database Driver Class Initialized
INFO - 2023-08-31 09:47:39 --> Email Class Initialized
DEBUG - 2023-08-31 09:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:47:39 --> Controller Class Initialized
INFO - 2023-08-31 09:47:39 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:47:39 --> Model "Home_model" initialized
INFO - 2023-08-31 09:47:39 --> Helper loaded: download_helper
INFO - 2023-08-31 09:47:39 --> Helper loaded: form_helper
INFO - 2023-08-31 09:47:39 --> Form Validation Class Initialized
INFO - 2023-08-31 09:47:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-31 09:47:39 --> Final output sent to browser
DEBUG - 2023-08-31 09:47:39 --> Total execution time: 1.2501
INFO - 2023-08-31 09:47:40 --> Config Class Initialized
INFO - 2023-08-31 09:47:40 --> Config Class Initialized
INFO - 2023-08-31 09:47:40 --> Hooks Class Initialized
INFO - 2023-08-31 09:47:40 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:47:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 09:47:41 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:47:41 --> Utf8 Class Initialized
INFO - 2023-08-31 09:47:41 --> URI Class Initialized
INFO - 2023-08-31 09:47:41 --> Utf8 Class Initialized
INFO - 2023-08-31 09:47:41 --> Router Class Initialized
INFO - 2023-08-31 09:47:41 --> URI Class Initialized
INFO - 2023-08-31 09:47:41 --> Output Class Initialized
INFO - 2023-08-31 09:47:41 --> Security Class Initialized
INFO - 2023-08-31 09:47:41 --> Router Class Initialized
DEBUG - 2023-08-31 09:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:47:41 --> Output Class Initialized
INFO - 2023-08-31 09:47:41 --> Input Class Initialized
INFO - 2023-08-31 09:47:41 --> Security Class Initialized
INFO - 2023-08-31 09:47:41 --> Language Class Initialized
DEBUG - 2023-08-31 09:47:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-31 09:47:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:47:41 --> Input Class Initialized
INFO - 2023-08-31 09:47:41 --> Language Class Initialized
ERROR - 2023-08-31 09:47:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:47:42 --> Config Class Initialized
INFO - 2023-08-31 09:47:42 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:47:42 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:47:42 --> Utf8 Class Initialized
INFO - 2023-08-31 09:47:42 --> URI Class Initialized
DEBUG - 2023-08-31 09:47:42 --> No URI present. Default controller set.
INFO - 2023-08-31 09:47:42 --> Router Class Initialized
INFO - 2023-08-31 09:47:42 --> Output Class Initialized
INFO - 2023-08-31 09:47:42 --> Security Class Initialized
DEBUG - 2023-08-31 09:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:47:43 --> Input Class Initialized
INFO - 2023-08-31 09:47:43 --> Language Class Initialized
INFO - 2023-08-31 09:47:43 --> Loader Class Initialized
INFO - 2023-08-31 09:47:43 --> Helper loaded: url_helper
INFO - 2023-08-31 09:47:43 --> Helper loaded: file_helper
INFO - 2023-08-31 09:47:43 --> Database Driver Class Initialized
INFO - 2023-08-31 09:47:43 --> Email Class Initialized
DEBUG - 2023-08-31 09:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:47:43 --> Controller Class Initialized
INFO - 2023-08-31 09:47:43 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:47:43 --> Model "Home_model" initialized
INFO - 2023-08-31 09:47:43 --> Helper loaded: download_helper
INFO - 2023-08-31 09:47:43 --> Helper loaded: form_helper
INFO - 2023-08-31 09:47:43 --> Form Validation Class Initialized
INFO - 2023-08-31 09:47:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 09:49:00 --> Config Class Initialized
INFO - 2023-08-31 09:49:00 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:49:00 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:49:00 --> Utf8 Class Initialized
INFO - 2023-08-31 09:49:00 --> URI Class Initialized
INFO - 2023-08-31 09:49:00 --> Router Class Initialized
INFO - 2023-08-31 09:49:01 --> Output Class Initialized
INFO - 2023-08-31 09:49:01 --> Security Class Initialized
DEBUG - 2023-08-31 09:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:49:01 --> Input Class Initialized
INFO - 2023-08-31 09:49:01 --> Language Class Initialized
INFO - 2023-08-31 09:49:01 --> Loader Class Initialized
INFO - 2023-08-31 09:49:01 --> Helper loaded: url_helper
INFO - 2023-08-31 09:49:01 --> Helper loaded: file_helper
INFO - 2023-08-31 09:49:01 --> Database Driver Class Initialized
INFO - 2023-08-31 09:49:01 --> Email Class Initialized
DEBUG - 2023-08-31 09:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:49:01 --> Controller Class Initialized
INFO - 2023-08-31 09:49:01 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:49:01 --> Model "Home_model" initialized
INFO - 2023-08-31 09:49:01 --> Helper loaded: download_helper
INFO - 2023-08-31 09:49:01 --> Helper loaded: form_helper
INFO - 2023-08-31 09:49:01 --> Form Validation Class Initialized
INFO - 2023-08-31 09:49:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-31 09:49:01 --> Final output sent to browser
DEBUG - 2023-08-31 09:49:01 --> Total execution time: 0.9304
INFO - 2023-08-31 09:49:02 --> Config Class Initialized
INFO - 2023-08-31 09:49:02 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:49:02 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:49:03 --> Utf8 Class Initialized
INFO - 2023-08-31 09:49:03 --> URI Class Initialized
INFO - 2023-08-31 09:49:03 --> Router Class Initialized
INFO - 2023-08-31 09:49:03 --> Output Class Initialized
INFO - 2023-08-31 09:49:03 --> Security Class Initialized
DEBUG - 2023-08-31 09:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:49:03 --> Input Class Initialized
INFO - 2023-08-31 09:49:03 --> Language Class Initialized
ERROR - 2023-08-31 09:49:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:49:03 --> Config Class Initialized
INFO - 2023-08-31 09:49:03 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:49:03 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:49:03 --> Utf8 Class Initialized
INFO - 2023-08-31 09:49:03 --> URI Class Initialized
INFO - 2023-08-31 09:49:03 --> Router Class Initialized
INFO - 2023-08-31 09:49:03 --> Output Class Initialized
INFO - 2023-08-31 09:49:03 --> Security Class Initialized
DEBUG - 2023-08-31 09:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:49:03 --> Input Class Initialized
INFO - 2023-08-31 09:49:03 --> Language Class Initialized
ERROR - 2023-08-31 09:49:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:49:21 --> Config Class Initialized
INFO - 2023-08-31 09:49:21 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:49:21 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:49:21 --> Utf8 Class Initialized
INFO - 2023-08-31 09:49:21 --> URI Class Initialized
INFO - 2023-08-31 09:49:21 --> Router Class Initialized
INFO - 2023-08-31 09:49:21 --> Output Class Initialized
INFO - 2023-08-31 09:49:21 --> Security Class Initialized
DEBUG - 2023-08-31 09:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:49:21 --> Input Class Initialized
INFO - 2023-08-31 09:49:21 --> Language Class Initialized
INFO - 2023-08-31 09:49:22 --> Loader Class Initialized
INFO - 2023-08-31 09:49:22 --> Helper loaded: url_helper
INFO - 2023-08-31 09:49:22 --> Helper loaded: file_helper
INFO - 2023-08-31 09:49:22 --> Database Driver Class Initialized
INFO - 2023-08-31 09:49:22 --> Email Class Initialized
DEBUG - 2023-08-31 09:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 09:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 09:49:22 --> Controller Class Initialized
INFO - 2023-08-31 09:49:22 --> Model "Contact_model" initialized
INFO - 2023-08-31 09:49:22 --> Model "Home_model" initialized
INFO - 2023-08-31 09:49:22 --> Helper loaded: download_helper
INFO - 2023-08-31 09:49:22 --> Helper loaded: form_helper
INFO - 2023-08-31 09:49:22 --> Form Validation Class Initialized
INFO - 2023-08-31 09:49:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-08-31 09:49:22 --> Final output sent to browser
DEBUG - 2023-08-31 09:49:23 --> Total execution time: 1.3178
INFO - 2023-08-31 09:49:23 --> Config Class Initialized
INFO - 2023-08-31 09:49:23 --> Hooks Class Initialized
DEBUG - 2023-08-31 09:49:23 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:49:23 --> Config Class Initialized
INFO - 2023-08-31 09:49:23 --> Hooks Class Initialized
INFO - 2023-08-31 09:49:23 --> Utf8 Class Initialized
DEBUG - 2023-08-31 09:49:23 --> UTF-8 Support Enabled
INFO - 2023-08-31 09:49:23 --> Utf8 Class Initialized
INFO - 2023-08-31 09:49:24 --> URI Class Initialized
INFO - 2023-08-31 09:49:24 --> URI Class Initialized
INFO - 2023-08-31 09:49:24 --> Router Class Initialized
INFO - 2023-08-31 09:49:24 --> Router Class Initialized
INFO - 2023-08-31 09:49:24 --> Output Class Initialized
INFO - 2023-08-31 09:49:24 --> Output Class Initialized
INFO - 2023-08-31 09:49:24 --> Security Class Initialized
INFO - 2023-08-31 09:49:24 --> Security Class Initialized
DEBUG - 2023-08-31 09:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 09:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 09:49:24 --> Input Class Initialized
INFO - 2023-08-31 09:49:24 --> Input Class Initialized
INFO - 2023-08-31 09:49:24 --> Language Class Initialized
ERROR - 2023-08-31 09:49:24 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 09:49:24 --> Language Class Initialized
ERROR - 2023-08-31 09:49:24 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 10:52:09 --> Config Class Initialized
INFO - 2023-08-31 10:52:09 --> Hooks Class Initialized
DEBUG - 2023-08-31 10:52:09 --> UTF-8 Support Enabled
INFO - 2023-08-31 10:52:09 --> Utf8 Class Initialized
INFO - 2023-08-31 10:52:09 --> URI Class Initialized
DEBUG - 2023-08-31 10:52:10 --> No URI present. Default controller set.
INFO - 2023-08-31 10:52:10 --> Router Class Initialized
INFO - 2023-08-31 10:52:10 --> Output Class Initialized
INFO - 2023-08-31 10:52:10 --> Security Class Initialized
DEBUG - 2023-08-31 10:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 10:52:10 --> Input Class Initialized
INFO - 2023-08-31 10:52:10 --> Language Class Initialized
INFO - 2023-08-31 10:52:10 --> Loader Class Initialized
INFO - 2023-08-31 10:52:10 --> Helper loaded: url_helper
INFO - 2023-08-31 10:52:10 --> Helper loaded: file_helper
INFO - 2023-08-31 10:52:11 --> Database Driver Class Initialized
INFO - 2023-08-31 10:52:11 --> Email Class Initialized
DEBUG - 2023-08-31 10:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 10:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 10:52:11 --> Controller Class Initialized
INFO - 2023-08-31 10:52:11 --> Model "Contact_model" initialized
INFO - 2023-08-31 10:52:11 --> Model "Home_model" initialized
INFO - 2023-08-31 10:52:11 --> Helper loaded: download_helper
INFO - 2023-08-31 10:52:11 --> Helper loaded: form_helper
INFO - 2023-08-31 10:52:11 --> Form Validation Class Initialized
INFO - 2023-08-31 10:52:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 10:52:12 --> Final output sent to browser
DEBUG - 2023-08-31 10:52:12 --> Total execution time: 2.5047
INFO - 2023-08-31 10:52:13 --> Config Class Initialized
INFO - 2023-08-31 10:52:13 --> Hooks Class Initialized
DEBUG - 2023-08-31 10:52:13 --> UTF-8 Support Enabled
INFO - 2023-08-31 10:52:13 --> Utf8 Class Initialized
INFO - 2023-08-31 10:52:13 --> URI Class Initialized
INFO - 2023-08-31 10:52:13 --> Router Class Initialized
INFO - 2023-08-31 10:52:13 --> Output Class Initialized
INFO - 2023-08-31 10:52:13 --> Security Class Initialized
DEBUG - 2023-08-31 10:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 10:52:13 --> Input Class Initialized
INFO - 2023-08-31 10:52:13 --> Language Class Initialized
INFO - 2023-08-31 10:52:13 --> Config Class Initialized
INFO - 2023-08-31 10:52:13 --> Hooks Class Initialized
DEBUG - 2023-08-31 10:52:13 --> UTF-8 Support Enabled
INFO - 2023-08-31 10:52:13 --> Utf8 Class Initialized
INFO - 2023-08-31 10:52:13 --> URI Class Initialized
INFO - 2023-08-31 10:52:13 --> Router Class Initialized
INFO - 2023-08-31 10:52:13 --> Output Class Initialized
INFO - 2023-08-31 10:52:13 --> Security Class Initialized
DEBUG - 2023-08-31 10:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 10:52:13 --> Input Class Initialized
INFO - 2023-08-31 10:52:13 --> Language Class Initialized
ERROR - 2023-08-31 10:52:13 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-31 10:52:13 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:00:14 --> Config Class Initialized
INFO - 2023-08-31 11:00:14 --> Config Class Initialized
INFO - 2023-08-31 11:00:14 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:00:14 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:00:14 --> Config Class Initialized
INFO - 2023-08-31 11:00:14 --> Config Class Initialized
INFO - 2023-08-31 11:00:14 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:00:14 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:00:14 --> Utf8 Class Initialized
INFO - 2023-08-31 11:00:14 --> URI Class Initialized
INFO - 2023-08-31 11:00:14 --> Router Class Initialized
INFO - 2023-08-31 11:00:14 --> Output Class Initialized
INFO - 2023-08-31 11:00:14 --> Security Class Initialized
DEBUG - 2023-08-31 11:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:00:14 --> Input Class Initialized
INFO - 2023-08-31 11:00:14 --> Language Class Initialized
ERROR - 2023-08-31 11:00:14 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:00:14 --> Hooks Class Initialized
INFO - 2023-08-31 11:00:14 --> Hooks Class Initialized
INFO - 2023-08-31 11:00:14 --> Config Class Initialized
INFO - 2023-08-31 11:00:14 --> Utf8 Class Initialized
INFO - 2023-08-31 11:00:14 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:00:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 11:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 11:00:15 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:00:15 --> Utf8 Class Initialized
INFO - 2023-08-31 11:00:15 --> URI Class Initialized
INFO - 2023-08-31 11:00:15 --> Router Class Initialized
INFO - 2023-08-31 11:00:15 --> Output Class Initialized
INFO - 2023-08-31 11:00:15 --> Security Class Initialized
DEBUG - 2023-08-31 11:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:00:15 --> Input Class Initialized
INFO - 2023-08-31 11:00:15 --> Language Class Initialized
ERROR - 2023-08-31 11:00:15 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:00:15 --> Utf8 Class Initialized
INFO - 2023-08-31 11:00:15 --> URI Class Initialized
INFO - 2023-08-31 11:00:15 --> URI Class Initialized
INFO - 2023-08-31 11:00:15 --> Router Class Initialized
INFO - 2023-08-31 11:00:15 --> Config Class Initialized
INFO - 2023-08-31 11:00:15 --> Utf8 Class Initialized
INFO - 2023-08-31 11:00:16 --> Router Class Initialized
INFO - 2023-08-31 11:00:16 --> Hooks Class Initialized
INFO - 2023-08-31 11:00:16 --> Output Class Initialized
DEBUG - 2023-08-31 11:00:16 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:00:16 --> URI Class Initialized
INFO - 2023-08-31 11:00:16 --> Router Class Initialized
INFO - 2023-08-31 11:00:16 --> Output Class Initialized
INFO - 2023-08-31 11:00:16 --> Utf8 Class Initialized
INFO - 2023-08-31 11:00:16 --> Security Class Initialized
INFO - 2023-08-31 11:00:16 --> Security Class Initialized
INFO - 2023-08-31 11:00:16 --> Output Class Initialized
DEBUG - 2023-08-31 11:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:00:16 --> URI Class Initialized
INFO - 2023-08-31 11:00:16 --> Router Class Initialized
DEBUG - 2023-08-31 11:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:00:16 --> Input Class Initialized
INFO - 2023-08-31 11:00:16 --> Input Class Initialized
INFO - 2023-08-31 11:00:16 --> Language Class Initialized
INFO - 2023-08-31 11:00:16 --> Language Class Initialized
ERROR - 2023-08-31 11:00:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:00:16 --> Security Class Initialized
DEBUG - 2023-08-31 11:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:00:16 --> Output Class Initialized
ERROR - 2023-08-31 11:00:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:00:16 --> Security Class Initialized
INFO - 2023-08-31 11:00:16 --> Input Class Initialized
DEBUG - 2023-08-31 11:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:00:16 --> Language Class Initialized
ERROR - 2023-08-31 11:00:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:00:16 --> Input Class Initialized
INFO - 2023-08-31 11:00:16 --> Language Class Initialized
ERROR - 2023-08-31 11:00:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:00:17 --> Config Class Initialized
INFO - 2023-08-31 11:00:17 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:00:17 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:00:17 --> Utf8 Class Initialized
INFO - 2023-08-31 11:00:17 --> URI Class Initialized
INFO - 2023-08-31 11:00:17 --> Router Class Initialized
INFO - 2023-08-31 11:00:17 --> Output Class Initialized
INFO - 2023-08-31 11:00:17 --> Security Class Initialized
DEBUG - 2023-08-31 11:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:00:17 --> Input Class Initialized
INFO - 2023-08-31 11:00:17 --> Language Class Initialized
ERROR - 2023-08-31 11:00:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:05 --> Config Class Initialized
INFO - 2023-08-31 11:08:05 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:05 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:05 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:05 --> URI Class Initialized
DEBUG - 2023-08-31 11:08:05 --> No URI present. Default controller set.
INFO - 2023-08-31 11:08:05 --> Router Class Initialized
INFO - 2023-08-31 11:08:05 --> Output Class Initialized
INFO - 2023-08-31 11:08:05 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:05 --> Input Class Initialized
INFO - 2023-08-31 11:08:05 --> Language Class Initialized
INFO - 2023-08-31 11:08:05 --> Loader Class Initialized
INFO - 2023-08-31 11:08:05 --> Helper loaded: url_helper
INFO - 2023-08-31 11:08:05 --> Helper loaded: file_helper
INFO - 2023-08-31 11:08:05 --> Database Driver Class Initialized
INFO - 2023-08-31 11:08:05 --> Email Class Initialized
DEBUG - 2023-08-31 11:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:08:05 --> Controller Class Initialized
INFO - 2023-08-31 11:08:05 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:08:06 --> Model "Home_model" initialized
INFO - 2023-08-31 11:08:06 --> Helper loaded: download_helper
INFO - 2023-08-31 11:08:06 --> Helper loaded: form_helper
INFO - 2023-08-31 11:08:06 --> Form Validation Class Initialized
INFO - 2023-08-31 11:08:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 11:08:06 --> Final output sent to browser
DEBUG - 2023-08-31 11:08:06 --> Total execution time: 0.7704
INFO - 2023-08-31 11:08:07 --> Config Class Initialized
INFO - 2023-08-31 11:08:07 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:07 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:07 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:07 --> URI Class Initialized
INFO - 2023-08-31 11:08:07 --> Router Class Initialized
INFO - 2023-08-31 11:08:07 --> Output Class Initialized
INFO - 2023-08-31 11:08:07 --> Security Class Initialized
INFO - 2023-08-31 11:08:08 --> Config Class Initialized
INFO - 2023-08-31 11:08:08 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 11:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:10 --> Config Class Initialized
INFO - 2023-08-31 11:08:11 --> Config Class Initialized
INFO - 2023-08-31 11:08:11 --> Input Class Initialized
INFO - 2023-08-31 11:08:11 --> Language Class Initialized
INFO - 2023-08-31 11:08:11 --> Hooks Class Initialized
INFO - 2023-08-31 11:08:11 --> Config Class Initialized
DEBUG - 2023-08-31 11:08:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:11 --> Config Class Initialized
ERROR - 2023-08-31 11:08:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:08:12 --> Hooks Class Initialized
INFO - 2023-08-31 11:08:12 --> Hooks Class Initialized
INFO - 2023-08-31 11:08:12 --> Hooks Class Initialized
INFO - 2023-08-31 11:08:12 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:12 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:13 --> URI Class Initialized
DEBUG - 2023-08-31 11:08:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 11:08:13 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:13 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:13 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:13 --> URI Class Initialized
DEBUG - 2023-08-31 11:08:14 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:14 --> URI Class Initialized
INFO - 2023-08-31 11:08:14 --> URI Class Initialized
INFO - 2023-08-31 11:08:14 --> Config Class Initialized
INFO - 2023-08-31 11:08:14 --> Router Class Initialized
INFO - 2023-08-31 11:08:14 --> Output Class Initialized
INFO - 2023-08-31 11:08:14 --> Router Class Initialized
INFO - 2023-08-31 11:08:14 --> Router Class Initialized
INFO - 2023-08-31 11:08:14 --> Output Class Initialized
INFO - 2023-08-31 11:08:14 --> Hooks Class Initialized
INFO - 2023-08-31 11:08:14 --> Router Class Initialized
INFO - 2023-08-31 11:08:14 --> Output Class Initialized
INFO - 2023-08-31 11:08:14 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:14 --> Security Class Initialized
INFO - 2023-08-31 11:08:14 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:14 --> Output Class Initialized
DEBUG - 2023-08-31 11:08:14 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:14 --> URI Class Initialized
INFO - 2023-08-31 11:08:14 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:14 --> Security Class Initialized
INFO - 2023-08-31 11:08:14 --> Input Class Initialized
INFO - 2023-08-31 11:08:14 --> Router Class Initialized
DEBUG - 2023-08-31 11:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:14 --> Input Class Initialized
INFO - 2023-08-31 11:08:14 --> Language Class Initialized
ERROR - 2023-08-31 11:08:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:08:14 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:14 --> Output Class Initialized
INFO - 2023-08-31 11:08:14 --> Input Class Initialized
INFO - 2023-08-31 11:08:14 --> Security Class Initialized
INFO - 2023-08-31 11:08:14 --> Language Class Initialized
INFO - 2023-08-31 11:08:14 --> URI Class Initialized
INFO - 2023-08-31 11:08:14 --> Language Class Initialized
ERROR - 2023-08-31 11:08:14 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-31 11:08:14 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-31 11:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 11:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:14 --> Router Class Initialized
INFO - 2023-08-31 11:08:15 --> Config Class Initialized
INFO - 2023-08-31 11:08:15 --> Output Class Initialized
INFO - 2023-08-31 11:08:15 --> Input Class Initialized
INFO - 2023-08-31 11:08:15 --> Input Class Initialized
INFO - 2023-08-31 11:08:16 --> Config Class Initialized
INFO - 2023-08-31 11:08:16 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:16 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:16 --> Language Class Initialized
INFO - 2023-08-31 11:08:17 --> Language Class Initialized
INFO - 2023-08-31 11:08:17 --> Hooks Class Initialized
INFO - 2023-08-31 11:08:17 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:17 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:17 --> UTF-8 Support Enabled
ERROR - 2023-08-31 11:08:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:17 --> URI Class Initialized
ERROR - 2023-08-31 11:08:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:17 --> Utf8 Class Initialized
DEBUG - 2023-08-31 11:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:17 --> URI Class Initialized
INFO - 2023-08-31 11:08:17 --> Router Class Initialized
INFO - 2023-08-31 11:08:17 --> Output Class Initialized
INFO - 2023-08-31 11:08:17 --> Router Class Initialized
INFO - 2023-08-31 11:08:17 --> Security Class Initialized
INFO - 2023-08-31 11:08:17 --> Input Class Initialized
INFO - 2023-08-31 11:08:17 --> Output Class Initialized
INFO - 2023-08-31 11:08:17 --> Language Class Initialized
ERROR - 2023-08-31 11:08:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:17 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 11:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:17 --> Input Class Initialized
INFO - 2023-08-31 11:08:17 --> Language Class Initialized
INFO - 2023-08-31 11:08:17 --> Input Class Initialized
ERROR - 2023-08-31 11:08:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:17 --> Language Class Initialized
ERROR - 2023-08-31 11:08:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:23 --> Config Class Initialized
INFO - 2023-08-31 11:08:23 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:23 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:23 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:23 --> URI Class Initialized
DEBUG - 2023-08-31 11:08:23 --> No URI present. Default controller set.
INFO - 2023-08-31 11:08:23 --> Router Class Initialized
INFO - 2023-08-31 11:08:24 --> Output Class Initialized
INFO - 2023-08-31 11:08:24 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:24 --> Input Class Initialized
INFO - 2023-08-31 11:08:24 --> Language Class Initialized
INFO - 2023-08-31 11:08:24 --> Loader Class Initialized
INFO - 2023-08-31 11:08:24 --> Helper loaded: url_helper
INFO - 2023-08-31 11:08:24 --> Helper loaded: file_helper
INFO - 2023-08-31 11:08:24 --> Database Driver Class Initialized
INFO - 2023-08-31 11:08:24 --> Email Class Initialized
DEBUG - 2023-08-31 11:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:08:24 --> Controller Class Initialized
INFO - 2023-08-31 11:08:24 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:08:24 --> Model "Home_model" initialized
INFO - 2023-08-31 11:08:24 --> Helper loaded: download_helper
INFO - 2023-08-31 11:08:24 --> Helper loaded: form_helper
INFO - 2023-08-31 11:08:24 --> Form Validation Class Initialized
INFO - 2023-08-31 11:08:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 11:08:24 --> Final output sent to browser
DEBUG - 2023-08-31 11:08:24 --> Total execution time: 0.9670
INFO - 2023-08-31 11:08:25 --> Config Class Initialized
INFO - 2023-08-31 11:08:25 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:25 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:25 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:25 --> URI Class Initialized
INFO - 2023-08-31 11:08:25 --> Router Class Initialized
INFO - 2023-08-31 11:08:25 --> Output Class Initialized
INFO - 2023-08-31 11:08:25 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:25 --> Input Class Initialized
INFO - 2023-08-31 11:08:25 --> Language Class Initialized
ERROR - 2023-08-31 11:08:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:08:25 --> Config Class Initialized
INFO - 2023-08-31 11:08:25 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:25 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:25 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:25 --> URI Class Initialized
INFO - 2023-08-31 11:08:25 --> Router Class Initialized
INFO - 2023-08-31 11:08:25 --> Output Class Initialized
INFO - 2023-08-31 11:08:25 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:25 --> Input Class Initialized
INFO - 2023-08-31 11:08:25 --> Language Class Initialized
ERROR - 2023-08-31 11:08:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:08:26 --> Config Class Initialized
INFO - 2023-08-31 11:08:26 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:26 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:26 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:26 --> URI Class Initialized
INFO - 2023-08-31 11:08:26 --> Router Class Initialized
INFO - 2023-08-31 11:08:26 --> Output Class Initialized
INFO - 2023-08-31 11:08:26 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:26 --> Input Class Initialized
INFO - 2023-08-31 11:08:26 --> Language Class Initialized
ERROR - 2023-08-31 11:08:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:26 --> Config Class Initialized
INFO - 2023-08-31 11:08:26 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:26 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:26 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:26 --> URI Class Initialized
INFO - 2023-08-31 11:08:26 --> Router Class Initialized
INFO - 2023-08-31 11:08:26 --> Output Class Initialized
INFO - 2023-08-31 11:08:26 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:26 --> Input Class Initialized
INFO - 2023-08-31 11:08:26 --> Language Class Initialized
ERROR - 2023-08-31 11:08:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:27 --> Config Class Initialized
INFO - 2023-08-31 11:08:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:27 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:27 --> URI Class Initialized
INFO - 2023-08-31 11:08:27 --> Router Class Initialized
INFO - 2023-08-31 11:08:27 --> Output Class Initialized
INFO - 2023-08-31 11:08:27 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:27 --> Input Class Initialized
INFO - 2023-08-31 11:08:27 --> Language Class Initialized
ERROR - 2023-08-31 11:08:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:27 --> Config Class Initialized
INFO - 2023-08-31 11:08:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:27 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:27 --> URI Class Initialized
INFO - 2023-08-31 11:08:27 --> Router Class Initialized
INFO - 2023-08-31 11:08:27 --> Output Class Initialized
INFO - 2023-08-31 11:08:27 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:27 --> Input Class Initialized
INFO - 2023-08-31 11:08:27 --> Language Class Initialized
ERROR - 2023-08-31 11:08:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:27 --> Config Class Initialized
INFO - 2023-08-31 11:08:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:27 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:27 --> URI Class Initialized
INFO - 2023-08-31 11:08:27 --> Router Class Initialized
INFO - 2023-08-31 11:08:27 --> Output Class Initialized
INFO - 2023-08-31 11:08:27 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:27 --> Input Class Initialized
INFO - 2023-08-31 11:08:27 --> Language Class Initialized
ERROR - 2023-08-31 11:08:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:28 --> Config Class Initialized
INFO - 2023-08-31 11:08:28 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:28 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:28 --> URI Class Initialized
INFO - 2023-08-31 11:08:28 --> Router Class Initialized
INFO - 2023-08-31 11:08:28 --> Output Class Initialized
INFO - 2023-08-31 11:08:28 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:28 --> Input Class Initialized
INFO - 2023-08-31 11:08:28 --> Language Class Initialized
ERROR - 2023-08-31 11:08:28 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:28 --> Config Class Initialized
INFO - 2023-08-31 11:08:28 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:28 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:28 --> URI Class Initialized
INFO - 2023-08-31 11:08:28 --> Router Class Initialized
INFO - 2023-08-31 11:08:28 --> Output Class Initialized
INFO - 2023-08-31 11:08:28 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:28 --> Input Class Initialized
INFO - 2023-08-31 11:08:28 --> Language Class Initialized
ERROR - 2023-08-31 11:08:28 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:40 --> Config Class Initialized
INFO - 2023-08-31 11:08:41 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:41 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:41 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:41 --> URI Class Initialized
DEBUG - 2023-08-31 11:08:41 --> No URI present. Default controller set.
INFO - 2023-08-31 11:08:41 --> Router Class Initialized
INFO - 2023-08-31 11:08:41 --> Output Class Initialized
INFO - 2023-08-31 11:08:41 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:41 --> Input Class Initialized
INFO - 2023-08-31 11:08:41 --> Language Class Initialized
INFO - 2023-08-31 11:08:41 --> Loader Class Initialized
INFO - 2023-08-31 11:08:41 --> Helper loaded: url_helper
INFO - 2023-08-31 11:08:41 --> Helper loaded: file_helper
INFO - 2023-08-31 11:08:41 --> Database Driver Class Initialized
INFO - 2023-08-31 11:08:41 --> Email Class Initialized
DEBUG - 2023-08-31 11:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:08:42 --> Controller Class Initialized
INFO - 2023-08-31 11:08:42 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:08:42 --> Model "Home_model" initialized
INFO - 2023-08-31 11:08:42 --> Helper loaded: download_helper
INFO - 2023-08-31 11:08:42 --> Helper loaded: form_helper
INFO - 2023-08-31 11:08:42 --> Form Validation Class Initialized
INFO - 2023-08-31 11:08:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 11:08:42 --> Final output sent to browser
DEBUG - 2023-08-31 11:08:42 --> Total execution time: 1.4817
INFO - 2023-08-31 11:08:43 --> Config Class Initialized
INFO - 2023-08-31 11:08:43 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:43 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:43 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:43 --> URI Class Initialized
INFO - 2023-08-31 11:08:43 --> Router Class Initialized
INFO - 2023-08-31 11:08:43 --> Output Class Initialized
INFO - 2023-08-31 11:08:43 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:43 --> Input Class Initialized
INFO - 2023-08-31 11:08:43 --> Language Class Initialized
ERROR - 2023-08-31 11:08:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:08:43 --> Config Class Initialized
INFO - 2023-08-31 11:08:43 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:43 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:43 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:43 --> URI Class Initialized
INFO - 2023-08-31 11:08:43 --> Router Class Initialized
INFO - 2023-08-31 11:08:43 --> Output Class Initialized
INFO - 2023-08-31 11:08:43 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:43 --> Input Class Initialized
INFO - 2023-08-31 11:08:43 --> Language Class Initialized
ERROR - 2023-08-31 11:08:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:08:43 --> Config Class Initialized
INFO - 2023-08-31 11:08:43 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:43 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:43 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:43 --> URI Class Initialized
INFO - 2023-08-31 11:08:43 --> Router Class Initialized
INFO - 2023-08-31 11:08:43 --> Output Class Initialized
INFO - 2023-08-31 11:08:43 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:43 --> Input Class Initialized
INFO - 2023-08-31 11:08:43 --> Language Class Initialized
ERROR - 2023-08-31 11:08:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:43 --> Config Class Initialized
INFO - 2023-08-31 11:08:43 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:43 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:43 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:43 --> URI Class Initialized
INFO - 2023-08-31 11:08:43 --> Router Class Initialized
INFO - 2023-08-31 11:08:43 --> Output Class Initialized
INFO - 2023-08-31 11:08:43 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:43 --> Input Class Initialized
INFO - 2023-08-31 11:08:43 --> Language Class Initialized
ERROR - 2023-08-31 11:08:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:44 --> Config Class Initialized
INFO - 2023-08-31 11:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:44 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:44 --> URI Class Initialized
INFO - 2023-08-31 11:08:44 --> Router Class Initialized
INFO - 2023-08-31 11:08:44 --> Output Class Initialized
INFO - 2023-08-31 11:08:44 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:44 --> Input Class Initialized
INFO - 2023-08-31 11:08:44 --> Language Class Initialized
ERROR - 2023-08-31 11:08:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:44 --> Config Class Initialized
INFO - 2023-08-31 11:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:44 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:44 --> URI Class Initialized
INFO - 2023-08-31 11:08:44 --> Router Class Initialized
INFO - 2023-08-31 11:08:44 --> Output Class Initialized
INFO - 2023-08-31 11:08:44 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:44 --> Input Class Initialized
INFO - 2023-08-31 11:08:44 --> Language Class Initialized
ERROR - 2023-08-31 11:08:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:44 --> Config Class Initialized
INFO - 2023-08-31 11:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:44 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:44 --> URI Class Initialized
INFO - 2023-08-31 11:08:44 --> Router Class Initialized
INFO - 2023-08-31 11:08:44 --> Output Class Initialized
INFO - 2023-08-31 11:08:44 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:44 --> Input Class Initialized
INFO - 2023-08-31 11:08:44 --> Language Class Initialized
ERROR - 2023-08-31 11:08:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:45 --> Config Class Initialized
INFO - 2023-08-31 11:08:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:45 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:45 --> URI Class Initialized
INFO - 2023-08-31 11:08:45 --> Router Class Initialized
INFO - 2023-08-31 11:08:45 --> Output Class Initialized
INFO - 2023-08-31 11:08:45 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:45 --> Input Class Initialized
INFO - 2023-08-31 11:08:45 --> Language Class Initialized
ERROR - 2023-08-31 11:08:45 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:08:45 --> Config Class Initialized
INFO - 2023-08-31 11:08:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:08:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:08:45 --> Utf8 Class Initialized
INFO - 2023-08-31 11:08:45 --> URI Class Initialized
INFO - 2023-08-31 11:08:45 --> Router Class Initialized
INFO - 2023-08-31 11:08:45 --> Output Class Initialized
INFO - 2023-08-31 11:08:45 --> Security Class Initialized
DEBUG - 2023-08-31 11:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:08:45 --> Input Class Initialized
INFO - 2023-08-31 11:08:45 --> Language Class Initialized
ERROR - 2023-08-31 11:08:45 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:09:05 --> Config Class Initialized
INFO - 2023-08-31 11:09:05 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:09:05 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:05 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:05 --> URI Class Initialized
DEBUG - 2023-08-31 11:09:05 --> No URI present. Default controller set.
INFO - 2023-08-31 11:09:05 --> Router Class Initialized
INFO - 2023-08-31 11:09:05 --> Output Class Initialized
INFO - 2023-08-31 11:09:05 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:06 --> Input Class Initialized
INFO - 2023-08-31 11:09:06 --> Language Class Initialized
INFO - 2023-08-31 11:09:06 --> Loader Class Initialized
INFO - 2023-08-31 11:09:06 --> Helper loaded: url_helper
INFO - 2023-08-31 11:09:06 --> Helper loaded: file_helper
INFO - 2023-08-31 11:09:06 --> Database Driver Class Initialized
INFO - 2023-08-31 11:09:06 --> Email Class Initialized
DEBUG - 2023-08-31 11:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:09:06 --> Controller Class Initialized
INFO - 2023-08-31 11:09:06 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:09:06 --> Model "Home_model" initialized
INFO - 2023-08-31 11:09:06 --> Helper loaded: download_helper
INFO - 2023-08-31 11:09:06 --> Helper loaded: form_helper
INFO - 2023-08-31 11:09:06 --> Form Validation Class Initialized
INFO - 2023-08-31 11:09:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 11:09:06 --> Final output sent to browser
DEBUG - 2023-08-31 11:09:06 --> Total execution time: 1.0972
INFO - 2023-08-31 11:09:07 --> Config Class Initialized
INFO - 2023-08-31 11:09:07 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:09:07 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:07 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:07 --> URI Class Initialized
INFO - 2023-08-31 11:09:07 --> Router Class Initialized
INFO - 2023-08-31 11:09:07 --> Output Class Initialized
INFO - 2023-08-31 11:09:07 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:07 --> Input Class Initialized
INFO - 2023-08-31 11:09:07 --> Language Class Initialized
ERROR - 2023-08-31 11:09:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:09:08 --> Config Class Initialized
INFO - 2023-08-31 11:09:09 --> Config Class Initialized
INFO - 2023-08-31 11:09:09 --> Config Class Initialized
INFO - 2023-08-31 11:09:09 --> Hooks Class Initialized
INFO - 2023-08-31 11:09:10 --> Hooks Class Initialized
INFO - 2023-08-31 11:09:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:09:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 11:09:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:10 --> Utf8 Class Initialized
DEBUG - 2023-08-31 11:09:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:11 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:11 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:11 --> URI Class Initialized
INFO - 2023-08-31 11:09:11 --> Router Class Initialized
INFO - 2023-08-31 11:09:11 --> URI Class Initialized
INFO - 2023-08-31 11:09:11 --> Output Class Initialized
INFO - 2023-08-31 11:09:11 --> URI Class Initialized
INFO - 2023-08-31 11:09:11 --> Router Class Initialized
INFO - 2023-08-31 11:09:11 --> Security Class Initialized
INFO - 2023-08-31 11:09:11 --> Output Class Initialized
INFO - 2023-08-31 11:09:11 --> Router Class Initialized
DEBUG - 2023-08-31 11:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:11 --> Input Class Initialized
INFO - 2023-08-31 11:09:11 --> Language Class Initialized
ERROR - 2023-08-31 11:09:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:09:11 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:11 --> Input Class Initialized
INFO - 2023-08-31 11:09:11 --> Language Class Initialized
ERROR - 2023-08-31 11:09:11 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:09:11 --> Config Class Initialized
INFO - 2023-08-31 11:09:11 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:09:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:11 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:11 --> URI Class Initialized
INFO - 2023-08-31 11:09:11 --> Router Class Initialized
INFO - 2023-08-31 11:09:11 --> Output Class Initialized
INFO - 2023-08-31 11:09:11 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:11 --> Input Class Initialized
INFO - 2023-08-31 11:09:11 --> Language Class Initialized
ERROR - 2023-08-31 11:09:11 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:09:11 --> Config Class Initialized
INFO - 2023-08-31 11:09:11 --> Config Class Initialized
INFO - 2023-08-31 11:09:11 --> Output Class Initialized
INFO - 2023-08-31 11:09:11 --> Config Class Initialized
INFO - 2023-08-31 11:09:11 --> Config Class Initialized
INFO - 2023-08-31 11:09:12 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:09:12 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:12 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:12 --> URI Class Initialized
INFO - 2023-08-31 11:09:12 --> Router Class Initialized
INFO - 2023-08-31 11:09:12 --> Output Class Initialized
INFO - 2023-08-31 11:09:12 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:12 --> Input Class Initialized
INFO - 2023-08-31 11:09:12 --> Language Class Initialized
ERROR - 2023-08-31 11:09:12 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:09:12 --> Security Class Initialized
INFO - 2023-08-31 11:09:12 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:12 --> Hooks Class Initialized
INFO - 2023-08-31 11:09:12 --> Hooks Class Initialized
INFO - 2023-08-31 11:09:12 --> Input Class Initialized
INFO - 2023-08-31 11:09:12 --> Language Class Initialized
ERROR - 2023-08-31 11:09:12 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-31 11:09:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 11:09:12 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 11:09:12 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:12 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:12 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:12 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:12 --> URI Class Initialized
INFO - 2023-08-31 11:09:12 --> URI Class Initialized
INFO - 2023-08-31 11:09:12 --> URI Class Initialized
INFO - 2023-08-31 11:09:12 --> Router Class Initialized
INFO - 2023-08-31 11:09:12 --> Output Class Initialized
INFO - 2023-08-31 11:09:12 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:12 --> Input Class Initialized
INFO - 2023-08-31 11:09:12 --> Language Class Initialized
ERROR - 2023-08-31 11:09:12 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:09:12 --> Router Class Initialized
INFO - 2023-08-31 11:09:12 --> Output Class Initialized
INFO - 2023-08-31 11:09:12 --> Router Class Initialized
INFO - 2023-08-31 11:09:12 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:12 --> Output Class Initialized
INFO - 2023-08-31 11:09:12 --> Input Class Initialized
INFO - 2023-08-31 11:09:12 --> Security Class Initialized
INFO - 2023-08-31 11:09:13 --> Language Class Initialized
DEBUG - 2023-08-31 11:09:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-31 11:09:13 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:09:13 --> Input Class Initialized
INFO - 2023-08-31 11:09:13 --> Language Class Initialized
ERROR - 2023-08-31 11:09:13 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:09:50 --> Config Class Initialized
INFO - 2023-08-31 11:09:50 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:09:50 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:50 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:50 --> URI Class Initialized
DEBUG - 2023-08-31 11:09:50 --> No URI present. Default controller set.
INFO - 2023-08-31 11:09:50 --> Router Class Initialized
INFO - 2023-08-31 11:09:50 --> Output Class Initialized
INFO - 2023-08-31 11:09:50 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:50 --> Input Class Initialized
INFO - 2023-08-31 11:09:50 --> Language Class Initialized
INFO - 2023-08-31 11:09:50 --> Loader Class Initialized
INFO - 2023-08-31 11:09:50 --> Helper loaded: url_helper
INFO - 2023-08-31 11:09:50 --> Helper loaded: file_helper
INFO - 2023-08-31 11:09:50 --> Database Driver Class Initialized
INFO - 2023-08-31 11:09:50 --> Email Class Initialized
DEBUG - 2023-08-31 11:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:09:50 --> Controller Class Initialized
INFO - 2023-08-31 11:09:50 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:09:50 --> Model "Home_model" initialized
INFO - 2023-08-31 11:09:51 --> Helper loaded: download_helper
INFO - 2023-08-31 11:09:51 --> Helper loaded: form_helper
INFO - 2023-08-31 11:09:51 --> Form Validation Class Initialized
INFO - 2023-08-31 11:09:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 11:09:51 --> Final output sent to browser
DEBUG - 2023-08-31 11:09:51 --> Total execution time: 1.0978
INFO - 2023-08-31 11:09:51 --> Config Class Initialized
INFO - 2023-08-31 11:09:51 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:09:51 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:51 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:51 --> URI Class Initialized
INFO - 2023-08-31 11:09:51 --> Router Class Initialized
INFO - 2023-08-31 11:09:51 --> Output Class Initialized
INFO - 2023-08-31 11:09:51 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:51 --> Input Class Initialized
INFO - 2023-08-31 11:09:51 --> Language Class Initialized
ERROR - 2023-08-31 11:09:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:09:52 --> Config Class Initialized
INFO - 2023-08-31 11:09:52 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:09:52 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:52 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:52 --> URI Class Initialized
INFO - 2023-08-31 11:09:52 --> Router Class Initialized
INFO - 2023-08-31 11:09:52 --> Output Class Initialized
INFO - 2023-08-31 11:09:52 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:52 --> Input Class Initialized
INFO - 2023-08-31 11:09:52 --> Language Class Initialized
ERROR - 2023-08-31 11:09:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:09:53 --> Config Class Initialized
INFO - 2023-08-31 11:09:53 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:09:53 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:53 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:53 --> URI Class Initialized
INFO - 2023-08-31 11:09:53 --> Router Class Initialized
INFO - 2023-08-31 11:09:53 --> Output Class Initialized
INFO - 2023-08-31 11:09:53 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:53 --> Input Class Initialized
INFO - 2023-08-31 11:09:53 --> Language Class Initialized
ERROR - 2023-08-31 11:09:53 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:09:53 --> Config Class Initialized
INFO - 2023-08-31 11:09:53 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:09:53 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:53 --> Config Class Initialized
INFO - 2023-08-31 11:09:53 --> Config Class Initialized
INFO - 2023-08-31 11:09:54 --> Config Class Initialized
INFO - 2023-08-31 11:09:54 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:09:54 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:54 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:54 --> URI Class Initialized
INFO - 2023-08-31 11:09:54 --> Router Class Initialized
INFO - 2023-08-31 11:09:54 --> Output Class Initialized
INFO - 2023-08-31 11:09:54 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:54 --> Input Class Initialized
INFO - 2023-08-31 11:09:54 --> Language Class Initialized
ERROR - 2023-08-31 11:09:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:09:54 --> Config Class Initialized
INFO - 2023-08-31 11:09:54 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:09:54 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:54 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:54 --> URI Class Initialized
INFO - 2023-08-31 11:09:54 --> Router Class Initialized
INFO - 2023-08-31 11:09:54 --> Output Class Initialized
INFO - 2023-08-31 11:09:54 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:54 --> Input Class Initialized
INFO - 2023-08-31 11:09:54 --> Language Class Initialized
ERROR - 2023-08-31 11:09:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:09:54 --> Hooks Class Initialized
INFO - 2023-08-31 11:09:54 --> Hooks Class Initialized
INFO - 2023-08-31 11:09:54 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:54 --> Config Class Initialized
INFO - 2023-08-31 11:09:54 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:09:54 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:54 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:54 --> URI Class Initialized
INFO - 2023-08-31 11:09:54 --> Router Class Initialized
INFO - 2023-08-31 11:09:54 --> Output Class Initialized
INFO - 2023-08-31 11:09:54 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 11:09:55 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:09:55 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:55 --> URI Class Initialized
INFO - 2023-08-31 11:09:55 --> URI Class Initialized
DEBUG - 2023-08-31 11:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:55 --> Utf8 Class Initialized
INFO - 2023-08-31 11:09:55 --> URI Class Initialized
INFO - 2023-08-31 11:09:56 --> Router Class Initialized
INFO - 2023-08-31 11:09:56 --> Router Class Initialized
INFO - 2023-08-31 11:09:56 --> Input Class Initialized
INFO - 2023-08-31 11:09:56 --> Router Class Initialized
INFO - 2023-08-31 11:09:56 --> Output Class Initialized
INFO - 2023-08-31 11:09:56 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:56 --> Input Class Initialized
INFO - 2023-08-31 11:09:56 --> Language Class Initialized
ERROR - 2023-08-31 11:09:56 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:09:56 --> Output Class Initialized
INFO - 2023-08-31 11:09:56 --> Output Class Initialized
INFO - 2023-08-31 11:09:56 --> Security Class Initialized
INFO - 2023-08-31 11:09:56 --> Language Class Initialized
INFO - 2023-08-31 11:09:56 --> Security Class Initialized
DEBUG - 2023-08-31 11:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:56 --> Input Class Initialized
INFO - 2023-08-31 11:09:56 --> Language Class Initialized
ERROR - 2023-08-31 11:09:56 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 11:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:09:56 --> Input Class Initialized
ERROR - 2023-08-31 11:09:56 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:09:57 --> Language Class Initialized
ERROR - 2023-08-31 11:09:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:10:26 --> Config Class Initialized
INFO - 2023-08-31 11:10:26 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:10:26 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:10:26 --> Utf8 Class Initialized
INFO - 2023-08-31 11:10:26 --> URI Class Initialized
DEBUG - 2023-08-31 11:10:27 --> No URI present. Default controller set.
INFO - 2023-08-31 11:10:27 --> Router Class Initialized
INFO - 2023-08-31 11:10:27 --> Output Class Initialized
INFO - 2023-08-31 11:10:27 --> Security Class Initialized
DEBUG - 2023-08-31 11:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:10:27 --> Input Class Initialized
INFO - 2023-08-31 11:10:27 --> Language Class Initialized
INFO - 2023-08-31 11:10:27 --> Loader Class Initialized
INFO - 2023-08-31 11:10:27 --> Helper loaded: url_helper
INFO - 2023-08-31 11:10:27 --> Helper loaded: file_helper
INFO - 2023-08-31 11:10:27 --> Database Driver Class Initialized
INFO - 2023-08-31 11:10:27 --> Email Class Initialized
DEBUG - 2023-08-31 11:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:10:27 --> Controller Class Initialized
INFO - 2023-08-31 11:10:27 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:10:27 --> Model "Home_model" initialized
INFO - 2023-08-31 11:10:27 --> Helper loaded: download_helper
INFO - 2023-08-31 11:10:27 --> Helper loaded: form_helper
INFO - 2023-08-31 11:10:27 --> Form Validation Class Initialized
INFO - 2023-08-31 11:10:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 11:10:27 --> Final output sent to browser
DEBUG - 2023-08-31 11:10:27 --> Total execution time: 0.6999
INFO - 2023-08-31 11:10:28 --> Config Class Initialized
INFO - 2023-08-31 11:10:28 --> Config Class Initialized
INFO - 2023-08-31 11:10:28 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:10:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:10:28 --> Hooks Class Initialized
INFO - 2023-08-31 11:10:28 --> Utf8 Class Initialized
DEBUG - 2023-08-31 11:10:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:10:28 --> URI Class Initialized
INFO - 2023-08-31 11:10:28 --> Utf8 Class Initialized
INFO - 2023-08-31 11:10:28 --> Router Class Initialized
INFO - 2023-08-31 11:10:28 --> URI Class Initialized
INFO - 2023-08-31 11:10:28 --> Output Class Initialized
INFO - 2023-08-31 11:10:28 --> Router Class Initialized
INFO - 2023-08-31 11:10:28 --> Security Class Initialized
INFO - 2023-08-31 11:10:28 --> Output Class Initialized
DEBUG - 2023-08-31 11:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:10:28 --> Security Class Initialized
INFO - 2023-08-31 11:10:29 --> Input Class Initialized
DEBUG - 2023-08-31 11:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:10:29 --> Language Class Initialized
INFO - 2023-08-31 11:10:29 --> Input Class Initialized
ERROR - 2023-08-31 11:10:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:10:29 --> Language Class Initialized
ERROR - 2023-08-31 11:10:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:10:44 --> Config Class Initialized
INFO - 2023-08-31 11:10:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:10:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:10:44 --> Utf8 Class Initialized
INFO - 2023-08-31 11:10:44 --> URI Class Initialized
INFO - 2023-08-31 11:10:44 --> Router Class Initialized
INFO - 2023-08-31 11:10:44 --> Output Class Initialized
INFO - 2023-08-31 11:10:44 --> Security Class Initialized
DEBUG - 2023-08-31 11:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:10:44 --> Input Class Initialized
INFO - 2023-08-31 11:10:44 --> Language Class Initialized
INFO - 2023-08-31 11:10:44 --> Loader Class Initialized
INFO - 2023-08-31 11:10:44 --> Helper loaded: url_helper
INFO - 2023-08-31 11:10:44 --> Helper loaded: file_helper
INFO - 2023-08-31 11:10:44 --> Database Driver Class Initialized
INFO - 2023-08-31 11:10:44 --> Email Class Initialized
DEBUG - 2023-08-31 11:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:10:44 --> Controller Class Initialized
INFO - 2023-08-31 11:10:44 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:10:44 --> Model "Home_model" initialized
INFO - 2023-08-31 11:10:44 --> Helper loaded: download_helper
INFO - 2023-08-31 11:10:44 --> Helper loaded: form_helper
INFO - 2023-08-31 11:10:44 --> Form Validation Class Initialized
INFO - 2023-08-31 11:10:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-31 11:10:45 --> Final output sent to browser
DEBUG - 2023-08-31 11:10:45 --> Total execution time: 0.5506
INFO - 2023-08-31 11:10:45 --> Config Class Initialized
INFO - 2023-08-31 11:10:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:10:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:10:45 --> Utf8 Class Initialized
INFO - 2023-08-31 11:10:45 --> URI Class Initialized
INFO - 2023-08-31 11:10:45 --> Router Class Initialized
INFO - 2023-08-31 11:10:45 --> Output Class Initialized
INFO - 2023-08-31 11:10:45 --> Security Class Initialized
DEBUG - 2023-08-31 11:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:10:45 --> Input Class Initialized
INFO - 2023-08-31 11:10:45 --> Language Class Initialized
ERROR - 2023-08-31 11:10:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:10:45 --> Config Class Initialized
INFO - 2023-08-31 11:10:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:10:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:10:45 --> Utf8 Class Initialized
INFO - 2023-08-31 11:10:45 --> URI Class Initialized
INFO - 2023-08-31 11:10:45 --> Router Class Initialized
INFO - 2023-08-31 11:10:45 --> Output Class Initialized
INFO - 2023-08-31 11:10:45 --> Security Class Initialized
DEBUG - 2023-08-31 11:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:10:45 --> Input Class Initialized
INFO - 2023-08-31 11:10:45 --> Language Class Initialized
ERROR - 2023-08-31 11:10:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:11:12 --> Config Class Initialized
INFO - 2023-08-31 11:11:12 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:11:12 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:11:12 --> Utf8 Class Initialized
INFO - 2023-08-31 11:11:12 --> URI Class Initialized
INFO - 2023-08-31 11:11:12 --> Router Class Initialized
INFO - 2023-08-31 11:11:12 --> Output Class Initialized
INFO - 2023-08-31 11:11:12 --> Security Class Initialized
DEBUG - 2023-08-31 11:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:11:12 --> Input Class Initialized
INFO - 2023-08-31 11:11:12 --> Language Class Initialized
INFO - 2023-08-31 11:11:12 --> Loader Class Initialized
INFO - 2023-08-31 11:11:13 --> Helper loaded: url_helper
INFO - 2023-08-31 11:11:13 --> Helper loaded: file_helper
INFO - 2023-08-31 11:11:13 --> Database Driver Class Initialized
INFO - 2023-08-31 11:11:13 --> Email Class Initialized
DEBUG - 2023-08-31 11:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:11:13 --> Controller Class Initialized
INFO - 2023-08-31 11:11:13 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:11:13 --> Model "Home_model" initialized
INFO - 2023-08-31 11:11:13 --> Helper loaded: download_helper
INFO - 2023-08-31 11:11:13 --> Helper loaded: form_helper
INFO - 2023-08-31 11:11:13 --> Form Validation Class Initialized
INFO - 2023-08-31 11:11:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-31 11:11:13 --> Final output sent to browser
DEBUG - 2023-08-31 11:11:13 --> Total execution time: 0.9114
INFO - 2023-08-31 11:11:14 --> Config Class Initialized
INFO - 2023-08-31 11:11:14 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:11:14 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:11:14 --> Utf8 Class Initialized
INFO - 2023-08-31 11:11:15 --> URI Class Initialized
INFO - 2023-08-31 11:11:15 --> Router Class Initialized
INFO - 2023-08-31 11:11:15 --> Output Class Initialized
INFO - 2023-08-31 11:11:15 --> Security Class Initialized
DEBUG - 2023-08-31 11:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:11:15 --> Input Class Initialized
INFO - 2023-08-31 11:11:15 --> Language Class Initialized
ERROR - 2023-08-31 11:11:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:11:15 --> Config Class Initialized
INFO - 2023-08-31 11:11:15 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:11:15 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:11:15 --> Utf8 Class Initialized
INFO - 2023-08-31 11:11:15 --> URI Class Initialized
INFO - 2023-08-31 11:11:15 --> Router Class Initialized
INFO - 2023-08-31 11:11:15 --> Output Class Initialized
INFO - 2023-08-31 11:11:15 --> Security Class Initialized
DEBUG - 2023-08-31 11:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:11:15 --> Input Class Initialized
INFO - 2023-08-31 11:11:15 --> Language Class Initialized
ERROR - 2023-08-31 11:11:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:11:20 --> Config Class Initialized
INFO - 2023-08-31 11:11:20 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:11:20 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:11:20 --> Utf8 Class Initialized
INFO - 2023-08-31 11:11:21 --> URI Class Initialized
INFO - 2023-08-31 11:11:21 --> Router Class Initialized
INFO - 2023-08-31 11:11:21 --> Output Class Initialized
INFO - 2023-08-31 11:11:21 --> Security Class Initialized
DEBUG - 2023-08-31 11:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:11:21 --> Input Class Initialized
INFO - 2023-08-31 11:11:21 --> Language Class Initialized
INFO - 2023-08-31 11:11:21 --> Loader Class Initialized
INFO - 2023-08-31 11:11:21 --> Helper loaded: url_helper
INFO - 2023-08-31 11:11:21 --> Helper loaded: file_helper
INFO - 2023-08-31 11:11:21 --> Database Driver Class Initialized
INFO - 2023-08-31 11:11:21 --> Email Class Initialized
DEBUG - 2023-08-31 11:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:11:21 --> Controller Class Initialized
INFO - 2023-08-31 11:11:21 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:11:21 --> Model "Home_model" initialized
INFO - 2023-08-31 11:11:21 --> Helper loaded: download_helper
INFO - 2023-08-31 11:11:21 --> Helper loaded: form_helper
INFO - 2023-08-31 11:11:21 --> Form Validation Class Initialized
INFO - 2023-08-31 11:11:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-31 11:11:22 --> Final output sent to browser
DEBUG - 2023-08-31 11:11:22 --> Total execution time: 1.2629
INFO - 2023-08-31 11:11:22 --> Config Class Initialized
INFO - 2023-08-31 11:11:22 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:11:22 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:11:23 --> Config Class Initialized
INFO - 2023-08-31 11:11:23 --> Utf8 Class Initialized
INFO - 2023-08-31 11:11:23 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:11:23 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:11:23 --> URI Class Initialized
INFO - 2023-08-31 11:11:23 --> Utf8 Class Initialized
INFO - 2023-08-31 11:11:23 --> Router Class Initialized
INFO - 2023-08-31 11:11:23 --> URI Class Initialized
INFO - 2023-08-31 11:11:23 --> Output Class Initialized
INFO - 2023-08-31 11:11:23 --> Security Class Initialized
INFO - 2023-08-31 11:11:23 --> Router Class Initialized
DEBUG - 2023-08-31 11:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:11:23 --> Output Class Initialized
INFO - 2023-08-31 11:11:23 --> Input Class Initialized
INFO - 2023-08-31 11:11:23 --> Language Class Initialized
INFO - 2023-08-31 11:11:23 --> Security Class Initialized
ERROR - 2023-08-31 11:11:23 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-31 11:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:11:23 --> Input Class Initialized
INFO - 2023-08-31 11:11:23 --> Language Class Initialized
ERROR - 2023-08-31 11:11:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:11:54 --> Config Class Initialized
INFO - 2023-08-31 11:11:54 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:11:54 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:11:54 --> Utf8 Class Initialized
INFO - 2023-08-31 11:11:54 --> URI Class Initialized
INFO - 2023-08-31 11:11:54 --> Router Class Initialized
INFO - 2023-08-31 11:11:55 --> Output Class Initialized
INFO - 2023-08-31 11:11:55 --> Security Class Initialized
DEBUG - 2023-08-31 11:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:11:55 --> Input Class Initialized
INFO - 2023-08-31 11:11:55 --> Language Class Initialized
INFO - 2023-08-31 11:11:55 --> Loader Class Initialized
INFO - 2023-08-31 11:11:55 --> Helper loaded: url_helper
INFO - 2023-08-31 11:11:55 --> Helper loaded: file_helper
INFO - 2023-08-31 11:11:55 --> Database Driver Class Initialized
INFO - 2023-08-31 11:11:55 --> Email Class Initialized
DEBUG - 2023-08-31 11:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:11:55 --> Controller Class Initialized
INFO - 2023-08-31 11:11:55 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:11:55 --> Model "Home_model" initialized
INFO - 2023-08-31 11:11:56 --> Helper loaded: download_helper
INFO - 2023-08-31 11:11:56 --> Helper loaded: form_helper
INFO - 2023-08-31 11:11:56 --> Form Validation Class Initialized
INFO - 2023-08-31 11:11:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-31 11:11:56 --> Final output sent to browser
DEBUG - 2023-08-31 11:11:56 --> Total execution time: 1.6915
INFO - 2023-08-31 11:11:57 --> Config Class Initialized
INFO - 2023-08-31 11:11:57 --> Hooks Class Initialized
INFO - 2023-08-31 11:11:57 --> Config Class Initialized
INFO - 2023-08-31 11:11:57 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:11:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 11:11:57 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:11:57 --> Utf8 Class Initialized
INFO - 2023-08-31 11:11:57 --> Utf8 Class Initialized
INFO - 2023-08-31 11:11:57 --> URI Class Initialized
INFO - 2023-08-31 11:11:57 --> URI Class Initialized
INFO - 2023-08-31 11:11:57 --> Router Class Initialized
INFO - 2023-08-31 11:11:57 --> Output Class Initialized
INFO - 2023-08-31 11:11:57 --> Security Class Initialized
DEBUG - 2023-08-31 11:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:11:57 --> Input Class Initialized
INFO - 2023-08-31 11:11:57 --> Language Class Initialized
ERROR - 2023-08-31 11:11:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:11:57 --> Router Class Initialized
INFO - 2023-08-31 11:11:57 --> Output Class Initialized
INFO - 2023-08-31 11:11:57 --> Security Class Initialized
DEBUG - 2023-08-31 11:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:11:57 --> Input Class Initialized
INFO - 2023-08-31 11:11:57 --> Language Class Initialized
ERROR - 2023-08-31 11:11:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:12:07 --> Config Class Initialized
INFO - 2023-08-31 11:12:08 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:12:08 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:12:08 --> Utf8 Class Initialized
INFO - 2023-08-31 11:12:08 --> URI Class Initialized
INFO - 2023-08-31 11:12:08 --> Router Class Initialized
INFO - 2023-08-31 11:12:08 --> Output Class Initialized
INFO - 2023-08-31 11:12:08 --> Security Class Initialized
DEBUG - 2023-08-31 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:12:08 --> Input Class Initialized
INFO - 2023-08-31 11:12:08 --> Language Class Initialized
INFO - 2023-08-31 11:12:08 --> Loader Class Initialized
INFO - 2023-08-31 11:12:08 --> Helper loaded: url_helper
INFO - 2023-08-31 11:12:08 --> Helper loaded: file_helper
INFO - 2023-08-31 11:12:08 --> Database Driver Class Initialized
INFO - 2023-08-31 11:12:08 --> Email Class Initialized
DEBUG - 2023-08-31 11:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:12:08 --> Controller Class Initialized
INFO - 2023-08-31 11:12:08 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:12:08 --> Model "Home_model" initialized
INFO - 2023-08-31 11:12:08 --> Helper loaded: download_helper
INFO - 2023-08-31 11:12:08 --> Helper loaded: form_helper
INFO - 2023-08-31 11:12:08 --> Form Validation Class Initialized
INFO - 2023-08-31 11:12:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-08-31 11:12:08 --> Final output sent to browser
DEBUG - 2023-08-31 11:12:08 --> Total execution time: 0.5850
INFO - 2023-08-31 11:12:09 --> Config Class Initialized
INFO - 2023-08-31 11:12:09 --> Hooks Class Initialized
INFO - 2023-08-31 11:12:09 --> Config Class Initialized
DEBUG - 2023-08-31 11:12:09 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:12:09 --> Utf8 Class Initialized
INFO - 2023-08-31 11:12:09 --> Hooks Class Initialized
INFO - 2023-08-31 11:12:09 --> URI Class Initialized
DEBUG - 2023-08-31 11:12:09 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:12:09 --> Utf8 Class Initialized
INFO - 2023-08-31 11:12:09 --> Router Class Initialized
INFO - 2023-08-31 11:12:09 --> URI Class Initialized
INFO - 2023-08-31 11:12:09 --> Output Class Initialized
INFO - 2023-08-31 11:12:09 --> Router Class Initialized
INFO - 2023-08-31 11:12:09 --> Security Class Initialized
INFO - 2023-08-31 11:12:09 --> Output Class Initialized
DEBUG - 2023-08-31 11:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:12:09 --> Security Class Initialized
INFO - 2023-08-31 11:12:09 --> Input Class Initialized
DEBUG - 2023-08-31 11:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:12:09 --> Language Class Initialized
INFO - 2023-08-31 11:12:09 --> Input Class Initialized
ERROR - 2023-08-31 11:12:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:12:10 --> Language Class Initialized
ERROR - 2023-08-31 11:12:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:12:29 --> Config Class Initialized
INFO - 2023-08-31 11:12:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:12:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:12:29 --> Utf8 Class Initialized
INFO - 2023-08-31 11:12:29 --> URI Class Initialized
INFO - 2023-08-31 11:12:29 --> Router Class Initialized
INFO - 2023-08-31 11:12:29 --> Output Class Initialized
INFO - 2023-08-31 11:12:29 --> Security Class Initialized
DEBUG - 2023-08-31 11:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:12:29 --> Input Class Initialized
INFO - 2023-08-31 11:12:29 --> Language Class Initialized
INFO - 2023-08-31 11:12:29 --> Loader Class Initialized
INFO - 2023-08-31 11:12:29 --> Helper loaded: url_helper
INFO - 2023-08-31 11:12:29 --> Helper loaded: file_helper
INFO - 2023-08-31 11:12:29 --> Database Driver Class Initialized
INFO - 2023-08-31 11:12:29 --> Email Class Initialized
DEBUG - 2023-08-31 11:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:12:29 --> Controller Class Initialized
INFO - 2023-08-31 11:12:29 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:12:29 --> Model "Home_model" initialized
INFO - 2023-08-31 11:12:30 --> Helper loaded: download_helper
INFO - 2023-08-31 11:12:30 --> Helper loaded: form_helper
INFO - 2023-08-31 11:12:30 --> Form Validation Class Initialized
INFO - 2023-08-31 11:12:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-31 11:12:30 --> Final output sent to browser
DEBUG - 2023-08-31 11:12:30 --> Total execution time: 0.7630
INFO - 2023-08-31 11:12:31 --> Config Class Initialized
INFO - 2023-08-31 11:12:31 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:12:31 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:12:31 --> Utf8 Class Initialized
INFO - 2023-08-31 11:12:31 --> URI Class Initialized
INFO - 2023-08-31 11:12:31 --> Router Class Initialized
INFO - 2023-08-31 11:12:31 --> Output Class Initialized
INFO - 2023-08-31 11:12:31 --> Security Class Initialized
DEBUG - 2023-08-31 11:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:12:31 --> Input Class Initialized
INFO - 2023-08-31 11:12:31 --> Language Class Initialized
ERROR - 2023-08-31 11:12:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:12:31 --> Config Class Initialized
INFO - 2023-08-31 11:12:31 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:12:31 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:12:31 --> Utf8 Class Initialized
INFO - 2023-08-31 11:12:31 --> URI Class Initialized
INFO - 2023-08-31 11:12:31 --> Router Class Initialized
INFO - 2023-08-31 11:12:31 --> Output Class Initialized
INFO - 2023-08-31 11:12:31 --> Security Class Initialized
DEBUG - 2023-08-31 11:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:12:31 --> Input Class Initialized
INFO - 2023-08-31 11:12:31 --> Language Class Initialized
ERROR - 2023-08-31 11:12:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 11:12:39 --> Config Class Initialized
INFO - 2023-08-31 11:12:39 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:12:39 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:12:39 --> Utf8 Class Initialized
INFO - 2023-08-31 11:12:39 --> URI Class Initialized
INFO - 2023-08-31 11:12:39 --> Router Class Initialized
INFO - 2023-08-31 11:12:39 --> Output Class Initialized
INFO - 2023-08-31 11:12:39 --> Security Class Initialized
DEBUG - 2023-08-31 11:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:12:39 --> Input Class Initialized
INFO - 2023-08-31 11:12:39 --> Language Class Initialized
INFO - 2023-08-31 11:12:39 --> Loader Class Initialized
INFO - 2023-08-31 11:12:39 --> Helper loaded: url_helper
INFO - 2023-08-31 11:12:39 --> Helper loaded: file_helper
INFO - 2023-08-31 11:12:39 --> Database Driver Class Initialized
INFO - 2023-08-31 11:12:39 --> Email Class Initialized
DEBUG - 2023-08-31 11:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:12:39 --> Controller Class Initialized
INFO - 2023-08-31 11:12:39 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:12:39 --> Model "Home_model" initialized
INFO - 2023-08-31 11:12:39 --> Helper loaded: download_helper
INFO - 2023-08-31 11:12:39 --> Helper loaded: form_helper
INFO - 2023-08-31 11:12:39 --> Form Validation Class Initialized
ERROR - 2023-08-31 11:12:39 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 11:12:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 11:12:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 11:12:39 --> Final output sent to browser
DEBUG - 2023-08-31 11:12:40 --> Total execution time: 0.5762
INFO - 2023-08-31 11:12:40 --> Config Class Initialized
INFO - 2023-08-31 11:12:40 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:12:40 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:12:40 --> Config Class Initialized
INFO - 2023-08-31 11:12:40 --> Utf8 Class Initialized
INFO - 2023-08-31 11:12:40 --> Hooks Class Initialized
INFO - 2023-08-31 11:12:40 --> URI Class Initialized
DEBUG - 2023-08-31 11:12:40 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:12:41 --> Router Class Initialized
INFO - 2023-08-31 11:12:41 --> Utf8 Class Initialized
INFO - 2023-08-31 11:12:41 --> URI Class Initialized
INFO - 2023-08-31 11:12:41 --> Output Class Initialized
INFO - 2023-08-31 11:12:41 --> Security Class Initialized
DEBUG - 2023-08-31 11:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:12:41 --> Router Class Initialized
INFO - 2023-08-31 11:12:41 --> Output Class Initialized
INFO - 2023-08-31 11:12:41 --> Input Class Initialized
INFO - 2023-08-31 11:12:41 --> Security Class Initialized
DEBUG - 2023-08-31 11:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:12:41 --> Input Class Initialized
INFO - 2023-08-31 11:12:41 --> Language Class Initialized
ERROR - 2023-08-31 11:12:41 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:12:41 --> Language Class Initialized
ERROR - 2023-08-31 11:12:41 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:12:52 --> Config Class Initialized
INFO - 2023-08-31 11:12:53 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:12:53 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:12:53 --> Utf8 Class Initialized
INFO - 2023-08-31 11:12:53 --> URI Class Initialized
INFO - 2023-08-31 11:12:53 --> Router Class Initialized
INFO - 2023-08-31 11:12:53 --> Output Class Initialized
INFO - 2023-08-31 11:12:53 --> Security Class Initialized
DEBUG - 2023-08-31 11:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:12:53 --> Input Class Initialized
INFO - 2023-08-31 11:12:53 --> Language Class Initialized
INFO - 2023-08-31 11:12:53 --> Loader Class Initialized
INFO - 2023-08-31 11:12:53 --> Helper loaded: url_helper
INFO - 2023-08-31 11:12:53 --> Helper loaded: file_helper
INFO - 2023-08-31 11:12:53 --> Database Driver Class Initialized
INFO - 2023-08-31 11:12:53 --> Email Class Initialized
DEBUG - 2023-08-31 11:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:12:53 --> Controller Class Initialized
INFO - 2023-08-31 11:12:53 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:12:53 --> Model "Home_model" initialized
INFO - 2023-08-31 11:12:53 --> Helper loaded: download_helper
INFO - 2023-08-31 11:12:53 --> Helper loaded: form_helper
INFO - 2023-08-31 11:12:53 --> Form Validation Class Initialized
ERROR - 2023-08-31 11:12:53 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 11:12:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 11:12:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 11:12:53 --> Final output sent to browser
DEBUG - 2023-08-31 11:12:53 --> Total execution time: 0.5559
INFO - 2023-08-31 11:12:53 --> Config Class Initialized
INFO - 2023-08-31 11:12:53 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:12:53 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:12:53 --> Utf8 Class Initialized
INFO - 2023-08-31 11:12:53 --> URI Class Initialized
INFO - 2023-08-31 11:12:53 --> Router Class Initialized
INFO - 2023-08-31 11:12:53 --> Output Class Initialized
INFO - 2023-08-31 11:12:53 --> Security Class Initialized
DEBUG - 2023-08-31 11:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:12:53 --> Input Class Initialized
INFO - 2023-08-31 11:12:53 --> Language Class Initialized
ERROR - 2023-08-31 11:12:53 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:12:54 --> Config Class Initialized
INFO - 2023-08-31 11:12:54 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:12:54 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:12:54 --> Utf8 Class Initialized
INFO - 2023-08-31 11:12:54 --> URI Class Initialized
INFO - 2023-08-31 11:12:54 --> Router Class Initialized
INFO - 2023-08-31 11:12:54 --> Output Class Initialized
INFO - 2023-08-31 11:12:54 --> Security Class Initialized
DEBUG - 2023-08-31 11:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:12:54 --> Input Class Initialized
INFO - 2023-08-31 11:12:54 --> Language Class Initialized
ERROR - 2023-08-31 11:12:54 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:13:27 --> Config Class Initialized
INFO - 2023-08-31 11:13:28 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:13:28 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:13:28 --> Utf8 Class Initialized
INFO - 2023-08-31 11:13:28 --> URI Class Initialized
INFO - 2023-08-31 11:13:28 --> Router Class Initialized
INFO - 2023-08-31 11:13:28 --> Output Class Initialized
INFO - 2023-08-31 11:13:28 --> Security Class Initialized
DEBUG - 2023-08-31 11:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:13:28 --> Input Class Initialized
INFO - 2023-08-31 11:13:28 --> Language Class Initialized
INFO - 2023-08-31 11:13:28 --> Loader Class Initialized
INFO - 2023-08-31 11:13:28 --> Helper loaded: url_helper
INFO - 2023-08-31 11:13:28 --> Helper loaded: file_helper
INFO - 2023-08-31 11:13:28 --> Database Driver Class Initialized
INFO - 2023-08-31 11:13:28 --> Email Class Initialized
DEBUG - 2023-08-31 11:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:13:28 --> Controller Class Initialized
INFO - 2023-08-31 11:13:28 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:13:28 --> Model "Home_model" initialized
INFO - 2023-08-31 11:13:28 --> Helper loaded: download_helper
INFO - 2023-08-31 11:13:28 --> Helper loaded: form_helper
INFO - 2023-08-31 11:13:28 --> Form Validation Class Initialized
ERROR - 2023-08-31 11:13:28 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 11:13:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 11:13:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 11:13:29 --> Final output sent to browser
DEBUG - 2023-08-31 11:13:29 --> Total execution time: 0.8908
INFO - 2023-08-31 11:13:29 --> Config Class Initialized
INFO - 2023-08-31 11:13:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:13:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:13:29 --> Utf8 Class Initialized
INFO - 2023-08-31 11:13:29 --> URI Class Initialized
INFO - 2023-08-31 11:13:29 --> Router Class Initialized
INFO - 2023-08-31 11:13:29 --> Output Class Initialized
INFO - 2023-08-31 11:13:29 --> Security Class Initialized
DEBUG - 2023-08-31 11:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:13:29 --> Input Class Initialized
INFO - 2023-08-31 11:13:29 --> Language Class Initialized
ERROR - 2023-08-31 11:13:29 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:13:30 --> Config Class Initialized
INFO - 2023-08-31 11:13:30 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:13:30 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:13:30 --> Utf8 Class Initialized
INFO - 2023-08-31 11:13:30 --> URI Class Initialized
INFO - 2023-08-31 11:13:30 --> Router Class Initialized
INFO - 2023-08-31 11:13:30 --> Output Class Initialized
INFO - 2023-08-31 11:13:30 --> Security Class Initialized
DEBUG - 2023-08-31 11:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:13:30 --> Input Class Initialized
INFO - 2023-08-31 11:13:30 --> Language Class Initialized
ERROR - 2023-08-31 11:13:30 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:13:37 --> Config Class Initialized
INFO - 2023-08-31 11:13:37 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:13:37 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:13:37 --> Utf8 Class Initialized
INFO - 2023-08-31 11:13:37 --> URI Class Initialized
INFO - 2023-08-31 11:13:37 --> Router Class Initialized
INFO - 2023-08-31 11:13:37 --> Output Class Initialized
INFO - 2023-08-31 11:13:37 --> Security Class Initialized
DEBUG - 2023-08-31 11:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:13:37 --> Input Class Initialized
INFO - 2023-08-31 11:13:37 --> Language Class Initialized
INFO - 2023-08-31 11:13:37 --> Loader Class Initialized
INFO - 2023-08-31 11:13:37 --> Helper loaded: url_helper
INFO - 2023-08-31 11:13:37 --> Helper loaded: file_helper
INFO - 2023-08-31 11:13:37 --> Database Driver Class Initialized
INFO - 2023-08-31 11:13:37 --> Email Class Initialized
DEBUG - 2023-08-31 11:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:13:37 --> Controller Class Initialized
INFO - 2023-08-31 11:13:37 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:13:37 --> Model "Home_model" initialized
INFO - 2023-08-31 11:13:37 --> Helper loaded: download_helper
INFO - 2023-08-31 11:13:37 --> Helper loaded: form_helper
INFO - 2023-08-31 11:13:37 --> Form Validation Class Initialized
ERROR - 2023-08-31 11:13:37 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 11:13:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 11:13:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 11:13:37 --> Final output sent to browser
DEBUG - 2023-08-31 11:13:38 --> Total execution time: 0.3510
INFO - 2023-08-31 11:13:38 --> Config Class Initialized
INFO - 2023-08-31 11:13:38 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:13:38 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:13:38 --> Utf8 Class Initialized
INFO - 2023-08-31 11:13:38 --> URI Class Initialized
INFO - 2023-08-31 11:13:38 --> Router Class Initialized
INFO - 2023-08-31 11:13:38 --> Output Class Initialized
INFO - 2023-08-31 11:13:38 --> Security Class Initialized
DEBUG - 2023-08-31 11:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:13:38 --> Input Class Initialized
INFO - 2023-08-31 11:13:38 --> Language Class Initialized
ERROR - 2023-08-31 11:13:38 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:13:38 --> Config Class Initialized
INFO - 2023-08-31 11:13:38 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:13:38 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:13:38 --> Utf8 Class Initialized
INFO - 2023-08-31 11:13:38 --> URI Class Initialized
INFO - 2023-08-31 11:13:38 --> Router Class Initialized
INFO - 2023-08-31 11:13:38 --> Output Class Initialized
INFO - 2023-08-31 11:13:39 --> Security Class Initialized
DEBUG - 2023-08-31 11:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:13:39 --> Input Class Initialized
INFO - 2023-08-31 11:13:39 --> Language Class Initialized
ERROR - 2023-08-31 11:13:39 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:14:11 --> Config Class Initialized
INFO - 2023-08-31 11:14:11 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:14:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:14:11 --> Utf8 Class Initialized
INFO - 2023-08-31 11:14:11 --> URI Class Initialized
INFO - 2023-08-31 11:14:11 --> Router Class Initialized
INFO - 2023-08-31 11:14:11 --> Output Class Initialized
INFO - 2023-08-31 11:14:11 --> Security Class Initialized
DEBUG - 2023-08-31 11:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:14:11 --> Input Class Initialized
INFO - 2023-08-31 11:14:11 --> Language Class Initialized
INFO - 2023-08-31 11:14:11 --> Loader Class Initialized
INFO - 2023-08-31 11:14:11 --> Helper loaded: url_helper
INFO - 2023-08-31 11:14:11 --> Helper loaded: file_helper
INFO - 2023-08-31 11:14:11 --> Database Driver Class Initialized
INFO - 2023-08-31 11:14:11 --> Email Class Initialized
DEBUG - 2023-08-31 11:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:14:11 --> Controller Class Initialized
INFO - 2023-08-31 11:14:11 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:14:11 --> Model "Home_model" initialized
INFO - 2023-08-31 11:14:11 --> Helper loaded: download_helper
INFO - 2023-08-31 11:14:11 --> Helper loaded: form_helper
INFO - 2023-08-31 11:14:11 --> Form Validation Class Initialized
ERROR - 2023-08-31 11:14:11 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 11:14:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 11:14:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 11:14:11 --> Final output sent to browser
DEBUG - 2023-08-31 11:14:12 --> Total execution time: 0.6858
INFO - 2023-08-31 11:14:12 --> Config Class Initialized
INFO - 2023-08-31 11:14:12 --> Config Class Initialized
INFO - 2023-08-31 11:14:12 --> Hooks Class Initialized
INFO - 2023-08-31 11:14:13 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:14:13 --> UTF-8 Support Enabled
DEBUG - 2023-08-31 11:14:13 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:14:13 --> Utf8 Class Initialized
INFO - 2023-08-31 11:14:13 --> Utf8 Class Initialized
INFO - 2023-08-31 11:14:13 --> URI Class Initialized
INFO - 2023-08-31 11:14:13 --> URI Class Initialized
INFO - 2023-08-31 11:14:13 --> Router Class Initialized
INFO - 2023-08-31 11:14:13 --> Router Class Initialized
INFO - 2023-08-31 11:14:13 --> Output Class Initialized
INFO - 2023-08-31 11:14:13 --> Output Class Initialized
INFO - 2023-08-31 11:14:13 --> Security Class Initialized
INFO - 2023-08-31 11:14:13 --> Security Class Initialized
DEBUG - 2023-08-31 11:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 11:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:14:13 --> Input Class Initialized
INFO - 2023-08-31 11:14:13 --> Input Class Initialized
INFO - 2023-08-31 11:14:13 --> Language Class Initialized
INFO - 2023-08-31 11:14:13 --> Language Class Initialized
ERROR - 2023-08-31 11:14:13 --> 404 Page Not Found: Service-detail/assets
ERROR - 2023-08-31 11:14:13 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:14:15 --> Config Class Initialized
INFO - 2023-08-31 11:14:15 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:14:15 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:14:15 --> Utf8 Class Initialized
INFO - 2023-08-31 11:14:15 --> URI Class Initialized
INFO - 2023-08-31 11:14:15 --> Router Class Initialized
ERROR - 2023-08-31 11:14:16 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 11:14:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 11:14:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 11:14:16 --> Final output sent to browser
DEBUG - 2023-08-31 11:14:16 --> Total execution time: 0.3078
INFO - 2023-08-31 11:14:16 --> Config Class Initialized
INFO - 2023-08-31 11:14:16 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:14:16 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:14:16 --> Utf8 Class Initialized
INFO - 2023-08-31 11:14:16 --> URI Class Initialized
INFO - 2023-08-31 11:14:16 --> Router Class Initialized
INFO - 2023-08-31 11:14:16 --> Output Class Initialized
INFO - 2023-08-31 11:14:16 --> Security Class Initialized
DEBUG - 2023-08-31 11:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:14:16 --> Input Class Initialized
INFO - 2023-08-31 11:14:16 --> Language Class Initialized
ERROR - 2023-08-31 11:14:16 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:14:16 --> Config Class Initialized
INFO - 2023-08-31 11:14:16 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:14:16 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:14:16 --> Utf8 Class Initialized
INFO - 2023-08-31 11:14:16 --> URI Class Initialized
INFO - 2023-08-31 11:14:16 --> Router Class Initialized
INFO - 2023-08-31 11:14:16 --> Output Class Initialized
INFO - 2023-08-31 11:14:16 --> Security Class Initialized
DEBUG - 2023-08-31 11:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:14:17 --> Input Class Initialized
INFO - 2023-08-31 11:14:17 --> Language Class Initialized
ERROR - 2023-08-31 11:14:17 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:14:31 --> Config Class Initialized
INFO - 2023-08-31 11:14:31 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:14:31 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:14:31 --> Utf8 Class Initialized
INFO - 2023-08-31 11:14:31 --> URI Class Initialized
INFO - 2023-08-31 11:14:31 --> Router Class Initialized
INFO - 2023-08-31 11:14:31 --> Output Class Initialized
INFO - 2023-08-31 11:14:31 --> Security Class Initialized
DEBUG - 2023-08-31 11:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:14:31 --> Input Class Initialized
INFO - 2023-08-31 11:14:31 --> Language Class Initialized
INFO - 2023-08-31 11:14:31 --> Loader Class Initialized
INFO - 2023-08-31 11:14:31 --> Helper loaded: url_helper
INFO - 2023-08-31 11:14:31 --> Helper loaded: file_helper
INFO - 2023-08-31 11:14:31 --> Database Driver Class Initialized
INFO - 2023-08-31 11:14:31 --> Email Class Initialized
DEBUG - 2023-08-31 11:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:14:31 --> Controller Class Initialized
INFO - 2023-08-31 11:14:31 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:14:31 --> Model "Home_model" initialized
INFO - 2023-08-31 11:14:31 --> Helper loaded: download_helper
INFO - 2023-08-31 11:14:31 --> Helper loaded: form_helper
INFO - 2023-08-31 11:14:31 --> Form Validation Class Initialized
ERROR - 2023-08-31 11:14:31 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 11:14:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 11:14:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 11:14:31 --> Final output sent to browser
DEBUG - 2023-08-31 11:14:32 --> Total execution time: 0.5611
INFO - 2023-08-31 11:14:32 --> Config Class Initialized
INFO - 2023-08-31 11:14:32 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:14:32 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:14:32 --> Config Class Initialized
INFO - 2023-08-31 11:14:32 --> Hooks Class Initialized
INFO - 2023-08-31 11:14:32 --> Utf8 Class Initialized
DEBUG - 2023-08-31 11:14:33 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:14:33 --> URI Class Initialized
INFO - 2023-08-31 11:14:33 --> Router Class Initialized
INFO - 2023-08-31 11:14:33 --> Output Class Initialized
INFO - 2023-08-31 11:14:33 --> Security Class Initialized
DEBUG - 2023-08-31 11:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:14:33 --> Input Class Initialized
INFO - 2023-08-31 11:14:33 --> Language Class Initialized
ERROR - 2023-08-31 11:14:33 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:14:33 --> Utf8 Class Initialized
INFO - 2023-08-31 11:14:33 --> URI Class Initialized
INFO - 2023-08-31 11:14:33 --> Router Class Initialized
INFO - 2023-08-31 11:14:33 --> Output Class Initialized
INFO - 2023-08-31 11:14:33 --> Security Class Initialized
DEBUG - 2023-08-31 11:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:14:33 --> Input Class Initialized
INFO - 2023-08-31 11:14:33 --> Language Class Initialized
ERROR - 2023-08-31 11:14:33 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:15:04 --> Config Class Initialized
INFO - 2023-08-31 11:15:04 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:15:04 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:15:04 --> Utf8 Class Initialized
INFO - 2023-08-31 11:15:04 --> URI Class Initialized
INFO - 2023-08-31 11:15:04 --> Router Class Initialized
INFO - 2023-08-31 11:15:04 --> Output Class Initialized
INFO - 2023-08-31 11:15:04 --> Security Class Initialized
DEBUG - 2023-08-31 11:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:15:04 --> Input Class Initialized
INFO - 2023-08-31 11:15:04 --> Language Class Initialized
INFO - 2023-08-31 11:15:04 --> Loader Class Initialized
INFO - 2023-08-31 11:15:04 --> Helper loaded: url_helper
INFO - 2023-08-31 11:15:04 --> Helper loaded: file_helper
INFO - 2023-08-31 11:15:04 --> Database Driver Class Initialized
INFO - 2023-08-31 11:15:04 --> Email Class Initialized
DEBUG - 2023-08-31 11:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:15:05 --> Controller Class Initialized
INFO - 2023-08-31 11:15:05 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:15:05 --> Model "Home_model" initialized
INFO - 2023-08-31 11:15:05 --> Helper loaded: download_helper
INFO - 2023-08-31 11:15:05 --> Helper loaded: form_helper
INFO - 2023-08-31 11:15:05 --> Form Validation Class Initialized
ERROR - 2023-08-31 11:15:05 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 11:15:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 11:15:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 11:15:05 --> Final output sent to browser
DEBUG - 2023-08-31 11:15:05 --> Total execution time: 1.1510
INFO - 2023-08-31 11:15:06 --> Config Class Initialized
INFO - 2023-08-31 11:15:06 --> Hooks Class Initialized
INFO - 2023-08-31 11:15:06 --> Config Class Initialized
DEBUG - 2023-08-31 11:15:06 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:15:06 --> Utf8 Class Initialized
INFO - 2023-08-31 11:15:06 --> URI Class Initialized
INFO - 2023-08-31 11:15:06 --> Hooks Class Initialized
INFO - 2023-08-31 11:15:06 --> Router Class Initialized
INFO - 2023-08-31 11:15:06 --> Output Class Initialized
DEBUG - 2023-08-31 11:15:06 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:15:06 --> Security Class Initialized
DEBUG - 2023-08-31 11:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:15:06 --> Utf8 Class Initialized
INFO - 2023-08-31 11:15:06 --> Input Class Initialized
INFO - 2023-08-31 11:15:06 --> Language Class Initialized
INFO - 2023-08-31 11:15:06 --> URI Class Initialized
ERROR - 2023-08-31 11:15:06 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:15:06 --> Router Class Initialized
INFO - 2023-08-31 11:15:06 --> Output Class Initialized
INFO - 2023-08-31 11:15:06 --> Security Class Initialized
DEBUG - 2023-08-31 11:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:15:06 --> Input Class Initialized
INFO - 2023-08-31 11:15:06 --> Language Class Initialized
ERROR - 2023-08-31 11:15:06 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:17:13 --> Config Class Initialized
INFO - 2023-08-31 11:17:13 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:17:13 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:17:13 --> Utf8 Class Initialized
INFO - 2023-08-31 11:17:13 --> URI Class Initialized
INFO - 2023-08-31 11:17:13 --> Router Class Initialized
INFO - 2023-08-31 11:17:13 --> Output Class Initialized
INFO - 2023-08-31 11:17:13 --> Security Class Initialized
DEBUG - 2023-08-31 11:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:17:14 --> Input Class Initialized
INFO - 2023-08-31 11:17:14 --> Language Class Initialized
INFO - 2023-08-31 11:17:14 --> Loader Class Initialized
INFO - 2023-08-31 11:17:14 --> Helper loaded: url_helper
INFO - 2023-08-31 11:17:14 --> Helper loaded: file_helper
INFO - 2023-08-31 11:17:14 --> Database Driver Class Initialized
INFO - 2023-08-31 11:17:14 --> Email Class Initialized
DEBUG - 2023-08-31 11:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:17:14 --> Controller Class Initialized
INFO - 2023-08-31 11:17:14 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:17:14 --> Model "Home_model" initialized
INFO - 2023-08-31 11:17:14 --> Helper loaded: download_helper
INFO - 2023-08-31 11:17:14 --> Helper loaded: form_helper
INFO - 2023-08-31 11:17:14 --> Form Validation Class Initialized
ERROR - 2023-08-31 11:17:14 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 11:17:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 11:17:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 11:17:14 --> Final output sent to browser
DEBUG - 2023-08-31 11:17:15 --> Total execution time: 0.9762
INFO - 2023-08-31 11:17:18 --> Config Class Initialized
INFO - 2023-08-31 11:17:18 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:17:18 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:17:18 --> Config Class Initialized
INFO - 2023-08-31 11:17:18 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:17:18 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:17:18 --> Utf8 Class Initialized
INFO - 2023-08-31 11:17:18 --> Utf8 Class Initialized
INFO - 2023-08-31 11:17:18 --> URI Class Initialized
INFO - 2023-08-31 11:17:18 --> Router Class Initialized
INFO - 2023-08-31 11:17:18 --> Output Class Initialized
INFO - 2023-08-31 11:17:18 --> Security Class Initialized
DEBUG - 2023-08-31 11:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:17:18 --> Input Class Initialized
INFO - 2023-08-31 11:17:18 --> Language Class Initialized
ERROR - 2023-08-31 11:17:18 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:17:18 --> URI Class Initialized
INFO - 2023-08-31 11:17:18 --> Router Class Initialized
INFO - 2023-08-31 11:17:18 --> Output Class Initialized
INFO - 2023-08-31 11:17:19 --> Security Class Initialized
DEBUG - 2023-08-31 11:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:17:19 --> Input Class Initialized
INFO - 2023-08-31 11:17:19 --> Language Class Initialized
ERROR - 2023-08-31 11:17:19 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:17:51 --> Config Class Initialized
INFO - 2023-08-31 11:17:51 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:17:51 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:17:51 --> Utf8 Class Initialized
INFO - 2023-08-31 11:17:51 --> URI Class Initialized
INFO - 2023-08-31 11:17:51 --> Router Class Initialized
INFO - 2023-08-31 11:17:51 --> Output Class Initialized
INFO - 2023-08-31 11:17:52 --> Security Class Initialized
DEBUG - 2023-08-31 11:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:17:52 --> Input Class Initialized
INFO - 2023-08-31 11:17:52 --> Language Class Initialized
INFO - 2023-08-31 11:17:52 --> Loader Class Initialized
INFO - 2023-08-31 11:17:52 --> Helper loaded: url_helper
INFO - 2023-08-31 11:17:52 --> Helper loaded: file_helper
INFO - 2023-08-31 11:17:52 --> Database Driver Class Initialized
INFO - 2023-08-31 11:17:52 --> Email Class Initialized
DEBUG - 2023-08-31 11:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:17:52 --> Controller Class Initialized
INFO - 2023-08-31 11:17:52 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:17:52 --> Model "Home_model" initialized
INFO - 2023-08-31 11:17:52 --> Helper loaded: download_helper
INFO - 2023-08-31 11:17:52 --> Helper loaded: form_helper
INFO - 2023-08-31 11:17:52 --> Form Validation Class Initialized
ERROR - 2023-08-31 11:17:52 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 11:17:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 11:17:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 11:17:52 --> Final output sent to browser
DEBUG - 2023-08-31 11:17:53 --> Total execution time: 1.1301
INFO - 2023-08-31 11:17:54 --> Config Class Initialized
INFO - 2023-08-31 11:17:54 --> Hooks Class Initialized
INFO - 2023-08-31 11:17:55 --> Config Class Initialized
DEBUG - 2023-08-31 11:17:55 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:17:55 --> Utf8 Class Initialized
INFO - 2023-08-31 11:17:55 --> Hooks Class Initialized
INFO - 2023-08-31 11:17:55 --> URI Class Initialized
DEBUG - 2023-08-31 11:17:55 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:17:55 --> Router Class Initialized
INFO - 2023-08-31 11:17:55 --> Utf8 Class Initialized
INFO - 2023-08-31 11:17:55 --> Output Class Initialized
INFO - 2023-08-31 11:17:55 --> URI Class Initialized
INFO - 2023-08-31 11:17:55 --> Security Class Initialized
INFO - 2023-08-31 11:17:55 --> Router Class Initialized
DEBUG - 2023-08-31 11:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:17:55 --> Output Class Initialized
INFO - 2023-08-31 11:17:55 --> Input Class Initialized
INFO - 2023-08-31 11:17:55 --> Security Class Initialized
INFO - 2023-08-31 11:17:55 --> Language Class Initialized
DEBUG - 2023-08-31 11:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:17:55 --> Input Class Initialized
ERROR - 2023-08-31 11:17:55 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:17:55 --> Language Class Initialized
ERROR - 2023-08-31 11:17:55 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:18:27 --> Config Class Initialized
INFO - 2023-08-31 11:18:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:18:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:18:27 --> Utf8 Class Initialized
INFO - 2023-08-31 11:18:27 --> URI Class Initialized
INFO - 2023-08-31 11:18:27 --> Router Class Initialized
INFO - 2023-08-31 11:18:27 --> Output Class Initialized
INFO - 2023-08-31 11:18:27 --> Security Class Initialized
DEBUG - 2023-08-31 11:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:18:28 --> Input Class Initialized
INFO - 2023-08-31 11:18:28 --> Language Class Initialized
INFO - 2023-08-31 11:18:28 --> Loader Class Initialized
INFO - 2023-08-31 11:18:28 --> Helper loaded: url_helper
INFO - 2023-08-31 11:18:28 --> Helper loaded: file_helper
INFO - 2023-08-31 11:18:28 --> Database Driver Class Initialized
INFO - 2023-08-31 11:18:28 --> Email Class Initialized
DEBUG - 2023-08-31 11:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 11:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 11:18:28 --> Controller Class Initialized
INFO - 2023-08-31 11:18:28 --> Model "Contact_model" initialized
INFO - 2023-08-31 11:18:28 --> Model "Home_model" initialized
INFO - 2023-08-31 11:18:28 --> Helper loaded: download_helper
INFO - 2023-08-31 11:18:28 --> Helper loaded: form_helper
INFO - 2023-08-31 11:18:28 --> Form Validation Class Initialized
ERROR - 2023-08-31 11:18:28 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
ERROR - 2023-08-31 11:18:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 118
INFO - 2023-08-31 11:18:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-08-31 11:18:29 --> Final output sent to browser
DEBUG - 2023-08-31 11:18:29 --> Total execution time: 1.6315
INFO - 2023-08-31 11:18:30 --> Config Class Initialized
INFO - 2023-08-31 11:18:31 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:18:31 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:18:31 --> Config Class Initialized
INFO - 2023-08-31 11:18:31 --> Hooks Class Initialized
INFO - 2023-08-31 11:18:31 --> Utf8 Class Initialized
DEBUG - 2023-08-31 11:18:31 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:18:31 --> URI Class Initialized
INFO - 2023-08-31 11:18:31 --> Utf8 Class Initialized
INFO - 2023-08-31 11:18:31 --> Router Class Initialized
INFO - 2023-08-31 11:18:31 --> URI Class Initialized
INFO - 2023-08-31 11:18:31 --> Output Class Initialized
INFO - 2023-08-31 11:18:31 --> Router Class Initialized
INFO - 2023-08-31 11:18:31 --> Output Class Initialized
INFO - 2023-08-31 11:18:31 --> Security Class Initialized
INFO - 2023-08-31 11:18:31 --> Security Class Initialized
DEBUG - 2023-08-31 11:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-31 11:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:18:31 --> Input Class Initialized
INFO - 2023-08-31 11:18:31 --> Input Class Initialized
INFO - 2023-08-31 11:18:31 --> Language Class Initialized
INFO - 2023-08-31 11:18:32 --> Language Class Initialized
ERROR - 2023-08-31 11:18:32 --> 404 Page Not Found: Service-detail/assets
ERROR - 2023-08-31 11:18:32 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-08-31 11:24:49 --> Config Class Initialized
INFO - 2023-08-31 11:24:49 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:24:49 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:24:49 --> Utf8 Class Initialized
INFO - 2023-08-31 11:24:49 --> URI Class Initialized
INFO - 2023-08-31 11:24:49 --> Router Class Initialized
INFO - 2023-08-31 11:24:49 --> Output Class Initialized
INFO - 2023-08-31 11:24:49 --> Security Class Initialized
DEBUG - 2023-08-31 11:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:24:49 --> Input Class Initialized
INFO - 2023-08-31 11:24:49 --> Language Class Initialized
ERROR - 2023-08-31 11:24:49 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:24:49 --> Config Class Initialized
INFO - 2023-08-31 11:24:49 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:24:49 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:24:49 --> Utf8 Class Initialized
INFO - 2023-08-31 11:24:49 --> URI Class Initialized
INFO - 2023-08-31 11:24:49 --> Router Class Initialized
INFO - 2023-08-31 11:24:49 --> Output Class Initialized
INFO - 2023-08-31 11:24:49 --> Security Class Initialized
DEBUG - 2023-08-31 11:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:24:49 --> Input Class Initialized
INFO - 2023-08-31 11:24:49 --> Language Class Initialized
ERROR - 2023-08-31 11:24:49 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:24:50 --> Config Class Initialized
INFO - 2023-08-31 11:24:50 --> Config Class Initialized
INFO - 2023-08-31 11:24:50 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:24:50 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:24:50 --> Utf8 Class Initialized
INFO - 2023-08-31 11:24:50 --> URI Class Initialized
INFO - 2023-08-31 11:24:50 --> Router Class Initialized
INFO - 2023-08-31 11:24:50 --> Output Class Initialized
INFO - 2023-08-31 11:24:50 --> Security Class Initialized
DEBUG - 2023-08-31 11:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:24:50 --> Input Class Initialized
INFO - 2023-08-31 11:24:50 --> Language Class Initialized
ERROR - 2023-08-31 11:24:50 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:24:50 --> Hooks Class Initialized
INFO - 2023-08-31 11:24:50 --> Config Class Initialized
INFO - 2023-08-31 11:24:50 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:24:50 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:24:50 --> Utf8 Class Initialized
DEBUG - 2023-08-31 11:24:50 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:24:50 --> URI Class Initialized
INFO - 2023-08-31 11:24:50 --> Router Class Initialized
INFO - 2023-08-31 11:24:50 --> Output Class Initialized
INFO - 2023-08-31 11:24:50 --> Security Class Initialized
DEBUG - 2023-08-31 11:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:24:50 --> Input Class Initialized
INFO - 2023-08-31 11:24:50 --> Language Class Initialized
ERROR - 2023-08-31 11:24:50 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:24:50 --> Utf8 Class Initialized
INFO - 2023-08-31 11:24:50 --> URI Class Initialized
INFO - 2023-08-31 11:24:51 --> Router Class Initialized
INFO - 2023-08-31 11:24:51 --> Output Class Initialized
INFO - 2023-08-31 11:24:51 --> Security Class Initialized
DEBUG - 2023-08-31 11:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:24:51 --> Input Class Initialized
INFO - 2023-08-31 11:24:51 --> Language Class Initialized
ERROR - 2023-08-31 11:24:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:24:51 --> Config Class Initialized
INFO - 2023-08-31 11:24:51 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:24:51 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:24:51 --> Utf8 Class Initialized
INFO - 2023-08-31 11:24:51 --> URI Class Initialized
INFO - 2023-08-31 11:24:51 --> Router Class Initialized
INFO - 2023-08-31 11:24:51 --> Output Class Initialized
INFO - 2023-08-31 11:24:51 --> Security Class Initialized
DEBUG - 2023-08-31 11:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:24:51 --> Input Class Initialized
INFO - 2023-08-31 11:24:52 --> Language Class Initialized
ERROR - 2023-08-31 11:24:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 11:24:52 --> Config Class Initialized
INFO - 2023-08-31 11:24:52 --> Hooks Class Initialized
DEBUG - 2023-08-31 11:24:52 --> UTF-8 Support Enabled
INFO - 2023-08-31 11:24:52 --> Utf8 Class Initialized
INFO - 2023-08-31 11:24:52 --> URI Class Initialized
INFO - 2023-08-31 11:24:52 --> Router Class Initialized
INFO - 2023-08-31 11:24:52 --> Output Class Initialized
INFO - 2023-08-31 11:24:52 --> Security Class Initialized
DEBUG - 2023-08-31 11:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 11:24:52 --> Input Class Initialized
INFO - 2023-08-31 11:24:52 --> Language Class Initialized
ERROR - 2023-08-31 11:24:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-31 14:30:10 --> Config Class Initialized
INFO - 2023-08-31 14:30:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 14:30:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 14:30:10 --> Utf8 Class Initialized
INFO - 2023-08-31 14:30:10 --> URI Class Initialized
DEBUG - 2023-08-31 14:30:10 --> No URI present. Default controller set.
INFO - 2023-08-31 14:30:10 --> Router Class Initialized
INFO - 2023-08-31 14:30:10 --> Output Class Initialized
INFO - 2023-08-31 14:30:10 --> Security Class Initialized
DEBUG - 2023-08-31 14:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 14:30:10 --> Input Class Initialized
INFO - 2023-08-31 14:30:10 --> Language Class Initialized
INFO - 2023-08-31 14:30:10 --> Loader Class Initialized
INFO - 2023-08-31 14:30:10 --> Helper loaded: url_helper
INFO - 2023-08-31 14:30:10 --> Helper loaded: file_helper
INFO - 2023-08-31 14:30:10 --> Database Driver Class Initialized
INFO - 2023-08-31 14:30:10 --> Email Class Initialized
DEBUG - 2023-08-31 14:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 14:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 14:30:11 --> Controller Class Initialized
INFO - 2023-08-31 14:30:11 --> Model "Contact_model" initialized
INFO - 2023-08-31 14:30:11 --> Model "Home_model" initialized
INFO - 2023-08-31 14:30:11 --> Helper loaded: download_helper
INFO - 2023-08-31 14:30:11 --> Helper loaded: form_helper
INFO - 2023-08-31 14:30:11 --> Form Validation Class Initialized
INFO - 2023-08-31 14:30:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 14:30:11 --> Final output sent to browser
DEBUG - 2023-08-31 14:30:11 --> Total execution time: 1.4507
INFO - 2023-08-31 14:30:13 --> Config Class Initialized
INFO - 2023-08-31 14:30:13 --> Hooks Class Initialized
DEBUG - 2023-08-31 14:30:13 --> UTF-8 Support Enabled
INFO - 2023-08-31 14:30:13 --> Utf8 Class Initialized
INFO - 2023-08-31 14:30:13 --> URI Class Initialized
INFO - 2023-08-31 14:30:13 --> Router Class Initialized
INFO - 2023-08-31 14:30:13 --> Output Class Initialized
INFO - 2023-08-31 14:30:13 --> Security Class Initialized
DEBUG - 2023-08-31 14:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 14:30:13 --> Input Class Initialized
INFO - 2023-08-31 14:30:13 --> Language Class Initialized
ERROR - 2023-08-31 14:30:13 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 14:30:13 --> Config Class Initialized
INFO - 2023-08-31 14:30:13 --> Hooks Class Initialized
DEBUG - 2023-08-31 14:30:13 --> UTF-8 Support Enabled
INFO - 2023-08-31 14:30:13 --> Utf8 Class Initialized
INFO - 2023-08-31 14:30:13 --> URI Class Initialized
INFO - 2023-08-31 14:30:13 --> Router Class Initialized
INFO - 2023-08-31 14:30:13 --> Output Class Initialized
INFO - 2023-08-31 14:30:13 --> Security Class Initialized
DEBUG - 2023-08-31 14:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 14:30:13 --> Input Class Initialized
INFO - 2023-08-31 14:30:13 --> Language Class Initialized
ERROR - 2023-08-31 14:30:13 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 14:37:37 --> Config Class Initialized
INFO - 2023-08-31 14:37:37 --> Hooks Class Initialized
DEBUG - 2023-08-31 14:37:37 --> UTF-8 Support Enabled
INFO - 2023-08-31 14:37:37 --> Utf8 Class Initialized
INFO - 2023-08-31 14:37:37 --> URI Class Initialized
INFO - 2023-08-31 14:37:37 --> Router Class Initialized
INFO - 2023-08-31 14:37:37 --> Output Class Initialized
INFO - 2023-08-31 14:37:37 --> Security Class Initialized
DEBUG - 2023-08-31 14:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 14:37:37 --> Input Class Initialized
INFO - 2023-08-31 14:37:37 --> Language Class Initialized
INFO - 2023-08-31 14:37:37 --> Loader Class Initialized
INFO - 2023-08-31 14:37:37 --> Helper loaded: url_helper
INFO - 2023-08-31 14:37:38 --> Helper loaded: file_helper
INFO - 2023-08-31 14:37:38 --> Database Driver Class Initialized
INFO - 2023-08-31 14:37:38 --> Email Class Initialized
DEBUG - 2023-08-31 14:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 14:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 14:37:38 --> Controller Class Initialized
INFO - 2023-08-31 14:37:38 --> Model "Contact_model" initialized
INFO - 2023-08-31 14:37:38 --> Model "Home_model" initialized
INFO - 2023-08-31 14:37:38 --> Helper loaded: download_helper
INFO - 2023-08-31 14:37:38 --> Helper loaded: form_helper
INFO - 2023-08-31 14:37:38 --> Form Validation Class Initialized
INFO - 2023-08-31 14:37:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-31 14:37:38 --> Final output sent to browser
DEBUG - 2023-08-31 14:37:39 --> Total execution time: 1.8119
INFO - 2023-08-31 14:37:40 --> Config Class Initialized
INFO - 2023-08-31 14:37:40 --> Hooks Class Initialized
DEBUG - 2023-08-31 14:37:40 --> UTF-8 Support Enabled
INFO - 2023-08-31 14:37:40 --> Config Class Initialized
INFO - 2023-08-31 14:37:40 --> Utf8 Class Initialized
INFO - 2023-08-31 14:37:40 --> URI Class Initialized
INFO - 2023-08-31 14:37:40 --> Hooks Class Initialized
INFO - 2023-08-31 14:37:41 --> Router Class Initialized
INFO - 2023-08-31 14:37:41 --> Output Class Initialized
DEBUG - 2023-08-31 14:37:41 --> UTF-8 Support Enabled
INFO - 2023-08-31 14:37:41 --> Security Class Initialized
INFO - 2023-08-31 14:37:41 --> Utf8 Class Initialized
DEBUG - 2023-08-31 14:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 14:37:41 --> URI Class Initialized
INFO - 2023-08-31 14:37:41 --> Input Class Initialized
INFO - 2023-08-31 14:37:41 --> Language Class Initialized
INFO - 2023-08-31 14:37:41 --> Router Class Initialized
ERROR - 2023-08-31 14:37:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 14:37:41 --> Output Class Initialized
INFO - 2023-08-31 14:37:41 --> Security Class Initialized
DEBUG - 2023-08-31 14:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 14:37:41 --> Input Class Initialized
INFO - 2023-08-31 14:37:43 --> Config Class Initialized
INFO - 2023-08-31 14:37:43 --> Hooks Class Initialized
DEBUG - 2023-08-31 14:37:43 --> UTF-8 Support Enabled
INFO - 2023-08-31 14:37:43 --> Utf8 Class Initialized
INFO - 2023-08-31 14:37:43 --> URI Class Initialized
INFO - 2023-08-31 14:37:43 --> Router Class Initialized
INFO - 2023-08-31 14:37:43 --> Output Class Initialized
INFO - 2023-08-31 14:37:43 --> Security Class Initialized
DEBUG - 2023-08-31 14:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 14:37:43 --> Input Class Initialized
INFO - 2023-08-31 14:37:43 --> Language Class Initialized
INFO - 2023-08-31 14:37:43 --> Loader Class Initialized
INFO - 2023-08-31 14:37:43 --> Helper loaded: url_helper
INFO - 2023-08-31 14:37:44 --> Helper loaded: file_helper
INFO - 2023-08-31 14:37:44 --> Database Driver Class Initialized
INFO - 2023-08-31 14:37:44 --> Email Class Initialized
DEBUG - 2023-08-31 14:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 14:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 14:37:44 --> Controller Class Initialized
INFO - 2023-08-31 14:37:44 --> Model "Contact_model" initialized
INFO - 2023-08-31 14:37:44 --> Model "Home_model" initialized
INFO - 2023-08-31 14:37:44 --> Helper loaded: download_helper
INFO - 2023-08-31 14:37:44 --> Helper loaded: form_helper
INFO - 2023-08-31 14:37:44 --> Form Validation Class Initialized
INFO - 2023-08-31 14:37:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-31 14:37:44 --> Final output sent to browser
DEBUG - 2023-08-31 14:37:45 --> Total execution time: 1.8174
INFO - 2023-08-31 14:37:45 --> Config Class Initialized
INFO - 2023-08-31 14:37:45 --> Config Class Initialized
INFO - 2023-08-31 14:37:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 14:37:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 14:37:46 --> Hooks Class Initialized
INFO - 2023-08-31 14:37:46 --> Utf8 Class Initialized
DEBUG - 2023-08-31 14:37:46 --> UTF-8 Support Enabled
INFO - 2023-08-31 14:37:46 --> Utf8 Class Initialized
INFO - 2023-08-31 14:37:46 --> URI Class Initialized
INFO - 2023-08-31 14:37:46 --> Router Class Initialized
INFO - 2023-08-31 14:37:46 --> URI Class Initialized
INFO - 2023-08-31 14:37:46 --> Output Class Initialized
INFO - 2023-08-31 14:37:46 --> Router Class Initialized
INFO - 2023-08-31 14:37:46 --> Security Class Initialized
INFO - 2023-08-31 14:37:46 --> Output Class Initialized
DEBUG - 2023-08-31 14:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 14:37:46 --> Security Class Initialized
INFO - 2023-08-31 14:37:46 --> Input Class Initialized
DEBUG - 2023-08-31 14:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 14:37:46 --> Language Class Initialized
INFO - 2023-08-31 14:37:46 --> Input Class Initialized
ERROR - 2023-08-31 14:37:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 14:37:46 --> Language Class Initialized
ERROR - 2023-08-31 14:37:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 15:58:09 --> Config Class Initialized
INFO - 2023-08-31 15:58:09 --> Hooks Class Initialized
DEBUG - 2023-08-31 15:58:09 --> UTF-8 Support Enabled
INFO - 2023-08-31 15:58:09 --> Utf8 Class Initialized
INFO - 2023-08-31 15:58:09 --> URI Class Initialized
DEBUG - 2023-08-31 15:58:09 --> No URI present. Default controller set.
INFO - 2023-08-31 15:58:09 --> Router Class Initialized
INFO - 2023-08-31 15:58:09 --> Output Class Initialized
INFO - 2023-08-31 15:58:09 --> Security Class Initialized
DEBUG - 2023-08-31 15:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 15:58:10 --> Input Class Initialized
INFO - 2023-08-31 15:58:10 --> Language Class Initialized
INFO - 2023-08-31 15:58:10 --> Loader Class Initialized
INFO - 2023-08-31 15:58:10 --> Helper loaded: url_helper
INFO - 2023-08-31 15:58:10 --> Helper loaded: file_helper
INFO - 2023-08-31 15:58:10 --> Database Driver Class Initialized
INFO - 2023-08-31 15:58:10 --> Email Class Initialized
DEBUG - 2023-08-31 15:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 15:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 15:58:10 --> Controller Class Initialized
INFO - 2023-08-31 15:58:10 --> Model "Contact_model" initialized
INFO - 2023-08-31 15:58:10 --> Model "Home_model" initialized
INFO - 2023-08-31 15:58:10 --> Helper loaded: download_helper
INFO - 2023-08-31 15:58:10 --> Helper loaded: form_helper
INFO - 2023-08-31 15:58:10 --> Form Validation Class Initialized
INFO - 2023-08-31 15:58:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 15:58:10 --> Final output sent to browser
DEBUG - 2023-08-31 15:58:10 --> Total execution time: 1.0013
INFO - 2023-08-31 15:58:11 --> Config Class Initialized
INFO - 2023-08-31 15:58:11 --> Hooks Class Initialized
INFO - 2023-08-31 15:58:11 --> Config Class Initialized
DEBUG - 2023-08-31 15:58:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 15:58:12 --> Hooks Class Initialized
DEBUG - 2023-08-31 15:58:12 --> UTF-8 Support Enabled
INFO - 2023-08-31 15:58:12 --> Utf8 Class Initialized
INFO - 2023-08-31 15:58:12 --> URI Class Initialized
INFO - 2023-08-31 15:58:12 --> Router Class Initialized
INFO - 2023-08-31 15:58:12 --> Output Class Initialized
INFO - 2023-08-31 15:58:12 --> Security Class Initialized
DEBUG - 2023-08-31 15:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 15:58:12 --> Input Class Initialized
INFO - 2023-08-31 15:58:12 --> Language Class Initialized
ERROR - 2023-08-31 15:58:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 15:58:12 --> Utf8 Class Initialized
INFO - 2023-08-31 15:58:12 --> URI Class Initialized
INFO - 2023-08-31 15:58:12 --> Router Class Initialized
INFO - 2023-08-31 15:58:12 --> Output Class Initialized
INFO - 2023-08-31 15:58:12 --> Security Class Initialized
DEBUG - 2023-08-31 15:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 15:58:12 --> Input Class Initialized
INFO - 2023-08-31 15:58:12 --> Language Class Initialized
ERROR - 2023-08-31 15:58:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 15:58:19 --> Config Class Initialized
INFO - 2023-08-31 15:58:19 --> Hooks Class Initialized
DEBUG - 2023-08-31 15:58:19 --> UTF-8 Support Enabled
INFO - 2023-08-31 15:58:19 --> Utf8 Class Initialized
INFO - 2023-08-31 15:58:19 --> URI Class Initialized
DEBUG - 2023-08-31 15:58:19 --> No URI present. Default controller set.
INFO - 2023-08-31 15:58:19 --> Router Class Initialized
INFO - 2023-08-31 15:58:19 --> Output Class Initialized
INFO - 2023-08-31 15:58:19 --> Security Class Initialized
DEBUG - 2023-08-31 15:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 15:58:19 --> Input Class Initialized
INFO - 2023-08-31 15:58:19 --> Language Class Initialized
INFO - 2023-08-31 15:58:19 --> Loader Class Initialized
INFO - 2023-08-31 15:58:19 --> Helper loaded: url_helper
INFO - 2023-08-31 15:58:19 --> Helper loaded: file_helper
INFO - 2023-08-31 15:58:19 --> Database Driver Class Initialized
INFO - 2023-08-31 15:58:19 --> Email Class Initialized
DEBUG - 2023-08-31 15:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 15:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 15:58:19 --> Controller Class Initialized
INFO - 2023-08-31 15:58:19 --> Model "Contact_model" initialized
INFO - 2023-08-31 15:58:19 --> Model "Home_model" initialized
INFO - 2023-08-31 15:58:19 --> Helper loaded: download_helper
INFO - 2023-08-31 15:58:19 --> Helper loaded: form_helper
INFO - 2023-08-31 15:58:19 --> Form Validation Class Initialized
INFO - 2023-08-31 15:58:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-31 15:58:19 --> Final output sent to browser
DEBUG - 2023-08-31 15:58:19 --> Total execution time: 0.1026
INFO - 2023-08-31 15:58:19 --> Config Class Initialized
INFO - 2023-08-31 15:58:19 --> Hooks Class Initialized
DEBUG - 2023-08-31 15:58:19 --> UTF-8 Support Enabled
INFO - 2023-08-31 15:58:19 --> Utf8 Class Initialized
INFO - 2023-08-31 15:58:19 --> URI Class Initialized
INFO - 2023-08-31 15:58:19 --> Router Class Initialized
INFO - 2023-08-31 15:58:19 --> Output Class Initialized
INFO - 2023-08-31 15:58:19 --> Security Class Initialized
DEBUG - 2023-08-31 15:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 15:58:19 --> Input Class Initialized
INFO - 2023-08-31 15:58:19 --> Language Class Initialized
ERROR - 2023-08-31 15:58:19 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 15:58:20 --> Config Class Initialized
INFO - 2023-08-31 15:58:20 --> Hooks Class Initialized
DEBUG - 2023-08-31 15:58:20 --> UTF-8 Support Enabled
INFO - 2023-08-31 15:58:20 --> Utf8 Class Initialized
INFO - 2023-08-31 15:58:20 --> URI Class Initialized
INFO - 2023-08-31 15:58:20 --> Router Class Initialized
INFO - 2023-08-31 15:58:20 --> Output Class Initialized
INFO - 2023-08-31 15:58:20 --> Security Class Initialized
DEBUG - 2023-08-31 15:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 15:58:20 --> Input Class Initialized
INFO - 2023-08-31 15:58:21 --> Language Class Initialized
ERROR - 2023-08-31 15:58:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 15:58:50 --> Config Class Initialized
INFO - 2023-08-31 15:58:50 --> Hooks Class Initialized
DEBUG - 2023-08-31 15:58:50 --> UTF-8 Support Enabled
INFO - 2023-08-31 15:58:50 --> Utf8 Class Initialized
INFO - 2023-08-31 15:58:50 --> URI Class Initialized
INFO - 2023-08-31 15:58:50 --> Router Class Initialized
INFO - 2023-08-31 15:58:50 --> Output Class Initialized
INFO - 2023-08-31 15:58:50 --> Security Class Initialized
DEBUG - 2023-08-31 15:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 15:58:50 --> Input Class Initialized
INFO - 2023-08-31 15:58:50 --> Language Class Initialized
INFO - 2023-08-31 15:58:50 --> Loader Class Initialized
INFO - 2023-08-31 15:58:51 --> Helper loaded: url_helper
INFO - 2023-08-31 15:58:51 --> Helper loaded: file_helper
INFO - 2023-08-31 15:58:51 --> Database Driver Class Initialized
INFO - 2023-08-31 15:58:51 --> Email Class Initialized
DEBUG - 2023-08-31 15:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 15:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 15:58:51 --> Controller Class Initialized
INFO - 2023-08-31 15:58:51 --> Config Class Initialized
INFO - 2023-08-31 15:58:51 --> Hooks Class Initialized
DEBUG - 2023-08-31 15:58:51 --> UTF-8 Support Enabled
INFO - 2023-08-31 15:58:51 --> Utf8 Class Initialized
INFO - 2023-08-31 15:58:51 --> URI Class Initialized
INFO - 2023-08-31 15:58:51 --> Router Class Initialized
INFO - 2023-08-31 15:58:51 --> Output Class Initialized
INFO - 2023-08-31 15:58:51 --> Security Class Initialized
DEBUG - 2023-08-31 15:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 15:58:51 --> Input Class Initialized
INFO - 2023-08-31 15:58:51 --> Language Class Initialized
INFO - 2023-08-31 15:58:51 --> Loader Class Initialized
INFO - 2023-08-31 15:58:51 --> Helper loaded: url_helper
INFO - 2023-08-31 15:58:51 --> Helper loaded: file_helper
INFO - 2023-08-31 15:58:51 --> Database Driver Class Initialized
INFO - 2023-08-31 15:58:51 --> Email Class Initialized
DEBUG - 2023-08-31 15:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 15:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 15:58:52 --> Controller Class Initialized
INFO - 2023-08-31 15:58:52 --> Model "User_model" initialized
INFO - 2023-08-31 15:58:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-31 15:58:52 --> Final output sent to browser
DEBUG - 2023-08-31 15:58:52 --> Total execution time: 0.8369
INFO - 2023-08-31 15:58:53 --> Config Class Initialized
INFO - 2023-08-31 15:58:53 --> Hooks Class Initialized
DEBUG - 2023-08-31 15:58:53 --> UTF-8 Support Enabled
INFO - 2023-08-31 15:58:53 --> Utf8 Class Initialized
INFO - 2023-08-31 15:58:53 --> URI Class Initialized
INFO - 2023-08-31 15:58:53 --> Router Class Initialized
INFO - 2023-08-31 15:58:53 --> Output Class Initialized
INFO - 2023-08-31 15:58:53 --> Security Class Initialized
DEBUG - 2023-08-31 15:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 15:58:53 --> Input Class Initialized
INFO - 2023-08-31 15:58:53 --> Language Class Initialized
ERROR - 2023-08-31 15:58:53 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-31 15:59:09 --> Config Class Initialized
INFO - 2023-08-31 15:59:09 --> Hooks Class Initialized
DEBUG - 2023-08-31 15:59:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 15:59:10 --> Utf8 Class Initialized
INFO - 2023-08-31 15:59:10 --> URI Class Initialized
INFO - 2023-08-31 15:59:10 --> Router Class Initialized
INFO - 2023-08-31 15:59:10 --> Output Class Initialized
INFO - 2023-08-31 15:59:10 --> Security Class Initialized
DEBUG - 2023-08-31 15:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 15:59:10 --> Input Class Initialized
INFO - 2023-08-31 15:59:10 --> Language Class Initialized
INFO - 2023-08-31 15:59:10 --> Loader Class Initialized
INFO - 2023-08-31 15:59:10 --> Helper loaded: url_helper
INFO - 2023-08-31 15:59:10 --> Helper loaded: file_helper
INFO - 2023-08-31 15:59:10 --> Database Driver Class Initialized
INFO - 2023-08-31 15:59:10 --> Email Class Initialized
DEBUG - 2023-08-31 15:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 15:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 15:59:10 --> Controller Class Initialized
INFO - 2023-08-31 15:59:10 --> Model "User_model" initialized
INFO - 2023-08-31 15:59:10 --> Config Class Initialized
INFO - 2023-08-31 15:59:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 15:59:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 15:59:10 --> Utf8 Class Initialized
INFO - 2023-08-31 15:59:10 --> URI Class Initialized
INFO - 2023-08-31 15:59:10 --> Router Class Initialized
INFO - 2023-08-31 15:59:10 --> Output Class Initialized
INFO - 2023-08-31 15:59:11 --> Security Class Initialized
DEBUG - 2023-08-31 15:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 15:59:11 --> Input Class Initialized
INFO - 2023-08-31 15:59:11 --> Language Class Initialized
INFO - 2023-08-31 15:59:11 --> Loader Class Initialized
INFO - 2023-08-31 15:59:11 --> Helper loaded: url_helper
INFO - 2023-08-31 15:59:11 --> Helper loaded: file_helper
INFO - 2023-08-31 15:59:11 --> Database Driver Class Initialized
INFO - 2023-08-31 15:59:11 --> Email Class Initialized
DEBUG - 2023-08-31 15:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 15:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 15:59:11 --> Controller Class Initialized
INFO - 2023-08-31 15:59:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-31 15:59:11 --> Final output sent to browser
DEBUG - 2023-08-31 15:59:11 --> Total execution time: 0.6748
INFO - 2023-08-31 15:59:48 --> Config Class Initialized
INFO - 2023-08-31 15:59:48 --> Hooks Class Initialized
DEBUG - 2023-08-31 15:59:48 --> UTF-8 Support Enabled
INFO - 2023-08-31 15:59:48 --> Utf8 Class Initialized
INFO - 2023-08-31 15:59:48 --> URI Class Initialized
INFO - 2023-08-31 15:59:48 --> Router Class Initialized
INFO - 2023-08-31 15:59:48 --> Output Class Initialized
INFO - 2023-08-31 15:59:48 --> Security Class Initialized
DEBUG - 2023-08-31 15:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 15:59:48 --> Input Class Initialized
INFO - 2023-08-31 15:59:48 --> Language Class Initialized
INFO - 2023-08-31 15:59:48 --> Loader Class Initialized
INFO - 2023-08-31 15:59:48 --> Helper loaded: url_helper
INFO - 2023-08-31 15:59:48 --> Helper loaded: file_helper
INFO - 2023-08-31 15:59:48 --> Database Driver Class Initialized
INFO - 2023-08-31 15:59:48 --> Email Class Initialized
DEBUG - 2023-08-31 15:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 15:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 15:59:48 --> Controller Class Initialized
INFO - 2023-08-31 15:59:48 --> Model "Services_model" initialized
INFO - 2023-08-31 15:59:49 --> Helper loaded: form_helper
INFO - 2023-08-31 15:59:49 --> Form Validation Class Initialized
INFO - 2023-08-31 15:59:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 15:59:49 --> Final output sent to browser
DEBUG - 2023-08-31 15:59:49 --> Total execution time: 0.8149
INFO - 2023-08-31 15:59:50 --> Config Class Initialized
INFO - 2023-08-31 15:59:50 --> Hooks Class Initialized
DEBUG - 2023-08-31 15:59:50 --> UTF-8 Support Enabled
INFO - 2023-08-31 15:59:51 --> Utf8 Class Initialized
INFO - 2023-08-31 15:59:51 --> URI Class Initialized
INFO - 2023-08-31 15:59:51 --> Router Class Initialized
INFO - 2023-08-31 15:59:51 --> Output Class Initialized
INFO - 2023-08-31 15:59:51 --> Security Class Initialized
DEBUG - 2023-08-31 15:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 15:59:51 --> Input Class Initialized
INFO - 2023-08-31 15:59:51 --> Language Class Initialized
INFO - 2023-08-31 15:59:51 --> Loader Class Initialized
INFO - 2023-08-31 15:59:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 15:59:51 --> Final output sent to browser
DEBUG - 2023-08-31 15:59:51 --> Total execution time: 0.3898
INFO - 2023-08-31 15:59:52 --> Config Class Initialized
INFO - 2023-08-31 15:59:52 --> Hooks Class Initialized
DEBUG - 2023-08-31 15:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-31 15:59:52 --> Utf8 Class Initialized
INFO - 2023-08-31 15:59:52 --> URI Class Initialized
INFO - 2023-08-31 15:59:52 --> Router Class Initialized
INFO - 2023-08-31 15:59:52 --> Output Class Initialized
INFO - 2023-08-31 15:59:52 --> Security Class Initialized
DEBUG - 2023-08-31 15:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 15:59:52 --> Input Class Initialized
INFO - 2023-08-31 15:59:52 --> Language Class Initialized
ERROR - 2023-08-31 15:59:52 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-31 16:15:39 --> Config Class Initialized
INFO - 2023-08-31 16:15:40 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:15:40 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:15:40 --> Utf8 Class Initialized
INFO - 2023-08-31 16:15:40 --> URI Class Initialized
INFO - 2023-08-31 16:15:40 --> Router Class Initialized
INFO - 2023-08-31 16:15:40 --> Output Class Initialized
INFO - 2023-08-31 16:15:40 --> Security Class Initialized
DEBUG - 2023-08-31 16:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:15:40 --> Input Class Initialized
INFO - 2023-08-31 16:15:40 --> Language Class Initialized
INFO - 2023-08-31 16:15:40 --> Loader Class Initialized
INFO - 2023-08-31 16:15:40 --> Helper loaded: url_helper
INFO - 2023-08-31 16:15:40 --> Helper loaded: file_helper
INFO - 2023-08-31 16:15:40 --> Database Driver Class Initialized
INFO - 2023-08-31 16:15:40 --> Email Class Initialized
DEBUG - 2023-08-31 16:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:15:40 --> Controller Class Initialized
INFO - 2023-08-31 16:15:40 --> Model "Services_model" initialized
INFO - 2023-08-31 16:15:40 --> Helper loaded: form_helper
INFO - 2023-08-31 16:15:40 --> Form Validation Class Initialized
INFO - 2023-08-31 16:15:40 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 16:15:41 --> Final output sent to browser
DEBUG - 2023-08-31 16:15:41 --> Total execution time: 0.9572
INFO - 2023-08-31 16:17:51 --> Config Class Initialized
INFO - 2023-08-31 16:17:51 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:17:51 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:17:51 --> Utf8 Class Initialized
INFO - 2023-08-31 16:17:51 --> URI Class Initialized
INFO - 2023-08-31 16:17:51 --> Router Class Initialized
INFO - 2023-08-31 16:17:51 --> Output Class Initialized
INFO - 2023-08-31 16:17:51 --> Security Class Initialized
DEBUG - 2023-08-31 16:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:17:51 --> Input Class Initialized
INFO - 2023-08-31 16:17:51 --> Language Class Initialized
INFO - 2023-08-31 16:17:51 --> Loader Class Initialized
INFO - 2023-08-31 16:17:51 --> Helper loaded: url_helper
INFO - 2023-08-31 16:17:51 --> Helper loaded: file_helper
INFO - 2023-08-31 16:17:51 --> Database Driver Class Initialized
INFO - 2023-08-31 16:17:52 --> Email Class Initialized
DEBUG - 2023-08-31 16:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:17:52 --> Controller Class Initialized
INFO - 2023-08-31 16:17:52 --> Model "Services_model" initialized
INFO - 2023-08-31 16:17:52 --> Helper loaded: form_helper
INFO - 2023-08-31 16:17:52 --> Form Validation Class Initialized
INFO - 2023-08-31 16:17:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 16:17:52 --> Final output sent to browser
DEBUG - 2023-08-31 16:17:52 --> Total execution time: 0.6136
INFO - 2023-08-31 16:35:10 --> Config Class Initialized
INFO - 2023-08-31 16:35:11 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:35:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:35:11 --> Utf8 Class Initialized
INFO - 2023-08-31 16:35:11 --> URI Class Initialized
INFO - 2023-08-31 16:35:11 --> Router Class Initialized
INFO - 2023-08-31 16:35:11 --> Output Class Initialized
INFO - 2023-08-31 16:35:11 --> Security Class Initialized
DEBUG - 2023-08-31 16:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:35:11 --> Input Class Initialized
INFO - 2023-08-31 16:35:11 --> Language Class Initialized
INFO - 2023-08-31 16:35:11 --> Loader Class Initialized
INFO - 2023-08-31 16:35:11 --> Helper loaded: url_helper
INFO - 2023-08-31 16:35:11 --> Helper loaded: file_helper
INFO - 2023-08-31 16:35:11 --> Database Driver Class Initialized
INFO - 2023-08-31 16:35:11 --> Email Class Initialized
DEBUG - 2023-08-31 16:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:35:11 --> Controller Class Initialized
INFO - 2023-08-31 16:35:11 --> Model "Services_model" initialized
INFO - 2023-08-31 16:35:11 --> Helper loaded: form_helper
INFO - 2023-08-31 16:35:11 --> Form Validation Class Initialized
INFO - 2023-08-31 16:35:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 16:35:12 --> Final output sent to browser
DEBUG - 2023-08-31 16:35:12 --> Total execution time: 0.9155
INFO - 2023-08-31 16:35:47 --> Config Class Initialized
INFO - 2023-08-31 16:35:47 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:35:47 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:35:47 --> Utf8 Class Initialized
INFO - 2023-08-31 16:35:47 --> URI Class Initialized
INFO - 2023-08-31 16:35:47 --> Router Class Initialized
INFO - 2023-08-31 16:35:47 --> Output Class Initialized
INFO - 2023-08-31 16:35:47 --> Security Class Initialized
DEBUG - 2023-08-31 16:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:35:47 --> Input Class Initialized
INFO - 2023-08-31 16:35:47 --> Language Class Initialized
INFO - 2023-08-31 16:35:47 --> Loader Class Initialized
INFO - 2023-08-31 16:35:47 --> Helper loaded: url_helper
INFO - 2023-08-31 16:35:47 --> Helper loaded: file_helper
INFO - 2023-08-31 16:35:47 --> Database Driver Class Initialized
INFO - 2023-08-31 16:35:47 --> Email Class Initialized
DEBUG - 2023-08-31 16:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:35:47 --> Controller Class Initialized
INFO - 2023-08-31 16:35:47 --> Model "Services_model" initialized
INFO - 2023-08-31 16:35:47 --> Helper loaded: form_helper
INFO - 2023-08-31 16:35:47 --> Form Validation Class Initialized
INFO - 2023-08-31 16:35:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 16:35:47 --> Final output sent to browser
DEBUG - 2023-08-31 16:35:48 --> Total execution time: 0.6238
INFO - 2023-08-31 16:40:08 --> Config Class Initialized
INFO - 2023-08-31 16:40:08 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:40:08 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:40:09 --> Utf8 Class Initialized
INFO - 2023-08-31 16:40:09 --> URI Class Initialized
INFO - 2023-08-31 16:40:09 --> Router Class Initialized
INFO - 2023-08-31 16:40:09 --> Output Class Initialized
INFO - 2023-08-31 16:40:09 --> Security Class Initialized
DEBUG - 2023-08-31 16:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:40:09 --> Input Class Initialized
INFO - 2023-08-31 16:40:09 --> Language Class Initialized
INFO - 2023-08-31 16:40:09 --> Loader Class Initialized
INFO - 2023-08-31 16:40:09 --> Helper loaded: url_helper
INFO - 2023-08-31 16:40:09 --> Helper loaded: file_helper
INFO - 2023-08-31 16:40:09 --> Database Driver Class Initialized
INFO - 2023-08-31 16:40:09 --> Email Class Initialized
DEBUG - 2023-08-31 16:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:40:09 --> Controller Class Initialized
INFO - 2023-08-31 16:40:09 --> Model "Services_model" initialized
INFO - 2023-08-31 16:40:09 --> Helper loaded: form_helper
INFO - 2023-08-31 16:40:09 --> Form Validation Class Initialized
INFO - 2023-08-31 16:40:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 16:40:09 --> Final output sent to browser
DEBUG - 2023-08-31 16:40:09 --> Total execution time: 0.6215
INFO - 2023-08-31 16:40:11 --> Config Class Initialized
INFO - 2023-08-31 16:40:11 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:40:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:40:11 --> Utf8 Class Initialized
INFO - 2023-08-31 16:40:11 --> URI Class Initialized
INFO - 2023-08-31 16:40:11 --> Router Class Initialized
INFO - 2023-08-31 16:40:11 --> Output Class Initialized
INFO - 2023-08-31 16:40:11 --> Security Class Initialized
DEBUG - 2023-08-31 16:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:40:11 --> Input Class Initialized
INFO - 2023-08-31 16:40:11 --> Language Class Initialized
ERROR - 2023-08-31 16:40:11 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-31 16:41:27 --> Config Class Initialized
INFO - 2023-08-31 16:41:27 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:41:27 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:41:27 --> Utf8 Class Initialized
INFO - 2023-08-31 16:41:27 --> URI Class Initialized
INFO - 2023-08-31 16:41:27 --> Router Class Initialized
INFO - 2023-08-31 16:41:27 --> Output Class Initialized
INFO - 2023-08-31 16:41:27 --> Security Class Initialized
DEBUG - 2023-08-31 16:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:41:27 --> Input Class Initialized
INFO - 2023-08-31 16:41:27 --> Language Class Initialized
INFO - 2023-08-31 16:41:27 --> Loader Class Initialized
INFO - 2023-08-31 16:41:27 --> Helper loaded: url_helper
INFO - 2023-08-31 16:41:27 --> Helper loaded: file_helper
INFO - 2023-08-31 16:41:27 --> Database Driver Class Initialized
INFO - 2023-08-31 16:41:27 --> Email Class Initialized
DEBUG - 2023-08-31 16:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:41:27 --> Controller Class Initialized
INFO - 2023-08-31 16:41:27 --> Model "Services_model" initialized
INFO - 2023-08-31 16:41:27 --> Helper loaded: form_helper
INFO - 2023-08-31 16:41:27 --> Form Validation Class Initialized
INFO - 2023-08-31 16:41:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 16:41:28 --> Final output sent to browser
DEBUG - 2023-08-31 16:41:28 --> Total execution time: 0.5288
INFO - 2023-08-31 16:41:29 --> Config Class Initialized
INFO - 2023-08-31 16:41:29 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:41:29 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:41:29 --> Utf8 Class Initialized
INFO - 2023-08-31 16:41:29 --> URI Class Initialized
INFO - 2023-08-31 16:41:29 --> Router Class Initialized
INFO - 2023-08-31 16:41:29 --> Output Class Initialized
INFO - 2023-08-31 16:41:29 --> Security Class Initialized
DEBUG - 2023-08-31 16:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:41:29 --> Input Class Initialized
INFO - 2023-08-31 16:41:29 --> Language Class Initialized
ERROR - 2023-08-31 16:41:29 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-31 16:41:31 --> Config Class Initialized
INFO - 2023-08-31 16:41:31 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:41:31 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:41:31 --> Utf8 Class Initialized
INFO - 2023-08-31 16:41:31 --> URI Class Initialized
INFO - 2023-08-31 16:41:31 --> Router Class Initialized
INFO - 2023-08-31 16:41:31 --> Output Class Initialized
INFO - 2023-08-31 16:41:31 --> Security Class Initialized
DEBUG - 2023-08-31 16:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:41:31 --> Input Class Initialized
INFO - 2023-08-31 16:41:31 --> Language Class Initialized
INFO - 2023-08-31 16:41:31 --> Loader Class Initialized
INFO - 2023-08-31 16:41:31 --> Helper loaded: url_helper
INFO - 2023-08-31 16:41:31 --> Helper loaded: file_helper
INFO - 2023-08-31 16:41:31 --> Database Driver Class Initialized
INFO - 2023-08-31 16:41:32 --> Email Class Initialized
DEBUG - 2023-08-31 16:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:41:32 --> Controller Class Initialized
INFO - 2023-08-31 16:41:32 --> Model "Services_model" initialized
INFO - 2023-08-31 16:41:32 --> Helper loaded: form_helper
INFO - 2023-08-31 16:41:32 --> Form Validation Class Initialized
INFO - 2023-08-31 16:41:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 16:41:32 --> Final output sent to browser
DEBUG - 2023-08-31 16:41:32 --> Total execution time: 0.6799
INFO - 2023-08-31 16:41:33 --> Config Class Initialized
INFO - 2023-08-31 16:41:33 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:41:33 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:41:33 --> Utf8 Class Initialized
INFO - 2023-08-31 16:41:33 --> URI Class Initialized
INFO - 2023-08-31 16:41:33 --> Router Class Initialized
INFO - 2023-08-31 16:41:33 --> Output Class Initialized
INFO - 2023-08-31 16:41:33 --> Security Class Initialized
DEBUG - 2023-08-31 16:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:41:33 --> Input Class Initialized
INFO - 2023-08-31 16:41:33 --> Language Class Initialized
ERROR - 2023-08-31 16:41:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 16:41:33 --> Config Class Initialized
INFO - 2023-08-31 16:41:33 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:41:33 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:41:33 --> Utf8 Class Initialized
INFO - 2023-08-31 16:41:33 --> URI Class Initialized
INFO - 2023-08-31 16:41:33 --> Router Class Initialized
INFO - 2023-08-31 16:41:33 --> Output Class Initialized
INFO - 2023-08-31 16:41:33 --> Security Class Initialized
DEBUG - 2023-08-31 16:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:41:33 --> Input Class Initialized
INFO - 2023-08-31 16:41:33 --> Language Class Initialized
ERROR - 2023-08-31 16:41:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-31 16:41:34 --> Config Class Initialized
INFO - 2023-08-31 16:41:34 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:41:34 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:41:34 --> Utf8 Class Initialized
INFO - 2023-08-31 16:41:34 --> URI Class Initialized
INFO - 2023-08-31 16:41:34 --> Router Class Initialized
INFO - 2023-08-31 16:41:34 --> Output Class Initialized
INFO - 2023-08-31 16:41:34 --> Security Class Initialized
DEBUG - 2023-08-31 16:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:41:34 --> Input Class Initialized
INFO - 2023-08-31 16:41:34 --> Language Class Initialized
INFO - 2023-08-31 16:41:34 --> Loader Class Initialized
INFO - 2023-08-31 16:41:34 --> Helper loaded: url_helper
INFO - 2023-08-31 16:41:34 --> Helper loaded: file_helper
INFO - 2023-08-31 16:41:34 --> Database Driver Class Initialized
INFO - 2023-08-31 16:41:34 --> Email Class Initialized
DEBUG - 2023-08-31 16:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:41:34 --> Controller Class Initialized
INFO - 2023-08-31 16:41:34 --> Model "Services_model" initialized
INFO - 2023-08-31 16:41:34 --> Helper loaded: form_helper
INFO - 2023-08-31 16:41:34 --> Form Validation Class Initialized
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 143
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 153
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 166
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 176
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 189
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 199
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 209
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 211
ERROR - 2023-08-31 16:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 213
INFO - 2023-08-31 16:41:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 16:41:34 --> Final output sent to browser
DEBUG - 2023-08-31 16:41:35 --> Total execution time: 0.9570
INFO - 2023-08-31 16:51:55 --> Config Class Initialized
INFO - 2023-08-31 16:51:55 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:51:55 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:51:55 --> Utf8 Class Initialized
INFO - 2023-08-31 16:51:55 --> URI Class Initialized
INFO - 2023-08-31 16:51:55 --> Router Class Initialized
INFO - 2023-08-31 16:51:55 --> Output Class Initialized
INFO - 2023-08-31 16:51:55 --> Security Class Initialized
DEBUG - 2023-08-31 16:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:51:55 --> Input Class Initialized
INFO - 2023-08-31 16:51:55 --> Language Class Initialized
INFO - 2023-08-31 16:51:55 --> Loader Class Initialized
INFO - 2023-08-31 16:51:55 --> Helper loaded: url_helper
INFO - 2023-08-31 16:51:55 --> Helper loaded: file_helper
INFO - 2023-08-31 16:51:55 --> Database Driver Class Initialized
INFO - 2023-08-31 16:51:55 --> Email Class Initialized
DEBUG - 2023-08-31 16:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:51:55 --> Controller Class Initialized
INFO - 2023-08-31 16:51:55 --> Model "Services_model" initialized
INFO - 2023-08-31 16:51:55 --> Helper loaded: form_helper
INFO - 2023-08-31 16:51:55 --> Form Validation Class Initialized
ERROR - 2023-08-31 16:51:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-31 16:51:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-31 16:51:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-31 16:51:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-31 16:51:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-31 16:51:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-31 16:51:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-31 16:51:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-31 16:51:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-31 16:51:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-31 16:51:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 143
ERROR - 2023-08-31 16:51:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 153
ERROR - 2023-08-31 16:51:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 166
ERROR - 2023-08-31 16:51:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 176
ERROR - 2023-08-31 16:51:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 189
ERROR - 2023-08-31 16:51:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 199
ERROR - 2023-08-31 16:51:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 209
ERROR - 2023-08-31 16:51:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 211
ERROR - 2023-08-31 16:51:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 213
INFO - 2023-08-31 16:51:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 16:51:56 --> Final output sent to browser
DEBUG - 2023-08-31 16:51:56 --> Total execution time: 1.1876
INFO - 2023-08-31 16:51:59 --> Config Class Initialized
INFO - 2023-08-31 16:51:59 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:51:59 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:51:59 --> Utf8 Class Initialized
INFO - 2023-08-31 16:51:59 --> URI Class Initialized
INFO - 2023-08-31 16:51:59 --> Router Class Initialized
INFO - 2023-08-31 16:51:59 --> Output Class Initialized
INFO - 2023-08-31 16:51:59 --> Security Class Initialized
DEBUG - 2023-08-31 16:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:51:59 --> Input Class Initialized
INFO - 2023-08-31 16:51:59 --> Language Class Initialized
INFO - 2023-08-31 16:51:59 --> Loader Class Initialized
INFO - 2023-08-31 16:51:59 --> Helper loaded: url_helper
INFO - 2023-08-31 16:51:59 --> Helper loaded: file_helper
INFO - 2023-08-31 16:51:59 --> Database Driver Class Initialized
INFO - 2023-08-31 16:51:59 --> Email Class Initialized
DEBUG - 2023-08-31 16:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:51:59 --> Controller Class Initialized
INFO - 2023-08-31 16:51:59 --> Model "Services_model" initialized
INFO - 2023-08-31 16:51:59 --> Helper loaded: form_helper
INFO - 2023-08-31 16:51:59 --> Form Validation Class Initialized
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 143
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 153
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 166
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 176
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 189
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 199
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 209
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 211
ERROR - 2023-08-31 16:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 213
INFO - 2023-08-31 16:51:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 16:51:59 --> Final output sent to browser
DEBUG - 2023-08-31 16:51:59 --> Total execution time: 0.0813
INFO - 2023-08-31 16:52:01 --> Config Class Initialized
INFO - 2023-08-31 16:52:01 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:52:01 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:52:01 --> Utf8 Class Initialized
INFO - 2023-08-31 16:52:01 --> URI Class Initialized
INFO - 2023-08-31 16:52:01 --> Router Class Initialized
INFO - 2023-08-31 16:52:01 --> Output Class Initialized
INFO - 2023-08-31 16:52:01 --> Security Class Initialized
DEBUG - 2023-08-31 16:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:52:01 --> Input Class Initialized
INFO - 2023-08-31 16:52:01 --> Language Class Initialized
INFO - 2023-08-31 16:52:01 --> Loader Class Initialized
INFO - 2023-08-31 16:52:01 --> Helper loaded: url_helper
INFO - 2023-08-31 16:52:01 --> Helper loaded: file_helper
INFO - 2023-08-31 16:52:01 --> Database Driver Class Initialized
INFO - 2023-08-31 16:52:01 --> Email Class Initialized
DEBUG - 2023-08-31 16:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:52:01 --> Controller Class Initialized
INFO - 2023-08-31 16:52:01 --> Model "Services_model" initialized
INFO - 2023-08-31 16:52:01 --> Helper loaded: form_helper
INFO - 2023-08-31 16:52:01 --> Form Validation Class Initialized
INFO - 2023-08-31 16:52:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 16:52:01 --> Final output sent to browser
DEBUG - 2023-08-31 16:52:01 --> Total execution time: 0.0781
INFO - 2023-08-31 16:52:02 --> Config Class Initialized
INFO - 2023-08-31 16:52:02 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:52:02 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:52:02 --> Utf8 Class Initialized
INFO - 2023-08-31 16:52:02 --> URI Class Initialized
INFO - 2023-08-31 16:52:02 --> Router Class Initialized
INFO - 2023-08-31 16:52:02 --> Output Class Initialized
INFO - 2023-08-31 16:52:02 --> Security Class Initialized
DEBUG - 2023-08-31 16:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:52:02 --> Input Class Initialized
INFO - 2023-08-31 16:52:02 --> Language Class Initialized
ERROR - 2023-08-31 16:52:02 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-31 16:52:04 --> Config Class Initialized
INFO - 2023-08-31 16:52:04 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:52:04 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:52:04 --> Utf8 Class Initialized
INFO - 2023-08-31 16:52:04 --> URI Class Initialized
INFO - 2023-08-31 16:52:04 --> Router Class Initialized
INFO - 2023-08-31 16:52:04 --> Output Class Initialized
INFO - 2023-08-31 16:52:04 --> Security Class Initialized
DEBUG - 2023-08-31 16:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:52:04 --> Input Class Initialized
INFO - 2023-08-31 16:52:04 --> Language Class Initialized
INFO - 2023-08-31 16:52:04 --> Loader Class Initialized
INFO - 2023-08-31 16:52:04 --> Helper loaded: url_helper
INFO - 2023-08-31 16:52:04 --> Helper loaded: file_helper
INFO - 2023-08-31 16:52:04 --> Database Driver Class Initialized
INFO - 2023-08-31 16:52:04 --> Email Class Initialized
DEBUG - 2023-08-31 16:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:52:04 --> Controller Class Initialized
INFO - 2023-08-31 16:52:04 --> Model "Services_model" initialized
INFO - 2023-08-31 16:52:04 --> Helper loaded: form_helper
INFO - 2023-08-31 16:52:04 --> Form Validation Class Initialized
INFO - 2023-08-31 16:52:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 16:52:04 --> Final output sent to browser
DEBUG - 2023-08-31 16:52:04 --> Total execution time: 0.0487
INFO - 2023-08-31 16:52:04 --> Config Class Initialized
INFO - 2023-08-31 16:52:04 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:52:04 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:52:04 --> Utf8 Class Initialized
INFO - 2023-08-31 16:52:04 --> URI Class Initialized
INFO - 2023-08-31 16:52:04 --> Router Class Initialized
INFO - 2023-08-31 16:52:04 --> Output Class Initialized
INFO - 2023-08-31 16:52:04 --> Security Class Initialized
DEBUG - 2023-08-31 16:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:52:04 --> Input Class Initialized
INFO - 2023-08-31 16:52:04 --> Language Class Initialized
ERROR - 2023-08-31 16:52:04 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-31 16:53:45 --> Config Class Initialized
INFO - 2023-08-31 16:53:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:53:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:53:45 --> Utf8 Class Initialized
INFO - 2023-08-31 16:53:45 --> URI Class Initialized
INFO - 2023-08-31 16:53:45 --> Router Class Initialized
INFO - 2023-08-31 16:53:45 --> Output Class Initialized
INFO - 2023-08-31 16:53:45 --> Security Class Initialized
DEBUG - 2023-08-31 16:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:53:45 --> Input Class Initialized
INFO - 2023-08-31 16:53:45 --> Language Class Initialized
INFO - 2023-08-31 16:53:45 --> Loader Class Initialized
INFO - 2023-08-31 16:53:45 --> Helper loaded: url_helper
INFO - 2023-08-31 16:53:45 --> Helper loaded: file_helper
INFO - 2023-08-31 16:53:45 --> Database Driver Class Initialized
INFO - 2023-08-31 16:53:45 --> Email Class Initialized
DEBUG - 2023-08-31 16:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:53:45 --> Controller Class Initialized
INFO - 2023-08-31 16:53:45 --> Model "Services_model" initialized
INFO - 2023-08-31 16:53:45 --> Helper loaded: form_helper
INFO - 2023-08-31 16:53:45 --> Form Validation Class Initialized
INFO - 2023-08-31 16:53:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-31 16:53:45 --> Query error: Column 'banner_text' cannot be null - Invalid query: INSERT INTO `services` (`name`, `description`, `description_new`, `status`, `image`, `banner_image`, `banner_text`, `module_name_1`, `module_quote_1`, `module_name_2`, `module_quote_2`, `module_name_3`, `module_quote_3`, `icon`, `created_at`, `created_by`) VALUES ('name', '<p>sss</p>', 'sdsd', '1', '/assets/images/services/1693493625SAMPLE.jpg', '/assets/images/banner_image/1693493625SAMPLE.jpg', NULL, 'jhgjh', 'hhghj', 'ggjg', 'gg', NULL, 'gjgjg', '/assets/images/service_icon/1693493625SAMPLE.jpg', '2023-08-31 16:53:45', '2')
INFO - 2023-08-31 16:53:45 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-31 16:54:11 --> Config Class Initialized
INFO - 2023-08-31 16:54:11 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:54:11 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:54:11 --> Utf8 Class Initialized
INFO - 2023-08-31 16:54:11 --> URI Class Initialized
INFO - 2023-08-31 16:54:11 --> Router Class Initialized
INFO - 2023-08-31 16:54:11 --> Output Class Initialized
INFO - 2023-08-31 16:54:11 --> Security Class Initialized
DEBUG - 2023-08-31 16:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:54:11 --> Input Class Initialized
INFO - 2023-08-31 16:54:11 --> Language Class Initialized
INFO - 2023-08-31 16:54:11 --> Loader Class Initialized
INFO - 2023-08-31 16:54:11 --> Helper loaded: url_helper
INFO - 2023-08-31 16:54:11 --> Helper loaded: file_helper
INFO - 2023-08-31 16:54:11 --> Database Driver Class Initialized
INFO - 2023-08-31 16:54:11 --> Email Class Initialized
DEBUG - 2023-08-31 16:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:54:11 --> Controller Class Initialized
INFO - 2023-08-31 16:54:12 --> Model "Services_model" initialized
INFO - 2023-08-31 16:54:12 --> Helper loaded: form_helper
INFO - 2023-08-31 16:54:12 --> Form Validation Class Initialized
INFO - 2023-08-31 16:54:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 16:54:12 --> Final output sent to browser
DEBUG - 2023-08-31 16:54:12 --> Total execution time: 0.9227
INFO - 2023-08-31 16:54:45 --> Config Class Initialized
INFO - 2023-08-31 16:54:45 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:54:45 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:54:45 --> Utf8 Class Initialized
INFO - 2023-08-31 16:54:45 --> URI Class Initialized
INFO - 2023-08-31 16:54:45 --> Router Class Initialized
INFO - 2023-08-31 16:54:45 --> Output Class Initialized
INFO - 2023-08-31 16:54:45 --> Security Class Initialized
DEBUG - 2023-08-31 16:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:54:46 --> Input Class Initialized
INFO - 2023-08-31 16:54:46 --> Language Class Initialized
INFO - 2023-08-31 16:54:46 --> Loader Class Initialized
INFO - 2023-08-31 16:54:46 --> Helper loaded: url_helper
INFO - 2023-08-31 16:54:46 --> Helper loaded: file_helper
INFO - 2023-08-31 16:54:46 --> Database Driver Class Initialized
INFO - 2023-08-31 16:54:46 --> Email Class Initialized
DEBUG - 2023-08-31 16:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:54:46 --> Controller Class Initialized
INFO - 2023-08-31 16:54:46 --> Model "Services_model" initialized
INFO - 2023-08-31 16:54:46 --> Helper loaded: form_helper
INFO - 2023-08-31 16:54:46 --> Form Validation Class Initialized
INFO - 2023-08-31 16:54:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 16:54:46 --> Final output sent to browser
DEBUG - 2023-08-31 16:54:46 --> Total execution time: 1.0081
INFO - 2023-08-31 16:54:48 --> Config Class Initialized
INFO - 2023-08-31 16:54:48 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:54:48 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:54:48 --> Utf8 Class Initialized
INFO - 2023-08-31 16:54:48 --> URI Class Initialized
INFO - 2023-08-31 16:54:48 --> Router Class Initialized
INFO - 2023-08-31 16:54:48 --> Output Class Initialized
INFO - 2023-08-31 16:54:48 --> Security Class Initialized
DEBUG - 2023-08-31 16:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:54:48 --> Input Class Initialized
INFO - 2023-08-31 16:54:48 --> Language Class Initialized
ERROR - 2023-08-31 16:54:48 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-31 16:56:24 --> Config Class Initialized
INFO - 2023-08-31 16:56:24 --> Hooks Class Initialized
DEBUG - 2023-08-31 16:56:24 --> UTF-8 Support Enabled
INFO - 2023-08-31 16:56:24 --> Utf8 Class Initialized
INFO - 2023-08-31 16:56:24 --> URI Class Initialized
INFO - 2023-08-31 16:56:25 --> Router Class Initialized
INFO - 2023-08-31 16:56:25 --> Output Class Initialized
INFO - 2023-08-31 16:56:25 --> Security Class Initialized
DEBUG - 2023-08-31 16:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 16:56:25 --> Input Class Initialized
INFO - 2023-08-31 16:56:25 --> Language Class Initialized
INFO - 2023-08-31 16:56:25 --> Loader Class Initialized
INFO - 2023-08-31 16:56:25 --> Helper loaded: url_helper
INFO - 2023-08-31 16:56:25 --> Helper loaded: file_helper
INFO - 2023-08-31 16:56:25 --> Database Driver Class Initialized
INFO - 2023-08-31 16:56:25 --> Email Class Initialized
DEBUG - 2023-08-31 16:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 16:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 16:56:25 --> Controller Class Initialized
INFO - 2023-08-31 16:56:25 --> Model "Services_model" initialized
INFO - 2023-08-31 16:56:25 --> Helper loaded: form_helper
INFO - 2023-08-31 16:56:25 --> Form Validation Class Initialized
INFO - 2023-08-31 16:56:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 16:56:26 --> Final output sent to browser
DEBUG - 2023-08-31 16:56:26 --> Total execution time: 1.1455
INFO - 2023-08-31 17:01:07 --> Config Class Initialized
INFO - 2023-08-31 17:01:07 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:01:07 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:01:07 --> Utf8 Class Initialized
INFO - 2023-08-31 17:01:07 --> URI Class Initialized
INFO - 2023-08-31 17:01:07 --> Router Class Initialized
INFO - 2023-08-31 17:01:07 --> Output Class Initialized
INFO - 2023-08-31 17:01:07 --> Security Class Initialized
DEBUG - 2023-08-31 17:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:01:07 --> Input Class Initialized
INFO - 2023-08-31 17:01:07 --> Language Class Initialized
INFO - 2023-08-31 17:01:07 --> Loader Class Initialized
INFO - 2023-08-31 17:01:07 --> Helper loaded: url_helper
INFO - 2023-08-31 17:01:07 --> Helper loaded: file_helper
INFO - 2023-08-31 17:01:07 --> Database Driver Class Initialized
INFO - 2023-08-31 17:01:07 --> Email Class Initialized
DEBUG - 2023-08-31 17:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:01:08 --> Controller Class Initialized
INFO - 2023-08-31 17:01:08 --> Model "Services_model" initialized
INFO - 2023-08-31 17:01:08 --> Helper loaded: form_helper
INFO - 2023-08-31 17:01:08 --> Form Validation Class Initialized
INFO - 2023-08-31 17:01:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 17:01:08 --> Final output sent to browser
DEBUG - 2023-08-31 17:01:08 --> Total execution time: 1.0231
INFO - 2023-08-31 17:01:09 --> Config Class Initialized
INFO - 2023-08-31 17:01:10 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:01:10 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:01:10 --> Utf8 Class Initialized
INFO - 2023-08-31 17:01:10 --> URI Class Initialized
INFO - 2023-08-31 17:01:10 --> Router Class Initialized
INFO - 2023-08-31 17:01:10 --> Output Class Initialized
INFO - 2023-08-31 17:01:10 --> Security Class Initialized
DEBUG - 2023-08-31 17:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:01:10 --> Input Class Initialized
INFO - 2023-08-31 17:01:10 --> Language Class Initialized
ERROR - 2023-08-31 17:01:10 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-31 17:01:51 --> Config Class Initialized
INFO - 2023-08-31 17:01:51 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:01:51 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:01:51 --> Utf8 Class Initialized
INFO - 2023-08-31 17:01:51 --> URI Class Initialized
INFO - 2023-08-31 17:01:51 --> Router Class Initialized
INFO - 2023-08-31 17:01:51 --> Output Class Initialized
INFO - 2023-08-31 17:01:51 --> Security Class Initialized
DEBUG - 2023-08-31 17:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:01:51 --> Input Class Initialized
INFO - 2023-08-31 17:01:51 --> Language Class Initialized
INFO - 2023-08-31 17:01:51 --> Loader Class Initialized
INFO - 2023-08-31 17:01:51 --> Helper loaded: url_helper
INFO - 2023-08-31 17:01:51 --> Helper loaded: file_helper
INFO - 2023-08-31 17:01:51 --> Database Driver Class Initialized
INFO - 2023-08-31 17:01:51 --> Email Class Initialized
DEBUG - 2023-08-31 17:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:01:52 --> Controller Class Initialized
INFO - 2023-08-31 17:01:52 --> Model "Services_model" initialized
INFO - 2023-08-31 17:01:52 --> Helper loaded: form_helper
INFO - 2023-08-31 17:01:52 --> Form Validation Class Initialized
INFO - 2023-08-31 17:01:52 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-31 17:01:52 --> Query error: Column 'banner_text' cannot be null - Invalid query: INSERT INTO `services` (`name`, `description`, `description_new`, `status`, `image`, `banner_image`, `banner_text`, `module_name_1`, `module_quote_1`, `module_name_2`, `module_quote_2`, `module_name_3`, `module_quote_3`, `icon`, `created_at`, `created_by`) VALUES ('sdfsdfs', '<p>sdfsdf</p>', 'sdfsdf', '1', '/assets/images/services/1693494112SAMPLE.jpg', '/assets/images/banner_image/1693494112banner1.jpg', NULL, '', '', '', '', NULL, '', '/assets/images/service_icon/1693494112SAMPLE.jpg', '2023-08-31 17:01:52', '2')
INFO - 2023-08-31 17:01:52 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-31 17:02:15 --> Config Class Initialized
INFO - 2023-08-31 17:02:15 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:02:15 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:02:15 --> Utf8 Class Initialized
INFO - 2023-08-31 17:02:15 --> URI Class Initialized
INFO - 2023-08-31 17:02:16 --> Router Class Initialized
INFO - 2023-08-31 17:02:16 --> Output Class Initialized
INFO - 2023-08-31 17:02:16 --> Security Class Initialized
DEBUG - 2023-08-31 17:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:02:16 --> Input Class Initialized
INFO - 2023-08-31 17:02:16 --> Language Class Initialized
INFO - 2023-08-31 17:02:16 --> Loader Class Initialized
INFO - 2023-08-31 17:02:16 --> Helper loaded: url_helper
INFO - 2023-08-31 17:02:16 --> Helper loaded: file_helper
INFO - 2023-08-31 17:02:16 --> Database Driver Class Initialized
INFO - 2023-08-31 17:02:16 --> Email Class Initialized
DEBUG - 2023-08-31 17:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:02:16 --> Controller Class Initialized
INFO - 2023-08-31 17:02:16 --> Model "Services_model" initialized
INFO - 2023-08-31 17:02:16 --> Helper loaded: form_helper
INFO - 2023-08-31 17:02:16 --> Form Validation Class Initialized
INFO - 2023-08-31 17:02:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 17:02:16 --> Final output sent to browser
DEBUG - 2023-08-31 17:02:16 --> Total execution time: 0.5992
INFO - 2023-08-31 17:02:44 --> Config Class Initialized
INFO - 2023-08-31 17:02:44 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:02:44 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:02:44 --> Utf8 Class Initialized
INFO - 2023-08-31 17:02:44 --> URI Class Initialized
INFO - 2023-08-31 17:02:44 --> Router Class Initialized
INFO - 2023-08-31 17:02:44 --> Output Class Initialized
INFO - 2023-08-31 17:02:44 --> Security Class Initialized
DEBUG - 2023-08-31 17:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:02:44 --> Input Class Initialized
INFO - 2023-08-31 17:02:44 --> Language Class Initialized
INFO - 2023-08-31 17:02:44 --> Loader Class Initialized
INFO - 2023-08-31 17:02:44 --> Helper loaded: url_helper
INFO - 2023-08-31 17:02:44 --> Helper loaded: file_helper
INFO - 2023-08-31 17:02:44 --> Database Driver Class Initialized
INFO - 2023-08-31 17:02:44 --> Email Class Initialized
DEBUG - 2023-08-31 17:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:02:44 --> Controller Class Initialized
INFO - 2023-08-31 17:02:44 --> Model "Services_model" initialized
INFO - 2023-08-31 17:02:44 --> Helper loaded: form_helper
INFO - 2023-08-31 17:02:44 --> Form Validation Class Initialized
INFO - 2023-08-31 17:02:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 17:02:44 --> Final output sent to browser
DEBUG - 2023-08-31 17:02:44 --> Total execution time: 0.6281
INFO - 2023-08-31 17:02:46 --> Config Class Initialized
INFO - 2023-08-31 17:02:46 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:02:46 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:02:46 --> Utf8 Class Initialized
INFO - 2023-08-31 17:02:46 --> URI Class Initialized
INFO - 2023-08-31 17:02:46 --> Router Class Initialized
INFO - 2023-08-31 17:02:46 --> Output Class Initialized
INFO - 2023-08-31 17:02:46 --> Security Class Initialized
DEBUG - 2023-08-31 17:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:02:46 --> Input Class Initialized
INFO - 2023-08-31 17:02:46 --> Language Class Initialized
ERROR - 2023-08-31 17:02:46 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-31 17:03:24 --> Config Class Initialized
INFO - 2023-08-31 17:03:24 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:03:24 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:03:24 --> Utf8 Class Initialized
INFO - 2023-08-31 17:03:24 --> URI Class Initialized
INFO - 2023-08-31 17:03:24 --> Router Class Initialized
INFO - 2023-08-31 17:03:24 --> Output Class Initialized
INFO - 2023-08-31 17:03:24 --> Security Class Initialized
DEBUG - 2023-08-31 17:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:03:24 --> Input Class Initialized
INFO - 2023-08-31 17:03:24 --> Language Class Initialized
INFO - 2023-08-31 17:03:24 --> Loader Class Initialized
INFO - 2023-08-31 17:03:24 --> Helper loaded: url_helper
INFO - 2023-08-31 17:03:24 --> Helper loaded: file_helper
INFO - 2023-08-31 17:03:24 --> Database Driver Class Initialized
INFO - 2023-08-31 17:03:24 --> Email Class Initialized
DEBUG - 2023-08-31 17:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:03:24 --> Controller Class Initialized
INFO - 2023-08-31 17:03:24 --> Model "Services_model" initialized
INFO - 2023-08-31 17:03:24 --> Helper loaded: form_helper
INFO - 2023-08-31 17:03:24 --> Form Validation Class Initialized
INFO - 2023-08-31 17:03:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-31 17:03:24 --> Query error: Column 'banner_text' cannot be null - Invalid query: INSERT INTO `services` (`name`, `description`, `description_new`, `status`, `image`, `banner_image`, `banner_text`, `module_name_1`, `module_quote_1`, `module_name_2`, `module_quote_2`, `module_name_3`, `module_quote_3`, `icon`, `created_at`, `created_by`) VALUES ('sdfsdf', '<p>sdfsdf</p>', 'sffgdfgdfg', '1', '/assets/images/services/1693494204banner1.jpg', '/assets/images/banner_image/1693494204banner1.jpg', NULL, 'jhgjg', 'hhkjh', 'gjgj', 'hgjgj', NULL, 'ghjgj', '/assets/images/service_icon/1693494204banner1.jpg', '2023-08-31 17:03:24', '2')
INFO - 2023-08-31 17:03:24 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-31 17:03:52 --> Config Class Initialized
INFO - 2023-08-31 17:03:52 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:03:52 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:03:52 --> Utf8 Class Initialized
INFO - 2023-08-31 17:03:52 --> URI Class Initialized
INFO - 2023-08-31 17:03:52 --> Router Class Initialized
INFO - 2023-08-31 17:03:52 --> Output Class Initialized
INFO - 2023-08-31 17:03:52 --> Security Class Initialized
DEBUG - 2023-08-31 17:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:03:52 --> Input Class Initialized
INFO - 2023-08-31 17:03:52 --> Language Class Initialized
INFO - 2023-08-31 17:03:52 --> Loader Class Initialized
INFO - 2023-08-31 17:03:52 --> Helper loaded: url_helper
INFO - 2023-08-31 17:03:52 --> Helper loaded: file_helper
INFO - 2023-08-31 17:03:52 --> Database Driver Class Initialized
INFO - 2023-08-31 17:03:52 --> Email Class Initialized
DEBUG - 2023-08-31 17:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:03:52 --> Controller Class Initialized
INFO - 2023-08-31 17:03:52 --> Model "Services_model" initialized
INFO - 2023-08-31 17:03:52 --> Helper loaded: form_helper
INFO - 2023-08-31 17:03:52 --> Form Validation Class Initialized
INFO - 2023-08-31 17:03:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 17:03:52 --> Final output sent to browser
DEBUG - 2023-08-31 17:03:52 --> Total execution time: 0.3163
INFO - 2023-08-31 17:03:54 --> Config Class Initialized
INFO - 2023-08-31 17:03:54 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:03:54 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:03:54 --> Utf8 Class Initialized
INFO - 2023-08-31 17:03:54 --> URI Class Initialized
INFO - 2023-08-31 17:03:54 --> Router Class Initialized
INFO - 2023-08-31 17:03:54 --> Output Class Initialized
INFO - 2023-08-31 17:03:54 --> Security Class Initialized
DEBUG - 2023-08-31 17:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:03:54 --> Input Class Initialized
INFO - 2023-08-31 17:03:54 --> Language Class Initialized
INFO - 2023-08-31 17:03:54 --> Loader Class Initialized
INFO - 2023-08-31 17:03:54 --> Helper loaded: url_helper
INFO - 2023-08-31 17:03:54 --> Helper loaded: file_helper
INFO - 2023-08-31 17:03:54 --> Database Driver Class Initialized
INFO - 2023-08-31 17:03:54 --> Email Class Initialized
DEBUG - 2023-08-31 17:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:03:54 --> Controller Class Initialized
INFO - 2023-08-31 17:03:54 --> Model "Services_model" initialized
INFO - 2023-08-31 17:03:54 --> Helper loaded: form_helper
INFO - 2023-08-31 17:03:54 --> Form Validation Class Initialized
INFO - 2023-08-31 17:03:54 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-31 17:03:54 --> Final output sent to browser
DEBUG - 2023-08-31 17:03:54 --> Total execution time: 0.0462
INFO - 2023-08-31 17:03:55 --> Config Class Initialized
INFO - 2023-08-31 17:03:55 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:03:55 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:03:55 --> Utf8 Class Initialized
INFO - 2023-08-31 17:03:55 --> URI Class Initialized
INFO - 2023-08-31 17:03:55 --> Router Class Initialized
INFO - 2023-08-31 17:03:55 --> Output Class Initialized
INFO - 2023-08-31 17:03:55 --> Security Class Initialized
DEBUG - 2023-08-31 17:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:03:55 --> Input Class Initialized
INFO - 2023-08-31 17:03:55 --> Language Class Initialized
ERROR - 2023-08-31 17:03:55 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-31 17:04:21 --> Config Class Initialized
INFO - 2023-08-31 17:04:21 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:04:21 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:04:21 --> Utf8 Class Initialized
INFO - 2023-08-31 17:04:21 --> URI Class Initialized
INFO - 2023-08-31 17:04:21 --> Router Class Initialized
INFO - 2023-08-31 17:04:21 --> Output Class Initialized
INFO - 2023-08-31 17:04:21 --> Security Class Initialized
DEBUG - 2023-08-31 17:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:04:21 --> Input Class Initialized
INFO - 2023-08-31 17:04:21 --> Language Class Initialized
INFO - 2023-08-31 17:04:21 --> Loader Class Initialized
INFO - 2023-08-31 17:04:21 --> Helper loaded: url_helper
INFO - 2023-08-31 17:04:21 --> Helper loaded: file_helper
INFO - 2023-08-31 17:04:21 --> Database Driver Class Initialized
INFO - 2023-08-31 17:04:21 --> Email Class Initialized
DEBUG - 2023-08-31 17:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:04:21 --> Controller Class Initialized
INFO - 2023-08-31 17:04:21 --> Model "Services_model" initialized
INFO - 2023-08-31 17:04:21 --> Helper loaded: form_helper
INFO - 2023-08-31 17:04:21 --> Form Validation Class Initialized
INFO - 2023-08-31 17:04:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-31 17:04:21 --> Config Class Initialized
INFO - 2023-08-31 17:04:21 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:04:21 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:04:21 --> Utf8 Class Initialized
INFO - 2023-08-31 17:04:21 --> URI Class Initialized
INFO - 2023-08-31 17:04:21 --> Router Class Initialized
INFO - 2023-08-31 17:04:21 --> Output Class Initialized
INFO - 2023-08-31 17:04:21 --> Security Class Initialized
DEBUG - 2023-08-31 17:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:04:21 --> Input Class Initialized
INFO - 2023-08-31 17:04:21 --> Language Class Initialized
INFO - 2023-08-31 17:04:21 --> Loader Class Initialized
INFO - 2023-08-31 17:04:21 --> Helper loaded: url_helper
INFO - 2023-08-31 17:04:21 --> Helper loaded: file_helper
INFO - 2023-08-31 17:04:21 --> Database Driver Class Initialized
INFO - 2023-08-31 17:04:21 --> Email Class Initialized
DEBUG - 2023-08-31 17:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:04:21 --> Controller Class Initialized
INFO - 2023-08-31 17:04:21 --> Model "Services_model" initialized
INFO - 2023-08-31 17:04:21 --> Helper loaded: form_helper
INFO - 2023-08-31 17:04:21 --> Form Validation Class Initialized
INFO - 2023-08-31 17:04:21 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 17:04:21 --> Final output sent to browser
DEBUG - 2023-08-31 17:04:21 --> Total execution time: 0.0875
INFO - 2023-08-31 17:04:22 --> Config Class Initialized
INFO - 2023-08-31 17:04:22 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:04:22 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:04:22 --> Utf8 Class Initialized
INFO - 2023-08-31 17:04:22 --> URI Class Initialized
INFO - 2023-08-31 17:04:22 --> Router Class Initialized
INFO - 2023-08-31 17:04:22 --> Output Class Initialized
INFO - 2023-08-31 17:04:22 --> Security Class Initialized
DEBUG - 2023-08-31 17:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:04:22 --> Input Class Initialized
INFO - 2023-08-31 17:04:22 --> Language Class Initialized
ERROR - 2023-08-31 17:04:22 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-31 17:04:24 --> Config Class Initialized
INFO - 2023-08-31 17:04:24 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:04:24 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:04:24 --> Utf8 Class Initialized
INFO - 2023-08-31 17:04:24 --> URI Class Initialized
INFO - 2023-08-31 17:04:24 --> Router Class Initialized
INFO - 2023-08-31 17:04:24 --> Output Class Initialized
INFO - 2023-08-31 17:04:24 --> Security Class Initialized
DEBUG - 2023-08-31 17:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:04:24 --> Input Class Initialized
INFO - 2023-08-31 17:04:24 --> Language Class Initialized
INFO - 2023-08-31 17:04:24 --> Loader Class Initialized
INFO - 2023-08-31 17:04:24 --> Helper loaded: url_helper
INFO - 2023-08-31 17:04:24 --> Helper loaded: file_helper
INFO - 2023-08-31 17:04:24 --> Database Driver Class Initialized
INFO - 2023-08-31 17:04:24 --> Email Class Initialized
DEBUG - 2023-08-31 17:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:04:24 --> Controller Class Initialized
INFO - 2023-08-31 17:04:24 --> Model "Services_model" initialized
INFO - 2023-08-31 17:04:24 --> Helper loaded: form_helper
INFO - 2023-08-31 17:04:24 --> Form Validation Class Initialized
INFO - 2023-08-31 17:04:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 17:04:24 --> Final output sent to browser
DEBUG - 2023-08-31 17:04:24 --> Total execution time: 0.0866
INFO - 2023-08-31 17:04:24 --> Config Class Initialized
INFO - 2023-08-31 17:04:24 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:04:24 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:04:24 --> Utf8 Class Initialized
INFO - 2023-08-31 17:04:24 --> URI Class Initialized
INFO - 2023-08-31 17:04:24 --> Router Class Initialized
INFO - 2023-08-31 17:04:24 --> Output Class Initialized
INFO - 2023-08-31 17:04:24 --> Security Class Initialized
DEBUG - 2023-08-31 17:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:04:24 --> Input Class Initialized
INFO - 2023-08-31 17:04:24 --> Language Class Initialized
INFO - 2023-08-31 17:04:24 --> Loader Class Initialized
INFO - 2023-08-31 17:04:24 --> Helper loaded: url_helper
INFO - 2023-08-31 17:04:24 --> Helper loaded: file_helper
INFO - 2023-08-31 17:04:24 --> Database Driver Class Initialized
INFO - 2023-08-31 17:04:24 --> Email Class Initialized
DEBUG - 2023-08-31 17:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:04:24 --> Controller Class Initialized
INFO - 2023-08-31 17:04:24 --> Model "Services_model" initialized
INFO - 2023-08-31 17:04:24 --> Helper loaded: form_helper
INFO - 2023-08-31 17:04:25 --> Form Validation Class Initialized
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 143
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 153
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 166
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 176
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 189
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 199
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 209
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 211
ERROR - 2023-08-31 17:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 213
INFO - 2023-08-31 17:04:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 17:04:25 --> Final output sent to browser
DEBUG - 2023-08-31 17:04:25 --> Total execution time: 0.0758
INFO - 2023-08-31 17:06:23 --> Config Class Initialized
INFO - 2023-08-31 17:06:23 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:06:23 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:06:23 --> Utf8 Class Initialized
INFO - 2023-08-31 17:06:23 --> URI Class Initialized
INFO - 2023-08-31 17:06:23 --> Router Class Initialized
INFO - 2023-08-31 17:06:23 --> Output Class Initialized
INFO - 2023-08-31 17:06:23 --> Security Class Initialized
DEBUG - 2023-08-31 17:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:06:23 --> Input Class Initialized
INFO - 2023-08-31 17:06:23 --> Language Class Initialized
INFO - 2023-08-31 17:06:23 --> Loader Class Initialized
INFO - 2023-08-31 17:06:23 --> Helper loaded: url_helper
INFO - 2023-08-31 17:06:23 --> Helper loaded: file_helper
INFO - 2023-08-31 17:06:23 --> Database Driver Class Initialized
INFO - 2023-08-31 17:06:23 --> Email Class Initialized
DEBUG - 2023-08-31 17:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:06:24 --> Controller Class Initialized
INFO - 2023-08-31 17:06:24 --> Model "Services_model" initialized
INFO - 2023-08-31 17:06:24 --> Helper loaded: form_helper
INFO - 2023-08-31 17:06:24 --> Form Validation Class Initialized
INFO - 2023-08-31 17:06:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 17:06:24 --> Final output sent to browser
DEBUG - 2023-08-31 17:06:24 --> Total execution time: 1.1382
INFO - 2023-08-31 17:06:25 --> Config Class Initialized
INFO - 2023-08-31 17:06:25 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:06:25 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:06:25 --> Utf8 Class Initialized
INFO - 2023-08-31 17:06:25 --> URI Class Initialized
INFO - 2023-08-31 17:06:25 --> Router Class Initialized
INFO - 2023-08-31 17:06:25 --> Output Class Initialized
INFO - 2023-08-31 17:06:25 --> Security Class Initialized
DEBUG - 2023-08-31 17:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:06:25 --> Input Class Initialized
INFO - 2023-08-31 17:06:25 --> Language Class Initialized
INFO - 2023-08-31 17:06:25 --> Loader Class Initialized
INFO - 2023-08-31 17:06:25 --> Helper loaded: url_helper
INFO - 2023-08-31 17:06:25 --> Helper loaded: file_helper
INFO - 2023-08-31 17:06:25 --> Database Driver Class Initialized
INFO - 2023-08-31 17:06:25 --> Email Class Initialized
DEBUG - 2023-08-31 17:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:06:25 --> Controller Class Initialized
INFO - 2023-08-31 17:06:25 --> Model "Services_model" initialized
INFO - 2023-08-31 17:06:25 --> Helper loaded: form_helper
INFO - 2023-08-31 17:06:25 --> Form Validation Class Initialized
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 119
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 131
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 144
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 167
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 190
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 212
ERROR - 2023-08-31 17:06:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 214
INFO - 2023-08-31 17:06:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 17:06:25 --> Final output sent to browser
DEBUG - 2023-08-31 17:06:25 --> Total execution time: 0.0637
INFO - 2023-08-31 17:07:07 --> Config Class Initialized
INFO - 2023-08-31 17:07:07 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:07:07 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:07:07 --> Utf8 Class Initialized
INFO - 2023-08-31 17:07:07 --> URI Class Initialized
INFO - 2023-08-31 17:07:07 --> Router Class Initialized
INFO - 2023-08-31 17:07:07 --> Output Class Initialized
INFO - 2023-08-31 17:07:07 --> Security Class Initialized
DEBUG - 2023-08-31 17:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:07:07 --> Input Class Initialized
INFO - 2023-08-31 17:07:07 --> Language Class Initialized
INFO - 2023-08-31 17:07:07 --> Loader Class Initialized
INFO - 2023-08-31 17:07:07 --> Helper loaded: url_helper
INFO - 2023-08-31 17:07:07 --> Helper loaded: file_helper
INFO - 2023-08-31 17:07:07 --> Database Driver Class Initialized
INFO - 2023-08-31 17:07:07 --> Email Class Initialized
DEBUG - 2023-08-31 17:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:07:07 --> Controller Class Initialized
INFO - 2023-08-31 17:07:07 --> Model "Services_model" initialized
INFO - 2023-08-31 17:07:08 --> Helper loaded: form_helper
INFO - 2023-08-31 17:07:08 --> Form Validation Class Initialized
INFO - 2023-08-31 17:07:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 17:07:08 --> Final output sent to browser
DEBUG - 2023-08-31 17:07:08 --> Total execution time: 0.7698
INFO - 2023-08-31 17:07:09 --> Config Class Initialized
INFO - 2023-08-31 17:07:09 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:07:09 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:07:09 --> Utf8 Class Initialized
INFO - 2023-08-31 17:07:09 --> URI Class Initialized
INFO - 2023-08-31 17:07:09 --> Router Class Initialized
INFO - 2023-08-31 17:07:09 --> Output Class Initialized
INFO - 2023-08-31 17:07:09 --> Security Class Initialized
DEBUG - 2023-08-31 17:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:07:09 --> Input Class Initialized
INFO - 2023-08-31 17:07:09 --> Language Class Initialized
INFO - 2023-08-31 17:07:09 --> Loader Class Initialized
INFO - 2023-08-31 17:07:09 --> Helper loaded: url_helper
INFO - 2023-08-31 17:07:09 --> Helper loaded: file_helper
INFO - 2023-08-31 17:07:09 --> Database Driver Class Initialized
INFO - 2023-08-31 17:07:09 --> Email Class Initialized
DEBUG - 2023-08-31 17:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:07:09 --> Controller Class Initialized
INFO - 2023-08-31 17:07:09 --> Model "Services_model" initialized
INFO - 2023-08-31 17:07:09 --> Helper loaded: form_helper
INFO - 2023-08-31 17:07:09 --> Form Validation Class Initialized
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-08-31 17:07:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-08-31 17:07:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 17:07:09 --> Final output sent to browser
DEBUG - 2023-08-31 17:07:09 --> Total execution time: 0.0546
INFO - 2023-08-31 17:08:23 --> Config Class Initialized
INFO - 2023-08-31 17:08:23 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:08:23 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:08:23 --> Utf8 Class Initialized
INFO - 2023-08-31 17:08:23 --> URI Class Initialized
INFO - 2023-08-31 17:08:23 --> Router Class Initialized
INFO - 2023-08-31 17:08:23 --> Output Class Initialized
INFO - 2023-08-31 17:08:23 --> Security Class Initialized
DEBUG - 2023-08-31 17:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:08:23 --> Input Class Initialized
INFO - 2023-08-31 17:08:23 --> Language Class Initialized
INFO - 2023-08-31 17:08:23 --> Loader Class Initialized
INFO - 2023-08-31 17:08:23 --> Helper loaded: url_helper
INFO - 2023-08-31 17:08:23 --> Helper loaded: file_helper
INFO - 2023-08-31 17:08:23 --> Database Driver Class Initialized
INFO - 2023-08-31 17:08:23 --> Email Class Initialized
DEBUG - 2023-08-31 17:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:08:23 --> Controller Class Initialized
INFO - 2023-08-31 17:08:24 --> Model "Services_model" initialized
INFO - 2023-08-31 17:08:24 --> Helper loaded: form_helper
INFO - 2023-08-31 17:08:24 --> Form Validation Class Initialized
INFO - 2023-08-31 17:08:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 17:08:24 --> Final output sent to browser
DEBUG - 2023-08-31 17:08:24 --> Total execution time: 0.6420
INFO - 2023-08-31 17:08:25 --> Config Class Initialized
INFO - 2023-08-31 17:08:25 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:08:25 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:08:25 --> Utf8 Class Initialized
INFO - 2023-08-31 17:08:25 --> URI Class Initialized
INFO - 2023-08-31 17:08:25 --> Router Class Initialized
INFO - 2023-08-31 17:08:25 --> Output Class Initialized
INFO - 2023-08-31 17:08:25 --> Security Class Initialized
DEBUG - 2023-08-31 17:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:08:25 --> Input Class Initialized
INFO - 2023-08-31 17:08:25 --> Language Class Initialized
INFO - 2023-08-31 17:08:25 --> Loader Class Initialized
INFO - 2023-08-31 17:08:25 --> Helper loaded: url_helper
INFO - 2023-08-31 17:08:25 --> Helper loaded: file_helper
INFO - 2023-08-31 17:08:25 --> Database Driver Class Initialized
INFO - 2023-08-31 17:08:25 --> Email Class Initialized
DEBUG - 2023-08-31 17:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:08:25 --> Controller Class Initialized
INFO - 2023-08-31 17:08:25 --> Model "Services_model" initialized
INFO - 2023-08-31 17:08:25 --> Helper loaded: form_helper
INFO - 2023-08-31 17:08:25 --> Form Validation Class Initialized
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-08-31 17:08:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-08-31 17:08:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 17:08:25 --> Final output sent to browser
DEBUG - 2023-08-31 17:08:25 --> Total execution time: 0.0612
INFO - 2023-08-31 17:09:01 --> Config Class Initialized
INFO - 2023-08-31 17:09:01 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:09:01 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:09:01 --> Utf8 Class Initialized
INFO - 2023-08-31 17:09:01 --> URI Class Initialized
INFO - 2023-08-31 17:09:01 --> Router Class Initialized
INFO - 2023-08-31 17:09:01 --> Output Class Initialized
INFO - 2023-08-31 17:09:01 --> Security Class Initialized
DEBUG - 2023-08-31 17:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:09:01 --> Input Class Initialized
INFO - 2023-08-31 17:09:01 --> Language Class Initialized
INFO - 2023-08-31 17:09:01 --> Loader Class Initialized
INFO - 2023-08-31 17:09:01 --> Helper loaded: url_helper
INFO - 2023-08-31 17:09:01 --> Helper loaded: file_helper
INFO - 2023-08-31 17:09:01 --> Database Driver Class Initialized
INFO - 2023-08-31 17:09:01 --> Email Class Initialized
DEBUG - 2023-08-31 17:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:09:01 --> Controller Class Initialized
INFO - 2023-08-31 17:09:01 --> Model "Services_model" initialized
INFO - 2023-08-31 17:09:01 --> Helper loaded: form_helper
INFO - 2023-08-31 17:09:01 --> Form Validation Class Initialized
INFO - 2023-08-31 17:09:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 17:09:01 --> Final output sent to browser
DEBUG - 2023-08-31 17:09:01 --> Total execution time: 0.1560
INFO - 2023-08-31 17:09:02 --> Config Class Initialized
INFO - 2023-08-31 17:09:02 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:09:02 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:09:02 --> Utf8 Class Initialized
INFO - 2023-08-31 17:09:02 --> URI Class Initialized
INFO - 2023-08-31 17:09:02 --> Router Class Initialized
INFO - 2023-08-31 17:09:02 --> Output Class Initialized
INFO - 2023-08-31 17:09:02 --> Security Class Initialized
DEBUG - 2023-08-31 17:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:09:02 --> Input Class Initialized
INFO - 2023-08-31 17:09:02 --> Language Class Initialized
INFO - 2023-08-31 17:09:02 --> Loader Class Initialized
INFO - 2023-08-31 17:09:02 --> Helper loaded: url_helper
INFO - 2023-08-31 17:09:02 --> Helper loaded: file_helper
INFO - 2023-08-31 17:09:02 --> Database Driver Class Initialized
INFO - 2023-08-31 17:09:02 --> Email Class Initialized
DEBUG - 2023-08-31 17:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:09:02 --> Controller Class Initialized
INFO - 2023-08-31 17:09:02 --> Model "Services_model" initialized
INFO - 2023-08-31 17:09:02 --> Helper loaded: form_helper
INFO - 2023-08-31 17:09:02 --> Form Validation Class Initialized
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-08-31 17:09:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-08-31 17:09:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 17:09:02 --> Final output sent to browser
DEBUG - 2023-08-31 17:09:02 --> Total execution time: 0.0747
INFO - 2023-08-31 17:09:05 --> Config Class Initialized
INFO - 2023-08-31 17:09:05 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:09:05 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:09:05 --> Utf8 Class Initialized
INFO - 2023-08-31 17:09:05 --> URI Class Initialized
INFO - 2023-08-31 17:09:05 --> Router Class Initialized
INFO - 2023-08-31 17:09:05 --> Output Class Initialized
INFO - 2023-08-31 17:09:05 --> Security Class Initialized
DEBUG - 2023-08-31 17:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:09:05 --> Input Class Initialized
INFO - 2023-08-31 17:09:05 --> Language Class Initialized
INFO - 2023-08-31 17:09:05 --> Loader Class Initialized
INFO - 2023-08-31 17:09:05 --> Helper loaded: url_helper
INFO - 2023-08-31 17:09:05 --> Helper loaded: file_helper
INFO - 2023-08-31 17:09:05 --> Database Driver Class Initialized
INFO - 2023-08-31 17:09:05 --> Email Class Initialized
DEBUG - 2023-08-31 17:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:09:05 --> Controller Class Initialized
INFO - 2023-08-31 17:09:05 --> Model "Services_model" initialized
INFO - 2023-08-31 17:09:05 --> Helper loaded: form_helper
INFO - 2023-08-31 17:09:05 --> Form Validation Class Initialized
INFO - 2023-08-31 17:09:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 17:09:05 --> Final output sent to browser
DEBUG - 2023-08-31 17:09:05 --> Total execution time: 0.0508
INFO - 2023-08-31 17:10:25 --> Config Class Initialized
INFO - 2023-08-31 17:10:25 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:10:25 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:10:25 --> Utf8 Class Initialized
INFO - 2023-08-31 17:10:25 --> URI Class Initialized
INFO - 2023-08-31 17:10:25 --> Router Class Initialized
INFO - 2023-08-31 17:10:25 --> Output Class Initialized
INFO - 2023-08-31 17:10:25 --> Security Class Initialized
DEBUG - 2023-08-31 17:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:10:25 --> Input Class Initialized
INFO - 2023-08-31 17:10:25 --> Language Class Initialized
INFO - 2023-08-31 17:10:25 --> Loader Class Initialized
INFO - 2023-08-31 17:10:25 --> Helper loaded: url_helper
INFO - 2023-08-31 17:10:25 --> Helper loaded: file_helper
INFO - 2023-08-31 17:10:25 --> Database Driver Class Initialized
INFO - 2023-08-31 17:10:25 --> Email Class Initialized
DEBUG - 2023-08-31 17:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:10:25 --> Controller Class Initialized
INFO - 2023-08-31 17:10:25 --> Model "Services_model" initialized
INFO - 2023-08-31 17:10:26 --> Helper loaded: form_helper
INFO - 2023-08-31 17:10:26 --> Form Validation Class Initialized
INFO - 2023-08-31 17:10:26 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 17:10:26 --> Final output sent to browser
DEBUG - 2023-08-31 17:10:26 --> Total execution time: 0.9849
INFO - 2023-08-31 17:10:26 --> Config Class Initialized
INFO - 2023-08-31 17:10:26 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:10:26 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:10:26 --> Utf8 Class Initialized
INFO - 2023-08-31 17:10:26 --> URI Class Initialized
INFO - 2023-08-31 17:10:26 --> Router Class Initialized
INFO - 2023-08-31 17:10:27 --> Output Class Initialized
INFO - 2023-08-31 17:10:27 --> Security Class Initialized
DEBUG - 2023-08-31 17:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:10:27 --> Input Class Initialized
INFO - 2023-08-31 17:10:27 --> Language Class Initialized
INFO - 2023-08-31 17:10:27 --> Loader Class Initialized
INFO - 2023-08-31 17:10:27 --> Helper loaded: url_helper
INFO - 2023-08-31 17:10:27 --> Helper loaded: file_helper
INFO - 2023-08-31 17:10:27 --> Database Driver Class Initialized
INFO - 2023-08-31 17:10:27 --> Email Class Initialized
DEBUG - 2023-08-31 17:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:10:27 --> Controller Class Initialized
INFO - 2023-08-31 17:10:27 --> Model "Services_model" initialized
INFO - 2023-08-31 17:10:27 --> Helper loaded: form_helper
INFO - 2023-08-31 17:10:27 --> Form Validation Class Initialized
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-08-31 17:10:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-08-31 17:10:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 17:10:27 --> Final output sent to browser
DEBUG - 2023-08-31 17:10:27 --> Total execution time: 0.0643
INFO - 2023-08-31 17:10:46 --> Config Class Initialized
INFO - 2023-08-31 17:10:46 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:10:46 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:10:46 --> Utf8 Class Initialized
INFO - 2023-08-31 17:10:46 --> URI Class Initialized
INFO - 2023-08-31 17:10:46 --> Router Class Initialized
INFO - 2023-08-31 17:10:46 --> Output Class Initialized
INFO - 2023-08-31 17:10:46 --> Security Class Initialized
DEBUG - 2023-08-31 17:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:10:46 --> Input Class Initialized
INFO - 2023-08-31 17:10:46 --> Language Class Initialized
INFO - 2023-08-31 17:10:46 --> Loader Class Initialized
INFO - 2023-08-31 17:10:46 --> Helper loaded: url_helper
INFO - 2023-08-31 17:10:46 --> Helper loaded: file_helper
INFO - 2023-08-31 17:10:46 --> Database Driver Class Initialized
INFO - 2023-08-31 17:10:46 --> Email Class Initialized
DEBUG - 2023-08-31 17:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:10:47 --> Controller Class Initialized
INFO - 2023-08-31 17:10:47 --> Model "Services_model" initialized
INFO - 2023-08-31 17:10:47 --> Helper loaded: form_helper
INFO - 2023-08-31 17:10:47 --> Form Validation Class Initialized
INFO - 2023-08-31 17:10:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-31 17:10:47 --> Query error: Unknown column 'banner_name' in 'field list' - Invalid query: UPDATE `services` SET `name` = 'kk1', `description` = '<p>hujh1</p><p>Description 1</p><p>uh</p>', `description_new` = NULL, `status` = '1', `image` = '/assets/images/services/1693494261male.jpg', `banner_image` = '', `banner_name` = NULL, `module_name_1` = 'h1', `module_quote_1` = 'hhh1', `module_name_2` = 'hh1', `module_quote_2` = 'h1', `module_name_3` = 'dd1', `module_quote_3` = 'h1', `icon` = '/assets/images/service_icon/1693494261male.jpg', `created_at` = 1693494647, `created_by` = '2'
WHERE `id` = '1'
INFO - 2023-08-31 17:10:47 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-31 17:11:42 --> Config Class Initialized
INFO - 2023-08-31 17:11:42 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:11:42 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:11:42 --> Utf8 Class Initialized
INFO - 2023-08-31 17:11:42 --> URI Class Initialized
INFO - 2023-08-31 17:11:42 --> Router Class Initialized
INFO - 2023-08-31 17:11:42 --> Output Class Initialized
INFO - 2023-08-31 17:11:42 --> Security Class Initialized
DEBUG - 2023-08-31 17:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:11:42 --> Input Class Initialized
INFO - 2023-08-31 17:11:42 --> Language Class Initialized
INFO - 2023-08-31 17:11:42 --> Loader Class Initialized
INFO - 2023-08-31 17:11:42 --> Helper loaded: url_helper
INFO - 2023-08-31 17:11:42 --> Helper loaded: file_helper
INFO - 2023-08-31 17:11:42 --> Database Driver Class Initialized
INFO - 2023-08-31 17:11:42 --> Email Class Initialized
DEBUG - 2023-08-31 17:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:11:42 --> Controller Class Initialized
INFO - 2023-08-31 17:11:42 --> Model "Services_model" initialized
INFO - 2023-08-31 17:11:42 --> Helper loaded: form_helper
INFO - 2023-08-31 17:11:42 --> Form Validation Class Initialized
INFO - 2023-08-31 17:11:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-31 17:11:42 --> Config Class Initialized
INFO - 2023-08-31 17:11:42 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:11:42 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:11:42 --> Utf8 Class Initialized
INFO - 2023-08-31 17:11:42 --> URI Class Initialized
INFO - 2023-08-31 17:11:42 --> Router Class Initialized
INFO - 2023-08-31 17:11:42 --> Output Class Initialized
INFO - 2023-08-31 17:11:42 --> Security Class Initialized
DEBUG - 2023-08-31 17:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:11:42 --> Input Class Initialized
INFO - 2023-08-31 17:11:42 --> Language Class Initialized
INFO - 2023-08-31 17:11:42 --> Loader Class Initialized
INFO - 2023-08-31 17:11:42 --> Helper loaded: url_helper
INFO - 2023-08-31 17:11:42 --> Helper loaded: file_helper
INFO - 2023-08-31 17:11:42 --> Database Driver Class Initialized
INFO - 2023-08-31 17:11:42 --> Email Class Initialized
DEBUG - 2023-08-31 17:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:11:42 --> Controller Class Initialized
INFO - 2023-08-31 17:11:42 --> Model "Services_model" initialized
INFO - 2023-08-31 17:11:42 --> Helper loaded: form_helper
INFO - 2023-08-31 17:11:42 --> Form Validation Class Initialized
INFO - 2023-08-31 17:11:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-31 17:11:42 --> Final output sent to browser
DEBUG - 2023-08-31 17:11:42 --> Total execution time: 0.1109
INFO - 2023-08-31 17:11:55 --> Config Class Initialized
INFO - 2023-08-31 17:11:55 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:11:55 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:11:55 --> Utf8 Class Initialized
INFO - 2023-08-31 17:11:55 --> URI Class Initialized
INFO - 2023-08-31 17:11:55 --> Router Class Initialized
INFO - 2023-08-31 17:11:55 --> Output Class Initialized
INFO - 2023-08-31 17:11:55 --> Security Class Initialized
DEBUG - 2023-08-31 17:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:11:56 --> Input Class Initialized
INFO - 2023-08-31 17:11:56 --> Language Class Initialized
INFO - 2023-08-31 17:11:56 --> Loader Class Initialized
INFO - 2023-08-31 17:11:56 --> Helper loaded: url_helper
INFO - 2023-08-31 17:11:56 --> Helper loaded: file_helper
INFO - 2023-08-31 17:11:56 --> Database Driver Class Initialized
INFO - 2023-08-31 17:11:56 --> Email Class Initialized
DEBUG - 2023-08-31 17:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:11:56 --> Controller Class Initialized
INFO - 2023-08-31 17:11:56 --> Model "Services_model" initialized
INFO - 2023-08-31 17:11:56 --> Helper loaded: form_helper
INFO - 2023-08-31 17:11:56 --> Form Validation Class Initialized
INFO - 2023-08-31 17:11:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 17:11:56 --> Final output sent to browser
DEBUG - 2023-08-31 17:11:56 --> Total execution time: 1.1469
INFO - 2023-08-31 17:11:57 --> Config Class Initialized
INFO - 2023-08-31 17:11:57 --> Hooks Class Initialized
DEBUG - 2023-08-31 17:11:57 --> UTF-8 Support Enabled
INFO - 2023-08-31 17:11:57 --> Utf8 Class Initialized
INFO - 2023-08-31 17:11:57 --> URI Class Initialized
INFO - 2023-08-31 17:11:57 --> Router Class Initialized
INFO - 2023-08-31 17:11:57 --> Output Class Initialized
INFO - 2023-08-31 17:11:57 --> Security Class Initialized
DEBUG - 2023-08-31 17:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-31 17:11:57 --> Input Class Initialized
INFO - 2023-08-31 17:11:57 --> Language Class Initialized
INFO - 2023-08-31 17:11:57 --> Loader Class Initialized
INFO - 2023-08-31 17:11:57 --> Helper loaded: url_helper
INFO - 2023-08-31 17:11:57 --> Helper loaded: file_helper
INFO - 2023-08-31 17:11:57 --> Database Driver Class Initialized
INFO - 2023-08-31 17:11:57 --> Email Class Initialized
DEBUG - 2023-08-31 17:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-31 17:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-31 17:11:57 --> Controller Class Initialized
INFO - 2023-08-31 17:11:57 --> Model "Services_model" initialized
INFO - 2023-08-31 17:11:57 --> Helper loaded: form_helper
INFO - 2023-08-31 17:11:57 --> Form Validation Class Initialized
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-08-31 17:11:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-08-31 17:11:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-31 17:11:57 --> Final output sent to browser
DEBUG - 2023-08-31 17:11:57 --> Total execution time: 0.0631
