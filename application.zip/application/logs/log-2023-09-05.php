<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-05 17:53:43 --> Config Class Initialized
INFO - 2023-09-05 17:53:43 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:53:44 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:53:44 --> Utf8 Class Initialized
INFO - 2023-09-05 17:53:44 --> URI Class Initialized
DEBUG - 2023-09-05 17:53:44 --> No URI present. Default controller set.
INFO - 2023-09-05 17:53:44 --> Router Class Initialized
INFO - 2023-09-05 17:53:44 --> Output Class Initialized
INFO - 2023-09-05 17:53:44 --> Security Class Initialized
DEBUG - 2023-09-05 17:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:53:44 --> Input Class Initialized
INFO - 2023-09-05 17:53:44 --> Language Class Initialized
INFO - 2023-09-05 17:53:45 --> Loader Class Initialized
INFO - 2023-09-05 17:53:45 --> Helper loaded: url_helper
INFO - 2023-09-05 17:53:45 --> Helper loaded: file_helper
INFO - 2023-09-05 17:53:45 --> Database Driver Class Initialized
INFO - 2023-09-05 17:53:45 --> Email Class Initialized
DEBUG - 2023-09-05 17:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 17:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 17:53:46 --> Controller Class Initialized
INFO - 2023-09-05 17:53:46 --> Model "Contact_model" initialized
INFO - 2023-09-05 17:53:46 --> Model "Home_model" initialized
INFO - 2023-09-05 17:53:46 --> Helper loaded: download_helper
INFO - 2023-09-05 17:53:46 --> Helper loaded: form_helper
INFO - 2023-09-05 17:53:46 --> Form Validation Class Initialized
INFO - 2023-09-05 17:53:47 --> Helper loaded: custom_helper
INFO - 2023-09-05 17:53:47 --> Model "Social_media_model" initialized
INFO - 2023-09-05 17:53:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-05 17:53:47 --> Final output sent to browser
DEBUG - 2023-09-05 17:53:47 --> Total execution time: 4.0519
INFO - 2023-09-05 17:53:51 --> Config Class Initialized
INFO - 2023-09-05 17:53:51 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:53:51 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:53:51 --> Utf8 Class Initialized
INFO - 2023-09-05 17:53:51 --> URI Class Initialized
INFO - 2023-09-05 17:53:51 --> Router Class Initialized
INFO - 2023-09-05 17:53:51 --> Output Class Initialized
INFO - 2023-09-05 17:53:51 --> Security Class Initialized
DEBUG - 2023-09-05 17:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:53:51 --> Input Class Initialized
INFO - 2023-09-05 17:53:51 --> Language Class Initialized
ERROR - 2023-09-05 17:53:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-05 17:54:01 --> Config Class Initialized
INFO - 2023-09-05 17:54:01 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:54:01 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:54:01 --> Utf8 Class Initialized
INFO - 2023-09-05 17:54:01 --> URI Class Initialized
DEBUG - 2023-09-05 17:54:01 --> No URI present. Default controller set.
INFO - 2023-09-05 17:54:01 --> Router Class Initialized
INFO - 2023-09-05 17:54:01 --> Output Class Initialized
INFO - 2023-09-05 17:54:01 --> Security Class Initialized
DEBUG - 2023-09-05 17:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:54:01 --> Input Class Initialized
INFO - 2023-09-05 17:54:01 --> Language Class Initialized
INFO - 2023-09-05 17:54:01 --> Loader Class Initialized
INFO - 2023-09-05 17:54:01 --> Helper loaded: url_helper
INFO - 2023-09-05 17:54:01 --> Helper loaded: file_helper
INFO - 2023-09-05 17:54:01 --> Database Driver Class Initialized
INFO - 2023-09-05 17:54:01 --> Email Class Initialized
DEBUG - 2023-09-05 17:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 17:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 17:54:01 --> Controller Class Initialized
INFO - 2023-09-05 17:54:01 --> Model "Contact_model" initialized
INFO - 2023-09-05 17:54:01 --> Model "Home_model" initialized
INFO - 2023-09-05 17:54:01 --> Helper loaded: download_helper
INFO - 2023-09-05 17:54:01 --> Helper loaded: form_helper
INFO - 2023-09-05 17:54:01 --> Form Validation Class Initialized
INFO - 2023-09-05 17:54:01 --> Helper loaded: custom_helper
INFO - 2023-09-05 17:54:01 --> Model "Social_media_model" initialized
INFO - 2023-09-05 17:54:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-05 17:54:02 --> Final output sent to browser
DEBUG - 2023-09-05 17:54:02 --> Total execution time: 0.2171
INFO - 2023-09-05 17:54:02 --> Config Class Initialized
INFO - 2023-09-05 17:54:02 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:54:02 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:54:02 --> Utf8 Class Initialized
INFO - 2023-09-05 17:54:02 --> URI Class Initialized
INFO - 2023-09-05 17:54:02 --> Router Class Initialized
INFO - 2023-09-05 17:54:02 --> Output Class Initialized
INFO - 2023-09-05 17:54:02 --> Security Class Initialized
DEBUG - 2023-09-05 17:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:54:02 --> Input Class Initialized
INFO - 2023-09-05 17:54:02 --> Language Class Initialized
ERROR - 2023-09-05 17:54:02 --> 404 Page Not Found: Assets/images
INFO - 2023-09-05 17:54:09 --> Config Class Initialized
INFO - 2023-09-05 17:54:09 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:54:09 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:54:09 --> Utf8 Class Initialized
INFO - 2023-09-05 17:54:09 --> URI Class Initialized
INFO - 2023-09-05 17:54:09 --> Router Class Initialized
INFO - 2023-09-05 17:54:09 --> Output Class Initialized
INFO - 2023-09-05 17:54:09 --> Security Class Initialized
DEBUG - 2023-09-05 17:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:54:09 --> Input Class Initialized
INFO - 2023-09-05 17:54:09 --> Language Class Initialized
ERROR - 2023-09-05 17:54:09 --> 404 Page Not Found: admin//index
INFO - 2023-09-05 17:54:15 --> Config Class Initialized
INFO - 2023-09-05 17:54:15 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:54:15 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:54:15 --> Utf8 Class Initialized
INFO - 2023-09-05 17:54:15 --> URI Class Initialized
INFO - 2023-09-05 17:54:15 --> Router Class Initialized
INFO - 2023-09-05 17:54:15 --> Output Class Initialized
INFO - 2023-09-05 17:54:15 --> Security Class Initialized
DEBUG - 2023-09-05 17:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:54:15 --> Input Class Initialized
INFO - 2023-09-05 17:54:15 --> Language Class Initialized
INFO - 2023-09-05 17:54:15 --> Loader Class Initialized
INFO - 2023-09-05 17:54:15 --> Helper loaded: url_helper
INFO - 2023-09-05 17:54:15 --> Helper loaded: file_helper
INFO - 2023-09-05 17:54:15 --> Database Driver Class Initialized
INFO - 2023-09-05 17:54:15 --> Email Class Initialized
DEBUG - 2023-09-05 17:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 17:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 17:54:15 --> Controller Class Initialized
INFO - 2023-09-05 17:54:15 --> Model "User_model" initialized
INFO - 2023-09-05 17:54:15 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-09-05 17:54:15 --> Final output sent to browser
DEBUG - 2023-09-05 17:54:15 --> Total execution time: 0.2496
INFO - 2023-09-05 17:54:17 --> Config Class Initialized
INFO - 2023-09-05 17:54:17 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:54:17 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:54:17 --> Utf8 Class Initialized
INFO - 2023-09-05 17:54:17 --> URI Class Initialized
INFO - 2023-09-05 17:54:17 --> Router Class Initialized
INFO - 2023-09-05 17:54:17 --> Output Class Initialized
INFO - 2023-09-05 17:54:17 --> Security Class Initialized
DEBUG - 2023-09-05 17:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:54:17 --> Input Class Initialized
INFO - 2023-09-05 17:54:17 --> Language Class Initialized
ERROR - 2023-09-05 17:54:17 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-05 17:54:24 --> Config Class Initialized
INFO - 2023-09-05 17:54:24 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:54:24 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:54:24 --> Utf8 Class Initialized
INFO - 2023-09-05 17:54:24 --> URI Class Initialized
INFO - 2023-09-05 17:54:24 --> Router Class Initialized
INFO - 2023-09-05 17:54:24 --> Output Class Initialized
INFO - 2023-09-05 17:54:24 --> Security Class Initialized
DEBUG - 2023-09-05 17:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:54:24 --> Input Class Initialized
INFO - 2023-09-05 17:54:24 --> Language Class Initialized
INFO - 2023-09-05 17:54:24 --> Loader Class Initialized
INFO - 2023-09-05 17:54:24 --> Helper loaded: url_helper
INFO - 2023-09-05 17:54:24 --> Helper loaded: file_helper
INFO - 2023-09-05 17:54:24 --> Database Driver Class Initialized
INFO - 2023-09-05 17:54:24 --> Email Class Initialized
DEBUG - 2023-09-05 17:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 17:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 17:54:24 --> Controller Class Initialized
INFO - 2023-09-05 17:54:24 --> Model "User_model" initialized
INFO - 2023-09-05 17:54:24 --> Config Class Initialized
INFO - 2023-09-05 17:54:24 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:54:24 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:54:24 --> Utf8 Class Initialized
INFO - 2023-09-05 17:54:24 --> URI Class Initialized
INFO - 2023-09-05 17:54:24 --> Router Class Initialized
INFO - 2023-09-05 17:54:24 --> Output Class Initialized
INFO - 2023-09-05 17:54:24 --> Security Class Initialized
DEBUG - 2023-09-05 17:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:54:24 --> Input Class Initialized
INFO - 2023-09-05 17:54:25 --> Language Class Initialized
INFO - 2023-09-05 17:54:25 --> Loader Class Initialized
INFO - 2023-09-05 17:54:25 --> Helper loaded: url_helper
INFO - 2023-09-05 17:54:25 --> Helper loaded: file_helper
INFO - 2023-09-05 17:54:25 --> Database Driver Class Initialized
INFO - 2023-09-05 17:54:25 --> Email Class Initialized
DEBUG - 2023-09-05 17:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 17:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 17:54:25 --> Controller Class Initialized
INFO - 2023-09-05 17:54:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-09-05 17:54:25 --> Final output sent to browser
DEBUG - 2023-09-05 17:54:25 --> Total execution time: 0.1832
INFO - 2023-09-05 17:54:45 --> Config Class Initialized
INFO - 2023-09-05 17:54:45 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:54:45 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:54:45 --> Utf8 Class Initialized
INFO - 2023-09-05 17:54:45 --> URI Class Initialized
INFO - 2023-09-05 17:54:45 --> Router Class Initialized
INFO - 2023-09-05 17:54:45 --> Output Class Initialized
INFO - 2023-09-05 17:54:45 --> Security Class Initialized
DEBUG - 2023-09-05 17:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:54:45 --> Input Class Initialized
INFO - 2023-09-05 17:54:45 --> Language Class Initialized
INFO - 2023-09-05 17:54:45 --> Loader Class Initialized
INFO - 2023-09-05 17:54:45 --> Helper loaded: url_helper
INFO - 2023-09-05 17:54:45 --> Helper loaded: file_helper
INFO - 2023-09-05 17:54:45 --> Database Driver Class Initialized
INFO - 2023-09-05 17:54:45 --> Email Class Initialized
DEBUG - 2023-09-05 17:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 17:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 17:54:45 --> Controller Class Initialized
INFO - 2023-09-05 17:54:45 --> Model "Services_model" initialized
INFO - 2023-09-05 17:54:45 --> Helper loaded: form_helper
INFO - 2023-09-05 17:54:45 --> Form Validation Class Initialized
INFO - 2023-09-05 17:54:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-05 17:54:46 --> Final output sent to browser
DEBUG - 2023-09-05 17:54:46 --> Total execution time: 0.2622
INFO - 2023-09-05 17:54:52 --> Config Class Initialized
INFO - 2023-09-05 17:54:52 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:54:52 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:54:52 --> Utf8 Class Initialized
INFO - 2023-09-05 17:54:52 --> URI Class Initialized
INFO - 2023-09-05 17:54:52 --> Router Class Initialized
INFO - 2023-09-05 17:54:52 --> Output Class Initialized
INFO - 2023-09-05 17:54:52 --> Security Class Initialized
DEBUG - 2023-09-05 17:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:54:52 --> Input Class Initialized
INFO - 2023-09-05 17:54:52 --> Language Class Initialized
INFO - 2023-09-05 17:54:52 --> Loader Class Initialized
INFO - 2023-09-05 17:54:52 --> Helper loaded: url_helper
INFO - 2023-09-05 17:54:52 --> Helper loaded: file_helper
INFO - 2023-09-05 17:54:52 --> Database Driver Class Initialized
INFO - 2023-09-05 17:54:52 --> Email Class Initialized
DEBUG - 2023-09-05 17:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 17:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 17:54:52 --> Controller Class Initialized
INFO - 2023-09-05 17:54:52 --> Model "Services_model" initialized
INFO - 2023-09-05 17:54:52 --> Helper loaded: form_helper
INFO - 2023-09-05 17:54:52 --> Form Validation Class Initialized
INFO - 2023-09-05 17:54:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-09-05 17:54:52 --> Final output sent to browser
DEBUG - 2023-09-05 17:54:52 --> Total execution time: 0.2505
INFO - 2023-09-05 17:54:53 --> Config Class Initialized
INFO - 2023-09-05 17:54:53 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:54:53 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:54:53 --> Utf8 Class Initialized
INFO - 2023-09-05 17:54:53 --> URI Class Initialized
INFO - 2023-09-05 17:54:53 --> Router Class Initialized
INFO - 2023-09-05 17:54:53 --> Output Class Initialized
INFO - 2023-09-05 17:54:53 --> Security Class Initialized
DEBUG - 2023-09-05 17:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:54:53 --> Input Class Initialized
INFO - 2023-09-05 17:54:53 --> Language Class Initialized
ERROR - 2023-09-05 17:54:53 --> 404 Page Not Found: admin/Services/images
INFO - 2023-09-05 17:58:27 --> Config Class Initialized
INFO - 2023-09-05 17:58:27 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:58:27 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:58:27 --> Utf8 Class Initialized
INFO - 2023-09-05 17:58:27 --> URI Class Initialized
INFO - 2023-09-05 17:58:27 --> Router Class Initialized
INFO - 2023-09-05 17:58:27 --> Output Class Initialized
INFO - 2023-09-05 17:58:27 --> Security Class Initialized
DEBUG - 2023-09-05 17:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:58:27 --> Input Class Initialized
INFO - 2023-09-05 17:58:27 --> Language Class Initialized
INFO - 2023-09-05 17:58:27 --> Loader Class Initialized
INFO - 2023-09-05 17:58:27 --> Helper loaded: url_helper
INFO - 2023-09-05 17:58:27 --> Helper loaded: file_helper
INFO - 2023-09-05 17:58:27 --> Database Driver Class Initialized
INFO - 2023-09-05 17:58:27 --> Email Class Initialized
DEBUG - 2023-09-05 17:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 17:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 17:58:27 --> Controller Class Initialized
INFO - 2023-09-05 17:58:27 --> Model "Services_model" initialized
INFO - 2023-09-05 17:58:27 --> Helper loaded: form_helper
INFO - 2023-09-05 17:58:27 --> Form Validation Class Initialized
INFO - 2023-09-05 17:58:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-05 17:58:27 --> Final output sent to browser
DEBUG - 2023-09-05 17:58:28 --> Total execution time: 0.3246
INFO - 2023-09-05 17:58:30 --> Config Class Initialized
INFO - 2023-09-05 17:58:30 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:58:30 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:58:30 --> Utf8 Class Initialized
INFO - 2023-09-05 17:58:30 --> URI Class Initialized
INFO - 2023-09-05 17:58:30 --> Router Class Initialized
INFO - 2023-09-05 17:58:31 --> Output Class Initialized
INFO - 2023-09-05 17:58:31 --> Security Class Initialized
DEBUG - 2023-09-05 17:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:58:31 --> Input Class Initialized
INFO - 2023-09-05 17:58:31 --> Language Class Initialized
INFO - 2023-09-05 17:58:31 --> Loader Class Initialized
INFO - 2023-09-05 17:58:31 --> Helper loaded: url_helper
INFO - 2023-09-05 17:58:31 --> Helper loaded: file_helper
INFO - 2023-09-05 17:58:31 --> Database Driver Class Initialized
INFO - 2023-09-05 17:58:31 --> Email Class Initialized
DEBUG - 2023-09-05 17:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 17:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 17:58:31 --> Controller Class Initialized
INFO - 2023-09-05 17:58:31 --> Model "Services_model" initialized
INFO - 2023-09-05 17:58:31 --> Helper loaded: form_helper
INFO - 2023-09-05 17:58:31 --> Form Validation Class Initialized
INFO - 2023-09-05 17:58:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-05 17:58:31 --> Final output sent to browser
DEBUG - 2023-09-05 17:58:31 --> Total execution time: 0.4595
INFO - 2023-09-05 17:58:32 --> Config Class Initialized
INFO - 2023-09-05 17:58:32 --> Hooks Class Initialized
DEBUG - 2023-09-05 17:58:32 --> UTF-8 Support Enabled
INFO - 2023-09-05 17:58:32 --> Utf8 Class Initialized
INFO - 2023-09-05 17:58:32 --> URI Class Initialized
INFO - 2023-09-05 17:58:32 --> Router Class Initialized
INFO - 2023-09-05 17:58:32 --> Output Class Initialized
INFO - 2023-09-05 17:58:32 --> Security Class Initialized
DEBUG - 2023-09-05 17:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 17:58:32 --> Input Class Initialized
INFO - 2023-09-05 17:58:32 --> Language Class Initialized
INFO - 2023-09-05 17:58:32 --> Loader Class Initialized
INFO - 2023-09-05 17:58:32 --> Helper loaded: url_helper
INFO - 2023-09-05 17:58:32 --> Helper loaded: file_helper
INFO - 2023-09-05 17:58:32 --> Database Driver Class Initialized
INFO - 2023-09-05 17:58:32 --> Email Class Initialized
DEBUG - 2023-09-05 17:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 17:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 17:58:32 --> Controller Class Initialized
INFO - 2023-09-05 17:58:32 --> Model "Services_model" initialized
INFO - 2023-09-05 17:58:32 --> Helper loaded: form_helper
INFO - 2023-09-05 17:58:32 --> Form Validation Class Initialized
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-09-05 17:58:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-09-05 17:58:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-05 17:58:32 --> Final output sent to browser
DEBUG - 2023-09-05 17:58:32 --> Total execution time: 0.2472
INFO - 2023-09-05 18:01:24 --> Config Class Initialized
INFO - 2023-09-05 18:01:24 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:01:24 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:01:24 --> Utf8 Class Initialized
INFO - 2023-09-05 18:01:24 --> URI Class Initialized
INFO - 2023-09-05 18:01:24 --> Router Class Initialized
INFO - 2023-09-05 18:01:24 --> Output Class Initialized
INFO - 2023-09-05 18:01:24 --> Security Class Initialized
DEBUG - 2023-09-05 18:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:01:24 --> Input Class Initialized
INFO - 2023-09-05 18:01:24 --> Language Class Initialized
INFO - 2023-09-05 18:01:24 --> Loader Class Initialized
INFO - 2023-09-05 18:01:24 --> Helper loaded: url_helper
INFO - 2023-09-05 18:01:24 --> Helper loaded: file_helper
INFO - 2023-09-05 18:01:24 --> Database Driver Class Initialized
INFO - 2023-09-05 18:01:24 --> Email Class Initialized
DEBUG - 2023-09-05 18:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:01:24 --> Controller Class Initialized
INFO - 2023-09-05 18:01:24 --> Model "Services_model" initialized
INFO - 2023-09-05 18:01:24 --> Helper loaded: form_helper
INFO - 2023-09-05 18:01:24 --> Form Validation Class Initialized
INFO - 2023-09-05 18:01:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-05 18:01:25 --> Final output sent to browser
DEBUG - 2023-09-05 18:01:25 --> Total execution time: 0.1789
INFO - 2023-09-05 18:01:26 --> Config Class Initialized
INFO - 2023-09-05 18:01:26 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:01:26 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:01:26 --> Utf8 Class Initialized
INFO - 2023-09-05 18:01:26 --> URI Class Initialized
INFO - 2023-09-05 18:01:26 --> Router Class Initialized
INFO - 2023-09-05 18:01:26 --> Output Class Initialized
INFO - 2023-09-05 18:01:26 --> Security Class Initialized
DEBUG - 2023-09-05 18:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:01:26 --> Input Class Initialized
INFO - 2023-09-05 18:01:26 --> Language Class Initialized
INFO - 2023-09-05 18:01:26 --> Loader Class Initialized
INFO - 2023-09-05 18:01:26 --> Helper loaded: url_helper
INFO - 2023-09-05 18:01:26 --> Helper loaded: file_helper
INFO - 2023-09-05 18:01:26 --> Database Driver Class Initialized
INFO - 2023-09-05 18:01:26 --> Email Class Initialized
DEBUG - 2023-09-05 18:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:01:26 --> Controller Class Initialized
INFO - 2023-09-05 18:01:26 --> Model "Services_model" initialized
INFO - 2023-09-05 18:01:26 --> Helper loaded: form_helper
INFO - 2023-09-05 18:01:26 --> Form Validation Class Initialized
INFO - 2023-09-05 18:01:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-09-05 18:01:27 --> Final output sent to browser
DEBUG - 2023-09-05 18:01:27 --> Total execution time: 0.4285
INFO - 2023-09-05 18:02:05 --> Config Class Initialized
INFO - 2023-09-05 18:02:05 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:02:05 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:02:05 --> Utf8 Class Initialized
INFO - 2023-09-05 18:02:05 --> URI Class Initialized
INFO - 2023-09-05 18:02:05 --> Router Class Initialized
INFO - 2023-09-05 18:02:05 --> Output Class Initialized
INFO - 2023-09-05 18:02:05 --> Security Class Initialized
DEBUG - 2023-09-05 18:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:02:05 --> Input Class Initialized
INFO - 2023-09-05 18:02:05 --> Language Class Initialized
INFO - 2023-09-05 18:02:05 --> Loader Class Initialized
INFO - 2023-09-05 18:02:05 --> Helper loaded: url_helper
INFO - 2023-09-05 18:02:05 --> Helper loaded: file_helper
INFO - 2023-09-05 18:02:05 --> Database Driver Class Initialized
INFO - 2023-09-05 18:02:05 --> Email Class Initialized
DEBUG - 2023-09-05 18:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:02:05 --> Controller Class Initialized
INFO - 2023-09-05 18:02:05 --> Model "Services_model" initialized
INFO - 2023-09-05 18:02:05 --> Helper loaded: form_helper
INFO - 2023-09-05 18:02:05 --> Form Validation Class Initialized
INFO - 2023-09-05 18:02:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-05 18:02:05 --> Config Class Initialized
INFO - 2023-09-05 18:02:05 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:02:05 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:02:05 --> Utf8 Class Initialized
INFO - 2023-09-05 18:02:05 --> URI Class Initialized
INFO - 2023-09-05 18:02:05 --> Router Class Initialized
INFO - 2023-09-05 18:02:05 --> Output Class Initialized
INFO - 2023-09-05 18:02:05 --> Security Class Initialized
DEBUG - 2023-09-05 18:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:02:05 --> Input Class Initialized
INFO - 2023-09-05 18:02:05 --> Language Class Initialized
INFO - 2023-09-05 18:02:05 --> Loader Class Initialized
INFO - 2023-09-05 18:02:05 --> Helper loaded: url_helper
INFO - 2023-09-05 18:02:05 --> Helper loaded: file_helper
INFO - 2023-09-05 18:02:05 --> Database Driver Class Initialized
INFO - 2023-09-05 18:02:05 --> Email Class Initialized
DEBUG - 2023-09-05 18:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:02:05 --> Controller Class Initialized
INFO - 2023-09-05 18:02:05 --> Model "Services_model" initialized
INFO - 2023-09-05 18:02:05 --> Helper loaded: form_helper
INFO - 2023-09-05 18:02:05 --> Form Validation Class Initialized
INFO - 2023-09-05 18:02:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-05 18:02:05 --> Final output sent to browser
DEBUG - 2023-09-05 18:02:05 --> Total execution time: 0.3317
INFO - 2023-09-05 18:02:10 --> Config Class Initialized
INFO - 2023-09-05 18:02:10 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:02:10 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:02:10 --> Utf8 Class Initialized
INFO - 2023-09-05 18:02:10 --> URI Class Initialized
INFO - 2023-09-05 18:02:10 --> Router Class Initialized
INFO - 2023-09-05 18:02:10 --> Output Class Initialized
INFO - 2023-09-05 18:02:10 --> Security Class Initialized
DEBUG - 2023-09-05 18:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:02:10 --> Input Class Initialized
INFO - 2023-09-05 18:02:10 --> Language Class Initialized
INFO - 2023-09-05 18:02:10 --> Loader Class Initialized
INFO - 2023-09-05 18:02:10 --> Helper loaded: url_helper
INFO - 2023-09-05 18:02:10 --> Helper loaded: file_helper
INFO - 2023-09-05 18:02:10 --> Database Driver Class Initialized
INFO - 2023-09-05 18:02:10 --> Email Class Initialized
DEBUG - 2023-09-05 18:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:02:10 --> Controller Class Initialized
INFO - 2023-09-05 18:02:10 --> Model "Services_model" initialized
INFO - 2023-09-05 18:02:10 --> Helper loaded: form_helper
INFO - 2023-09-05 18:02:10 --> Form Validation Class Initialized
INFO - 2023-09-05 18:02:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-05 18:02:10 --> Final output sent to browser
DEBUG - 2023-09-05 18:02:10 --> Total execution time: 0.3162
INFO - 2023-09-05 18:02:11 --> Config Class Initialized
INFO - 2023-09-05 18:02:11 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:02:11 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:02:11 --> Utf8 Class Initialized
INFO - 2023-09-05 18:02:11 --> URI Class Initialized
INFO - 2023-09-05 18:02:11 --> Router Class Initialized
INFO - 2023-09-05 18:02:11 --> Output Class Initialized
INFO - 2023-09-05 18:02:11 --> Security Class Initialized
DEBUG - 2023-09-05 18:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:02:11 --> Input Class Initialized
INFO - 2023-09-05 18:02:11 --> Language Class Initialized
INFO - 2023-09-05 18:02:11 --> Loader Class Initialized
INFO - 2023-09-05 18:02:11 --> Helper loaded: url_helper
INFO - 2023-09-05 18:02:11 --> Helper loaded: file_helper
INFO - 2023-09-05 18:02:11 --> Database Driver Class Initialized
INFO - 2023-09-05 18:02:11 --> Email Class Initialized
DEBUG - 2023-09-05 18:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:02:11 --> Controller Class Initialized
INFO - 2023-09-05 18:02:11 --> Model "Services_model" initialized
INFO - 2023-09-05 18:02:11 --> Helper loaded: form_helper
INFO - 2023-09-05 18:02:11 --> Form Validation Class Initialized
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-09-05 18:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-09-05 18:02:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-05 18:02:11 --> Final output sent to browser
DEBUG - 2023-09-05 18:02:11 --> Total execution time: 0.0595
INFO - 2023-09-05 18:03:01 --> Config Class Initialized
INFO - 2023-09-05 18:03:01 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:03:01 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:03:01 --> Utf8 Class Initialized
INFO - 2023-09-05 18:03:01 --> URI Class Initialized
INFO - 2023-09-05 18:03:01 --> Router Class Initialized
INFO - 2023-09-05 18:03:01 --> Output Class Initialized
INFO - 2023-09-05 18:03:01 --> Security Class Initialized
DEBUG - 2023-09-05 18:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:03:01 --> Input Class Initialized
INFO - 2023-09-05 18:03:01 --> Language Class Initialized
INFO - 2023-09-05 18:03:01 --> Loader Class Initialized
INFO - 2023-09-05 18:03:01 --> Helper loaded: url_helper
INFO - 2023-09-05 18:03:01 --> Helper loaded: file_helper
INFO - 2023-09-05 18:03:01 --> Database Driver Class Initialized
INFO - 2023-09-05 18:03:01 --> Email Class Initialized
DEBUG - 2023-09-05 18:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:03:01 --> Controller Class Initialized
INFO - 2023-09-05 18:03:01 --> Model "Services_model" initialized
INFO - 2023-09-05 18:03:01 --> Helper loaded: form_helper
INFO - 2023-09-05 18:03:01 --> Form Validation Class Initialized
INFO - 2023-09-05 18:03:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-05 18:03:01 --> Final output sent to browser
DEBUG - 2023-09-05 18:03:02 --> Total execution time: 0.3368
INFO - 2023-09-05 18:03:02 --> Config Class Initialized
INFO - 2023-09-05 18:03:02 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:03:02 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:03:02 --> Utf8 Class Initialized
INFO - 2023-09-05 18:03:02 --> URI Class Initialized
INFO - 2023-09-05 18:03:02 --> Router Class Initialized
INFO - 2023-09-05 18:03:02 --> Output Class Initialized
INFO - 2023-09-05 18:03:02 --> Security Class Initialized
DEBUG - 2023-09-05 18:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:03:02 --> Input Class Initialized
INFO - 2023-09-05 18:03:02 --> Language Class Initialized
INFO - 2023-09-05 18:03:02 --> Loader Class Initialized
INFO - 2023-09-05 18:03:02 --> Helper loaded: url_helper
INFO - 2023-09-05 18:03:02 --> Helper loaded: file_helper
INFO - 2023-09-05 18:03:02 --> Database Driver Class Initialized
INFO - 2023-09-05 18:03:02 --> Email Class Initialized
DEBUG - 2023-09-05 18:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:03:03 --> Controller Class Initialized
INFO - 2023-09-05 18:03:03 --> Model "Services_model" initialized
INFO - 2023-09-05 18:03:03 --> Helper loaded: form_helper
INFO - 2023-09-05 18:03:03 --> Form Validation Class Initialized
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-09-05 18:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-09-05 18:03:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-05 18:03:03 --> Final output sent to browser
DEBUG - 2023-09-05 18:03:03 --> Total execution time: 0.0676
INFO - 2023-09-05 18:03:47 --> Config Class Initialized
INFO - 2023-09-05 18:03:47 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:03:47 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:03:47 --> Utf8 Class Initialized
INFO - 2023-09-05 18:03:47 --> URI Class Initialized
INFO - 2023-09-05 18:03:47 --> Router Class Initialized
INFO - 2023-09-05 18:03:47 --> Output Class Initialized
INFO - 2023-09-05 18:03:47 --> Security Class Initialized
DEBUG - 2023-09-05 18:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:03:47 --> Input Class Initialized
INFO - 2023-09-05 18:03:47 --> Language Class Initialized
INFO - 2023-09-05 18:03:47 --> Loader Class Initialized
INFO - 2023-09-05 18:03:47 --> Helper loaded: url_helper
INFO - 2023-09-05 18:03:48 --> Helper loaded: file_helper
INFO - 2023-09-05 18:03:48 --> Database Driver Class Initialized
INFO - 2023-09-05 18:03:48 --> Email Class Initialized
DEBUG - 2023-09-05 18:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:03:48 --> Controller Class Initialized
INFO - 2023-09-05 18:03:48 --> Model "Services_model" initialized
INFO - 2023-09-05 18:03:48 --> Helper loaded: form_helper
INFO - 2023-09-05 18:03:48 --> Form Validation Class Initialized
INFO - 2023-09-05 18:03:48 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-05 18:03:48 --> Final output sent to browser
DEBUG - 2023-09-05 18:03:48 --> Total execution time: 0.7381
INFO - 2023-09-05 18:03:49 --> Config Class Initialized
INFO - 2023-09-05 18:03:49 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:03:49 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:03:49 --> Utf8 Class Initialized
INFO - 2023-09-05 18:03:49 --> URI Class Initialized
INFO - 2023-09-05 18:03:49 --> Router Class Initialized
INFO - 2023-09-05 18:03:49 --> Output Class Initialized
INFO - 2023-09-05 18:03:49 --> Security Class Initialized
DEBUG - 2023-09-05 18:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:03:49 --> Input Class Initialized
INFO - 2023-09-05 18:03:49 --> Language Class Initialized
INFO - 2023-09-05 18:03:49 --> Loader Class Initialized
INFO - 2023-09-05 18:03:49 --> Helper loaded: url_helper
INFO - 2023-09-05 18:03:49 --> Helper loaded: file_helper
INFO - 2023-09-05 18:03:49 --> Database Driver Class Initialized
INFO - 2023-09-05 18:03:49 --> Email Class Initialized
DEBUG - 2023-09-05 18:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:03:49 --> Controller Class Initialized
INFO - 2023-09-05 18:03:49 --> Model "Services_model" initialized
INFO - 2023-09-05 18:03:49 --> Helper loaded: form_helper
INFO - 2023-09-05 18:03:49 --> Form Validation Class Initialized
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-09-05 18:03:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-09-05 18:03:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-05 18:03:49 --> Final output sent to browser
DEBUG - 2023-09-05 18:03:49 --> Total execution time: 0.0536
INFO - 2023-09-05 18:04:35 --> Config Class Initialized
INFO - 2023-09-05 18:04:35 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:04:35 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:04:35 --> Utf8 Class Initialized
INFO - 2023-09-05 18:04:35 --> URI Class Initialized
INFO - 2023-09-05 18:04:35 --> Router Class Initialized
INFO - 2023-09-05 18:04:35 --> Output Class Initialized
INFO - 2023-09-05 18:04:35 --> Security Class Initialized
DEBUG - 2023-09-05 18:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:04:35 --> Input Class Initialized
INFO - 2023-09-05 18:04:35 --> Language Class Initialized
INFO - 2023-09-05 18:04:35 --> Loader Class Initialized
INFO - 2023-09-05 18:04:35 --> Helper loaded: url_helper
INFO - 2023-09-05 18:04:35 --> Helper loaded: file_helper
INFO - 2023-09-05 18:04:35 --> Database Driver Class Initialized
INFO - 2023-09-05 18:04:35 --> Email Class Initialized
DEBUG - 2023-09-05 18:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:04:35 --> Controller Class Initialized
INFO - 2023-09-05 18:04:35 --> Model "Services_model" initialized
INFO - 2023-09-05 18:04:35 --> Helper loaded: form_helper
INFO - 2023-09-05 18:04:35 --> Form Validation Class Initialized
INFO - 2023-09-05 18:04:35 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-05 18:04:35 --> Final output sent to browser
DEBUG - 2023-09-05 18:04:35 --> Total execution time: 0.6292
INFO - 2023-09-05 18:04:37 --> Config Class Initialized
INFO - 2023-09-05 18:04:37 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:04:37 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:04:37 --> Utf8 Class Initialized
INFO - 2023-09-05 18:04:37 --> URI Class Initialized
INFO - 2023-09-05 18:04:37 --> Router Class Initialized
INFO - 2023-09-05 18:04:37 --> Output Class Initialized
INFO - 2023-09-05 18:04:37 --> Security Class Initialized
DEBUG - 2023-09-05 18:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:04:37 --> Input Class Initialized
INFO - 2023-09-05 18:04:37 --> Language Class Initialized
INFO - 2023-09-05 18:04:37 --> Loader Class Initialized
INFO - 2023-09-05 18:04:37 --> Helper loaded: url_helper
INFO - 2023-09-05 18:04:37 --> Helper loaded: file_helper
INFO - 2023-09-05 18:04:37 --> Database Driver Class Initialized
INFO - 2023-09-05 18:04:37 --> Email Class Initialized
DEBUG - 2023-09-05 18:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:04:37 --> Controller Class Initialized
INFO - 2023-09-05 18:04:37 --> Model "Services_model" initialized
INFO - 2023-09-05 18:04:37 --> Helper loaded: form_helper
INFO - 2023-09-05 18:04:37 --> Form Validation Class Initialized
ERROR - 2023-09-05 18:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-05 18:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-09-05 18:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-09-05 18:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-09-05 18:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-09-05 18:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-09-05 18:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-09-05 18:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-05 18:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-09-05 18:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-09-05 18:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-09-05 18:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-09-05 18:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-09-05 18:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-09-05 18:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-09-05 18:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-09-05 18:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-09-05 18:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-09-05 18:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-09-05 18:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-09-05 18:04:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-05 18:04:38 --> Final output sent to browser
DEBUG - 2023-09-05 18:04:38 --> Total execution time: 0.9101
INFO - 2023-09-05 18:04:48 --> Config Class Initialized
INFO - 2023-09-05 18:04:48 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:04:48 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:04:48 --> Utf8 Class Initialized
INFO - 2023-09-05 18:04:48 --> URI Class Initialized
INFO - 2023-09-05 18:04:48 --> Router Class Initialized
INFO - 2023-09-05 18:04:48 --> Output Class Initialized
INFO - 2023-09-05 18:04:48 --> Security Class Initialized
DEBUG - 2023-09-05 18:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:04:48 --> Input Class Initialized
INFO - 2023-09-05 18:04:48 --> Language Class Initialized
INFO - 2023-09-05 18:04:48 --> Loader Class Initialized
INFO - 2023-09-05 18:04:48 --> Helper loaded: url_helper
INFO - 2023-09-05 18:04:48 --> Helper loaded: file_helper
INFO - 2023-09-05 18:04:48 --> Database Driver Class Initialized
INFO - 2023-09-05 18:04:48 --> Email Class Initialized
DEBUG - 2023-09-05 18:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:04:48 --> Controller Class Initialized
INFO - 2023-09-05 18:04:48 --> Model "Services_model" initialized
INFO - 2023-09-05 18:04:48 --> Helper loaded: form_helper
INFO - 2023-09-05 18:04:48 --> Form Validation Class Initialized
INFO - 2023-09-05 18:04:48 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-05 18:04:48 --> Final output sent to browser
DEBUG - 2023-09-05 18:04:48 --> Total execution time: 0.5656
INFO - 2023-09-05 18:04:49 --> Config Class Initialized
INFO - 2023-09-05 18:04:49 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:04:49 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:04:49 --> Utf8 Class Initialized
INFO - 2023-09-05 18:04:49 --> URI Class Initialized
INFO - 2023-09-05 18:04:49 --> Router Class Initialized
INFO - 2023-09-05 18:04:49 --> Output Class Initialized
INFO - 2023-09-05 18:04:49 --> Security Class Initialized
DEBUG - 2023-09-05 18:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:04:49 --> Input Class Initialized
INFO - 2023-09-05 18:04:49 --> Language Class Initialized
ERROR - 2023-09-05 18:04:50 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-05 18:04:51 --> Config Class Initialized
INFO - 2023-09-05 18:04:51 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:04:51 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:04:51 --> Utf8 Class Initialized
INFO - 2023-09-05 18:04:51 --> URI Class Initialized
INFO - 2023-09-05 18:04:51 --> Router Class Initialized
INFO - 2023-09-05 18:04:51 --> Output Class Initialized
INFO - 2023-09-05 18:04:51 --> Security Class Initialized
DEBUG - 2023-09-05 18:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:04:51 --> Input Class Initialized
INFO - 2023-09-05 18:04:51 --> Language Class Initialized
INFO - 2023-09-05 18:04:51 --> Loader Class Initialized
INFO - 2023-09-05 18:04:51 --> Helper loaded: url_helper
INFO - 2023-09-05 18:04:51 --> Helper loaded: file_helper
INFO - 2023-09-05 18:04:51 --> Database Driver Class Initialized
INFO - 2023-09-05 18:04:51 --> Email Class Initialized
DEBUG - 2023-09-05 18:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:04:51 --> Controller Class Initialized
INFO - 2023-09-05 18:04:51 --> Model "Services_model" initialized
INFO - 2023-09-05 18:04:51 --> Helper loaded: form_helper
INFO - 2023-09-05 18:04:51 --> Form Validation Class Initialized
INFO - 2023-09-05 18:04:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-09-05 18:04:51 --> Final output sent to browser
DEBUG - 2023-09-05 18:04:51 --> Total execution time: 0.4572
INFO - 2023-09-05 18:04:52 --> Config Class Initialized
INFO - 2023-09-05 18:04:52 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:04:52 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:04:52 --> Utf8 Class Initialized
INFO - 2023-09-05 18:04:52 --> URI Class Initialized
INFO - 2023-09-05 18:04:52 --> Router Class Initialized
INFO - 2023-09-05 18:04:52 --> Output Class Initialized
INFO - 2023-09-05 18:04:52 --> Security Class Initialized
DEBUG - 2023-09-05 18:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:04:52 --> Input Class Initialized
INFO - 2023-09-05 18:04:52 --> Language Class Initialized
ERROR - 2023-09-05 18:04:52 --> 404 Page Not Found: admin/Services/images
INFO - 2023-09-05 18:05:17 --> Config Class Initialized
INFO - 2023-09-05 18:05:18 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:05:18 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:05:18 --> Utf8 Class Initialized
INFO - 2023-09-05 18:05:18 --> URI Class Initialized
INFO - 2023-09-05 18:05:18 --> Router Class Initialized
INFO - 2023-09-05 18:05:18 --> Output Class Initialized
INFO - 2023-09-05 18:05:18 --> Security Class Initialized
DEBUG - 2023-09-05 18:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:05:18 --> Input Class Initialized
INFO - 2023-09-05 18:05:18 --> Language Class Initialized
INFO - 2023-09-05 18:05:18 --> Loader Class Initialized
INFO - 2023-09-05 18:05:18 --> Helper loaded: url_helper
INFO - 2023-09-05 18:05:18 --> Helper loaded: file_helper
INFO - 2023-09-05 18:05:18 --> Database Driver Class Initialized
INFO - 2023-09-05 18:05:18 --> Email Class Initialized
DEBUG - 2023-09-05 18:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:05:18 --> Controller Class Initialized
INFO - 2023-09-05 18:05:18 --> Model "Services_model" initialized
INFO - 2023-09-05 18:05:18 --> Helper loaded: form_helper
INFO - 2023-09-05 18:05:18 --> Form Validation Class Initialized
INFO - 2023-09-05 18:05:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-09-05 18:05:18 --> Final output sent to browser
DEBUG - 2023-09-05 18:05:18 --> Total execution time: 0.5931
INFO - 2023-09-05 18:05:20 --> Config Class Initialized
INFO - 2023-09-05 18:05:20 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:05:20 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:05:20 --> Utf8 Class Initialized
INFO - 2023-09-05 18:05:20 --> URI Class Initialized
INFO - 2023-09-05 18:05:20 --> Router Class Initialized
INFO - 2023-09-05 18:05:20 --> Output Class Initialized
INFO - 2023-09-05 18:05:20 --> Security Class Initialized
DEBUG - 2023-09-05 18:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:05:20 --> Input Class Initialized
INFO - 2023-09-05 18:05:20 --> Language Class Initialized
INFO - 2023-09-05 18:05:20 --> Loader Class Initialized
INFO - 2023-09-05 18:05:20 --> Helper loaded: url_helper
INFO - 2023-09-05 18:05:20 --> Helper loaded: file_helper
INFO - 2023-09-05 18:05:20 --> Database Driver Class Initialized
INFO - 2023-09-05 18:05:20 --> Email Class Initialized
DEBUG - 2023-09-05 18:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:05:20 --> Controller Class Initialized
INFO - 2023-09-05 18:05:20 --> Model "Services_model" initialized
INFO - 2023-09-05 18:05:20 --> Helper loaded: form_helper
INFO - 2023-09-05 18:05:20 --> Form Validation Class Initialized
INFO - 2023-09-05 18:05:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-05 18:05:20 --> Final output sent to browser
DEBUG - 2023-09-05 18:05:21 --> Total execution time: 0.5675
INFO - 2023-09-05 18:05:25 --> Config Class Initialized
INFO - 2023-09-05 18:05:25 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:05:25 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:05:25 --> Utf8 Class Initialized
INFO - 2023-09-05 18:05:25 --> URI Class Initialized
INFO - 2023-09-05 18:05:25 --> Router Class Initialized
INFO - 2023-09-05 18:05:25 --> Output Class Initialized
INFO - 2023-09-05 18:05:25 --> Security Class Initialized
DEBUG - 2023-09-05 18:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:05:25 --> Input Class Initialized
INFO - 2023-09-05 18:05:25 --> Language Class Initialized
INFO - 2023-09-05 18:05:25 --> Loader Class Initialized
INFO - 2023-09-05 18:05:25 --> Helper loaded: url_helper
INFO - 2023-09-05 18:05:25 --> Helper loaded: file_helper
INFO - 2023-09-05 18:05:25 --> Database Driver Class Initialized
INFO - 2023-09-05 18:05:25 --> Email Class Initialized
DEBUG - 2023-09-05 18:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:05:25 --> Controller Class Initialized
INFO - 2023-09-05 18:05:25 --> Model "Services_model" initialized
INFO - 2023-09-05 18:05:25 --> Helper loaded: form_helper
INFO - 2023-09-05 18:05:25 --> Form Validation Class Initialized
INFO - 2023-09-05 18:05:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-05 18:05:25 --> Final output sent to browser
DEBUG - 2023-09-05 18:05:26 --> Total execution time: 0.5672
INFO - 2023-09-05 18:05:26 --> Config Class Initialized
INFO - 2023-09-05 18:05:26 --> Hooks Class Initialized
DEBUG - 2023-09-05 18:05:26 --> UTF-8 Support Enabled
INFO - 2023-09-05 18:05:26 --> Utf8 Class Initialized
INFO - 2023-09-05 18:05:26 --> URI Class Initialized
INFO - 2023-09-05 18:05:26 --> Router Class Initialized
INFO - 2023-09-05 18:05:26 --> Output Class Initialized
INFO - 2023-09-05 18:05:26 --> Security Class Initialized
DEBUG - 2023-09-05 18:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 18:05:27 --> Input Class Initialized
INFO - 2023-09-05 18:05:27 --> Language Class Initialized
INFO - 2023-09-05 18:05:27 --> Loader Class Initialized
INFO - 2023-09-05 18:05:27 --> Helper loaded: url_helper
INFO - 2023-09-05 18:05:27 --> Helper loaded: file_helper
INFO - 2023-09-05 18:05:27 --> Database Driver Class Initialized
INFO - 2023-09-05 18:05:27 --> Email Class Initialized
DEBUG - 2023-09-05 18:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 18:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 18:05:27 --> Controller Class Initialized
INFO - 2023-09-05 18:05:27 --> Model "Services_model" initialized
INFO - 2023-09-05 18:05:27 --> Helper loaded: form_helper
INFO - 2023-09-05 18:05:27 --> Form Validation Class Initialized
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-09-05 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-09-05 18:05:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-05 18:05:27 --> Final output sent to browser
DEBUG - 2023-09-05 18:05:27 --> Total execution time: 1.0464
