
<meta name="google-site-verification" content="1gRjPjvKnKSv3uRyjFsV3faLSqPIdr04ocZTfOdrK9A" />
<script async src="https://www.googletagmanager.com/gtag/js?id=G-4MMT68X3EL"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-4MMT68X3EL');
</script>

<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=6935422259854837&ev=PageView&noscript=1" /></noscript>
<script>
    ! function(f, b, e, v, n, t, s) {
        if (f.fbq) return;
        n = f.fbq = function() {
            n.callMethod ?
                n.callMethod.apply(n, arguments) : n.queue.push(arguments)
        };
        if (!f._fbq) f._fbq = n;
        n.push = n;
        n.loaded = !0;
        n.version = '2.0';
        n.queue = [];
        t = b.createElement(e);
        t.async = !0;
        t.src = v;
        s = b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t, s)
    }(window, document, 'script',
        'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '6935422259854837');
    fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=6935422259854837&ev=PageView&noscript=1" /></noscript>



