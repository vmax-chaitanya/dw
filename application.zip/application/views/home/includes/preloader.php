<div class="preloader">
    <img class="preloader__image" width="60" src="<?php echo base_url();?>assets/home/images/loader.png" alt />
</div>